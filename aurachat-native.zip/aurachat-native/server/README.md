# AuraChat sunucusu
Sadece /api/send-notification: push bildirimi gönderir.
Vercel: Root Directory = server, ortam değişkeni FIREBASE_SERVICE_ACCOUNT (Firebase hizmet hesabı JSON'u).

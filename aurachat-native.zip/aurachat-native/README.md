# AuraChat Native

Kotlin + Jetpack Compose ile yazılan tam native AuraChat. Web sürümüyle AYNI Firebase
projesini (aurachat-99f69) ve aynı Firestore şemasını kullanır; iki sürüm birlikte çalışır.

## Derleme
GitHub → Actions → "Build Native APK" → Run workflow. Gerekli secret'lar:
- `GOOGLE_SERVICES_JSON` (mevcut projedekiyle aynı)
- `ANDROID_KEYSTORE_BASE64` (mevcut projedekiyle aynı; Google girişi için SHA-1 sabit kalır)

## Aşamalar
1. [x] Giriş (e-posta + Google), sohbet listesi, birebir sohbet (metin, tik, yazıyor), FCM bildirimi + dokununca sohbet
2. [ ] Fotoğraf/albüm gönderme-alma, galeri önbelleği, görüntüleyici
3. [ ] Yanıtla, ilet, sil, tepki, yıldız, düzenle, gün ayırıcı + okunmamış ayırıcı
4. [ ] Gruplar (oluştur, üye/yönetici, grup sohbeti)
5. [ ] Sesli mesaj, konum, belge, anket
6. [ ] Sesli/görüntülü arama (WebRTC), grup araması, tam ekran gelen arama
7. [ ] Durum, profil/avatar kırpma, sohbet teması, Drive yedekleme, paylaşım menüsü
8. [ ] Kayıt ekranı (telefon numarası seçici)

# AuraChat Native

Kotlin + Jetpack Compose ile yazılan tam native AuraChat. Web sürümüyle AYNI Firebase
projesini (aurachat-99f69) ve aynı Firestore şemasını kullanır; iki sürüm birlikte çalışır.

## Derleme
Repo kökündeki build.yml workflow'u zip'i açıp derler (google-services.json repo köküne konur).

## Aşamalar
1. [x] Giriş (e-posta + Google), sohbet listesi, birebir sohbet (metin, tik, yazıyor), FCM bildirimi + dokununca sohbet
2. [x] Fotoğraf/albüm gönderme-alma, galeri önbelleği, görüntüleyici
3. [x] Yanıtla, ilet, sil, tepki, yıldız, düzenle, gün ayırıcı + okunmamış ayırıcı
4. [x] Gruplar (oluştur, üye/yönetici, grup sohbeti)
5. [x] Sesli mesaj, konum, belge (anket: yer tutucu)
6. [ ] Sesli/görüntülü arama (WebRTC), grup araması, tam ekran gelen arama
7. [ ] Durum, profil/avatar kırpma, sohbet teması, Drive yedekleme, paylaşım menüsü
8. [ ] Kayıt ekranı (telefon numarası seçici)

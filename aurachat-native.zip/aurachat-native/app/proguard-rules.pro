# WebRTC (JNI native kodu Java sınıflarını adıyla çağırır)
-keep class org.webrtc.** { *; }
-keep class io.getstream.webrtc.** { *; }
-dontwarn org.webrtc.**

# Firebase / Google Play hizmetleri kendi kurallarını getirir; uyarıları sustur
-dontwarn com.google.android.gms.**
-dontwarn com.google.firebase.**

# Eski ikon takma adları (activity-alias) ve servisler manifestten korunur
-keep class com.aurachat.app.push.AuraFcmService { *; }
-keep class com.aurachat.app.call.CallService { *; }

-dontwarn javax.annotation.**
-dontwarn org.slf4j.**
-dontwarn org.checkerframework.**
-dontwarn kotlin.**

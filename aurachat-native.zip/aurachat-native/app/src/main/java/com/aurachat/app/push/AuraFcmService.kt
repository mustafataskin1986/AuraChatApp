package com.aurachat.app.push

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.aurachat.app.AppState
import com.aurachat.app.CHANNEL_MESSAGES
import com.aurachat.app.MainActivity
import com.aurachat.app.R
import com.aurachat.app.data.Repo
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class AuraFcmService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        Repo.saveToken(uid, token)
    }

    override fun onMessageReceived(m: RemoteMessage) {
        val d = m.data
        val chatId = d["chatId"] ?: ""
        if (d["kind"] == "call") {
            showCallNotification(d)
            return
        }
        // Cevapsız arama vb. geldiyse çalan arama bildirimini kaldır
        if (chatId.isNotEmpty()) com.aurachat.app.call.CallManager.cancelCallNotif(chatId)
        // Bu sohbet şu an ekranda açıksa bildirim gösterme
        if (AppState.foreground && chatId.isNotEmpty() && AppState.activeChatId == chatId) return

        // WhatsApp tarzı: sohbet başına tek bildirim bloğu + Cevapla / Okundu / Sessize al
        Notifs.show(this, d)
        // Fotoğraf / ses / belge: telefona indir, Firebase'deki kopyasını sil (arka planda)
        val type = d["msgType"] ?: ""
        val msgId = d["msgId"]?.takeIf { it.isNotEmpty() } ?: (d["tag"] ?: "").removePrefix("msg-")
        val me = FirebaseAuth.getInstance().currentUser?.uid
        if (me != null && chatId.isNotEmpty() && msgId.length == 20 && type != "call") {
            try {
                // Mesajı (yazı dahil) yerel veritabanına yaz; medya ise telefona indir
                val msg = Repo.fetchMessageBlocking(chatId, msgId)
                if (msg != null) {
                    com.aurachat.app.data.LocalDb.upsert(chatId, listOf(msg))
                    if (type == "image" || type == "audio" || type == "document") {
                        com.aurachat.app.data.LocalMedia.ingestBlocking(chatId, msg, me, d["isGroup"] == "1")
                    }
                }
            } catch (e: Throwable) {}
        }
    }

    private fun showCallNotification(d: Map<String, String>) {
        // Uygulama önündeyse arama ekranını Firestore dinleyicisi zaten gösterir
        if (AppState.foreground) return
        val chatId = d["chatId"] ?: return
        val name = d["callerName"] ?: d["otherName"] ?: "Arama"
        val video = d["callType"] != "audio"
        val open = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("incomingCall", true)
        }
        val id = (com.aurachat.app.call.CallManager.CALL_NOTIF_TAG + chatId).hashCode()
        val pi = PendingIntent.getActivity(
            this, id, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, com.aurachat.app.CHANNEL_CALLS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(name)
            .setContentText(if (video) "Görüntülü arama" else "Sesli arama")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .setAutoCancel(true)
            .setTimeoutAfter(45000)
            .setFullScreenIntent(pi, true)
            .setContentIntent(pi)
            .addAction(0, "Cevapla", pi)
            .build()
        notifySafely(this, id, n)
    }

    private fun notifySafely(ctx: Context, id: Int, n: android.app.Notification) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED || android.os.Build.VERSION.SDK_INT < 33
        ) {
            NotificationManagerCompat.from(ctx).notify(id, n)
        }
    }
}

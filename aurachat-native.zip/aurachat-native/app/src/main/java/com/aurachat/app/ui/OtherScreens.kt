package com.aurachat.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.ChatSummary
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Repo
import com.aurachat.app.data.StarredItem
import com.aurachat.app.data.UserProfile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** İletilecek sohbeti seç: mevcut sohbetler + henüz sohbet açılmamış kişiler */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForwardScreen(me: UserProfile, count: Int, title: String? = null, onBack: () -> Unit, onPick: (ChatTarget) -> Unit) {
    val chats by remember(me.uid) { Repo.chatsFlow(me.uid) }.collectAsState(emptyList<ChatSummary>())
    val users by remember(me.uid) { Repo.usersFlow(me.uid) }.collectAsState(Repo.cachedUsers() ?: emptyList())
    var q by remember { mutableStateOf("") }

    val existing = visibleChats(chats).sortedByDescending { it.lastTime }
    val existingIds = existing.map { it.chatId }.toSet()
    val rows = ArrayList<ChatTarget>()
    existing.forEach { rows.add(ChatTarget(it.chatId, it.isGroup, it.otherUid, it.name)) }
    users.forEach { u ->
        val id = Repo.chatId(me.uid, u.uid)
        if (!existingIds.contains(id)) rows.add(ChatTarget(id, false, u.uid, u.name))
    }
    val shown = rows.filter { q.isBlank() || it.name.contains(q, ignoreCase = true) }

    Scaffold(
        containerColor = AuraBg,
        topBar = {
            TopAppBar(
                title = { Text(title ?: if (count > 1) "$count mesajı ilet" else "Mesajı ilet") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AuraBg, titleContentColor = Color.White, navigationIconContentColor = Color.White),
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") } }
            )
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(
                value = q, onValueChange = { q = it }, placeholder = { Text("Ara") },
                singleLine = true, modifier = Modifier.fillMaxWidth().padding(12.dp)
            )
            LazyColumn {
                items(shown, key = { it.chatId }) { t ->
                    val lp by liveProfile(if (t.isGroup) "" else t.otherUid)
                    val avatar = lp?.avatar ?: ""
                    val liveName = liveChatName(t)
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(t) }.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(liveName, avatar, 44.dp, isGroup = t.isGroup)
                        Spacer(Modifier.width(14.dp))
                        Text(liveName, fontSize = 16.sp, color = Color.White)
                    }
                }
            }
        }
    }
}

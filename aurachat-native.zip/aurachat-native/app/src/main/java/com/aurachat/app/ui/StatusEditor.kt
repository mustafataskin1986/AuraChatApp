package com.aurachat.app.ui

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.CropRotate
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Media
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// =====================================================================
//  Durum fotoğraf düzenleyici (WhatsApp tarzı): filtre, yakınlaştırma, yazı, çizim, çıkartma, döndürme
// =====================================================================

/** Resmin üzerindeki yazı / çıkartma. x,y: çerçeveye göre 0..1 merkez konumu */
private data class StItem(
    val id: Int, val text: String, val color: Int, val font: Int, val bg: Int, val align: Int,
    val x: Float, val y: Float, val scale: Float, val rot: Float, val sticker: Boolean = false
)

/** Çizgi: pts çerçeveye göre 0..1; kind 0 ince kalem, 1 kalın kalem, 2 fosforlu, 3 silgi */
private class StStroke(val color: Int, val kind: Int) {
    val pts = mutableStateListOf<Offset>()
    val widthF: Float get() = when (kind) { 0 -> 0.008f; 1 -> 0.018f; 2 -> 0.035f; else -> 0.04f }
    val alpha: Float get() = if (kind == 2) 0.45f else 1f
}

private class StFilter(val name: String, val m: FloatArray)

private fun stMat(sat: Float = 1f, contrast: Float = 1f, bright: Float = 0f, rg: Float = 1f, gg: Float = 1f, bg: Float = 1f): FloatArray {
    val s = floatArrayOf(
        0.213f + 0.787f * sat, 0.715f - 0.715f * sat, 0.072f - 0.072f * sat,
        0.213f - 0.213f * sat, 0.715f + 0.285f * sat, 0.072f - 0.072f * sat,
        0.213f - 0.213f * sat, 0.715f - 0.715f * sat, 0.072f + 0.928f * sat
    )
    val gains = floatArrayOf(rg, gg, bg)
    val t = (1f - contrast) * 128f + bright
    val out = FloatArray(20)
    for (r in 0..2) {
        for (c in 0..2) out[r * 5 + c] = s[r * 3 + c] * contrast * gains[r]
        out[r * 5 + 4] = t * gains[r]
    }
    out[18] = 1f
    return out
}

private val StFilters = listOf(
    StFilter("Yok", stMat()),
    StFilter("Canlı", stMat(sat = 1.5f, contrast = 1.1f)),
    StFilter("S&B", stMat(sat = 0f)),
    StFilter("Soğuk", stMat(sat = 1.05f, rg = 0.9f, bg = 1.15f)),
    StFilter("Krom", stMat(sat = 1.3f, contrast = 1.3f, bright = -8f)),
    StFilter("Sıcak", stMat(sat = 1.1f, rg = 1.1f, bg = 0.88f, bright = 6f)),
    StFilter("Solgun", stMat(sat = 0.75f, contrast = 0.85f, bright = 22f)),
    StFilter("Sepya", floatArrayOf(
        0.393f, 0.769f, 0.189f, 0f, 0f,
        0.349f, 0.686f, 0.168f, 0f, 0f,
        0.272f, 0.534f, 0.131f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    ))
)

private val StSpectrum = listOf(
    Color.White, Color(0xFFFF1744), Color(0xFFFF9100), Color(0xFFFFEA00), Color(0xFF00E676),
    Color(0xFF00E5FF), Color(0xFF2979FF), Color(0xFFD500F9), Color(0xFFFF4081)
)

private fun stColorAt(t: Float): Color {
    val p = t.coerceIn(0f, 1f) * (StSpectrum.size - 1)
    val i = min(p.toInt(), StSpectrum.size - 2)
    return lerp(StSpectrum[i], StSpectrum[i + 1], p - i)
}

internal val StFontFamilies = listOf(FontFamily.SansSerif, FontFamily.Serif, FontFamily.Serif, FontFamily.SansSerif, FontFamily.Monospace, FontFamily.Cursive)
internal val StFontWeights = listOf(FontWeight.Normal, FontWeight.Normal, FontWeight.Normal, FontWeight.Bold, FontWeight.Bold, FontWeight.Normal)
internal val StFontStyles = listOf(FontStyle.Normal, FontStyle.Normal, FontStyle.Italic, FontStyle.Normal, FontStyle.Normal, FontStyle.Normal)

private fun stTypeface(i: Int): Typeface = when (i) {
    1 -> Typeface.SERIF
    2 -> Typeface.create(Typeface.SERIF, Typeface.ITALIC)
    3 -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    4 -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    5 -> Typeface.create("cursive", Typeface.NORMAL)
    else -> Typeface.SANS_SERIF
}

private val StEmojis = listOf(
    "😀", "😂", "🥰", "😍", "😎", "🤩", "😭", "😡", "🥳", "😴", "🤔", "🙏",
    "👍", "👏", "🙌", "💪", "❤️", "🔥", "✨", "🎉", "🎂", "🎁", "🌹", "🌞",
    "🌙", "⭐", "🌈", "☕", "🍕", "🍔", "⚽", "🎵", "📸", "✈️", "🏖️", "🚗",
    "🐶", "🐱", "🦋", "🌸", "💯", "✅", "❌", "💬", "📍", "🕌", "🤲", "🕋"
)

private fun stBubbleColors(t: StItem): Pair<Color, Color> {
    val c = Color(t.color)
    if (t.sticker) return Color.Transparent to c
    val lum = c.red * 0.299f + c.green * 0.587f + c.blue * 0.114f
    val contrast = if (lum > 0.6f) Color(0xFF111111) else Color.White
    return when (t.bg) {
        1 -> c to contrast                              // dolu zemin, zıt renkli yazı
        2 -> c.copy(alpha = 0.55f) to Color.White       // yarı saydam zemin, beyaz yazı
        3 -> contrast to c                              // zıt renkli zemin, seçilen renkte yazı
        else -> Color.Transparent to c                  // şeffaf zemin
    }
}

@Composable
private fun StBubble(t: StItem, frameW: Float, modifier: Modifier = Modifier) {
    val sizePx = frameW * (if (t.sticker) 0.22f else 0.075f)
    val (bgc, fg) = stBubbleColors(t)
    val d = LocalDensity.current
    val align = when (t.align) { 1 -> TextAlign.Start; 2 -> TextAlign.End; else -> TextAlign.Center }
    val f = t.font.coerceIn(0, 5)
    with(d) {
        Text(
            t.text, color = fg, fontSize = sizePx.toSp(), textAlign = align,
            fontFamily = StFontFamilies[f], fontWeight = StFontWeights[f], fontStyle = StFontStyles[f],
            modifier = modifier.widthIn(max = (frameW * 0.8f).toDp())
                .then(if (bgc.alpha > 0f) Modifier.background(bgc, RoundedCornerShape((sizePx * 0.3f).toDp())) else Modifier)
                .padding(horizontal = (sizePx * (if (t.sticker) 0.05f else 0.4f)).toDp(), vertical = (sizePx * (if (t.sticker) 0.05f else 0.2f)).toDp())
        )
    }
}

@Composable
private fun StColorSlider(t: Float, onT: (Float) -> Unit, modifier: Modifier = Modifier, onActive: (Boolean) -> Unit = {}) {
    var h by remember { mutableFloatStateOf(1f) }
    Box(
        modifier.width(10.dp).height(240.dp).onSizeChanged { h = it.height.toFloat().coerceAtLeast(1f) }
            .clip(RoundedCornerShape(5.dp)).background(Brush.verticalGradient(StSpectrum))
            .pointerInput(Unit) {
                detectTapGestures(onPress = { o -> onActive(true); onT((o.y / h).coerceIn(0f, 1f)); tryAwaitRelease(); onActive(false) })
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { onActive(true) }, onDragEnd = { onActive(false) }, onDragCancel = { onActive(false) },
                    onVerticalDrag = { c, _ -> c.consume(); onT((c.position.y / h).coerceIn(0f, 1f)) }
                )
            }
    ) {}
}

@Composable
private fun TopCircle(onClick: () -> Unit, active: Boolean = false, tint: Color? = null, content: @Composable () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(tint ?: if (active) Color(0xFF25D366) else Color(0x66000000)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(Color(0x99000000)).clickable { onClick() }.padding(horizontal = 18.dp, vertical = 10.dp)) {
        Text(text, color = Color.White, fontSize = 16.sp)
    }
}

/** Resim + süslemeleri tek bir JPEG'e işler (ekrandaki görünümle aynı hesap) */
private fun stRender(
    src: Bitmap, filter: FloatArray?, zoom: Float, pan: Offset, fw: Float, fh: Float,
    strokes: List<StStroke>, items: List<StItem>
): Bitmap {
    val w = 1080
    val h = (w * fh / fw).roundToInt().coerceIn(200, 2400)
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = AndroidCanvas(out)
    c.drawColor(android.graphics.Color.BLACK)
    val k = w / fw
    val fit = min(fw / src.width, fh / src.height)
    val ip = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    if (filter != null) ip.colorFilter = ColorMatrixColorFilter(filter)
    c.save()
    c.translate(w / 2f + pan.x * k, h / 2f + pan.y * k)
    val sc = fit * zoom * k
    c.scale(sc, sc)
    c.drawBitmap(src, -src.width / 2f, -src.height / 2f, ip)
    c.restore()

    if (strokes.isNotEmpty()) {
        val layer = c.saveLayer(null, null)
        strokes.forEach { s ->
            if (s.pts.isEmpty()) return@forEach
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
                strokeWidth = s.widthF * w
                color = s.color
                alpha = (s.alpha * 255).toInt()
                if (s.kind == 3) xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            }
            val path = android.graphics.Path()
            val f = s.pts.first()
            path.moveTo(f.x * w, f.y * h)
            if (s.pts.size == 1) path.lineTo(f.x * w + 0.01f, f.y * h)
            s.pts.drop(1).forEach { path.lineTo(it.x * w, it.y * h) }
            c.drawPath(path, p)
        }
        c.restoreToCount(layer)
    }

    items.forEach { t ->
        val sizePx = w * (if (t.sticker) 0.22f else 0.075f)
        val (bgc, fg) = stBubbleColors(t)
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = sizePx; color = fg.toArgb(); typeface = if (t.sticker) Typeface.DEFAULT else stTypeface(t.font) }
        val padX = sizePx * (if (t.sticker) 0.05f else 0.4f)
        val padY = sizePx * (if (t.sticker) 0.05f else 0.2f)
        val maxW = (w * 0.8f - 2 * padX).toInt().coerceAtLeast(50)
        val al = when (t.align) { 1 -> Layout.Alignment.ALIGN_NORMAL; 2 -> Layout.Alignment.ALIGN_OPPOSITE; else -> Layout.Alignment.ALIGN_CENTER }
        val probe = StaticLayout.Builder.obtain(t.text, 0, t.text.length, tp, maxW).setAlignment(al).build()
        var tw = 0f
        for (i in 0 until probe.lineCount) tw = max(tw, probe.getLineWidth(i))
        val lw = Math.ceil(tw.toDouble()).toInt().coerceIn(1, maxW)
        val lay = StaticLayout.Builder.obtain(t.text, 0, t.text.length, tp, lw).setAlignment(al).build()
        val bw = lw + 2 * padX
        val bh = lay.height + 2 * padY
        c.save()
        c.translate(t.x * w, t.y * h)
        c.rotate(t.rot)
        c.scale(t.scale, t.scale)
        if (bgc.alpha > 0f) {
            val bp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bgc.toArgb() }
            c.drawRoundRect(RectF(-bw / 2, -bh / 2, bw / 2, bh / 2), sizePx * 0.3f, sizePx * 0.3f, bp)
        }
        c.translate(-bw / 2 + padX, -bh / 2 + padY)
        lay.draw(c)
        c.restore()
    }
    return out
}

private class EdPage(val data: String, bmp: Bitmap) {
    var base by mutableStateOf(bmp)
    var rotated by mutableStateOf(false)
    var zoomV by mutableFloatStateOf(1f)
    var pan by mutableStateOf(Offset.Zero)
    var filterIdx by mutableIntStateOf(0)
    var caption by mutableStateOf("")
    val ovs = mutableStateListOf<StItem>()
    val strokes = mutableStateListOf<StStroke>()
    val sizes = mutableStateMapOf<Int, IntSize>()
    var nextId = 1
}

private enum class EdMode { NONE, FILTERS, TEXT, DRAW, STICKERS }

@Composable
fun StatusPhotoEditor(
    imageData: String, busy: Boolean,
    onClose: () -> Unit, onSoon: (String) -> Unit, onSend: (List<Pair<String, String>>) -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val orig = remember(imageData) { Media.decode(imageData, 1600) }
    if (orig == null) { LaunchedEffect(Unit) { onClose() }; return }

    val pages = remember(imageData) { mutableStateListOf(EdPage(imageData, orig)) }
    var sel by remember { mutableIntStateOf(0) }
    val pg = pages[sel.coerceIn(0, pages.lastIndex)]
    var mode by remember { mutableStateOf(EdMode.NONE) }
    var fw by remember { mutableFloatStateOf(1f) }
    var fh by remember { mutableFloatStateOf(1f) }
    var active by remember { mutableIntStateOf(-1) }
    var dragging by remember { mutableStateOf(false) }
    var swipeDx by remember { mutableFloatStateOf(0f) }
    var exporting by remember { mutableStateOf(false) }
    var cropping by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }

    // yazı düzenleme durumu
    var editId by remember { mutableIntStateOf(-1) }       // -1: yeni
    var dText by remember { mutableStateOf("") }
    var dColorT by remember { mutableFloatStateOf(0f) }
    var dFont by remember { mutableIntStateOf(0) }
    var dBg by remember { mutableIntStateOf(0) }
    var dAlign by remember { mutableIntStateOf(0) }
    val focus = remember { FocusRequester() }

    // çizim durumu
    var brush by remember { mutableIntStateOf(1) }
    var drawColorT by remember { mutableFloatStateOf(0.18f) }
    var drawing by remember { mutableStateOf(false) }
    var sliding by remember { mutableStateOf(false) }
    val ctlA by androidx.compose.animation.core.animateFloatAsState(if (drawing) 0f else 1f, androidx.compose.animation.core.tween(280), label = "ctl")

    fun openText(id: Int) {
        val t = pg.ovs.firstOrNull { it.id == id }
        editId = id
        if (t != null && !t.sticker) { dText = t.text; dFont = t.font; dBg = t.bg; dAlign = t.align
            // renk kaydırıcıda yaklaşık konum bulunamaz; en yakın tonu seç
            var best = 0f; var bd = Float.MAX_VALUE
            for (i in 0..100) { val cc = stColorAt(i / 100f); val dd = abs(cc.red - Color(t.color).red) + abs(cc.green - Color(t.color).green) + abs(cc.blue - Color(t.color).blue); if (dd < bd) { bd = dd; best = i / 100f } }
            dColorT = best
        } else { dText = ""; dFont = 0; dBg = 0; dAlign = 0; dColorT = 0f }
        mode = EdMode.TEXT
    }

    fun commitText() {
        val txt = dText.trim()
        if (txt.isEmpty()) { if (editId >= 0) pg.ovs.removeAll { it.id == editId } }
        else {
            val col = stColorAt(dColorT).toArgb()
            val i = pg.ovs.indexOfFirst { it.id == editId }
            if (i >= 0) pg.ovs[i] = pg.ovs[i].copy(text = txt, color = col, font = dFont, bg = dBg, align = dAlign)
            else pg.ovs.add(StItem(pg.nextId++, txt, col, dFont, dBg, dAlign, 0.5f, 0.45f, 1f, 0f))
        }
        mode = EdMode.NONE
    }

    fun hit(p: Offset): Int {
        for (t in pg.ovs.reversed()) {
            val sz = pg.sizes[t.id] ?: continue
            val d = p - Offset(t.x * fw, t.y * fh)
            val a = (t.rot * PI / 180.0).toFloat()
            val lx = d.x * cos(a) + d.y * sin(a)
            val ly = -d.x * sin(a) + d.y * cos(a)
            if (abs(lx) <= sz.width * t.scale / 2f + 28f && abs(ly) <= sz.height * t.scale / 2f + 28f) return t.id
        }
        return -1
    }

    fun clampPan(p: Offset, z: Float): Offset {
        val fit = min(fw / pg.base.width, fh / pg.base.height)
        val dw = pg.base.width * fit * z; val dh = pg.base.height * fit * z
        val lx = max(0f, (dw - fw) / 2f); val ly = max(0f, (dh - fh) / 2f)
        return Offset(p.x.coerceIn(-lx, lx), p.y.coerceIn(-ly, ly))
    }

    fun doExport() {
        if (exporting || busy) return
        exporting = true
        val snap = pages.toList()
        val w0 = fw; val h0 = fh
        scope.launch {
            val out = withContext(Dispatchers.Default) {
                snap.map { p ->
                    val unchanged = !p.rotated && p.filterIdx == 0 && p.zoomV == 1f && p.pan == Offset.Zero && p.ovs.isEmpty() && p.strokes.isEmpty()
                    val data = if (unchanged) p.data else try {
                        Media.bitmapToDataUrl(stRender(p.base, if (p.filterIdx == 0) null else StFilters[p.filterIdx].m, p.zoomV, p.pan, w0, h0, p.strokes.toList(), p.ovs.toList()), 300 * 1024)
                    } catch (e: Throwable) { com.aurachat.app.AuraLog.e("StatusEditor", e); "" }
                    data to p.caption.trim()
                }
            }
            exporting = false
            if (out.all { it.first.isNotEmpty() }) onSend(out)
        }
    }

    var picking by remember { mutableStateOf(false) }
    val addedUris = remember { mutableStateListOf<android.net.Uri>() }
    fun addFrom(uris: List<android.net.Uri>) {
        if (uris.isEmpty()) return
        addedUris.addAll(uris.filter { it !in addedUris })
        scope.launch {
            exporting = true
            for (u in uris) {
                val d = withContext(Dispatchers.IO) { Media.compress(ctx, u, 300 * 1024) } ?: continue
                val bm = withContext(Dispatchers.IO) { Media.decode(d, 1600) } ?: continue
                pages.add(EdPage(d, bm))
            }
            exporting = false
            sel = pages.lastIndex
            mode = EdMode.NONE
        }
    }

    BackHandler(enabled = !cropping && !confirmExit && !picking) {
        when (mode) {
            EdMode.TEXT -> commitText()
            EdMode.NONE -> confirmExit = true
            else -> mode = EdMode.NONE
        }
    }

    val cf = remember(pg.filterIdx) { if (pg.filterIdx == 0) null else ColorFilter.colorMatrix(ColorMatrix(StFilters[pg.filterIdx].m)) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // ---- çerçeve: resim + çizgiler + yazılar ----
        Box(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().clipToBounds()
                .onSizeChanged { fw = it.width.toFloat().coerceAtLeast(1f); fh = it.height.toFloat().coerceAtLeast(1f) }
        ) {
            val idle = mode == EdMode.NONE || mode == EdMode.FILTERS
            run {
                val coverK = min(fw / pg.base.width, fh / pg.base.height)
                val dens = LocalDensity.current
                Image(
                    bitmap = pg.base.asImageBitmap(), contentDescription = null, contentScale = ContentScale.FillBounds, colorFilter = cf,
                    modifier = Modifier.align(Alignment.Center)
                        .requiredSize(with(dens) { (pg.base.width * coverK).toDp() }, with(dens) { (pg.base.height * coverK).toDp() })
                        .graphicsLayer { scaleX = pg.zoomV; scaleY = pg.zoomV; translationX = pg.pan.x; translationY = pg.pan.y }
                )
            }
            Canvas(Modifier.fillMaxSize().graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)) {
                pg.strokes.forEach { s ->
                    if (s.pts.isEmpty()) return@forEach
                    val path = Path()
                    val f0 = s.pts.first()
                    path.moveTo(f0.x * size.width, f0.y * size.height)
                    if (s.pts.size == 1) path.lineTo(f0.x * size.width + 0.01f, f0.y * size.height)
                    s.pts.drop(1).forEach { path.lineTo(it.x * size.width, it.y * size.height) }
                    drawPath(
                        path, color = Color(s.color), alpha = s.alpha,
                        style = Stroke(width = s.widthF * size.width, cap = StrokeCap.Round, join = StrokeJoin.Round),
                        blendMode = if (s.kind == 3) BlendMode.Clear else BlendMode.SrcOver
                    )
                }
            }
            pg.ovs.forEach { t ->
                if (mode == EdMode.TEXT && t.id == editId) return@forEach
                Box(
                    Modifier.align(Alignment.Center)
                        .graphicsLayer { translationX = (t.x - 0.5f) * fw; translationY = (t.y - 0.5f) * fh; rotationZ = t.rot; scaleX = t.scale; scaleY = t.scale }
                        .onSizeChanged { pg.sizes[t.id] = it }
                ) { StBubble(t, fw) }
            }
            // dokunuş katmanı
            if (idle) {
                Box(
                    Modifier.fillMaxSize()
                        .pointerInput(pg) {
                            awaitPointerEventScope {
                                var wasDown = false; var downPos = Offset.Zero; var downT = 0L; var moved = false
                                while (true) {
                                    val e = awaitPointerEvent(PointerEventPass.Initial)
                                    val pressed = e.changes.count { it.pressed }
                                    val first = e.changes.first()
                                    if (!wasDown && pressed >= 1) {
                                        wasDown = true; downPos = first.position; downT = first.uptimeMillis; moved = false
                                        active = hit(downPos); dragging = false; swipeDx = 0f
                                    } else if (wasDown && pressed >= 1) {
                                        if ((first.position - downPos).getDistance() > 14f) moved = true
                                    } else if (wasDown && pressed == 0) {
                                        wasDown = false
                                        val id = active
                                        if (!moved && id >= 0 && first.uptimeMillis - downT < 400) openText(id)
                                        else if (dragging && id >= 0) {
                                            val it2 = pg.ovs.firstOrNull { x -> x.id == id }
                                            if (it2 != null && it2.y > 0.88f) pg.ovs.removeAll { x -> x.id == id }
                                        }
                                        if (id < 0 && pages.size > 1 && pg.zoomV <= 1.01f && abs(swipeDx) > 140f) {
                                            sel = (sel + (if (swipeDx < 0f) 1 else -1)).coerceIn(0, pages.lastIndex); mode = EdMode.NONE
                                        } else if (id < 0 && pg.zoomV < 1f) {
                                            val pgx = pg
                                            scope.launch {
                                                androidx.compose.animation.core.animate(pgx.zoomV, 1f) { v, _ -> pgx.zoomV = v; pgx.pan = clampPan(pgx.pan, v) }
                                            }
                                        }
                                        swipeDx = 0f
                                        active = -1; dragging = false
                                    }
                                }
                            }
                        }
                        .pointerInput(pg) {
                            detectTransformGestures { _, p, zoom, rot ->
                                val id = active
                                if (id >= 0) {
                                    val i = pg.ovs.indexOfFirst { it.id == id }
                                    if (i >= 0) {
                                        val t = pg.ovs[i]; dragging = true
                                        pg.ovs[i] = t.copy(x = t.x + p.x / fw, y = t.y + p.y / fh, scale = (t.scale * zoom).coerceIn(0.3f, 8f), rot = t.rot + rot)
                                    }
                                } else {
                                    val z = (pg.zoomV * zoom).coerceIn(0.6f, 6f)
                                    pg.zoomV = z
                                    if (z <= 1.01f && abs(zoom - 1f) < 0.02f) swipeDx += p.x
                                    pg.pan = clampPan(Offset(pg.pan.x + p.x, pg.pan.y + p.y), z)
                                }
                            }
                        }
                )
            }
            if (mode == EdMode.DRAW) {
                Box(
                    Modifier.fillMaxSize().pointerInput(brush, drawColorT, pg) {
                        var cur: StStroke? = null
                        detectDragGestures(
                            onDragStart = { o ->
                                drawing = true
                                val s = StStroke(stColorAt(drawColorT).toArgb(), brush)
                                s.pts.add(Offset(o.x / fw, o.y / fh)); pg.strokes.add(s); cur = s
                            },
                            onDrag = { c, _ -> c.consume(); cur?.pts?.add(Offset(c.position.x / fw, c.position.y / fh)) },
                            onDragEnd = { cur = null; drawing = false }, onDragCancel = { cur = null; drawing = false }
                        )
                    }.pointerInput(brush, drawColorT, pg) {
                        detectTapGestures { o ->
                            val s = StStroke(stColorAt(drawColorT).toArgb(), brush)
                            s.pts.add(Offset(o.x / fw, o.y / fh)); pg.strokes.add(s)
                        }
                    }
                )
            }
        }

        // ---- üst çubuk (ana görünüm) ----
        if (mode == EdMode.NONE || mode == EdMode.FILTERS) {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TopCircle(onClick = { confirmExit = true }) { Icon(Icons.Default.Close, "Kapat", tint = Color.White) }
                Spacer(Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TopCircle(onClick = { onSoon("Müzik") }) { Icon(Icons.Default.MusicNote, "Müzik", tint = Color.White) }
                    TopCircle(onClick = { cropping = true }) { Icon(Icons.Default.CropRotate, "Kırp", tint = Color.White) }
                    TopCircle(onClick = { mode = EdMode.STICKERS }) { Icon(Icons.Default.EmojiEmotions, "Çıkartma", tint = Color.White) }
                    TopCircle(onClick = { openText(-1) }) { Text("Aa", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium) }
                    TopCircle(onClick = { mode = EdMode.DRAW }) { Icon(Icons.Default.Edit, "Çiz", tint = Color.White) }
                }
            }
        }

        // ---- çöp kutusu (öğe sürüklenirken) ----
        if (dragging && active >= 0) {
            Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 24.dp).size(56.dp).clip(CircleShape).background(Color(0xCC000000)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Delete, "Sil", tint = Color.White)
            }
        }

        // ---- alt bölüm (ana görünüm) ----
        if (mode == EdMode.NONE && !(dragging && active >= 0)) {
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().imePadding()) {
                Column(
                    Modifier.fillMaxWidth().clickable { mode = EdMode.FILTERS }
                        .pointerInput(Unit) { detectVerticalDragGestures { c, dy -> if (dy < -8f) { c.consume(); mode = EdMode.FILTERS } } }
                        .padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.KeyboardArrowUp, null, tint = Color.White)
                    Text("Filtreler", color = Color.White, fontSize = 16.sp)
                }
                if (pages.size > 1) {
                    LazyRow(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp)) {
                        itemsIndexed(pages) { i, pgx ->
                            val th = remember(pgx.base) {
                                val k = 120f / max(pgx.base.width, pgx.base.height)
                                Bitmap.createScaledBitmap(pgx.base, (pgx.base.width * k).toInt().coerceAtLeast(1), (pgx.base.height * k).toInt().coerceAtLeast(1), true).asImageBitmap()
                            }
                            Box(
                                Modifier.size(44.dp).clip(RoundedCornerShape(7.dp))
                                    .then(if (i == sel) Modifier.border(2.dp, Color.White, RoundedCornerShape(8.dp)) else Modifier)
                                    .clickable {
                                        if (i == sel) { pages.removeAt(i); sel = sel.coerceAtMost(pages.lastIndex).coerceAtLeast(0) } else { sel = i; mode = EdMode.NONE }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Image(bitmap = th, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                                if (i == sel) {
                                    Box(Modifier.fillMaxSize().background(Color(0x66000000)), contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Delete, "Sil", tint = Color.White, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    }
                }
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(50)).background(Color(0xCC11161A))
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.AddPhotoAlternate, "Resim ekle", tint = Color.White,
                        modifier = Modifier.size(26.dp).clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) {
                            picking = true
                        }
                    )
                    Spacer(Modifier.width(14.dp))
                    BasicTextField(
                        value = pg.caption, onValueChange = { if (it.length <= 200) pg.caption = it }, singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 17.sp), cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.weight(1f),
                        decorationBox = { field -> if (pg.caption.isEmpty()) Text("Açıklama ekleyin...", color = Color(0xFFB0B7BE), fontSize = 17.sp); field() }
                    )
                }
                Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.clip(RoundedCornerShape(50)).background(Color(0x99000000)).padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Text("Durum (tüm kişiler)", color = Color.White, fontSize = 15.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Box(
                        Modifier.size(56.dp).clip(CircleShape).background(Color(0xFF25D366).copy(alpha = if (busy || exporting) 0.6f else 1f)).clickable { doExport() },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.AutoMirrored.Filled.Send, "Paylaş", tint = Color(0xFF0B141A)) }
                }
            }
        }

        // ---- filtre şeridi ----
        androidx.compose.animation.AnimatedVisibility(
            visible = mode == EdMode.FILTERS,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(280)) { it } + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(200)),
            exit = androidx.compose.animation.slideOutVertically(androidx.compose.animation.core.tween(240)) { it } + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(200))
        ) {
            Column(
                Modifier.fillMaxWidth().background(Color(0xE60B141A))
                    .pointerInput(Unit) { detectVerticalDragGestures { c, dy -> if (dy > 8f) { c.consume(); mode = EdMode.NONE } } }
                    .navigationBarsPadding().padding(bottom = 10.dp)
            ) {
                Box(Modifier.fillMaxWidth().clickable { mode = EdMode.NONE }.padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.KeyboardArrowDown, "Kapat", tint = Color.White)
                }
                val thumb = remember(pg.base) {
                    val k = 150f / max(pg.base.width, pg.base.height)
                    Bitmap.createScaledBitmap(pg.base, (pg.base.width * k).toInt().coerceAtLeast(1), (pg.base.height * k).toInt().coerceAtLeast(1), true).asImageBitmap()
                }
                LazyRow(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    itemsIndexed(StFilters) { i, f ->
                        Column(Modifier.clickable { pg.filterIdx = i }, horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(
                                bitmap = thumb, contentDescription = f.name, contentScale = ContentScale.Crop,
                                colorFilter = if (i == 0) null else ColorFilter.colorMatrix(ColorMatrix(f.m)),
                                modifier = Modifier.size(78.dp).clip(RoundedCornerShape(10.dp))
                                    .then(if (i == pg.filterIdx) Modifier.border(3.dp, Color.White, RoundedCornerShape(10.dp)) else Modifier)
                            )
                            Text(f.name, color = if (i == pg.filterIdx) Color.White else Color(0xFF9AA3AB), fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }
        }

        // ---- çıkartma seçici ----
        if (mode == EdMode.STICKERS) {
            Box(Modifier.fillMaxSize().background(Color(0x66000000)).clickable { mode = EdMode.NONE })
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(360.dp).clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                    .background(Color(0xFF1A1F24)).navigationBarsPadding().padding(12.dp)
            ) {
                Text("Çıkartmalar", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(bottom = 8.dp, start = 4.dp))
                LazyVerticalGrid(GridCells.Fixed(6), Modifier.fillMaxSize()) {
                    items(StEmojis) { e ->
                        Box(Modifier.size(54.dp).clickable {
                            pg.ovs.add(StItem(pg.nextId++, e, android.graphics.Color.WHITE, 0, 0, 0, 0.5f, 0.45f, 1f, 0f, sticker = true))
                            mode = EdMode.NONE
                        }, contentAlignment = Alignment.Center) { Text(e, fontSize = 30.sp) }
                    }
                }
            }
        }

        // ---- yazı düzenleme ----
        if (mode == EdMode.TEXT) {
            LaunchedEffect(Unit) { delay(80); try { focus.requestFocus() } catch (e: Throwable) { } }
            val cur = StItem(0, dText, stColorAt(dColorT).toArgb(), dFont, dBg, dAlign, 0.5f, 0.5f, 1f, 0f)
            val (bgc, fg) = stBubbleColors(cur)
            val sizePx = fw * 0.075f
            Box(Modifier.fillMaxSize().background(Color(0xB3000000)).clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { commitText() })
            Column(Modifier.fillMaxSize().statusBarsPadding().imePadding().navigationBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Pill("Bitti") { commitText() }
                    Spacer(Modifier.weight(1f))
                    TopCircle(onClick = { dAlign = (dAlign + 1) % 3 }) {
                        Icon(when (dAlign) { 1 -> Icons.Default.FormatAlignLeft; 2 -> Icons.Default.FormatAlignRight; else -> Icons.Default.FormatAlignCenter }, "Hizala", tint = Color.White)
                    }
                    Spacer(Modifier.width(8.dp))
                    TopCircle(onClick = { dBg = (dBg + 1) % 4 }, active = dBg != 0) { Text("A", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                }
                Box(Modifier.weight(1f).fillMaxWidth().clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { commitText() }, contentAlignment = Alignment.Center) {
                    val d = LocalDensity.current
                    val f = dFont.coerceIn(0, 5)
                    with(d) {
                        BasicTextField(
                            value = dText, onValueChange = { if (it.length <= 300) dText = it },
                            textStyle = TextStyle(
                                color = fg, fontSize = sizePx.toSp(), fontFamily = StFontFamilies[f], fontWeight = StFontWeights[f], fontStyle = StFontStyles[f],
                                textAlign = when (dAlign) { 1 -> TextAlign.Start; 2 -> TextAlign.End; else -> TextAlign.Center }
                            ),
                            cursorBrush = SolidColor(fg),
                            modifier = Modifier.focusRequester(focus).widthIn(min = 40.dp, max = (fw * 0.8f).toDp())
                                .then(if (bgc.alpha > 0f) Modifier.background(bgc, RoundedCornerShape((sizePx * 0.3f).toDp())) else Modifier)
                                .padding(horizontal = (sizePx * 0.4f).toDp(), vertical = (sizePx * 0.2f).toDp())
                        )
                    }
                    StColorSlider(dColorT, { dColorT = it }, Modifier.align(Alignment.CenterEnd).padding(end = 25.dp))
                }
                LazyRow(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp)) {
                    itemsIndexed(listOf(0, 1, 2, 3, 4, 5)) { _, i ->
                        Box(
                            Modifier.size(46.dp).clip(CircleShape).background(if (dFont == i) Color.White else Color(0x66000000)).clickable { dFont = i },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Aa", color = if (dFont == i) Color.Black else Color.White, fontSize = 18.sp,
                                fontFamily = StFontFamilies[i], fontWeight = StFontWeights[i], fontStyle = StFontStyles[i])
                        }
                    }
                }
            }
        }

        // ---- çizim kontrolleri ----
        if (mode == EdMode.DRAW) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().graphicsLayer { alpha = ctlA }) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Pill("Bitti") { mode = EdMode.NONE }
                    Spacer(Modifier.weight(1f))
                    TopCircle(onClick = { if (pg.strokes.isNotEmpty()) pg.strokes.removeAt(pg.strokes.size - 1) }) { Icon(Icons.AutoMirrored.Filled.Undo, "Geri al", tint = Color.White) }
                    Spacer(Modifier.width(8.dp))
                    TopCircle(onClick = { }, tint = stColorAt(drawColorT)) {
                        if (sliding) Box(Modifier.size(12.dp).clip(CircleShape).background(Color.White))
                        else Icon(Icons.Default.Edit, "Kalem", tint = Color.White)
                    }
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    StColorSlider(drawColorT, { drawColorT = it }, Modifier.align(Alignment.TopEnd).padding(end = 25.dp, top = 12.dp), onActive = { sliding = it })
                }
                Row(Modifier.fillMaxWidth().background(Color(0x99000000)).padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    listOf("İnce", "Kalın", "Fosforlu", "Silgi").forEachIndexed { i, label ->
                        Box(
                            Modifier.clip(RoundedCornerShape(50)).background(if (brush == i) Color(0xFF3A4046) else Color.Transparent)
                                .clickable { brush = i }.padding(horizontal = 16.dp, vertical = 10.dp)
                        ) { Text(label, color = Color.White, fontSize = 15.sp) }
                    }
                }
            }
        }

        if (picking) {
            StatusMultiPicker(addedUris.toSet(), onClose = { picking = false }) { uris -> picking = false; addFrom(uris) }
        }
        if (confirmExit) {
            AuraAlertDialog(
                onDismissRequest = { confirmExit = false },
                containerColor = AuraSurface,
                title = { Text("Fotoğraf silinsin mi?", color = AuraWhite) },
                text = { Text("Yaptığınız düzenlemeler de silinir.", color = AuraMuted) },
                confirmButton = { androidx.compose.material3.TextButton(onClick = { confirmExit = false; onClose() }) { Text("Sil", color = Color(0xFFEF4444)) } },
                dismissButton = { androidx.compose.material3.TextButton(onClick = { confirmExit = false }) { Text("İptal", color = AuraMuted) } }
            )
        }
        if (cropping) {
            StatusCropper(pg.base, onCancel = { cropping = false }) { nb ->
                pg.base = nb; pg.rotated = true; pg.zoomV = 1f; pg.pan = Offset.Zero; cropping = false
            }
        }
        if (exporting) {
            Box(Modifier.fillMaxSize().background(Color(0x66000000)), contentAlignment = Alignment.Center) {
                androidx.compose.material3.CircularProgressIndicator(color = Color.White)
            }
        }
    }
}


/** Kırpma sayfası: köşe ve kenarlardan çekerek serbest kırpma, ortadaki düğmeyle döndürme */
@Composable
private fun StatusCropper(src: Bitmap, onCancel: () -> Unit, onDone: (Bitmap) -> Unit) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onCancel,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) { CropperContent(src, false, onCancel, onDone) }
}


/** Çoklu resim seçici (sohbetteki galeri seçicisi gibi): numaralı seçim, altta seçilenler ve onay düğmesi */
@Composable
private fun StatusMultiPicker(already: Set<android.net.Uri>, onClose: () -> Unit, onDone: (List<android.net.Uri>) -> Unit) {
    var album by remember { mutableStateOf<String?>(null) }
    var albums by remember { mutableStateOf<List<Pair<String, Int>>>(emptyList()) }
    var albumMenu by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<List<android.net.Uri>>(emptyList()) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    BackHandler { onClose() }
    Column(Modifier.fillMaxSize().background(Color(0xFF0B0F12)).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(CircleShape).clickable { onClose() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Close, "Kapat", tint = Color.White)
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Row(Modifier.clip(RoundedCornerShape(20.dp)).clickable { albumMenu = true }.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(album ?: "Son kullanılanlar", color = Color.White, fontSize = 20.sp, maxLines = 1)
                    Icon(Icons.Default.KeyboardArrowDown, null, tint = Color.White)
                }
                AuraDropdownMenu(expanded = albumMenu, onDismissRequest = { albumMenu = false }, containerColor = AuraSurface, alignEnd = false) {
                    androidx.compose.material3.DropdownMenuItem(text = { Text("Son kullanılanlar", color = AuraWhite) }, onClick = { album = null; albumMenu = false })
                    albums.forEach { (n, c) ->
                        androidx.compose.material3.DropdownMenuItem(text = { Text("$n  ($c)", color = AuraWhite) }, onClick = { album = n; albumMenu = false })
                    }
                }
            }
            Spacer(Modifier.width(48.dp))
        }
        GalleryStrip(
            accent = Color(0xFF25D366), maxPick = 10, selected = selected, onSelected = { selected = it },
            modifier = Modifier.weight(1f), grid = true, album = album, onAlbums = { albums = it }, columns = 3, disabled = already
        )
        if (selected.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().background(Color(0xFF1A1F24)).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(selected) { _, u ->
                        val bm by androidx.compose.runtime.produceState<Bitmap?>(null, u) { value = withContext(Dispatchers.IO) { loadThumb(ctx, u) } }
                        Box(Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF2B3036)).clickable { selected = selected - u }) {
                            bm?.let { Image(bitmap = it.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                Box(Modifier.size(56.dp).clip(CircleShape).background(Color(0xFF25D366)).clickable { onDone(selected) }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Check, "Tamam", tint = Color(0xFF0B141A))
                }
            }
        }
    }
}

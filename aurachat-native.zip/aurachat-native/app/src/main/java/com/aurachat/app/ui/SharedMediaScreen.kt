package com.aurachat.app.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.LocalMedia
import com.aurachat.app.data.Media
import com.aurachat.app.data.Message
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import java.util.Calendar
import kotlinx.coroutines.launch

private val MONTHS = listOf("Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık")

private fun groupLabel(ms: Long): String {
    val d = Calendar.getInstance().apply { timeInMillis = ms }
    val n = Calendar.getInstance()
    val diff = (n.get(Calendar.YEAR) - d.get(Calendar.YEAR)) * 12 + (n.get(Calendar.MONTH) - d.get(Calendar.MONTH))
    if (diff == 0) return "BU AY"
    if (diff == 1) return "GEÇEN AY"
    val name = MONTHS[d.get(Calendar.MONTH)].uppercase(java.util.Locale("tr", "TR"))
    return if (d.get(Calendar.YEAR) == n.get(Calendar.YEAR)) name else name + " " + d.get(Calendar.YEAR)
}

private fun dateText(ms: Long): String {
    val d = Calendar.getInstance().apply { timeInMillis = ms }
    return "${d.get(Calendar.DAY_OF_MONTH)} ${MONTHS[d.get(Calendar.MONTH)]} ${d.get(Calendar.YEAR)}"
}

private data class MediaItem(val src: String, val time: Long, val msgId: String, val senderUid: String, val senderName: String)
private data class LinkItem(val url: String, val text: String, val time: Long)

private val URL_RE = Regex("(https?://[^\\s]+|www\\.[^\\s]+)", RegexOption.IGNORE_CASE)

@Composable
fun SharedMediaScreen(
    me: UserProfile, target: ChatTarget,
    onForward: (List<Message>) -> Unit = {}, onShowInChat: (Message) -> Unit = {}, onEdited: (String) -> Unit = {},
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    BackHandler { onBack() }
    val raw by remember(target.chatId) { Repo.messagesFlow(target.chatId, 1000) }.collectAsState(emptyList())
    val ver = LocalMedia.version
    val msgs = remember(raw, ver) {
        raw.filter { !it.deleted && !it.deletedFor.contains(me.uid) && !it.viewOnce }.map { LocalMedia.localize(it) }
    }
    val images = remember(msgs) {
        msgs.filter { it.type == "image" }.flatMap { m -> messageImages(m).map { MediaItem(it, m.time, m.id, m.senderUid, m.senderName) } }
    }
    val docs = remember(msgs) { msgs.filter { it.type == "document" } }
    val links = remember(msgs) {
        msgs.filter { it.type == "text" }.flatMap { m ->
            URL_RE.findAll(m.text).map { LinkItem(it.value, m.text, m.time) }.toList()
        }
    }
    val pager = androidx.compose.foundation.pager.rememberPagerState { 3 }
    val tab = pager.currentPage
    val pgScope = rememberCoroutineScope()
    var viewer by remember { mutableStateOf<Pair<List<String>, Int>?>(null) }

    Column(Modifier.fillMaxSize().background(auraC(0xFF0B141A)).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = AuraWhite) }
            Text(liveChatName(target), color = AuraWhite, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(Modifier.fillMaxWidth()) {
            listOf("Medya" to images.size, "Belgeler" to docs.size, "Bağlantılar" to links.size).forEachIndexed { i, (n, c) ->
                Column(Modifier.weight(1f).clickable { pgScope.launch { pager.animateScrollToPage(i) } }.padding(top = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$n $c", color = if (tab == i) auraLc(0xFF25D366) else auraLc(0xFF8696A0), fontSize = 14.sp)
                    Box(
                        Modifier.padding(top = 10.dp).fillMaxWidth().height(2.dp)
                            .background(if (tab == i) auraLc(0xFF25D366) else auraLc(0x1FFFFFFF))
                    )
                }
            }
        }
        androidx.compose.foundation.pager.HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { pg ->
        when (pg) {
            0 -> if (images.isEmpty()) Empty("Paylaşılan medya yok") else {
                val flat = images.map { it.src }
                val groups = images.withIndex().groupBy { groupLabel(it.value.time) }
                LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    groups.forEach { (label, list) ->
                        item(span = { GridItemSpan(3) }) {
                            Text(label, color = auraLc(0xFF9CA3AF), fontSize = 14.sp, modifier = Modifier.padding(16.dp, 12.dp))
                        }
                        items(list) { iv ->
                            DataUrlImage(
                                iv.value.src, 320,
                                Modifier.fillMaxWidth().aspectRatio(1f).clickable { viewer = Pair(flat, iv.index) },
                                ContentScale.Crop
                            )
                        }
                    }
                }
            }
            1 -> if (docs.isEmpty()) Empty("Paylaşılan belge yok") else LazyColumn(Modifier.fillMaxSize()) {
                items(docs) { d ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            try {
                                val f = Media.sharableFile(ctx, d.imageUrl, d.fileName.ifBlank { "belge" })
                                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                                ctx.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(uri, d.fileMime.ifBlank { "*/*" })
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                })
                            } catch (e: Throwable) {
                                android.widget.Toast.makeText(ctx, "Bu belgeyi açacak uygulama yok", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }.padding(16.dp, 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(auraLc(0xFF1F2C33)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Description, null, tint = auraLc(0xFF9CA3AF))
                        }
                        Column(Modifier.padding(start = 14.dp)) {
                            Text(d.fileName.ifBlank { "Belge" }, color = AuraWhite, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(dateText(d.time), color = auraLc(0xFF9CA3AF), fontSize = 13.sp)
                        }
                    }
                }
            }
            else -> if (links.isEmpty()) Empty("Paylaşılan bağlantı yok") else LazyColumn(Modifier.fillMaxSize()) {
                items(links) { l ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            try {
                                val u = if (l.url.startsWith("http", true)) l.url else "https://" + l.url
                                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
                            } catch (e: Throwable) {}
                        }.padding(16.dp, 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(auraLc(0xFF1F2C33)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Link, null, tint = auraLc(0xFF9CA3AF))
                        }
                        Column(Modifier.padding(start = 14.dp)) {
                            Text(l.text, color = AuraWhite, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(l.url, color = auraLc(0xFF7DD3FC), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(dateText(l.time), color = auraLc(0xFF6B7280), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        }
    }
    val v = viewer
    if (v != null) {
        val tName = liveChatName(target)
        val vItems = images.map { ViewerItem(it.src, it.time, if (it.senderUid == me.uid) me.name else it.senderName.ifBlank { tName }, it.msgId, "", it.senderUid) }
        MessageImageViewer(
            me = me, target = target, items = vItems, startIndex = v.second, album = false,
            msgFor = { id -> msgs.firstOrNull { it.id == id } },
            onForward = { m -> onForward(listOf(m)) }, onShowInChat = onShowInChat, onEdited = onEdited,
            onClose = { viewer = null }
        )
    }
}

@Composable
private fun Empty(t: String) {
    Box(Modifier.fillMaxSize().padding(top = 60.dp), contentAlignment = Alignment.TopCenter) {
        Text(t, color = auraLc(0xFF6B7280), fontSize = 15.sp)
    }
}

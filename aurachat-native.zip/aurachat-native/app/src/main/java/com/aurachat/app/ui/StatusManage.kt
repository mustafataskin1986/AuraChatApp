package com.aurachat.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.zIndex
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Repo
import com.aurachat.app.data.StatusItem
import kotlinx.coroutines.launch

/** "Durumlarımı yönet": ana ekrandan sahip olunan karta basılı tutunca açılır. Çoklu seç → sil. */
object StatusManageHolder {
    var request by mutableStateOf(false)
}

@Composable
private fun ManageThumb(it0: StatusItem, modifier: Modifier = Modifier) {
    Box(modifier.background(if (it0.type == "text") parseBg(it0.bg) else Color(0xFF202C33))) {
        if (it0.type == "text") {
            Text(it0.text, color = Color.White, fontSize = 10.sp, maxLines = 4, overflow = TextOverflow.Ellipsis, modifier = Modifier.align(Alignment.Center).padding(6.dp))
        } else {
            val media by produceState<String?>(Repo.peekStatusMedia(it0.id), it0.id) { if (value == null) value = Repo.loadStatusMedia(it0.id) }
            val m = media
            if (!m.isNullOrEmpty()) DataUrlImage(m, 400, Modifier.fillMaxSize(), ContentScale.Crop)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MyStatusManager(items: List<StatusItem>, onOpen: (String) -> Unit, onChangeMusic: (StatusItem) -> Unit, onClose: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var sel by remember { mutableStateOf<Set<String>>(emptySet()) }
    var confirm by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var openIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    val gridState = androidx.compose.foundation.lazy.grid.rememberLazyGridState()
    var dragId by remember { mutableStateOf<String?>(null) }
    var dragX by remember { mutableFloatStateOf(0f) }
    var dragY by remember { mutableFloatStateOf(0f) }
    var hoverId by remember { mutableStateOf<String?>(null) }
    // Aynı anda (aynı gönderimde) paylaşılan durumlar tek kartta toplanır: createdAt farkı 1 sn'den azsa aynı grup
    val groups = remember(items) {
        val out = ArrayList<MutableList<StatusItem>>()
        for (st in items.sortedBy { it.createdAt }) {
            val last = out.lastOrNull()
            if (last != null && st.createdAt - last.last().createdAt < 1000L) last.add(st) else out.add(mutableListOf(st))
        }
        out.reversed().map { it.toList() }
    }
    val open = groups.firstOrNull { g -> g.any { openIds.contains(it.id) } }
    val sorted = open ?: emptyList()
    val bg = Color(0xFF0B141A)
    BackHandler(enabled = sel.isNotEmpty()) { sel = emptySet() }
    BackHandler(enabled = sel.isEmpty() && open != null) { openIds = emptySet() }
    BackHandler(enabled = sel.isEmpty() && open == null) { onClose() }
    if (items.isEmpty()) androidx.compose.runtime.LaunchedEffect(Unit) { onClose() }

    Column(Modifier.fillMaxSize().background(bg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (sel.isNotEmpty()) sel = emptySet() else if (open != null) openIds = emptySet() else onClose() }) {
                Icon(if (sel.isNotEmpty()) Icons.Default.Close else Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White)
            }
            Text(
                if (sel.isEmpty()) "Durumlarım" else "${sel.size} seçildi",
                color = Color.White, fontSize = 20.sp, modifier = Modifier.weight(1f).padding(start = 6.dp)
            )
            if (sel.isNotEmpty()) {
                TextButton(onClick = { sel = if (sel.size == sorted.size) emptySet() else sorted.map { it.id }.toSet() }) {
                    Text(if (sel.size == sorted.size) "Seçimi kaldır" else "Tümünü seç", color = Color(0xFF22C55E))
                }
                if (sel.size == 2) {
                    IconButton(enabled = !busy, onClick = {
                        val two = sorted.filter { sel.contains(it.id) }
                        if (two.size == 2) {
                            busy = true
                            scope.launch {
                                try { Repo.swapStatusOrder(two[0], two[1]) } catch (e: Throwable) { android.widget.Toast.makeText(ctx, "Sıra değiştirilemedi", android.widget.Toast.LENGTH_SHORT).show() }
                                busy = false; sel = emptySet()
                            }
                        }
                    }) { Icon(Icons.Default.SwapHoriz, "Yer değiştir", tint = Color.White) }
                }
                IconButton(onClick = { confirm = true }) { Icon(Icons.Default.Delete, "Sil", tint = Color.White) }
            }
        }
        // Üstte küçük kartlar: her paylaşım bir kart; basınca altta içeriği açılır
        LazyRow(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            rowItems(groups, key = { it.first().id }) { g ->
                val isOpen = g === open
                val first = g.first()
                Box(
                    Modifier.width(64.dp).height(100.dp).clip(RoundedCornerShape(10.dp))
                        .then(if (isOpen) Modifier.border(2.dp, Color(0xFF22C55E), RoundedCornerShape(10.dp)) else Modifier)
                        .clickable { sel = emptySet(); openIds = if (isOpen) emptySet() else g.map { it.id }.toSet() }
                ) {
                    ManageThumb(first, Modifier.fillMaxSize())
                    if (g.size > 1) {
                        Box(Modifier.align(Alignment.TopEnd).padding(4.dp).clip(RoundedCornerShape(50)).background(Color(0xB3000000)).padding(horizontal = 6.dp, vertical = 1.dp)) {
                            Text("${g.size}", color = Color.White, fontSize = 11.sp)
                        }
                    }
                    Text(statusTimeLabel(first.createdAt), color = Color.White, fontSize = 10.sp, maxLines = 1, modifier = Modifier.align(Alignment.BottomStart).padding(5.dp))
                }
            }
        }
        if (open == null) {
            Text("İçeriğini görmek için bir duruma basın", color = Color(0xFF9AA5AD), fontSize = 13.sp, modifier = Modifier.padding(start = 16.dp, top = 14.dp))
        } else if (sel.isEmpty()) {
            Text("Basılı tutup sürükleyerek sırayı değiştirin · bırakınca seçilir", color = Color(0xFF9AA5AD), fontSize = 13.sp, modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp))
        }
        LazyVerticalGrid(
            GridCells.Fixed(3), Modifier.weight(1f).fillMaxWidth(), state = gridState,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(sorted, key = { it.id }) { it0 ->
                val on = sel.contains(it0.id)
                val tapCb = androidx.compose.runtime.rememberUpdatedState<() -> Unit>({
                    if (sel.isNotEmpty()) sel = if (on) sel - it0.id else sel + it0.id else onOpen(it0.id)
                })
                val toggleCb = androidx.compose.runtime.rememberUpdatedState<() -> Unit>({ sel = if (on) sel - it0.id else sel + it0.id })
                val dropCb = androidx.compose.runtime.rememberUpdatedState<(String?) -> Unit>({ target ->
                    // yerleşimdeki gibi: bırakılan karta takas
                    val other = sorted.firstOrNull { x -> x.id == target }
                    if (other != null && other.id != it0.id) {
                        val a = it0
                        scope.launch {
                            try { Repo.swapStatusOrder(a, other) }
                            catch (e: kotlinx.coroutines.CancellationException) { throw e }
                            catch (e: Throwable) { android.widget.Toast.makeText(ctx, "Sıra değiştirilemedi", android.widget.Toast.LENGTH_SHORT).show() }
                        }
                    }
                })
                val isDrag = dragId == it0.id
                Box(
                    Modifier.fillMaxWidth().aspectRatio(0.62f)
                        .zIndex(if (isDrag) 1f else 0f)
                        .graphicsLayer {
                            if (isDrag) { translationX = dragX; translationY = dragY; scaleX = 1.06f; scaleY = 1.06f; alpha = 0.92f }
                        }
                        .clip(RoundedCornerShape(10.dp))
                        .then(if (hoverId == it0.id) Modifier.border(2.5.dp, Color(0xFF25D366), RoundedCornerShape(10.dp)) else Modifier)
                        .pointerInput(it0.id) {
                            awaitEachGesture {
                                val down = awaitFirstDown(requireUnconsumed = false)
                                var upEarly = false
                                val long = try {
                                    withTimeout(viewConfiguration.longPressTimeoutMillis) {
                                        val up = waitForUpOrCancellation()
                                        if (up != null) upEarly = true
                                    }
                                    false
                                } catch (e: androidx.compose.ui.input.pointer.PointerEventTimeoutCancellationException) { true }
                                if (!long) {
                                    if (upEarly) tapCb.value()
                                    return@awaitEachGesture
                                }
                                // basılı tutuldu: bırakılırsa seç, sürüklenirse sırayı değiştir
                                val startInfo = gridState.layoutInfo.visibleItemsInfo.firstOrNull { x -> x.key == it0.id }
                                dragId = it0.id; dragX = 0f; dragY = 0f; hoverId = null
                                var moved = false
                                val thr = 10.dp.toPx()
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val c = ev.changes.firstOrNull { x -> x.id == down.id } ?: break
                                    if (!c.pressed) break
                                    val pc = c.positionChange()
                                    dragX += pc.x; dragY += pc.y
                                    if (kotlin.math.abs(dragX) > thr || kotlin.math.abs(dragY) > thr) moved = true
                                    c.consume()
                                    if (moved && startInfo != null) {
                                        val cx = startInfo.offset.x + startInfo.size.width / 2f + dragX
                                        val cy = startInfo.offset.y + startInfo.size.height / 2f + dragY
                                        hoverId = gridState.layoutInfo.visibleItemsInfo.firstOrNull { x ->
                                            x.key != it0.id && cx >= x.offset.x && cx <= x.offset.x + x.size.width &&
                                                cy >= x.offset.y && cy <= x.offset.y + x.size.height
                                        }?.key as? String
                                    }
                                }
                                val target = hoverId
                                dragId = null; hoverId = null; dragX = 0f; dragY = 0f
                                if (!moved) toggleCb.value() else dropCb.value(target)
                            }
                        }
                ) {
                    ManageThumb(it0, Modifier.fillMaxSize())
                    if (it0.music != null) Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.align(Alignment.TopStart).padding(6.dp).size(16.dp))
                    Text(
                        statusTimeLabel(it0.createdAt), color = Color.White, fontSize = 11.sp, maxLines = 1,
                        modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
                    )
                    if (sel.isEmpty() && it0.type == "image") {
                        Box(
                            Modifier.align(Alignment.BottomCenter).padding(bottom = 22.dp, start = 4.dp, end = 4.dp)
                                .clip(RoundedCornerShape(50)).background(Color(0xB3000000))
                                .clickable { onChangeMusic(it0) }.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(if (it0.music != null) "Müziği değiştir" else "Müzik ekle", color = Color.White, fontSize = 10.sp, maxLines = 1)
                        }
                    }
                    if (on) {
                        Box(Modifier.fillMaxSize().background(Color(0x6622C55E)))
                        Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).clip(CircleShape).background(Color(0xFF22C55E)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(15.dp))
                        }
                    }
                }
            }
        }
    }

    if (confirm) {
        AuraAlertDialog(
            onDismissRequest = { if (!busy) confirm = false },
            containerColor = Color(0xFF202C33),
            title = { Text(if (sel.size == 1) "Bu durum silinsin mi?" else "${sel.size} durum silinsin mi?", color = Color.White) },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    busy = true
                    val ids = sel.toList()
                    scope.launch {
                        var fail = 0
                        for (id in ids) { try { Repo.deleteStatus(id) } catch (e: Throwable) { fail++ } }
                        busy = false; confirm = false; sel = emptySet()
                        if (fail > 0) android.widget.Toast.makeText(ctx, "$fail durum silinemedi", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Sil", color = AuraDialogBtn) }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { confirm = false }) { Text("İptal", color = Color(0xFF22C55E)) } }
        )
    }
}

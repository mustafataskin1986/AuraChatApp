package com.aurachat.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun digits10(s: String): String = s.filter { it.isDigit() }.takeLast(10)

private fun deviceHas(ctx: Context, phone: String): Boolean {
    val want = digits10(phone)
    if (want.length < 7) return true
    return try {
        ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use { c ->
            while (c.moveToNext()) if (digits10(c.getString(0) ?: "") == want) return@use true
            false
        } ?: false
    } catch (e: Throwable) { true }
}

private fun prettyPhone(p: String): String {
    val d = p.filter { it.isDigit() }
    return if (d.length == 12 && d.startsWith("90")) "+90 ${d.substring(2, 5)} ${d.substring(5, 8)} ${d.substring(8, 10)} ${d.substring(10)}"
    else if (p.startsWith("+")) p else "+$d"
}

private fun countryOf(p: String): String {
    val d = p.filter { it.isDigit() }
    return when {
        d.startsWith("90") -> "Türkiye"
        d.startsWith("49") -> "Almanya"
        d.startsWith("44") -> "Birleşik Krallık"
        d.startsWith("31") -> "Hollanda"
        d.startsWith("33") -> "Fransa"
        d.startsWith("1") -> "ABD / Kanada"
        else -> ""
    }
}

@Composable
fun UnknownContactCard(me: UserProfile, other: UserProfile, onBlock: () -> Unit) {
    val ctx = LocalContext.current
    var known by remember(other.uid) { mutableStateOf<Boolean?>(null) }
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) }
    LaunchedEffect(Unit) { granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED }
    LaunchedEffect(granted, other.phone) {
        known = if (granted) withContext(Dispatchers.IO) { deviceHas(ctx, other.phone) } else null
    }
    if (known != false || other.phone.isBlank()) return
    val common = remember(other.uid) { Repo.commonGroupCount(me.uid, other.uid) }
    val country = countryOf(other.phone)
    val line = buildString {
        if (country.isNotEmpty()) append("Telefon numarasının ait olduğu ülke: $country • ")
        append("Kişilerde kayıtlı değil • ")
        append(if (common == 0) "Ortak grup yok" else "$common ortak grup")
    }
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp).clip(RoundedCornerShape(20.dp)).background(ChipLook.glass).padding(horizontal = 16.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Avatar(other.name, other.avatar, 80.dp)
        Text(prettyPhone(other.phone), color = AuraWhite, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 10.dp))
        Text("~ ${other.name}", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
        Text(line, color = AuraMuted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp))
        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val shape = RoundedCornerShape(50)
            Box(
                Modifier.height(38.dp).clip(shape).clickable { onBlock() }.background(Color.Transparent).padding(horizontal = 26.dp),
                contentAlignment = Alignment.Center
            ) { Text("Engelle", color = Color(0xFFF15C6D), fontSize = 14.sp, fontWeight = FontWeight.Medium) }
            Box(
                Modifier.height(38.dp).clip(shape).background(AuraGreen.copy(alpha = 0.18f)).clickable {
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI).apply {
                            putExtra(ContactsContract.Intents.Insert.PHONE, other.phone)
                            putExtra(ContactsContract.Intents.Insert.NAME, other.name)
                        })
                    } catch (e: Throwable) { android.widget.Toast.makeText(ctx, "Rehber uygulaması bulunamadı", android.widget.Toast.LENGTH_SHORT).show() }
                }.padding(horizontal = 26.dp),
                contentAlignment = Alignment.Center
            ) { Text("Ekle", color = AuraGreen, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
        }
    }
}

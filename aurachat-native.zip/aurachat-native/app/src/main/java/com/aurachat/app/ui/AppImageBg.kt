package com.aurachat.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.io.File
import kotlin.math.max

/*
 * ARAYÜZ RESMİ — ana sekmelerin (Sohbetler / Durum / Kişiler / Aramalar) arka planına resim koyar. Tamamen ayrı modül.
 * Kaldırmak için: bu dosyayı sil; ThemePanel.kt'deki "AppImg" satırlarını, MainTabs.kt'deki "AppImg" satırını ve
 * "tabBg()" kullanılan yerleri (ChatListScreen, StatusScreens, ContactsScreen, CallScreens) eski .background(AuraBg)'ye çevir.
 */
object AppImg {
    var active by mutableStateOf(false)
        private set
    var dim by mutableFloatStateOf(0.55f)
        private set
    var version by mutableIntStateOf(0)
        private set
    private var cache: ImageBitmap? = null
    private var stamp = 0L
    private var loaded = false

    private fun sp(ctx: Context) = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)
    private fun file(ctx: Context) = File(ctx.filesDir, "app_bg.jpg")

    /** Uygulama açılışında bir kez okur */
    fun ensure(ctx: Context) {
        if (loaded) return
        loaded = true
        active = sp(ctx).getBoolean("appimg_on", false) && file(ctx).exists()
        dim = sp(ctx).getFloat("appimg_dim", 0.55f)
    }

    fun bitmap(ctx: Context): ImageBitmap? {
        @Suppress("UNUSED_VARIABLE") val v = version
        val f = file(ctx)
        if (!f.exists()) return null
        if (cache != null && stamp == f.lastModified()) return cache
        return try { BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap().also { cache = it; stamp = f.lastModified() } } catch (e: Throwable) { null }
    }

    fun apply(ctx: Context, bmp: Bitmap?, dimV: Float) {
        try {
            if (bmp != null) java.io.FileOutputStream(file(ctx)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            sp(ctx).edit().putBoolean("appimg_on", true).putFloat("appimg_dim", dimV).apply()
            dim = dimV; active = file(ctx).exists(); version++
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("AppImg", e) }
    }

    fun clear(ctx: Context) {
        sp(ctx).edit().putBoolean("appimg_on", false).apply()
        try { file(ctx).delete() } catch (e: Throwable) { }
        cache = null; active = false; version++
    }

    /** Galeriden seçilen resmi en çok 1600px'e küçültüp açar */
    fun decode(ctx: Context, uri: Uri): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var ss = 1
        while (max(o.outWidth, o.outHeight) / ss > 1600) ss *= 2
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = ss }) }
    } catch (e: Throwable) { null }
}

internal fun DrawScope.drawCoverImg(img: ImageBitmap) {
    val w = size.width; val h = size.height
    val scale = max(w / img.width, h / img.height)
    val srcW = (w / scale).toInt().coerceIn(1, img.width)
    val srcH = (h / scale).toInt().coerceIn(1, img.height)
    drawImage(img, srcOffset = IntOffset((img.width - srcW) / 2, (img.height - srcH) / 2), srcSize = IntSize(srcW, srcH), dstSize = IntSize(w.toInt().coerceAtLeast(1), h.toInt().coerceAtLeast(1)))
}

/** Resim açıksa resmi + koyu (açıkta beyaz) örtüyü çizer; kapalıysa hiçbir şey yapmaz */
@Composable
fun Modifier.appImgLayer(): Modifier {
    val ctx = LocalContext.current
    AppImg.ensure(ctx)
    if (!AppImg.active) return this
    val bmp = AppImg.bitmap(ctx) ?: return this
    val dim = AppImg.dim
    val scrim = if (AuraUi.light) Color.White else Color.Black
    return this.drawBehind { drawCoverImg(bmp); drawRect(scrim.copy(alpha = dim)) }
}

/** Sekme sayfası zemini: resim açıksa saydam (resim görünür), değilse normal zemin */
fun Modifier.tabBg(): Modifier = if (AppImg.active) this else this.background(AuraBg)

@Composable
fun AppImgPage(onClose: () -> Unit, onApplied: () -> Unit) {
    val ctx = LocalContext.current
    AppImg.ensure(ctx)
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var dim by remember { mutableFloatStateOf(AppImg.dim) }
    val shown: ImageBitmap? = bmp?.asImageBitmap() ?: if (AppImg.active) AppImg.bitmap(ctx) else null
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val b = AppImg.decode(ctx, uri)
            if (b != null) bmp = b else Toast.makeText(ctx, "Resim açılamadı", Toast.LENGTH_SHORT).show()
        }
    }
    val scrim = if (AuraUi.light) Color.White else Color.Black
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Column(Modifier.fillMaxSize().background(if (AuraUi.light) Color.White else Color.Black).statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(54.dp).padding(start = 0.5.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Spacer(Modifier.width(8.dp))
                Text("Arayüz resmi", color = AuraWhite, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                val shape = RoundedCornerShape(20.dp)
                Box(
                    Modifier.fillMaxWidth().height(300.dp).clip(shape).border(1.dp, AuraMuted.copy(alpha = 0.3f), shape)
                        .background(AuraMuted.copy(alpha = 0.1f))
                        .drawBehind { if (shown != null) { drawCoverImg(shown); drawRect(scrim.copy(alpha = dim)) } }
                ) {
                    if (shown == null) Text("Resim seçilmedi", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.align(Alignment.Center))
                    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 10.dp)) {
                        listOf("Ayşe" to "Akşam görüşürüz", "Proje grubu" to "Dosyayı gönderdim", "Anne" to "Tamam kızım").forEach { r ->
                            Row(Modifier.fillMaxWidth().height(58.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(36.dp).clip(CircleShape).background(AuraGreen.copy(alpha = 0.4f)))
                                Column(Modifier.padding(start = 12.dp)) {
                                    Text(r.first, color = AuraWhite, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                    Text(r.second, color = AuraMuted, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(AuraMuted.copy(alpha = 0.14f))
                        .clickable { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }.padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center
                ) { Text(if (shown != null) "Resmi değiştir" else "Resim yükle", color = AuraWhite, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Resim koyuluğu", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text("%" + Math.round(dim * 100f), color = AuraMuted, fontSize = 13.sp)
                }
                GradBar(dim / 0.9f, listOf(Color(0x00000000), Color(0xFF000000))) { dim = (it * 0.9f).coerceIn(0f, 0.9f) }
                Text("Ana sekmelerin (Sohbetler, Durum, Kişiler, Aramalar) arka planında görünür. Yazılar okunmuyorsa koyuluğu artır.", color = AuraMuted, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(AuraMuted.copy(alpha = 0.2f)))
            Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.weight(1f).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { AppImg.clear(ctx); onApplied() }.padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) { Text("KALDIR", color = AuraMuted, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
                Box(
                    Modifier.weight(1f).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        if (bmp != null || AppImg.active) { AppImg.apply(ctx, bmp, dim); onApplied() }
                        else Toast.makeText(ctx, "Önce resim seç", Toast.LENGTH_SHORT).show()
                    }.padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) { Text("UYGULA", color = AuraGreen, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
    }
}

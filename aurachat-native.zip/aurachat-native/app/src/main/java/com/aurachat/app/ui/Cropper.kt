package com.aurachat.app.ui

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * WhatsApp tarzı kırpma: köşelerden (serbest kipte kenarlardan da) çekerek çerçeve boyutlanır, içinden sürükleyince taşınır.
 * lockSquare: kare kalır (profil fotoğrafı). Ortadaki düğme resmi döndürür. Sonuç kırpılmış Bitmap olarak döner.
 */
@Composable
fun CropperContent(src: Bitmap, lockSquare: Boolean, onCancel: () -> Unit, onDone: (Bitmap) -> Unit) {
    var rot by remember { mutableIntStateOf(0) }
    val b = remember(src, rot) {
        if (rot % 4 == 0) src else Bitmap.createBitmap(src, 0, 0, src.width, src.height, Matrix().apply { postRotate(90f * (rot % 4)) }, true)
    }
    val density = LocalDensity.current
    var fitS by remember { mutableFloatStateOf(1f) }
    var ix by remember { mutableFloatStateOf(0f) }
    var iy by remember { mutableFloatStateOf(0f) }
    var rl by remember(b) { mutableFloatStateOf(-1f) }
    var rt by remember(b) { mutableFloatStateOf(0f) }
    var rr by remember(b) { mutableFloatStateOf(0f) }
    var rb by remember(b) { mutableFloatStateOf(0f) }

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val boxW = with(density) { maxWidth.toPx() }
            val boxH = with(density) { maxHeight.toPx() }
            val pad = with(density) { 20.dp.toPx() }
            val s = min((boxW - 2 * pad) / b.width, (boxH - 2 * pad) / b.height)
            val iw = b.width * s
            val ih = b.height * s
            val x0 = (boxW - iw) / 2f
            val y0 = (boxH - ih) / 2f
            fitS = s; ix = x0; iy = y0
            if (rl < 0f) {
                if (lockSquare) {
                    val side = min(iw, ih)
                    rl = x0 + (iw - side) / 2f; rt = y0 + (ih - side) / 2f; rr = rl + side; rb = rt + side
                } else { rl = x0; rt = y0; rr = x0 + iw; rb = y0 + ih }
            }
            val minS = with(density) { 80.dp.toPx() }
            val hitR = with(density) { 44.dp.toPx() }
            val edgeR = with(density) { 26.dp.toPx() }
            var mode by remember(b) { mutableIntStateOf(0) }   // 1 SOL-ÜST 2 SAĞ-ÜST 3 SOL-ALT 4 SAĞ-ALT 5 sol 6 sağ 7 üst 8 alt 9 taşı

            Box(
                Modifier.fillMaxSize().pointerInput(b, boxW, boxH) {
                    detectDragGestures(
                        onDragStart = { o ->
                            fun near(x: Float, y: Float) = abs(o.x - x) < hitR && abs(o.y - y) < hitR
                            mode = when {
                                near(rl, rt) -> 1; near(rr, rt) -> 2; near(rl, rb) -> 3; near(rr, rb) -> 4
                                !lockSquare && abs(o.x - rl) < edgeR && o.y in rt..rb -> 5
                                !lockSquare && abs(o.x - rr) < edgeR && o.y in rt..rb -> 6
                                !lockSquare && abs(o.y - rt) < edgeR && o.x in rl..rr -> 7
                                !lockSquare && abs(o.y - rb) < edgeR && o.x in rl..rr -> 8
                                o.x in rl..rr && o.y in rt..rb -> 9
                                else -> 0
                            }
                        },
                        onDragEnd = { mode = 0 }, onDragCancel = { mode = 0 },
                        onDrag = { c, d ->
                            if (mode != 0) c.consume()
                            val dx = d.x; val dy = d.y
                            val side = rr - rl
                            if (lockSquare && mode in 1..4) {
                                when (mode) {
                                    4 -> { val ns = (side + (dx + dy) / 2f).coerceIn(minS, min(x0 + iw - rl, y0 + ih - rt)); rr = rl + ns; rb = rt + ns }
                                    1 -> { val ns = (side - (dx + dy) / 2f).coerceIn(minS, min(rr - x0, rb - y0)); rl = rr - ns; rt = rb - ns }
                                    2 -> { val ns = (side + (dx - dy) / 2f).coerceIn(minS, min(x0 + iw - rl, rb - y0)); rr = rl + ns; rt = rb - ns }
                                    3 -> { val ns = (side + (-dx + dy) / 2f).coerceIn(minS, min(rr - x0, y0 + ih - rt)); rl = rr - ns; rb = rt + ns }
                                }
                            } else when (mode) {
                                1 -> { rl = (rl + dx).coerceIn(x0, rr - minS); rt = (rt + dy).coerceIn(y0, rb - minS) }
                                2 -> { rr = (rr + dx).coerceIn(rl + minS, x0 + iw); rt = (rt + dy).coerceIn(y0, rb - minS) }
                                3 -> { rl = (rl + dx).coerceIn(x0, rr - minS); rb = (rb + dy).coerceIn(rt + minS, y0 + ih) }
                                4 -> { rr = (rr + dx).coerceIn(rl + minS, x0 + iw); rb = (rb + dy).coerceIn(rt + minS, y0 + ih) }
                                5 -> rl = (rl + dx).coerceIn(x0, rr - minS)
                                6 -> rr = (rr + dx).coerceIn(rl + minS, x0 + iw)
                                7 -> rt = (rt + dy).coerceIn(y0, rb - minS)
                                8 -> rb = (rb + dy).coerceIn(rt + minS, y0 + ih)
                                9 -> {
                                    val w = rr - rl; val h = rb - rt
                                    val nl = (rl + dx).coerceIn(x0, x0 + iw - w); val nt = (rt + dy).coerceIn(y0, y0 + ih - h)
                                    rl = nl; rt = nt; rr = nl + w; rb = nt + h
                                }
                            }
                        }
                    )
                }
            ) {
                Image(
                    bitmap = b.asImageBitmap(), contentDescription = null, contentScale = androidx.compose.ui.layout.ContentScale.FillBounds,
                    modifier = Modifier.align(Alignment.Center).requiredSize(with(density) { iw.toDp() }, with(density) { ih.toDp() })
                )
                Canvas(Modifier.fillMaxSize()) {
                    val path = Path().apply {
                        fillType = PathFillType.EvenOdd
                        addRect(Rect(0f, 0f, size.width, size.height))
                        addRect(Rect(rl, rt, rr, rb))
                    }
                    drawPath(path, Color.Black.copy(alpha = 0.62f))
                    drawRect(Color.White.copy(alpha = 0.8f), Offset(rl, rt), Size(rr - rl, rb - rt), style = Stroke(1.5f))
                    for (i in 1..2) {
                        drawLine(Color.White.copy(alpha = 0.4f), Offset(rl + (rr - rl) * i / 3f, rt), Offset(rl + (rr - rl) * i / 3f, rb), 1f)
                        drawLine(Color.White.copy(alpha = 0.4f), Offset(rl, rt + (rb - rt) * i / 3f), Offset(rr, rt + (rb - rt) * i / 3f), 1f)
                    }
                    val arm = 24.dp.toPx(); val sw = 4.dp.toPx()
                    fun corner(x: Float, y: Float, dx: Float, dy: Float) {
                        drawLine(Color.White, Offset(x - dx * sw / 2f, y), Offset(x + dx * arm, y), sw)
                        drawLine(Color.White, Offset(x, y - dy * sw / 2f), Offset(x, y + dy * arm), sw)
                    }
                    corner(rl, rt, 1f, 1f); corner(rr, rt, -1f, 1f); corner(rl, rb, 1f, -1f); corner(rr, rb, -1f, -1f)
                    if (!lockSquare) {
                        val hl = 14.dp.toPx()
                        val mx = (rl + rr) / 2f; val my = (rt + rb) / 2f
                        drawLine(Color.White, Offset(mx - hl, rt), Offset(mx + hl, rt), sw)
                        drawLine(Color.White, Offset(mx - hl, rb), Offset(mx + hl, rb), sw)
                        drawLine(Color.White, Offset(rl, my - hl), Offset(rl, my + hl), sw)
                        drawLine(Color.White, Offset(rr, my - hl), Offset(rr, my + hl), sw)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("İptal", color = AuraGreen, fontSize = 18.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { onCancel() }.padding(horizontal = 12.dp, vertical = 10.dp))
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(48.dp).clip(CircleShape).clickable { rot++ }, contentAlignment = Alignment.Center) {
                Icon(Icons.Default.RotateRight, "Döndür", tint = Color.White, modifier = Modifier.size(28.dp))
            }
            Spacer(Modifier.weight(1f))
            Text("Bitti", color = AuraGreen, fontSize = 18.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable {
                    if (rl >= 0f && fitS > 0f) {
                        val px = ((rl - ix) / fitS).toInt().coerceIn(0, b.width - 1)
                        val py = ((rt - iy) / fitS).toInt().coerceIn(0, b.height - 1)
                        val pw = ((rr - rl) / fitS).toInt().coerceIn(1, b.width - px)
                        val ph = ((rb - rt) / fitS).toInt().coerceIn(1, b.height - py)
                        var out = Bitmap.createBitmap(b, px, py, pw, ph)
                        val k = min(1f, 1600f / max(pw, ph))
                        if (k < 1f) out = Bitmap.createScaledBitmap(out, (pw * k).toInt().coerceAtLeast(1), (ph * k).toInt().coerceAtLeast(1), true)
                        onDone(out)
                    }
                }.padding(horizontal = 12.dp, vertical = 10.dp))
        }
    }
}

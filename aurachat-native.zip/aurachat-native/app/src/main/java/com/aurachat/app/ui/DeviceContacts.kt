package com.aurachat.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class DevContact(val name: String, val phone: String)

fun phoneKey(s: String): String = s.filter { it.isDigit() }.takeLast(10)

fun hasContactsPermission(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

suspend fun readDeviceContacts(ctx: Context): List<DevContact> = withContext(Dispatchers.IO) {
    val out = LinkedHashMap<String, DevContact>()
    try {
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: ""
                val p = c.getString(1) ?: ""
                val k = phoneKey(p)
                if (k.length >= 7 && !out.containsKey(k)) out[k] = DevContact(n, p)
            }
        }
    } catch (e: Throwable) { com.aurachat.app.AuraLog.e("DeviceContacts", e) }
    out.values.toList()
}

/** Rehber izni yoksa null; izin verilince (uygulamaya dönünce) kendiliğinden yüklenir. */
@Composable
fun rememberDeviceContacts(): State<List<DevContact>?> {
    val ctx = LocalContext.current
    val state = remember { mutableStateOf<List<DevContact>?>(null) }
    var tick by remember { mutableStateOf(0) }
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    androidx.compose.runtime.LaunchedEffect(tick) {
        state.value = if (hasContactsPermission(ctx)) readDeviceContacts(ctx) else null
    }
    return state
}

@Composable
fun rememberAskContacts(): () -> Unit {
    val l = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    return { try { l.launch(Manifest.permission.READ_CONTACTS) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("DeviceContacts", e) } }
}

fun inviteTo(ctx: Context, phone: String) {
    try {
        val i = Intent(Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:" + phone.filter { it.isDigit() || it == '+' }))
        i.putExtra("sms_body", "AuraChat'e katıl, sohbet edelim!")
        ctx.startActivity(i)
    } catch (e: Throwable) { com.aurachat.app.AuraLog.e("DeviceContacts", e) }
}

package com.aurachat.app.ui

import android.app.UiModeManager
import android.content.res.Configuration
import androidx.compose.foundation.IndicationNodeFactory
import androidx.compose.foundation.interaction.FocusInteraction
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.LocalIndication
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.ContentDrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.node.DelegatableNode
import androidx.compose.ui.node.DrawModifierNode
import androidx.compose.ui.node.invalidateDraw
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Modifier
import kotlinx.coroutines.launch

/** Android TV (kumanda) algılanır; yalnızca orada belirgin odak çerçevesi devreye girer, telefon görünümü değişmez */
fun isTelevision(ctx: android.content.Context): Boolean = try {
    (ctx.getSystemService(android.content.Context.UI_MODE_SERVICE) as UiModeManager).currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
} catch (e: Throwable) { false }

/** Kumandayla seçili öğeyi belirgin gösterir: dolgu + kalın çerçeve (basılıyken biraz daha koyu) */
private object TvFocusIndication : IndicationNodeFactory {
    override fun create(interactionSource: InteractionSource): DelegatableNode = Node(interactionSource)
    override fun equals(other: Any?) = other === this
    override fun hashCode() = -1

    private class Node(val src: InteractionSource) : Modifier.Node(), DrawModifierNode {
        var focused = false
        var pressed = false
        override fun onAttach() {
            coroutineScope.launch {
                src.interactions.collect { i ->
                    when (i) {
                        is FocusInteraction.Focus -> focused = true
                        is FocusInteraction.Unfocus -> focused = false
                        is PressInteraction.Press -> pressed = true
                        is PressInteraction.Release, is PressInteraction.Cancel -> pressed = false
                    }
                    invalidateDraw()
                }
            }
        }
        override fun ContentDrawScope.draw() {
            drawContent()
            if (pressed && !focused) drawRect(Color.White.copy(alpha = 0.10f))
            if (focused) {
                val acc = AuraUi.accentColor() ?: Color(0xFF22C55E)
                val r = 10.dp.toPx()
                val sw = 3.dp.toPx()
                drawRoundRect(acc.copy(alpha = if (pressed) 0.38f else 0.24f), cornerRadius = CornerRadius(r, r))
                drawRoundRect(
                    Color.White, topLeft = Offset(sw / 2f, sw / 2f), size = Size(size.width - sw, size.height - sw),
                    cornerRadius = CornerRadius(r, r), style = Stroke(sw)
                )
            }
        }
    }
}

@Composable
fun TvIndicationHost(content: @Composable () -> Unit) {
    if (isTelevision(LocalContext.current)) CompositionLocalProvider(LocalIndication provides TvFocusIndication) { content() }
    else content()
}

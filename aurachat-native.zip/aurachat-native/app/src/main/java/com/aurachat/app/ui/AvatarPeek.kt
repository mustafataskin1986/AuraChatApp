package com.aurachat.app.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * WhatsApp tarzı profil önizlemesi: ortada kare resim, üstte saydam ad, altta işlem çubuğu.
 * Resme dokununca tam ekran açılır (üstte geri + ad; yukarı/aşağı sürükleyince kapanır).
 * Çerçeve ve çubuk rengi vurguya (çip rengi) uyar.
 * act: 0 mesaj, 1 sesli arama, 2 görüntülü arama, 3 bilgi
 */
@Composable
fun AvatarPeekDialog(name: String, avatar: String, isGroup: Boolean, onDismiss: () -> Unit, onAction: (Int) -> Unit) {
    var full by remember { mutableStateOf(false) }
    val frame = ChipLook.border
    val barBg = ChipLook.bg.compositeOver(AuraBg)
    val fg = ChipLook.fg
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier.width(290.dp).clip(RoundedCornerShape(14.dp)).background(barBg).border(2.dp, frame, RoundedCornerShape(14.dp))
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {}
            ) {
                Box(Modifier.fillMaxWidth().aspectRatio(1f).clickable(enabled = avatar.isNotEmpty()) { full = true }) {
                    if (avatar.isNotEmpty()) DataUrlImage(avatar, 900, Modifier.fillMaxSize(), ContentScale.Crop)
                    else Box(Modifier.fillMaxSize().background(barBg), contentAlignment = Alignment.Center) {
                        Icon(if (isGroup) Icons.Default.Groups else Icons.Default.Person, null, tint = fg, modifier = Modifier.size(120.dp))
                    }
                    Box(Modifier.fillMaxWidth().background(Color(0x66000000)).padding(horizontal = 16.dp, vertical = 10.dp)) {
                        Text(name.ifBlank { "Kullanıcı" }, color = Color.White, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf(Icons.Default.Chat to 0, Icons.Default.Call to 1, Icons.Default.Videocam to 2, Icons.Default.Info to 3).forEach { (ic, act) ->
                        IconButton(onClick = { onAction(act) }) { Icon(ic, null, tint = fg, modifier = Modifier.size(26.dp)) }
                    }
                }
            }
        }
    }
    if (full) FullAvatarViewer(name, avatar, onClose = { full = false })
}

@Composable
private fun FullAvatarViewer(name: String, avatar: String, onClose: () -> Unit) {
    var dragY by remember { mutableFloatStateOf(0f) }
    val alpha by animateFloatAsState((1f - abs(dragY) / 900f).coerceIn(0.2f, 1f), label = "fav")
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = alpha)).pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = { if (abs(dragY) > 220f) onClose() else dragY = 0f },
                    onDragCancel = { dragY = 0f },
                    onVerticalDrag = { _, d -> dragY += d }
                )
            }
        ) {
            if (avatar.isNotEmpty()) DataUrlImage(avatar, 2048, Modifier.fillMaxSize().offset { IntOffset(0, dragY.roundToInt()) }, ContentScale.Fit)
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
                Text(name.ifBlank { "Kullanıcı" }, color = Color.White, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 6.dp))
            }
        }
    }
}

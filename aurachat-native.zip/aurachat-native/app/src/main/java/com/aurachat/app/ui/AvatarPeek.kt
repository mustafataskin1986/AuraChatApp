package com.aurachat.app.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import com.aurachat.app.data.Media
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * WhatsApp tarzı profil önizlemesi: ortada kare resim, üstte saydam ad, altta işlem çubuğu.
 * Resme dokununca tam ekran açılır (üstte geri + ad; yukarı/aşağı sürükleyince kapanır).
 * Çerçeve ve çubuk rengi vurguya (çip rengi) uyar.
 * act: 0 mesaj, 1 sesli arama, 2 görüntülü arama, 3 bilgi
 */
@Composable
fun AvatarPeekDialog(name: String, avatar: String, isGroup: Boolean, onDismiss: () -> Unit, onAction: (Int) -> Unit) {
    // Eylem seçilince (sohbet / sesli / görüntülü / bilgi) önce popup ve büyük resim pencereleri kapanır, sonra eylem çalışır; geri dönünce popup görünmez
    // Popup, yeni sayfa açılana kadar yerinde kalır (liste ekranı arada görünmesin); sayfa açılınca ya da kısa süre sonra kapanır
    var pending by remember { mutableStateOf<Int?>(null) }
    androidx.compose.runtime.LaunchedEffect(pending) {
        val act = pending ?: return@LaunchedEffect
        onAction(act)
        kotlinx.coroutines.delay(700)
        onDismiss()
    }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { if (pending != null) onDismiss() } }
    val frame = ChipLook.border
    val barBg = ChipLook.bg.compositeOver(AuraBg)
    val fg = ChipLook.fg
    // WhatsApp gibi: büyük resim popup'ın üstünde ayrı pencerede açılır; popup kapanmaz, geri gelince olduğu gibi durur
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier.offset(y = (-80).dp).width(290.dp).clip(RoundedCornerShape(14.dp)).background(barBg).border(2.dp, frame, RoundedCornerShape(14.dp))
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {}
            ) {
                Box(Modifier.fillMaxWidth().aspectRatio(1f).clickable(enabled = avatar.isNotEmpty(), indication = null, interactionSource = remember { MutableInteractionSource() }) { AvatarFull.open(name, avatar) { onDismiss() } }) {
                    if (avatar.isNotEmpty()) DataUrlImage(avatar, 900, Modifier.fillMaxSize(), ContentScale.Crop)
                    else Box(Modifier.fillMaxSize().background(barBg), contentAlignment = Alignment.Center) {
                        Icon(if (isGroup) Icons.Default.Groups else Icons.Default.Person, null, tint = fg, modifier = Modifier.size(120.dp))
                    }
                    Box(Modifier.fillMaxWidth().background(Color(0x66000000)).clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { if (pending == null) pending = 3 }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                        Text(name.ifBlank { "Kullanıcı" }, color = Color.White, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf(Icons.Default.Chat to 0, Icons.Default.Call to 1, Icons.Default.Videocam to 2, Icons.Default.Info to 3).forEach { (ic, act) ->
                        IconButton(onClick = { if (pending == null) pending = act }) { Icon(ic, null, tint = fg, modifier = Modifier.size(26.dp)) }
                    }
                }
            }
        }
    }
}

/**
 * Profil resmi tam ekran: Dialog penceresi DEĞİL, uygulamanın ana penceresindeki tam ekran katmanda (ViewerOverlay) çizilir.
 * Dialog pencereleri bu cihazda üstten/alttan boşluk bırakıyordu; ana pencere ise zaten tam ekran.
 * Çağıran popup/panel kendini hemen kapatabilir, resim bağımsız yaşar.
 */
object AvatarFull {
    private var preKey: String = ""
    private var preBmp: android.graphics.Bitmap? = null
    fun pre(avatar: String): android.graphics.Bitmap? = if (avatar == preKey) preBmp else null
    /** Resim önce arka planda çözülür, hazır olunca tam ekran açılır ve onShown çağrılır (arada siyah ekran/boş kare olmasın) */
    fun open(name: String, avatar: String, onShown: () -> Unit = {}) {
        if (avatar.isEmpty()) { ViewerOverlay.content.value = { AvatarOverlayBody(name, avatar) }; onShown(); return }
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
            val b = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { Media.decode(avatar, 600) }
            preKey = avatar; preBmp = b
            ViewerOverlay.content.value = { AvatarOverlayBody(name, avatar) }
            // overlay'in ilk karesi çizilsin, sonra popup kapansın
            kotlinx.coroutines.delay(80)
            onShown()
        }
    }
    fun close() { ViewerOverlay.content.value = null }
}

@Composable
private fun AvatarOverlayBody(name: String, avatar: String) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var c: android.content.Context? = ctx
    while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext
    val w = (c as? android.app.Activity)?.window
    androidx.compose.runtime.DisposableEffect(Unit) {
        val ctl = w?.let { androidx.core.view.WindowCompat.getInsetsController(it, it.decorView) }
        // resim hep koyu: açık temada bile durum çubuğu simgeleri beyaz
        ctl?.isAppearanceLightStatusBars = false
        ctl?.isAppearanceLightNavigationBars = false
        onDispose {
            ctl?.isAppearanceLightStatusBars = AuraUi.light
            ctl?.isAppearanceLightNavigationBars = AuraUi.light
        }
    }
    androidx.activity.compose.BackHandler { AvatarFull.close() }
    FullAvatarBody(name, avatar, { }, { AvatarFull.close() })
}

@Composable
private fun FullAvatarBody(name: String, avatar: String, onShown: () -> Unit, onClose: () -> Unit) {
    // Büyük resim çözülene kadar küçük pencere görünür kalır (gri boş sayfa görünmesin)
    val bigBmp by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(AvatarFull.pre(avatar), avatar) {
        if (avatar.isNotEmpty()) {
            // önce küçük hali hızlıca, sonra büyük hali (gri boşluk görünmesin)
            if (value == null) value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { Media.decode(avatar, 600) }
            val big = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { Media.decode(avatar, 2048) }
            if (big != null) value = big
        }
    }
    androidx.compose.runtime.LaunchedEffect(bigBmp) {
        if (bigBmp != null || avatar.isEmpty()) { kotlinx.coroutines.delay(120); onShown() }
    }
    var dragY by remember { mutableFloatStateOf(0f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    val zoomA by animateFloatAsState(zoom, label = "fz")
    val alpha by animateFloatAsState((1f - abs(dragY) / 900f).coerceIn(0.2f, 1f), label = "fav")
    val bmpRef by androidx.compose.runtime.rememberUpdatedState(bigBmp)
    // resim çerçevesinin dışına kaydırılamasın: kaydırma sınırı ekran değil, görünen resim boyutuna göre
    fun panLimit(w: Float, h: Float, z: Float): Offset {
        val b = bmpRef ?: return Offset(w * (z - 1f) / 2f, h * (z - 1f) / 2f)
        val f = minOf(w / b.width, h / b.height)
        return Offset(maxOf(0f, (b.width * f * z - w) / 2f), maxOf(0f, (b.height * f * z - h) / 2f))
    }
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = alpha))
                .pointerInput(Unit) {
                    // iki parmakla büyütme (tek parmak hareketlerine karışmaz)
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        do {
                            val ev = awaitPointerEvent()
                            if (ev.changes.size >= 2) {
                                val z = ev.calculateZoom()
                                val pn = ev.calculatePan()
                                zoom = (zoom * z).coerceIn(1f, 5f)
                                if (zoom > 1.01f) {
                                    val pl = panLimit(size.width.toFloat(), size.height.toFloat(), zoom)
                                    pan = Offset((pan.x + pn.x).coerceIn(-pl.x, pl.x), (pan.y + pn.y).coerceIn(-pl.y, pl.y))
                                } else pan = Offset.Zero
                                ev.changes.forEach { it.consume() }
                            }
                        } while (ev.changes.any { it.pressed })
                        if (zoom < 1.05f) { zoom = 1f; pan = Offset.Zero }
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(onDoubleTap = { zoom = if (zoom > 1.01f) 1f else 2.5f; pan = Offset.Zero })
                }
                .pointerInput(zoom > 1.01f) {
                    if (zoom > 1.01f) {
                        detectDragGestures { c, d ->
                            c.consume()
                            val pl = panLimit(size.width.toFloat(), size.height.toFloat(), zoom)
                            pan = Offset((pan.x + d.x).coerceIn(-pl.x, pl.x), (pan.y + d.y).coerceIn(-pl.y, pl.y))
                        }
                    } else {
                        detectVerticalDragGestures(
                            onDragEnd = { if (abs(dragY) > 220f) onClose() else dragY = 0f },
                            onDragCancel = { dragY = 0f },
                            onVerticalDrag = { _, d -> dragY += d }
                        )
                    }
                }
        ) {
            bigBmp?.let { b ->
                androidx.compose.foundation.Image(
                    bitmap = b.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = zoomA; scaleY = zoomA; translationX = pan.x; translationY = pan.y + dragY }
                )
            }
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
                Text(name.ifBlank { "Kullanıcı" }, color = Color.White, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 6.dp))
            }
        }

}

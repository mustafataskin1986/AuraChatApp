package com.aurachat.app.push

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import androidx.core.app.RemoteInput
import androidx.core.content.ContextCompat
import androidx.core.content.LocusIdCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.aurachat.app.CHANNEL_MESSAGES
import com.aurachat.app.MainActivity
import com.aurachat.app.R
import com.aurachat.app.data.Media
import com.google.android.gms.tasks.Tasks
import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

/**
 * WhatsApp tarzı bildirim: sohbet başına TEK blok (MessagingStyle), büyük avatar,
 * altında "Cevapla" (bildirimden yazma), "Okundu olarak işaretle" ve "Sessize al".
 */
object Notifs {
    const val ACT_REPLY = "com.aurachat.NOTIF_REPLY"
    const val ACT_READ = "com.aurachat.NOTIF_READ"
    const val ACT_MUTE = "com.aurachat.NOTIF_MUTE"
    const val ACT_CLEAR = "com.aurachat.NOTIF_CLEAR"
    const val KEY_REPLY = "aura_reply"
    private const val DELETED = "🚫 Bu mesaj silindi"
    private const val ACCENT = 0xFF10B981.toInt()
    private const val MAX_MSGS = 15

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("aura_notif", Context.MODE_PRIVATE)

    // ---------- depo ----------
    @Synchronized
    private fun stored(c: Context, chatId: String): JSONArray = try {
        JSONArray(sp(c).getString("chat_$chatId", null) ?: "[]")
    } catch (e: Throwable) { JSONArray() }

    @Synchronized
    private fun save(c: Context, chatId: String, arr: JSONArray) {
        val out = JSONArray()
        for (i in maxOf(0, arr.length() - MAX_MSGS) until arr.length()) out.put(arr.get(i))
        sp(c).edit().putString("chat_$chatId", out.toString()).apply()
    }

    @Synchronized
    private fun meta(c: Context, chatId: String): JSONObject = try {
        JSONObject(sp(c).getString("meta_$chatId", null) ?: "{}")
    } catch (e: Throwable) { JSONObject() }

    fun otherNameOf(c: Context, chatId: String): String = meta(c, chatId).optString("otherName", "")

    @Synchronized
    fun forget(c: Context, chatId: String) {
        sp(c).edit().remove("chat_$chatId").remove("meta_$chatId").apply()
    }

    /** Bildirimi kaldırır ve depoyu temizler (sohbet açılınca / okundu işaretlenince) */
    fun clear(c: Context, chatId: String) {
        if (chatId.isEmpty()) return
        forget(c, chatId)
        try {
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager)?.cancel("chat_$chatId", 1)
        } catch (e: Throwable) {}
    }

    // ---------- gelen mesaj ----------
    fun show(c: Context, d: Map<String, String>) {
        try {
            val chatId = d["chatId"] ?: return
            if (chatId.isEmpty()) return
            val title = (d["title"] ?: "").ifEmpty { "AuraChat" }
            val body = d["body"] ?: ""
            val tag = d["tag"] ?: ""
            val group = d["isGroup"] == "1"
            val arr = stored(c, chatId)

            if (body == DELETED && tag.isNotEmpty()) {
                var found = false
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    if (o.optString("tag") == tag) { o.put("text", DELETED); found = true }
                }
                if (!found) return
            } else {
                var sender = title
                var text = body
                if (group) {
                    val i = body.indexOf(": ")
                    if (i in 1..40) { sender = body.substring(0, i); text = body.substring(i + 2) }
                }
                if (tag.isNotEmpty()) {
                    for (i in 0 until arr.length()) if (arr.optJSONObject(i)?.optString("tag") == tag) return
                }
                arr.put(JSONObject()
                    .put("tag", tag).put("text", text).put("sender", sender)
                    .put("senderUid", d["senderUid"] ?: "")
                    .put("t", System.currentTimeMillis()).put("me", false))
            }
            save(c, chatId, arr)
            sp(c).edit().putString(
                "meta_$chatId",
                JSONObject().put("title", title).put("group", group)
                    .put("otherUid", d["otherUid"] ?: "")
                    .put("otherName", d["otherName"] ?: title).toString()
            ).apply()
            post(c, chatId, false)
        } catch (e: Throwable) {}
    }

    fun appendMine(c: Context, chatId: String, text: String) {
        val arr = stored(c, chatId)
        arr.put(JSONObject().put("tag", "").put("text", text).put("sender", "").put("senderUid", "")
            .put("t", System.currentTimeMillis()).put("me", true))
        save(c, chatId, arr)
        post(c, chatId, true)
    }

    fun appendFailure(c: Context, chatId: String) {
        val arr = stored(c, chatId)
        arr.put(JSONObject().put("tag", "").put("text", "⚠️ Cevap gönderilemedi").put("sender", "AuraChat")
            .put("senderUid", "aura-system").put("t", System.currentTimeMillis()).put("me", false))
        save(c, chatId, arr)
        post(c, chatId, true)
    }

    // ---------- avatar ----------
    private val colors = intArrayOf(
        0xFF6366F1.toInt(), 0xFFEC4899.toInt(), 0xFFF59E0B.toInt(), 0xFF10B981.toInt(),
        0xFF3B82F6.toInt(), 0xFF8B5CF6.toInt(), 0xFFEF4444.toInt(), 0xFF14B8A6.toInt()
    )

    private fun circle(src: Bitmap, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        cv.drawCircle(size / 2f, size / 2f, size / 2f, p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        val s = minOf(src.width, src.height)
        val r = Rect((src.width - s) / 2, (src.height - s) / 2, (src.width + s) / 2, (src.height + s) / 2)
        cv.drawBitmap(src, r, Rect(0, 0, size, size), p)
        return out
    }

    fun initialsBitmap(name: String, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = colors[(name.hashCode() and 0x7fffffff) % colors.size]
        cv.drawCircle(size / 2f, size / 2f, size / 2f, p)
        p.color = 0xFFFFFFFF.toInt()
        p.textSize = size * 0.42f
        p.textAlign = Paint.Align.CENTER
        val ini = name.trim().split(" ").filter { it.isNotEmpty() }.take(2).joinToString("") { it.substring(0, 1).uppercase() }.ifEmpty { "?" }
        val y = size / 2f - (p.descent() + p.ascent()) / 2f
        cv.drawText(ini, size / 2f, y, p)
        return out
    }

    /** Kullanıcı (ya da grup) avatarı: dosyada önbelleklenir, yoksa Firestore'dan çekilir (bloklar) */
    private fun avatarFor(c: Context, key: String, isGroup: Boolean): Bitmap? {
        if (key.isEmpty()) return null
        return try {
            val dir = File(c.filesDir, "notif_av").also { it.mkdirs() }
            val f = File(dir, key.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".png")
            val fresh = f.exists() && System.currentTimeMillis() - f.lastModified() < 12 * 3600 * 1000L
            if (!fresh) {
                val doc = Tasks.await(
                    FirebaseFirestore.getInstance().collection(if (isGroup) "groups" else "users").document(key).get(),
                    5, TimeUnit.SECONDS
                )
                val data = doc.getString(if (isGroup) "photo" else "avatar") ?: ""
                val bmp = if (data.isNotBlank()) Media.decode(data, 192) else null
                if (bmp != null) {
                    FileOutputStream(f).use { circle(bmp, 128).compress(Bitmap.CompressFormat.PNG, 100, it) }
                } else if (f.exists()) f.setLastModified(System.currentTimeMillis())
            }
            if (f.exists()) android.graphics.BitmapFactory.decodeFile(f.absolutePath) else null
        } catch (e: Throwable) { null }
    }

    private fun smallBitmap(c: Context, key: String, isGroup: Boolean, name: String, size: Int): Bitmap =
        avatarFor(c, key, isGroup) ?: initialsBitmap(name, size)

    // ---------- bildirimi çiz ----------
    fun post(c: Context, chatId: String, quiet: Boolean) {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            // Servis uygulama açılmadan çalışırsa kanal henüz yoktur; yoksa bildirim sessizce düşer
            if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL_MESSAGES) == null) {
                nm.createNotificationChannel(
                    android.app.NotificationChannel(CHANNEL_MESSAGES, "Mesajlar", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val arr = stored(c, chatId)
            if (arr.length() == 0) return
            val meta = meta(c, chatId)
            val title = meta.optString("title", "AuraChat")
            val group = meta.optBoolean("group", false)
            val otherUid = meta.optString("otherUid", "")
            val otherName = meta.optString("otherName", title)

            val me = Person.Builder().setName("Ben").setKey("aura-me").build()
            val style = NotificationCompat.MessagingStyle(me)
            if (group) { style.setConversationTitle(title); style.setGroupConversation(true) }

            val chatAv = smallBitmap(c, if (group) chatId else otherUid, group, title, 192)
            val people = HashMap<String, Person>()
            var lastT = System.currentTimeMillis()
            var lastText = ""
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val t = o.optLong("t", System.currentTimeMillis())
                val text = o.optString("text", "")
                lastT = t; lastText = text
                if (o.optBoolean("me", false)) {
                    style.addMessage(text, t, me)
                } else {
                    val name = o.optString("sender", title)
                    var key = o.optString("senderUid", "")
                    val uidKey = key
                    if (key.isEmpty()) key = "n:$name"
                    val p = people.getOrPut(key) {
                        val av = if (group) smallBitmap(c, uidKey, false, name, 128) else Bitmap.createScaledBitmap(chatAv, 128, 128, true)
                        Person.Builder().setName(name).setKey(key).setIcon(IconCompat.createWithBitmap(av)).build()
                    }
                    style.addMessage(text, t, p)
                }
            }

            val imm = PendingIntent.FLAG_IMMUTABLE
            val open = Intent(c, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("chatId", chatId)
                putExtra("otherUid", otherUid)
                putExtra("otherName", otherName)
            }
            val openPi = PendingIntent.getActivity(c, chatId.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT or imm)

            fun act(action: String) = Intent(c, NotifActionReceiver::class.java).setAction(action)
                .setData(Uri.parse("aura://${action.substringAfterLast('_').lowercase()}/$chatId")).putExtra("chatId", chatId)

            val mut = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val replyPi = PendingIntent.getBroadcast(c, chatId.hashCode(), act(ACT_REPLY), PendingIntent.FLAG_UPDATE_CURRENT or mut)
            val replyAction = NotificationCompat.Action.Builder(0, "Cevapla", replyPi)
                .addRemoteInput(RemoteInput.Builder(KEY_REPLY).setLabel("Mesaj yaz").build())
                .setAllowGeneratedReplies(true)
                .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
                .setShowsUserInterface(false).build()
            val readPi = PendingIntent.getBroadcast(c, chatId.hashCode(), act(ACT_READ), PendingIntent.FLAG_UPDATE_CURRENT or imm)
            val readAction = NotificationCompat.Action.Builder(0, "Okundu olarak işaretle", readPi)
                .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MARK_AS_READ)
                .setShowsUserInterface(false).build()
            val mutePi = PendingIntent.getBroadcast(c, chatId.hashCode(), act(ACT_MUTE), PendingIntent.FLAG_UPDATE_CURRENT or imm)
            val muteAction = NotificationCompat.Action.Builder(0, "Sessize al", mutePi)
                .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MUTE)
                .setShowsUserInterface(false).build()
            val clearPi = PendingIntent.getBroadcast(c, chatId.hashCode(), act(ACT_CLEAR), PendingIntent.FLAG_UPDATE_CURRENT or imm)

            // Android 11+: kısayol tanımlanınca bildirim "konuşma" görünümü alır (büyük avatar, uygulama ikonu)
            val sid = "chat_$chatId"
            try {
                val sc = ShortcutInfoCompat.Builder(c, sid)
                    .setShortLabel(title.take(30))
                    .setLongLived(true)
                    .setPerson(Person.Builder().setName(title).setKey(sid).setIcon(IconCompat.createWithBitmap(chatAv)).build())
                    .setIcon(IconCompat.createWithBitmap(chatAv))
                    .setIntent(Intent(c, MainActivity::class.java).setAction(Intent.ACTION_VIEW)
                        .putExtra("chatId", chatId).putExtra("otherUid", otherUid).putExtra("otherName", otherName))
                    .build()
                ShortcutManagerCompat.pushDynamicShortcut(c, sc)
            } catch (e: Throwable) {}

            val b = NotificationCompat.Builder(c, CHANNEL_MESSAGES)
                .setSmallIcon(R.drawable.ic_notification)
                .setColor(ACCENT)
                .setShortcutId(sid)
                .setLocusId(LocusIdCompat(sid))
                .setContentTitle(title)
                .setContentText(lastText)
                .setStyle(style)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(false)
                .setShowWhen(true)
                .setWhen(lastT)
                .setOnlyAlertOnce(quiet)
                .setContentIntent(openPi)
                .setDeleteIntent(clearPi)
                .addAction(replyAction)
                .addAction(readAction)
                .addAction(muteAction)
                .setLargeIcon(chatAv)
            nm.notify("chat_$chatId", 1, b.build())
        } catch (e: Throwable) {}
    }
}

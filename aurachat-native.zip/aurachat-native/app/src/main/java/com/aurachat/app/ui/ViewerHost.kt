package com.aurachat.app.ui

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Media
import com.aurachat.app.data.Message
import com.aurachat.app.data.ReplyRef
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.launch

/** Resim görüntüleyiciden düzenlenen resmi, ilgili sohbetin mesaj kutusuna taşır (sohbet dışındaki sayfalardan) */
object ViewerBridge {
    private val edited = HashMap<String, MutableList<String>>()
    fun put(chatId: String, dataUrl: String) { edited.getOrPut(chatId) { ArrayList() }.add(dataUrl) }
    fun take(chatId: String): List<String> = edited.remove(chatId) ?: emptyList()
}

/**
 * Tüm sayfalarda (sohbet, medya, yıldızlı, kişi bilgisi) aynı resim görüntüleyici: ilet, yıldız, tepki, cevap,
 * "Sohbette göster", "Profil resmi yap", "Düzenle". Tek yerde tutulur ki hepsi birebir aynı olsun.
 */
@Composable
fun MessageImageViewer(
    me: UserProfile,
    target: ChatTarget,
    items: List<ViewerItem>,
    startIndex: Int,
    album: Boolean,
    msgFor: (String) -> Message?,
    onForward: (Message) -> Unit,
    onShowInChat: (Message) -> Unit,
    onEdited: (String) -> Unit,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val starredList by remember(me.uid) { Repo.starredFlow(me.uid) }.collectAsState(emptyList())
    val starredKeys = remember(starredList) { starredList.map { it.key }.toSet() }
    val localReact = remember { androidx.compose.runtime.mutableStateMapOf<String, String>() }
    val splitIds = remember { androidx.compose.runtime.mutableStateMapOf<String, String>() }   // albümden ayrılan foto (src) -> yeni mesaj id
    var editSrc by remember { mutableStateOf<String?>(null) }
    var cropUri by remember { mutableStateOf<android.net.Uri?>(null) }

    fun mOf(it: ViewerItem): Message? = msgFor(it.id)

    ChatImageViewer(
        items, startIndex, album,
        ViewerActions(
            onForward = { it -> mOf(it)?.let { m -> onClose(); onForward(m) } },
            onStar = { it ->
                mOf(it)?.let { m ->
                    val sid = splitIds[it.src]
                    if (sid != null) {
                        Repo.toggleStar(me.uid, target, m.copy(id = sid, imageUrl = it.src, images = emptyList(), imagesCount = 0, text = ""), starredKeys.contains(Repo.starKey(target.chatId, sid)))
                    } else {
                        val idx = m.images.indexOf(it.src)
                        if (m.images.size > 1 && idx >= 0 && m.senderUid == me.uid && !starredKeys.contains(Repo.starKey(target.chatId, m.id))) {
                            scope.launch {
                                val nid = try { Repo.splitAlbumImage(me.uid, target, m, idx) } catch (ex: Throwable) { null }
                                if (nid != null) {
                                    splitIds[it.src] = nid
                                    Repo.toggleStar(me.uid, target, m.copy(id = nid, imageUrl = it.src, images = emptyList(), imagesCount = 0, text = ""), false)
                                } else Repo.toggleStar(me.uid, target, m, false)
                            }
                        } else Repo.toggleStar(me.uid, target, m, starredKeys.contains(Repo.starKey(target.chatId, m.id)))
                    }
                }
            },
            isStarred = { it -> starredKeys.contains(Repo.starKey(target.chatId, splitIds[it.src] ?: it.id)) },
            getReaction = { it -> localReact[it.id] ?: mOf(it)?.reactions?.get(me.uid) },
            onReact = { it, e ->
                val m = mOf(it)
                if (m != null) {
                    val old = (localReact[m.id] ?: m.reactions[me.uid])?.takeIf { it.isNotEmpty() }
                    Repo.react(me.uid, target.chatId, m.id, e, old)
                    localReact[m.id] = if (old == e) "" else e
                    if (old != e) scope.launch { try { Repo.reactNotify(me, target, m, e) } catch (ex: Throwable) {} }
                }
            },
            onReplySend = { it, t ->
                val m = mOf(it)
                if (m != null) {
                    val ref = ReplyRef(m.id, m.senderName.ifBlank { "Kullanıcı" }, Repo.previewOf(m).take(100), m.senderUid)
                    scope.launch { try { Repo.sendText(me, target, t, ref) } catch (ex: Throwable) {} }
                }
            },
            menu = listOf<Pair<String, (ViewerItem) -> Unit>>(
                "Sohbette göster" to { it -> mOf(it)?.let { m -> onClose(); onShowInChat(m) } },
                "Profil resmi yap" to { it ->
                    try {
                        val f = Media.sharableFile(ctx, it.src, "profil_${System.currentTimeMillis()}.jpg")
                        cropUri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                    } catch (e: Throwable) { Toast.makeText(ctx, "Resim açılamadı", Toast.LENGTH_SHORT).show() }
                },
                "Düzenle" to { it -> editSrc = it.src }
            )
        ),
        onClose
    )

    editSrc?.let { src ->
        ImageEditor(
            dataUrl = src, targetBytes = 300 * 1024,
            onDone = { nu -> editSrc = null; onEdited(nu); onClose() },
            onCancel = { editSrc = null }
        )
    }
    cropUri?.let { cu ->
        AvatarCropper(
            cu, 320,
            onDone = { d ->
                cropUri = null
                scope.launch {
                    try { Repo.updateProfileFields(me, mapOf("avatar" to d)); Toast.makeText(ctx, "Profil resmi güncellendi", Toast.LENGTH_SHORT).show() } catch (e: Throwable) {}
                }
                onClose()
            },
            onCancel = { cropUri = null }
        )
    }
}

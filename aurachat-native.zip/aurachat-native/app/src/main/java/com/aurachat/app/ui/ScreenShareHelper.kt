package com.aurachat.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext

/**
 * Ekran paylaşımı için tek giriş noktası: hem görüntülü arama menüsü hem de sohbetteki "+" penceresi
 * burayı kullanır. İzin penceresini açar, onay gelince onResult(resultCode, data) çağrılır.
 */
@Composable
fun rememberScreenShareStarter(onResult: (Int, Intent) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val cb by rememberUpdatedState(onResult)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == Activity.RESULT_OK && d != null) cb(r.resultCode, d)
    }
    return {
        try {
            val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            launcher.launch(mpm.createScreenCaptureIntent())
        } catch (e: Throwable) {
            Toast.makeText(ctx, "Ekran paylaşımı başlatılamadı", Toast.LENGTH_SHORT).show()
        }
    }
}

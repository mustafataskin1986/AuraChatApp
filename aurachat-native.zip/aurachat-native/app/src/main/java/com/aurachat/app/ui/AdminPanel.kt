package com.aurachat.app.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Yönetici e-postası: panel yalnızca bu hesapla açılır; asıl yetki kontrolü sunucuda (api/admin) yapılır */
private const val ADMIN_EMAIL = "mustafataskin1986@gmail.com"
private const val ADMIN_API = "https://aurachat-amber.vercel.app/api/admin"

fun isAdminAccount(): Boolean =
    FirebaseAuth.getInstance().currentUser?.email?.trim()?.equals(ADMIN_EMAIL, ignoreCase = true) == true

/** Parmak sayısı örüntüsü: 1, 1, 2, 1 (tek, tek, iki parmakla, tek) dokunuşu paneli açar. Dokunuşları tüketmez. */
fun Modifier.adminTapPattern(enabled: Boolean, onOpen: () -> Unit): Modifier =
    if (!enabled) this else this.pointerInput(Unit) {
        val seq = ArrayList<Int>()
        var last = 0L
        awaitEachGesture {
            val first = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            val start = System.currentTimeMillis()
            var maxP = 1
            var moved = false
            while (true) {
                val ev = awaitPointerEvent(PointerEventPass.Initial)
                val pressed = ev.changes.count { it.pressed }
                if (pressed > maxP) maxP = pressed
                if (ev.changes.any { (it.position - first.position).getDistance() > viewConfiguration.touchSlop * 2f }) moved = true
                if (pressed == 0) break
            }
            val now = System.currentTimeMillis()
            if (moved || now - start > 450) { seq.clear(); return@awaitEachGesture }
            if (seq.isNotEmpty() && now - last > 1500) seq.clear()
            last = now
            seq.add(maxP)
            while (seq.size > 4) seq.removeAt(0)
            if (seq == listOf(1, 1, 2, 1)) { seq.clear(); onOpen() }
        }
    }

private object AdminApi {
    suspend fun call(body: JSONObject): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val user = FirebaseAuth.getInstance().currentUser ?: return@withContext null
            val token = user.getIdToken(false).await().token ?: return@withContext null
            val c = URL(ADMIN_API).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer $token")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
            c.disconnect()
            JSONObject(txt).put("_code", code)
        } catch (e: Throwable) { null }
    }
}

private class AdminReport(val id: String, val reporter: String, val reported: String, val chatId: String, val isGroup: Boolean, val reason: String, val note: String, val at: Long, val msgs: List<ReportMsg> = emptyList(), val reportedUid: String = "", val bubble: String = "")
private class ReportMsg(val t: Long, val who: String, val mine: Boolean, val text: String, val uid: String = "", val kind: String = "text")

private class AdminUser(val uid: String, val name: String, val email: String, val phone: String, val platform: String, val hasToken: Boolean, val lastSeen: Long)

private val AdPanel: Color get() = auraLc(0xFF111B21)
private val AdField: Color get() = AuraSurface
private val AdGreen: Color get() = auraLc(0xFF22C55E)

@Composable
private fun AdChip(label: String, on: Boolean, onClick: () -> Unit) {
    val lt = AuraUi.light
    val bg = if (on) (if (lt) Color(0xFFD9FDD3) else Color(0xFF103629)) else Color.Transparent
    val fg = if (on) (if (lt) Color(0xFF0B6B4D) else Color(0xFF25D366)) else (if (lt) Color(0xFF3B4A54) else Color(0xFFA7ADB2))
    val bd = if (lt) (if (on) Color(0xFFA9E5A0) else Color(0xFFE0E0E0)) else (if (on) Color(0xFF14503B) else Color(0xFF2C2C2C))
    Text(
        label, color = fg, fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(bg).border(1.dp, bd, RoundedCornerShape(50))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 4.dp)
    )
}

@Composable
private fun AdLabel(text: String, right: String = "") {
    Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = AuraMuted, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        if (right.isNotEmpty()) Text(right, color = AuraMuted, fontSize = 12.sp)
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun AdminUserRow(u: AdminUser, selected: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val prof = liveProfile(u.uid).value
    val name = prof?.name?.takeIf { it.isNotBlank() } ?: u.name.ifBlank { "(adsız)" }
    Row(
        Modifier.fillMaxWidth()
            .background(if (selected) (if (AuraUi.light) Color(0xFFD7F5CF) else auraLc(0x4422C55E)) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(50.dp)) {
            Avatar(name, prof?.avatar, 50.dp)
            if (selected) Box(
                Modifier.align(Alignment.BottomEnd).size(20.dp).clip(CircleShape).background(AuraBg),
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size(16.dp).clip(CircleShape).background(AdGreen), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(12.dp))
                }
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = AuraWhite, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val sub = listOf(u.email, u.phone).filter { it.isNotBlank() }.joinToString(" • ")
            if (sub.isNotEmpty()) Text(sub, color = AuraMuted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(if (u.hasToken) AdGreen else Color(0xFFF59E0B)))
                Text(
                    "  " + (if (u.hasToken) "Bildirim açık" else "Bildirim yok") + (if (u.platform.isNotBlank()) " • ${if (u.platform == "native") "Android" else u.platform}" else "") +
                        (if (u.lastSeen > 0) " • ${statusTimeLabel(u.lastSeen)}" else ""),
                    color = AuraMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun AdminPanelScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val pager = androidx.compose.foundation.pager.rememberPagerState { 3 }
    var users by remember { mutableStateOf<List<AdminUser>?>(null) }
    var error by remember { mutableStateOf("") }
    val selected = remember { mutableStateListOf<String>() }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) }
    var title by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("push") }
    var busy by remember { mutableStateOf(false) }
    var reports by remember { mutableStateOf<List<AdminReport>?>(null) }
    val openReports = remember { androidx.compose.runtime.mutableStateListOf<String>() }
    var banTarget by remember { mutableStateOf<AdminReport?>(null) }
    var detail by remember { mutableStateOf<AdminUser?>(null) }
    var confirmSend by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val selMode = selected.isNotEmpty()
    BackHandler { if (selMode) selected.clear() else onBack() }

    banTarget?.let { bt ->
        AuraAlertDialog(
            onDismissRequest = { banTarget = null },
            containerColor = AuraSurface,
            title = { Text("Kullanıcı banlansın mı?", color = AuraWhite) },
            text = { Text("${bt.reported.ifBlank { "Bu kullanıcı" }} hesabı devre dışı bırakılır ve oturumu kapanır. Şikayet listeden kalkar.", color = AuraMuted) },
            confirmButton = {
                TextButton(onClick = {
                    banTarget = null
                    scope.launch {
                        val r = AdminApi.call(JSONObject().put("action", "ban").put("uid", bt.reportedUid).put("id", bt.id))
                        if (r != null && r.optInt("_code") == 200) reports = reports?.filter { it.id != bt.id }
                        else android.widget.Toast.makeText(ctx, "Banlanamadı (admin.js güncel mi?)", android.widget.Toast.LENGTH_LONG).show()
                    }
                }) { Text("Banla", color = auraLc(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { banTarget = null }) { Text("Vazgeç", color = AdGreen) } }
        )
    }

    fun loadReports() {
        scope.launch {
            val r = AdminApi.call(JSONObject().put("action", "reports"))
            if (r == null || r.optInt("_code") != 200) { reports = emptyList(); return@launch }
            val arr: JSONArray = r.optJSONArray("reports") ?: JSONArray()
            reports = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                AdminReport(o.optString("id"), o.optString("reporterName"), o.optString("reportedName"), o.optString("chatId"), o.optBoolean("isGroup"), o.optString("reason"), o.optString("note"), o.optLong("at"),
                    (o.optJSONArray("messages")?.let { a -> (0 until a.length()).map { k ->
                        val mo = a.optJSONObject(k)
                        if (mo != null) ReportMsg(mo.optLong("t"), mo.optString("w"), mo.optBoolean("me"), mo.optString("x"), mo.optString("u"), mo.optString("k").ifBlank { "text" })
                        else ReportMsg(0L, "", false, a.optString(k))
                    } } ?: emptyList()), o.optString("reportedUid"), o.optString("bubble"))
            }
        }
    }

    fun load() {
        loadReports()
        error = ""
        users = null
        scope.launch {
            val r = AdminApi.call(JSONObject().put("action", "users"))
            if (r == null || r.optInt("_code") != 200) {
                error = r?.optString("error")?.ifBlank { null } ?: "Sunucuya ulaşılamadı"
                users = emptyList()
                return@launch
            }
            val arr: JSONArray = r.optJSONArray("users") ?: JSONArray()
            users = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                AdminUser(o.optString("uid"), o.optString("name"), o.optString("email"), o.optString("phone"), o.optString("platform"), o.optBoolean("hasToken"), o.optLong("lastSeen"))
            }
        }
    }
    LaunchedEffect(Unit) { load() }

    val now = System.currentTimeMillis()
    val q = query.trim().lowercase()
    val shown = (users ?: emptyList()).filter { u ->
        (q.isEmpty() || u.name.lowercase().contains(q) || u.email.lowercase().contains(q) || u.phone.contains(q)) &&
            when (filter) { 1 -> u.hasToken; 2 -> !u.hasToken; 3 -> u.lastSeen > 0 && now - u.lastSeen < 24L * 3600_000L; else -> true }
    }
    val recipientCount = if (selected.isEmpty()) (users?.size ?: 0) else selected.size

    fun doSend() {
        busy = true
        scope.launch {
            val body = JSONObject().put("action", "send").put("title", title.trim()).put("body", text.trim()).put("mode", mode)
            if (selected.isNotEmpty()) body.put("uids", JSONArray(selected.toList()))
            val r = AdminApi.call(body)
            busy = false
            if (r != null && r.optInt("_code") == 200) {
                Toast.makeText(ctx, "${r.optInt("sent")} kişiye gönderildi" + (if (r.optInt("failed") > 0) ", ${r.optInt("failed")} başarısız" else ""), Toast.LENGTH_LONG).show()
                title = ""; text = ""
            } else Toast.makeText(ctx, r?.optString("error")?.ifBlank { null } ?: "Gönderilemedi", Toast.LENGTH_LONG).show()
        }
    }

    if (confirmSend) {
        AuraAlertDialog(
            onDismissRequest = { confirmSend = false },
            containerColor = AuraSurface,
            title = { Text("Bildirim gönderilsin mi?", color = AuraWhite, fontSize = 18.sp) },
            text = { Text(if (selected.isEmpty()) "Tüm kullanıcılara ($recipientCount kişi) gönderilecek." else "$recipientCount seçili kişiye gönderilecek.", color = AuraMuted, fontSize = 14.sp) },
            confirmButton = { TextButton(onClick = { confirmSend = false; doSend() }) { Text("Gönder", color = AdGreen, fontWeight = FontWeight.Medium) } },
            dismissButton = { TextButton(onClick = { confirmSend = false }) { Text("Vazgeç", color = AuraMuted) } }
        )
    }

    detail?.let { du ->
        val prof = liveProfile(du.uid).value
        val nm = prof?.name?.takeIf { it.isNotBlank() } ?: du.name.ifBlank { "(adsız)" }
        AuraAlertDialog(
            onDismissRequest = { detail = null },
            containerColor = AuraSurface,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(nm, prof?.avatar, 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(nm, color = AuraWhite, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        "E-posta" to du.email, "Telefon" to du.phone,
                        "Platform" to (if (du.platform == "native") "Android" else du.platform),
                        "Bildirim" to (if (du.hasToken) "Açık" else "Yok"),
                        "Son görülme" to (if (du.lastSeen > 0) statusTimeLabel(du.lastSeen) else "-"),
                        "UID" to du.uid
                    ).filter { it.second.isNotBlank() }.forEach { (k, v) ->
                        Row {
                            Text(k, color = AuraMuted, fontSize = 13.sp, modifier = Modifier.width(88.dp))
                            Text(v, color = AuraWhite, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    selected.clear(); selected.add(du.uid); detail = null
                    scope.launch { pager.animateScrollToPage(1) }
                }) { Text("Bildirim gönder", color = AdGreen, fontWeight = FontWeight.Medium) }
            },
            dismissButton = { TextButton(onClick = { detail = null }) { Text("Kapat", color = AuraMuted) } }
        )
    }

    Column(Modifier.fillMaxSize().background(AuraBg).navigationBarsPadding()) {
        // Üst çubuk: sohbet listesindeki gibi; seçim modunda renk değişir, ⋮ menüsü var
        val selBar = if (AuraUi.light) Color(0xFFF7F5F3) else if (AuraUi.black) Color(0xFF1A1A1A) else Color(0xFF1F2C34)
        Box(Modifier.fillMaxWidth().background(if (selMode) selBar else AuraBg).statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().height(60.dp).background(if (selMode) selBar else AuraBlack).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (selMode) {
                    IconButton(onClick = { selected.clear() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "İptal", tint = AuraWhite) }
                    Text("${selected.size}", color = AuraWhite, fontSize = 20.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = { scope.launch { pager.animateScrollToPage(1) } }) { Icon(Icons.AutoMirrored.Filled.Send, "Bildirim gönder", tint = AuraWhite) }
                } else {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                    Column(Modifier.weight(1f).padding(start = 4.dp)) {
                        Text("Yönetici paneli", color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        val us = users
                        if (us != null) Text("${us.size} kişi • ${us.count { it.hasToken }} bildirim alabilir", color = AuraMuted, fontSize = 12.sp, maxLines = 1)
                    }
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = AuraWhite) }
                    AuraDropdownMenu(expanded = menu, onDismissRequest = { menu = false }, shape = RoundedCornerShape(16.dp), containerColor = AuraSurface) {
                        @Composable
                        fun Item(label: String, onClick: () -> Unit) {
                            DropdownMenuItem(text = { Text(label, color = AuraWhite, fontSize = 16.sp) }, onClick = { menu = false; onClick() })
                        }
                        Item("Yenile") { load() }
                        Item("Tümünü seç") { shown.forEach { if (!selected.contains(it.uid)) selected.add(it.uid) } }
                        Item("Bildirimi olanları seç") { selected.clear(); (users ?: emptyList()).filter { it.hasToken }.forEach { selected.add(it.uid) } }
                        if (selMode) Item("Seçimi temizle") { selected.clear() }
                    }
                }
            }
        }

        LiquidTabs(pager, listOf("Kişiler", "Bildirim gönder", "Şikayetler"), listOf(0, 0, reports?.size ?: 0)) { i -> scope.launch { pager.animateScrollToPage(i) } }
        Spacer(Modifier.height(8.dp))

        androidx.compose.foundation.pager.HorizontalPager(state = pager, modifier = Modifier.weight(1f).fillMaxWidth(), beyondViewportPageCount = 2) { page -> when (page) {
        0 -> Column(Modifier.fillMaxSize()) {
            // Arama kutusu: sohbet listesiyle aynı ölçü ve renk
            Row(Modifier.fillMaxWidth().padding(start = 13.dp, end = 13.dp, top = 2.dp, bottom = 8.dp)) {
                Row(
                    Modifier.weight(1f).height(49.dp).clip(RoundedCornerShape(50)).background(AuraSurface).padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search, null, tint = AuraMuted, modifier = Modifier.size(24.dp))
                    Box(Modifier.weight(1f).padding(start = 14.dp)) {
                        if (query.isEmpty()) Text("Ara (ad, e-posta, telefon)", color = AuraMuted, fontSize = 17.sp, maxLines = 1)
                        AuraTextField(
                            value = query, onValueChange = { query = it }, singleLine = true,
                            textStyle = TextStyle(color = AuraWhite, fontSize = 17.sp), cursorBrush = SolidColor(AdGreen),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (query.isNotEmpty()) Icon(Icons.Default.Close, "Temizle", tint = AuraMuted, modifier = Modifier.size(20.dp).clickable { query = "" })
                }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 13.dp).padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Tümü", "Bildirimi açık", "Bildirimi yok", "Son 24 saat").forEachIndexed { k, l -> AdChip(l, filter == k) { filter = k } }
            }
            val list = users
            if (list == null) {
                Text("Yükleniyor...", color = AuraMuted, modifier = Modifier.padding(20.dp))
            } else {
                if (error.isNotEmpty()) Text(error, color = auraLc(0xFFEF4444), modifier = Modifier.padding(16.dp))
                if (shown.isEmpty() && error.isEmpty()) Text("Kişi bulunamadı", color = AuraMuted, modifier = Modifier.padding(20.dp))
                LazyColumn(Modifier.weight(1f)) {
                    items(shown, key = { it.uid }) { u ->
                        val on = selected.contains(u.uid)
                        AdminUserRow(
                            u, on,
                            onClick = { if (selMode) { if (on) selected.remove(u.uid) else selected.add(u.uid) } else detail = u },
                            onLongClick = { if (on) selected.remove(u.uid) else selected.add(u.uid) }
                        )
                    }
                }
            }
        }
        2 -> Column(Modifier.fillMaxSize()) {
            val rl = reports
            if (rl == null) Text("Yükleniyor...", color = AuraMuted, modifier = Modifier.padding(20.dp))
            else if (rl.isEmpty()) Text("Şikayet yok", color = AuraMuted, modifier = Modifier.padding(20.dp))
            else LazyColumn(Modifier.weight(1f)) {
                items(rl, key = { it.id }) { rp ->
                    ReportItem(
                        rp, openReports.contains(rp.id),
                        onToggle = { if (openReports.contains(rp.id)) openReports.remove(rp.id) else openReports.add(rp.id) },
                        onBan = { banTarget = rp },
                        onDelete = {
                            scope.launch {
                                AdminApi.call(JSONObject().put("action", "reportDone").put("id", rp.id))
                                reports = reports?.filter { it.id != rp.id }
                            }
                        }
                    )
                }
            }
        }
        else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            AdLabel("Başlık", "${title.length}/100")
            AdminField(title, { if (it.length <= 100) title = it }, "Örn: Yeni sürüm yayında")
            AdLabel("Metin", "${text.length}/400")
            AdminField(text, { if (it.length <= 400) text = it }, "Mesajınız", singleLine = false, minH = 110)
            AdLabel("Gönderim şekli")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AdChip("Kayan bildirim", mode == "push") { mode = "push" }
                AdChip("Uygulama içi", mode == "inapp") { mode = "inapp" }
            }
            Text(
                if (mode == "push") "Uygulama kapalıyken de telefonda üstten kayan bildirim olarak çıkar."
                else "Sadece uygulaması o an açık olanlara üstten kayan bir kart olarak gösterilir.",
                color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
            )
            AdLabel("Alıcı")
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(AuraSurface).padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (selected.isEmpty()) "Herkes ($recipientCount kişi)" else "$recipientCount seçili kişi",
                        color = AuraWhite, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f)
                    )
                    if (selected.isNotEmpty()) Text("Temizle", color = AdGreen, fontSize = 14.sp, modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { selected.clear() }.padding(6.dp))
                }
                if (selected.isNotEmpty()) {
                    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        selected.take(6).forEach { uid ->
                            val pr = liveProfile(uid).value
                            val n = pr?.name?.takeIf { it.isNotBlank() } ?: (users?.firstOrNull { it.uid == uid }?.name ?: "")
                            Box(Modifier.padding(end = 6.dp)) { Avatar(n, pr?.avatar, 34.dp) }
                        }
                        if (selected.size > 6) Text("+${selected.size - 6}", color = AuraMuted, fontSize = 13.sp)
                    }
                } else Text("Kişiler sekmesinde bir kişiye basılı tutarak seçim yapabilirsin.", color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
            AdLabel("Önizleme")
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(AuraSurface)
                    .border(1.dp, AuraMuted.copy(alpha = 0.2f), RoundedCornerShape(16.dp)).padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(title.ifBlank { "Başlık" }, color = if (title.isBlank()) AuraMuted else AuraWhite, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(text.ifBlank { "Mesajınız burada görünür" }, color = if (text.isBlank()) AuraMuted else AuraWhite.copy(alpha = 0.85f), fontSize = 14.sp, maxLines = 4, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
            }
            Spacer(Modifier.height(22.dp))
            val canSend = !busy && title.isNotBlank() && text.isNotBlank()
            Box(
                Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(50))
                    .background(if (canSend) AdGreen else AuraMuted.copy(alpha = 0.25f))
                    .clickable(enabled = canSend) { confirmSend = true },
                contentAlignment = Alignment.Center
            ) { Text(if (busy) "Gönderiliyor..." else "Gönder", color = if (canSend) Color.White else AuraMuted, fontSize = 17.sp, fontWeight = FontWeight.Medium) }
            Spacer(Modifier.height(24.dp))
        } } }
    }
}

@Composable
private fun AdminField(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier, singleLine: Boolean = true, minH: Int = 48) {
    Box(
        modifier.fillMaxWidth().heightIn(min = minH.dp).clip(RoundedCornerShape(14.dp)).background(AuraSurface).padding(horizontal = 16.dp, vertical = 13.dp)
    ) {
        if (value.isEmpty()) Text(hint, color = AuraMuted, fontSize = 16.sp)
        AuraTextField(
            value = value, onValueChange = onChange, singleLine = singleLine,
            textStyle = TextStyle(color = AuraWhite, fontSize = 16.sp), cursorBrush = SolidColor(AdGreen),
            modifier = Modifier.fillMaxWidth()
        )
    }
}


/** Uygulama açıkken yöneticiden gelen "uygulama içi" bildirimler */
object AdminBanner {
    val msg = mutableStateOf<Pair<String, String>?>(null)
    fun show(title: String, body: String) { msg.value = title to body }
}

@Composable
fun AdminBannerOverlay() {
    val m = AdminBanner.msg.value
    LaunchedEffect(m) { if (m != null) { delay(6000); if (AdminBanner.msg.value == m) AdminBanner.msg.value = null } }
    androidx.compose.animation.AnimatedVisibility(
        visible = m != null,
        enter = androidx.compose.animation.slideInVertically { -it } + androidx.compose.animation.fadeIn(),
        exit = androidx.compose.animation.slideOutVertically { -it } + androidx.compose.animation.fadeOut()
    ) {
        val shown = remember(m) { m }
        Box(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(auraLc(0xFF1F2C34))
                    .border(1.dp, auraLc(0xFF2E4048), RoundedCornerShape(16.dp))
                    .clickable { AdminBanner.msg.value = null }.padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(shown?.first ?: "", color = AuraWhite, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(shown?.second ?: "", color = auraLc(0xFFD1D5DB), fontSize = 14.sp, maxLines = 4, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
            }
        }
    }
}


private fun hexColor(h: String, fallback: Color): Color = try { Color(android.graphics.Color.parseColor(h)) } catch (e: Throwable) { fallback }

/** Şikayet satırı: kapalıyken kompakt kart (sağa kaydırınca silinir), açılınca son mesajlar balon olarak görünür */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun ReportItem(rp: AdminReport, open: Boolean, onToggle: () -> Unit, onBan: () -> Unit, onDelete: () -> Unit) {
    val dismiss = androidx.compose.material3.rememberSwipeToDismissBoxState(
        confirmValueChange = { v -> if (v == androidx.compose.material3.SwipeToDismissBoxValue.StartToEnd) { onDelete(); true } else false }
    )
    // kişi adı değişince otomatik güncellenir
    val liveReported = if (rp.reportedUid.isNotBlank()) liveProfile(rp.reportedUid).value?.name?.takeIf { it.isNotBlank() } else null
    val reportedName = liveReported ?: rp.reported.ifBlank { "(adsız)" }
    androidx.compose.material3.SwipeToDismissBox(
        state = dismiss,
        enableDismissFromStartToEnd = !open,
        enableDismissFromEndToStart = false,
        backgroundContent = {
            Box(
                Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFB91C1C)).padding(start = 18.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Delete, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    Text("  Sil", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp)).background(AdField)) {
            Column(Modifier.fillMaxWidth().clickable { onToggle() }.padding(horizontal = 12.dp, vertical = 10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(reportedName, if (rp.reportedUid.isNotBlank()) liveProfile(rp.reportedUid).value?.avatar else "", 34.dp, isGroup = rp.isGroup)
                    Spacer(Modifier.width(10.dp))
                    Text((if (rp.isGroup) "Grup: " else "Kişi: ") + reportedName, color = AuraWhite, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        rp.reason, color = auraLc(0xFFFBBF24), fontSize = 12.sp,
                        modifier = Modifier.clip(RoundedCornerShape(50)).border(1.dp, auraLc(0xFF7A5A10), RoundedCornerShape(50))
                            .background(auraLc(0x33F59E0B)).padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        androidx.compose.ui.text.buildAnnotatedString {
                            append("Şikayet eden: ")
                            pushStyle(androidx.compose.ui.text.SpanStyle(fontWeight = FontWeight.Bold)); append(rp.reporter.ifBlank { "(adsız)" }); pop()
                            append(" • " + statusTimeLabel(rp.at))
                        },
                        color = AuraMuted, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(if (open) "Gizle ▲" else "Mesajları Gör ▼", color = AdGreen, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
            if (open) {
                Column(Modifier.fillMaxWidth().background(AuraBlack).padding(horizontal = 12.dp, vertical = 10.dp)) {
                    if (rp.note.isNotBlank()) {
                        Text(rp.note, color = AuraWhite, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
                    }
                    Text("SON SOHBET AKIŞI VE EKLER", color = AuraMuted, fontSize = 11.sp, letterSpacing = 0.8.sp)
                    if (rp.msgs.isEmpty()) Text("Mesaj eklenmemiş", color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    rp.msgs.forEach { m ->
                        val liveN = if (m.uid.isNotBlank()) liveProfile(m.uid).value?.name?.takeIf { it.isNotBlank() } else null
                        val nm = liveN ?: m.who.ifBlank { "?" }
                        // balon rengi: şikayet anındaki sohbet teması (gönderen = şikayet edenin giden balon rengi)
                        val bg = if (m.mine) hexColor(rp.bubble, Color(0xFF7F2527)) else Color(0xFF212121)
                        Box(Modifier.fillMaxWidth().padding(top = 6.dp), contentAlignment = if (m.mine) Alignment.CenterEnd else Alignment.CenterStart) {
                            Column(Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(12.dp)).background(bg).padding(horizontal = 10.dp, vertical = 6.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(nm + if (m.mine) " (Şikayet Eden)" else "", color = Color(0xFFE9D5D5), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f, fill = false), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (m.t > 0) Text(statusTimeLabel(m.t), color = Color(0xB3FFFFFF), fontSize = 10.sp)
                                }
                                if (m.kind != "text") {
                                    // görsel/ses/belge görünmese bile küçük bir kart
                                    val (ic: androidx.compose.ui.graphics.vector.ImageVector, lbl: String) = when (m.kind) {
                                        "image" -> Icons.Default.Image to "Fotoğraf"
                                        "audio" -> Icons.Default.Mic to "Sesli mesaj"
                                        "video" -> Icons.Default.Videocam to "Video"
                                        "file" -> Icons.Default.Description to "Belge"
                                        else -> Icons.Default.LocationOn to "Konum"
                                    }
                                    Row(
                                        Modifier.padding(top = 4.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x33FFFFFF)).padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(ic, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                        Text(" " + lbl, color = Color.White, fontSize = 13.sp)
                                    }
                                }
                                if (m.text.isNotBlank()) Text(m.text, color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!rp.isGroup && rp.reportedUid.isNotBlank()) Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).border(1.dp, auraLc(0xFF7F2527), RoundedCornerShape(10.dp))
                                .background(auraLc(0x33DC2626)).clickable { onBan() }.padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) { Text("Kullanıcıyı Banla", color = auraLc(0xFFFCA5A5), fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).border(1.dp, auraLc(0xFF3A3D42), RoundedCornerShape(10.dp))
                                .background(AdField).clickable { onToggle() }.padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) { Text("Şikayeti Kapat", color = AuraWhite, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                    }
                }
            }
        }
    }
}


/** Sohbet listesindeki alt çubuk gibi: iki ucu farklı hızda kayan su damlası göstergeli, parmakla kaydırılan sekmeler */
@Composable
private fun LiquidTabs(pager: androidx.compose.foundation.pager.PagerState, labels: List<String>, badges: List<Int>, onTab: (Int) -> Unit) {
    val n = labels.size
    val pos = (pager.currentPage + pager.currentPageOffsetFraction).coerceIn(0f, (n - 1).toFloat())
    Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp).height(46.dp).clip(RoundedCornerShape(23.dp)).background(AdField)) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            val cw = size.width / n
            val cy = size.height / 2f
            val r = cy - 4.dp.toPx()
            val half = (cw / 2f - r - 5.dp.toPx()).coerceAtLeast(2.dp.toPx())
            val i = kotlin.math.floor(pos).toInt().coerceIn(0, n - 2)
            val p = (pos - i).coerceIn(0f, 1f)
            val xi = (i + 0.5f) * cw
            val xj = (i + 1.5f) * cw
            val a = xi + (xj - xi) * (p * p)
            val b = xi + (xj - xi) * (1f - (1f - p) * (1f - p))
            val left = kotlin.math.min(a, b) - half
            val right = kotlin.math.max(a, b) + half
            val stretch = (right - left) - 2f * half
            val neck = r * (1f - 0.6f * kotlin.math.min(1f, stretch / (cw * 0.6f)))
            val mid = (left + right) / 2f
            val path = androidx.compose.ui.graphics.Path().apply {
                moveTo(left, cy - r)
                quadraticTo(mid, cy - neck, right, cy - r)
                arcTo(androidx.compose.ui.geometry.Rect(right - r, cy - r, right + r, cy + r), -90f, 180f, false)
                quadraticTo(mid, cy + neck, left, cy + r)
                arcTo(androidx.compose.ui.geometry.Rect(left - r, cy - r, left + r, cy + r), 90f, 180f, false)
                close()
            }
            drawPath(path, AdGreen)
        }
        Row(Modifier.fillMaxSize()) {
            labels.forEachIndexed { idx, l ->
                val t = 1f - kotlin.math.min(1f, kotlin.math.abs(pos - idx))
                Row(
                    Modifier.weight(1f).fillMaxHeight().clickable(
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null
                    ) { onTab(idx) },
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
                ) {
                    Text(l, color = androidx.compose.ui.graphics.lerp(AuraWhite, AuraBlack, t), fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                    val bc = badges.getOrElse(idx) { 0 }
                    if (bc > 0) {
                        Spacer(Modifier.width(5.dp))
                        Box(Modifier.height(17.dp).widthIn(min = 17.dp).clip(CircleShape).background(Color(0xFFEF4444)), contentAlignment = Alignment.Center) {
                            Text(if (bc > 99) "99+" else bc.toString(), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(horizontal = 4.dp))
                        }
                    }
                }
            }
        }
    }
}

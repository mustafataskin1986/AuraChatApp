package com.aurachat.app.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Yönetici e-postası: panel yalnızca bu hesapla açılır; asıl yetki kontrolü sunucuda (api/admin) yapılır */
private const val ADMIN_EMAIL = "mustafataskin1986@gmail.com"
private const val ADMIN_API = "https://aurachat-amber.vercel.app/api/admin"

fun isAdminAccount(): Boolean =
    FirebaseAuth.getInstance().currentUser?.email?.trim()?.equals(ADMIN_EMAIL, ignoreCase = true) == true

/** Parmak sayısı örüntüsü: 1, 1, 2, 1 (tek, tek, iki parmakla, tek) dokunuşu paneli açar. Dokunuşları tüketmez. */
fun Modifier.adminTapPattern(enabled: Boolean, onOpen: () -> Unit): Modifier =
    if (!enabled) this else this.pointerInput(Unit) {
        val seq = ArrayList<Int>()
        var last = 0L
        awaitEachGesture {
            val first = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            val start = System.currentTimeMillis()
            var maxP = 1
            var moved = false
            while (true) {
                val ev = awaitPointerEvent(PointerEventPass.Initial)
                val pressed = ev.changes.count { it.pressed }
                if (pressed > maxP) maxP = pressed
                if (ev.changes.any { (it.position - first.position).getDistance() > viewConfiguration.touchSlop * 2f }) moved = true
                if (pressed == 0) break
            }
            val now = System.currentTimeMillis()
            if (moved || now - start > 450) { seq.clear(); return@awaitEachGesture }
            if (seq.isNotEmpty() && now - last > 1500) seq.clear()
            last = now
            seq.add(maxP)
            while (seq.size > 4) seq.removeAt(0)
            if (seq == listOf(1, 1, 2, 1)) { seq.clear(); onOpen() }
        }
    }

private object AdminApi {
    suspend fun call(body: JSONObject): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val user = FirebaseAuth.getInstance().currentUser ?: return@withContext null
            val token = user.getIdToken(false).await().token ?: return@withContext null
            val c = URL(ADMIN_API).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer $token")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
            c.disconnect()
            JSONObject(txt).put("_code", code)
        } catch (e: Throwable) { null }
    }
}

private class AdminReport(val id: String, val reporter: String, val reported: String, val chatId: String, val isGroup: Boolean, val reason: String, val note: String, val at: Long)

private class AdminUser(val uid: String, val name: String, val email: String, val phone: String, val platform: String, val hasToken: Boolean, val lastSeen: Long)

private val AdPanel: Color get() = auraLc(0xFF111B21)
private val AdField: Color get() = auraLc(0xFF1F2C34)
private val AdGreen: Color get() = auraLc(0xFF22C55E)

@Composable
fun AdminPanelScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler { onBack() }
    var tab by remember { mutableStateOf(0) }
    var users by remember { mutableStateOf<List<AdminUser>?>(null) }
    var error by remember { mutableStateOf("") }
    val selected = remember { mutableStateListOf<String>() }
    var query by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("push") }
    var busy by remember { mutableStateOf(false) }
    var reports by remember { mutableStateOf<List<AdminReport>?>(null) }

    fun loadReports() {
        scope.launch {
            val r = AdminApi.call(JSONObject().put("action", "reports"))
            if (r == null || r.optInt("_code") != 200) { reports = emptyList(); return@launch }
            val arr: JSONArray = r.optJSONArray("reports") ?: JSONArray()
            reports = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                AdminReport(o.optString("id"), o.optString("reporterName"), o.optString("reportedName"), o.optString("chatId"), o.optBoolean("isGroup"), o.optString("reason"), o.optString("note"), o.optLong("at"))
            }
        }
    }

    fun load() {
        loadReports()
        error = ""
        users = null
        scope.launch {
            val r = AdminApi.call(JSONObject().put("action", "users"))
            if (r == null || r.optInt("_code") != 200) {
                error = r?.optString("error")?.ifBlank { null } ?: "Sunucuya ulaşılamadı"
                users = emptyList()
                return@launch
            }
            val arr: JSONArray = r.optJSONArray("users") ?: JSONArray()
            users = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                AdminUser(o.optString("uid"), o.optString("name"), o.optString("email"), o.optString("phone"), o.optString("platform"), o.optBoolean("hasToken"), o.optLong("lastSeen"))
            }
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text("Yönetici paneli", color = AuraWhite, fontSize = 20.sp, modifier = Modifier.padding(start = 6.dp).weight(1f))
            Text("Yenile", color = AdGreen, fontSize = 15.sp, modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { load() }.padding(horizontal = 12.dp, vertical = 8.dp))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Kişiler" to 0, "Bildirim gönder" to 1, "Şikayetler" to 2).forEach { (label, i) ->
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(if (tab == i) AdGreen else AdField).clickable { tab = i }
                        .padding(horizontal = 18.dp, vertical = 9.dp)
                ) { Text(label, color = if (tab == i) AuraBlack else AuraWhite, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
            }
        }
        Spacer(Modifier.height(10.dp))

        if (tab == 0) {
            AdminField(query, { query = it }, "Ara (ad, e-posta, telefon)", Modifier.padding(horizontal = 14.dp))
            val list = users
            if (list == null) {
                Text("Yükleniyor...", color = AuraMuted, modifier = Modifier.padding(20.dp))
            } else {
                if (error.isNotEmpty()) Text(error, color = auraLc(0xFFEF4444), modifier = Modifier.padding(16.dp))
                val q = query.trim().lowercase()
                val shown = list.filter { q.isEmpty() || it.name.lowercase().contains(q) || it.email.lowercase().contains(q) || it.phone.contains(q) }
                Text(
                    "${list.size} kişi • ${list.count { it.hasToken }} bildirim alabilir" + if (selected.isNotEmpty()) " • ${selected.size} seçili" else "",
                    color = AuraMuted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                val allOn = shown.isNotEmpty() && shown.all { selected.contains(it.uid) }
                Row(
                    Modifier.fillMaxWidth().clickable {
                        if (allOn) shown.forEach { selected.remove(it.uid) } else shown.forEach { if (!selected.contains(it.uid)) selected.add(it.uid) }
                    }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(24.dp).clip(CircleShape).background(if (allOn) AdGreen else Color.Transparent)
                            .border(2.dp, if (allOn) AdGreen else auraLc(0xFF6B7280), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { if (allOn) Icon(Icons.Default.Check, null, tint = AuraBlack, modifier = Modifier.size(16.dp)) }
                    Spacer(Modifier.width(14.dp))
                    Text("Herkes (${shown.size})", color = AuraWhite, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                }
                LazyColumn(Modifier.weight(1f)) {
                    items(shown, key = { it.uid }) { u ->
                        val on = selected.contains(u.uid)
                        Row(
                            Modifier.fillMaxWidth().clickable { if (on) selected.remove(u.uid) else selected.add(u.uid) }.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(24.dp).clip(CircleShape).background(if (on) AdGreen else Color.Transparent)
                                    .border(2.dp, if (on) AdGreen else auraLc(0xFF6B7280), CircleShape),
                                contentAlignment = Alignment.Center
                            ) { if (on) Icon(Icons.Default.Check, null, tint = AuraBlack, modifier = Modifier.size(16.dp)) }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(u.name.ifBlank { "(adsız)" }, color = AuraWhite, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    listOf(u.email, u.phone).filter { it.isNotBlank() }.joinToString(" • "),
                                    color = AuraMuted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    (if (u.hasToken) "Bildirim açık" else "Bildirim yok") + (if (u.platform.isNotBlank()) " • ${if (u.platform == "native") "Android" else u.platform}" else "") +
                                        (if (u.lastSeen > 0) " • son görülme: ${statusTimeLabel(u.lastSeen)}" else ""),
                                    color = if (u.hasToken) AdGreen else auraLc(0xFFF59E0B), fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        } else if (tab == 2) {
            val rl = reports
            if (rl == null) Text("Yükleniyor...", color = AuraMuted, modifier = Modifier.padding(20.dp))
            else if (rl.isEmpty()) Text("Şikayet yok", color = AuraMuted, modifier = Modifier.padding(20.dp))
            else LazyColumn(Modifier.weight(1f)) {
                items(rl, key = { it.id }) { rp ->
                    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp).clip(RoundedCornerShape(12.dp)).background(AdField).padding(14.dp)) {
                        Text((if (rp.isGroup) "Grup: " else "Kişi: ") + rp.reported.ifBlank { "(adsız)" }, color = AuraWhite, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        Text("Sebep: " + rp.reason, color = auraLc(0xFFF59E0B), fontSize = 14.sp, modifier = Modifier.padding(top = 3.dp))
                        if (rp.note.isNotBlank()) Text(rp.note, color = AuraWhite, fontSize = 14.sp, modifier = Modifier.padding(top = 3.dp))
                        Text("Şikayet eden: " + rp.reporter.ifBlank { "(adsız)" } + " • " + statusTimeLabel(rp.at), color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        Text(
                            "Çözüldü (listeden kaldır)", color = AdGreen, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp)).clickable {
                                scope.launch {
                                    AdminApi.call(JSONObject().put("action", "reportDone").put("id", rp.id))
                                    reports = reports?.filter { it.id != rp.id }
                                }
                            }.padding(vertical = 6.dp)
                        )
                    }
                }
            }
        } else {
            Column(Modifier.weight(1f).verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal = 14.dp)) {
                Text("Başlık", color = AuraMuted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
                AdminField(title, { if (it.length <= 100) title = it }, "Örn: Yeni sürüm yayında")
                Text("Metin", color = AuraMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
                AdminField(text, { if (it.length <= 400) text = it }, "Mesajınız", singleLine = false, minH = 110)
                Text("Gönderim şekli", color = AuraMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Kayan bildirim" to "push", "Uygulama içi" to "inapp").forEach { (l, m) ->
                        Box(
                            Modifier.clip(RoundedCornerShape(50)).background(if (mode == m) AdGreen else AdField).clickable { mode = m }
                                .padding(horizontal = 16.dp, vertical = 9.dp)
                        ) { Text(l, color = if (mode == m) AuraBlack else AuraWhite, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                    }
                }
                Text(
                    if (mode == "push") "Uygulama kapalıyken de telefonda üstten kayan bildirim olarak çıkar."
                    else "Sadece uygulaması o an açık olanlara üstten kayan bir kart olarak gösterilir.",
                    color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                )
                Text("Alıcı", color = AuraMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
                Text(
                    if (selected.isEmpty()) "Herkes (${users?.size ?: 0} kişi)" else "${selected.size} seçili kişi (Kişiler sekmesinden seç)",
                    color = AuraWhite, fontSize = 15.sp
                )
                Spacer(Modifier.height(22.dp))
                Box(
                    Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(50))
                        .background(if (busy || title.isBlank() || text.isBlank()) auraLc(0xFF374151) else AdGreen)
                        .clickable(enabled = !busy && title.isNotBlank() && text.isNotBlank()) {
                            busy = true
                            scope.launch {
                                val body = JSONObject().put("action", "send").put("title", title.trim()).put("body", text.trim()).put("mode", mode)
                                if (selected.isNotEmpty()) body.put("uids", JSONArray(selected.toList()))
                                val r = AdminApi.call(body)
                                busy = false
                                if (r != null && r.optInt("_code") == 200) {
                                    Toast.makeText(ctx, "${r.optInt("sent")} kişiye gönderildi" + (if (r.optInt("failed") > 0) ", ${r.optInt("failed")} başarısız" else ""), Toast.LENGTH_LONG).show()
                                    title = ""; text = ""
                                } else Toast.makeText(ctx, r?.optString("error")?.ifBlank { null } ?: "Gönderilemedi", Toast.LENGTH_LONG).show()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) { Text(if (busy) "Gönderiliyor..." else "Gönder", color = AuraBlack, fontSize = 17.sp, fontWeight = FontWeight.Medium) }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun AdminField(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier, singleLine: Boolean = true, minH: Int = 48) {
    Box(
        modifier.fillMaxWidth().heightIn(min = minH.dp).clip(RoundedCornerShape(12.dp)).background(AdField).padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        if (value.isEmpty()) Text(hint, color = AuraMuted, fontSize = 15.sp)
        AuraTextField(
            value = value, onValueChange = onChange, singleLine = singleLine,
            textStyle = TextStyle(color = AuraWhite, fontSize = 15.sp), cursorBrush = SolidColor(AuraWhite),
            modifier = Modifier.fillMaxWidth()
        )
    }
}


/** Uygulama açıkken yöneticiden gelen "uygulama içi" bildirimler */
object AdminBanner {
    val msg = mutableStateOf<Pair<String, String>?>(null)
    fun show(title: String, body: String) { msg.value = title to body }
}

@Composable
fun AdminBannerOverlay() {
    val m = AdminBanner.msg.value
    LaunchedEffect(m) { if (m != null) { delay(6000); if (AdminBanner.msg.value == m) AdminBanner.msg.value = null } }
    androidx.compose.animation.AnimatedVisibility(
        visible = m != null,
        enter = androidx.compose.animation.slideInVertically { -it } + androidx.compose.animation.fadeIn(),
        exit = androidx.compose.animation.slideOutVertically { -it } + androidx.compose.animation.fadeOut()
    ) {
        val shown = remember(m) { m }
        Box(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(auraLc(0xFF1F2C34))
                    .border(1.dp, auraLc(0xFF2E4048), RoundedCornerShape(16.dp))
                    .clickable { AdminBanner.msg.value = null }.padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(shown?.first ?: "", color = AuraWhite, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(shown?.second ?: "", color = auraLc(0xFFD1D5DB), fontSize = 14.sp, maxLines = 4, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
            }
        }
    }
}

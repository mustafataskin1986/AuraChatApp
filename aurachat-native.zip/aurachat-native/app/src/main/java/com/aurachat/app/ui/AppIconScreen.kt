package com.aurachat.app.ui

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.R

/** Ana ekran simgesi: activity-alias aç/kapat (0 = varsayılan, 1..8 = seçenekler) */
object AppIcon {
    const val COUNT = 8
    @Volatile var pending: Int = -1

    private fun alias(ctx: Context, n: Int) =
        ComponentName(ctx.packageName, "com.aurachat.app." + if (n == 0) "IconDefault" else "IconAlt$n")

    fun current(ctx: Context): Int {
        if (pending >= 0) return pending
        val pm = ctx.packageManager
        for (n in 0..COUNT) {
            val st = try { pm.getComponentEnabledSetting(alias(ctx, n)) } catch (e: Throwable) { continue }
            val on = st == PackageManager.COMPONENT_ENABLED_STATE_ENABLED ||
                (st == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && n == 0)
            if (on) return n
        }
        return 0
    }

    /** Bekleyen seçimi uygular (uygulamadan çıkarken ya da "Şimdi değiştir") */
    fun applyPending(ctx: Context) {
        val target = pending
        if (target < 0) return
        pending = -1
        try {
            val pm = ctx.packageManager
            pm.setComponentEnabledSetting(alias(ctx, target), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            for (n in 0..COUNT) {
                if (n == target) continue
                try {
                    pm.setComponentEnabledSetting(alias(ctx, n), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                } catch (e: Throwable) { com.aurachat.app.AuraLog.e("AppIconScreen", e) }
            }
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("AppIconScreen", e) }
    }

    /** İkonu hemen uygular ve uygulamayı yeniden açar */
    fun applyNowAndRestart(ctx: Context) {
        val target = pending
        if (target < 0) return
        val relaunch = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = alias(ctx, target)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        val pi = PendingIntent.getActivity(ctx, 9301, relaunch, PendingIntent.FLAG_CANCEL_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        try { am?.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 2000, pi) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("AppIconScreen", e) }
        applyPending(ctx)
        var c: Context? = ctx
        while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext
        (c as? android.app.Activity)?.finishAffinity()
        val app = ctx.applicationContext
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            try { am?.cancel(pi) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("AppIconScreen", e) }
            try { app.startActivity(relaunch) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("AppIconScreen", e) }
        }, 500)
    }
}

private fun resFor(n: Int): Int = when (n) {
    0 -> R.mipmap.ic_launcher
    1 -> R.mipmap.ic_alt_1
    2 -> R.mipmap.ic_alt_2
    3 -> R.mipmap.ic_alt_3
    4 -> R.mipmap.ic_alt_4
    5 -> R.mipmap.ic_alt_5
    6 -> R.mipmap.ic_alt_6
    7 -> R.mipmap.ic_alt_7
    else -> R.mipmap.ic_alt_8
}

private val IconAccent: Color get() = AuraUi.accentColor() ?: auraLc(0xFF22C55E)

@Composable
fun AppIconScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val currentIcon = remember { AppIcon.current(ctx) }
    var choice by remember { mutableIntStateOf(-1) }
    var left by remember { mutableIntStateOf(10) }

    BackHandler { onBack() }

    fun applyChoice() {
        val n = choice
        choice = -1
        if (n < 0) return
        AppIcon.pending = n
        AppIcon.applyNowAndRestart(ctx)
    }

    androidx.compose.runtime.LaunchedEffect(choice) {
        if (choice >= 0) {
            left = 10
            while (left > 0) {
                kotlinx.coroutines.delay(1000)
                left--
            }
            applyChoice()
        }
    }

    Box(Modifier.fillMaxSize().background(AuraBlack)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraMuted) }
                Text("Uygulama ikonu", color = AuraWhite, fontSize = 20.sp, modifier = Modifier.padding(start = 12.dp))
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(auraLc(0xFF1F2937)))
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 20.dp)) {
                Text(
                    "Ana ekranda görünecek uygulama ikonunu seç.",
                    color = AuraMuted, fontSize = 16.sp, lineHeight = 23.sp, modifier = Modifier.padding(bottom = 20.dp)
                )
                for (row in 0..2) {
                    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        for (col in 0..2) {
                            val n = row * 3 + col
                            if (n > AppIcon.COUNT) {
                                Box(Modifier.size(100.dp))
                            } else {
                                IconTile(n, (if (choice >= 0) choice else currentIcon) == n) {
                                    if (n == currentIcon) {
                                        Toast.makeText(ctx, "Bu ikon zaten seçili", Toast.LENGTH_SHORT).show()
                                    } else {
                                        choice = n
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (choice >= 0) {
        AuraAlertDialog(
            onDismissRequest = { choice = -1 },
            containerColor = auraLc(0xFF111111),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Uygulama ANA EKRAN simgesi değişecek!!!",
                        color = AuraWhite, fontSize = 18.sp, lineHeight = 25.sp, modifier = Modifier.weight(1f)
                    )
                    Box(
                        Modifier.padding(start = 12.dp).size(40.dp).clip(CircleShape).border(2.dp, IconAccent, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text(left.toString(), color = IconAccent, fontSize = 18.sp) }
                }
            },
            text = {
                Text("Uygulama kısa süre kapanıp yeniden açılacak.", color = AuraMuted, fontSize = 14.sp)
            },
            confirmButton = {
                TextButton(onClick = { applyChoice() }) { Text("Şimdi değiştir", color = IconAccent, fontSize = 17.sp) }
            },
            dismissButton = {
                TextButton(onClick = { choice = -1 }) { Text("Vazgeç", color = IconAccent, fontSize = 17.sp) }
            }
        )
    }
}

@Composable
private fun IconTile(n: Int, selected: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val bmp = remember(n) { BitmapFactory.decodeResource(ctx.resources, resFor(n)) }
    // Köşe pikselinden arka plan rengi (şeffafsa şeffaf)
    val bg = remember(n) {
        try {
            val px = bmp.getPixel(2, 2)
            if (android.graphics.Color.alpha(px) < 255) Color.Transparent else Color(px)
        } catch (e: Throwable) { Color.Transparent }
    }
    Column(Modifier.size(width = 100.dp, height = 124.dp).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(100.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(78.dp).clip(RoundedCornerShape(20.dp)).background(bg)
                    .then(if (selected) Modifier.border(3.dp, IconAccent, RoundedCornerShape(20.dp)) else Modifier),
                contentAlignment = Alignment.Center
            ) {
                Image(bmp.asImageBitmap(), null, contentScale = ContentScale.Fit, colorFilter = auraImageFilter(), modifier = Modifier.size(65.dp))
            }
            if (selected) {
                Box(
                    Modifier.align(Alignment.BottomEnd).padding(end = 6.dp, bottom = 8.dp).size(24.dp).clip(CircleShape).background(IconAccent),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Check, null, tint = AuraWhite, modifier = Modifier.size(14.dp)) }
            }
        }
        Text(if (n == 0) "Varsayılan" else n.toString(), color = AuraMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

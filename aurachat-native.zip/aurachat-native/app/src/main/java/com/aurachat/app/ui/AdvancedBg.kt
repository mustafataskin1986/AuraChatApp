package com.aurachat.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/*
 * GELİŞMİŞ ARKA PLAN (gradyan / resim) — tamamen ayrı modül.
 * Kaldırmak için: bu dosyayı sil + ChatThemes.kt'deki 3 "AdvBg" satırını + ThemePanel.kt'deki "AdvBg" satırlarını sil.
 * Yalnız varsayılan (tema seçilmemiş) sohbetlere uygulanır; sohbete özel tema seçilmişse o kazanır.
 */

/** type: 0 doğrusal, 1 dairesel, 2 konik. angle: CSS açısı (0 = yukarı, 90 = sağa, 180 = aşağı). stops: eşit aralıklı renkler */
class AdvSpec(val type: Int, val angle: Int, val colors: List<Int>) {
    val stops: Array<Pair<Float, Color>>
        get() = colors.mapIndexed { i, c -> (if (colors.size <= 1) 0f else i / (colors.size - 1f)) to Color(0xFF000000.toInt() or c) }.toTypedArray()
}

internal fun DrawScope.drawAdv(s: AdvSpec) {
    val st = s.stops
    if (st.size < 2) { drawRect(st.firstOrNull()?.second ?: Color.Black); return }
    val brush = when (s.type) {
        1 -> Brush.radialGradient(*st, center = Offset(size.width / 2f, size.height * 0.3f), radius = max(size.width, size.height) * 0.8f)
        2 -> Brush.sweepGradient(*st, center = Offset(size.width / 2f, size.height / 2f))
        else -> {
            val rad = Math.toRadians(s.angle.toDouble())
            val dx = sin(rad).toFloat(); val dy = -cos(rad).toFloat()
            val half = (abs(size.width * dx) + abs(size.height * dy)) / 2f
            val c = Offset(size.width / 2f, size.height / 2f)
            Brush.linearGradient(*st, start = Offset(c.x - dx * half, c.y - dy * half), end = Offset(c.x + dx * half, c.y + dy * half))
        }
    }
    drawRect(brush)
}

internal fun DrawScope.drawCover(img: ImageBitmap) {
    val w = size.width; val h = size.height
    val scale = max(w / img.width, h / img.height)
    val srcW = (w / scale).toInt().coerceIn(1, img.width)
    val srcH = (h / scale).toInt().coerceIn(1, img.height)
    drawImage(img, srcOffset = IntOffset((img.width - srcW) / 2, (img.height - srcH) / 2), srcSize = IntSize(srcW, srcH), dstSize = IntSize(w.toInt().coerceAtLeast(1), h.toInt().coerceAtLeast(1)))
}

object AdvBg {
    /** Değişince sohbet temasını yeniden çözen sayaç */
    var version by mutableIntStateOf(0)
        private set
    private var imgCache: ImageBitmap? = null
    private var imgStamp = 0L

    private fun sp(ctx: Context) = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)
    private fun imgFile(ctx: Context) = File(ctx.filesDir, "adv_bg.jpg")

    /** "", "grad" ya da "image" */
    fun kind(ctx: Context): String = sp(ctx).getString("adv_kind", "") ?: ""

    fun spec(ctx: Context): AdvSpec? {
        val p = sp(ctx)
        val cs = (p.getString("adv_colors", "") ?: "").split(",").mapNotNull { it.trim().toIntOrNull(16) }
        if (cs.size < 2) return null
        return AdvSpec(p.getInt("adv_type", 0), p.getInt("adv_angle", 180), cs)
    }

    fun image(ctx: Context): ImageBitmap? {
        val f = imgFile(ctx)
        if (!f.exists()) return null
        if (imgCache != null && imgStamp == f.lastModified()) return imgCache
        return try { BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap().also { imgCache = it; imgStamp = f.lastModified() } } catch (e: Throwable) { null }
    }

    fun applyGrad(ctx: Context, s: AdvSpec) {
        sp(ctx).edit().putString("adv_kind", "grad").putInt("adv_type", s.type).putInt("adv_angle", s.angle)
            .putString("adv_colors", s.colors.joinToString(",") { String.format("%06X", it and 0xFFFFFF) }).apply()
        version++
    }

    fun applyImage(ctx: Context, bmp: Bitmap) {
        try {
            java.io.FileOutputStream(imgFile(ctx)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            sp(ctx).edit().putString("adv_kind", "image").apply()
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("AdvBg", e) }
        version++
    }

    fun clear(ctx: Context) {
        sp(ctx).edit().putString("adv_kind", "").apply()
        try { imgFile(ctx).delete() } catch (e: Throwable) { }
        imgCache = null
        version++
    }

    /** ChatThemes.resolve buradan sorar: açıksa gradyan / resimli tema döner, kapalıysa null */
    fun resolved(ctx: Context, out: Color, bright: Float): ResolvedTheme? {
        @Suppress("UNUSED_VARIABLE") val v = version
        return when (kind(ctx)) {
            "grad" -> spec(ctx)?.let { ResolvedTheme("advgrad", null, null, out, false, bright, adv = it) }
            "image" -> image(ctx)?.let { ResolvedTheme("advimg", null, it, out, false, bright) }
            else -> null
        }
    }

    /** Galeriden seçilen resmi en çok 1600px'e küçültüp açar */
    fun decode(ctx: Context, uri: Uri): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var ss = 1
        while (max(o.outWidth, o.outHeight) / ss > 1600) ss *= 2
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = ss }) }
    } catch (e: Throwable) { null }
}

private val advDefault = listOf(0x0A1016, 0x1B3A4B, 0x22C55E)

/** Gelişmiş arka plan sayfası (tam ekran). onApplied: Uygula / Kaldır sonrası çağrılır */
@Composable
fun AdvancedBgPage(onClose: () -> Unit, onApplied: () -> Unit) {
    val ctx = LocalContext.current
    val saved = remember { AdvBg.spec(ctx) }
    var type by remember { mutableIntStateOf(saved?.type ?: 0) }
    var angle by remember { mutableIntStateOf(saved?.angle ?: 180) }
    val colors = remember { mutableStateListOf<Int>().apply { addAll(saved?.colors ?: advDefault) } }
    var useImage by remember { mutableStateOf(AdvBg.kind(ctx) == "image") }
    var imgBmp by remember { mutableStateOf<Bitmap?>(null) }
    val imgShown: ImageBitmap? = if (useImage) (imgBmp?.asImageBitmap() ?: AdvBg.image(ctx)) else null
    var bulk by remember { mutableStateOf("") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val b = AdvBg.decode(ctx, uri)
            if (b != null) { imgBmp = b; useImage = true } else Toast.makeText(ctx, "Resim açılamadı", Toast.LENGTH_SHORT).show()
        }
    }
    val dark = !AuraUi.light
    val page = if (dark) Color.Black else Color.White
    val spec = AdvSpec(type, angle, colors.toList())

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Column(Modifier.fillMaxSize().background(page).statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(54.dp).padding(start = 0.5.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Spacer(Modifier.width(8.dp))
                Text("Gelişmiş arka plan", color = AuraWhite, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // önizleme: sohbet ekranı gibi
                val shape = RoundedCornerShape(20.dp)
                Box(
                    Modifier.fillMaxWidth().height(260.dp).clip(shape).border(1.dp, AuraMuted.copy(alpha = 0.3f), shape)
                        .drawBehind { if (imgShown != null) drawCover(imgShown) else drawAdv(spec) }
                ) {
                    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.Bottom)) {
                        Text("Selam, akşam görüşürüz", color = Color.White, fontSize = 14.sp, modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xD91E1E1E)).padding(horizontal = 12.dp, vertical = 8.dp))
                        Text("Tamam, 19:00 uygun mu?", color = Color.White, fontSize = 14.sp, modifier = Modifier.align(Alignment.End).clip(RoundedCornerShape(12.dp)).background(Color(0xEB005C4B)).padding(horizontal = 12.dp, vertical = 8.dp))
                    }
                }

                // tür seçimi
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Doğrusal", "Dairesel", "Konik").forEachIndexed { i, n ->
                        val on = !useImage && type == i
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(if (on) AuraGreen else AuraMuted.copy(alpha = 0.14f))
                                .clickable { useImage = false; type = i }.padding(vertical = 11.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(n, color = if (on) Color(0xFF07140D) else AuraWhite, fontSize = 14.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal) }
                    }
                }
                if (!useImage && type == 0) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Açı", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text("$angle°", color = AuraMuted, fontSize = 13.sp)
                    }
                    GradBar(angle / 360f, listOf(Color(0xFF3A3A3A), Color(0xFFBDBDBD))) { angle = Math.round(it * 360f) }
                }

                if (!useImage) {
                    // toplu renk kodu girişi
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(AuraMuted.copy(alpha = 0.14f)).padding(horizontal = 12.dp, vertical = 12.dp)) {
                            if (bulk.isEmpty()) Text("#0A1016, #1B3A4B, #22C55E", color = AuraMuted, fontSize = 14.sp)
                            BasicTextField(
                                value = bulk, onValueChange = { bulk = it }, singleLine = true,
                                textStyle = TextStyle(color = AuraWhite, fontSize = 14.sp), cursorBrush = SolidColor(AuraGreen),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Box(
                            Modifier.clip(RoundedCornerShape(12.dp)).background(AuraMuted.copy(alpha = 0.14f)).clickable {
                                val ok = bulk.split(Regex("[\\s,;]+")).map { it.trim().removePrefix("#") }.filter { Regex("[0-9a-fA-F]{6}").matches(it) }.map { it.toInt(16) }
                                if (ok.size >= 2) { colors.clear(); colors.addAll(ok); bulk = "" } else Toast.makeText(ctx, "En az 2 geçerli renk kodu yaz", Toast.LENGTH_SHORT).show()
                            }.padding(horizontal = 14.dp, vertical = 12.dp)
                        ) { Text("AL", color = AuraGreen, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
                    }
                    // tek tek renkler
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(AuraMuted.copy(alpha = 0.12f)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        colors.forEachIndexed { i, c ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(30.dp).clip(CircleShape).background(Color(0xFF000000.toInt() or c)).border(1.dp, AuraMuted.copy(alpha = 0.4f), CircleShape))
                                Spacer(Modifier.width(12.dp))
                                Text("Renk ${i + 1}", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                                HexField(c) { colors[i] = it and 0xFFFFFF }
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "×", color = if (colors.size > 2) AuraWhite else AuraMuted.copy(alpha = 0.35f), fontSize = 22.sp,
                                    modifier = Modifier.clickable(enabled = colors.size > 2, interactionSource = remember { MutableInteractionSource() }, indication = null) { colors.removeAt(i) }.padding(horizontal = 6.dp)
                                )
                            }
                        }
                        Text(
                            "+ Renk ekle", color = AuraGreen, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { colors.add(colors.last()) }.padding(vertical = 4.dp)
                        )
                    }
                }

                // resim yükle
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (useImage) AuraGreen.copy(alpha = 0.25f) else AuraMuted.copy(alpha = 0.14f))
                        .clickable { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }.padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center
                ) { Text(if (useImage) "Resmi değiştir" else "Resim yükle", color = AuraWhite, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                Text("Yalnız tema seçilmemiş sohbetlerde görünür. Sohbete özel tema seçtiysen o geçerli.", color = AuraMuted, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(AuraMuted.copy(alpha = 0.2f)))
            Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.weight(1f).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { AdvBg.clear(ctx); onApplied() }.padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) { Text("KALDIR", color = AuraMuted, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
                Box(
                    Modifier.weight(1f).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        if (useImage) {
                            val b = imgBmp
                            if (b != null) { AdvBg.applyImage(ctx, b); onApplied() }
                            else if (AdvBg.kind(ctx) == "image") onApplied()
                            else Toast.makeText(ctx, "Önce resim seç", Toast.LENGTH_SHORT).show()
                        } else { AdvBg.applyGrad(ctx, spec); onApplied() }
                    }.padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) { Text("UYGULA", color = AuraGreen, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
    }
}

package com.aurachat.app

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Sessizce yutulan hataları dosyaya yazar; Menü → "Hata kayıtları" ekranında görünür. */
object AuraLog {
    private var file: File? = null
    private var app: Context? = null
    private var lastNotif = 0L
    private val lock = Any()
    private var lastKey = ""
    private var lastAt = 0L
    private const val MAX = 120_000

    fun init(ctx: Context) {
        app = ctx.applicationContext
        file = File(ctx.applicationContext.filesDir, "aura_errors.txt")
    }

    fun e(tag: String, t: Throwable, note: String = "") {
        if (t is kotlinx.coroutines.CancellationException) return
        try {
            val f = file ?: return
            val key = tag + t.javaClass.name + (t.message ?: "")
            val now = System.currentTimeMillis()
            synchronized(lock) {
                if (key == lastKey && now - lastAt < 5000) return
                lastKey = key; lastAt = now
                val ts = SimpleDateFormat("dd.MM HH:mm:ss", Locale.US).format(Date(now))
                val top = t.stackTrace.take(4).joinToString("\n   ") { "${it.fileName}:${it.lineNumber} ${it.methodName}" }
                val line = "[$ts] $tag${if (note.isNotEmpty()) " ($note)" else ""}\n${t.javaClass.simpleName}: ${t.message ?: ""}\n   $top\n\n"
                var old = if (f.exists()) f.readText() else ""
                if (old.length > MAX) old = old.takeLast(MAX / 2)
                f.writeText(old + line)
            }
            android.util.Log.w("AuraLog", "$tag: $t")
            notifyAdmin(tag, t)
        } catch (_: Throwable) {}
    }

    fun read(): String = try { file?.takeIf { it.exists() }?.readText().orEmpty() } catch (_: Throwable) { "" }
    fun clear() { try { file?.delete() } catch (_: Throwable) {} }

    /** Sadece yönetici hesapta: yeni hata olunca bildirim (dokununca hata kayıtları açılır). Dakikada en fazla bir kez. */
    private fun notifyAdmin(tag: String, t: Throwable) {
        val c = app ?: return
        try {
            val now = System.currentTimeMillis()
            if (now - lastNotif < 60_000) return
            if (!com.aurachat.app.ui.isAdminAccount()) return
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                androidx.core.content.ContextCompat.checkSelfPermission(c, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
            lastNotif = now
            val nm = c.getSystemService(android.app.NotificationManager::class.java)
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(android.app.NotificationChannel("aurachat-errors", "Hata uyarıları", android.app.NotificationManager.IMPORTANCE_DEFAULT))
            }
            val open = android.content.Intent(c, MainActivity::class.java)
                .putExtra("openErrors", true)
                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP)
            val pi = android.app.PendingIntent.getActivity(c, 9001, open, android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
            val n = androidx.core.app.NotificationCompat.Builder(c, "aurachat-errors")
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("AuraChat hata kaydı")
                .setContentText("$tag: ${t.javaClass.simpleName} ${t.message ?: ""}".take(120))
                .setContentIntent(pi).setAutoCancel(true).build()
            nm.notify(9001, n)
        } catch (_: Throwable) {}
    }
}

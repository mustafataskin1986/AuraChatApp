package com.aurachat.app.ui

import android.Manifest
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.File

private fun findOwner(c: Context): LifecycleOwner? {
    var x: Context? = c
    while (x != null) {
        if (x is LifecycleOwner) return x
        x = (x as? ContextWrapper)?.baseContext
    }
    return null
}

/**
 * WhatsApp tarzı uygulama içi kamera: üstte kapat + flaş, altta galeri şeridi (çoklu seçim),
 * yeşil onay (seçilen sayısıyla), deklanşör, galeri, kamera çevirme, Video / Fotoğraf.
 * Fotoğraf çekince ya da onaya basınca seçilenlerle birlikte [onDone] çağrılır.
 */
@Composable
fun ChatCameraScreen(
    accent: Color,
    onClose: () -> Unit,
    onVideo: () -> Unit,
    onGallery: () -> Unit,
    onDone: (List<Uri>) -> Unit
) {
    val ctx = LocalContext.current
    var hasPerm by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        hasPerm = ok
        if (!ok) { Toast.makeText(ctx, "Kamera izni gerekli", Toast.LENGTH_SHORT).show(); onClose() }
    }
    LaunchedEffect(Unit) { if (!hasPerm) permLauncher.launch(Manifest.permission.CAMERA) }
    BackHandler { onClose() }

    var front by remember { mutableStateOf(false) }
    var flash by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var capture by remember { mutableStateOf<ImageCapture?>(null) }
    var busy by remember { mutableStateOf(false) }
    val previewView = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }
    val owner = remember { findOwner(ctx) }

    DisposableEffect(hasPerm, front) {
        var prov: ProcessCameraProvider? = null
        if (hasPerm && owner != null) {
            val fut = ProcessCameraProvider.getInstance(ctx)
            fut.addListener({
                try {
                    val p = fut.get()
                    prov = p
                    val pv = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                    val ic = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .setFlashMode(ImageCapture.FLASH_MODE_OFF)
                        .build()
                    p.unbindAll()
                    p.bindToLifecycle(owner, if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA, pv, ic)
                    capture = ic
                } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatCamera", e) }
            }, ContextCompat.getMainExecutor(ctx))
        }
        onDispose { try { prov?.unbindAll() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatCamera", e) }; capture = null }
    }
    LaunchedEffect(flash, capture) { capture?.flashMode = if (flash) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF }

    fun shoot() {
        val ic = capture ?: return
        if (busy) return
        busy = true
        val dir = File(ctx.cacheDir, "camera").also { it.mkdirs() }
        val f = File(dir, "shot_${System.currentTimeMillis()}.jpg")
        ic.takePicture(ImageCapture.OutputFileOptions.Builder(f).build(), ContextCompat.getMainExecutor(ctx), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) { busy = false; onDone(selected + Uri.fromFile(f)) }
            override fun onError(e: ImageCaptureException) {
                busy = false
                com.aurachat.app.AuraLog.e("ChatCamera", e)
                Toast.makeText(ctx, "Fotoğraf çekilemedi", Toast.LENGTH_SHORT).show()
            }
        })
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ previewView }, Modifier.fillMaxSize())

        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(CircleShape).background(Color(0x66000000)).clickable { onClose() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Close, "Kapat", tint = Color.White)
            }
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(48.dp).clip(CircleShape).background(Color(0x66000000)).clickable { flash = !flash }, contentAlignment = Alignment.Center) {
                Icon(if (flash) Icons.Default.FlashOn else Icons.Default.FlashOff, "Flaş", tint = Color.White)
            }
        }

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding()) {
            if (selected.isNotEmpty()) {
                Row(Modifier.fillMaxWidth().padding(end = 14.dp, bottom = 8.dp), horizontalArrangement = Arrangement.End) {
                    Box(Modifier.size(62.dp).clip(CircleShape).background(accent).clickable { onDone(selected) }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Check, "Tamam", tint = Color.White, modifier = Modifier.size(32.dp))
                        Text("${selected.size}", color = Color.White, fontSize = 15.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(end = 9.dp, bottom = 7.dp))
                    }
                }
            }
            GalleryStrip(
                accent = accent, maxPick = 5, selected = selected, onSelected = { selected = it },
                modifier = Modifier.height(96.dp), grid = false
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).clip(CircleShape).background(Color(0x66000000)).clickable { onGallery() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.PhotoLibrary, "Galeri", tint = Color.White)
                }
                Spacer(Modifier.weight(1f))
                Box(Modifier.size(76.dp).clip(CircleShape).border(5.dp, Color.White, CircleShape).padding(7.dp).clip(CircleShape).background(Color.White).clickable { shoot() })
                Spacer(Modifier.weight(1f))
                Box(Modifier.size(54.dp).clip(CircleShape).background(Color(0x66000000)).clickable { front = !front }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.FlipCameraAndroid, "Kamerayı çevir", tint = Color.White)
                }
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Text("Video", color = Color.White, fontSize = 18.sp, modifier = Modifier.clip(RoundedCornerShape(24.dp)).clickable { onVideo() }.padding(horizontal = 18.dp, vertical = 10.dp))
                Spacer(Modifier.size(8.dp))
                Text("Fotoğraf", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.clip(RoundedCornerShape(24.dp)).background(Color(0xFF1B1F23)).padding(horizontal = 18.dp, vertical = 10.dp))
            }
        }
    }
}

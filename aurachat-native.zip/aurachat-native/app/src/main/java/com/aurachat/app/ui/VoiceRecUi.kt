package com.aurachat.app.ui

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.VoiceRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.PI
import kotlin.math.sin

/** Kayıt başlat / duraklat / sil kısa sesleri (kodla üretilir, dosya gerekmez) */
object RecSounds {
    private fun tone(freqs: List<Pair<Int, Int>>, vol: Float = 0.5f) {
        Thread {
            try {
                val sr = 22050
                val total = freqs.sumOf { it.second } * sr / 1000
                val pcm = ShortArray(total)
                var pos = 0
                var phase = 0.0
                for ((f, ms) in freqs) {
                    val n = ms * sr / 1000
                    for (i in 0 until n) {
                        val env = minOf(1f, minOf(i, n - 1 - i) / (sr * 0.008f))
                        phase += 2 * PI * f / sr
                        pcm[pos++] = (sin(phase) * 32767 * vol * env).toInt().toShort()
                    }
                }
                val at = AudioTrack(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
                    AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
                    total * 2, AudioTrack.MODE_STATIC, AudioManager.AUDIO_SESSION_ID_GENERATE
                )
                at.write(pcm, 0, total)
                at.play()
                Thread.sleep((total * 1000L / sr) + 80)
                at.release()
            } catch (e: Throwable) {
                com.aurachat.app.AuraLog.e("RecSounds", e)
            }
        }.start()
    }

    fun start() = tone(listOf(660 to 70, 880 to 90))
    fun pause() = tone(listOf(700 to 70, 520 to 90))
    fun delete() = tone(listOf(520 to 70, 400 to 70, 280 to 110))
}

/** Duraklatılmış kaydın önizleme oynatıcısı */
object RecPreview {
    var playing by mutableStateOf(false)
    var posMs by androidx.compose.runtime.mutableIntStateOf(0)
    var durMs by androidx.compose.runtime.mutableIntStateOf(0)
    private var mp: MediaPlayer? = null
    private var path: String? = null

    private fun ensure(f: File): MediaPlayer? {
        val cur = mp
        if (cur != null && path == f.absolutePath) return cur
        release()
        return try {
            val p = MediaPlayer()
            p.setDataSource(f.absolutePath)
            p.prepare()
            p.setOnCompletionListener { playing = false; posMs = 0; try { it.seekTo(0) } catch (ignored: Throwable) { } }
            mp = p
            path = f.absolutePath
            durMs = p.duration
            posMs = 0
            p
        } catch (e: Throwable) {
            release()
            null
        }
    }

    fun toggle(f: File) {
        val p = ensure(f) ?: return
        try {
            if (playing) { p.pause(); playing = false } else { p.start(); playing = true }
        } catch (e: Throwable) { playing = false }
    }

    fun seek(f: File, frac: Float) {
        val p = ensure(f) ?: return
        try {
            val t = (p.duration * frac.coerceIn(0f, 1f)).toInt()
            p.seekTo(t)
            posMs = t
        } catch (ignored: Throwable) { }
    }

    fun tick() {
        val p = mp ?: return
        if (playing) try { posMs = p.currentPosition } catch (ignored: Throwable) { }
    }

    fun release() {
        val p = mp
        mp = null
        path = null
        if (p != null) {
            try { p.stop() } catch (ignored: Throwable) { }
            try { p.release() } catch (ignored: Throwable) { }
        }
        playing = false
        posMs = 0
        durMs = 0
    }
}

/** "1" simgeli tek dinlemelik düğmesi */
@Composable
fun RecOnceToggle(on: Boolean, accent: Color, onClick: () -> Unit) {
    val c = if (on) accent else Color(0xFF9AA5AD)
    Box(
        Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(24.dp).clip(CircleShape).background(if (on) accent else Color.Transparent).border(2.dp, c, CircleShape),
            contentAlignment = Alignment.Center
        ) { Text("1", color = if (on) Color.White else c, fontSize = 13.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }
    }
}

/** Duraklatılmışken: oynat/duraklat düğmesi + kaydırılabilir dalga formu + süre */
@Composable
fun RecPausedBar(recorder: VoiceRecorder, amps: List<Float>, totalSec: Int, accent: Color, modifier: Modifier = Modifier) {
    var file by remember { mutableStateOf<File?>(null) }
    var drag by remember { mutableFloatStateOf(-1f) }
    LaunchedEffect(Unit) { file = withContext(Dispatchers.IO) { recorder.previewFile() } }
    DisposableEffect(Unit) { onDispose { RecPreview.release() } }
    LaunchedEffect(RecPreview.playing) {
        while (RecPreview.playing) { RecPreview.tick(); delay(60) }
    }
    val total = if (RecPreview.durMs > 0) RecPreview.durMs else totalSec * 1000
    val frac = if (drag >= 0f) drag else if (total > 0) (RecPreview.posMs.toFloat() / total).coerceIn(0f, 1f) else 0f
    val shownSec = if (drag >= 0f || RecPreview.posMs > 0) (frac * total / 1000f).toInt() else totalSec
    val barCol = Color(0xFF8696A0)
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).clickable { file?.let { RecPreview.toggle(it) } },
            contentAlignment = Alignment.Center
        ) {
            Icon(if (RecPreview.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(32.dp))
        }
        Canvas(
            Modifier.weight(1f).fillMaxHeight()
                .pointerInput(file) {
                    detectTapGestures { o ->
                        val fr = (o.x / size.width).coerceIn(0f, 1f)
                        file?.let { RecPreview.seek(it, fr) }
                    }
                }
                .pointerInput(file) {
                    detectHorizontalDragGestures(
                        onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                        onDragEnd = { file?.let { RecPreview.seek(it, drag) }; drag = -1f },
                        onDragCancel = { drag = -1f },
                        onHorizontalDrag = { c, _ ->
                            drag = (c.position.x / size.width).coerceIn(0f, 1f)
                            file?.let { RecPreview.seek(it, drag) }
                        }
                    )
                }
        ) {
            val step = 6.dp.toPx()
            val bw = 3.dp.toPx()
            val n = (size.width / step).toInt().coerceAtLeast(1)
            val cy = size.height / 2f
            for (i in 0 until n) {
                val a = (i * amps.size) / n
                val b = (((i + 1) * amps.size) / n).coerceAtLeast(a + 1).coerceAtMost(amps.size)
                var v = 0f
                for (k in a until b) if (k < amps.size && amps[k] > v) v = amps[k]
                val x = i * step + bw / 2f
                val h = (4.dp.toPx() + v * (size.height - 4.dp.toPx())).coerceAtMost(size.height)
                val played = (i + 0.5f) / n <= frac
                drawLine(if (played) Color.White else barCol, Offset(x, cy - h / 2f), Offset(x, cy + h / 2f), bw, StrokeCap.Round)
            }
            drawCircle(accent, 7.dp.toPx(), Offset((frac * size.width).coerceIn(7.dp.toPx(), size.width - 7.dp.toPx()), cy))
        }
        Text(
            "%d:%02d".format(shownSec / 60, shownSec % 60),
            color = Color.White, fontSize = 18.sp, modifier = Modifier.width(52.dp).padding(start = 8.dp)
        )
    }
}

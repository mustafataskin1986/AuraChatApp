package com.aurachat.app.ui

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.VoiceRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.PI
import kotlin.math.sin

/** Kayıt başlat / duraklat / sil kısa sesleri (kodla üretilir, dosya gerekmez) */
object RecSounds {
    private fun tone(freqs: List<Pair<Int, Int>>, vol: Float = 0.5f) {
        Thread {
            try {
                val sr = 22050
                val total = freqs.sumOf { it.second } * sr / 1000
                val pcm = ShortArray(total)
                var pos = 0
                var phase = 0.0
                for ((f, ms) in freqs) {
                    val n = ms * sr / 1000
                    for (i in 0 until n) {
                        val env = minOf(1f, minOf(i, n - 1 - i) / (sr * 0.008f))
                        phase += 2 * PI * f / sr
                        pcm[pos++] = (sin(phase) * 32767 * vol * env).toInt().toShort()
                    }
                }
                val at = AudioTrack(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
                    AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
                    total * 2, AudioTrack.MODE_STATIC, AudioManager.AUDIO_SESSION_ID_GENERATE
                )
                at.write(pcm, 0, total)
                at.play()
                Thread.sleep((total * 1000L / sr) + 80)
                at.release()
            } catch (e: Throwable) {
                com.aurachat.app.AuraLog.e("RecSounds", e)
            }
        }.start()
    }

    fun start() = tone(listOf(660 to 70, 880 to 90))
    fun pause() = tone(listOf(700 to 70, 520 to 90))
    fun delete() = tone(listOf(520 to 70, 400 to 70, 280 to 110))
}

/** Duraklatılmış kaydın önizleme oynatıcısı */
object RecPreview {
    var playing by mutableStateOf(false)
    var posMs by androidx.compose.runtime.mutableIntStateOf(0)
    var durMs by androidx.compose.runtime.mutableIntStateOf(0)
    private var mp: MediaPlayer? = null
    private var path: String? = null

    private fun ensure(f: File): MediaPlayer? {
        val cur = mp
        if (cur != null && path == f.absolutePath) return cur
        release()
        return try {
            val p = MediaPlayer()
            p.setDataSource(f.absolutePath)
            p.prepare()
            p.setOnCompletionListener { playing = false; posMs = 0; try { it.seekTo(0) } catch (ignored: Throwable) { } }
            mp = p
            path = f.absolutePath
            durMs = p.duration
            posMs = 0
            p
        } catch (e: Throwable) {
            release()
            null
        }
    }

    fun toggle(f: File) {
        val p = ensure(f) ?: return
        try {
            if (playing) { p.pause(); playing = false } else { p.start(); playing = true }
        } catch (e: Throwable) { playing = false }
    }

    fun seek(f: File, frac: Float) {
        val p = ensure(f) ?: return
        try {
            val t = (p.duration * frac.coerceIn(0f, 1f)).toInt()
            p.seekTo(t)
            posMs = t
        } catch (ignored: Throwable) { }
    }

    fun tick() {
        val p = mp ?: return
        if (playing) try { posMs = p.currentPosition } catch (ignored: Throwable) { }
    }

    fun release() {
        val p = mp
        mp = null
        path = null
        if (p != null) {
            try { p.stop() } catch (ignored: Throwable) { }
            try { p.release() } catch (ignored: Throwable) { }
        }
        playing = false
        posMs = 0
        durMs = 0
    }
}

/** "1" simgeli tek dinlemelik düğmesi */
@Composable
fun RecOnceToggle(on: Boolean, accent: Color, onClick: () -> Unit) {
    val c = if (on) accent else Color(0xFF9AA5AD)
    Box(
        Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(26.dp).clip(CircleShape).background(if (on) accent else Color.Transparent).border(2.2.dp, c, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "1", color = if (on) Color.White else c, fontSize = 16.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                style = androidx.compose.ui.text.TextStyle(
                    platformStyle = androidx.compose.ui.text.PlatformTextStyle(includeFontPadding = false),
                    lineHeightStyle = androidx.compose.ui.text.style.LineHeightStyle(
                        androidx.compose.ui.text.style.LineHeightStyle.Alignment.Center,
                        androidx.compose.ui.text.style.LineHeightStyle.Trim.Both
                    )
                )
            )
        }
    }
}

/** Duraklatılmışken: oynat/duraklat düğmesi + kaydırılabilir dalga formu + süre */
@Composable
fun RecPausedBar(recorder: VoiceRecorder, amps: List<Float>, totalSec: Int, accent: Color, modifier: Modifier = Modifier) {
    var file by remember { mutableStateOf<File?>(null) }
    var drag by remember { mutableFloatStateOf(-1f) }
    LaunchedEffect(Unit) { file = withContext(Dispatchers.IO) { recorder.previewFile() } }
    DisposableEffect(Unit) { onDispose { RecPreview.release() } }
    LaunchedEffect(RecPreview.playing) {
        while (RecPreview.playing) { RecPreview.tick(); delay(60) }
    }
    val total = if (RecPreview.durMs > 0) RecPreview.durMs else totalSec * 1000
    val frac = if (drag >= 0f) drag else if (total > 0) (RecPreview.posMs.toFloat() / total).coerceIn(0f, 1f) else 0f
    val shownSec = if (drag >= 0f || RecPreview.posMs > 0) (frac * total / 1000f).toInt() else totalSec
    val barCol = Color(0xFF8696A0)
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).clickable { file?.let { RecPreview.toggle(it) } },
            contentAlignment = Alignment.Center
        ) {
            Icon(if (RecPreview.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(32.dp))
        }
        Canvas(
            Modifier.weight(1f).fillMaxHeight()
                .pointerInput(file) {
                    detectTapGestures { o ->
                        val fr = (o.x / size.width).coerceIn(0f, 1f)
                        file?.let { RecPreview.seek(it, fr) }
                    }
                }
                .pointerInput(file) {
                    detectHorizontalDragGestures(
                        onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                        onDragEnd = { file?.let { RecPreview.seek(it, drag) }; drag = -1f },
                        onDragCancel = { drag = -1f },
                        onHorizontalDrag = { c, _ ->
                            drag = (c.position.x / size.width).coerceIn(0f, 1f)
                            file?.let { RecPreview.seek(it, drag) }
                        }
                    )
                }
        ) {
            val step = 6.dp.toPx()
            val bw = 3.dp.toPx()
            val n = (size.width / step).toInt().coerceAtLeast(1)
            val cy = size.height / 2f
            for (i in 0 until n) {
                val a = (i * amps.size) / n
                val b = (((i + 1) * amps.size) / n).coerceAtLeast(a + 1).coerceAtMost(amps.size)
                var v = 0f
                for (k in a until b) if (k < amps.size && amps[k] > v) v = amps[k]
                val x = i * step + bw / 2f
                val h = (4.dp.toPx() + v * (size.height - 4.dp.toPx())).coerceAtMost(size.height)
                val played = (i + 0.5f) / n <= frac
                drawLine(if (played) Color.White else barCol, Offset(x, cy - h / 2f), Offset(x, cy + h / 2f), bw, StrokeCap.Round)
            }
            drawCircle(accent, 7.dp.toPx(), Offset((frac * size.width).coerceIn(7.dp.toPx(), size.width - 7.dp.toPx()), cy))
        }
        Text(
            "%d:%02d".format(shownSec / 60, shownSec % 60),
            color = Color.White, fontSize = 14.sp, maxLines = 1, softWrap = false, modifier = Modifier.padding(start = 8.dp, end = 4.dp)
        )
    }
}

/** Mikrofon düğmesi: basılı tut → kayıt, sola kaydır → iptal, yukarı kaydır → kilitle, bırak → gönder. Kısa dokunuş onTap. canSend iken normal gönder. */
@Composable
fun Modifier.micGesture(
    canSend: Boolean,
    onSend: () -> Unit,
    onTap: () -> Unit,
    onHoldStart: () -> Unit,
    onMove: (Float, Float) -> Unit,
    onEnd: (Boolean, Boolean) -> Unit
): Modifier {
    val sendS by androidx.compose.runtime.rememberUpdatedState(onSend)
    val tapS by androidx.compose.runtime.rememberUpdatedState(onTap)
    val startS by androidx.compose.runtime.rememberUpdatedState(onHoldStart)
    val moveS by androidx.compose.runtime.rememberUpdatedState(onMove)
    val endS by androidx.compose.runtime.rememberUpdatedState(onEnd)
    return this.pointerInput(canSend) {
        val cancelThr = 90.dp.toPx()
        val lockThr = 70.dp.toPx()
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            if (canSend) {
                val up = waitForUpOrCancellation()
                if (up != null) sendS()
                return@awaitEachGesture
            }
            var upEarly = false
            var cancelled = false
            val longPress = try {
                withTimeout(250L) {
                    val up = waitForUpOrCancellation()
                    if (up != null) upEarly = true else cancelled = true
                }
                false
            } catch (e: androidx.compose.ui.input.pointer.PointerEventTimeoutCancellationException) {
                true
            }
            if (!longPress) {
                if (upEarly) tapS()
                return@awaitEachGesture
            }
            startS()
            var canceled = false
            var locked = false
            while (true) {
                val ev = awaitPointerEvent()
                val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                if (!c.pressed) break
                val dx = c.position.x - down.position.x
                val dy = c.position.y - down.position.y
                moveS(dx, dy)
                if (dy < -lockThr && kotlin.math.abs(dy) > kotlin.math.abs(dx)) { locked = true; break }
                if (dx < -cancelThr) { canceled = true; break }
                c.consume()
            }
            endS(canceled, locked)
        }
    }
}

/** Basılı tutarken alt çubuk: kırmızı mikrofon + süre + "İptal etmek için kaydırın" */
@Composable
fun RecHoldBar(sec: Int, dx: Float, modifier: Modifier = Modifier) {
    val inf = androidx.compose.animation.core.rememberInfiniteTransition(label = "rec")
    val a by inf.animateFloat(
        1f, 0.25f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(700), androidx.compose.animation.core.RepeatMode.Reverse),
        label = "recdot"
    )
    val shift = (dx / 3f).coerceAtMost(0f)
    val fade = (1f - (-dx / 260f)).coerceIn(0f, 1f)
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Icon(androidx.compose.material.icons.Icons.Default.Mic, null, tint = Color(0xFFEF4444).copy(alpha = a), modifier = Modifier.padding(start = 11.dp).size(24.dp))
        Text("%d:%02d".format(sec / 60, sec % 60), color = Color(0xFF9AA5AD), fontSize = 20.sp, softWrap = false, modifier = Modifier.padding(start = 13.dp).width(98.dp))
        Row(
            Modifier.weight(1f).graphicsLayer { translationX = shift; alpha = fade },
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Start
        ) {
            Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.KeyboardArrowLeft, null, tint = Color(0xFF9AA5AD), modifier = Modifier.size(16.dp))
            Text("İptal etmek için kaydırın", color = Color(0xFF9AA5AD), fontSize = 11.sp, softWrap = false, modifier = Modifier.padding(start = 6.dp))
        }
    }
}

/** Büyük yeşil mikrofon (basılıyken) */
@Composable
fun RecBigMic(accent: Color, modifier: Modifier = Modifier) {
    Box(modifier.size(89.dp).clip(CircleShape).background(accent), contentAlignment = Alignment.Center) {
        Icon(androidx.compose.material.icons.Icons.Default.Mic, null, tint = if (accent.luminance() < 0.5f) Color.White else Color(0xFF111B21), modifier = Modifier.size(40.dp))
    }
}

/** Yukarı kaydırınca kilitlenir: kilit hapı (prog 0..1) */
@Composable
fun RecLockPill(prog: Float, modifier: Modifier = Modifier) {
    val h = (156f - 70f * prog).dp
    Box(modifier.size(width = 56.dp, height = h).clip(androidx.compose.foundation.shape.RoundedCornerShape(27.dp)).background(Color(0xFF1F2A30)), contentAlignment = Alignment.TopCenter) {
        androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 22.dp)) {
            Icon(
                if (prog > 0.7f) androidx.compose.material.icons.Icons.Default.Lock else androidx.compose.material.icons.Icons.Default.LockOpen,
                null, tint = Color.White, modifier = Modifier.size(20.dp)
            )
            Icon(androidx.compose.material.icons.Icons.Default.KeyboardArrowUp, null, tint = Color(0xFF9AA5AD).copy(alpha = 1f - prog), modifier = Modifier.padding(top = 8.dp).size(16.dp))
        }
    }
}

/** Kayıt genliklerinden 40 çubuklu (2..31) dalga formu */
fun recWave(amps: List<Float>): List<Int> {
    if (amps.isEmpty()) return emptyList()
    return List(40) { i ->
        val a = i * amps.size / 40
        val b = ((i + 1) * amps.size / 40).coerceAtLeast(a + 1).coerceAtMost(amps.size)
        var mx = 0f
        for (k in a until b) if (amps[k] > mx) mx = amps[k]
        (mx * 31f).toInt().coerceIn(2, 31)
    }
}

/** Kilitli kayıt paneli (sil / duraklat-devam / gönder + ① tek dinlemelik) — ChatScreenImpl'i küçültmek için ayrı */
@Composable
fun RecPanel(
    recorder: VoiceRecorder, amps: List<Float>, sec: Int, paused: Boolean, once: Boolean,
    accent: Color, btnColor: Color,
    onOnce: () -> Unit, onCancel: () -> Unit, onSend: () -> Unit, onPause: () -> Unit
) {
    val panelBg = androidx.compose.ui.graphics.lerp(AuraSurface, accent, 0.10f)
    val pillBg = androidx.compose.ui.graphics.lerp(AuraSurface, accent, 0.24f)
    val red = auraLc(0xFFEF4444)
    androidx.compose.foundation.layout.Column(
        Modifier.fillMaxWidth().clip(androidx.compose.foundation.shape.RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)).background(panelBg)
            .padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
            if (paused) RecPausedBar(recorder, amps, sec, accent, Modifier.weight(1f).fillMaxHeight()) else {
                Text("%d:%02d".format(sec / 60, sec % 60), color = AuraWhite, fontSize = 24.sp, modifier = Modifier.width(64.dp))
                val barCol = AuraMuted
                Canvas(Modifier.weight(1f).fillMaxHeight()) {
                    val step = 6.dp.toPx()
                    val bw = 3.dp.toPx()
                    val n = (size.width / step).toInt()
                    val cy = size.height / 2f
                    for (i in 0 until n) {
                        val idx = amps.size - 1 - (n - 1 - i)
                        val v = if (idx >= 0 && idx < amps.size) amps[idx] else -1f
                        val x = i * step + bw / 2f
                        if (v < 0f) {
                            drawCircle(barCol.copy(alpha = 0.5f), 1.5.dp.toPx(), Offset(x, cy))
                        } else {
                            val h = (4.dp.toPx() + v * (size.height - 4.dp.toPx())).coerceAtMost(size.height)
                            drawLine(barCol, Offset(x, cy - h / 2f), Offset(x, cy + h / 2f), bw, StrokeCap.Round)
                        }
                    }
                }
            }
            RecOnceToggle(once, accent, onOnce)
        }
        androidx.compose.foundation.layout.Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(60.dp).clip(CircleShape).background(red.copy(alpha = 0.22f)).clickable(onClick = onCancel), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Delete, "İptal", tint = red, modifier = Modifier.size(28.dp))
            }
            androidx.compose.foundation.layout.Spacer(Modifier.width(10.dp))
            Row(
                Modifier.weight(1f).height(60.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(18.dp)).background(pillBg).clickable(onClick = onPause),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center, verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(if (paused) Icons.Default.Mic else Icons.Default.Pause, null, tint = AuraWhite, modifier = Modifier.size(26.dp))
                androidx.compose.foundation.layout.Spacer(Modifier.width(10.dp))
                Text(if (paused) "Devam et" else "Duraklat", color = AuraWhite, fontSize = 19.sp)
            }
            androidx.compose.foundation.layout.Spacer(Modifier.width(10.dp))
            Box(Modifier.size(60.dp).clip(CircleShape).background(btnColor).clickable(onClick = onSend), contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Filled.Send, "Gönder", tint = if (btnColor.luminance() < 0.5f) Color.White else Color(0xFF111B21), modifier = Modifier.size(28.dp))
            }
        }
    }
}

/** Basılı tutarken: alt çubuk + kilit hapı + büyük mikrofon */
@Composable
fun androidx.compose.foundation.layout.BoxScope.RecHoldOverlay(
    sec: Int, dx: Float, dy: Float, btnColor: Color,
    shape: androidx.compose.ui.graphics.Shape, padH: androidx.compose.ui.unit.Dp, padT: androidx.compose.ui.unit.Dp, padB: androidx.compose.ui.unit.Dp
) {
    val holdBg = if (AuraUi.light) Color.White else (ChatBar.tint ?: AuraBlack)
    // WhatsApp ölçüleri: 48dp yüksekliğinde hap çubuk (sol 8dp), altında büyük mikrofon, üstte kilit hapı
    Box(
        Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(start = padH, end = padH, bottom = padB)
            .height(48.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(24.dp)).background(holdBg)
    ) {
        RecHoldBar(sec, dx, Modifier.fillMaxSize().padding(end = 80.dp))
    }
    val lockProg = (-dy / 200f).coerceIn(0f, 1f)
    Box(Modifier.matchParentSize()) {
        RecLockPill(lockProg, Modifier.align(Alignment.BottomEnd).padding(end = 4.dp, bottom = padB + 24.dp))
        RecBigMic(btnColor, Modifier.align(Alignment.BottomEnd).padding(bottom = padB).offset(x = 12.dp, y = 17.dp))
    }
}

/** Sohbetten çıkarken açık ses kaydını taslak olarak saklar */
fun saveVoiceDraft(ctx: android.content.Context, chatId: String, rec: VoiceRecorder, amps: List<Float>) {
    try {
        rec.pause()
        val f = rec.previewFile() ?: return
        val sec = rec.elapsedSec()
        if (sec < 1) return
        f.copyTo(Drafts.voiceFile(ctx, chatId), overwrite = true)
        Drafts.setVoice(ctx, chatId, sec, recWave(amps))
    } catch (e: Throwable) {
        com.aurachat.app.AuraLog.e("VoiceDraft", e)
    }
}

/** Taslak varsa kaydediciyi duraklatılmış halde hazırlar; süre ve genlikleri döner */
fun restoreVoiceDraft(ctx: android.content.Context, chatId: String, rec: VoiceRecorder): Pair<Int, List<Float>>? {
    val sec = Drafts.voice[chatId] ?: return null
    val f = Drafts.voiceFile(ctx, chatId)
    if (!f.exists() || !rec.restore(f, sec)) return null
    val wave = Drafts.voiceWave(chatId)
    val n = (sec * 10).coerceAtLeast(1)
    val amps = if (wave.isEmpty()) List(n) { 0.3f } else List(n) { i -> wave[(i * wave.size / n).coerceAtMost(wave.size - 1)] / 31f }
    return sec to amps
}

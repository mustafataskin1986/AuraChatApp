package com.aurachat.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Uygulama genelinde yazı boyutu çarpanı ve yazı stili (yazı tipi ailesi). Ayarlar → Yazı boyutu ve stili */
object AuraFont {
    var scale by mutableFloatStateOf(1f)
        private set
    var familyId by mutableIntStateOf(0)
        private set

    val names = listOf("Varsayılan", "İnce", "Dar", "Serif", "Daktilo", "El yazısı", "Rahat")

    fun family(id: Int = familyId): FontFamily = when (id) {
        1 -> FontFamily(android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL))
        2 -> FontFamily(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.NORMAL))
        3 -> FontFamily.Serif
        4 -> FontFamily.Monospace
        5 -> FontFamily.Cursive
        6 -> FontFamily(android.graphics.Typeface.create("casual", android.graphics.Typeface.NORMAL))
        else -> FontFamily.Default
    }

    private fun prefs(ctx: android.content.Context) = ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE)

    fun load(ctx: android.content.Context) {
        scale = prefs(ctx).getFloat("font_scale", 1f).coerceIn(0.8f, 1.5f)
        familyId = prefs(ctx).getInt("font_family", 0).coerceIn(0, names.size - 1)
    }

    fun setScale(ctx: android.content.Context, v: Float) {
        scale = v.coerceIn(0.8f, 1.5f)
        prefs(ctx).edit().putFloat("font_scale", scale).apply()
    }

    fun setFamily(ctx: android.content.Context, id: Int) {
        familyId = id
        prefs(ctx).edit().putInt("font_family", id).apply()
    }
}

fun auraTypography(f: FontFamily): androidx.compose.material3.Typography {
    val b = androidx.compose.material3.Typography()
    return androidx.compose.material3.Typography(
        displayLarge = b.displayLarge.copy(fontFamily = f), displayMedium = b.displayMedium.copy(fontFamily = f), displaySmall = b.displaySmall.copy(fontFamily = f),
        headlineLarge = b.headlineLarge.copy(fontFamily = f), headlineMedium = b.headlineMedium.copy(fontFamily = f), headlineSmall = b.headlineSmall.copy(fontFamily = f),
        titleLarge = b.titleLarge.copy(fontFamily = f), titleMedium = b.titleMedium.copy(fontFamily = f), titleSmall = b.titleSmall.copy(fontFamily = f),
        bodyLarge = b.bodyLarge.copy(fontFamily = f), bodyMedium = b.bodyMedium.copy(fontFamily = f), bodySmall = b.bodySmall.copy(fontFamily = f),
        labelLarge = b.labelLarge.copy(fontFamily = f), labelMedium = b.labelMedium.copy(fontFamily = f), labelSmall = b.labelSmall.copy(fontFamily = f)
    )
}

@Composable
fun FontStyleScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler { onBack() }
    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text("Yazı boyutu ve stili", color = AuraWhite, fontSize = 22.sp, modifier = Modifier.padding(start = 8.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
            // önizleme
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(ChipLook.bg).border(1.dp, ChipLook.border, RoundedCornerShape(18.dp)).padding(16.dp)
            ) {
                Text("Önizleme", color = ChipLook.fg, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(8.dp))
                Text("Merhaba! Bu yazı seçtiğin boyut ve stilde görünür.", color = AuraWhite, fontSize = 17.sp)
                Spacer(Modifier.height(4.dp))
                Text("Aralarında 0123456789 ve ğüşiöç karakterleri de var.", color = AuraMuted, fontSize = 14.sp)
            }
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Yazı boyutu", color = AuraWhite, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Text("%${Math.round(AuraFont.scale * 100)}", color = AuraMuted, fontSize = 15.sp)
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("A", color = AuraMuted, fontSize = 13.sp)
                Slider(
                    value = AuraFont.scale, onValueChange = { AuraFont.setScale(ctx, Math.round(it * 20f) / 20f) },
                    valueRange = 0.8f..1.5f, steps = 13, modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    colors = SliderDefaults.colors(thumbColor = ChipLook.fg, activeTrackColor = ChipLook.fg, inactiveTrackColor = ChipLook.border)
                )
                Text("A", color = AuraMuted, fontSize = 24.sp)
            }
            Spacer(Modifier.height(20.dp))
            Text("Yazı stili", color = AuraWhite, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            AuraFont.names.forEachIndexed { i, name ->
                val on = AuraFont.familyId == i
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(14.dp))
                        .background(if (on) ChipLook.bg else androidx.compose.ui.graphics.Color.Transparent)
                        .border(1.dp, if (on) ChipLook.border else AuraMuted.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
                        .clickable { AuraFont.setFamily(ctx, i) }.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(name, color = if (on) ChipLook.fg else AuraWhite, fontSize = 17.sp, fontFamily = AuraFont.family(i), modifier = Modifier.weight(1f))
                    if (on) Icon(Icons.Default.Check, null, tint = ChipLook.fg)
                }
            }
            Box(
                Modifier.padding(top = 8.dp).clip(RoundedCornerShape(50)).border(1.dp, AuraMuted.copy(alpha = 0.4f), RoundedCornerShape(50))
                    .clickable { AuraFont.setScale(ctx, 1f); AuraFont.setFamily(ctx, 0) }.padding(horizontal = 18.dp, vertical = 10.dp)
            ) { Text("Varsayılana dön", color = AuraMuted, fontSize = 15.sp) }
            Spacer(Modifier.height(24.dp))
        }
    }
}

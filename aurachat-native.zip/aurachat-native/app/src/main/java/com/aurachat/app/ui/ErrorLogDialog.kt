package com.aurachat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aurachat.app.AuraLog

@Composable
fun ErrorLogDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf(AuraLog.read()) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xFF0B0F12)).statusBarsPadding().padding(16.dp)) {
            Text("Hata kayıtları", color = Color.White, fontSize = 20.sp)
            Text("Sessizce yutulan hatalar burada görünür. Ekran görüntüsünü gönder.", color = Color(0xFF9CA3AF), fontSize = 13.sp, modifier = Modifier.padding(vertical = 6.dp))
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                Text(if (text.isBlank()) "Kayıtlı hata yok." else text, color = Color(0xFFE5E7EB), fontSize = 11.sp, lineHeight = 15.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = {
                    (ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                        .setPrimaryClip(android.content.ClipData.newPlainText("hata", text))
                }) { Text("Kopyala") }
                TextButton(onClick = { AuraLog.clear(); text = "" }) { Text("Temizle") }
                TextButton(onClick = onDismiss) { Text("Kapat") }
            }
        }
    }
}

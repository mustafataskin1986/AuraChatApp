package com.aurachat.app.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile

/** Yeni kişi: kullanıcı adı ya da telefon numarasıyla AuraChat'ta kişi bulup sohbet açar */
@Composable
fun NewContactScreen(me: UserProfile, onBack: () -> Unit, onOpenQr: () -> Unit, onOpenChat: (UserProfile) -> Unit, edit: UserProfile? = null) {
    val ctx = LocalContext.current
    BackHandler { onBack() }
    val users by remember(me.uid) { Repo.usersFlow(me.uid) }.collectAsState(Repo.cachedUsers() ?: emptyList())
    var first by remember { mutableStateOf(edit?.name.orEmpty().let { n -> if (n.contains(' ')) n.substringBeforeLast(' ') else n }) }
    var last by remember { mutableStateOf(edit?.name.orEmpty().let { n -> if (n.contains(' ')) n.substringAfterLast(' ') else "" }) }
    var uname by remember { mutableStateOf(edit?.username ?: "") }
    var phone by remember { mutableStateOf(edit?.phone?.filter { it.isDigit() }?.takeLast(10) ?: "") }
    val canSave = first.isNotBlank() && (edit != null || uname.isNotBlank() || phone.length >= 10)

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = AuraGreen, unfocusedBorderColor = AuraMuted.copy(alpha = 0.5f),
        focusedTextColor = AuraWhite, unfocusedTextColor = AuraWhite, cursorColor = AuraGreen,
        focusedLabelColor = AuraMuted, unfocusedLabelColor = AuraMuted,
        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent
    )
    val txt = TextStyle(fontSize = 17.sp, letterSpacing = 0.sp, color = AuraWhite)
    val shape = RoundedCornerShape(14.dp)

    fun save() {
        if (edit != null) {
            // Düzenleme: değişiklikler telefonun rehber uygulamasına aktarılır
            try {
                ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_INSERT_OR_EDIT).apply {
                    type = android.provider.ContactsContract.Contacts.CONTENT_ITEM_TYPE
                    putExtra(android.provider.ContactsContract.Intents.Insert.NAME, (first.trim() + " " + last.trim()).trim())
                    putExtra(android.provider.ContactsContract.Intents.Insert.PHONE, if (phone.isBlank()) "" else "+90$phone")
                }.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Throwable) { Toast.makeText(ctx, "Rehber uygulaması açılamadı", Toast.LENGTH_SHORT).show() }
            onBack()
            return
        }
        val un = uname.trim().removePrefix("@")
        val ph = phone.filter { it.isDigit() }
        val u = users.firstOrNull { (un.isNotEmpty() && it.username.equals(un, true)) || (ph.length >= 10 && it.phone.filter { c -> c.isDigit() }.endsWith(ph.takeLast(10))) }
        when {
            u == null -> Toast.makeText(ctx, "AuraChat'ta bu bilgilerle bir kullanıcı bulunamadı", Toast.LENGTH_SHORT).show()
            else -> onOpenChat(u)
        }
    }

    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text(if (edit != null) "Kişiyi düzenleyin" else "Yeni kişi", color = AuraWhite, fontSize = 21.sp, letterSpacing = 0.sp, modifier = Modifier.padding(start = 8.dp).weight(1f))
            if (edit == null) IconButton(onClick = onOpenQr) { Icon(Icons.Default.QrCode2, "Profil paylaşımı", tint = AuraWhite) }
        }
        HorizontalDivider(color = AuraMuted.copy(alpha = 0.18f))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 24.dp)) {
            Row(Modifier.fillMaxWidth().padding(end = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(60.dp), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = AuraMuted, modifier = Modifier.size(24.dp)) }
                OutlinedTextField(first, { first = it }, Modifier.weight(1f).height(58.dp), singleLine = true, shape = shape, textStyle = txt, colors = fieldColors,
                    placeholder = { Text("Ad", color = AuraMuted, fontSize = 17.sp, letterSpacing = 0.sp) })
            }
            Row(Modifier.fillMaxWidth().padding(top = 32.dp, end = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.width(60.dp))
                OutlinedTextField(last, { last = it }, Modifier.weight(1f).height(58.dp), singleLine = true, shape = shape, textStyle = txt, colors = fieldColors,
                    placeholder = { Text("Soyadı", color = AuraMuted, fontSize = 17.sp, letterSpacing = 0.sp) })
            }
            Row(Modifier.fillMaxWidth().padding(top = 32.dp, end = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(60.dp), contentAlignment = Alignment.Center) { Icon(Icons.Default.AlternateEmail, null, tint = AuraMuted, modifier = Modifier.size(24.dp)) }
                OutlinedTextField(uname, { uname = it.filter { c -> !c.isWhitespace() } }, Modifier.weight(1f).height(58.dp), singleLine = true, shape = shape, textStyle = txt, colors = fieldColors,
                    placeholder = { Text("Kullanıcı adı", color = AuraMuted, fontSize = 17.sp, letterSpacing = 0.sp) })
            }
            Row(Modifier.fillMaxWidth().padding(top = 32.dp, end = 24.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.width(60.dp), contentAlignment = Alignment.Center) { Icon(Icons.Default.Call, null, tint = AuraMuted, modifier = Modifier.size(24.dp)) }
                OutlinedTextField("TR +90", {}, Modifier.width(127.dp).height(58.dp), readOnly = true, singleLine = true, shape = shape, textStyle = txt, colors = fieldColors,
                    label = { Text("Ülke", fontSize = 13.sp, letterSpacing = 0.sp) },
                    trailingIcon = { Icon(Icons.Default.ArrowDropDown, null, tint = AuraMuted) })
                OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() }.take(10) }, Modifier.weight(1f).height(58.dp), singleLine = true, shape = shape, textStyle = txt, colors = fieldColors,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    placeholder = { Text("Telefon", color = AuraMuted, fontSize = 17.sp, letterSpacing = 0.sp) })
            }
            Row(Modifier.fillMaxWidth().padding(top = 28.dp, end = 24.dp)) {
                Box(Modifier.width(60.dp).padding(top = 2.dp), contentAlignment = Alignment.TopCenter) { Icon(Icons.Default.Sync, null, tint = AuraMuted, modifier = Modifier.size(24.dp)) }
                Column(Modifier.weight(1f).padding(end = 8.dp)) {
                    Text("Kişiyi telefonla senkronize et", color = AuraWhite, fontSize = 16.sp, letterSpacing = 0.sp)
                    Text("Yalnızca telefon numarası olan kişiler senkronize edilebilir", color = AuraMuted, fontSize = 14.sp, lineHeight = 18.sp, letterSpacing = 0.sp, modifier = Modifier.padding(top = 2.dp))
                }
                Switch(checked = false, onCheckedChange = null, enabled = false)
            }
        }
        Box(
            Modifier.padding(start = 30.dp, end = 30.dp, bottom = 20.dp, top = 8.dp).fillMaxWidth().height(40.dp).clip(RoundedCornerShape(50))
                .background(if (canSave) AuraGreen else AuraSurface).clickable(enabled = canSave) { save() },
            contentAlignment = Alignment.Center
        ) { Text("Kaydet", color = if (canSave) AuraBlack else AuraMuted.copy(alpha = 0.6f), fontSize = 17.sp, letterSpacing = 0.sp) }
    }
}

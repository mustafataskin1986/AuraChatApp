package com.aurachat.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Uygulama çökerse hatayı ekranda gösterir (ayrı işlemde çalışır); ekran görüntüsü alıp gönderebilirsin. */
class CrashActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val err = intent.getStringExtra("err") ?: "(hata metni yok)"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(32, 96, 32, 32)
        }
        root.addView(TextView(this).apply {
            text = "AuraChat çöktü. Bu ekranın görüntüsünü gönder."
            setTextColor(Color.parseColor("#F87171"))
            textSize = 16f
        })
        val tv = TextView(this).apply {
            text = err
            setTextColor(Color.WHITE)
            textSize = 11f
            setTextIsSelectable(true)
        }
        root.addView(ScrollView(this).apply { addView(tv) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply {
            text = "Kopyala"
            setOnClickListener {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("hata", err))
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { gravity = Gravity.BOTTOM })
        setContentView(root)
    }
}

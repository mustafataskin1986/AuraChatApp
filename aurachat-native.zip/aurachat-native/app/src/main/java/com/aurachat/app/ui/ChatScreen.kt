package com.aurachat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.aurachat.app.AppState
import com.aurachat.app.data.Message
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(me: UserProfile, chatId: String, otherUid: String, otherName: String, onBack: () -> Unit) {
    val messages by remember(chatId) { Repo.messagesFlow(chatId) }.collectAsState(emptyList())
    val otherTyping by remember(chatId) { Repo.typingFlow(chatId, otherUid) }.collectAsState(false)
    val avatar by produceState("", otherUid) { value = Repo.avatarOf(otherUid) }
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var lastTypingWrite by remember { mutableLongStateOf(0L) }
    val listState = rememberLazyListState()
    // Ekran gerçekten önümüzdeyken (uygulama arka planda değilken) true
    val lifeState by LocalLifecycleOwner.current.lifecycle.currentStateFlow.collectAsState()
    val visible = lifeState.isAtLeast(Lifecycle.State.RESUMED)

    // Bu sohbet açıkken bildirim bastırılır
    DisposableEffect(chatId) {
        AppState.activeChatId = chatId
        onDispose {
            if (AppState.activeChatId == chatId) AppState.activeChatId = null
            Repo.setTyping(me.uid, chatId, otherUid, false)
        }
    }

    // Gelen mesajları okundu yap
    LaunchedEffect(messages, visible) { if (visible) Repo.markRead(me.uid, chatId, otherUid, messages) }
    // Yeni mesajda en alta kay
    LaunchedEffect(messages.firstOrNull()?.id) { if (messages.isNotEmpty()) listState.animateScrollToItem(0) }
    // Yazma bildirimi: en fazla 1,5 sn'de bir; 3 sn durunca kapat
    LaunchedEffect(text, visible) {
        // Kutu boşaldıysa ya da uygulama arka plandaysa: "yazıyor"u kapat
        if (text.isBlank() || !visible) {
            if (lastTypingWrite != 0L) {
                lastTypingWrite = 0L
                Repo.setTyping(me.uid, chatId, otherUid, false)
            }
            return@LaunchedEffect
        }
        val now = System.currentTimeMillis()
        if (now - lastTypingWrite > 1500) {
            lastTypingWrite = now
            Repo.setTyping(me.uid, chatId, otherUid, true)
        }
        delay(3000)
        lastTypingWrite = 0L
        Repo.setTyping(me.uid, chatId, otherUid, false)
    }

    Column(Modifier.fillMaxSize().background(AuraBg).imePadding()) {
        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(containerColor = AuraSurface),
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") } },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(otherName, avatar, 38.dp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(otherName, fontSize = 17.sp, maxLines = 1)
                        if (otherTyping) Text("yazıyor...", fontSize = 12.sp, color = AuraGreen)
                    }
                }
            }
        )
        LazyColumn(
            state = listState,
            reverseLayout = true,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(messages, key = { it.id }) { m -> Bubble(m, mine = m.senderUid == me.uid) }
        }
        Row(
            Modifier.fillMaxWidth().background(AuraSurface).navigationBarsPadding().padding(8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Box(
                Modifier.weight(1f).background(Color(0xFF2A2F31), RoundedCornerShape(22.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                if (text.isEmpty()) Text("Mesaj", color = AuraMuted, fontSize = 16.sp)
                BasicTextField(
                    value = text, onValueChange = { text = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(AuraGreen),
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.width(6.dp))
            IconButton(
                onClick = {
                    val t = text.trim()
                    if (t.isEmpty()) return@IconButton
                    text = ""
                    scope.launch {
                        try { Repo.sendText(me, chatId, otherUid, otherName, t) } catch (_: Exception) {}
                    }
                },
                modifier = Modifier.background(AuraGreen, RoundedCornerShape(50))
            ) { Icon(Icons.AutoMirrored.Filled.Send, "Gönder", tint = Color.Black) }
        }
    }
}

@Composable
private fun Bubble(m: Message, mine: Boolean) {
    val body = when {
        m.deleted || m.type == "deleted" -> "🚫 Bu mesaj silindi"
        m.type == "image" -> "📷 Fotoğraf (yakında)"
        m.type == "audio" || m.type == "voice" -> "🎤 Sesli mesaj (yakında)"
        m.type == "call_duration" -> "📞 Arama"
        m.text.isNotEmpty() -> m.text
        else -> "Desteklenmeyen mesaj"
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 300.dp)
                .background(if (mine) AuraMine else AuraTheirs, RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text(body, fontSize = 16.sp, color = Color.White)
            Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                Text(formatClock(m.time), fontSize = 11.sp, color = Color(0xFFCBD5D1))
                if (mine) {
                    val tick = when {
                        m.pending -> "🕓"
                        m.read -> "✓✓"
                        else -> "✓"
                    }
                    Spacer(Modifier.width(4.dp))
                    Text(tick, fontSize = 11.sp, color = if (m.read) Color(0xFF53BDEB) else Color(0xFFCBD5D1))
                }
            }
        }
    }
}

package com.aurachat.app.ui

import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.zIndex
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.layout.offset
import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.border
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Computer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Description
import androidx.compose.runtime.produceState
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.requiredHeight
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardDoubleArrowDown
import androidx.compose.foundation.gestures.draggable
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.focus.focusRequester
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.material.icons.filled.Flag
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.aurachat.app.AppState
import com.aurachat.app.call.CallManager
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Media
import com.aurachat.app.data.Message
import com.aurachat.app.data.ReplyRef
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import com.aurachat.app.data.VoiceRecorder
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val REACTIONS = listOf("👍", "❤️", "😂", "😮", "😢", "🙏")

private fun effTime(m: Message): Long = if (m.time <= 0L) System.currentTimeMillis() else m.time

private fun dayKey(ms: Long): Int {
    val c = Calendar.getInstance().apply { timeInMillis = ms }
    return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
}

/** "Hakkımda" baloncuğu: en alttan iki sayfa boyuna kadar görünür, kaydırırken gizlenir, durunca belirir (WhatsApp gibi) */
@Composable
private fun rememberAboutVisible(listState: androidx.compose.foundation.lazy.LazyListState): Boolean {
    var show by remember(listState) { mutableStateOf(true) }
    LaunchedEffect(listState) {
        // Kaydırılan mesajların gerçek yükseklikleri sırayla ölçülür; uzaklık tahminle değil toplamla bulunur
        val sizes = HashMap<Int, Int>()
        androidx.compose.runtime.snapshotFlow { listState.layoutInfo to listState.isScrollInProgress }.collect { (li, scrolling) ->
            li.visibleItemsInfo.forEach { sizes[it.index] = it.size }
            val first = listState.firstVisibleItemIndex
            val avg = if (sizes.isEmpty()) 0f else sizes.values.average().toFloat()
            var dist = listState.firstVisibleItemScrollOffset.toFloat()
            for (i in 0 until first) dist += (sizes[i] ?: avg.toInt()).toFloat()
            show = !scrolling && li.visibleItemsInfo.isNotEmpty() && dist < 2f * li.viewportSize.height
        }
    }
    return show
}

@Composable
private fun DayChip(text: String) {
    Text(
        text, color = auraLc(0xFF9AA5AB), fontSize = 12.5.sp, lineHeight = 15.sp,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(AuraSurface.copy(alpha = 0.78f)).padding(horizontal = 8.dp, vertical = 2.dp)
    )
}

private fun dayLabel(ms: Long): String {
    val k = dayKey(ms)
    val now = System.currentTimeMillis()
    if (k == dayKey(now)) return "Bugün"
    if (k == dayKey(now - 86_400_000L)) return "Dün"
    val c0 = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    val c1 = Calendar.getInstance().apply { timeInMillis = ms; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    val diff = Math.round((c0.timeInMillis - c1.timeInMillis) / 86_400_000.0)
    if (diff in 2..6) return SimpleDateFormat("EEEE", Locale("tr")).format(Date(ms))
    return SimpleDateFormat("d MMMM yyyy", Locale("tr")).format(Date(ms))
}

private fun toast(ctx: Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

@SuppressLint("MissingPermission")
@Composable
fun ChatScreen(
    me: UserProfile,
    target: ChatTarget,
    onBack: () -> Unit,
    onOpenGroupInfo: () -> Unit,
    onForward: (List<Message>) -> Unit,
    onCall: (Boolean) -> Unit,
    onOpenTheme: () -> Unit,
    onNewGroup: () -> Unit = {},
    onOpenMedia: () -> Unit = {},
    jumpToMsgId: String? = null,
    startSearch: Boolean = false,
    onMemberChat: (UserProfile) -> Unit = {},
    onMemberCall: (UserProfile, Boolean) -> Unit = { _, _ -> }
) {
    val c = LocalContext.current
    val th = remember(target.chatId, AuraUi.light) { ChatThemes.resolve(c, target.chatId) }
    val ac = if (th.isDefaultOut) AuraBtn else th.out
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.foundation.text.selection.LocalTextSelectionColors provides
            androidx.compose.foundation.text.selection.TextSelectionColors(ac, ac.copy(alpha = 0.7f))
    ) {
        ChatScreenImpl(me, target, onBack, onOpenGroupInfo, onForward, onCall, onOpenTheme, onNewGroup, onOpenMedia, jumpToMsgId, startSearch, onMemberChat, onMemberCall)
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@SuppressLint("MissingPermission")
@Composable
private fun ChatScreenImpl(
    me: UserProfile,
    target: ChatTarget,
    onBack: () -> Unit,
    onOpenGroupInfo: () -> Unit,
    onForward: (List<Message>) -> Unit,
    onCall: (Boolean) -> Unit,
    onOpenTheme: () -> Unit,
    onNewGroup: () -> Unit = {},
    onOpenMedia: () -> Unit = {},
    jumpToMsgId: String? = null,
    startSearch: Boolean = false,
    onMemberChat: (UserProfile) -> Unit = {},
    onMemberCall: (UserProfile, Boolean) -> Unit = { _, _ -> }
) {
    val ctx = LocalContext.current
    val theme = remember(target.chatId, AuraUi.light) { ChatThemes.resolve(ctx, target.chatId) }
    // karanlık temada üst çubuk ve menüler sohbet temasından değil uygulama arka plan renginden gelir (null = AuraBlack)
    val barT = remember(theme, AuraUi.light) { if (AuraUi.light) themeBarTint(theme) else null }
    androidx.compose.runtime.SideEffect { ChatBar.tint = barT; AuraUi.accentOff = true }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { ChatBar.tint = null; ChatBar.sel = false; AuraUi.accentOff = false } }
    val accent = theme.out
    val btnColor = if (theme.isDefaultOut) ThemeDefaultOut else accent
    val inputBorder = theme.out
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    fun launchSafe(block: suspend () -> Unit) {
        scope.launch {
            try { block() } catch (e: Throwable) { toast(ctx, "İşlem başarısız oldu") }
        }
    }
    val lifecycleOwner = LocalLifecycleOwner.current

    // ---------- Yaşam döngüsü: yalnızca ekran açıkken okundu/yazıyor ----------
    var resumed by remember { mutableStateOf(lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) resumed = true
            if (e == Lifecycle.Event.ON_PAUSE) resumed = false
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }
    DisposableEffect(target.chatId) {
        AppState.activeChatId = target.chatId
        onDispose {
            if (AppState.activeChatId == target.chatId) AppState.activeChatId = null
            AudioPlayer.stop()
        }
    }

    // ---------- Veri ----------
    // Aramadan bir mesaja gidiliyorsa, o mesaja kadar olan kısım tek seferde yerelden yüklenir (kademeli yükleme sayfayı geç ve atlayarak getiriyordu)
    var limit by remember(target.chatId, jumpToMsgId) {
        mutableLongStateOf(
            if (jumpToMsgId != null) com.aurachat.app.data.LocalDb.countFrom(target.chatId, jumpToMsgId).let { if (it > 0) (it + 20).coerceAtMost(3000).toLong() else 30L } else 30L
        )
    }
    val raw by remember(target.chatId, limit) { Repo.messagesFlow(target.chatId, limit) }.collectAsState(remember(target.chatId) { Repo.cachedMessages(target.chatId) })
    val clearedAt by remember(target.chatId) { Repo.clearedAtFlow(me.uid, target.chatId) }.collectAsState(remember(target.chatId) { Repo.peekClearedAt(me.uid, target.chatId) })
    val starredList by remember { Repo.starredFlow(me.uid) }.collectAsState(emptyList())
    val starredKeys = remember(starredList) { starredList.map { it.key }.toSet() }
    val groupTyping by remember(target.chatId) {
        if (target.isGroup) Repo.groupTypingFlow(target.chatId, me.uid) else kotlinx.coroutines.flow.flowOf(emptyList<String>())
    }.collectAsState(emptyList<String>())
    val otherTyping by remember(target.chatId) {
        if (target.isGroup) kotlinx.coroutines.flow.flowOf(false) else Repo.typingFlow(target.chatId, target.otherUid)
    }.collectAsState(false)

    val localVer = com.aurachat.app.data.LocalMedia.version
    val pinMap by remember(target.chatId) { Repo.pinsFlow(target.chatId) }.collectAsState(emptyMap())
    val visible = remember(raw, clearedAt, localVer, pinMap) {
        raw.filter { m ->
            !m.deletedFor.contains(me.uid) && (clearedAt <= 0L || m.time <= 0L || m.time > clearedAt)
        }.map { com.aurachat.app.data.LocalMedia.localize(it) }.map { m ->
            val pi = pinMap[m.id]
            if (pi != null && (pi.second <= 0L || pi.second > System.currentTimeMillis())) m.copy(pinned = true, pinnedAt = pi.first, pinUntil = pi.second) else m.copy(pinned = false)
        }
    }
    // Gelen / giden medya telefona (Android/media/AuraChat) yazılır, alıcıda Firebase kopyası silinir
    LaunchedEffect(raw) {
        val todo = raw.filter { com.aurachat.app.data.LocalMedia.needsIngest(it, me.uid, target.isGroup) }
        if (todo.isNotEmpty()) {
            withContext(Dispatchers.IO) {
                todo.forEach { com.aurachat.app.data.LocalMedia.ingestBlocking(target.chatId, it, me.uid, target.isGroup) }
            }
        }
    }

    // Okunmamış ayırıcı: ilk anlık görüntüde bir kez hesaplanır
    val seenBefore = remember(target.chatId) { Repo.lastSeen(target.chatId) }
    val rawNow by androidx.compose.runtime.rememberUpdatedState(raw)
    val lifeOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(target.chatId, lifeOwner) {
        // Uygulama arka plana atılınca da (işlem öldürülse bile) "görülen son mesaj" kaydedilsin; yoksa dönüşte okunmamış sayısı yeniden çıkıyor
        val ob = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_PAUSE || e == androidx.lifecycle.Lifecycle.Event.ON_STOP)
                Repo.setLastSeen(target.chatId, rawNow.maxOfOrNull { it.time } ?: 0L)
        }
        lifeOwner.lifecycle.addObserver(ob)
        onDispose {
            lifeOwner.lifecycle.removeObserver(ob)
            Repo.setLastSeen(target.chatId, rawNow.maxOfOrNull { it.time } ?: 0L)
        }
    }
    var anchorSet by remember(target.chatId) { mutableStateOf(false) }
    var unreadAnchorId by remember(target.chatId) { mutableStateOf<String?>(null) }
    var unreadAnchorCount by remember(target.chatId) { mutableIntStateOf(0) }
    // Sohbet açılırken yerel kayıt eksik olabilir (mesajlar ağdan sonradan gelir): ilk birkaç saniye
    // "okunmamış" ayırıcısı ve sayısı gelen yeni verilere göre güncellenir (daha eski okunmamış çıkarsa ayırıcı oraya kayar)
    val openedAt = remember(target.chatId) { System.currentTimeMillis() }
    if (raw.isNotEmpty() && (!anchorSet || System.currentTimeMillis() - openedAt < 4000L)) {
        val unreadOnes = raw.filter {
            it.senderUid != me.uid && it.type != "system" &&
                (it.time <= 0L || it.time > seenBefore) &&
                (if (target.isGroup) !it.readBy.contains(me.uid) else !it.read)
        }
        if (unreadOnes.isNotEmpty()) {
            val cand = unreadOnes.last() // en eski okunmamış
            val curT = raw.firstOrNull { it.id == unreadAnchorId }?.time ?: Long.MAX_VALUE
            if (unreadAnchorId == null || (cand.time in 1 until curT)) unreadAnchorId = cand.id
        }
        val at = raw.firstOrNull { it.id == unreadAnchorId }?.time ?: 0L
        if (unreadAnchorId != null) {
            val cnt = raw.count { it.senderUid != me.uid && it.type != "system" && (at <= 0L || it.time >= at) }
            if (cnt != unreadAnchorCount) unreadAnchorCount = cnt
        }
        anchorSet = true
    }

    val hasUnread = raw.any {
        it.senderUid != me.uid && !it.pending && it.type != "system" &&
            (if (target.isGroup) !it.readBy.contains(me.uid) else !it.read)
    }
    LaunchedEffect(resumed, hasUnread) {
        if (resumed && hasUnread) {
            Repo.markRead(me.uid, target, raw)
            Repo.setLastSeen(target.chatId, raw.maxOfOrNull { it.time } ?: 0L)
        }
    }
    LaunchedEffect(resumed) {
        if (resumed && raw.isEmpty()) Repo.markRead(me.uid, target, raw)
    }

    // ---------- Giriş durumu ----------
    var text by remember(target.chatId) { mutableStateOf(Drafts.text[target.chatId] ?: "") }
    var replyTo by remember(target.chatId) { mutableStateOf<Message?>(null) }
    var editing by remember(target.chatId) { mutableStateOf<Message?>(null) }
    var pendingImages by remember(target.chatId) { mutableStateOf<List<String>>(Drafts.images[target.chatId] ?: emptyList()) }
    var viewOnceOn by remember(target.chatId) { mutableStateOf(false) }
    var voViewing by remember(target.chatId) { mutableStateOf<Message?>(null) }
    var voTick by remember(target.chatId) { mutableStateOf(0) }
    var multiLine by remember(target.chatId) { mutableStateOf(false) }
    var editIdx by remember(target.chatId) { mutableStateOf(-1) }
    var showPoll by remember(target.chatId) { mutableStateOf(false) }
    androidx.compose.runtime.LaunchedEffect(target.chatId) { com.aurachat.app.push.Notifs.clear(ctx, target.chatId) }
    var selected by remember(target.chatId) { mutableStateOf<Set<String>>(emptySet()) }
    androidx.compose.runtime.SideEffect { ChatBar.sel = selected.isNotEmpty() }
    var showAttach by remember { mutableStateOf(false) }
    var attachClosing by remember { mutableStateOf(false) }
    var attachInstant by remember { mutableStateOf(false) }
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val inputFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    val kbOpen = remember { booleanArrayOf(false) }
    val entryStamp = remember { System.currentTimeMillis() }
    // Sohbete hangi yoldan girilirse girilsin (arama, avatar, bildirim...) klavye kendiliğinden açılmasın
    androidx.compose.runtime.LaunchedEffect(target.chatId) {
        keyboard?.hide(); focusManager.clearFocus()
        kbOpen[0] = false
        kotlinx.coroutines.delay(150)
        keyboard?.hide()
        kbOpen[0] = false
    }
    // klavye kapalıyken uygulamaya dönünce kendiliğinden açılmasın (odak bırakılır); açıkken arka plana atılırsa dönüşte yine açık gelsin
    val kbNowRef = remember { intArrayOf(0) }
    val resumeAt = remember { longArrayOf(0L) }
    var resumeHold by remember { mutableStateOf(false) }
    DisposableEffect(lifecycleOwner) {
        val ob = androidx.lifecycle.LifecycleEventObserver { _, e ->
            // klavye açıkken arka plana gidilirse sistem klavyeyi kapatıp geri açar; bu sırada giriş çubuğu aşağı inip çıkmasın diye yüksekliği tutulur
            if (e == Lifecycle.Event.ON_PAUSE && kbOpen[0]) resumeHold = true
            if (e == Lifecycle.Event.ON_RESUME) {
                resumeAt[0] = System.currentTimeMillis()
                if (resumeHold) scope.launch { kotlinx.coroutines.delay(1500); resumeHold = false }
            }
            if (e == Lifecycle.Event.ON_STOP && !kbOpen[0]) { try { focusManager.clearFocus() } catch (ex: Throwable) { com.aurachat.app.AuraLog.e("ChatScreen", ex) } }
            // sohbete girişteki ilk 1,5 saniyede klavye geri açılmaz (aramadan gelirken klavye açık görünüyordu)
            if (e == Lifecycle.Event.ON_RESUME && kbOpen[0] && System.currentTimeMillis() - entryStamp > 1500L) {
                // sistem klavyeyi kendisi geri getirir; yalnızca gelmediyse elle aç (çifte açma titreme yapıyordu)
                scope.launch {
                    kotlinx.coroutines.delay(700)
                    if (kbNowRef[0] <= 0 && kbOpen[0]) {
                        try { inputFocus.requestFocus(); keyboard?.show() } catch (ex: Throwable) { com.aurachat.app.AuraLog.e("ChatScreen", ex) }
                    }
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(ob)
        onDispose { lifecycleOwner.lifecycle.removeObserver(ob) }
    }
    var lastPendingCount by remember(target.chatId) { mutableStateOf(pendingImages.size) }
    androidx.compose.runtime.LaunchedEffect(pendingImages.size) {
        if (pendingImages.size > lastPendingCount) {
            kotlinx.coroutines.delay(250)
            try { inputFocus.requestFocus(); keyboard?.show() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatScreen", e) }
        }
        lastPendingCount = pendingImages.size
    }
    // alıntı yapılınca klavye hemen açık gelsin
    androidx.compose.runtime.LaunchedEffect(replyTo?.id) {
        if (replyTo != null) {
            // gecikme yok: alıntı şeridi ile klavye aynı anda gelsin
            try { inputFocus.requestFocus(); keyboard?.show() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatScreen", e) }
        }
    }
    val kbNow = (WindowInsets.ime.getBottom(density) - WindowInsets.navigationBars.getBottom(density)).coerceAtLeast(0)
    kbNowRef[0] = kbNow
    if (resumed && kbNow > 0) kbOpen[0] = true
    // klavye kullanıcı tarafından kapatıldıysa (geri/kaydırma) açık sayılmasın: odak yoksa kapalı
    if (resumed && kbNow == 0 && System.currentTimeMillis() - resumeAt[0] > 1500L) kbOpen[0] = false
    val minSheetPx = with(density) { 300.dp.roundToPx() }
    val minKbPx = with(density) { 150.dp.roundToPx() }
    var lastKb by remember { mutableIntStateOf(Repo.savedKbPx().takeIf { it > minKbPx } ?: with(density) { 260.dp.roundToPx() }) }
    // klavye tam açılıp oturunca yüksekliğini hatırla (panel aynı yüksekliği alır)
    LaunchedEffect(kbNow) {
        if (kbNow > minKbPx) {
            delay(150)
            lastKb = kbNow
            Repo.saveKbPx(kbNow)
        }
    }
    // Girişe dokunulunca klavye tam açılınca panel kapanır (arada toplam yükseklik sabit kalır)
    LaunchedEffect(attachClosing, kbNow) {
        if (attachClosing && kbNow > minKbPx) {
            delay(90) // klavye yüksekliği oturdu
            lastKb = kbNow
            Repo.saveKbPx(kbNow)
            attachInstant = true
            showAttach = false
            attachClosing = false
        }
    }
    LaunchedEffect(attachClosing) {
        if (attachClosing) {
            delay(800)
            attachInstant = true
            showAttach = false
            attachClosing = false
        }
    }
    // Panel yüksekliği: yukarı kayarak açılır, aşağı kayarak kapanır (klavyeye geçişte anında kapanır)
    val panelFullPx = lastKb
    val screenHpx = with(density) { androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp.dp.toPx() }
    val halfPx = (screenHpx * 0.55f).coerceAtLeast(panelFullPx * 1.3f)
    val panelAnim = remember { androidx.compose.animation.core.Animatable(0f) }
    var panelDragging by remember { mutableStateOf(false) }
    var panelExpanded by remember { mutableStateOf(false) }
    LaunchedEffect(showAttach, attachInstant, panelFullPx) {
        if (panelDragging) return@LaunchedEffect
        if (showAttach) {
            if (attachInstant) panelAnim.snapTo(panelFullPx.toFloat())
            else panelAnim.animateTo(
                if (panelExpanded) panelAnim.value.coerceAtLeast(panelFullPx.toFloat()) else panelFullPx.toFloat(),
                androidx.compose.animation.core.tween(320, easing = androidx.compose.animation.core.FastOutSlowInEasing)
            )
        } else {
            panelExpanded = false
            if (attachInstant) panelAnim.snapTo(0f)
            else panelAnim.animateTo(0f, androidx.compose.animation.core.tween(260, easing = androidx.compose.animation.core.FastOutSlowInEasing))
        }
    }
    val panelPx = panelAnim.value.toInt()
    val pProg = if (halfPx > panelFullPx) ((panelAnim.value - panelFullPx) / (halfPx - panelFullPx)).coerceIn(0f, 1f) else 0f
    var inputHpx by remember { mutableIntStateOf(with(density) { 56.dp.roundToPx() }) }
    // Panelin çıkabileceği en yüksek yükseklik: üst çubuğun hemen altına kadar (hızlı itince üstüne çıkmasın)
    var panelMaxPx by remember { mutableFloatStateOf(0f) }
    var colHpx by remember { mutableFloatStateOf(0f) }
    var galSel by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var galCaption by remember { mutableStateOf("") }
    var galHd by remember { mutableStateOf(false) }
    val galEdited = remember { androidx.compose.runtime.mutableStateMapOf<Uri, String>() }
    var galEditSrc by remember { mutableStateOf<Pair<Uri, String>?>(null) }
    var confirmDiscard by remember { mutableStateOf(false) }
    // Taslak: yazı/resim bırakıp çıkınca sohbet listesinde "Taslak:" görünür, tekrar girince geri gelir
    LaunchedEffect(text, pendingImages, editing) { if (editing == null) Drafts.set(target.chatId, text, pendingImages) }
    androidx.compose.runtime.DisposableEffect(target.chatId) { onDispose { ReadMore.open.clear() } }
    var oncePop by remember { mutableStateOf(false) }
    LaunchedEffect(oncePop) { if (oncePop) { delay(2000); oncePop = false } }
    // Geri / X / aşağı çekip kapatma: seçimler ve açıklama temizlenir, klavye de kapanır (onay sorulmaz)
    val closeSheet: () -> Unit = {
        galSel = emptyList(); galEdited.clear(); galCaption = ""; galHd = false; viewOnceOn = false
        focusManager.clearFocus(); keyboard?.hide()
        attachInstant = false; showAttach = false; attachClosing = false
    }
    LaunchedEffect(galSel) {
        val one = galSel.size == 1 && !(ctx.contentResolver.getType(galSel[0]) ?: "").startsWith("video")
        if (showAttach && !one) viewOnceOn = false
    }
    LaunchedEffect(showAttach) { if (!showAttach) { galSel = emptyList(); galCaption = ""; galHd = false; galEdited.clear() } }
    LaunchedEffect(galSel.isNotEmpty()) {
        if (galSel.isNotEmpty() && showAttach && panelAnim.value < halfPx - 4f) {
            panelExpanded = true
            panelAnim.animateTo(halfPx, androidx.compose.animation.core.tween(260, easing = androidx.compose.animation.core.FastOutSlowInEasing))
        }
    }
    // panel ile klavye aynı alanı paylaşır: alttaki boşluk ikisinden büyük olanı kadardır
    val kbLay = if (resumeHold && kbNow < lastKb) lastKb else kbNow
    val bottomGapPx = (kbLay - panelPx).coerceAtLeast(0)
    var showDelete by remember { mutableStateOf(false) }
    var viewer by remember { mutableStateOf<Pair<List<String>, Int>?>(null) }
    var viewerMsg by remember { mutableStateOf<Message?>(null) }
    var viewerEditSrc by remember { mutableStateOf<String?>(null) }
    var viewerCropUri by remember { mutableStateOf<Uri?>(null) }
    var busy by remember { mutableStateOf(false) }

    // yazıyor bilgisi
    var typingSent by remember { mutableStateOf(false) }
    LaunchedEffect(text, resumed) {
        if (resumed && text.isNotBlank() && editing == null) {
            if (!typingSent) {
                Repo.setTyping(me.uid, target, true)
                typingSent = true
            }
            delay(3000)
            Repo.setTyping(me.uid, target, false)
            typingSent = false
        } else if (typingSent) {
            Repo.setTyping(me.uid, target, false)
            typingSent = false
        }
    }
    DisposableEffect(target.chatId) {
        onDispose { if (typingSent) Repo.setTyping(me.uid, target, false) }
    }

    fun clearSelection() { selected = emptySet() }

    BackHandler(enabled = selected.isNotEmpty() || replyTo != null || editing != null) {
        when {
            selected.isNotEmpty() -> clearSelection()
            editing != null -> { editing = null; text = "" }
            else -> replyTo = null
        }
    }

    BackHandler(enabled = showAttach) {
        if (galSel.isNotEmpty()) {
            // Seçim varsa ilk geri sadece seçimleri ve açıklama çubuğunu kaldırır; sonra tam/yarım boy normale düşer; normaldeyken geri paneli kapatır
            galSel = emptyList(); galEdited.clear(); galCaption = ""; galHd = false; viewOnceOn = false
            focusManager.clearFocus(); keyboard?.hide()
        } else if (panelAnim.value > panelFullPx + 4f) {
            scope.launch {
                panelExpanded = false
                panelAnim.animateTo(panelFullPx.toFloat(), androidx.compose.animation.core.tween(240, easing = androidx.compose.animation.core.FastOutSlowInEasing))
            }
        } else closeSheet()
    }

    fun replyRefOf(): ReplyRef? = replyTo?.let {
        ReplyRef(it.id, it.senderName.ifBlank { "Kullanıcı" }, Repo.previewOf(it).take(100), it.senderUid)
    }

    // ---------- Etiketleme (@) ----------
    val mGroup by remember(target.chatId) {
        if (target.isGroup) Repo.groupFlow(target.chatId) else kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.GroupData?>(null)
    }.collectAsState(null as com.aurachat.app.data.GroupData?)
    val mNames by androidx.compose.runtime.produceState<Map<String, String>>(emptyMap(), mGroup?.members) {
        value = (mGroup?.members ?: emptyList()).filter { it != me.uid }.associateWith { u -> Repo.profileOf(u).name }
    }
    val chosenMentions = remember(target.chatId) { androidx.compose.runtime.mutableStateMapOf<String, String>() }
    val mentionMatch = remember(text) { Regex("(^|\\s)@([^@\\n]{0,30})$").find(text) }
    val mentionList: List<Pair<String, String>> = if (!target.isGroup || mentionMatch == null) emptyList() else {
        val q = mentionMatch.groupValues[2].lowercase()
        (listOf("*" to "Herkes") + mNames.entries.filter { it.value.isNotBlank() }.map { it.key to it.value })
            .filter { q.isEmpty() || it.second.lowercase().contains(q) }.take(30)
    }

    // Yapıştırılan bağlantının önizlemesi (gönderilmeden önce girişte görünür)
    var dismissedUrl by remember(target.chatId) { mutableStateOf("") }
    var linkPrev by remember(target.chatId) { mutableStateOf<com.aurachat.app.data.LinkPreview?>(null) }
    val inputUrl = remember(text) {
        Regex("https?://[^\\s<>\"']+", RegexOption.IGNORE_CASE).find(text)?.value?.trimEnd('.', ',', ';', ':', '!', '?', ')', ']')
    }
    LaunchedEffect(inputUrl) {
        if (inputUrl == null) { linkPrev = null }
        else if (linkPrev?.url != inputUrl) {
            delay(500)
            linkPrev = try { Repo.fetchLinkPreview(inputUrl) } catch (e: Throwable) { null }
        }
    }
    val shownLink = if (inputUrl != null && inputUrl != dismissedUrl && linkPrev?.url == inputUrl && editing == null && pendingImages.isEmpty()) linkPrev else null

    // ---------- Gönder ----------
    fun send() {
        val t = text.trim()
        val ed = editing
        if (ed != null) {
            if (t.isNotEmpty() && t != ed.text) Repo.editText(target.chatId, ed.id, t)
            editing = null
            text = ""
            return
        }
        if (pendingImages.isNotEmpty()) {
            val imgs = pendingImages
            if (imgs.sumOf { it.length } > 900_000) {
                toast(ctx, "Fotoğraflar çok büyük, daha az seç")
                return
            }
            val r = replyRefOf()
            val vo = viewOnceOn && imgs.size == 1
            pendingImages = emptyList()
            viewOnceOn = false
            text = ""
            replyTo = null
            launchSafe { Repo.sendImages(me, target, imgs, t, r, vo) }
            return
        }
        if (t.isEmpty()) return
        val r = replyRefOf()
        text = ""
        replyTo = null
        val mUids = ArrayList<String>()
        val mLabels = ArrayList<String>()
        chosenMentions.forEach { (name, uid) ->
            if (Regex("(^|\\s)@" + Regex.escape(name) + "(?=$|[\\s.,;:!?)])").containsMatchIn(t)) {
                if (uid == "*") mNames.keys.forEach { if (!mUids.contains(it)) mUids.add(it) }
                else if (!mUids.contains(uid)) mUids.add(uid)
                if (!mLabels.contains(name)) mLabels.add(name)
            }
        }
        chosenMentions.clear()
        val lpSend = shownLink
        val noLp = inputUrl != null && inputUrl == dismissedUrl
        dismissedUrl = ""
        launchSafe { Repo.sendText(me, target, t, r, mUids, mLabels, lpSend, noLp) }
    }

    // ---------- Medya seçiciler ----------
    fun addImages(uris: List<Uri>, hd: Boolean = false, edited: Map<Uri, String> = emptyMap()) {
        if (uris.isEmpty()) return
        scope.launch {
            busy = true
            val multi = uris.size > 1 || pendingImages.isNotEmpty()
            val limitBytes = if (hd) (if (multi) 260 * 1024 else 640 * 1024) else (if (multi) 150 * 1024 else 300 * 1024)
            val out = withContext(Dispatchers.IO) { uris.mapNotNull { edited[it] ?: Media.compress(ctx, it, limitBytes) } }
            pendingImages = (pendingImages + out).take(5)
            busy = false
            if (out.size < uris.size) toast(ctx, "Bazı fotoğraflar okunamadı")
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(5)) { uris ->
        addImages(uris)
    }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = cameraUri
        if (ok && u != null) addImages(listOf(u))
    }
    fun sendVideoUri(u: Uri) {
        launchSafe {
            busy = true
            val v = withContext(Dispatchers.IO) { Media.readVideo(ctx, u) }
            busy = false
            if (v == null) {
                toast(ctx, "Video çok büyük (en fazla 640 KB, yaklaşık 5 sn). Daha kısa çek ya da küçült.")
            } else {
                val r = replyRefOf()
                replyTo = null
                Repo.sendVideo(me, target, v, r)
            }
        }
    }
    val videoPickLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) sendVideoUri(uri)
    }
    var videoCaptureUri by remember { mutableStateOf<Uri?>(null) }
    val videoCaptureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val u = videoCaptureUri
        if (r.resultCode == android.app.Activity.RESULT_OK && u != null) sendVideoUri(u)
    }
    val docLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            launchSafe {
                busy = true
                val f = withContext(Dispatchers.IO) { Media.readDocument(ctx, uri) }
                busy = false
                if (f == null) {
                    toast(ctx, "Belge okunamadı ya da 700 KB'tan büyük")
                } else {
                    val r = replyRefOf()
                    replyTo = null
                    Repo.sendDocument(me, target, f.name, f.mime, f.dataUrl, r)
                }
            }
        }
    }

    fun sendLocationNow() {
        scope.launch {
            toast(ctx, "Konum alınıyor…")
            try {
                val client = LocationServices.getFusedLocationProviderClient(ctx)
                val loc = client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
                    ?: client.lastLocation.await()
                if (loc == null) {
                    toast(ctx, "Konum alınamadı")
                } else {
                    val r = replyRefOf()
                    replyTo = null
                    Repo.sendLocation(me, target, loc.latitude, loc.longitude, r)
                }
            } catch (e: Throwable) {
                toast(ctx, "Konum alınamadı")
            }
        }
    }
    val locPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) sendLocationNow() else toast(ctx, "Konum izni gerekli")
    }

    // ---------- Ses kaydı ----------
    val recorder = remember { VoiceRecorder(ctx) }
    var recording by remember { mutableStateOf(false) }
    var recSec by remember { mutableIntStateOf(0) }
    var recPaused by remember { mutableStateOf(false) }
    val recAmps = remember { androidx.compose.runtime.mutableStateListOf<Float>() }

    fun finishRecording(send: Boolean) {
        recording = false
        recPaused = false
        if (!send) {
            recorder.cancel()
            return
        }
        val res = recorder.stop()
        if (res == null) {
            toast(ctx, "Kayıt çok kısa")
            return
        }
        val (file, sec) = res
        val r = replyRefOf()
        replyTo = null
        launchSafe {
            val data = withContext(Dispatchers.IO) { Media.fileToDataUrl(file, "audio/mp4") }
            file.delete()
            if (data.length > 950_000) toast(ctx, "Ses kaydı çok uzun") else Repo.sendAudio(me, target, data, sec, r)
        }
    }

    fun startRecording() {
        if (recorder.start()) {
            recSec = 0
            recAmps.clear()
            recPaused = false
            recording = true
        } else {
            toast(ctx, "Kayıt başlatılamadı")
        }
    }
    val micPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording() else toast(ctx, "Mikrofon izni gerekli")
    }
    LaunchedEffect(recording) {
        while (recording) {
            delay(100)
            recSec = recorder.elapsedSec()
            if (!recPaused) {
                recAmps.add(recorder.level())
                if (recAmps.size > 400) recAmps.removeRange(0, recAmps.size - 400)
            }
            if (recSec >= 119) {
                finishRecording(true)
            }
        }
    }
    DisposableEffect(Unit) { onDispose { recorder.cancel() } }

    // ---------- Üç nokta menüsü durumu ----------
    val chatFlags by remember(target.chatId) { Repo.chatFlagsFlow(me.uid, target.chatId) }
        .collectAsState(Repo.ChatFlags(false, false, false))
    val disappearMs by remember(target.chatId) { Repo.disappearFlow(target.chatId) }.collectAsState(0L)
    val blockedList by remember(me.uid) { Repo.blockedFlow(me.uid) }.collectAsState(emptyList())
    val otherBlocked = !target.isGroup && blockedList.contains(target.otherUid)
    val theirBlockList by remember(target.otherUid, target.isGroup) {
        if (target.isGroup) kotlinx.coroutines.flow.flowOf(emptyList<String>()) else Repo.blockedFlow(target.otherUid)
    }.collectAsState(emptyList())
    val blockedByThem = !target.isGroup && theirBlockList.contains(me.uid)
    val chatBlocked = otherBlocked || blockedByThem
    var showDisappear by remember { mutableStateOf(false) }
    var showWipe by remember { mutableStateOf(false) }
    var showReport by remember { mutableStateOf(false) }
    var pinAsk by remember { mutableStateOf<Message?>(null) }

    // ---------- Liste durumu ----------
    val listState = rememberLazyListState()
    val atBottom by remember { derivedStateOf { listState.firstVisibleItemIndex <= 1 } }
    val newestId = visible.firstOrNull()?.id
    val newestMine = visible.firstOrNull()?.senderUid == me.uid
    // Mesaj telefondaki kayıtta yoksa hiç beklenmez / liste gizlenmez
    val jumpKnown = remember(target.chatId, jumpToMsgId) { jumpToMsgId != null && com.aurachat.app.data.LocalDb.countFrom(target.chatId, jumpToMsgId) > 0 }
    var jumpPending by remember(target.chatId, jumpToMsgId) { mutableStateOf(jumpKnown) }
    var jumpHide by remember(target.chatId, jumpToMsgId) { mutableStateOf(jumpKnown) }
    var highlightId by remember(target.chatId) { mutableStateOf<String?>(null) }
    LaunchedEffect(highlightId) {
        if (highlightId != null) { delay(1600); highlightId = null }
    }
    suspend fun centerOn(idx: Int) {
        listState.scrollToItem(idx)
        val info = listState.layoutInfo
        val sz = info.visibleItemsInfo.firstOrNull { it.index == idx }?.size ?: 0
        listState.scrollToItem(idx, -((info.viewportSize.height - sz) / 2).coerceAtLeast(0))
    }
    var quoteWanted by remember(target.chatId) { mutableStateOf<String?>(null) }
    fun showInChat(id: String) {
        val idx = visible.indexOfFirst { it.id == id }
        if (idx >= 0) scope.launch {
            centerOn(idx)
            highlightId = id
        }
    }
    // Alıntılanan mesaj henüz yüklenmemişse bulunana kadar eski mesajlar kademeli yüklenir (sınır yok)
    LaunchedEffect(quoteWanted, raw.size, visible.size, limit) {
        val id = quoteWanted ?: return@LaunchedEffect
        val i = visible.indexOfFirst { it.id == id }
        if (i >= 0) { quoteWanted = null; showInChat(id) }
        else if (raw.size >= limit) limit += 400
        else { delay(1500); if (visible.none { it.id == id }) { toast(ctx, "Mesaj bulunamadı (silinmiş olabilir)"); quoteWanted = null } }
    }
    LaunchedEffect(jumpPending, raw.size, visible.size, limit) {
        val id = jumpToMsgId
        if (jumpPending && id != null) {
            val idx = visible.indexOfFirst { it.id == id }
            if (idx >= 0) {
                centerOn(idx)
                jumpHide = false
                highlightId = id
                for (round in 0 until 3) {
                    delay(220)
                    val i2 = visible.indexOfFirst { it.id == id }.coerceAtLeast(0)
                    val info = listState.layoutInfo
                    val vh = info.viewportSize.height
                    val sz = info.visibleItemsInfo.firstOrNull { it.index == i2 }?.size ?: 0
                    // ters listede negatif ofset öğeyi ekranda yukarı alır → ortada göster
                    listState.scrollToItem(i2, -((vh - sz) / 2).coerceAtLeast(0))
                }
                // kaydırma bitmeden "en alta git" davranışları devreye girmesin
                jumpPending = false
            } else if (raw.size >= limit) {
                limit += 300
            } else {
                // Liste henüz bu sınır için yüklenmedi (önbellekteki kısa liste geldi): yeni veri gelene kadar bekle.
                // Yeni veri gelirse bu blok iptal olup baştan çalışır; gelmezse vazgeç.
                delay(5000)
                if (visible.none { it.id == id }) { jumpHide = false; jumpPending = false }
            }
        }
    }

    // ---------- Sohbet içi arama ----------
    var videoMsg by remember(target.chatId) { mutableStateOf<Message?>(null) }
    var showVideoChoice by remember { mutableStateOf(false) }
    val startShare = rememberScreenShareStarter { c, d ->
        val cu = CallManager.ui.value
        if (cu.phase != com.aurachat.app.call.Phase.IDLE && cu.video) CallManager.startScreenShare(c, d)
        else { CallManager.pendingShare = c to d; onCall(true) }
    }
    var reactionsMsgId by remember(target.chatId) { mutableStateOf<String?>(null) }
    var callSheet by remember(target.chatId) { mutableStateOf<Message?>(null) }
    var memberSheet by remember(target.chatId) { mutableStateOf<UserProfile?>(null) }
    var searching by remember(target.chatId, startSearch) { mutableStateOf(startSearch) }
    var searchQ by remember(target.chatId) { mutableStateOf("") }
    var matchIdx by remember(target.chatId) { mutableIntStateOf(0) }
    val matches = remember(visible, searchQ) {
        if (searchQ.isBlank()) emptyList()
        else visible.filter { !it.deleted && it.type != "system" && it.text.contains(searchQ, ignoreCase = true) }
    }
    val curMatchId = if (searching) matches.getOrNull(matchIdx)?.id else null
    LaunchedEffect(searchQ) { matchIdx = 0 }
    // Aramadayken geri tuşu klavyeyi kapatır: klavye kapanınca arama çubuğu da kapansın, mesaj kutusu geri gelsin
    val imeBottomPx = WindowInsets.ime.getBottom(androidx.compose.ui.platform.LocalDensity.current)
    var hadIme by remember(searching) { mutableStateOf(false) }
    LaunchedEffect(imeBottomPx, searching) {
        if (searching) {
            if (imeBottomPx > 0) hadIme = true
            else if (hadIme) { searching = false; searchQ = "" }
        }
    }
    LaunchedEffect(curMatchId) {
        val id = curMatchId ?: return@LaunchedEffect
        val i = visible.indexOfFirst { it.id == id }
        if (i >= 0) centerOn(i)
    }
    // Eski mesajlar: listenin en üstüne yaklaşınca otomatik yüklenir (düğme yok)
    val nearTop by remember { derivedStateOf { (listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0) >= listState.layoutInfo.totalItemsCount - 4 } }
    LaunchedEffect(nearTop, raw.size, limit) {
        if (nearTop && raw.size >= limit && !jumpPending) limit += 50
    }
    var newBelow by remember(target.chatId) { mutableIntStateOf(0) }
    LaunchedEffect(atBottom) { if (atBottom) newBelow = 0 }
    LaunchedEffect(newestId) {
        if (newestId != null && !atBottom && !newestMine && !jumpPending) newBelow++
    }
    LaunchedEffect(newestId) {
        if (!jumpPending && newestId != null && (atBottom || newestMine)) listState.animateScrollToItem(0)
    }
    // Sohbet ortadayken o sohbetin bildirimine dokunulursa en yeni mesajlara git (WhatsApp gibi)
    val chatPing = com.aurachat.app.AppState.chatPing.intValue
    var seenPing by remember { mutableIntStateOf(chatPing) }
    LaunchedEffect(chatPing) {
        if (chatPing != seenPing) { seenPing = chatPing; listState.scrollToItem(0) }
    }
    // "yazıyor" balonu en alta eklenince liste eski konumda kalıp balonu aşağıda gizlemesin
    val someoneTyping = otherTyping || groupTyping.isNotEmpty()
    LaunchedEffect(someoneTyping) {
        if (someoneTyping && !jumpPending && listState.firstVisibleItemIndex <= 1) listState.animateScrollToItem(0)
    }

    val selectedMsgs = visible.filter { selected.contains(it.id) }.sortedBy { effTime(it) }
    val single = if (selectedMsgs.size == 1) selectedMsgs[0] else null
    var selTopRoot by remember { mutableFloatStateOf(0f) }
    var listTopRoot by remember { mutableFloatStateOf(0f) }
    var listHpx by remember { mutableFloatStateOf(0f) }
    var listWpx by remember { mutableFloatStateOf(0f) }
    var touchPos by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    var reactBarW by remember { mutableFloatStateOf(0f) }
    var colTopRoot by remember { mutableFloatStateOf(0f) }
    panelMaxPx = (colTopRoot + colHpx - listTopRoot - inputHpx).coerceAtLeast(panelFullPx.toFloat())
    var dragStartPx by remember { mutableFloatStateOf(0f) }
    var dragActive by remember { mutableStateOf(false) }
    val sheetDrag = androidx.compose.foundation.gestures.rememberDraggableState { delta ->
        if (!dragActive) { dragStartPx = panelAnim.value; dragActive = true }
        val maxPx = panelMaxPx.coerceAtLeast(panelFullPx.toFloat())
        scope.launch { panelAnim.snapTo((panelAnim.value - delta).coerceIn(0f, maxPx)) }
    }
    val settle: (Float) -> Unit = { vel ->
        val normal = panelFullPx.toFloat()
        val maxPx = panelMaxPx.coerceAtLeast(normal)
        val half = halfPx.coerceAtMost(maxPx)
        val proj = panelAnim.value - vel * 0.12f
        // Parmakla itince sadece iki duruş var: normal ve tam boy (yarım boy yalnızca resim seçilince kendiliğinden açılır).
        // Küçük bir itiş bile diğer duruşa geçirir; normalin altına belirgin inince kapanır.
        val start = dragStartPx
        val span = (maxPx - normal).coerceAtLeast(1f)
        val d = proj - start
        val target = when {
            proj < normal * 0.55f -> 0f
            d > span * 0.07f -> maxPx
            d < -span * 0.07f -> normal
            start > (normal + maxPx) / 2f -> maxPx
            else -> normal
        }
        dragActive = false
        scope.launch {
            if (galSel.isNotEmpty() && (target <= 0f || target < start - 1f)) {
                // Seçili resim varken aşağı çekince (tam / yarım / normalden): panel normale iner ve "Seçim yok sayılsın mı?" sorulur
                confirmDiscard = true
                panelExpanded = false
                panelAnim.animateTo(normal, androidx.compose.animation.core.tween(200, easing = androidx.compose.animation.core.FastOutSlowInEasing))
                panelDragging = false
            } else if (target <= 0f) {
                panelDragging = false
                closeSheet()
            } else {
                panelExpanded = target > normal
                panelAnim.animateTo(target, androidx.compose.animation.core.tween(240, easing = androidx.compose.animation.core.FastOutSlowInEasing))
                panelDragging = false
            }
        }
    }
    val sheetNested = remember {
        object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
                if (available.y < 0f) {
                    val maxPx = panelMaxPx.coerceAtLeast(panelFullPx.toFloat())
                    if (panelAnim.value < maxPx - 1f) {
                        panelDragging = true
                        sheetDrag.dispatchRawDelta(available.y)
                        return androidx.compose.ui.geometry.Offset(0f, available.y)
                    }
                } else if (available.y > 0f && panelDragging) {
                    sheetDrag.dispatchRawDelta(available.y)
                    return androidx.compose.ui.geometry.Offset(0f, available.y)
                }
                return androidx.compose.ui.geometry.Offset.Zero
            }
            override fun onPostScroll(consumed: androidx.compose.ui.geometry.Offset, available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
                if (available.y > 0f) {
                    panelDragging = true
                    sheetDrag.dispatchRawDelta(available.y)
                    return androidx.compose.ui.geometry.Offset(0f, available.y)
                }
                return androidx.compose.ui.geometry.Offset.Zero
            }
            override suspend fun onPreFling(available: androidx.compose.ui.unit.Velocity): androidx.compose.ui.unit.Velocity {
                if (panelDragging) {
                    settle(available.y)
                    return androidx.compose.ui.unit.Velocity(0f, available.y)
                }
                return androidx.compose.ui.unit.Velocity.Zero
            }
        }
    }
    val sheetModifier = Modifier.draggable(
        state = sheetDrag, orientation = androidx.compose.foundation.gestures.Orientation.Vertical,
        onDragStarted = { panelDragging = true },
        onDragStopped = { vel -> settle(vel) }
    )

    Box(Modifier.fillMaxSize()) {

    // ---------- Arayüz ----------
    Column(
        Modifier
            .fillMaxSize()
            .themeBackground(theme)
            .navigationBarsPadding()
            .padding(bottom = with(density) { bottomGapPx.toDp() })
            .onGloballyPositioned { colTopRoot = it.positionInRoot().y; colHpx = it.size.height.toFloat() }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                        val d = e.changes.firstOrNull { it.pressed && !it.previousPressed }
                        if (d != null && selected.isNotEmpty() && colTopRoot + d.position.y > listTopRoot + listHpx) selected = emptySet()
                    }
                }
            }
    ) {
        // Durum çubuğu alanı: üst çubukla aynı siyah (tema rengi sadece sohbet zemininde)
        Spacer(Modifier.fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars).background(ChatBar.tint ?: if (selected.isNotEmpty()) AuraSelBar else AuraBlack))
        if (searching) {
            ChatSearchBar(
                searchQ, { searchQ = it }, matches.size, matchIdx,
                onClose = { searching = false; searchQ = "" },
                onPrev = { if (matchIdx < matches.size - 1) matchIdx++ },
                onNext = { if (matchIdx > 0) matchIdx-- }
            )
        } else if (selected.isNotEmpty()) {
            ChatSelectionBar(
                selected.size, single, selectedMsgs, starredKeys, me, target,
                onClear = { clearSelection() },
                onReply = { m -> replyTo = m; editing = null; clearSelection() },
                onDelete = { showDelete = true },
                onForward = { onForward(selectedMsgs); clearSelection() },
                onEdit = { m -> editing = m; text = m.text; replyTo = null; clearSelection() },
                onPin = { m, pin -> if (pin) { pinAsk = m } else { Repo.pinMessage(target.chatId, m.id, false); clearSelection() } },
                onReport = { clearSelection(); showReport = true }
            )
        } else {
            ChatHeaderRow(
                me, target, onBack, onOpenGroupInfo, onCall, onOpenTheme,
                otherTyping, chatBlocked, otherBlocked, chatFlags, disappearMs,
                onSearch = { searching = true }, onDisappear = { showDisappear = true }, onWipe = { showWipe = true }, onReport = { showReport = true },
                onNewGroup = onNewGroup, onOpenMedia = onOpenMedia, ringColor = accent,
                showAbout = rememberAboutVisible(listState),
                onExport = {
                    scope.launch {
                        val list = try { withContext(Dispatchers.IO) { Repo.messagesFlow(target.chatId, 1000).first() } } catch (e: Throwable) { emptyList() }
                        val fmt = java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale("tr"))
                        val sb = StringBuilder()
                        list.filter { !it.deleted && !it.deletedFor.contains(me.uid) && (clearedAt <= 0L || it.time <= 0L || it.time > clearedAt) }
                            .sortedBy { it.time }.forEach { m ->
                                val who = if (m.senderUid == me.uid) me.name else m.senderName.ifBlank { target.name }
                                val body = m.text.ifBlank { when (m.type) { "image" -> "<Resim>"; "audio" -> "<Ses>"; "video" -> "<Video>"; "file" -> "<Belge: ${m.fileName}>"; "location" -> "<Konum>"; else -> "<${m.type}>" } }
                                sb.append(fmt.format(java.util.Date(m.time))).append(" - ").append(who).append(": ").append(body).append('\n')
                            }
                        if (sb.isEmpty()) { toast(ctx, "Dışa aktarılacak mesaj yok"); return@launch }
                        try {
                            ctx.startActivity(Intent.createChooser(
                                Intent(Intent.ACTION_SEND).setType("text/plain")
                                    .putExtra(Intent.EXTRA_SUBJECT, "${target.name} ile sohbet")
                                    .putExtra(Intent.EXTRA_TEXT, sb.toString()),
                                "Sohbeti dışa aktar"
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (e: Throwable) { toast(ctx, "Dışa aktarılamadı") }
                    }
                }
            )
        }

        // Sabitlenmiş mesajlar: üst çubuğun altında ince bar (birden fazlaysa aşağı açılan liste)
        val pins = remember(visible) { visible.filter { it.pinned && !it.deleted && (it.pinUntil <= 0L || it.pinUntil > System.currentTimeMillis()) }.sortedByDescending { it.pinnedAt } }
        if (pins.isNotEmpty() && !searching) {
            PinnedBar(pins, me, target,
                onJump = { id ->
                    if (visible.any { it.id == id }) showInChat(id) else quoteWanted = id
                },
                onUnpin = { m -> Repo.pinMessage(target.chatId, m.id, false) })
        }

        // Mesajlar
        Box(Modifier.weight(1f).fillMaxWidth().clipToBounds().onGloballyPositioned { listTopRoot = it.positionInRoot().y; listHpx = it.size.height.toFloat(); listWpx = it.size.width.toFloat() }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                        e.changes.firstOrNull { it.pressed }?.let { touchPos = it.position }
                    }
                }
            }) {
            LazyColumn(
                state = listState,
                reverseLayout = true,
                verticalArrangement = Arrangement.Top,
                modifier = Modifier.fillMaxSize().graphicsLayer(alpha = if (jumpHide) 0f else 1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 12.dp, bottom = 1.dp)
            ) {
                if (otherTyping || groupTyping.isNotEmpty()) item(key = "typing-bubble") { TypingBubble(groupTyping.size, theme.theirs ?: AuraTheirs) }
                itemsIndexed(visible, key = { _, m -> m.id }) { i, m ->
                    val older = visible.getOrNull(i + 1)
                    val newDay = older == null || dayKey(effTime(older)) != dayKey(effTime(m))
                    val sameRunAsOlder = older != null && !newDay && older.type != "system" &&
                        older.senderUid == m.senderUid && !(m.id == unreadAnchorId && unreadAnchorCount > 0)
                    Column {
                        if (newDay) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 1.dp), contentAlignment = Alignment.Center) {
                                DayChip(dayLabel(effTime(m)))
                            }
                        }
                        if (m.id == unreadAnchorId && unreadAnchorCount > 0) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(accent.copy(alpha = 0.27f)), contentAlignment = Alignment.Center) {
                                Text("$unreadAnchorCount okunmamış mesaj", color = AuraWhite, fontSize = 12.sp, modifier = Modifier.padding(4.dp))
                            }
                        }
                        var swipeDx by remember(m.id) { mutableFloatStateOf(0f) }
                        val swipeMax = with(density) { 72.dp.toPx() }
                        val canSwipe = m.type != "system" && !m.deleted && !chatBlocked
                        Box(
                            Modifier.onGloballyPositioned { c -> if (single?.id == m.id) selTopRoot = c.positionInRoot().y }
                                .then(if (canSwipe) Modifier.pointerInput(m.id) {
                                    detectHorizontalDragGestures(
                                        onDragEnd = {
                                            if (swipeDx >= swipeMax * 0.8f && selected.isEmpty()) {
                                                replyTo = m; editing = null
                                                try { haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatScreen", e) }
                                            }
                                            swipeDx = 0f
                                        },
                                        onDragCancel = { swipeDx = 0f }
                                    ) { _, dx -> if (selected.isEmpty()) swipeDx = (swipeDx + dx).coerceIn(0f, listWpx.coerceAtLeast(swipeMax)) }
                                } else Modifier)
                        ) {
                        if (swipeDx > 8f) {
                            Box(
                                Modifier.align(Alignment.CenterStart)
                                    .offset { androidx.compose.ui.unit.IntOffset(kotlin.math.min(swipeDx - 38.dp.toPx(), 38.dp.toPx()).toInt(), 0) }
                                    .size(32.dp)
                                    .graphicsLayer { val f = (swipeDx / swipeMax).coerceIn(0f, 1f); alpha = f; scaleX = 0.6f + 0.4f * f; scaleY = 0.6f + 0.4f * f }
                                    .clip(CircleShape)
                                    .background(if (AuraUi.light) Color(0x59808080) else Color(0xD93B4448)),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.AutoMirrored.Filled.Reply, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
                        }
                        Box(Modifier.graphicsLayer(translationX = swipeDx)) {
                        MessageBubble(
                            m = m,
                            onForward = { onForward(listOf(m)) },
                            onReactionsClick = { reactionsMsgId = m.id },
                            onCallClick = { msg -> if (selected.isEmpty() && !target.isGroup) callSheet = msg },
                            tail = true,
                            me = me.uid,
                            swipeFade = { (swipeDx / swipeMax).coerceIn(0f, 1f) },
                            isGroup = target.isGroup,
                            onAvatarClick = {
                                memberSheet = Repo.peekProfile(m.senderUid) ?: UserProfile(m.senderUid, m.senderName, "", "", "")
                            },
                            groupAvatar = target.isGroup && m.senderUid != me.uid && !sameRunAsOlder,
                            groupSpace = target.isGroup && m.senderUid != me.uid && sameRunAsOlder,
                            mineColor = theme.bubble,
                            theirColor = theme.theirs ?: AuraTheirs,
                            starred = starredKeys.contains(Repo.starKey(target.chatId, m.id)),
                            selected = selected.contains(m.id) || curMatchId == m.id,
                            flash = highlightId == m.id,
                            flashColor = accent,
                            onClick = {
                                if (selected.isNotEmpty() && m.type != "system") {
                                    selected = if (selected.contains(m.id)) selected - m.id else selected + m.id
                                }
                            },
                            onLongClick = {
                                if (m.type != "system") selected = if (selected.contains(m.id)) selected - m.id else selected + m.id
                            },
                            quoteImage = m.replyTo?.let { rq0 ->
                                quoteThumbOf(visible.firstOrNull { it.id == rq0.msgId })
                            } ?: "",
                            onQuoteClick = { id ->
                                val idx = visible.indexOfFirst { it.id == id }
                                if (idx >= 0) showInChat(id) else quoteWanted = id
                            },
                            onOpenImages = { list, idx -> viewerMsg = m; viewer = Pair(list, idx) },
                            viewOnceSeen = voTick >= 0 && Repo.isViewOnceSeen(target.chatId, m.id),
                            onOpenViewOnce = { msg -> voViewing = msg },
                            onVote = { msg, optId -> if (selected.isEmpty()) Repo.votePoll(me.uid, target.chatId, msg, optId) },
                            onOpenDocument = { msg ->
                                if (msg.type == "video") { videoMsg = msg } else
                                try {
                                    val f = Media.sharableFile(ctx, msg.imageUrl, msg.fileName.ifBlank { "belge" })
                                    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                                    val i = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, msg.fileMime.ifBlank { "*/*" })
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    ctx.startActivity(i)
                                } catch (e: Throwable) {
                                    toast(ctx, "Bu belgeyi açacak uygulama yok")
                                }
                            },
                            onOpenLocation = { msg ->
                                try {
                                    val u = Uri.parse("geo:${msg.lat},${msg.lng}?q=${msg.lat},${msg.lng}")
                                    ctx.startActivity(Intent(Intent.ACTION_VIEW, u))
                                } catch (e: Throwable) {
                                    toast(ctx, "Harita uygulaması bulunamadı")
                                }
                            }
                        )
                        }
                        }
                    }
                }
            }
            if (single != null && !single.deleted && single.type != "system") {
                ReactionBar(
                    single, me, target, touchPos, listHpx, listWpx, reactBarW, { reactBarW = it }, theme.theirs ?: AuraTheirs,
                    { blk -> launchSafe(blk) }, { clearSelection() }
                )
            }
            ListOverlays(listState, visible, atBottom, newBelow, accent) { scope.launch { listState.scrollToItem(0) } }
        }

        val rep = if (searching || chatBlocked) null else replyTo

        if (busy) {
            Text("İşleniyor…", color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
        }

        // Giriş çubuğu (eski sürüm: siyah, yeşil çerçeveli kutu; + ve mikrofon/gönder içinde)
        if (chatBlocked && !searching) {
            Row(
                Modifier.fillMaxWidth().background(ChatBar.tint ?: AuraBlack).navigationBarsPadding().height(60.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (otherBlocked) {
                    val red = if (AuraUi.light) Color(0xFFC62840) else Color(0xFFEF4444)
                    Row(
                        Modifier.weight(1f).fillMaxHeight().clickable { showWipe = true },
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Delete, null, tint = red, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("Sohbeti sil", color = red, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    }
                    Row(
                        Modifier.weight(1f).fillMaxHeight().clickable { Repo.setBlocked(me.uid, target.otherUid, false); toast(ctx, "Engel kaldırıldı") },
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Block, null, tint = accent, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("Engeli kaldır", color = accent, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    }
                } else Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("Bu kişiyle mesajlaşamazsınız.", color = AuraMuted, fontSize = 14.sp)
                }
            }
        } else if (searching) {
        } else if (recording) {
            val panelBg = androidx.compose.ui.graphics.lerp(AuraSurface, accent, 0.10f)
            val pillBg = androidx.compose.ui.graphics.lerp(AuraSurface, accent, 0.24f)
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)).background(panelBg)
                    .padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 12.dp)
            ) {
                Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "%d:%02d".format(recSec / 60, recSec % 60),
                        color = AuraWhite, fontSize = 24.sp, modifier = Modifier.width(64.dp)
                    )
                    val barCol = AuraMuted
                    val dotCol = accent
                    androidx.compose.foundation.Canvas(Modifier.weight(1f).fillMaxHeight()) {
                        val step = 6.dp.toPx()
                        val bw = 3.dp.toPx()
                        val n = (size.width / step).toInt()
                        val cy = size.height / 2f
                        for (i in 0 until n) {
                            val idx = recAmps.size - 1 - (n - 1 - i)
                            val v = if (idx >= 0 && idx < recAmps.size) recAmps[idx] else -1f
                            val x = i * step + bw / 2f
                            if (v < 0f) {
                                drawCircle(barCol.copy(alpha = 0.5f), 1.5.dp.toPx(), androidx.compose.ui.geometry.Offset(x, cy))
                            } else {
                                val h = (4.dp.toPx() + v * (size.height - 4.dp.toPx())).coerceAtMost(size.height)
                                drawLine(barCol, androidx.compose.ui.geometry.Offset(x, cy - h / 2f), androidx.compose.ui.geometry.Offset(x, cy + h / 2f), bw, androidx.compose.ui.graphics.StrokeCap.Round)
                            }
                        }
                        if (recPaused) drawCircle(dotCol, 6.dp.toPx(), androidx.compose.ui.geometry.Offset(((n - 1) * step + bw / 2f).coerceAtLeast(0f), cy))
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(60.dp).clip(CircleShape).background(auraLc(0xFFEF4444).copy(alpha = 0.22f)).clickable { finishRecording(false) },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Delete, "İptal", tint = auraLc(0xFFEF4444), modifier = Modifier.size(28.dp)) }
                    Spacer(Modifier.width(10.dp))
                    Row(
                        Modifier.weight(1f).height(60.dp).clip(RoundedCornerShape(18.dp)).background(pillBg).clickable {
                            if (recPaused) { recorder.resume(); recPaused = false } else { recorder.pause(); recPaused = true }
                        },
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(if (recPaused) Icons.Default.Mic else Icons.Default.Pause, null, tint = AuraWhite, modifier = Modifier.size(26.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(if (recPaused) "Devam et" else "Duraklat", color = AuraWhite, fontSize = 19.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier.size(60.dp).clip(CircleShape).background(btnColor).clickable { finishRecording(true) },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.AutoMirrored.Filled.Send, "Gönder", tint = if (btnColor.luminance() < 0.5f) Color.White else Color(0xFF111B21), modifier = Modifier.size(28.dp)) }
                }
            }
        } else {
            val canSend = text.isNotBlank() || pendingImages.isNotEmpty()
            if (mentionList.isNotEmpty()) {
                MentionList(mentionList) { uid, name ->
                    val mm = mentionMatch
                    if (mm != null) {
                        val start = mm.range.first + mm.groupValues[1].length
                        text = text.substring(0, start) + "@" + name + " "
                        chosenMentions[name] = uid
                    }
                }
            }
            val boxShape = RoundedCornerShape(18.dp)
            val plusBtn: @Composable () -> Unit = {
                IconButton(onClick = {
                    if (showAttach) {
                        attachInstant = false
                        showAttach = false
                        attachClosing = false
                    } else {
                        // klavye açıksa panel klavyenin yerine anında oturur (kapanıp açılma hissi olmasın)
                        attachInstant = kbNow > minKbPx
                        attachClosing = false
                        showAttach = true
                        focusManager.clearFocus()
                        keyboard?.hide()
                    }
                }) {
                    val plusRot by androidx.compose.animation.core.animateFloatAsState(if (showAttach) 45f else 0f, androidx.compose.animation.core.tween(200), label = "plusRot")
                    Icon(Icons.Default.Add, "Ekle", tint = AuraWhite, modifier = Modifier.size(30.dp).graphicsLayer { rotationZ = plusRot })
                }
            }
            val sendBtn: @Composable () -> Unit = {
                Box(
                    modifier = Modifier.size(39.dp).clip(CircleShape).background(btnColor).clickable {
                        if (canSend) send() else {
                            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                startRecording()
                            } else {
                                micPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (canSend) Icons.Default.ArrowUpward else Icons.Default.Mic,
                        if (canSend) "Gönder" else "Ses kaydı",
                        tint = if (btnColor.luminance() < 0.5f) Color.White else Color(0xFF111B21),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            // Kapalıyken giriş kutusu kenarlardan boşluklu "yüzer"; klavye ya da "+" paneli açılınca boşluklar kalkar, kutu klavyeye/panele yapışır
            // Boşluklar zamanla değil klavye/panel yüksekliğiyle birlikte (aynı karede) kaybolur: gecikme, boşluk ve zıplama olmaz
            // klavye açıkken de kapalıyken olduğu gibi yüzer görünür; yalnızca "+" paneli açılınca panele yapışır
            val flushP = (panelPx.toFloat() / lastKb.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
            val navDp = with(density) { WindowInsets.navigationBars.getBottom(density).toDp().value }
            // WhatsApp ölçüsü: üstte mesajlara çok yakın (2 dp), yanlarda ve altta 6 dp. "+" paneli açılınca da aynı kalır (yapışmaz)
            val padH = 6.dp
            val padB = maxOf(0f, 6f - navDp).dp
            val padT = 2.dp
            val boxShapeAnim = RoundedCornerShape(18.dp)
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(start = padH, end = padH, top = padT, bottom = padB)
                    .clip(boxShapeAnim)
                    .background(AuraBlack)
                    .border(1.dp, inputBorder, boxShapeAnim)
            ) {
                if (rep != null) {
                    val repImg = if (rep.type == "image" && !rep.viewOnce && !rep.deleted) (rep.images.firstOrNull() ?: rep.imageUrl) else ""
                    val repPrev = Repo.previewOf(rep)
                    val repPhoto = repPrev.startsWith("\uD83D\uDCF7")
                    val repLiveName = liveProfile(rep.senderUid).value?.name?.takeIf { it.isNotBlank() }
                    val repShown = (repLiveName ?: rep.senderName).ifBlank { "Kullanıcı" }
                    // grupta kişinin adı rengi, birebirde sohbetin tema rengi (balondaki alıntıyla aynı)
                    val repColor = if (target.isGroup && rep.senderUid.isNotEmpty()) senderColor(rep.senderUid, repShown, 78) else accent
                    Box(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 8.dp)) {
                        QuoteCard(
                            repShown, repColor, repColor,
                            if (repPhoto) repPrev.removePrefix("\uD83D\uDCF7").trim() else repPrev, repPhoto, repImg,
                            auraLc(0xFF1A1A1A), 12.dp, 13f, 48.dp, endPad = 24.dp
                        )
                        Box(
                            Modifier.align(Alignment.TopEnd).padding(4.dp).size(22.dp).clip(CircleShape).background(auraLc(0x99000000))
                                .clickable { replyTo = null },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Close, "Kapat", tint = AuraWhite, modifier = Modifier.size(14.dp)) }
                    }
                }
                if (shownLink != null) {
                    val lk = shownLink
                    Box(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 8.dp)) {
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(auraLc(0xFF1A1A1A)).height(androidx.compose.foundation.layout.IntrinsicSize.Min)) {
                            if (lk.image.isNotBlank()) {
                                Box(Modifier.width(76.dp).fillMaxHeight().heightIn(min = 64.dp)) {
                                    LinkThumb(lk.image, WebHostIsVideo(lk.url), Modifier.matchParentSize())
                                }
                            }
                            Column(Modifier.weight(1f).padding(start = 10.dp, end = 30.dp, top = 8.dp, bottom = 8.dp)) {
                                if (lk.title.isNotBlank()) Text(lk.title, color = AuraWhite, fontSize = 13.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(
                                    try { android.net.Uri.parse(lk.url).host?.removePrefix("www.") ?: "" } catch (e: Throwable) { "" },
                                    color = auraLc(0xFF9AA5AB), fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                        }
                        Box(
                            Modifier.align(Alignment.TopEnd).padding(5.dp).size(22.dp).clip(CircleShape).background(auraLc(0x66000000))
                                .clickable { dismissedUrl = lk.url },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Close, "Kapat", tint = auraLc(0xFFB0BCC4), modifier = Modifier.size(14.dp)) }
                    }
                }
                if (editing != null) {
                    Row(
                        Modifier.fillMaxWidth().padding(8.dp).clip(RoundedCornerShape(16.dp)).background(auraLc(0xFF1A1A1A))
                            .padding(start = 14.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Edit, null, tint = auraLc(0xFFB8C2C8), modifier = Modifier.size(20.dp))
                        Text("Mesaj düzenleniyor", color = AuraWhite, fontSize = 16.sp, modifier = Modifier.weight(1f).padding(start = 12.dp))
                        IconButton(onClick = { editing = null; text = "" }) { Icon(Icons.Default.Close, "Kapat", tint = AuraWhite) }
                    }
                }
                if (pendingImages.isNotEmpty()) {
                    PendingImagesRow(
                        pendingImages, accent,
                        onEdit = { idx -> focusManager.clearFocus(); keyboard?.hide(); editIdx = idx },
                        onRemove = { idx ->
                            pendingImages = pendingImages.filterIndexed { j, _ -> j != idx }
                            if (pendingImages.size != 1) viewOnceOn = false
                        }
                    )
                }
                ChatInputField(
                    text, { text = it }, multiLine, { multiLine = it },
                    pendingImages.isNotEmpty(), viewOnceOn, inputFocus, showAttach,
                    { attachClosing = true }, accent, inputBorder, plusBtn, sendBtn, replyTo != null
                )
            }
        }

        if (panelPx > 0 && !recording && !searching && !chatBlocked) {
            Box(
                Modifier.fillMaxWidth().height(with(density) { panelPx.toDp() }).clipToBounds()
                    .onGloballyPositioned { if (pProg == 0f) inputHpx = (it.positionInRoot().y - listTopRoot - listHpx).toInt().coerceAtLeast(0) }
                    .then(sheetModifier)
            ) {
            AttachSheet(
                height = with(density) { maxOf(panelFullPx, panelPx).toDp() },
                expanded = panelExpanded,
                onGallery = {
                    showAttach = false
                    galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onCamera = {
                    showAttach = false
                    try {
                        val dir = File(ctx.cacheDir, "camera").also { it.mkdirs() }
                        val f = File(dir, "photo_${System.currentTimeMillis()}.jpg")
                        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                        cameraUri = u
                        cameraLauncher.launch(u)
                    } catch (e: Throwable) {
                        toast(ctx, "Kamera açılamadı")
                    }
                },
                onLocation = {
                    showAttach = false
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        sendLocationNow()
                    } else {
                        locPermLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                    }
                },
                onDocument = {
                    showAttach = false
                    docLauncher.launch(arrayOf("*/*"))
                },
                onPoll = { showAttach = false; showPoll = true },
                onVideo = { showAttach = false; showVideoChoice = true },
                onShare = {
                    showAttach = false
                    if (target.isGroup) toast(ctx, "Ekran paylaşımı şimdilik birebir görüntülü aramada")
                    else if (chatBlocked) toast(ctx, "Bu kişiyle arama yapamazsınız")
                    else startShare()
                },
                onTheme = { closeSheet(); onOpenTheme() },
                accent = accent,
                maxPick = (5 - pendingImages.size).coerceAtLeast(1),
                galSel = galSel, onGalSel = { galSel = it },
                onClose = { attachInstant = false; showAttach = false }
            )
            }
        }
    }
    if (pProg > 0f && showAttach && !recording && !searching && !chatBlocked) {
        val hDp = with(density) { (panelPx + (inputHpx * pProg).toInt()).toDp() }
        PickerSheet(
            accent = accent, maxPick = (5 - pendingImages.size).coerceAtLeast(1),
            selected = galSel, onSelected = { galSel = it },
            caption = galCaption, onCaption = { galCaption = it },
            canViewOnce = galSel.size == 1 && !(ctx.contentResolver.getType(galSel[0]) ?: "").startsWith("video"),
            viewOnce = viewOnceOn, onViewOnce = {
                viewOnceOn = !viewOnceOn
                if (viewOnceOn) oncePop = true
            },
            onCaptionFocus = {
                scope.launch {
                    panelExpanded = true
                    val full = panelMaxPx.coerceAtLeast(panelFullPx.toFloat())
                    panelAnim.animateTo(full, androidx.compose.animation.core.tween(260, easing = androidx.compose.animation.core.FastOutSlowInEasing))
                }
            },
            kbPx = (kbLay - bottomGapPx).coerceAtLeast(0),
            onClose = { closeSheet() },
            nested = sheetNested,
            onSend = {
                val sel = galSel
                val hd = galHd
                val ed = galEdited.toMap()
                if (galCaption.isNotBlank()) text = galCaption.trim()
                scope.launch {
                    // Klavye hemen istenir (açılması zaman alır); panel tam boydaysa aynı anda klavye yüksekliğine iner
                    try { inputFocus.requestFocus(); keyboard?.show() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatScreen", e) }
                    if (panelAnim.value > panelFullPx + 4f) {
                        panelDragging = true
                        panelAnim.animateTo(panelFullPx.toFloat(), androidx.compose.animation.core.tween(160, easing = androidx.compose.animation.core.FastOutSlowInEasing))
                        panelDragging = false
                        if (!showAttach) panelAnim.snapTo(0f)
                    }
                    attachClosing = true
                }
                val vids = sel.filter { (ctx.contentResolver.getType(it) ?: "").startsWith("video") }
                addImages(sel - vids.toSet(), hd, ed)
                vids.forEach { sendVideoUri(it) }
            },
            hd = galHd, onHd = { galHd = !galHd },
            canEdit = galSel.any { !(ctx.contentResolver.getType(it) ?: "").startsWith("video") },
            onEdit = {
                val u = galSel.lastOrNull { !(ctx.contentResolver.getType(it) ?: "").startsWith("video") }
                if (u != null) scope.launch {
                    busy = true
                    val d = galEdited[u] ?: withContext(Dispatchers.IO) { Media.compress(ctx, u, 700 * 1024) }
                    busy = false
                    if (d != null) galEditSrc = Pair(u, d) else toast(ctx, "Resim açılamadı")
                }
            },
            headerMod = sheetModifier,
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .navigationBarsPadding().padding(bottom = with(density) { bottomGapPx.toDp() })
                .height(hDp).graphicsLayer(alpha = (pProg * 2f).coerceAtMost(1f))
        )
    }
    }

    galEditSrc?.let { ge ->
        ImageEditor(
            dataUrl = ge.second, targetBytes = if (galHd) 640 * 1024 else 300 * 1024,
            onDone = { nu -> galEdited[ge.first] = nu; galEditSrc = null },
            onCancel = { galEditSrc = null }
        )
    }

    callSheet?.let { cm -> CallSheet(cm, target, accent, { callSheet = null }, onCall) }

    if (oncePop) {
        androidx.compose.ui.window.Popup(
            alignment = Alignment.Center,
            properties = androidx.compose.ui.window.PopupProperties(focusable = false)
        ) {
            Text(
                "Medya bir kez görüntülenecek şekilde ayarlandı", color = AuraBlack, fontSize = 18.sp,
                modifier = Modifier.padding(horizontal = 32.dp).clip(RoundedCornerShape(28.dp)).background(auraLc(0xFFF2F2F2))
                    .padding(horizontal = 26.dp, vertical = 20.dp)
            )
        }
    }
    if (confirmDiscard) {
        AuraAlertDialog(
            onDismissRequest = { confirmDiscard = false },
            containerColor = auraLc(0xFF202C33),
            text = { Text("Seçim yok sayılsın mı?", color = AuraWhite, fontSize = 17.sp) },
            confirmButton = {
                TextButton(onClick = { confirmDiscard = false; closeSheet() }) { Text("Yok say", color = accent) }
            },
            dismissButton = {
                TextButton(onClick = {
                    confirmDiscard = false
                    scope.launch {
                        panelExpanded = true
                        panelAnim.animateTo(panelMaxPx.coerceAtLeast(panelFullPx.toFloat()), androidx.compose.animation.core.tween(240, easing = androidx.compose.animation.core.FastOutSlowInEasing))
                    }
                }) { Text("İptal", color = accent) }
            }
        )
    }

    if (showPoll) {
        PollCreator(
            onSend = { q, opts, multi ->
                showPoll = false
                val r = replyRefOf()
                replyTo = null
                launchSafe { Repo.sendPoll(me, target, q, opts, multi, r) }
            },
            onClose = { showPoll = false }
        )
    }
    if (editIdx in pendingImages.indices) {
        ImageEditor(
            dataUrl = pendingImages[editIdx],
            targetBytes = if (pendingImages.size > 1) 150 * 1024 else 300 * 1024,
            onDone = { nu ->
                val i = editIdx
                pendingImages = pendingImages.toMutableList().also { if (i in it.indices) it[i] = nu }
                editIdx = -1
            },
            onCancel = { editIdx = -1 }
        )
    }

    if (showDisappear) {
        AuraAlertDialog(
            onDismissRequest = { showDisappear = false },
            containerColor = AuraSurface,
            title = { Text("Süreli mesajlar (yeni mesajlar için)", color = AuraWhite, fontSize = 17.sp) },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    listOf("Kapalı" to 0L, "24 saat" to 24 * 3600 * 1000L, "7 gün" to 7 * 24 * 3600 * 1000L).forEach { (label, ms) ->
                        TextButton(onClick = {
                            showDisappear = false
                            Repo.setDisappearAfter(target.chatId, me.name, me.uid, ms)
                            toast(ctx, if (ms > 0) "Süreli mesajlar açıldı" else "Süreli mesajlar kapatıldı")
                        }) { Text(label, color = AuraGreen) }
                    }
                    TextButton(onClick = { showDisappear = false }) { Text("İptal", color = AuraMuted) }
                }
            }
        )
    }
    videoMsg?.let { vm -> VideoPlayerDialog(vm) { videoMsg = null } }
    if (showVideoChoice) {
        AuraAlertDialog(
            onDismissRequest = { showVideoChoice = false },
            containerColor = AuraSurface,
            title = { Text("Video gönder", color = AuraWhite, fontSize = 17.sp) },
            text = { Text("Mesajlaşma sınırı yüzünden video en fazla 640 KB (yaklaşık 5 saniye) olabilir.", color = AuraMuted, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = {
                    showVideoChoice = false
                    try {
                        val dir = File(ctx.cacheDir, "camera").also { it.mkdirs() }
                        val f = File(dir, "video_${System.currentTimeMillis()}.mp4")
                        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                        videoCaptureUri = u
                        videoCaptureLauncher.launch(
                            Intent(android.provider.MediaStore.ACTION_VIDEO_CAPTURE)
                                .putExtra(android.provider.MediaStore.EXTRA_OUTPUT, u)
                                .putExtra(android.provider.MediaStore.EXTRA_SIZE_LIMIT, (Media.VIDEO_MAX_BYTES - 20 * 1024).toLong())
                                .putExtra(android.provider.MediaStore.EXTRA_VIDEO_QUALITY, 0)
                                .putExtra(android.provider.MediaStore.EXTRA_DURATION_LIMIT, 8)
                                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        )
                    } catch (e: Throwable) { toast(ctx, "Kamera açılamadı") }
                }) { Text("Video çek", color = AuraGreen) }
            },
            dismissButton = {
                TextButton(onClick = {
                    showVideoChoice = false
                    videoPickLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                }) { Text("Galeriden seç", color = AuraGreen) }
            }
        )
    }
    reactionsMsgId?.let { rid ->
        val rm = visible.firstOrNull { it.id == rid }
        if (rm == null || rm.reactions.isEmpty()) { reactionsMsgId = null } else {
            ReactionsSheet(rm, me, target) { reactionsMsgId = null }
        }
    }
    memberSheet?.let { mu -> MemberSheet(mu, { memberSheet = null }, onMemberChat, onMemberCall) }
    pinAsk?.let { pm ->
        AuraAlertDialog(
            onDismissRequest = { pinAsk = null },
            containerColor = AuraSurface,
            title = { Text("Sabitleme süresini seçin", color = AuraWhite, fontSize = 18.sp) },
            text = {
                Column {
                    Text("Mesajı istediğiniz zaman kaldırabilirsiniz.", color = AuraMuted, fontSize = 13.sp)
                    listOf("24 saat" to 24L * 3600_000L, "7 gün" to 7L * 24 * 3600_000L, "30 gün" to 30L * 24 * 3600_000L).forEach { (lbl, ms) ->
                        Text(lbl, color = AuraWhite, fontSize = 16.sp,
                            modifier = Modifier.fillMaxWidth().clickable {
                                Repo.pinMessage(target.chatId, pm.id, true, ms); pinAsk = null; clearSelection()
                            }.padding(vertical = 13.dp))
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pinAsk = null }) { Text("İptal", color = AuraMuted) } }
        )
    }
    if (showReport) {
        val chatNameR = liveChatName(target)
        var reason by remember { mutableStateOf("Spam") }
        var note by remember { mutableStateOf("") }
        AuraAlertDialog(
            onDismissRequest = { showReport = false },
            containerColor = AuraSurface,
            title = { Text(if (target.isGroup) "Grubu şikayet et" else "Kişiyi şikayet et", color = AuraWhite, fontSize = 18.sp) },
            text = {
                Column {
                    listOf("Spam", "Taciz / zorbalık", "Uygunsuz içerik", "Sahte hesap", "Diğer").forEach { r ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { reason = r }.padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = reason == r, onClick = { reason = r },
                                colors = androidx.compose.material3.RadioButtonDefaults.colors(selectedColor = AuraGreen, unselectedColor = AuraMuted)
                            )
                            Text(r, color = AuraWhite, fontSize = 16.sp)
                        }
                    }
                    Text("Şikayetiniz yöneticiye iletilir. Kişi bunu bilmez.", color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showReport = false
                    // şikayete sohbetin son 5 mesajı eklenir (yönetici panelinde görünür)
                    val reportMsgs = visible.filter { !it.deleted }.takeLast(5).map { m ->
                        val mine = m.senderUid == me.uid
                        val kind = when (m.type) { "image", "audio", "video", "file", "location" -> m.type; else -> "text" }
                        org.json.JSONObject().put("t", m.time).put("w", if (mine) me.name else m.senderName.ifBlank { chatNameR })
                            .put("u", m.senderUid).put("k", kind).put("me", mine).put("x", m.text.take(200))
                    }
                    val bubbleHex = try {
                        val oc = ChatThemes.bubbleColors.firstOrNull { it.id == ChatThemes.savedOutId(ctx, target.chatId) }?.color ?: ThemeDefaultOut
                        String.format("#%06X", oc.toArgb() and 0xFFFFFF)
                    } catch (e: Throwable) { "" }
                    scope.launch {
                        val ok = Repo.sendReport(target.chatId, if (target.isGroup) "" else target.otherUid, chatNameR, target.isGroup, me.name, reason, note, reportMsgs, bubbleHex)
                        toast(ctx, if (ok) "Şikayet gönderildi" else "Gönderilemedi, bağlantını kontrol et")
                    }
                }) { Text("Gönder", color = AuraGreen) }
            },
            dismissButton = { TextButton(onClick = { showReport = false }) { Text("İptal", color = AuraMuted) } }
        )
    }
    if (showWipe) {
        val st = starredIn(me.uid, listOf(target.chatId))
        var alsoStars by remember { mutableStateOf(false) }
        AuraAlertDialog(
            onDismissRequest = { showWipe = false },
            containerColor = AuraSurface,
            title = { Text("Bu sohbeti kalıcı olarak silmek üzeresiniz", color = AuraWhite, fontSize = 17.sp) },
            text = { if (st.isNotEmpty()) StarClearRow(alsoStars, st.size) { alsoStars = it } },
            confirmButton = {
                TextButton(onClick = {
                    showWipe = false
                    if (alsoStars) Repo.unstarAll(me.uid, st.map { it.key })
                    Repo.wipeChat(me.uid, target.chatId)
                    toast(ctx, "Sohbet temizlendi")
                }) { Text("Sil", color = auraLc(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { showWipe = false }) { Text("İptal", color = AuraMuted) } }
        )
    }

    voViewing?.let { vm ->
        androidx.compose.runtime.LaunchedEffect(vm.id) { Repo.openViewOnce(target.chatId, vm.id, target.isGroup) }
        val voName = vm.senderName.ifBlank { liveChatName(target) }
        ViewOnceViewer(
            vm.imageUrl,
            onReply = if (vm.senderUid != me.uid) { t ->
                val ref = ReplyRef(vm.id, voName, "Fotoğraf", vm.senderUid)
                scope.launch { try { Repo.sendText(me, target, t, ref) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatScreen", e) } }
            } else null
        ) {
            Repo.consumeViewOnce(target.chatId, vm.id, target.isGroup)
            voViewing = null
            voTick++
        }
    }

    // Silme penceresi
    if (showDelete) {
        DeleteMsgsDialog(selectedMsgs, me, target, onDismiss = { showDelete = false }, onDone = { showDelete = false; clearSelection() })
    }

    val v = viewer
    val vmsg = viewerMsg
    if (v != null && vmsg != null) {
        val sname = vmsg.senderName.ifBlank { if (vmsg.senderUid == me.uid) me.name else liveChatName(target) }
        val isAlbum = v.first.size > 1
        // tek resimli mesajda sohbetteki tüm resimler arasında gezilir; albümde yalnızca o albüm
        val otherName = liveChatName(target)
        val allItems = remember(visible, vmsg.id, isAlbum, otherName) {
            if (isAlbum) null
            else visible.asReversed().filter { it.type == "image" && !it.deleted && !it.viewOnce }.flatMap { m ->
                val nm = m.senderName.ifBlank { if (m.senderUid == me.uid) me.name else otherName }
                messageImages(m).map { ViewerItem(it, effTime(m), nm, m.id, m.text, m.senderUid) }
            }
        }
        val chatStart = allItems?.indexOfFirst { it.id == vmsg.id }?.takeIf { it >= 0 }
        val vItems = if (allItems != null && chatStart != null) allItems else v.first.map { ViewerItem(it, effTime(vmsg), sname, vmsg.id, vmsg.text, vmsg.senderUid) }
        MessageImageViewer(
            me = me, target = target, items = vItems, startIndex = if (allItems != null && chatStart != null) chatStart else v.second, album = isAlbum,
            msgFor = { id -> visible.firstOrNull { it.id == id } ?: vmsg.takeIf { it.id == id } },
            onForward = { m -> viewer = null; viewerMsg = null; onForward(listOf(m)) },
            onShowInChat = { m -> viewer = null; viewerMsg = null; showInChat(m.id) },
            onEdited = { nu -> pendingImages = (pendingImages + nu).take(5) },
            onReplyTo = { m -> viewer = null; viewerMsg = null; replyTo = m; editing = null },
            onPin = { m -> viewer = null; viewerMsg = null; pinAsk = m },
            onReport = { _ -> viewer = null; viewerMsg = null; showReport = true },
            onClose = { viewer = null; viewerMsg = null }
        )
    } else if (v != null) ImageViewer(v.first, v.second) { viewer = null }
    LaunchedEffect(target.chatId) {
        val got = ViewerBridge.take(target.chatId)
        if (got.isNotEmpty()) pendingImages = (pendingImages + got).take(5)
    }
}

private fun lastSeenText(ms: Long): String {
    val time = SimpleDateFormat("HH:mm", Locale("tr")).format(Date(ms))
    val startToday = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    return when {
        ms >= startToday -> "son görülme bugün $time"
        ms >= startToday - 86_400_000L -> "son görülme dün $time"
        else -> "son görülme " + SimpleDateFormat("d MMMM", Locale("tr")).format(Date(ms))
    }
}

@Composable
private fun AttachSheet(
    height: androidx.compose.ui.unit.Dp,
    expanded: Boolean = false,
    onGallery: () -> Unit,
    onCamera: () -> Unit,
    onLocation: () -> Unit,
    onDocument: () -> Unit,
    onPoll: () -> Unit,
    onVideo: () -> Unit = {},
    onShare: () -> Unit,
    onTheme: () -> Unit = {},
    accent: Color,
    maxPick: Int,
    galSel: List<Uri>,
    onGalSel: (List<Uri>) -> Unit,
    onClose: () -> Unit = {}
) {
    val items = listOf(
        Triple("Galeri", Icons.Default.Image, auraLc(0xFF3B82F6)) to onGallery,
        Triple("Kamera", Icons.Default.PhotoCamera, auraLc(0xFFF43F5E)) to onCamera,
        Triple("Konum", Icons.Default.LocationOn, auraLc(0xFF10B981)) to onLocation,
        Triple("Video", Icons.Default.Videocam, auraLc(0xFFEC4899)) to onVideo,
        Triple("Belge", Icons.Default.Description, auraLc(0xFF8B5CF6)) to onDocument,
        Triple("Anket", Icons.Default.BarChart, auraLc(0xFFF59E0B)) to onPoll,
        Triple("Sohbet teması", Icons.Default.Palette, auraLc(0xFFF472B6)) to onTheme,
        Triple("Ekran paylaş", Icons.Default.ScreenShare, auraLc(0xFF38BDF8)) to onShare
    )
    Column(
        Modifier.fillMaxWidth().wrapContentHeight(Alignment.Top, unbounded = true).height(height).clipToBounds()
            .background(AuraBlack)
    ) {
        Spacer(Modifier.height(10.dp))
        items.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
                for (k in 0 until 4) {
                    val it = row.getOrNull(k)
                    Column(
                        Modifier.weight(1f).then(if (it != null) Modifier.clickable { it.second() } else Modifier),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (it != null) {
                            val info = it.first
                            Box(
                                Modifier.width(64.dp).height(34.dp).clip(RoundedCornerShape(17.dp))
                                    .border(1.dp, auraLc(0xFF2A3239), RoundedCornerShape(17.dp)),
                                contentAlignment = Alignment.Center
                            ) { Icon(info.second, info.first, tint = info.third, modifier = Modifier.size(22.dp)) }
                            Text(info.first, color = auraLc(0xFF9AA3A9), fontSize = 14.sp, maxLines = 1, softWrap = false, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
        }
        GalleryStrip(accent, maxPick, galSel, onGalSel, Modifier.weight(1f).padding(top = 10.dp), grid = false)
    }
}

private val auraLH = androidx.compose.ui.text.style.LineHeightStyle(androidx.compose.ui.text.style.LineHeightStyle.Alignment.Center, androidx.compose.ui.text.style.LineHeightStyle.Trim.None)

/** Yarım / tam açık "+" paneli: WhatsApp galeri seçicisi (üstte başlık, ızgara, altta açıklama + gönder) */
@Composable
private fun PickerSheet(
    accent: Color,
    maxPick: Int,
    selected: List<Uri>,
    onSelected: (List<Uri>) -> Unit,
    caption: String,
    onCaption: (String) -> Unit,
    onCaptionFocus: () -> Unit = {},
    canViewOnce: Boolean = false,
    viewOnce: Boolean = false,
    onViewOnce: () -> Unit = {},
    kbPx: Int,
    onClose: () -> Unit,
    onSend: () -> Unit,
    hd: Boolean,
    onHd: () -> Unit,
    canEdit: Boolean,
    onEdit: () -> Unit,
    headerMod: Modifier,
    nested: androidx.compose.ui.input.nestedscroll.NestedScrollConnection,
    modifier: Modifier
) {
    var album by remember { mutableStateOf<String?>(null) }
    var albums by remember { mutableStateOf<List<Pair<String, Int>>>(emptyList()) }
    var albumMenu by remember { mutableStateOf(false) }
    Column(
        modifier.background(AuraBlack)
    ) {
        Column(headerMod) {
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Kapat", tint = AuraWhite) }
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Row(
                        Modifier.clip(RoundedCornerShape(20.dp)).clickable { albumMenu = true }.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(album ?: "Son kullanılanlar", color = AuraWhite, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Icon(Icons.Default.KeyboardArrowDown, null, tint = AuraWhite)
                    }
                    AuraDropdownMenu(expanded = albumMenu, onDismissRequest = { albumMenu = false }, shape = RoundedCornerShape(16.dp), containerColor = AuraSurface, alignEnd = false) {
                        DropdownMenuItem(text = { Text("Son kullanılanlar", color = AuraWhite) }, onClick = { album = null; albumMenu = false })
                        albums.forEach { (n, c) ->
                            DropdownMenuItem(
                                text = { Text(n, color = AuraWhite) },
                                trailingIcon = { Text("$c", color = AuraMuted, fontSize = 13.sp) },
                                onClick = { album = n; albumMenu = false }
                            )
                        }
                    }
                }
                Text(
                    "HD", color = if (hd) AuraWhite else auraLc(0xFFB8C2C8), fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(end = 12.dp).clip(CircleShape).background(if (hd) accent else AuraBlack)
                        .border(1.dp, if (hd) accent else auraLc(0xFF2E2E2E), CircleShape).clickable(onClick = onHd)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
        GalleryStrip(accent, maxPick, selected, onSelected, Modifier.weight(1f).nestedScroll(nested), grid = true, album = album, onAlbums = { albums = it })
        if (selected.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().offset { androidx.compose.ui.unit.IntOffset(0, -kbPx) }
                    .background(AuraBlack).padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.weight(1f).heightIn(min = 46.dp).clip(RoundedCornerShape(23.dp)).background(AuraBlack).border(1.dp, auraLc(0xFF2E2E2E), RoundedCornerShape(23.dp)).padding(start = 16.dp, end = if (canViewOnce) 48.dp else 16.dp, top = 12.dp, bottom = 12.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (caption.isEmpty()) Text("Açıklama ekleyin…", color = AuraMuted, style = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, lineHeightStyle = auraLH))
                    AuraTextField(
                        value = caption, onValueChange = onCaption, maxLines = 3,
                        textStyle = TextStyle(color = AuraWhite, fontSize = 16.sp, lineHeight = 22.sp, lineHeightStyle = auraLH),
                        cursorBrush = SolidColor(accent),
                        modifier = Modifier.fillMaxWidth().onFocusChanged { if (it.isFocused) onCaptionFocus() }
                    )
                    if (canViewOnce) {
                        Box(
                            Modifier.align(Alignment.CenterEnd).offset(x = 38.dp).size(28.dp).clip(CircleShape)
                                .background(if (viewOnce) accent else Color.Transparent)
                                .border(2.dp, if (viewOnce) accent else AuraMuted, CircleShape)
                                .clickable(onClick = onViewOnce),
                            contentAlignment = Alignment.Center
                        ) { Text("1", color = AuraWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    }
                }
                Spacer(Modifier.width(6.dp))
                Spacer(Modifier.width(10.dp))
                Box {
                    Box(
                        Modifier.size(39.dp).clip(CircleShape).background(accent).clickable(onClick = onSend),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.ArrowUpward, "Gönder", tint = if (accent.luminance() < 0.5f) Color.White else Color(0xFF111B21), modifier = Modifier.size(22.dp)) }
                }
            }
        }
    }
}


@Composable
private fun ChatSearchBar(searchQ: String, onQ: (String) -> Unit, matchCount: Int, matchIdx: Int, onClose: () -> Unit, onPrev: () -> Unit, onNext: () -> Unit) {
                val searchFocus = remember { androidx.compose.ui.focus.FocusRequester() }
                LaunchedEffect(Unit) { try { searchFocus.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatScreen", e) } }
                Row(
                    Modifier.fillMaxWidth().height(54.dp).background(ChatBar.tint ?: AuraBlack).padding(start = 6.dp, end = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kapat", tint = AuraWhite) }
                    Row(
                        Modifier.weight(1f).height(42.dp).clip(RoundedCornerShape(50)).background(AuraSurface).padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.weight(1f)) {
                            if (searchQ.isEmpty()) Text("Sohbette ara...", color = AuraMuted, fontSize = 14.sp)
                            AuraTextField(
                                value = searchQ, onValueChange = onQ, singleLine = true,
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { }),
                                textStyle = TextStyle(color = AuraWhite, fontSize = 14.sp),
                                cursorBrush = SolidColor(AuraGreen),
                                modifier = Modifier.fillMaxWidth().focusRequester(searchFocus)
                            )
                        }
                        if (searchQ.isNotEmpty()) {
                            Text(
                                if (matchCount == 0) "0" else "${matchIdx + 1}/$matchCount",
                                color = AuraMuted, fontSize = 12.sp
                            )
                        }
                    }
                    IconButton(
                        onClick = onPrev,
                        modifier = Modifier.size(40.dp)
                    ) { Icon(Icons.Default.KeyboardArrowUp, "Önceki", tint = if (matchIdx < matchCount - 1) AuraWhite else AuraMuted) }
                    IconButton(
                        onClick = onNext,
                        modifier = Modifier.size(40.dp)
                    ) { Icon(Icons.Default.KeyboardArrowDown, "Sonraki", tint = if (matchIdx > 0) AuraWhite else AuraMuted) }
    }
}

@Composable
private fun ChatSelectionBar(
    selCount: Int, single: Message?, selectedMsgs: List<Message>, starredKeys: Set<String>, me: UserProfile, target: ChatTarget,
    onClear: () -> Unit, onReply: (Message) -> Unit, onDelete: () -> Unit, onForward: () -> Unit, onEdit: (Message) -> Unit,
    onPin: (Message, Boolean) -> Unit = { _, _ -> }, onReport: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
            var moreMenu by remember { mutableStateOf(false) }
            Row(
                Modifier.fillMaxWidth().height(56.dp).background(ChatBar.tint ?: AuraSelBar).padding(start = 6.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onClear() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "İptal", tint = AuraWhite) }
                Text("$selCount", color = AuraWhite, fontSize = 24.sp, modifier = Modifier.weight(1f).padding(start = 22.dp))
                if (single != null && !single.deleted && single.type != "system") {
                    IconButton(onClick = { onReply(single) }) {
                        Icon(Icons.AutoMirrored.Filled.Reply, "Yanıtla", tint = AuraWhite)
                    }
                }
                val starMsgs = selectedMsgs.filter { !it.deleted && it.type != "system" && it.type != "call" }
                if (starMsgs.isNotEmpty()) {
                    val allSt = starMsgs.all { starredKeys.contains(Repo.starKey(target.chatId, it.id)) }
                    IconButton(onClick = {
                        starMsgs.forEach {
                            val has = starredKeys.contains(Repo.starKey(target.chatId, it.id))
                            if (allSt) Repo.toggleStar(me.uid, target, it, true) else if (!has) Repo.toggleStar(me.uid, target, it, false)
                        }
                        onClear()
                    }) { Icon(if (allSt) Icons.Default.Star else Icons.Default.StarBorder, "Yıldız", tint = AuraWhite) }
                }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Sil", tint = AuraWhite) }
                val copyable = selectedMsgs.filter { !it.deleted && it.text.isNotBlank() }
                if (selectedMsgs.none { it.deleted || it.type == "system" || it.type == "poll" || it.type == "call" || it.viewOnce }) {
                    IconButton(onClick = { onForward() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, "İlet", tint = AuraWhite)
                    }
                }
                val canEdit = single != null && single.senderUid == me.uid && single.type == "text" && !single.deleted &&
                    System.currentTimeMillis() - effTime(single) < 15 * 60 * 1000L
                val canPin = single != null && !single.deleted && single.type != "system" && single.type != "call"
                val canTranslate = single != null && !single.deleted && single.text.isNotBlank()
                val canReport = single != null && single.senderUid != me.uid && !single.deleted && single.type != "system"
                if (copyable.isNotEmpty() || canPin || canTranslate || canReport || (canEdit && single != null)) {
                    Box {
                        IconButton(onClick = { moreMenu = true }) { Icon(Icons.Default.MoreVert, "Daha fazla", tint = AuraWhite) }
                        AuraDropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }, shape = RoundedCornerShape(16.dp), containerColor = AuraSurface, selecting = true, yGap = 1.dp) {
                            if (canEdit && single != null) {
                                DropdownMenuItem(text = { Text("Düzenle") }, onClick = { moreMenu = false; onEdit(single) })
                            }
                            if (copyable.isNotEmpty()) {
                                DropdownMenuItem(text = { Text("Kopyala") }, onClick = {
                                    moreMenu = false
                                    clipboard.setText(AnnotatedString(copyable.joinToString("\n") { it.text }))
                                    toast(ctx, "Kopyalandı")
                                    onClear()
                                })
                            }
                            if (canPin && single != null) {
                                DropdownMenuItem(text = { Text(if (single.pinned) "Sabitlemeyi kaldır" else "Sabitle") }, onClick = { moreMenu = false; onPin(single, !single.pinned) })
                            }
                            if (canTranslate && single != null) {
                                DropdownMenuItem(text = { Text("Çevir") }, onClick = {
                                    moreMenu = false
                                    try {
                                        val u = "https://translate.google.com/?sl=auto&tl=tr&op=translate&text=" + java.net.URLEncoder.encode(single.text, "UTF-8")
                                        ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                    } catch (e: Throwable) { toast(ctx, "Çevrilemedi") }
                                    onClear()
                                })
                            }
                            if (canReport) {
                                DropdownMenuItem(text = { Text("Şikayet et") }, onClick = { moreMenu = false; onReport() })
                            }
                        }
                    }
                }
            }
}

@Composable
private fun ChatHeaderRow(
    me: UserProfile, target: ChatTarget, onBack: () -> Unit, onOpenGroupInfo: () -> Unit, onCall: (Boolean) -> Unit, onOpenTheme: () -> Unit,
    otherTyping: Boolean, chatBlocked: Boolean, otherBlocked: Boolean, chatFlags: Repo.ChatFlags, disappearMs: Long,
    onSearch: () -> Unit, onDisappear: () -> Unit, onWipe: () -> Unit, onReport: () -> Unit = {},
    onNewGroup: () -> Unit = {}, onOpenMedia: () -> Unit = {}, onExport: () -> Unit = {}, ringColor: Color = Color(0xFF22C55E), showAbout: Boolean = true
) {
    var menuUp by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val kbc = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    val fm = androidx.compose.ui.platform.LocalFocusManager.current
            val live by remember(target.otherUid) {
                if (target.isGroup) kotlinx.coroutines.flow.flowOf<UserProfile?>(null) else Repo.profileFlow(target.otherUid)
            }.collectAsState(if (target.isGroup) null else Repo.peekProfile(target.otherUid))
            val avatar = live?.avatar ?: ""
            var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
            LaunchedEffect(Unit) { while (true) { delay(5000); nowMs = System.currentTimeMillis() } }
            val presence by remember(target.otherUid) {
                if (target.isGroup) kotlinx.coroutines.flow.flowOf<Repo.Presence?>(null) else Repo.presenceFlow(target.otherUid)
            }.collectAsState(null as Repo.Presence?)
            val groupData by remember(target.chatId) {
                if (target.isGroup) Repo.groupFlow(target.chatId) else kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.GroupData?>(null)
            }.collectAsState(if (target.isGroup) Repo.peekGroup(target.chatId) else null)
            // grup adı canlı: ad değişince geri dönüldüğünde de güncel görünür
            val shownName = if (target.isGroup) (groupData?.name?.takeIf { it.isNotBlank() } ?: target.name)
                else (live?.name?.takeIf { it.isNotBlank() } ?: target.name)
            // üyelerin adları canlı izlenir: biri adını değiştirince başlıktaki liste de kendiliğinden güncellenir
            val memberNames: Map<String, String> = (groupData?.members ?: emptyList()).associateWith { u ->
                if (u == me.uid) "Sen" else (liveProfile(u).value?.name?.takeIf { it.isNotBlank() } ?: Repo.peekProfile(u)?.name ?: "")
            }
            val typingUids by remember(target.chatId) {
                if (target.isGroup) Repo.groupTypingFlow(target.chatId, me.uid) else kotlinx.coroutines.flow.flowOf(emptyList<String>())
            }.collectAsState(emptyList<String>())

            val status: Pair<String, Boolean> = when {
                target.isGroup && typingUids.isNotEmpty() -> {
                    val n = typingUids.mapNotNull { memberNames[it] }.filter { it.isNotBlank() }
                    Pair(if (n.size in 1..2) n.joinToString(", ") + " yazıyor..." else "${typingUids.size} kişi yazıyor...", true)
                }
                target.isGroup -> Pair(memberNames.values.filter { it.isNotBlank() }.joinToString(", "), false)
                otherTyping -> Pair("yazıyor...", true)
                presence == null || Repo.isPresenceHidden() || presence!!.lastSeenMs <= 0L -> Pair("", false)
                presence!!.online && nowMs - presence!!.lastSeenMs < 25000L -> Pair("çevrimiçi", true)
                else -> Pair(lastSeenText(presence!!.lastSeenMs), false)
            }

            Box(Modifier.fillMaxWidth().zIndex(2f)) {
            Row(
                Modifier.fillMaxWidth().height(54.dp).background(ChatBar.tint ?: AuraBlack).padding(start = 6.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Row(
                    Modifier.weight(1f).clickable { onOpenGroupInfo() },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val avDp = (108f / androidx.compose.ui.platform.LocalDensity.current.density).dp
                    val allSt by remember { Repo.statusesFlow() }.collectAsState(emptyList<com.aurachat.app.data.StatusItem>())
                    val ringState = remember(allSt, me.uid, target.otherUid, target.isGroup) {
                        if (target.isGroup) 0 else {
                            val nowT = System.currentTimeMillis()
                            val l = allSt.filter { it.uid == target.otherUid && it.expiresAt > nowT }
                            if (l.isEmpty()) 0 else if (l.any { !it.viewers.contains(me.uid) }) 1 else 2
                        }
                    }
                    var statusOpen by remember { mutableStateOf(false) }
                    if (statusOpen) UserStatusViewer(
                        me, target.otherUid, onMessage = { statusOpen = false }, onClose = { statusOpen = false },
                        actions = StatusMenuActions(
                            onCall = { _, v -> statusOpen = false; onCall(v) },
                            onProfile = { statusOpen = false; onOpenGroupInfo() }
                        )
                    )
                    if (ringState != 0) {
                        Box(
                            Modifier.size(avDp).clip(CircleShape).clickable { statusOpen = true }
                                .border(2.5.dp, if (ringState == 1) ringColor else Color(0xFF6B7280), CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Avatar(shownName, avatar, avDp - 8.dp, accentAlways = true) }
                    } else Avatar(shownName, if (target.isGroup) (groupData?.photo ?: "") else avatar, avDp, isGroup = target.isGroup, accentAlways = true)
                    Spacer(Modifier.width(12.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(1.dp), horizontalAlignment = Alignment.Start) {
                        val tight = androidx.compose.ui.text.style.LineHeightStyle(
                            androidx.compose.ui.text.style.LineHeightStyle.Alignment.Center,
                            androidx.compose.ui.text.style.LineHeightStyle.Trim.Both
                        )
                        Text(
                            shownName, color = AuraWhite, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = androidx.compose.ui.text.TextStyle(lineHeight = 17.sp, lineHeightStyle = tight)
                        )
                        if (status.first.isNotEmpty()) Text(
                            status.first,
                            color = if (status.second) AuraGreen else AuraMuted,
                            fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = androidx.compose.ui.text.TextStyle(lineHeight = 14.sp, lineHeightStyle = tight)
                        )
                    }
                }
                run {
                    IconButton(onClick = { kbc?.hide(); fm.clearFocus(); if (chatBlocked) toast(ctx, if (otherBlocked) "Bu kişiyi engellediniz" else "Bu kişiyle arama yapamazsınız") else onCall(false) }, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.Call, "Sesli ara", tint = AuraWhite) }
                    IconButton(onClick = { kbc?.hide(); fm.clearFocus(); if (chatBlocked) toast(ctx, if (otherBlocked) "Bu kişiyi engellediniz" else "Bu kişiyle arama yapamazsınız") else onCall(true) }, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.Videocam, "Görüntülü ara", tint = AuraWhite) }
                }
                var headMenu by remember { mutableStateOf(false) }
                var subMenu by remember { mutableStateOf(false) }
                LaunchedEffect(headMenu, subMenu) { menuUp = headMenu || subMenu }
                var muteDlg by remember { mutableStateOf(false) }
                if (muteDlg) MuteDialog(isGroup = target.isGroup, onDismiss = { muteDlg = false }) { until ->
                    Repo.setMuted(me.uid, target.chatId, true, until); muteDlg = false
                    toast(ctx, "Sohbet sessize alındı")
                }
                Box {
                    IconButton(onClick = { headMenu = true }, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.MoreVert, "Menü", tint = AuraWhite) }
                    AuraDropdownMenu(
                        expanded = headMenu, onDismissRequest = { headMenu = false },
                        shape = RoundedCornerShape(16.dp), containerColor = AuraSurface
                    ) {
                        @Composable
                        fun MenuRow(label: String, textColor: Color = AuraWhite, onClick: () -> Unit) {
                            DropdownMenuItem(
                                text = { Text(label, color = textColor, fontSize = 17.sp) },
                                onClick = { headMenu = false; onClick() },
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                        MenuRow("Yeni grup") { onNewGroup() }
                        androidx.compose.material3.HorizontalDivider(color = auraLc(0xFF2A2F33))
                        MenuRow(if (target.isGroup) "Grup bilgisini görüntüle" else "Kişi profilini görüntüle") { onOpenGroupInfo() }
                        MenuRow("Ara") { onSearch() }
                        MenuRow("Medya, bağlantı ve belgeler") { onOpenMedia() }
                        MenuRow(if (chatFlags.muted) "Bildirimlerin sesini aç" else "Bildirimleri sessize al") {
                            if (chatFlags.muted) { Repo.setMuted(me.uid, target.chatId, false); toast(ctx, "Sohbetin sesi açıldı") }
                            else muteDlg = true
                        }
                        if (!target.isGroup) MenuRow("Süreli mesajlar") { onDisappear() }
                        MenuRow("Sohbet teması") { onOpenTheme() }
                        androidx.compose.material3.HorizontalDivider(color = auraLc(0xFF2A2F33))
                        DropdownMenuItem(
                            text = { Text("Diğer", color = AuraWhite, fontSize = 17.sp) },
                            trailingIcon = { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = AuraMuted) },
                            onClick = { headMenu = false; subMenu = true },
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                    AuraDropdownMenu(
                        expanded = subMenu, onDismissRequest = { subMenu = false },
                        shape = RoundedCornerShape(16.dp), containerColor = AuraSurface
                    ) {
                        @Composable
                        fun SubRow(label: String, onClick: () -> Unit) {
                            DropdownMenuItem(
                                text = { Text(label, color = AuraWhite, fontSize = 17.sp) },
                                onClick = { subMenu = false; onClick() },
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                        SubRow("Şikayet et") { onReport() }
                        if (!target.isGroup) SubRow(if (otherBlocked) "Engeli kaldır" else "Engelle") {
                            Repo.setBlocked(me.uid, target.otherUid, !otherBlocked)
                            toast(ctx, if (otherBlocked) "Engel kaldırıldı" else "Kişi engellendi")
                        }
                        SubRow("Sohbeti temizle") { onWipe() }
                        SubRow("Sohbeti dışa aktar") { onExport() }
                        SubRow("Kısayol ekle") {
                            val ok = com.aurachat.app.push.Notifs.pinChatShortcut(ctx, target.chatId, target.isGroup, target.otherUid, shownName)
                            toast(ctx, if (ok) "Kısayol ekleniyor" else "Bu cihaz kısayol eklemeyi desteklemiyor")
                        }
                        val lockedNow = ChatLock.all(ctx).contains(target.chatId)
                        SubRow(if (lockedNow) "Sohbet kilidini kaldır" else "Sohbeti kilitle") {
                            if (lockedNow) { ChatLock.unlock(ctx, listOf(target.chatId)); toast(ctx, "Kilit kaldırıldı") }
                            else if (!ChatLock.canLock(ctx)) toast(ctx, "Önce telefona ekran kilidi (PIN, desen veya parmak izi) ayarla")
                            else { ChatLock.lock(ctx, listOf(target.chatId)); toast(ctx, "Sohbet kilitlendi"); onBack() }
                        }
                        SubRow(if (chatFlags.fav) "Listeden çıkar" else "Listeye ekle") {
                            Repo.setFavorite(me.uid, target.chatId, !chatFlags.fav)
                            toast(ctx, if (!chatFlags.fav) "Favorilere eklendi" else "Favorilerden kaldırıldı")
                        }
                    }
                }
            }
            if (showAbout && !menuUp && !target.isGroup && (live?.about ?: "").isNotBlank() && !chatBlocked) {
                val aboutTxt = live?.about ?: ""
                val bcol = if (AuraUi.light) Color.White else auraLc(0xFF1F2C33)
                val maxBw = (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp - 28).dp
                Box(Modifier.align(Alignment.TopStart).offset(x = 14.dp, y = 48.dp)) {
                    Box(
                        Modifier.widthIn(max = maxBw).shadow(2.dp, RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp)).background(bcol)
                            .clickable { onOpenGroupInfo() }.padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            aboutTxt, color = AuraWhite, fontSize = 11.sp, lineHeight = 14.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Box(Modifier.offset(x = 34.dp, y = (-5).dp).requiredSize(8.dp).clip(CircleShape).background(bcol))
                }
            }
        }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun ReactionsSheet(rm: Message, me: UserProfile, target: ChatTarget, onDismiss: () -> Unit) {
            var tab by remember(rm.id) { mutableStateOf("") }
            val rctx = androidx.compose.ui.platform.LocalContext.current
            val rTheme = remember(target.chatId, AuraUi.light) { ChatThemes.resolve(rctx, target.chatId) }
            val counts = rm.reactions.values.groupingBy { it }.eachCount()
            val list = rm.reactions.entries.filter { tab.isEmpty() || it.value == tab }
                .sortedByDescending { it.key == me.uid }
            AuraBottomSheet(
                onDismissRequest = { onDismiss() },
                containerColor = ChatBar.tint ?: AuraBlack
            ) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 12.dp)) {
                    Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (listOf("" to rm.reactions.size) + counts.entries.map { it.key to it.value }).forEach { (e, n) ->
                            val on = tab == e
                            Text(
                                (if (e.isEmpty()) "Tümü " else "$e ") + n,
                                color = if (on) (if (rTheme.bubble.luminance() > 0.55f) Color(0xFF111B21) else Color.White) else AuraWhite, fontSize = 14.sp,
                                modifier = Modifier.clip(RoundedCornerShape(50)).background(if (on) rTheme.bubble else rTheme.bubble.copy(alpha = 0.35f))
                                    .clickable { tab = e }.padding(horizontal = 14.dp, vertical = 7.dp)
                            )
                        }
                    }
                    list.forEach { (uid, emoji) ->
                        val lp by liveProfile(uid)
                        val mineR = uid == me.uid
                        val nm = if (mineR) "Sen" else (lp?.name?.takeIf { it.isNotBlank() } ?: rm.senderName.takeIf { rm.senderUid == uid && it.isNotBlank() } ?: "Kullanıcı")
                        Row(
                            Modifier.fillMaxWidth()
                                .then(if (mineR) Modifier.clickable {
                                    Repo.react(me.uid, target.chatId, rm.id, emoji, emoji)
                                    onDismiss()
                                } else Modifier)
                                .padding(horizontal = 20.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(nm.ifBlank { "?" }, if (mineR) me.avatar else (lp?.avatar ?: ""), 44.dp, accentAlways = true)
                            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                                Text(nm, color = AuraWhite, fontSize = 16.sp)
                                if (mineR) Text("Kaldırmak için dokun", color = AuraMuted, fontSize = 12.sp)
                            }
                            Text(emoji, fontSize = 24.sp)
                        }
                    }
                }
            }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun MemberSheet(mu: UserProfile, onDismiss: () -> Unit, onMemberChat: (UserProfile) -> Unit, onMemberCall: (UserProfile, Boolean) -> Unit) {
        val lp by liveProfile(mu.uid)
        val u = lp ?: mu
        AuraBottomSheet(
            onDismissRequest = { onDismiss() },
            containerColor = ChatBar.tint ?: AuraBlack
        ) {
            Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.clip(CircleShape).then(if (u.avatar.isNotBlank()) Modifier.clickable { AvatarFull.open(u.name, u.avatar); onDismiss() } else Modifier)
                ) { Avatar(u.name.ifBlank { "?" }, u.avatar, 96.dp, accentAlways = true) }
                val mctx = LocalContext.current
                Text(u.name.ifBlank { "Kullanıcı" }, color = AuraWhite, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 12.dp))
                if (u.phone.isNotBlank()) Text(u.phone, color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
                Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        Triple(Icons.Default.Chat, "Mesaj", 0),
                        Triple(Icons.Default.Call, "Sesli", 1),
                        Triple(Icons.Default.Videocam, "Görüntülü", 2),
                        Triple(Icons.Default.PersonAdd, "Kaydet", 3)
                    ).forEach { (ic, label, act) ->
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(auraC(0xFF111B21))
                                .clickable {
                                    if (act == 3) {
                                        if (u.phone.isBlank()) {
                                            Toast.makeText(mctx, "Bu kişinin telefon numarası yok", Toast.LENGTH_SHORT).show()
                                        } else {
                                            try {
                                                mctx.startActivity(Intent(android.provider.ContactsContract.Intents.Insert.ACTION).apply {
                                                    type = android.provider.ContactsContract.RawContacts.CONTENT_TYPE
                                                    putExtra(android.provider.ContactsContract.Intents.Insert.NAME, u.name)
                                                    putExtra(android.provider.ContactsContract.Intents.Insert.PHONE, u.phone)
                                                })
                                            } catch (e: Throwable) {
                                                Toast.makeText(mctx, "Kişiler uygulaması açılamadı", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    } else {
                                        onDismiss()
                                        when (act) { 0 -> onMemberChat(u); 1 -> onMemberCall(u, false); else -> onMemberCall(u, true) }
                                    }
                                }.padding(vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(ic, label, tint = AuraGreen, modifier = Modifier.size(24.dp))
                            Text(label, color = auraLc(0xFFE5E7EB), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
                if (u.about.isNotBlank()) {
                    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
                        Text("Bilgi", color = AuraMuted, fontSize = 13.sp)
                        Text(u.about, color = AuraWhite, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun CallSheet(cm: Message, target: ChatTarget, accent: Color, onDismiss: () -> Unit, onCall: (Boolean) -> Unit) {
        val audio = cm.callType == "audio"
        AuraBottomSheet(onDismissRequest = { onDismiss() }, containerColor = AuraSurface, shape = RoundedCornerShape(0.dp)) {
            Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                val lp by liveProfile(target.otherUid)
                Avatar(liveChatName(target).ifBlank { "?" }, lp?.avatar ?: "", 84.dp, accentAlways = true)
                Text(liveChatName(target), color = AuraWhite, fontSize = 22.sp, modifier = Modifier.padding(top = 12.dp, bottom = 16.dp))
                Row(
                    Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp)).background(accent)
                        .clickable { onDismiss(); onCall(!audio) },
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(if (audio) Icons.Default.Call else Icons.Default.Videocam, null, tint = AuraWhite, modifier = Modifier.size(22.dp))
                    Text("  Ara", color = AuraWhite, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.height(12.dp))
            }
        }
}

@Composable
private fun DeleteMsgsDialog(selectedMsgs: List<Message>, me: UserProfile, target: ChatTarget, onDismiss: () -> Unit, onDone: () -> Unit) {
    val allMine = selectedMsgs.isNotEmpty() && selectedMsgs.all { it.senderUid == me.uid && !it.deleted && !it.pending }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val dTheme = remember(target.chatId, AuraUi.light) { ChatThemes.resolve(ctx, target.chatId) }
    // yazılar sohbet balonu renginde; koyu zeminde okunsun diye çok koyuysa biraz açılır
    val btnC = dTheme.bubble.let { if (it.luminance() < 0.2f) androidx.compose.ui.graphics.lerp(it, Color.White, 0.3f) else it }
    val title = when {
        selectedMsgs.size == 1 && !allMine -> {
            val nm = selectedMsgs[0].senderName.ifBlank { liveChatName(target) }
            "$nm kişisinden gelen mesaj silinsin mi?"
        }
        selectedMsgs.size == 1 -> "Mesaj silinsin mi?"
        else -> "${selectedMsgs.size} mesaj silinsin mi?"
    }
    val forMe = {
        selectedMsgs.forEach { Repo.deleteForMe(me.uid, target.chatId, it.id) }
        onDone()
    }
    @Composable
    fun Btn(label: String, onClick: () -> Unit) {
        TextButton(onClick = onClick, modifier = Modifier.heightIn(min = 48.dp)) {
            Text(label, color = btnC, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
    }
    AuraAlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AuraSurface,
        title = { Text(title, color = AuraWhite, fontSize = 18.sp, fontWeight = FontWeight.Normal) },
        confirmButton = {
            if (allMine) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
                    Btn("Herkesten sil") {
                        selectedMsgs.forEach { Repo.deleteForEveryone(target.chatId, it.id, me.uid) }
                        onDone()
                    }
                    Btn("Benden sil") { forMe() }
                    Btn("İptal") { onDismiss() }
                }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Btn("İptal") { onDismiss() }
                    Spacer(Modifier.width(8.dp))
                    Btn("Benden sil") { forMe() }
                }
            }
        }
    )
}

@Composable
private fun MentionList(mentionList: List<Pair<String, String>>, onPick: (String, String) -> Unit) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp).heightIn(max = 220.dp)
                        .clip(RoundedCornerShape(12.dp)).background(auraC(0xFF1F2C34))
                        .border(1.dp, auraLc(0x1FFFFFFF), RoundedCornerShape(12.dp))
                        .verticalScroll(androidx.compose.foundation.rememberScrollState())
                ) {
                    mentionList.forEach { (uid, name) ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onPick(uid, name) }.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (uid == "*") {
                                Box(Modifier.size(34.dp).clip(CircleShape).background(auraLc(0xFF128C7E)), contentAlignment = Alignment.Center) {
                                    Text("@", color = AuraWhite, fontSize = 14.sp)
                                }
                            } else Avatar(name, "", 34.dp, accentAlways = true)
                            Column(Modifier.padding(start = 10.dp)) {
                                Text(name, color = auraLc(0xFFE9EDEF), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (uid == "*") Text("Tüm grup üyelerini etiketle", color = auraLc(0xFF8696A0), fontSize = 12.sp)
                            }
                        }
                    }
                }
}

@Composable
private fun PendingImagesRow(pendingImages: List<String>, accent: Color, onEdit: (Int) -> Unit, onRemove: (Int) -> Unit) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                            .padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        pendingImages.forEachIndexed { idx, img ->
                            Box(Modifier.size(width = 71.dp, height = 71.dp).padding(top = 6.dp, end = 6.dp)) {
                                DataUrlImage(
                                    img, 220,
                                    Modifier.size(65.dp).clip(RoundedCornerShape(12.dp)).clickable {
                                        onEdit(idx)
                                    },
                                    androidx.compose.ui.layout.ContentScale.Crop
                                )
                                Box(
                                    Modifier.align(Alignment.TopEnd).offset(x = 0.dp, y = (-0).dp).size(20.dp).clip(CircleShape).background(accent)
                                        .clickable {
                                            onRemove(idx)
                                        },
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.Close, "Kaldır", tint = AuraWhite, modifier = Modifier.size(14.dp)) }
                            }
                        }
                    }
}

@Composable
private fun androidx.compose.foundation.layout.BoxScope.ReactionBar(
    single: Message, me: UserProfile, target: ChatTarget, touchPos: androidx.compose.ui.geometry.Offset,
    listHpx: Float, listWpx: Float, reactBarW: Float, onBarW: (Float) -> Unit, barColor: Color,
    launch: (suspend () -> Unit) -> Unit, onDone: () -> Unit
) {
    val density = LocalDensity.current
                val barH = with(density) { 66.dp.toPx() }
                val y = (touchPos.y - barH - with(density) { 36.dp.toPx() })
                    .coerceIn(with(density) { 4.dp.toPx() }, (listHpx - barH).coerceAtLeast(0f))
                val edge = with(density) { 8.dp.toPx() }
                val x = (touchPos.x - reactBarW / 2f).coerceIn(edge, (listWpx - reactBarW - edge).coerceAtLeast(edge))
                Row(
                    Modifier
                        .align(Alignment.TopStart)
                        .onGloballyPositioned { onBarW(it.size.width.toFloat()) }
                        .offset { androidx.compose.ui.unit.IntOffset(x.toInt(), y.toInt()) }
                        .clip(RoundedCornerShape(28.dp)).background(barColor).padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    REACTIONS.forEach { e ->
                        Text(
                            e, fontSize = 32.sp,
                            modifier = Modifier.clip(CircleShape).clickable {
                                Repo.react(me.uid, target.chatId, single.id, e, single.reactions[me.uid])
                                if (single.reactions[me.uid] != e) launch { Repo.reactNotify(me, target, single, e) }
                                onDone()
                            }.padding(5.dp)
                        )
                    }
                }
}

@Composable
private fun androidx.compose.foundation.layout.BoxScope.ListOverlays(
    listState: androidx.compose.foundation.lazy.LazyListState, visible: List<Message>, atBottom: Boolean, newBelow: Int, accent: Color, onDown: () -> Unit
) {
    val density = LocalDensity.current
            run {
                // Gün etiketi yalnızca kullanıcı parmakla listeyi gerçekten kaydırınca görünür (sohbete girişte ve en dipteyken yukarı itince görünmez)
                var showChip by remember { mutableStateOf(false) }
                var armed by remember { mutableStateOf(false) }
                LaunchedEffect(listState) {
                    listState.interactionSource.interactions.collect { i ->
                        if (i is androidx.compose.foundation.interaction.DragInteraction.Start) armed = true
                    }
                }
                // Parmakla kaydırma başladıysa etiket kaydırma boyunca açık kalır; kaydırma durup 1,2 sn geçince kapanır.
                // (Daha önce uzun kaydırmada araya giren duraksamada "armed" sıfırlanıp etiket bir daha çıkmıyordu)
                LaunchedEffect(listState.isScrollInProgress) {
                    if (listState.isScrollInProgress) { if (armed) showChip = true }
                    else { kotlinx.coroutines.delay(1200); showChip = false; armed = false }
                }
                val byId = remember(visible) { visible.associateBy { it.id } }
                val topMsg = listState.layoutInfo.visibleItemsInfo.lastOrNull { byId.containsKey(it.key) }?.let { byId[it.key] }
                androidx.compose.animation.AnimatedVisibility(
                    visible = showChip && topMsg != null,
                    enter = androidx.compose.animation.slideInVertically { -it * 2 } + androidx.compose.animation.fadeIn(),
                    exit = androidx.compose.animation.slideOutVertically { -it * 2 },
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 4.dp)
                ) {
                    DayChip(dayLabel(topMsg?.let { effTime(it) } ?: 0L))
                }
            }
            if (!atBottom) {
                Box(Modifier.align(Alignment.BottomEnd).padding(12.dp)) {
                    Box(
                        Modifier.size(with(density) { 80.toDp() }, with(density) { 100.toDp() })
                            .clip(RoundedCornerShape(50)).background(AuraSurface.copy(alpha = 0.72f))
                            .clickable { onDown() },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.KeyboardDoubleArrowDown, "Aşağı", tint = AuraWhite, modifier = Modifier.size(26.dp)) }
                    if (newBelow > 0) {
                        Box(
                            Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-8).dp).heightIn(min = 20.dp).widthIn(min = 20.dp)
                                .clip(CircleShape).background(accent).padding(horizontal = 5.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(if (newBelow > 99) "99+" else newBelow.toString(), color = AuraWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
}

@Composable
private fun ChatInputField(
    text: String, onText: (String) -> Unit, multiLine: Boolean, onMultiLine: (Boolean) -> Unit,
    hasImages: Boolean, viewOnceOn: Boolean, inputFocus: androidx.compose.ui.focus.FocusRequester, showAttach: Boolean,
    onFocusWhileAttach: () -> Unit, accent: Color, inputBorder: Color,
    plusBtn: @Composable () -> Unit, sendBtn: @Composable () -> Unit, replying: Boolean = false
) {
                val multi = multiLine && text.isNotEmpty()
                Box(Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                    Box(
                        Modifier.fillMaxWidth().padding(
                            start = 16.dp,
                            end = if (multi) 46.dp else 100.dp,
                            top = if (multi) 12.dp else 4.dp,
                            bottom = if (multi) 56.dp else 4.dp
                        ).align(Alignment.CenterStart)
                    ) {
                        if (text.isEmpty()) {
                            Text(
                                if (hasImages) (if (viewOnceOn) "Bir kez görüntülenecek" else "Başlık ekle…") else if (replying) "Alıntıya cevap verin..." else "Bir mesaj yazın...",
                                color = AuraMuted, style = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, lineHeightStyle = auraLH), modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                        AuraTextField(
                            value = text,
                            onValueChange = {
                                onText(it)
                                if (it.isEmpty()) onMultiLine(false)
                            },
                            textStyle = TextStyle(color = AuraWhite, fontSize = 14.sp, lineHeight = 20.sp, lineHeightStyle = auraLH),
                            cursorBrush = SolidColor(inputBorder),
                            maxLines = 4,
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Sentences),
                            onTextLayout = { if (it.lineCount > 1) onMultiLine(true) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .focusRequester(inputFocus)
                                .onFocusChanged { if (it.isFocused && showAttach) onFocusWhileAttach() }
                        )
                    }
                    if (multi) {
                        Box(
                            Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 12.dp).size(22.dp).clip(CircleShape)
                                .background(accent).clickable { onText(""); onMultiLine(false) },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Close, "Temizle", tint = AuraWhite, modifier = Modifier.size(15.dp)) }
                    }
                    Row(
                        Modifier.align(if (multi) Alignment.BottomEnd else Alignment.CenterEnd).padding(end = 7.5.dp, bottom = if (multi) 7.5.dp else 0.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        plusBtn()
                        sendBtn()
                    }
                }
}


private fun pinPreview(m: Message): String =
    m.text.ifBlank {
        when (m.type) {
            "image" -> "📷 Fotoğraf"; "audio" -> "🎤 Sesli mesaj"; "video" -> "🎥 Video"
            "document", "file" -> "📄 " + m.fileName; "location" -> "📍 Konum"; "poll" -> "📊 " + m.question
            else -> "Mesaj"
        }
    }.replace('\n', ' ')

@Composable
private fun PinnedBar(pins: List<Message>, me: UserProfile, target: ChatTarget, onJump: (String) -> Unit, onUnpin: (Message) -> Unit) {
    var open by remember { mutableStateOf(false) }
    if (pins.size <= 1 && open) open = false
    fun who(m: Message) = if (m.senderUid == me.uid) "Sen" else m.senderName.ifBlank { target.name }
    Column(Modifier.fillMaxWidth().background(AuraBlack).animateContentSize()) {
        Row(
            Modifier.fillMaxWidth().height(38.dp)
                .clickable { if (pins.size > 1) open = !open else onJump(pins[0].id) }
                .padding(start = 16.dp, end = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.PushPin, null, tint = AuraMuted, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(10.dp))
            if (pins.size > 1) {
                Text("${pins.size} sabitlenmiş mesaj", color = AuraWhite, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1)
                Icon(if (open) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, null, tint = AuraMuted, modifier = Modifier.size(20.dp))
            } else {
                Text(who(pins[0]) + ": ", color = AuraMuted, fontSize = 13.sp, maxLines = 1)
                Text(pinPreview(pins[0]), color = AuraWhite, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                IconButton(onClick = { onUnpin(pins[0]) }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, "Sabitlemeyi kaldır", tint = AuraMuted, modifier = Modifier.size(16.dp))
                }
            }
        }
        if (open && pins.size > 1) {
            pins.forEach { m ->
                Row(
                    Modifier.fillMaxWidth().height(40.dp).clickable { open = false; onJump(m.id) }.padding(start = 42.dp, end = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(who(m) + ": ", color = AuraMuted, fontSize = 13.sp, maxLines = 1)
                    Text(pinPreview(m), color = AuraWhite, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    IconButton(onClick = { onUnpin(m) }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, "Sabitlemeyi kaldır", tint = AuraMuted, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(0.5.dp).background(AuraMuted.copy(alpha = 0.25f)))
    }
}

package com.aurachat.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.border
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Description
import androidx.compose.runtime.produceState
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.requiredHeight
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.aurachat.app.AppState
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Media
import com.aurachat.app.data.Message
import com.aurachat.app.data.ReplyRef
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import com.aurachat.app.data.VoiceRecorder
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val REACTIONS = listOf("👍", "❤️", "😂", "😮", "😢", "🙏")

private fun effTime(m: Message): Long = if (m.time <= 0L) System.currentTimeMillis() else m.time

private fun dayKey(ms: Long): Int {
    val c = Calendar.getInstance().apply { timeInMillis = ms }
    return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
}

private fun dayLabel(ms: Long): String {
    val k = dayKey(ms)
    val now = System.currentTimeMillis()
    if (k == dayKey(now)) return "Bugün"
    if (k == dayKey(now - 86_400_000L)) return "Dün"
    return SimpleDateFormat("d MMMM yyyy", Locale("tr")).format(Date(ms))
}

private fun toast(ctx: Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

@SuppressLint("MissingPermission")
@Composable
fun ChatScreen(
    me: UserProfile,
    target: ChatTarget,
    onBack: () -> Unit,
    onOpenGroupInfo: () -> Unit,
    onForward: (List<Message>) -> Unit,
    onCall: (Boolean) -> Unit,
    onOpenTheme: () -> Unit
) {
    val ctx = LocalContext.current
    val theme = remember(target.chatId) { ChatThemes.resolve(ctx, target.chatId) }
    val accent = if (theme.id == "default") AuraBtn else theme.out
    val inputBorder = if (theme.id == "default") AuraBorder else theme.out
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    fun launchSafe(block: suspend () -> Unit) {
        scope.launch {
            try { block() } catch (e: Throwable) { toast(ctx, "İşlem başarısız oldu") }
        }
    }
    val lifecycleOwner = LocalLifecycleOwner.current

    // ---------- Yaşam döngüsü: yalnızca ekran açıkken okundu/yazıyor ----------
    var resumed by remember { mutableStateOf(lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) resumed = true
            if (e == Lifecycle.Event.ON_PAUSE) resumed = false
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }
    DisposableEffect(target.chatId) {
        AppState.activeChatId = target.chatId
        onDispose {
            if (AppState.activeChatId == target.chatId) AppState.activeChatId = null
            AudioPlayer.stop()
        }
    }

    // ---------- Veri ----------
    var limit by remember(target.chatId) { mutableLongStateOf(50L) }
    val raw by remember(target.chatId, limit) { Repo.messagesFlow(target.chatId, limit) }.collectAsState(emptyList())
    val clearedAt by remember(target.chatId) { Repo.clearedAtFlow(me.uid, target.chatId) }.collectAsState(0L)
    val starredList by remember { Repo.starredFlow(me.uid) }.collectAsState(emptyList())
    val starredKeys = remember(starredList) { starredList.map { it.key }.toSet() }
    val otherTyping by remember(target.chatId) {
        if (target.isGroup) kotlinx.coroutines.flow.flowOf(false) else Repo.typingFlow(target.chatId, target.otherUid)
    }.collectAsState(false)

    val visible = remember(raw, clearedAt) {
        raw.filter { m ->
            !m.deletedFor.contains(me.uid) && (clearedAt <= 0L || m.time <= 0L || m.time > clearedAt)
        }
    }

    // Okunmamış ayırıcı: ilk anlık görüntüde bir kez hesaplanır
    var anchorSet by remember(target.chatId) { mutableStateOf(false) }
    var unreadAnchorId by remember(target.chatId) { mutableStateOf<String?>(null) }
    var unreadAnchorCount by remember(target.chatId) { mutableIntStateOf(0) }
    if (!anchorSet && raw.isNotEmpty()) {
        val unreadOnes = raw.filter {
            it.senderUid != me.uid && it.type != "system" &&
                (if (target.isGroup) !it.readBy.contains(me.uid) else !it.read)
        }
        if (unreadOnes.isNotEmpty()) {
            unreadAnchorId = unreadOnes.last().id // en eski okunmamış
            unreadAnchorCount = unreadOnes.size
        }
        anchorSet = true
    }

    val hasUnread = raw.any {
        it.senderUid != me.uid && !it.pending && it.type != "system" &&
            (if (target.isGroup) !it.readBy.contains(me.uid) else !it.read)
    }
    LaunchedEffect(resumed, hasUnread) {
        if (resumed && hasUnread) Repo.markRead(me.uid, target, raw)
    }
    LaunchedEffect(resumed) {
        if (resumed && raw.isEmpty()) Repo.markRead(me.uid, target, raw)
    }

    // ---------- Giriş durumu ----------
    var text by remember(target.chatId) { mutableStateOf("") }
    var replyTo by remember(target.chatId) { mutableStateOf<Message?>(null) }
    var editing by remember(target.chatId) { mutableStateOf<Message?>(null) }
    var pendingImages by remember(target.chatId) { mutableStateOf<List<String>>(emptyList()) }
    var viewOnceOn by remember(target.chatId) { mutableStateOf(false) }
    var voViewing by remember(target.chatId) { mutableStateOf<Message?>(null) }
    var voTick by remember(target.chatId) { mutableStateOf(0) }
    var multiLine by remember(target.chatId) { mutableStateOf(false) }
    var selected by remember(target.chatId) { mutableStateOf<Set<String>>(emptySet()) }
    var showAttach by remember { mutableStateOf(false) }
    var attachClosing by remember { mutableStateOf(false) }
    var attachInstant by remember { mutableStateOf(false) }
    val density = LocalDensity.current
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val kbNow = (WindowInsets.ime.getBottom(density) - WindowInsets.navigationBars.getBottom(density)).coerceAtLeast(0)
    val minSheetPx = with(density) { 230.dp.roundToPx() }
    val minKbPx = with(density) { 150.dp.roundToPx() }
    var lastKb by remember { mutableIntStateOf(with(density) { 300.dp.roundToPx() }) }
    // klavye tam açılıp oturunca yüksekliğini hatırla (panel aynı yüksekliği alır)
    LaunchedEffect(kbNow) {
        if (kbNow > minKbPx) {
            delay(150)
            lastKb = kbNow
        }
    }
    // Girişe dokunulunca klavye tam açılınca panel kapanır (arada toplam yükseklik sabit kalır)
    LaunchedEffect(attachClosing, kbNow, lastKb) {
        if (attachClosing && kbNow >= lastKb - 8) {
            attachInstant = true
            showAttach = false
            attachClosing = false
        }
    }
    LaunchedEffect(attachClosing) {
        if (attachClosing) {
            delay(800)
            attachInstant = true
            showAttach = false
            attachClosing = false
        }
    }
    // Panel yüksekliği: yukarı kayarak açılır, aşağı kayarak kapanır (klavyeye geçişte anında kapanır)
    val panelFullPx = maxOf(lastKb, minSheetPx)
    val panelPx by androidx.compose.animation.core.animateIntAsState(
        targetValue = if (showAttach) panelFullPx else 0,
        animationSpec = if (attachInstant) androidx.compose.animation.core.snap()
        else androidx.compose.animation.core.tween(220, easing = androidx.compose.animation.core.FastOutSlowInEasing),
        label = "attachPanel"
    )
    // panel ile klavye aynı alanı paylaşır: alttaki boşluk ikisinden büyük olanı kadardır
    val bottomGapPx = (kbNow - panelPx).coerceAtLeast(0)
    var showDelete by remember { mutableStateOf(false) }
    var viewer by remember { mutableStateOf<Pair<List<String>, Int>?>(null) }
    var busy by remember { mutableStateOf(false) }

    // yazıyor bilgisi
    var typingSent by remember { mutableStateOf(false) }
    LaunchedEffect(text, resumed) {
        if (resumed && text.isNotBlank() && editing == null) {
            if (!typingSent) {
                Repo.setTyping(me.uid, target, true)
                typingSent = true
            }
            delay(3000)
            Repo.setTyping(me.uid, target, false)
            typingSent = false
        } else if (typingSent) {
            Repo.setTyping(me.uid, target, false)
            typingSent = false
        }
    }
    DisposableEffect(target.chatId) {
        onDispose { if (typingSent) Repo.setTyping(me.uid, target, false) }
    }

    fun clearSelection() { selected = emptySet() }

    BackHandler(enabled = selected.isNotEmpty() || replyTo != null || editing != null) {
        when {
            selected.isNotEmpty() -> clearSelection()
            editing != null -> { editing = null; text = "" }
            else -> replyTo = null
        }
    }

    BackHandler(enabled = showAttach) { showAttach = false }

    fun replyRefOf(): ReplyRef? = replyTo?.let {
        ReplyRef(it.id, it.senderName.ifBlank { "Kullanıcı" }, Repo.previewOf(it).take(100), it.senderUid)
    }

    // ---------- Gönder ----------
    fun send() {
        val t = text.trim()
        val ed = editing
        if (ed != null) {
            if (t.isNotEmpty() && t != ed.text) Repo.editText(target.chatId, ed.id, t)
            editing = null
            text = ""
            return
        }
        if (pendingImages.isNotEmpty()) {
            val imgs = pendingImages
            if (imgs.sumOf { it.length } > 900_000) {
                toast(ctx, "Fotoğraflar çok büyük, daha az seç")
                return
            }
            val r = replyRefOf()
            val vo = viewOnceOn && imgs.size == 1
            pendingImages = emptyList()
            viewOnceOn = false
            text = ""
            replyTo = null
            launchSafe { Repo.sendImages(me, target, imgs, t, r, vo) }
            return
        }
        if (t.isEmpty()) return
        val r = replyRefOf()
        text = ""
        replyTo = null
        launchSafe { Repo.sendText(me, target, t, r) }
    }

    // ---------- Medya seçiciler ----------
    fun addImages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        scope.launch {
            busy = true
            val multi = uris.size > 1 || pendingImages.isNotEmpty()
            val limitBytes = if (multi) 150 * 1024 else 300 * 1024
            val out = withContext(Dispatchers.IO) { uris.mapNotNull { Media.compress(ctx, it, limitBytes) } }
            pendingImages = (pendingImages + out).take(5)
            busy = false
            if (out.size < uris.size) toast(ctx, "Bazı fotoğraflar okunamadı")
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(5)) { uris ->
        addImages(uris)
    }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = cameraUri
        if (ok && u != null) addImages(listOf(u))
    }
    val docLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            launchSafe {
                busy = true
                val f = withContext(Dispatchers.IO) { Media.readDocument(ctx, uri) }
                busy = false
                if (f == null) {
                    toast(ctx, "Belge okunamadı ya da 700 KB'tan büyük")
                } else {
                    val r = replyRefOf()
                    replyTo = null
                    Repo.sendDocument(me, target, f.name, f.mime, f.dataUrl, r)
                }
            }
        }
    }

    fun sendLocationNow() {
        scope.launch {
            toast(ctx, "Konum alınıyor…")
            try {
                val client = LocationServices.getFusedLocationProviderClient(ctx)
                val loc = client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
                    ?: client.lastLocation.await()
                if (loc == null) {
                    toast(ctx, "Konum alınamadı")
                } else {
                    val r = replyRefOf()
                    replyTo = null
                    Repo.sendLocation(me, target, loc.latitude, loc.longitude, r)
                }
            } catch (e: Throwable) {
                toast(ctx, "Konum alınamadı")
            }
        }
    }
    val locPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) sendLocationNow() else toast(ctx, "Konum izni gerekli")
    }

    // ---------- Ses kaydı ----------
    val recorder = remember { VoiceRecorder(ctx) }
    var recording by remember { mutableStateOf(false) }
    var recSec by remember { mutableIntStateOf(0) }

    fun finishRecording(send: Boolean) {
        recording = false
        if (!send) {
            recorder.cancel()
            return
        }
        val res = recorder.stop()
        if (res == null) {
            toast(ctx, "Kayıt çok kısa")
            return
        }
        val (file, sec) = res
        val r = replyRefOf()
        replyTo = null
        launchSafe {
            val data = withContext(Dispatchers.IO) { Media.fileToDataUrl(file, "audio/mp4") }
            file.delete()
            if (data.length > 950_000) toast(ctx, "Ses kaydı çok uzun") else Repo.sendAudio(me, target, data, sec, r)
        }
    }

    fun startRecording() {
        if (recorder.start()) {
            recSec = 0
            recording = true
        } else {
            toast(ctx, "Kayıt başlatılamadı")
        }
    }
    val micPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording() else toast(ctx, "Mikrofon izni gerekli")
    }
    LaunchedEffect(recording) {
        while (recording) {
            delay(300)
            recSec = recorder.elapsedSec()
            if (recSec >= 119) {
                finishRecording(true)
            }
        }
    }
    DisposableEffect(Unit) { onDispose { recorder.cancel() } }

    // ---------- Liste durumu ----------
    val listState = rememberLazyListState()
    val atBottom by remember { derivedStateOf { listState.firstVisibleItemIndex <= 1 } }
    val newestId = visible.firstOrNull()?.id
    val newestMine = visible.firstOrNull()?.senderUid == me.uid
    LaunchedEffect(newestId) {
        if (newestId != null && (atBottom || newestMine)) listState.animateScrollToItem(0)
    }

    val selectedMsgs = visible.filter { selected.contains(it.id) }.sortedBy { effTime(it) }
    val single = if (selectedMsgs.size == 1) selectedMsgs[0] else null

    // ---------- Arayüz ----------
    Column(
        Modifier
            .fillMaxSize()
            .themeBackground(theme)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(bottom = with(density) { bottomGapPx.toDp() })
    ) {
        // Üst çubuk (eski sürümle aynı: siyah, 65dp)
        if (selected.isNotEmpty()) {
            var moreMenu by remember { mutableStateOf(false) }
            Row(
                Modifier.fillMaxWidth().height(65.dp).background(Color.Black).padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { clearSelection() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "İptal", tint = Color.White) }
                Text("${selected.size}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f).padding(start = 6.dp))
                if (single != null && !single.deleted && single.type != "system") {
                    IconButton(onClick = { replyTo = single; editing = null; clearSelection() }) {
                        Icon(Icons.AutoMirrored.Filled.Reply, "Yanıtla", tint = Color.White)
                    }
                    val st = starredKeys.contains(Repo.starKey(target.chatId, single.id))
                    IconButton(onClick = {
                        Repo.toggleStar(me.uid, target, single, st)
                        clearSelection()
                    }) { Icon(if (st) Icons.Default.Star else Icons.Default.StarBorder, "Yıldız", tint = Color.White) }
                }
                IconButton(onClick = { showDelete = true }) { Icon(Icons.Default.Delete, "Sil", tint = Color.White) }
                val copyable = selectedMsgs.filter { !it.deleted && it.text.isNotBlank() }
                if (copyable.isNotEmpty()) {
                    IconButton(onClick = {
                        clipboard.setText(AnnotatedString(copyable.joinToString("\n") { it.text }))
                        toast(ctx, "Kopyalandı")
                        clearSelection()
                    }) { Icon(Icons.Default.ContentCopy, "Kopyala", tint = Color.White) }
                }
                if (selectedMsgs.none { it.deleted || it.type == "system" || it.type == "poll" || it.type == "call" || it.viewOnce }) {
                    IconButton(onClick = { onForward(selectedMsgs); clearSelection() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, "İlet", tint = Color.White)
                    }
                }
                val canEdit = single != null && single.senderUid == me.uid && single.type == "text" && !single.deleted &&
                    System.currentTimeMillis() - effTime(single) < 15 * 60 * 1000L
                if (canEdit && single != null) {
                    Box {
                        IconButton(onClick = { moreMenu = true }) { Icon(Icons.Default.MoreVert, "Daha fazla", tint = Color.White) }
                        DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Default.Edit, null) },
                                text = { Text("Düzenle") },
                                onClick = {
                                    moreMenu = false
                                    editing = single
                                    text = single.text
                                    replyTo = null
                                    clearSelection()
                                }
                            )
                        }
                    }
                }
            }
            if (single != null && !single.deleted && single.type != "system") {
                Row(
                    Modifier.align(Alignment.CenterHorizontally).padding(vertical = 6.dp)
                        .clip(RoundedCornerShape(28.dp)).background(Color(0xFF233138)).padding(horizontal = 10.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    REACTIONS.forEach { e ->
                        Text(
                            e, fontSize = 26.sp,
                            modifier = Modifier.clip(CircleShape).clickable {
                                Repo.react(me.uid, target.chatId, single.id, e, single.reactions[me.uid])
                                clearSelection()
                            }.padding(5.dp)
                        )
                    }
                }
            }
        } else {
            val live by remember(target.otherUid) {
                if (target.isGroup) kotlinx.coroutines.flow.flowOf<UserProfile?>(null) else Repo.profileFlow(target.otherUid)
            }.collectAsState(null)
            val avatar = live?.avatar ?: ""
            val shownName = live?.name?.takeIf { it.isNotBlank() } ?: target.name
            var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
            LaunchedEffect(Unit) { while (true) { delay(5000); nowMs = System.currentTimeMillis() } }
            val presence by remember(target.otherUid) {
                if (target.isGroup) kotlinx.coroutines.flow.flowOf<Repo.Presence?>(null) else Repo.presenceFlow(target.otherUid)
            }.collectAsState(null as Repo.Presence?)
            val groupData by remember(target.chatId) {
                if (target.isGroup) Repo.groupFlow(target.chatId) else kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.GroupData?>(null)
            }.collectAsState(null as com.aurachat.app.data.GroupData?)
            val memberNames by produceState<Map<String, String>>(emptyMap(), groupData?.members) {
                value = (groupData?.members ?: emptyList()).associateWith { u ->
                    if (u == me.uid) "Sen" else Repo.profileOf(u).name
                }
            }
            val typingUids by remember(target.chatId) {
                if (target.isGroup) Repo.groupTypingFlow(target.chatId, me.uid) else kotlinx.coroutines.flow.flowOf(emptyList<String>())
            }.collectAsState(emptyList<String>())

            val status: Pair<String, Boolean> = when {
                target.isGroup && typingUids.isNotEmpty() -> {
                    val n = typingUids.mapNotNull { memberNames[it] }.filter { it.isNotBlank() }
                    Pair(if (n.size in 1..2) n.joinToString(", ") + " yazıyor..." else "${typingUids.size} kişi yazıyor...", true)
                }
                target.isGroup -> Pair(memberNames.values.filter { it.isNotBlank() }.joinToString(", "), false)
                otherTyping -> Pair("yazıyor...", true)
                presence == null || Repo.isPresenceHidden() || presence!!.lastSeenMs <= 0L -> Pair("", false)
                presence!!.online && nowMs - presence!!.lastSeenMs < 25000L -> Pair("çevrimiçi", true)
                else -> Pair(lastSeenText(presence!!.lastSeenMs), false)
            }

            Row(
                Modifier.fillMaxWidth().height(65.dp).background(Color.Black).padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
                Row(
                    Modifier.weight(1f).clickable { onOpenGroupInfo() },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(shownName, if (target.isGroup) (groupData?.photo ?: "") else avatar, 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(shownName, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            status.first.ifEmpty { " " },
                            color = if (status.second) AuraGreen else AuraMuted,
                            fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                if (!target.isGroup) {
                    IconButton(onClick = { onCall(false) }) { Icon(Icons.Default.Call, "Sesli ara", tint = Color.White) }
                    IconButton(onClick = { onCall(true) }) { Icon(Icons.Default.Videocam, "Görüntülü ara", tint = Color.White) }
                }
                var headMenu by remember { mutableStateOf(false) }
                Box {
                    IconButton(onClick = { headMenu = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = Color.White) }
                    DropdownMenu(expanded = headMenu, onDismissRequest = { headMenu = false }) {
                        DropdownMenuItem(text = { Text("Sohbet teması") }, onClick = { headMenu = false; onOpenTheme() })
                        DropdownMenuItem(
                            text = { Text(if (target.isGroup) "Grup bilgisi" else "Kişi bilgisi") },
                            onClick = { headMenu = false; onOpenGroupInfo() }
                        )
                    }
                }
            }
        }

        // Mesajlar
        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                state = listState,
                reverseLayout = true,
                verticalArrangement = Arrangement.Top,
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp)
            ) {
                itemsIndexed(visible, key = { _, m -> m.id }) { i, m ->
                    val older = visible.getOrNull(i + 1)
                    val newDay = older == null || dayKey(effTime(older)) != dayKey(effTime(m))
                    Column {
                        if (newDay) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    dayLabel(effTime(m)), color = AuraMuted, fontSize = 12.sp,
                                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(AuraSurface).padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        if (m.id == unreadAnchorId && unreadAnchorCount > 0) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Color(0x3322C55E)), contentAlignment = Alignment.Center) {
                                Text("$unreadAnchorCount okunmamış mesaj", color = AuraGreen, fontSize = 12.sp, modifier = Modifier.padding(4.dp))
                            }
                        }
                        MessageBubble(
                            m = m,
                            me = me.uid,
                            isGroup = target.isGroup,
                            mineColor = theme.out,
                            starred = starredKeys.contains(Repo.starKey(target.chatId, m.id)),
                            selected = selected.contains(m.id),
                            onClick = {
                                if (selected.isNotEmpty() && m.type != "system") {
                                    selected = if (selected.contains(m.id)) selected - m.id else selected + m.id
                                }
                            },
                            onLongClick = {
                                if (m.type != "system") selected = if (selected.contains(m.id)) selected - m.id else selected + m.id
                            },
                            onQuoteClick = { id ->
                                val idx = visible.indexOfFirst { it.id == id }
                                if (idx >= 0) scope.launch { listState.animateScrollToItem(idx) }
                                else toast(ctx, "Mesaj yüklenmemiş, yukarıdan eski mesajları yükle")
                            },
                            onOpenImages = { list, idx -> viewer = Pair(list, idx) },
                            viewOnceSeen = voTick >= 0 && Repo.isViewOnceSeen(target.chatId, m.id),
                            onOpenViewOnce = { msg -> voViewing = msg },
                            onOpenDocument = { msg ->
                                try {
                                    val f = Media.writeCacheFile(ctx, msg.imageUrl, msg.fileName.ifBlank { "belge" })
                                    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                                    val i = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, msg.fileMime.ifBlank { "*/*" })
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    ctx.startActivity(i)
                                } catch (e: Throwable) {
                                    toast(ctx, "Bu belgeyi açacak uygulama yok")
                                }
                            },
                            onOpenLocation = { msg ->
                                try {
                                    val u = Uri.parse("geo:${msg.lat},${msg.lng}?q=${msg.lat},${msg.lng}")
                                    ctx.startActivity(Intent(Intent.ACTION_VIEW, u))
                                } catch (e: Throwable) {
                                    toast(ctx, "Harita uygulaması bulunamadı")
                                }
                            }
                        )
                    }
                }
                if (raw.size >= limit) {
                    item(key = "load-more") {
                        Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                            TextButton(onClick = { limit += 50 }) { Text("Eski mesajları yükle", color = AuraGreen) }
                        }
                    }
                }
            }
            if (!atBottom) {
                IconButton(
                    onClick = { scope.launch { listState.animateScrollToItem(0) } },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp).size(40.dp).clip(CircleShape).background(AuraSurface)
                ) { Icon(Icons.Default.KeyboardArrowDown, "Aşağı", tint = Color.White) }
            }
        }

        // Yanıt / düzenleme çubuğu
        val rep = replyTo
        if (rep != null) {
            Row(
                Modifier.fillMaxWidth().background(AuraSurface).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.width(3.dp).height(34.dp).background(AuraGreen))
                Column(Modifier.weight(1f).padding(start = 8.dp)) {
                    Text(rep.senderName.ifBlank { "Kullanıcı" }, color = AuraGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(Repo.previewOf(rep), color = AuraMuted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { replyTo = null }) { Icon(Icons.Default.Close, "Kapat", tint = AuraMuted) }
            }
        }
        if (editing != null) {
            Row(
                Modifier.fillMaxWidth().background(AuraSurface).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Edit, null, tint = AuraGreen, modifier = Modifier.size(18.dp))
                Text("Mesajı düzenle", color = AuraGreen, fontSize = 13.sp, modifier = Modifier.weight(1f).padding(start = 8.dp))
                IconButton(onClick = { editing = null; text = "" }) { Icon(Icons.Default.Close, "Kapat", tint = AuraMuted) }
            }
        }

        if (busy) {
            Text("İşleniyor…", color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
        }

        // Giriş çubuğu (eski sürüm: siyah, yeşil çerçeveli kutu; + ve mikrofon/gönder içinde)
        if (recording) {
            Row(
                Modifier.fillMaxWidth().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { finishRecording(false) }) { Icon(Icons.Default.Delete, "İptal", tint = Color(0xFFEF4444)) }
                Box(Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFEF4444)))
                Text(
                    "  %d:%02d".format(recSec / 60, recSec % 60),
                    color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { finishRecording(true) },
                    modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(accent)
                ) { Icon(Icons.AutoMirrored.Filled.Send, "Gönder", tint = Color.White) }
            }
        } else {
            val canSend = text.isNotBlank() || pendingImages.isNotEmpty()
            val boxShape = RoundedCornerShape(18.dp)
            val plusBtn: @Composable () -> Unit = {
                IconButton(onClick = {
                    if (showAttach) {
                        attachInstant = false
                        showAttach = false
                        attachClosing = false
                    } else {
                        attachInstant = false
                        attachClosing = false
                        showAttach = true
                        focusManager.clearFocus()
                        keyboard?.hide()
                    }
                }) {
                    Icon(Icons.Default.Add, "Ekle", tint = Color.White, modifier = Modifier.size(30.dp))
                }
            }
            val sendBtn: @Composable () -> Unit = {
                IconButton(
                    onClick = {
                        if (canSend) send() else {
                            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                startRecording()
                            } else {
                                micPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    modifier = Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(accent)
                ) {
                    Icon(
                        if (canSend) Icons.AutoMirrored.Filled.Send else Icons.Default.Mic,
                        if (canSend) "Gönder" else "Ses kaydı",
                        tint = Color.White
                    )
                }
            }
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp)
                    .clip(boxShape)
                    .background(Color.Black)
                    .border(1.dp, inputBorder, boxShape)
                    .animateContentSize()
            ) {
                if (pendingImages.isNotEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                            .padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        pendingImages.forEachIndexed { idx, img ->
                            Box(Modifier.size(width = 71.dp, height = 71.dp).padding(top = 6.dp, end = 6.dp)) {
                                DataUrlImage(img, 220, Modifier.size(65.dp).clip(RoundedCornerShape(12.dp)), androidx.compose.ui.layout.ContentScale.Crop)
                                Box(
                                    Modifier.align(Alignment.TopEnd).offset(x = 0.dp, y = (-0).dp).size(20.dp).clip(CircleShape).background(accent)
                                        .clickable {
                                            pendingImages = pendingImages.filterIndexed { j, _ -> j != idx }
                                            if (pendingImages.size != 1) viewOnceOn = false
                                        },
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.Close, "Kaldır", tint = Color.White, modifier = Modifier.size(14.dp)) }
                            }
                        }
                        if (pendingImages.size == 1) {
                            Box(
                                Modifier.size(34.dp).clip(CircleShape)
                                    .background(if (viewOnceOn) accent else Color.Transparent)
                                    .border(2.dp, if (viewOnceOn) accent else AuraMuted, CircleShape)
                                    .clickable { viewOnceOn = !viewOnceOn },
                                contentAlignment = Alignment.Center
                            ) { Text("1", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.weight(1f).padding(vertical = 8.dp)) {
                        if (text.isEmpty()) {
                            Text(
                                if (pendingImages.isNotEmpty()) (if (viewOnceOn) "Bir kez görüntülenecek" else "Başlık ekle…") else "Bir mesaj yazın...",
                                color = AuraMuted, fontSize = 17.sp
                            )
                        }
                        BasicTextField(
                            value = text,
                            onValueChange = { text = it },
                            textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
                            cursorBrush = SolidColor(inputBorder),
                            maxLines = 6,
                            onTextLayout = { multiLine = it.lineCount > 1 },
                            modifier = Modifier
                                .fillMaxWidth()
                                .onFocusChanged { if (it.isFocused && showAttach) attachClosing = true }
                        )
                    }
                    if (multiLine && text.isNotEmpty()) {
                        IconButton(onClick = { text = "" }) { Icon(Icons.Default.Close, "Temizle", tint = AuraMuted) }
                    } else {
                        plusBtn()
                        sendBtn()
                    }
                }
                if (multiLine && text.isNotEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().padding(end = 4.dp, bottom = 4.dp),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        plusBtn()
                        sendBtn()
                    }
                }
            }
        }

        if (panelPx > 0 && !recording) {
            Box(Modifier.fillMaxWidth().height(with(density) { panelPx.toDp() }).clipToBounds()) {
            AttachSheet(
                height = with(density) { panelFullPx.toDp() },
                onGallery = {
                    showAttach = false
                    galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onCamera = {
                    showAttach = false
                    try {
                        val dir = File(ctx.cacheDir, "camera").also { it.mkdirs() }
                        val f = File(dir, "photo_${System.currentTimeMillis()}.jpg")
                        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                        cameraUri = u
                        cameraLauncher.launch(u)
                    } catch (e: Throwable) {
                        toast(ctx, "Kamera açılamadı")
                    }
                },
                onLocation = {
                    showAttach = false
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        sendLocationNow()
                    } else {
                        locPermLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                    }
                },
                onDocument = {
                    showAttach = false
                    docLauncher.launch(arrayOf("*/*"))
                },
                onPoll = { showAttach = false; toast(ctx, "Anket bu sürümde yok") },
                onShare = { showAttach = false; toast(ctx, "Ekran paylaşımı bu sürümde yok") },
                accent = accent,
                maxPick = (5 - pendingImages.size).coerceAtLeast(1),
                onPickGallery = { uris -> showAttach = false; addImages(uris) }
            )
            }
        }
    }

    voViewing?.let { vm ->
        ViewOnceViewer(vm.imageUrl) {
            Repo.consumeViewOnce(target.chatId, vm.id, target.isGroup)
            voViewing = null
            voTick++
        }
    }

    // Silme penceresi
    if (showDelete) {
        val allMine = selectedMsgs.isNotEmpty() && selectedMsgs.all { it.senderUid == me.uid && !it.deleted && !it.pending }
        AlertDialog(
            onDismissRequest = { showDelete = false },
            containerColor = AuraSurface,
            title = { Text("Mesaj silinsin mi?", color = Color.White) },
            text = { Text("${selectedMsgs.size} mesaj", color = AuraMuted) },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    if (allMine) {
                        TextButton(onClick = {
                            selectedMsgs.forEach { Repo.deleteForEveryone(target.chatId, it.id) }
                            showDelete = false
                            clearSelection()
                        }) { Text("Herkesten sil", color = Color(0xFFEF4444)) }
                    }
                    TextButton(onClick = {
                        selectedMsgs.forEach { Repo.deleteForMe(me.uid, target.chatId, it.id) }
                        showDelete = false
                        clearSelection()
                    }) { Text("Benden sil", color = Color(0xFFEF4444)) }
                    TextButton(onClick = { showDelete = false }) { Text("Vazgeç", color = AuraGreen) }
                }
            }
        )
    }

    val v = viewer
    if (v != null) ImageViewer(v.first, v.second) { viewer = null }
}

private fun lastSeenText(ms: Long): String {
    val time = SimpleDateFormat("HH:mm", Locale("tr")).format(Date(ms))
    val startToday = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    return when {
        ms >= startToday -> "son görülme bugün $time"
        ms >= startToday - 86_400_000L -> "son görülme dün $time"
        else -> "son görülme " + SimpleDateFormat("d MMMM", Locale("tr")).format(Date(ms))
    }
}

@Composable
private fun AttachSheet(
    height: androidx.compose.ui.unit.Dp,
    onGallery: () -> Unit,
    onCamera: () -> Unit,
    onLocation: () -> Unit,
    onDocument: () -> Unit,
    onPoll: () -> Unit,
    onShare: () -> Unit,
    accent: Color,
    maxPick: Int,
    onPickGallery: (List<Uri>) -> Unit
) {
    val items = listOf(
        Triple("Galeri", Icons.Default.Image, Color(0xFF3B82F6)) to onGallery,
        Triple("Kamera", Icons.Default.PhotoCamera, Color(0xFFF43F5E)) to onCamera,
        Triple("Konum", Icons.Default.LocationOn, Color(0xFF10B981)) to onLocation,
        Triple("Belge", Icons.Default.Description, Color(0xFFF59E0B)) to onDocument,
        Triple("Anket", Icons.Default.BarChart, Color(0xFF8B5CF6)) to onPoll,
        Triple("Ekran paylaş", Icons.Default.Computer, Color(0xFF06B6D4)) to onShare
    )
    Column(Modifier.fillMaxWidth().requiredHeight(height).clipToBounds().background(Color.Black).padding(horizontal = 12.dp, vertical = 6.dp)) {
        Box(
            Modifier.align(Alignment.CenterHorizontally).padding(vertical = 4.dp)
                .width(44.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF3A4247))
        )
        items.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (info, action) ->
                    Column(
                        Modifier.weight(1f).clickable { action() },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier.fillMaxWidth().height(54.dp)
                                .clip(RoundedCornerShape(27.dp))
                                .border(1.dp, Color(0xFF2A3942), RoundedCornerShape(27.dp)),
                            contentAlignment = Alignment.Center
                        ) { Icon(info.second, info.first, tint = info.third, modifier = Modifier.size(28.dp)) }
                        Text(info.first, color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
        }
        GalleryStrip(accent, maxPick, onPickGallery, Modifier.weight(1f).padding(top = 6.dp))
    }
}

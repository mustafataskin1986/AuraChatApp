package com.aurachat.app.ui

import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.offset
import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.border
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Description
import androidx.compose.runtime.produceState
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.requiredHeight
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardDoubleArrowDown
import androidx.compose.foundation.gestures.draggable
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.focus.focusRequester
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.aurachat.app.AppState
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Media
import com.aurachat.app.data.Message
import com.aurachat.app.data.ReplyRef
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import com.aurachat.app.data.VoiceRecorder
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val REACTIONS = listOf("👍", "❤️", "😂", "😮", "😢", "🙏")

private fun effTime(m: Message): Long = if (m.time <= 0L) System.currentTimeMillis() else m.time

private fun dayKey(ms: Long): Int {
    val c = Calendar.getInstance().apply { timeInMillis = ms }
    return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
}

private fun dayLabel(ms: Long): String {
    val k = dayKey(ms)
    val now = System.currentTimeMillis()
    if (k == dayKey(now)) return "Bugün"
    if (k == dayKey(now - 86_400_000L)) return "Dün"
    val c0 = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    val c1 = Calendar.getInstance().apply { timeInMillis = ms; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    val diff = Math.round((c0.timeInMillis - c1.timeInMillis) / 86_400_000.0)
    if (diff in 2..6) return SimpleDateFormat("EEEE", Locale("tr")).format(Date(ms))
    return SimpleDateFormat("d MMMM yyyy", Locale("tr")).format(Date(ms))
}

private fun toast(ctx: Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

@SuppressLint("MissingPermission")
@Composable
fun ChatScreen(
    me: UserProfile,
    target: ChatTarget,
    onBack: () -> Unit,
    onOpenGroupInfo: () -> Unit,
    onForward: (List<Message>) -> Unit,
    onCall: (Boolean) -> Unit,
    onOpenTheme: () -> Unit,
    jumpToMsgId: String? = null,
    startSearch: Boolean = false,
    onMemberChat: (UserProfile) -> Unit = {},
    onMemberCall: (UserProfile, Boolean) -> Unit = { _, _ -> }
) {
    val c = LocalContext.current
    val th = remember(target.chatId) { ChatThemes.resolve(c, target.chatId) }
    val ac = if (th.id == "default") AuraBtn else th.out
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.foundation.text.selection.LocalTextSelectionColors provides
            androidx.compose.foundation.text.selection.TextSelectionColors(ac, ac.copy(alpha = 0.4f))
    ) {
        ChatScreenImpl(me, target, onBack, onOpenGroupInfo, onForward, onCall, onOpenTheme, jumpToMsgId, startSearch, onMemberChat, onMemberCall)
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@SuppressLint("MissingPermission")
@Composable
private fun ChatScreenImpl(
    me: UserProfile,
    target: ChatTarget,
    onBack: () -> Unit,
    onOpenGroupInfo: () -> Unit,
    onForward: (List<Message>) -> Unit,
    onCall: (Boolean) -> Unit,
    onOpenTheme: () -> Unit,
    jumpToMsgId: String? = null,
    startSearch: Boolean = false,
    onMemberChat: (UserProfile) -> Unit = {},
    onMemberCall: (UserProfile, Boolean) -> Unit = { _, _ -> }
) {
    val ctx = LocalContext.current
    val theme = remember(target.chatId) { ChatThemes.resolve(ctx, target.chatId) }
    val accent = if (theme.id == "default") AuraBtn else theme.out
    val inputBorder = if (theme.id == "default") AuraBorder else theme.out
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    fun launchSafe(block: suspend () -> Unit) {
        scope.launch {
            try { block() } catch (e: Throwable) { toast(ctx, "İşlem başarısız oldu") }
        }
    }
    val lifecycleOwner = LocalLifecycleOwner.current

    // ---------- Yaşam döngüsü: yalnızca ekran açıkken okundu/yazıyor ----------
    var resumed by remember { mutableStateOf(lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) resumed = true
            if (e == Lifecycle.Event.ON_PAUSE) resumed = false
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }
    DisposableEffect(target.chatId) {
        AppState.activeChatId = target.chatId
        onDispose {
            if (AppState.activeChatId == target.chatId) AppState.activeChatId = null
            AudioPlayer.stop()
        }
    }

    // ---------- Veri ----------
    var limit by remember(target.chatId) { mutableLongStateOf(30L) }
    val raw by remember(target.chatId, limit) { Repo.messagesFlow(target.chatId, limit) }.collectAsState(emptyList())
    val clearedAt by remember(target.chatId) { Repo.clearedAtFlow(me.uid, target.chatId) }.collectAsState(remember(target.chatId) { Repo.peekClearedAt(me.uid, target.chatId) })
    val starredList by remember { Repo.starredFlow(me.uid) }.collectAsState(emptyList())
    val starredKeys = remember(starredList) { starredList.map { it.key }.toSet() }
    val otherTyping by remember(target.chatId) {
        if (target.isGroup) kotlinx.coroutines.flow.flowOf(false) else Repo.typingFlow(target.chatId, target.otherUid)
    }.collectAsState(false)

    val localVer = com.aurachat.app.data.LocalMedia.version
    val visible = remember(raw, clearedAt, localVer) {
        raw.filter { m ->
            !m.deletedFor.contains(me.uid) && (clearedAt <= 0L || m.time <= 0L || m.time > clearedAt)
        }.map { com.aurachat.app.data.LocalMedia.localize(it) }
    }
    // Gelen / giden medya telefona (Android/media/AuraChat) yazılır, alıcıda Firebase kopyası silinir
    LaunchedEffect(raw) {
        val todo = raw.filter { com.aurachat.app.data.LocalMedia.needsIngest(it, me.uid, target.isGroup) }
        if (todo.isNotEmpty()) {
            withContext(Dispatchers.IO) {
                todo.forEach { com.aurachat.app.data.LocalMedia.ingestBlocking(target.chatId, it, me.uid, target.isGroup) }
            }
        }
    }

    // Okunmamış ayırıcı: ilk anlık görüntüde bir kez hesaplanır
    val seenBefore = remember(target.chatId) { Repo.lastSeen(target.chatId) }
    val rawNow by androidx.compose.runtime.rememberUpdatedState(raw)
    androidx.compose.runtime.DisposableEffect(target.chatId) {
        onDispose { Repo.setLastSeen(target.chatId, rawNow.maxOfOrNull { it.time } ?: 0L) }
    }
    var anchorSet by remember(target.chatId) { mutableStateOf(false) }
    var unreadAnchorId by remember(target.chatId) { mutableStateOf<String?>(null) }
    var unreadAnchorCount by remember(target.chatId) { mutableIntStateOf(0) }
    if (!anchorSet && raw.isNotEmpty()) {
        val unreadOnes = raw.filter {
            it.senderUid != me.uid && it.type != "system" &&
                (it.time <= 0L || it.time > seenBefore) &&
                (if (target.isGroup) !it.readBy.contains(me.uid) else !it.read)
        }
        if (unreadOnes.isNotEmpty()) {
            unreadAnchorId = unreadOnes.last().id // en eski okunmamış
            unreadAnchorCount = unreadOnes.size
        }
        anchorSet = true
    }

    val hasUnread = raw.any {
        it.senderUid != me.uid && !it.pending && it.type != "system" &&
            (if (target.isGroup) !it.readBy.contains(me.uid) else !it.read)
    }
    LaunchedEffect(resumed, hasUnread) {
        if (resumed && hasUnread) Repo.markRead(me.uid, target, raw)
    }
    LaunchedEffect(resumed) {
        if (resumed && raw.isEmpty()) Repo.markRead(me.uid, target, raw)
    }

    // ---------- Giriş durumu ----------
    var text by remember(target.chatId) { mutableStateOf("") }
    var replyTo by remember(target.chatId) { mutableStateOf<Message?>(null) }
    var editing by remember(target.chatId) { mutableStateOf<Message?>(null) }
    var pendingImages by remember(target.chatId) { mutableStateOf<List<String>>(emptyList()) }
    var viewOnceOn by remember(target.chatId) { mutableStateOf(false) }
    var voViewing by remember(target.chatId) { mutableStateOf<Message?>(null) }
    var voTick by remember(target.chatId) { mutableStateOf(0) }
    var multiLine by remember(target.chatId) { mutableStateOf(false) }
    var editIdx by remember(target.chatId) { mutableStateOf(-1) }
    var showPoll by remember(target.chatId) { mutableStateOf(false) }
    androidx.compose.runtime.LaunchedEffect(target.chatId) { com.aurachat.app.push.Notifs.clear(ctx, target.chatId) }
    var selected by remember(target.chatId) { mutableStateOf<Set<String>>(emptySet()) }
    var showAttach by remember { mutableStateOf(false) }
    var attachClosing by remember { mutableStateOf(false) }
    var attachInstant by remember { mutableStateOf(false) }
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val kbNow = (WindowInsets.ime.getBottom(density) - WindowInsets.navigationBars.getBottom(density)).coerceAtLeast(0)
    val minSheetPx = with(density) { 300.dp.roundToPx() }
    val minKbPx = with(density) { 150.dp.roundToPx() }
    var lastKb by remember { mutableIntStateOf(Repo.savedKbPx().takeIf { it > minKbPx } ?: with(density) { 260.dp.roundToPx() }) }
    // klavye tam açılıp oturunca yüksekliğini hatırla (panel aynı yüksekliği alır)
    LaunchedEffect(kbNow) {
        if (kbNow > minKbPx) {
            delay(150)
            lastKb = kbNow
            Repo.saveKbPx(kbNow)
        }
    }
    // Girişe dokunulunca klavye tam açılınca panel kapanır (arada toplam yükseklik sabit kalır)
    LaunchedEffect(attachClosing, kbNow) {
        if (attachClosing && kbNow > minKbPx) {
            delay(90) // klavye yüksekliği oturdu
            lastKb = kbNow
            Repo.saveKbPx(kbNow)
            attachInstant = true
            showAttach = false
            attachClosing = false
        }
    }
    LaunchedEffect(attachClosing) {
        if (attachClosing) {
            delay(800)
            attachInstant = true
            showAttach = false
            attachClosing = false
        }
    }
    // Panel yüksekliği: yukarı kayarak açılır, aşağı kayarak kapanır (klavyeye geçişte anında kapanır)
    val panelFullPx = maxOf(lastKb, minSheetPx)
    val panelAnim = remember { androidx.compose.animation.core.Animatable(0f) }
    var panelDragging by remember { mutableStateOf(false) }
    var panelExpanded by remember { mutableStateOf(false) }
    LaunchedEffect(showAttach, attachInstant, panelFullPx) {
        if (panelDragging) return@LaunchedEffect
        if (showAttach) {
            if (attachInstant) panelAnim.snapTo(panelFullPx.toFloat())
            else panelAnim.animateTo(
                if (panelExpanded) panelAnim.value.coerceAtLeast(panelFullPx.toFloat()) else panelFullPx.toFloat(),
                androidx.compose.animation.core.tween(320, easing = androidx.compose.animation.core.FastOutSlowInEasing)
            )
        } else {
            panelExpanded = false
            if (attachInstant) panelAnim.snapTo(0f)
            else panelAnim.animateTo(0f, androidx.compose.animation.core.tween(260, easing = androidx.compose.animation.core.FastOutSlowInEasing))
        }
    }
    val panelPx = panelAnim.value.toInt()
    // panel ile klavye aynı alanı paylaşır: alttaki boşluk ikisinden büyük olanı kadardır
    val bottomGapPx = (kbNow - panelPx).coerceAtLeast(0)
    var showDelete by remember { mutableStateOf(false) }
    var viewer by remember { mutableStateOf<Pair<List<String>, Int>?>(null) }
    var busy by remember { mutableStateOf(false) }

    // yazıyor bilgisi
    var typingSent by remember { mutableStateOf(false) }
    LaunchedEffect(text, resumed) {
        if (resumed && text.isNotBlank() && editing == null) {
            if (!typingSent) {
                Repo.setTyping(me.uid, target, true)
                typingSent = true
            }
            delay(3000)
            Repo.setTyping(me.uid, target, false)
            typingSent = false
        } else if (typingSent) {
            Repo.setTyping(me.uid, target, false)
            typingSent = false
        }
    }
    DisposableEffect(target.chatId) {
        onDispose { if (typingSent) Repo.setTyping(me.uid, target, false) }
    }

    fun clearSelection() { selected = emptySet() }

    BackHandler(enabled = selected.isNotEmpty() || replyTo != null || editing != null) {
        when {
            selected.isNotEmpty() -> clearSelection()
            editing != null -> { editing = null; text = "" }
            else -> replyTo = null
        }
    }

    BackHandler(enabled = showAttach) { showAttach = false }

    fun replyRefOf(): ReplyRef? = replyTo?.let {
        ReplyRef(it.id, it.senderName.ifBlank { "Kullanıcı" }, Repo.previewOf(it).take(100), it.senderUid)
    }

    // ---------- Etiketleme (@) ----------
    val mGroup by remember(target.chatId) {
        if (target.isGroup) Repo.groupFlow(target.chatId) else kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.GroupData?>(null)
    }.collectAsState(null as com.aurachat.app.data.GroupData?)
    val mNames by androidx.compose.runtime.produceState<Map<String, String>>(emptyMap(), mGroup?.members) {
        value = (mGroup?.members ?: emptyList()).filter { it != me.uid }.associateWith { u -> Repo.profileOf(u).name }
    }
    val chosenMentions = remember(target.chatId) { androidx.compose.runtime.mutableStateMapOf<String, String>() }
    val mentionMatch = remember(text) { Regex("(^|\\s)@([^@\\n]{0,30})$").find(text) }
    val mentionList: List<Pair<String, String>> = if (!target.isGroup || mentionMatch == null) emptyList() else {
        val q = mentionMatch.groupValues[2].lowercase()
        (listOf("*" to "Herkes") + mNames.entries.filter { it.value.isNotBlank() }.map { it.key to it.value })
            .filter { q.isEmpty() || it.second.lowercase().contains(q) }.take(30)
    }

    // ---------- Gönder ----------
    fun send() {
        val t = text.trim()
        val ed = editing
        if (ed != null) {
            if (t.isNotEmpty() && t != ed.text) Repo.editText(target.chatId, ed.id, t)
            editing = null
            text = ""
            return
        }
        if (pendingImages.isNotEmpty()) {
            val imgs = pendingImages
            if (imgs.sumOf { it.length } > 900_000) {
                toast(ctx, "Fotoğraflar çok büyük, daha az seç")
                return
            }
            val r = replyRefOf()
            val vo = viewOnceOn && imgs.size == 1
            pendingImages = emptyList()
            viewOnceOn = false
            text = ""
            replyTo = null
            launchSafe { Repo.sendImages(me, target, imgs, t, r, vo) }
            return
        }
        if (t.isEmpty()) return
        val r = replyRefOf()
        text = ""
        replyTo = null
        val mUids = ArrayList<String>()
        val mLabels = ArrayList<String>()
        chosenMentions.forEach { (name, uid) ->
            if (Regex("(^|\\s)@" + Regex.escape(name) + "(?=$|[\\s.,;:!?)])").containsMatchIn(t)) {
                if (uid == "*") mNames.keys.forEach { if (!mUids.contains(it)) mUids.add(it) }
                else if (!mUids.contains(uid)) mUids.add(uid)
                if (!mLabels.contains(name)) mLabels.add(name)
            }
        }
        chosenMentions.clear()
        launchSafe { Repo.sendText(me, target, t, r, mUids, mLabels) }
    }

    // ---------- Medya seçiciler ----------
    fun addImages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        scope.launch {
            busy = true
            val multi = uris.size > 1 || pendingImages.isNotEmpty()
            val limitBytes = if (multi) 150 * 1024 else 300 * 1024
            val out = withContext(Dispatchers.IO) { uris.mapNotNull { Media.compress(ctx, it, limitBytes) } }
            pendingImages = (pendingImages + out).take(5)
            busy = false
            if (out.size < uris.size) toast(ctx, "Bazı fotoğraflar okunamadı")
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(5)) { uris ->
        addImages(uris)
    }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = cameraUri
        if (ok && u != null) addImages(listOf(u))
    }
    fun sendVideoUri(u: Uri) {
        launchSafe {
            busy = true
            val v = withContext(Dispatchers.IO) { Media.readVideo(ctx, u) }
            busy = false
            if (v == null) {
                toast(ctx, "Video çok büyük (en fazla 640 KB, yaklaşık 5 sn). Daha kısa çek ya da küçült.")
            } else {
                val r = replyRefOf()
                replyTo = null
                Repo.sendVideo(me, target, v, r)
            }
        }
    }
    val videoPickLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) sendVideoUri(uri)
    }
    var videoCaptureUri by remember { mutableStateOf<Uri?>(null) }
    val videoCaptureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val u = videoCaptureUri
        if (r.resultCode == android.app.Activity.RESULT_OK && u != null) sendVideoUri(u)
    }
    val docLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            launchSafe {
                busy = true
                val f = withContext(Dispatchers.IO) { Media.readDocument(ctx, uri) }
                busy = false
                if (f == null) {
                    toast(ctx, "Belge okunamadı ya da 700 KB'tan büyük")
                } else {
                    val r = replyRefOf()
                    replyTo = null
                    Repo.sendDocument(me, target, f.name, f.mime, f.dataUrl, r)
                }
            }
        }
    }

    fun sendLocationNow() {
        scope.launch {
            toast(ctx, "Konum alınıyor…")
            try {
                val client = LocationServices.getFusedLocationProviderClient(ctx)
                val loc = client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
                    ?: client.lastLocation.await()
                if (loc == null) {
                    toast(ctx, "Konum alınamadı")
                } else {
                    val r = replyRefOf()
                    replyTo = null
                    Repo.sendLocation(me, target, loc.latitude, loc.longitude, r)
                }
            } catch (e: Throwable) {
                toast(ctx, "Konum alınamadı")
            }
        }
    }
    val locPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) sendLocationNow() else toast(ctx, "Konum izni gerekli")
    }

    // ---------- Ses kaydı ----------
    val recorder = remember { VoiceRecorder(ctx) }
    var recording by remember { mutableStateOf(false) }
    var recSec by remember { mutableIntStateOf(0) }

    fun finishRecording(send: Boolean) {
        recording = false
        if (!send) {
            recorder.cancel()
            return
        }
        val res = recorder.stop()
        if (res == null) {
            toast(ctx, "Kayıt çok kısa")
            return
        }
        val (file, sec) = res
        val r = replyRefOf()
        replyTo = null
        launchSafe {
            val data = withContext(Dispatchers.IO) { Media.fileToDataUrl(file, "audio/mp4") }
            file.delete()
            if (data.length > 950_000) toast(ctx, "Ses kaydı çok uzun") else Repo.sendAudio(me, target, data, sec, r)
        }
    }

    fun startRecording() {
        if (recorder.start()) {
            recSec = 0
            recording = true
        } else {
            toast(ctx, "Kayıt başlatılamadı")
        }
    }
    val micPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording() else toast(ctx, "Mikrofon izni gerekli")
    }
    LaunchedEffect(recording) {
        while (recording) {
            delay(300)
            recSec = recorder.elapsedSec()
            if (recSec >= 119) {
                finishRecording(true)
            }
        }
    }
    DisposableEffect(Unit) { onDispose { recorder.cancel() } }

    // ---------- Üç nokta menüsü durumu ----------
    val chatFlags by remember(target.chatId) { Repo.chatFlagsFlow(me.uid, target.chatId) }
        .collectAsState(Repo.ChatFlags(false, false, false))
    val disappearMs by remember(target.chatId) { Repo.disappearFlow(target.chatId) }.collectAsState(0L)
    val blockedList by remember(me.uid) { Repo.blockedFlow(me.uid) }.collectAsState(emptyList())
    val otherBlocked = !target.isGroup && blockedList.contains(target.otherUid)
    val theirBlockList by remember(target.otherUid, target.isGroup) {
        if (target.isGroup) kotlinx.coroutines.flow.flowOf(emptyList<String>()) else Repo.blockedFlow(target.otherUid)
    }.collectAsState(emptyList())
    val blockedByThem = !target.isGroup && theirBlockList.contains(me.uid)
    val chatBlocked = otherBlocked || blockedByThem
    var showDisappear by remember { mutableStateOf(false) }
    var showWipe by remember { mutableStateOf(false) }

    // ---------- Liste durumu ----------
    val listState = rememberLazyListState()
    val atBottom by remember { derivedStateOf { listState.firstVisibleItemIndex <= 1 } }
    val newestId = visible.firstOrNull()?.id
    val newestMine = visible.firstOrNull()?.senderUid == me.uid
    var jumpPending by remember(target.chatId, jumpToMsgId) { mutableStateOf(jumpToMsgId != null) }
    var highlightId by remember(target.chatId) { mutableStateOf<String?>(null) }
    LaunchedEffect(highlightId) {
        if (highlightId != null) { delay(1600); highlightId = null }
    }
    LaunchedEffect(jumpPending, raw.size, visible.size, limit) {
        val id = jumpToMsgId
        if (jumpPending && id != null) {
            val idx = visible.indexOfFirst { it.id == id }
            if (idx >= 0) {
                listState.scrollToItem(idx)
                jumpPending = false
                highlightId = id
                for (round in 0 until 3) {
                    delay(220)
                    val i2 = visible.indexOfFirst { it.id == id }.coerceAtLeast(0)
                    val info = listState.layoutInfo
                    val vh = info.viewportSize.height
                    val sz = info.visibleItemsInfo.firstOrNull { it.index == i2 }?.size ?: 0
                    // ters listede negatif ofset öğeyi ekranda yukarı alır → ortada göster
                    listState.scrollToItem(i2, -((vh - sz) / 2).coerceAtLeast(0))
                }
            } else if (raw.isNotEmpty() && raw.size >= limit) {
                limit += 300
            } else {
                // eski mesajlar henüz gelmemiş olabilir: biraz bekle, gelmezse vazgeç
                delay(6000)
                jumpPending = false
            }
        }
    }

    // ---------- Sohbet içi arama ----------
    var videoMsg by remember(target.chatId) { mutableStateOf<Message?>(null) }
    var showVideoChoice by remember { mutableStateOf(false) }
    var reactionsMsgId by remember(target.chatId) { mutableStateOf<String?>(null) }
    var memberSheet by remember(target.chatId) { mutableStateOf<UserProfile?>(null) }
    var searching by remember(target.chatId, startSearch) { mutableStateOf(startSearch) }
    var searchQ by remember(target.chatId) { mutableStateOf("") }
    var matchIdx by remember(target.chatId) { mutableIntStateOf(0) }
    val matches = remember(visible, searchQ) {
        if (searchQ.isBlank()) emptyList()
        else visible.filter { !it.deleted && it.type != "system" && it.text.contains(searchQ, ignoreCase = true) }
    }
    val curMatchId = if (searching) matches.getOrNull(matchIdx)?.id else null
    LaunchedEffect(searchQ) { matchIdx = 0 }
    // Aramadayken geri tuşu klavyeyi kapatır: klavye kapanınca arama çubuğu da kapansın, mesaj kutusu geri gelsin
    val imeBottomPx = WindowInsets.ime.getBottom(androidx.compose.ui.platform.LocalDensity.current)
    var hadIme by remember(searching) { mutableStateOf(false) }
    LaunchedEffect(imeBottomPx, searching) {
        if (searching) {
            if (imeBottomPx > 0) hadIme = true
            else if (hadIme) { searching = false; searchQ = "" }
        }
    }
    LaunchedEffect(curMatchId) {
        val id = curMatchId ?: return@LaunchedEffect
        val i = visible.indexOfFirst { it.id == id }
        if (i >= 0) listState.animateScrollToItem(i)
    }
    // Eski mesajlar: listenin en üstüne yaklaşınca otomatik yüklenir (düğme yok)
    val nearTop by remember { derivedStateOf { (listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0) >= listState.layoutInfo.totalItemsCount - 4 } }
    LaunchedEffect(nearTop, raw.size, limit) {
        if (nearTop && raw.size >= limit && !jumpPending) limit += 50
    }
    var newBelow by remember(target.chatId) { mutableIntStateOf(0) }
    LaunchedEffect(atBottom) { if (atBottom) newBelow = 0 }
    LaunchedEffect(newestId) {
        if (newestId != null && !atBottom && !newestMine && !jumpPending) newBelow++
    }
    LaunchedEffect(newestId) {
        if (!jumpPending && newestId != null && (atBottom || newestMine)) listState.animateScrollToItem(0)
    }

    val selectedMsgs = visible.filter { selected.contains(it.id) }.sortedBy { effTime(it) }
    val single = if (selectedMsgs.size == 1) selectedMsgs[0] else null
    var selTopRoot by remember { mutableFloatStateOf(0f) }
    var listTopRoot by remember { mutableFloatStateOf(0f) }
    var listHpx by remember { mutableFloatStateOf(0f) }
    var listWpx by remember { mutableFloatStateOf(0f) }
    var touchPos by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    var reactBarW by remember { mutableFloatStateOf(0f) }
    var colTopRoot by remember { mutableFloatStateOf(0f) }

    // ---------- Arayüz ----------
    Column(
        Modifier
            .fillMaxSize()
            .themeBackground(theme)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(bottom = with(density) { bottomGapPx.toDp() })
            .onGloballyPositioned { colTopRoot = it.positionInRoot().y }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                        val d = e.changes.firstOrNull { it.pressed && !it.previousPressed }
                        if (d != null && selected.isNotEmpty() && colTopRoot + d.position.y > listTopRoot + listHpx) selected = emptySet()
                    }
                }
            }
    ) {
        // Üst çubuk (eski sürümle aynı: siyah, 65dp)
        if (searching) {
                val searchFocus = remember { androidx.compose.ui.focus.FocusRequester() }
                LaunchedEffect(Unit) { try { searchFocus.requestFocus() } catch (e: Throwable) {} }
                Row(
                    Modifier.fillMaxWidth().height(65.dp).background(Color.Black).padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { searching = false; searchQ = "" }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kapat", tint = Color.White) }
                    Row(
                        Modifier.weight(1f).height(42.dp).clip(RoundedCornerShape(50)).background(AuraSurface).padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.weight(1f)) {
                            if (searchQ.isEmpty()) Text("Sohbette ara...", color = AuraMuted, fontSize = 14.sp)
                            BasicTextField(
                                value = searchQ, onValueChange = { searchQ = it }, singleLine = true,
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { }),
                                textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                                cursorBrush = SolidColor(AuraGreen),
                                modifier = Modifier.fillMaxWidth().focusRequester(searchFocus)
                            )
                        }
                        if (searchQ.isNotEmpty()) {
                            Text(
                                if (matches.isEmpty()) "0" else "${matchIdx + 1}/${matches.size}",
                                color = AuraMuted, fontSize = 12.sp
                            )
                        }
                    }
                    IconButton(
                        onClick = { if (matchIdx < matches.size - 1) matchIdx++ },
                        modifier = Modifier.size(40.dp)
                    ) { Icon(Icons.Default.KeyboardArrowUp, "Önceki", tint = if (matchIdx < matches.size - 1) Color.White else AuraMuted) }
                    IconButton(
                        onClick = { if (matchIdx > 0) matchIdx-- },
                        modifier = Modifier.size(40.dp)
                    ) { Icon(Icons.Default.KeyboardArrowDown, "Sonraki", tint = if (matchIdx > 0) Color.White else AuraMuted) }
                }
        } else if (selected.isNotEmpty()) {
            var moreMenu by remember { mutableStateOf(false) }
            Row(
                Modifier.fillMaxWidth().height(65.dp).background(Color.Black).padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { clearSelection() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "İptal", tint = Color.White) }
                Text("${selected.size}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f).padding(start = 6.dp))
                if (single != null && !single.deleted && single.type != "system") {
                    IconButton(onClick = { replyTo = single; editing = null; clearSelection() }) {
                        Icon(Icons.AutoMirrored.Filled.Reply, "Yanıtla", tint = Color.White)
                    }
                }
                val starMsgs = selectedMsgs.filter { !it.deleted && it.type != "system" && it.type != "call" }
                if (starMsgs.isNotEmpty()) {
                    val allSt = starMsgs.all { starredKeys.contains(Repo.starKey(target.chatId, it.id)) }
                    IconButton(onClick = {
                        starMsgs.forEach {
                            val has = starredKeys.contains(Repo.starKey(target.chatId, it.id))
                            if (allSt) Repo.toggleStar(me.uid, target, it, true) else if (!has) Repo.toggleStar(me.uid, target, it, false)
                        }
                        clearSelection()
                    }) { Icon(if (allSt) Icons.Default.Star else Icons.Default.StarBorder, "Yıldız", tint = Color.White) }
                }
                IconButton(onClick = { showDelete = true }) { Icon(Icons.Default.Delete, "Sil", tint = Color.White) }
                val copyable = selectedMsgs.filter { !it.deleted && it.text.isNotBlank() }
                if (copyable.isNotEmpty()) {
                    IconButton(onClick = {
                        clipboard.setText(AnnotatedString(copyable.joinToString("\n") { it.text }))
                        toast(ctx, "Kopyalandı")
                        clearSelection()
                    }) { Icon(Icons.Default.ContentCopy, "Kopyala", tint = Color.White) }
                }
                if (selectedMsgs.none { it.deleted || it.type == "system" || it.type == "poll" || it.type == "call" || it.viewOnce }) {
                    IconButton(onClick = { onForward(selectedMsgs); clearSelection() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, "İlet", tint = Color.White)
                    }
                }
                val canEdit = single != null && single.senderUid == me.uid && single.type == "text" && !single.deleted &&
                    System.currentTimeMillis() - effTime(single) < 15 * 60 * 1000L
                if (canEdit && single != null) {
                    Box {
                        IconButton(onClick = { moreMenu = true }) { Icon(Icons.Default.MoreVert, "Daha fazla", tint = Color.White) }
                        DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                            DropdownMenuItem(
                                leadingIcon = { Icon(Icons.Default.Edit, null) },
                                text = { Text("Düzenle") },
                                onClick = {
                                    moreMenu = false
                                    editing = single
                                    text = single.text
                                    replyTo = null
                                    clearSelection()
                                }
                            )
                        }
                    }
                }
            }
        } else {
            val live by remember(target.otherUid) {
                if (target.isGroup) kotlinx.coroutines.flow.flowOf<UserProfile?>(null) else Repo.profileFlow(target.otherUid)
            }.collectAsState(if (target.isGroup) null else Repo.peekProfile(target.otherUid))
            val avatar = live?.avatar ?: ""
            val shownName = live?.name?.takeIf { it.isNotBlank() } ?: target.name
            var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
            LaunchedEffect(Unit) { while (true) { delay(5000); nowMs = System.currentTimeMillis() } }
            val presence by remember(target.otherUid) {
                if (target.isGroup) kotlinx.coroutines.flow.flowOf<Repo.Presence?>(null) else Repo.presenceFlow(target.otherUid)
            }.collectAsState(null as Repo.Presence?)
            val groupData by remember(target.chatId) {
                if (target.isGroup) Repo.groupFlow(target.chatId) else kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.GroupData?>(null)
            }.collectAsState(if (target.isGroup) Repo.peekGroup(target.chatId) else null)
            val memberNames by produceState<Map<String, String>>(emptyMap(), groupData?.members) {
                value = (groupData?.members ?: emptyList()).associateWith { u ->
                    if (u == me.uid) "Sen" else Repo.profileOf(u).name
                }
            }
            val typingUids by remember(target.chatId) {
                if (target.isGroup) Repo.groupTypingFlow(target.chatId, me.uid) else kotlinx.coroutines.flow.flowOf(emptyList<String>())
            }.collectAsState(emptyList<String>())

            val status: Pair<String, Boolean> = when {
                target.isGroup && typingUids.isNotEmpty() -> {
                    val n = typingUids.mapNotNull { memberNames[it] }.filter { it.isNotBlank() }
                    Pair(if (n.size in 1..2) n.joinToString(", ") + " yazıyor..." else "${typingUids.size} kişi yazıyor...", true)
                }
                target.isGroup -> Pair(memberNames.values.filter { it.isNotBlank() }.joinToString(", "), false)
                otherTyping -> Pair("yazıyor...", true)
                presence == null || Repo.isPresenceHidden() || presence!!.lastSeenMs <= 0L -> Pair("", false)
                presence!!.online && nowMs - presence!!.lastSeenMs < 25000L -> Pair("çevrimiçi", true)
                else -> Pair(lastSeenText(presence!!.lastSeenMs), false)
            }

            Row(
                Modifier.fillMaxWidth().height(65.dp).background(Color.Black).padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
                Row(
                    Modifier.weight(1f).clickable { onOpenGroupInfo() },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(shownName, if (target.isGroup) (groupData?.photo ?: "") else avatar, (108f / androidx.compose.ui.platform.LocalDensity.current.density).dp, isGroup = target.isGroup)
                    Spacer(Modifier.width(12.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        val tight = androidx.compose.ui.text.style.LineHeightStyle(
                            androidx.compose.ui.text.style.LineHeightStyle.Alignment.Center,
                            androidx.compose.ui.text.style.LineHeightStyle.Trim.Both
                        )
                        Text(
                            shownName, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = androidx.compose.ui.text.TextStyle(lineHeight = 17.sp, lineHeightStyle = tight)
                        )
                        Text(
                            status.first.ifEmpty { " " },
                            color = if (status.second) AuraGreen else AuraMuted,
                            fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = androidx.compose.ui.text.TextStyle(lineHeight = 14.sp, lineHeightStyle = tight)
                        )
                    }
                }
                run {
                    IconButton(onClick = { if (chatBlocked) toast(ctx, if (otherBlocked) "Bu kişiyi engellediniz" else "Bu kişiyle arama yapamazsınız") else onCall(false) }, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.Call, "Sesli ara", tint = Color.White) }
                    IconButton(onClick = { if (chatBlocked) toast(ctx, if (otherBlocked) "Bu kişiyi engellediniz" else "Bu kişiyle arama yapamazsınız") else onCall(true) }, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.Videocam, "Görüntülü ara", tint = Color.White) }
                }
                var headMenu by remember { mutableStateOf(false) }
                Box {
                    IconButton(onClick = { headMenu = true }, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.MoreVert, "Menü", tint = Color.White) }
                    DropdownMenu(
                        expanded = headMenu, onDismissRequest = { headMenu = false },
                        shape = RoundedCornerShape(16.dp), containerColor = Color(0xFF0F1419),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A3942))
                    ) {
                        @Composable
                        fun MenuRow(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, label: String, textColor: Color = Color.White, onClick: () -> Unit) {
                            DropdownMenuItem(
                                leadingIcon = { Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp)) },
                                text = { Text(label, color = textColor, fontSize = 17.sp) },
                                onClick = { headMenu = false; onClick() },
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                        MenuRow(Icons.Default.Search, Color.White, "Ara") { searching = true }
                        MenuRow(Icons.Default.Info, Color(0xFF38BDF8), if (target.isGroup) "Grup bilgisi" else "Kişi bilgisi") { onOpenGroupInfo() }
                        MenuRow(
                            if (chatFlags.muted) Icons.Default.Notifications else Icons.Default.NotificationsOff, Color(0xFFFBBF24),
                            if (chatFlags.muted) "Sesi aç" else "Sessize al"
                        ) {
                            Repo.setMuted(me.uid, target.chatId, !chatFlags.muted)
                            toast(ctx, if (!chatFlags.muted) "Sohbet sessize alındı" else "Sohbetin sesi açıldı")
                        }
                        MenuRow(Icons.Default.Palette, Color(0xFFF472B6), "Sohbet teması") { onOpenTheme() }
                        if (!target.isGroup) {
                            MenuRow(
                                Icons.Default.HourglassTop, Color(0xFF7DD3FC),
                                "Süreli mesajlar: " + when (disappearMs) { 0L -> "Kapalı"; 24 * 3600 * 1000L -> "24 saat"; 7 * 24 * 3600 * 1000L -> "7 gün"; else -> "Açık" }
                            ) { showDisappear = true }
                        }
                        MenuRow(Icons.Default.Delete, Color(0xFFFB7185), "Sohbeti temizle") { showWipe = true }
                        if (!target.isGroup) {
                            MenuRow(
                                Icons.Default.Block, Color(0xFFFB7185),
                                if (otherBlocked) "Engeli kaldır" else "Engelle",
                                if (otherBlocked) Color.White else Color(0xFFFB7185)
                            ) {
                                Repo.setBlocked(me.uid, target.otherUid, !otherBlocked)
                                toast(ctx, if (otherBlocked) "Engel kaldırıldı" else "Kişi engellendi")
                            }
                        }
                    }
                }
            }
        }

        // Mesajlar
        Box(Modifier.weight(1f).fillMaxWidth().onGloballyPositioned { listTopRoot = it.positionInRoot().y; listHpx = it.size.height.toFloat(); listWpx = it.size.width.toFloat() }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                        e.changes.firstOrNull { it.pressed }?.let { touchPos = it.position }
                    }
                }
            }) {
            LazyColumn(
                state = listState,
                reverseLayout = true,
                verticalArrangement = Arrangement.Top,
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp)
            ) {
                itemsIndexed(visible, key = { _, m -> m.id }) { i, m ->
                    val older = visible.getOrNull(i + 1)
                    val newDay = older == null || dayKey(effTime(older)) != dayKey(effTime(m))
                    val sameRunAsOlder = older != null && !newDay && older.type != "system" &&
                        older.senderUid == m.senderUid && !(m.id == unreadAnchorId && unreadAnchorCount > 0)
                    Column {
                        if (newDay) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    dayLabel(effTime(m)), color = AuraMuted, fontSize = 12.sp,
                                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(AuraSurface).padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        if (m.id == unreadAnchorId && unreadAnchorCount > 0) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Color(0x3322C55E)), contentAlignment = Alignment.Center) {
                                Text("$unreadAnchorCount okunmamış mesaj", color = AuraGreen, fontSize = 12.sp, modifier = Modifier.padding(4.dp))
                            }
                        }
                        var swipeDx by remember(m.id) { mutableFloatStateOf(0f) }
                        val swipeMax = with(density) { 72.dp.toPx() }
                        val canSwipe = m.type != "system" && !m.deleted && !chatBlocked
                        Box(
                            Modifier.onGloballyPositioned { c -> if (single?.id == m.id) selTopRoot = c.positionInRoot().y }
                                .then(if (canSwipe) Modifier.pointerInput(m.id) {
                                    detectHorizontalDragGestures(
                                        onDragEnd = {
                                            if (swipeDx >= swipeMax * 0.8f && selected.isEmpty()) {
                                                replyTo = m; editing = null
                                                try { haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress) } catch (e: Throwable) {}
                                            }
                                            swipeDx = 0f
                                        },
                                        onDragCancel = { swipeDx = 0f }
                                    ) { _, dx -> if (selected.isEmpty()) swipeDx = (swipeDx + dx).coerceIn(0f, swipeMax) }
                                } else Modifier)
                        ) {
                        if (swipeDx > 8f) {
                            Box(
                                Modifier.align(Alignment.CenterStart).padding(start = 14.dp).size(32.dp).clip(CircleShape)
                                    .background(Color(0x55000000)).graphicsLayer(alpha = (swipeDx / swipeMax).coerceIn(0f, 1f)),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.AutoMirrored.Filled.Reply, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
                        }
                        Box(Modifier.graphicsLayer(translationX = swipeDx)) {
                        MessageBubble(
                            m = m,
                            onForward = { onForward(listOf(m)) },
                            onReactionsClick = { reactionsMsgId = m.id },
                            me = me.uid,
                            isGroup = target.isGroup,
                            onAvatarClick = {
                                memberSheet = Repo.peekProfile(m.senderUid) ?: UserProfile(m.senderUid, m.senderName, "", "", "")
                            },
                            groupAvatar = target.isGroup && m.senderUid != me.uid && !sameRunAsOlder,
                            groupSpace = target.isGroup && m.senderUid != me.uid && sameRunAsOlder,
                            mineColor = theme.out,
                            starred = starredKeys.contains(Repo.starKey(target.chatId, m.id)),
                            selected = selected.contains(m.id) || curMatchId == m.id,
                            flash = highlightId == m.id,
                            flashColor = accent,
                            onClick = {
                                if (selected.isNotEmpty() && m.type != "system") {
                                    selected = if (selected.contains(m.id)) selected - m.id else selected + m.id
                                }
                            },
                            onLongClick = {
                                if (m.type != "system") selected = if (selected.contains(m.id)) selected - m.id else selected + m.id
                            },
                            onQuoteClick = { id ->
                                val idx = visible.indexOfFirst { it.id == id }
                                if (idx >= 0) scope.launch { listState.animateScrollToItem(idx) }
                                else toast(ctx, "Mesaj yüklenmemiş, yukarıdan eski mesajları yükle")
                            },
                            onOpenImages = { list, idx -> viewer = Pair(list, idx) },
                            viewOnceSeen = voTick >= 0 && Repo.isViewOnceSeen(target.chatId, m.id),
                            onOpenViewOnce = { msg -> voViewing = msg },
                            onVote = { msg, optId -> if (selected.isEmpty()) Repo.votePoll(me.uid, target.chatId, msg, optId) },
                            onOpenDocument = { msg ->
                                if (msg.type == "video") { videoMsg = msg } else
                                try {
                                    val f = Media.sharableFile(ctx, msg.imageUrl, msg.fileName.ifBlank { "belge" })
                                    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                                    val i = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, msg.fileMime.ifBlank { "*/*" })
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    ctx.startActivity(i)
                                } catch (e: Throwable) {
                                    toast(ctx, "Bu belgeyi açacak uygulama yok")
                                }
                            },
                            onOpenLocation = { msg ->
                                try {
                                    val u = Uri.parse("geo:${msg.lat},${msg.lng}?q=${msg.lat},${msg.lng}")
                                    ctx.startActivity(Intent(Intent.ACTION_VIEW, u))
                                } catch (e: Throwable) {
                                    toast(ctx, "Harita uygulaması bulunamadı")
                                }
                            }
                        )
                        }
                        }
                    }
                }
            }
            if (single != null && !single.deleted && single.type != "system") {
                val barH = with(density) { 54.dp.toPx() }
                val y = (touchPos.y - barH - with(density) { 36.dp.toPx() })
                    .coerceIn(with(density) { 4.dp.toPx() }, (listHpx - barH).coerceAtLeast(0f))
                val edge = with(density) { 8.dp.toPx() }
                val x = (touchPos.x - reactBarW / 2f).coerceIn(edge, (listWpx - reactBarW - edge).coerceAtLeast(edge))
                Row(
                    Modifier
                        .align(Alignment.TopStart)
                        .onGloballyPositioned { reactBarW = it.size.width.toFloat() }
                        .offset { androidx.compose.ui.unit.IntOffset(x.toInt(), y.toInt()) }
                        .clip(RoundedCornerShape(28.dp)).background(auraC(0xFF233138)).padding(horizontal = 10.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    REACTIONS.forEach { e ->
                        Text(
                            e, fontSize = 26.sp,
                            modifier = Modifier.clip(CircleShape).clickable {
                                Repo.react(me.uid, target.chatId, single.id, e, single.reactions[me.uid])
                                if (single.reactions[me.uid] != e) launchSafe { Repo.reactNotify(me, target, single, e) }
                                clearSelection()
                            }.padding(5.dp)
                        )
                    }
                }
            }
            run {
                var showChip by remember { mutableStateOf(false) }
                LaunchedEffect(listState.isScrollInProgress) {
                    if (listState.isScrollInProgress) showChip = true
                    else { kotlinx.coroutines.delay(1200); showChip = false }
                }
                val topIdx = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
                val topMsg = visible.getOrNull(topIdx)
                androidx.compose.animation.AnimatedVisibility(
                    visible = showChip && topMsg != null,
                    enter = androidx.compose.animation.fadeIn(),
                    exit = androidx.compose.animation.fadeOut(),
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp)
                ) {
                    Text(
                        dayLabel(topMsg?.let { effTime(it) } ?: 0L),
                        color = Color.White, fontSize = 12.sp,
                        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xCC1F2C34)).padding(horizontal = 12.dp, vertical = 5.dp)
                    )
                }
            }
            if (!atBottom) {
                Box(Modifier.align(Alignment.BottomEnd).padding(12.dp)) {
                    IconButton(
                        onClick = { scope.launch { listState.animateScrollToItem(0) } },
                        modifier = Modifier.size(32.dp).clip(CircleShape).background(AuraSurface)
                    ) { Icon(Icons.Default.KeyboardDoubleArrowDown, "Aşağı", tint = Color.White, modifier = Modifier.size(20.dp)) }
                    if (newBelow > 0) {
                        Box(
                            Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-8).dp).heightIn(min = 20.dp).widthIn(min = 20.dp)
                                .clip(CircleShape).background(accent).padding(horizontal = 5.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(if (newBelow > 99) "99+" else newBelow.toString(), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }

        // Yanıt / düzenleme çubuğu
        val rep = if (searching || chatBlocked) null else replyTo
        if (rep != null) {
            Row(
                Modifier.fillMaxWidth().background(AuraSurface).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.width(3.dp).height(34.dp).background(AuraGreen))
                Column(Modifier.weight(1f).padding(start = 8.dp)) {
                    Text(rep.senderName.ifBlank { "Kullanıcı" }, color = AuraGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(Repo.previewOf(rep), color = AuraMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { replyTo = null }) { Icon(Icons.Default.Close, "Kapat", tint = AuraMuted) }
            }
        }
        if (editing != null) {
            Row(
                Modifier.fillMaxWidth().background(AuraSurface).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Edit, null, tint = AuraGreen, modifier = Modifier.size(18.dp))
                Text("Mesajı düzenle", color = AuraGreen, fontSize = 13.sp, modifier = Modifier.weight(1f).padding(start = 8.dp))
                IconButton(onClick = { editing = null; text = "" }) { Icon(Icons.Default.Close, "Kapat", tint = AuraMuted) }
            }
        }

        if (busy) {
            Text("İşleniyor…", color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
        }

        // Giriş çubuğu (eski sürüm: siyah, yeşil çerçeveli kutu; + ve mikrofon/gönder içinde)
        if (chatBlocked && !searching) {
            Row(
                Modifier.fillMaxWidth().background(auraC(0xFF202C33)).padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
            ) {
                if (otherBlocked) {
                    Text("Bu kişiyi engellediniz. ", color = Color(0xFF9CA3AF), fontSize = 13.sp)
                    Text("Engeli kaldır", color = Color(0xFF34D399), fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { Repo.setBlocked(me.uid, target.otherUid, false); toast(ctx, "Engel kaldırıldı") })
                } else Text("Bu kişiyle mesajlaşamazsınız.", color = Color(0xFF9CA3AF), fontSize = 13.sp)
            }
        } else if (searching) {
        } else if (recording) {
            Row(
                Modifier.fillMaxWidth().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { finishRecording(false) }) { Icon(Icons.Default.Delete, "İptal", tint = Color(0xFFEF4444)) }
                Box(Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFEF4444)))
                Text(
                    "  %d:%02d".format(recSec / 60, recSec % 60),
                    color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { finishRecording(true) },
                    modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(accent)
                ) { Icon(Icons.AutoMirrored.Filled.Send, "Gönder", tint = Color.White) }
            }
        } else {
            val canSend = text.isNotBlank() || pendingImages.isNotEmpty()
            if (mentionList.isNotEmpty()) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp).heightIn(max = 220.dp)
                        .clip(RoundedCornerShape(12.dp)).background(auraC(0xFF1F2C34))
                        .border(1.dp, Color(0x1FFFFFFF), RoundedCornerShape(12.dp))
                        .verticalScroll(androidx.compose.foundation.rememberScrollState())
                ) {
                    mentionList.forEach { (uid, name) ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                val mm = mentionMatch
                                if (mm != null) {
                                    val start = mm.range.first + mm.groupValues[1].length
                                    text = text.substring(0, start) + "@" + name + " "
                                    chosenMentions[name] = uid
                                }
                            }.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (uid == "*") {
                                Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF128C7E)), contentAlignment = Alignment.Center) {
                                    Text("@", color = Color.White, fontSize = 14.sp)
                                }
                            } else Avatar(name, "", 34.dp)
                            Column(Modifier.padding(start = 10.dp)) {
                                Text(name, color = Color(0xFFE9EDEF), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (uid == "*") Text("Tüm grup üyelerini etiketle", color = Color(0xFF8696A0), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
            val boxShape = RoundedCornerShape(18.dp)
            val plusBtn: @Composable () -> Unit = {
                IconButton(onClick = {
                    if (showAttach) {
                        attachInstant = false
                        showAttach = false
                        attachClosing = false
                    } else {
                        attachInstant = false
                        attachClosing = false
                        showAttach = true
                        focusManager.clearFocus()
                        keyboard?.hide()
                    }
                }) {
                    Icon(Icons.Default.Add, "Ekle", tint = Color.White, modifier = Modifier.size(30.dp))
                }
            }
            val sendBtn: @Composable () -> Unit = {
                IconButton(
                    onClick = {
                        if (canSend) send() else {
                            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                startRecording()
                            } else {
                                micPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    modifier = Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(accent)
                ) {
                    Icon(
                        if (canSend) Icons.AutoMirrored.Filled.Send else Icons.Default.Mic,
                        if (canSend) "Gönder" else "Ses kaydı",
                        tint = Color.White
                    )
                }
            }
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp)
                    .clip(boxShape)
                    .background(Color.Black)
                    .border(1.dp, inputBorder, boxShape)
            ) {
                if (pendingImages.isNotEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                            .padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        pendingImages.forEachIndexed { idx, img ->
                            Box(Modifier.size(width = 71.dp, height = 71.dp).padding(top = 6.dp, end = 6.dp)) {
                                DataUrlImage(
                                    img, 220,
                                    Modifier.size(65.dp).clip(RoundedCornerShape(12.dp)).clickable {
                                        focusManager.clearFocus(); keyboard?.hide(); editIdx = idx
                                    },
                                    androidx.compose.ui.layout.ContentScale.Crop
                                )
                                Box(
                                    Modifier.align(Alignment.TopEnd).offset(x = 0.dp, y = (-0).dp).size(20.dp).clip(CircleShape).background(accent)
                                        .clickable {
                                            pendingImages = pendingImages.filterIndexed { j, _ -> j != idx }
                                            if (pendingImages.size != 1) viewOnceOn = false
                                        },
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.Close, "Kaldır", tint = Color.White, modifier = Modifier.size(14.dp)) }
                            }
                        }
                        if (pendingImages.size == 1) {
                            Box(
                                Modifier.size(34.dp).clip(CircleShape)
                                    .background(if (viewOnceOn) accent else Color.Transparent)
                                    .border(2.dp, if (viewOnceOn) accent else AuraMuted, CircleShape)
                                    .clickable { viewOnceOn = !viewOnceOn },
                                contentAlignment = Alignment.Center
                            ) { Text("1", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
                val multi = multiLine && text.isNotEmpty()
                Box(Modifier.fillMaxWidth().heightIn(min = 54.dp)) {
                    Box(
                        Modifier.fillMaxWidth().padding(
                            start = 16.dp,
                            end = if (multi) 46.dp else 104.dp,
                            top = if (multi) 12.dp else 4.dp,
                            bottom = if (multi) 56.dp else 4.dp
                        ).align(Alignment.CenterStart)
                    ) {
                        if (text.isEmpty()) {
                            Text(
                                if (pendingImages.isNotEmpty()) (if (viewOnceOn) "Bir kez görüntülenecek" else "Başlık ekle…") else "Bir mesaj yazın...",
                                color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                        BasicTextField(
                            value = text,
                            onValueChange = {
                                text = it
                                if (it.isEmpty()) multiLine = false
                            },
                            textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                            cursorBrush = SolidColor(inputBorder),
                            maxLines = 6,
                            onTextLayout = { if (it.lineCount > 1) multiLine = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .onFocusChanged { if (it.isFocused && showAttach) attachClosing = true }
                        )
                    }
                    if (multi) {
                        Box(
                            Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 12.dp).size(22.dp).clip(CircleShape)
                                .background(accent).clickable { text = ""; multiLine = false },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Close, "Temizle", tint = Color.White, modifier = Modifier.size(15.dp)) }
                    }
                    Row(
                        Modifier.align(if (multi) Alignment.BottomEnd else Alignment.CenterEnd).padding(end = 4.dp, bottom = if (multi) 4.dp else 0.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        plusBtn()
                        sendBtn()
                    }
                }
            }
        }

        if (panelPx > 0 && !recording && !searching && !chatBlocked) {
            val sheetDrag = androidx.compose.foundation.gestures.rememberDraggableState { delta ->
                val maxPx = (listHpx + panelAnim.value).coerceAtLeast(panelFullPx.toFloat())
                scope.launch { panelAnim.snapTo((panelAnim.value - delta).coerceIn(0f, maxPx)) }
            }
            Box(
                Modifier.fillMaxWidth().height(with(density) { panelPx.toDp() }).clipToBounds()
                    .draggable(
                        state = sheetDrag, orientation = androidx.compose.foundation.gestures.Orientation.Vertical,
                        onDragStarted = { panelDragging = true },
                        onDragStopped = { vel ->
                            val half = panelFullPx.toFloat()
                            val maxPx = (listHpx + panelAnim.value).coerceAtLeast(half)
                            val proj = panelAnim.value - vel * 0.12f
                            val target = listOf(0f, half, maxPx).minByOrNull { kotlin.math.abs(it - proj) } ?: half
                            scope.launch {
                                if (target <= 0f) {
                                    panelDragging = false
                                    attachInstant = false
                                    showAttach = false
                                } else {
                                    panelExpanded = target > half
                                    panelAnim.animateTo(target, androidx.compose.animation.core.tween(240, easing = androidx.compose.animation.core.FastOutSlowInEasing))
                                    panelDragging = false
                                }
                            }
                        }
                    )
            ) {
            AttachSheet(
                height = with(density) { maxOf(panelFullPx, panelPx).toDp() },
                expanded = panelExpanded,
                onGallery = {
                    showAttach = false
                    galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onCamera = {
                    showAttach = false
                    try {
                        val dir = File(ctx.cacheDir, "camera").also { it.mkdirs() }
                        val f = File(dir, "photo_${System.currentTimeMillis()}.jpg")
                        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                        cameraUri = u
                        cameraLauncher.launch(u)
                    } catch (e: Throwable) {
                        toast(ctx, "Kamera açılamadı")
                    }
                },
                onLocation = {
                    showAttach = false
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        sendLocationNow()
                    } else {
                        locPermLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                    }
                },
                onDocument = {
                    showAttach = false
                    docLauncher.launch(arrayOf("*/*"))
                },
                onPoll = { showAttach = false; showPoll = true },
                onVideo = { showAttach = false; showVideoChoice = true },
                onShare = { showAttach = false; toast(ctx, "Ekran paylaşımı bu sürümde yok") },
                accent = accent,
                maxPick = (5 - pendingImages.size).coerceAtLeast(1),
                onPickGallery = { uris -> showAttach = false; addImages(uris) },
                onClose = { attachInstant = false; showAttach = false }
            )
            }
        }
    }

    if (showPoll) {
        PollCreator(
            onSend = { q, opts, multi ->
                showPoll = false
                val r = replyRefOf()
                replyTo = null
                launchSafe { Repo.sendPoll(me, target, q, opts, multi, r) }
            },
            onClose = { showPoll = false }
        )
    }
    if (editIdx in pendingImages.indices) {
        ImageEditor(
            dataUrl = pendingImages[editIdx],
            targetBytes = if (pendingImages.size > 1) 150 * 1024 else 300 * 1024,
            onDone = { nu ->
                val i = editIdx
                pendingImages = pendingImages.toMutableList().also { if (i in it.indices) it[i] = nu }
                editIdx = -1
            },
            onCancel = { editIdx = -1 }
        )
    }

    if (showDisappear) {
        AlertDialog(
            onDismissRequest = { showDisappear = false },
            containerColor = AuraSurface,
            title = { Text("Süreli mesajlar (yeni mesajlar için)", color = Color.White, fontSize = 17.sp) },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    listOf("Kapalı" to 0L, "24 saat" to 24 * 3600 * 1000L, "7 gün" to 7 * 24 * 3600 * 1000L).forEach { (label, ms) ->
                        TextButton(onClick = {
                            showDisappear = false
                            Repo.setDisappearAfter(target.chatId, me.name, me.uid, ms)
                            toast(ctx, if (ms > 0) "Süreli mesajlar açıldı" else "Süreli mesajlar kapatıldı")
                        }) { Text(label, color = AuraGreen) }
                    }
                    TextButton(onClick = { showDisappear = false }) { Text("İptal", color = AuraMuted) }
                }
            }
        )
    }
    videoMsg?.let { vm -> VideoPlayerDialog(vm) { videoMsg = null } }
    if (showVideoChoice) {
        AlertDialog(
            onDismissRequest = { showVideoChoice = false },
            containerColor = AuraSurface,
            title = { Text("Video gönder", color = Color.White, fontSize = 17.sp) },
            text = { Text("Mesajlaşma sınırı yüzünden video en fazla 640 KB (yaklaşık 5 saniye) olabilir.", color = AuraMuted, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = {
                    showVideoChoice = false
                    try {
                        val dir = File(ctx.cacheDir, "camera").also { it.mkdirs() }
                        val f = File(dir, "video_${System.currentTimeMillis()}.mp4")
                        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                        videoCaptureUri = u
                        videoCaptureLauncher.launch(
                            Intent(android.provider.MediaStore.ACTION_VIDEO_CAPTURE)
                                .putExtra(android.provider.MediaStore.EXTRA_OUTPUT, u)
                                .putExtra(android.provider.MediaStore.EXTRA_SIZE_LIMIT, (Media.VIDEO_MAX_BYTES - 20 * 1024).toLong())
                                .putExtra(android.provider.MediaStore.EXTRA_VIDEO_QUALITY, 0)
                                .putExtra(android.provider.MediaStore.EXTRA_DURATION_LIMIT, 8)
                                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        )
                    } catch (e: Throwable) { toast(ctx, "Kamera açılamadı") }
                }) { Text("Video çek", color = AuraGreen) }
            },
            dismissButton = {
                TextButton(onClick = {
                    showVideoChoice = false
                    videoPickLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                }) { Text("Galeriden seç", color = AuraGreen) }
            }
        )
    }
    reactionsMsgId?.let { rid ->
        val rm = visible.firstOrNull { it.id == rid }
        if (rm == null || rm.reactions.isEmpty()) { reactionsMsgId = null } else {
            var tab by remember(rid) { mutableStateOf("") }
            val counts = rm.reactions.values.groupingBy { it }.eachCount()
            val list = rm.reactions.entries.filter { tab.isEmpty() || it.value == tab }
                .sortedByDescending { it.key == me.uid }
            androidx.compose.material3.ModalBottomSheet(
                onDismissRequest = { reactionsMsgId = null },
                containerColor = auraC(0xFF202C33)
            ) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 12.dp)) {
                    Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (listOf("" to rm.reactions.size) + counts.entries.map { it.key to it.value }).forEach { (e, n) ->
                            val on = tab == e
                            Text(
                                (if (e.isEmpty()) "Tümü " else "$e ") + n,
                                color = if (on) Color.White else Color(0xFFD1D5DB), fontSize = 14.sp,
                                modifier = Modifier.clip(RoundedCornerShape(50)).background(if (on) AuraBtn else auraC(0xFF111B21))
                                    .clickable { tab = e }.padding(horizontal = 14.dp, vertical = 7.dp)
                            )
                        }
                    }
                    list.forEach { (uid, emoji) ->
                        val lp by liveProfile(uid)
                        val mineR = uid == me.uid
                        val nm = if (mineR) "Sen" else (lp?.name?.takeIf { it.isNotBlank() } ?: rm.senderName.takeIf { rm.senderUid == uid && it.isNotBlank() } ?: "Kullanıcı")
                        Row(
                            Modifier.fillMaxWidth()
                                .then(if (mineR) Modifier.clickable {
                                    Repo.react(me.uid, target.chatId, rm.id, emoji, emoji)
                                    reactionsMsgId = null
                                } else Modifier)
                                .padding(horizontal = 20.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(nm.ifBlank { "?" }, if (mineR) me.avatar else (lp?.avatar ?: ""), 44.dp)
                            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                                Text(nm, color = Color.White, fontSize = 16.sp)
                                if (mineR) Text("Kaldırmak için dokun", color = AuraMuted, fontSize = 12.sp)
                            }
                            Text(emoji, fontSize = 24.sp)
                        }
                    }
                }
            }
        }
    }
    memberSheet?.let { mu ->
        val lp by liveProfile(mu.uid)
        val u = lp ?: mu
        androidx.compose.material3.ModalBottomSheet(
            onDismissRequest = { memberSheet = null },
            containerColor = auraC(0xFF202C33)
        ) {
            Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Avatar(u.name.ifBlank { "?" }, u.avatar, 96.dp)
                Text(u.name.ifBlank { "Kullanıcı" }, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 12.dp))
                Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(
                        Triple(Icons.Default.Chat, "Mesaj", 0),
                        Triple(Icons.Default.Call, "Sesli", 1),
                        Triple(Icons.Default.Videocam, "Görüntülü", 2)
                    ).forEach { (ic, label, act) ->
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(auraC(0xFF111B21))
                                .clickable {
                                    memberSheet = null
                                    when (act) { 0 -> onMemberChat(u); 1 -> onMemberCall(u, false); else -> onMemberCall(u, true) }
                                }.padding(vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(ic, label, tint = AuraGreen, modifier = Modifier.size(24.dp))
                            Text(label, color = Color(0xFFE5E7EB), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }
        }
    }
    if (showWipe) {
        AlertDialog(
            onDismissRequest = { showWipe = false },
            containerColor = AuraSurface,
            title = { Text("Bu sohbeti kalıcı olarak silmek üzeresiniz", color = Color.White, fontSize = 17.sp) },
            confirmButton = {
                TextButton(onClick = {
                    showWipe = false
                    Repo.wipeChat(me.uid, target.chatId)
                    toast(ctx, "Sohbet temizlendi")
                }) { Text("Sil", color = Color(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { showWipe = false }) { Text("İptal", color = AuraMuted) } }
        )
    }

    voViewing?.let { vm ->
        ViewOnceViewer(vm.imageUrl) {
            Repo.consumeViewOnce(target.chatId, vm.id, target.isGroup)
            voViewing = null
            voTick++
        }
    }

    // Silme penceresi
    if (showDelete) {
        val allMine = selectedMsgs.isNotEmpty() && selectedMsgs.all { it.senderUid == me.uid && !it.deleted && !it.pending }
        AlertDialog(
            onDismissRequest = { showDelete = false },
            containerColor = AuraSurface,
            title = { Text("Mesaj silinsin mi?", color = Color.White) },
            text = { Text("${selectedMsgs.size} mesaj", color = AuraMuted) },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    if (allMine) {
                        TextButton(onClick = {
                            selectedMsgs.forEach { Repo.deleteForEveryone(target.chatId, it.id, me.uid) }
                            showDelete = false
                            clearSelection()
                        }) { Text("Herkesten sil", color = Color(0xFFEF4444)) }
                    }
                    TextButton(onClick = {
                        selectedMsgs.forEach { Repo.deleteForMe(me.uid, target.chatId, it.id) }
                        showDelete = false
                        clearSelection()
                    }) { Text("Benden sil", color = Color(0xFFEF4444)) }
                    TextButton(onClick = { showDelete = false }) { Text("Vazgeç", color = AuraGreen) }
                }
            }
        )
    }

    val v = viewer
    if (v != null) ImageViewer(v.first, v.second) { viewer = null }
}

private fun lastSeenText(ms: Long): String {
    val time = SimpleDateFormat("HH:mm", Locale("tr")).format(Date(ms))
    val startToday = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    return when {
        ms >= startToday -> "son görülme bugün $time"
        ms >= startToday - 86_400_000L -> "son görülme dün $time"
        else -> "son görülme " + SimpleDateFormat("d MMMM", Locale("tr")).format(Date(ms))
    }
}

@Composable
private fun AttachSheet(
    height: androidx.compose.ui.unit.Dp,
    expanded: Boolean = false,
    onGallery: () -> Unit,
    onCamera: () -> Unit,
    onLocation: () -> Unit,
    onDocument: () -> Unit,
    onPoll: () -> Unit,
    onVideo: () -> Unit = {},
    onShare: () -> Unit,
    accent: Color,
    maxPick: Int,
    onPickGallery: (List<Uri>) -> Unit,
    onClose: () -> Unit = {}
) {
    val items = listOf(
        Triple("Galeri", Icons.Default.Image, Color(0xFF3B82F6)) to onGallery,
        Triple("Kamera", Icons.Default.PhotoCamera, Color(0xFFF43F5E)) to onCamera,
        Triple("Konum", Icons.Default.LocationOn, Color(0xFF10B981)) to onLocation,
        Triple("Video", Icons.Default.Videocam, Color(0xFFEC4899)) to onVideo,
        Triple("Belge", Icons.Default.Description, Color(0xFF8B5CF6)) to onDocument,
        Triple("Anket", Icons.Default.BarChart, Color(0xFFF59E0B)) to onPoll
    )
    Column(
        Modifier.fillMaxWidth().requiredHeight(height).clipToBounds()
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)).background(Color(0xFF14191C))
    ) {
        Box(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.width(44.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF8A9096)))
        }
        items.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
                for (k in 0 until 4) {
                    val it = row.getOrNull(k)
                    Column(
                        Modifier.weight(1f).then(if (it != null) Modifier.clickable { it.second() } else Modifier),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (it != null) {
                            val info = it.first
                            Box(
                                Modifier.width(64.dp).height(34.dp).clip(RoundedCornerShape(17.dp))
                                    .border(1.dp, Color(0xFF2A3239), RoundedCornerShape(17.dp)),
                                contentAlignment = Alignment.Center
                            ) { Icon(info.second, info.first, tint = info.third, modifier = Modifier.size(22.dp)) }
                            Text(info.first, color = Color(0xFF9AA3A9), fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
        }
        GalleryStrip(accent, maxPick, onPickGallery, Modifier.weight(1f).padding(top = 10.dp), grid = expanded)
    }
}

package com.aurachat.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.DonutLarge
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

private val Water: Color get() = AuraGreen

/** Sohbetler / Durum / Kişiler / Aramalar: parmakla kaydırılan sayfalar + su damlası alt çubuk */
@Composable
fun MainTabs(
    page: Int,
    onPageChanged: (Int) -> Unit,
    badges: List<Int> = listOf(0, 0, 0, 0),
    chats: @Composable () -> Unit,
    status: @Composable (onFullscreen: (Boolean) -> Unit) -> Unit,
    contacts: @Composable () -> Unit,
    calls: @Composable () -> Unit
) {
    val pager = rememberPagerState(initialPage = page.coerceIn(0, 3)) { 4 }
    val scope = rememberCoroutineScope()
    var fullscreen by remember { mutableStateOf(false) }

    LaunchedEffect(pager.currentPage) { onPageChanged(pager.currentPage) }
    BackHandler(enabled = pager.currentPage != 0 && !fullscreen) {
        scope.launch { pager.animateScrollToPage(0) }
    }

    Column(Modifier.fillMaxSize().background(AuraBg)) {
        HorizontalPager(
            state = pager,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            userScrollEnabled = !fullscreen,
            beyondViewportPageCount = 3
        ) { p ->
            when (p) {
                0 -> chats()
                1 -> status { fullscreen = it }
                2 -> contacts()
                else -> calls()
            }
        }
        if (!fullscreen) {
            LiquidNav(pager, badges) { i -> scope.launch { pager.animateScrollToPage(i) } }
        }
    }
}

private data class NavDef(val icon: androidx.compose.ui.graphics.vector.ImageVector, val label: String)

private val navDefs = listOf(
    NavDef(Icons.Default.ChatBubble, "Sohbetler"),
    NavDef(Icons.Default.DonutLarge, "Durum"),
    NavDef(Icons.Default.People, "Kişiler"),
    NavDef(Icons.Default.Call, "Aramalar")
)

@Composable
private fun LiquidNav(pager: PagerState, badges: List<Int>, onTab: (Int) -> Unit) {
    val pos = (pager.currentPage + pager.currentPageOffsetFraction).coerceIn(0f, 3f)
    Box(Modifier.fillMaxWidth().background(AuraBlack).navigationBarsPadding().padding(bottom = 13.5.dp).height(66.dp)) {
        // su damlası: iki uç farklı hızda kayar, aradaki köprü incelir (metaball gibi)
        Canvas(Modifier.fillMaxSize()) {
            val cw = size.width / 4f
            val cy = 31.dp.toPx()
            val r = 17.dp.toPx()
            val half = 13.dp.toPx()
            val i = floor(pos).toInt().coerceIn(0, 2)
            val p = (pos - i).coerceIn(0f, 1f)
            val xi = (i + 0.5f) * cw
            val xj = (i + 1.5f) * cw
            val eIn = p * p
            val eOut = 1f - (1f - p) * (1f - p)
            val a = xi + (xj - xi) * eIn
            val b = xi + (xj - xi) * eOut
            val left = min(a, b) - half
            val right = max(a, b) + half
            val stretch = (right - left) - 2f * half
            val neck = r * (1f - 0.6f * min(1f, stretch / (cw * 0.6f)))
            val mid = (left + right) / 2f
            val path = Path().apply {
                moveTo(left, cy - r)
                quadraticTo(mid, cy - neck, right, cy - r)
                arcTo(Rect(right - r, cy - r, right + r, cy + r), -90f, 180f, false)
                quadraticTo(mid, cy + neck, left, cy + r)
                arcTo(Rect(left - r, cy - r, left + r, cy + r), 90f, 180f, false)
                close()
            }
            val accD = AuraUi.accentColor()
            drawPath(path, if (accD != null) accD.copy(alpha = if (AuraUi.light) 0.16f else 0.24f) else if (AuraUi.light) Color(0xFFD9FDD3) else Color(0xFF103629))
        }
        Row(Modifier.fillMaxSize()) {
            navDefs.forEachIndexed { idx, d ->
                val t = 1f - min(1f, abs(pos - idx))
                val accT = AuraUi.accentColor()
                val selT = if (accT == null) AuraWhite else if (AuraUi.light) lerp(accT, Color.Black, 0.25f) else lerp(accT, Color.White, 0.45f)
                val tint = lerp(AuraMuted, selT, t)
                Column(
                    Modifier.weight(1f).fillMaxHeight().clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { onTab(idx) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(19.dp))
                    Box {
                        Icon(d.icon, d.label, tint = tint, modifier = Modifier.size(24.dp))
                        val bc = badges.getOrElse(idx) { 0 }
                        if (bc != 0) {
                            // WhatsApp gibi: simgenin sağ üstünde yeşil rozet (sayı) ya da küçük yeşil nokta (yeni durum)
                            Box(
                                Modifier.align(Alignment.TopStart).offset(x = if (bc < 0) 17.dp else 13.dp, y = if (bc < 0) (-4).dp else (-7).dp)
                                    .then(if (bc < 0) Modifier.size(10.dp) else Modifier.height(17.dp).widthIn(min = 17.dp))
                                    .clip(CircleShape).background((AuraUi.accentColor() ?: if (AuraUi.light) Color(0xFF1B6B49) else Color(0xFF25D366))),
                                contentAlignment = Alignment.Center
                            ) {
                                if (bc > 0) Text(
                                    if (bc > 99) "99+" else bc.toString(), color = if (AuraUi.light || AuraUi.accentColor() != null) Color(0xFFFFFFFF) else Color(0xFF04210F), fontSize = 11.sp, lineHeight = 11.sp,
                                    fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false,
                                    style = androidx.compose.ui.text.TextStyle(
                                        platformStyle = androidx.compose.ui.text.PlatformTextStyle(includeFontPadding = false),
                                        lineHeightStyle = androidx.compose.ui.text.style.LineHeightStyle(
                                            androidx.compose.ui.text.style.LineHeightStyle.Alignment.Center,
                                            androidx.compose.ui.text.style.LineHeightStyle.Trim.Both
                                        )
                                    ),
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                            }
                        }
                    }
                    Text(d.label, color = tint, fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
                }
            }
        }
    }
}

package com.aurachat.app.ui

import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.DonutLarge
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

private val Water: Color get() = AuraGreen

/** Sekme sayfasının üst başlığı: sayfa kayarken yerinde sabit kalır, sayfa yerine oturunca yenisiyle değişir */
internal val LocalPagePin = androidx.compose.runtime.compositionLocalOf<Modifier> { Modifier }

@Composable
internal fun Modifier.pagePin(): Modifier = this.then(LocalPagePin.current)

/** Sekmelerde düz başlıklar (Güncellemeler / Kişiler / Aramalar) MainTabs'ta sabit çizilir; sayfadaki kopya yalnız yer tutar */
internal val LocalTitleHoisted = androidx.compose.runtime.compositionLocalOf { false }

/** Sekmede başlık MainTabs'ta çizildiği için sayfada 60 dp'lik boş yer bırakır; tek başına açılınca kendi başlığını çizer */
@Composable
internal fun TitleSlot(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    if (LocalTitleHoisted.current) androidx.compose.foundation.layout.Spacer(modifier.height(60.dp)) else content()
}

@Composable
internal fun Modifier.hoistedTitle(): Modifier = if (LocalTitleHoisted.current) this.then(Modifier.graphicsLayer { alpha = 0f }) else this

/** Sohbetler / Durum / Kişiler / Aramalar: parmakla kaydırılan sayfalar + su damlası alt çubuk */
@Composable
fun MainTabs(
    page: Int,
    onPageChanged: (Int) -> Unit,
    badges: List<Int> = listOf(0, 0, 0, 0),
    chats: @Composable () -> Unit,
    status: @Composable (onFullscreen: (Boolean) -> Unit) -> Unit,
    contacts: @Composable () -> Unit,
    calls: @Composable () -> Unit
) {
    val pager = rememberPagerState(initialPage = page.coerceIn(0, 3)) { 4 }
    val scope = rememberCoroutineScope()
    var fullscreen by remember { mutableStateOf(false) }

    LaunchedEffect(pager.currentPage) { onPageChanged(pager.currentPage) }
    // üst başlık: parmak sürüklerken bile sayfanın yarısı geçilince (en yakın sayfa değişince) yenisine geçer
    val shown by remember { androidx.compose.runtime.derivedStateOf { Math.round(pager.currentPage + pager.currentPageOffsetFraction).coerceIn(0, 3) } }
    LaunchedEffect(page) { if (pager.currentPage != page.coerceIn(0, 3)) pager.scrollToPage(page.coerceIn(0, 3)) }
    BackHandler(enabled = pager.currentPage != 0 && !fullscreen) {
        scope.launch { pager.animateScrollToPage(0) }
    }

    Column(Modifier.fillMaxSize().background(AuraBg)) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
        androidx.compose.runtime.CompositionLocalProvider(LocalTitleHoisted provides true) {
        HorizontalPager(
            state = pager,
            modifier = Modifier.fillMaxSize().pointerInput(Unit) {
                // ilk sekmede (Sohbetler) parmağı sağa kaydırınca uygulama teması paneli açılır; sayfa kaydırmasını engellemez
                val w = size.width.toFloat().coerceAtLeast(1f)
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    val allow = pager.currentPage == 0 && pager.currentPageOffsetFraction == 0f
                    var started = false
                    val vt = androidx.compose.ui.input.pointer.util.VelocityTracker()
                    vt.addPosition(down.uptimeMillis, down.position)
                    do {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        val ch = ev.changes.firstOrNull() ?: break
                        vt.addPosition(ch.uptimeMillis, ch.position)
                        val dx = ch.position.x - down.position.x; val dy = ch.position.y - down.position.y
                        if (allow && !started && dx > 24f && dx > 2f * kotlin.math.abs(dy)) {
                            started = true
                            AuraPanelHost.dragStarted = true; AuraPanelHost.dragFrac = 0f; AuraPanelHost.dragging = true; AuraPanelHost.openRequest = true
                        }
                        if (started) AuraPanelHost.dragFrac = ((dx - 24f) / w).coerceIn(0f, 1f)
                    } while (ev.changes.any { it.pressed })
                    if (started) {
                        val vx = vt.calculateVelocity().x
                        AuraPanelHost.flick = if (vx > 700f) 1 else if (vx < -700f) -1 else 0
                        AuraPanelHost.dragging = false
                    }
                }
            },
            userScrollEnabled = !fullscreen && !ChipDrag.active,
            beyondViewportPageCount = 3
        ) { p ->
            // kumanda: yalnız görünen sayfadaki öğeler odak alır; yoksa yön tuşu ekran dışındaki sayfalara atlayıp sayfayı sürekli kaydırır
            val pin = Modifier.graphicsLayer {
                val w = (pager.layoutInfo.pageSize + pager.layoutInfo.pageSpacing).toFloat()
                translationX = ((pager.currentPage + pager.currentPageOffsetFraction) - p) * w
                alpha = if (shown == p) 1f else 0f
            }
            androidx.compose.runtime.CompositionLocalProvider(LocalPagePin provides pin) {
            Box(Modifier.fillMaxSize().zIndex(if (shown == p) 1f else 0f).focusProperties { canFocus = (p == pager.currentPage) }) {
                when (p) {
                    0 -> chats()
                    1 -> status { fullscreen = it }
                    2 -> contacts()
                    else -> calls()
                }
            }
            }
        }
        }
        val dens = androidx.compose.ui.platform.LocalDensity.current
        val title = when (shown) { 1 -> "Güncellemeler"; 2 -> "Kişiler"; 3 -> "Aramalar"; else -> null }
        if (title != null && !fullscreen) {
            // WhatsApp'tan ölçüldü (1080px): düz (kalın değil) başlık, 'Güncellemeler' 430px genişlik ≈ 68px punto, sol boşluk 45px
            Box(Modifier.fillMaxWidth().statusBarsPadding().height(60.dp).padding(start = (45f / dens.density).dp - 4.dp), contentAlignment = Alignment.CenterStart) {
                Text(
                    title, color = AuraWhite,
                    style = androidx.compose.ui.text.TextStyle(
                        fontSize = with(dens) { 68f.toSp() }, fontWeight = androidx.compose.ui.text.font.FontWeight.Normal,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif
                    ),
                    maxLines = 1, modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }
        }
        if (!fullscreen) {
            LiquidNav(pager, badges) { i -> scope.launch { pager.scrollToPage(i) } }
        }
    }
}

private data class NavDef(val icon: androidx.compose.ui.graphics.vector.ImageVector, val label: String)

private val navDefs = listOf(
    NavDef(Icons.Default.ChatBubble, "Sohbetler"),
    NavDef(Icons.Default.DonutLarge, "Durum"),
    NavDef(Icons.Default.People, "Kişiler"),
    NavDef(Icons.Default.Call, "Aramalar")
)

@OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)
@Composable
private fun LiquidNav(pager: PagerState, badges: List<Int>, onTab: (Int) -> Unit) {
    val pos = (pager.currentPage + pager.currentPageOffsetFraction).coerceIn(0f, 3f)
    val dropColor = ChipLook.bg
    Box(Modifier.fillMaxWidth().background(AuraBlack).navigationBarsPadding().padding(bottom = 13.5.dp).height(66.dp)) {
        // su damlası: iki uç farklı hızda kayar, aradaki köprü incelir (metaball gibi)
        Canvas(Modifier.fillMaxSize()) {
            val cw = size.width / 4f
            val cy = 31.dp.toPx()
            val r = 17.dp.toPx()
            val half = 13.dp.toPx()
            val i = floor(pos).toInt().coerceIn(0, 2)
            val p = (pos - i).coerceIn(0f, 1f)
            val xi = (i + 0.5f) * cw
            val xj = (i + 1.5f) * cw
            val eIn = p * p
            val eOut = 1f - (1f - p) * (1f - p)
            val a = xi + (xj - xi) * eIn
            val b = xi + (xj - xi) * eOut
            val left = min(a, b) - half
            val right = max(a, b) + half
            val stretch = (right - left) - 2f * half
            val neck = r * (1f - 0.6f * min(1f, stretch / (cw * 0.6f)))
            val mid = (left + right) / 2f
            val path = Path().apply {
                moveTo(left, cy - r)
                quadraticTo(mid, cy - neck, right, cy - r)
                arcTo(Rect(right - r, cy - r, right + r, cy + r), -90f, 180f, false)
                quadraticTo(mid, cy + neck, left, cy + r)
                arcTo(Rect(left - r, cy - r, left + r, cy + r), 90f, 180f, false)
                close()
            }
            drawPath(path, dropColor)
        }
        val reqs = remember { List(4) { androidx.compose.ui.focus.FocusRequester() } }
        var focusedTab by remember { mutableStateOf(-1) }
        Row(Modifier.fillMaxSize()) {
            navDefs.forEachIndexed { idx, d ->
                val t = 1f - min(1f, abs(pos - idx))
                val accT = AuraUi.accentColor()
                // renkler üstteki "Tümü" çipleriyle aynı: seçili = çip yazı rengi (ChipLook.fg), seçili olmayan = çipin pasif rengi
                val selT = ChipLook.fg
                val unT = if (AuraUi.light) Color(0xFF3B4A54) else Color(0xFFA7ADB2)
                val tint = lerp(unT, selT, t)
                Column(
                    Modifier.weight(1f).fillMaxHeight()
                        .focusRequester(reqs[idx])
                        .focusProperties {
                            left = if (idx > 0) reqs[idx - 1] else androidx.compose.ui.focus.FocusRequester.Cancel
                            right = if (idx < 3) reqs[idx + 1] else androidx.compose.ui.focus.FocusRequester.Cancel
                        }
                        .onFocusChanged { st ->
                            if (st.isFocused) { focusedTab = idx; if (pager.currentPage != idx) onTab(idx) }
                            else if (focusedTab == idx) focusedTab = -1
                        }
                        .drawBehind {
                            if (focusedTab == idx) {
                                val rr = androidx.compose.ui.geometry.CornerRadius(14.dp.toPx(), 14.dp.toPx())
                                val sw = 3.dp.toPx()
                                val inset = 6.dp.toPx()
                                val tl = androidx.compose.ui.geometry.Offset(inset, 2.dp.toPx())
                                val sz = androidx.compose.ui.geometry.Size(size.width - 2 * inset, size.height - 4.dp.toPx())
                                drawRoundRect(Color.White.copy(alpha = 0.14f), tl, sz, rr)
                                drawRoundRect(Color.White, androidx.compose.ui.geometry.Offset(tl.x + sw / 2f, tl.y + sw / 2f), androidx.compose.ui.geometry.Size(sz.width - sw, sz.height - sw), rr, style = androidx.compose.ui.graphics.drawscope.Stroke(sw))
                            }
                        }
                        .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { onTab(idx) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(19.dp))
                    Box {
                        Icon(d.icon, d.label, tint = tint, modifier = Modifier.size(24.dp))
                        val bc = badges.getOrElse(idx) { 0 }
                        if (bc != 0) {
                            // WhatsApp gibi: simgenin sağ üstünde yeşil rozet (sayı) ya da küçük yeşil nokta (yeni durum)
                            Box(
                                Modifier.align(Alignment.TopStart).offset(x = if (bc < 0) 17.dp else 13.dp, y = if (bc < 0) (-4).dp else (-7).dp)
                                    .then(if (bc < 0) Modifier.size(10.dp) else Modifier.height(17.dp).widthIn(min = 17.dp))
                                    .clip(CircleShape).background((AuraUi.accentColor() ?: if (AuraUi.light) Color(0xFF1B6B49) else Color(0xFF25D366))),
                                contentAlignment = Alignment.Center
                            ) {
                                if (bc > 0) Text(
                                    if (bc > 99) "99+" else bc.toString(), color = if (AuraUi.light || AuraUi.accentColor() != null) Color(0xFFFFFFFF) else Color(0xFF04210F), fontSize = 11.sp, lineHeight = 11.sp,
                                    fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false,
                                    style = androidx.compose.ui.text.TextStyle(
                                        platformStyle = androidx.compose.ui.text.PlatformTextStyle(includeFontPadding = false),
                                        lineHeightStyle = androidx.compose.ui.text.style.LineHeightStyle(
                                            androidx.compose.ui.text.style.LineHeightStyle.Alignment.Center,
                                            androidx.compose.ui.text.style.LineHeightStyle.Trim.Both
                                        )
                                    ),
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                            }
                        }
                    }
                    Text(d.label, color = tint, fontSize = with(androidx.compose.ui.platform.LocalDensity.current) { 41f.toSp() }, maxLines = 1, softWrap = false, modifier = Modifier.padding(top = 3.dp))
                }
            }
        }
    }
}


/** Çip sürüklenirken sayfa (sekme) kaydırması kapansın */
object ChipDrag { var active by androidx.compose.runtime.mutableStateOf(false) }

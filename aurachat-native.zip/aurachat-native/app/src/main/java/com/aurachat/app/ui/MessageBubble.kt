package com.aurachat.app.ui

import androidx.compose.runtime.remember
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Message
import kotlinx.coroutines.delay

private val TickBlue = AuraTick

private fun fmtSec(s: Int): String = "%d:%02d".format(s / 60, s % 60)

fun messageImages(m: Message): List<String> =
    if (m.images.isNotEmpty()) m.images else if (m.imageUrl.isNotEmpty()) listOf(m.imageUrl) else emptyList()

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(
    m: Message,
    me: String,
    isGroup: Boolean,
    starred: Boolean,
    selected: Boolean,
    flash: Boolean = false,
    flashColor: Color = Color(0xFF22C55E),
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onQuoteClick: (String) -> Unit,
    onOpenImages: (List<String>, Int) -> Unit,
    onOpenDocument: (Message) -> Unit,
    onOpenLocation: (Message) -> Unit,
    mineColor: Color = AuraMine,
    viewOnceSeen: Boolean = false,
    onOpenViewOnce: (Message) -> Unit = {},
    onVote: (Message, String) -> Unit = { _, _ -> }
) {
    if (m.type == "system") {
        Box(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
            Text(
                m.text,
                color = AuraMuted,
                fontSize = 12.sp,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF1B1F21)).padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        return
    }

    val mine = m.senderUid == me
    val bubbleColor = if (mine) mineColor else AuraTheirs
    val flashA by androidx.compose.animation.core.animateFloatAsState(
        if (flash) 0.34f else 0f,
        androidx.compose.animation.core.tween(if (flash) 120 else 1100), label = "flash"
    )
    val highlight = if (selected) Color(0x4422C55E) else if (flashA > 0.001f) flashColor.copy(alpha = flashA) else Color.Transparent

    Row(
        Modifier
            .fillMaxWidth()
            .background(highlight)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
    ) {
        Column(horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
            Column(
                Modifier
                    .widthIn(max = 300.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(bubbleColor)
                    .then(if (m.type == "image" && !m.deleted && !m.viewOnce) Modifier.padding(4.dp) else Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            ) {
                if (isGroup && !mine && m.senderName.isNotBlank() && !m.deleted) {
                    Text(m.senderName, color = colorForName(m.senderName), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
                if (m.forwarded && !m.deleted) {
                    Text("↪ İletildi", color = AuraMuted, fontSize = 11.sp, fontStyle = FontStyle.Italic)
                }
                val rq = m.replyTo
                if (rq != null && !m.deleted) {
                    Row(
                        Modifier
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0x33000000))
                            .clickable { onQuoteClick(rq.msgId) }
                            .height(IntrinsicSize.Min)
                    ) {
                        Box(Modifier.width(3.dp).fillMaxHeight().background(AuraGreen))
                        Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                            Text(rq.senderName, color = AuraGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(rq.previewText, color = Color(0xFFD0D5D8), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }

                if (m.deleted || m.type == "deleted") {
                    Text("🚫 Bu mesaj silindi", color = AuraMuted, fontSize = 14.sp, fontStyle = FontStyle.Italic)
                } else when (m.type) {
                    "image" -> if (m.viewOnce) ViewOnceRow(m, mine, viewOnceSeen, onOpenViewOnce) else ImageBlock(m, onOpenImages)
                    "audio" -> AudioRow(m)
                    "location" -> LocationBlock(m, onOpenLocation)
                    "document" -> DocumentBlock(m, onOpenDocument)
                    "call" -> Text(
                        "📞 " + m.text.ifBlank { "Arama" } + if (m.callDuration > 0) " · ${fmtSec(m.callDuration)}" else "",
                        color = Color.White, fontSize = 15.sp
                    )
                    "missed_call" -> Text(
                        if (m.callType == "audio") "📞 Cevapsız sesli arama" else "📹 Cevapsız görüntülü arama",
                        color = Color(0xFFF87171), fontSize = 15.sp
                    )
                    "declined_call" -> Text(
                        if (m.callType == "audio") "📞 Reddedilen sesli arama" else "📹 Reddedilen görüntülü arama",
                        color = Color.White, fontSize = 15.sp
                    )
                    "call_duration" -> Text(
                        (if (m.callType == "audio") "📞 Sesli arama" else "📹 Görüntülü arama") + " • " + fmtSec(m.callDuration),
                        color = Color.White, fontSize = 15.sp
                    )
                    "poll" -> PollBlock(m, me, onVote)
                    else -> Column {
                        Text(mentionText(m, me), color = Color(0xFFF3F4F6), fontSize = 15.sp)
                        m.linkPreview?.let { LinkCard(it) }
                    }
                }
                if (m.type == "image" && m.text.isNotBlank() && !m.deleted) {
                    Text(m.text, color = Color(0xFFF3F4F6), fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp, start = 6.dp, end = 6.dp))
                }

                Row(
                    Modifier.align(Alignment.End).padding(top = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (starred) {
                        Icon(Icons.Default.Star, null, tint = AuraMuted, modifier = Modifier.size(11.dp))
                        Spacer(Modifier.width(3.dp))
                    }
                    if (m.edited && !m.deleted) {
                        Text("düzenlendi · ", color = Color.White, fontSize = 10.sp)
                    }
                    Text(formatClock(m.time), color = Color.White, fontSize = 10.sp)
                    if (mine && !m.deleted) {
                        Spacer(Modifier.width(3.dp))
                        val seen = if (isGroup) m.readBy.any { it != me } else m.read
                        when {
                            m.pending -> Icon(Icons.Default.Schedule, null, tint = AuraMuted, modifier = Modifier.size(13.dp))
                            seen -> Icon(Icons.Default.DoneAll, null, tint = TickBlue, modifier = Modifier.size(14.dp))
                            else -> Icon(Icons.Default.DoneAll, null, tint = Color(0xFF9CA3AF), modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }
            if (m.reactions.isNotEmpty() && !m.deleted) {
                val grouped = m.reactions.values.groupingBy { it }.eachCount()
                Row(
                    Modifier
                        .padding(top = 2.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF1B1F21))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    grouped.forEach { (emoji, n) ->
                        Text(if (n > 1) "$emoji $n " else "$emoji ", fontSize = 13.sp, color = Color.White)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ImageBlock(m: Message, onOpen: (List<String>, Int) -> Unit) {
    val imgs = messageImages(m)
    if (imgs.isEmpty()) {
        Box(Modifier.size(200.dp, 120.dp).background(Color(0xFF2A2F31)), contentAlignment = Alignment.Center) {
            Text("📷 Fotoğraf yükleniyor…", color = AuraMuted, fontSize = 12.sp)
        }
        return
    }
    if (imgs.size == 1) {
        DataUrlImage(
            imgs[0], 720,
            Modifier.size(230.dp, 230.dp).clip(RoundedCornerShape(8.dp)).clickable { onOpen(imgs, 0) },
            ContentScale.Crop
        )
        return
    }
    val shown = imgs.take(4)
    val extra = imgs.size - shown.size
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        shown.chunked(2).forEachIndexed { r, row ->
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                row.forEachIndexed { c, img ->
                    val idx = r * 2 + c
                    Box(Modifier.size(114.dp).clip(RoundedCornerShape(6.dp)).clickable { onOpen(imgs, idx) }) {
                        DataUrlImage(img, 360, Modifier.size(114.dp), ContentScale.Crop)
                        if (idx == 3 && extra > 0) {
                            Box(Modifier.size(114.dp).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                                Text("+$extra", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Mesajdaki @İsim parçalarını mavi vurgular */
private fun mentionText(m: Message, me: String): androidx.compose.ui.text.AnnotatedString {
    if (m.mentionNames.isEmpty() || m.type != "text") return androidx.compose.ui.text.AnnotatedString(m.text)
    val mine = m.mentions.contains(me)
    return androidx.compose.ui.text.buildAnnotatedString {
        append(m.text)
        m.mentionNames.forEach { name ->
            val tok = "@$name"
            var from = 0
            while (true) {
                val i = m.text.indexOf(tok, from)
                if (i < 0) break
                addStyle(
                    androidx.compose.ui.text.SpanStyle(
                        color = Color(0xFF53BDEB), fontWeight = FontWeight.SemiBold,
                        background = if (mine) Color(0x2E53BDEB) else Color.Unspecified
                    ), i, i + tok.length
                )
                from = i + tok.length
            }
        }
    }
}

@Composable
private fun LinkCard(lp: com.aurachat.app.data.LinkPreview) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val host = remember(lp.url) { try { android.net.Uri.parse(lp.url).host?.removePrefix("www.") ?: "" } catch (e: Throwable) { "" } }
    Column(
        Modifier.padding(top = 6.dp).widthIn(min = 200.dp).clip(RoundedCornerShape(10.dp)).background(Color(0x40000000))
            .clickable {
                try { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(lp.url))) } catch (e: Throwable) {}
            }
    ) {
        if (lp.image.isNotBlank()) RemoteImage(lp.image, Modifier.fillMaxWidth().heightIn(max = 150.dp).height(140.dp))
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            if (lp.title.isNotBlank()) Text(lp.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            if (lp.description.isNotBlank()) Text(lp.description, color = Color(0xFFD1D7DB), fontSize = 11.5.sp, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            Text(host, color = Color(0xFF9AA5AB), fontSize = 10.5.sp, modifier = Modifier.padding(top = 3.dp))
        }
    }
}

@Composable
private fun RemoteImage(url: String, modifier: Modifier) {
    val bmp by produceState<android.graphics.Bitmap?>(null, url) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) }
            } catch (e: Throwable) { null }
        }
    }
    val b = bmp
    if (b != null) androidx.compose.foundation.Image(b.asImageBitmap(), null, modifier, contentScale = androidx.compose.ui.layout.ContentScale.Crop)
}

@Composable
private fun PollBlock(m: Message, me: String, onVote: (Message, String) -> Unit) {
    val counts = HashMap<String, Int>()
    var voters = 0
    m.votes.values.forEach { arr ->
        if (arr.isNotEmpty()) voters++
        arr.forEach { counts[it] = (counts[it] ?: 0) + 1 }
    }
    val mine = m.votes[me] ?: emptyList()
    val maxCount = maxOf(1, m.pollOptions.maxOfOrNull { counts[it.id] ?: 0 } ?: 0)
    Column(Modifier.widthIn(min = 230.dp, max = 300.dp)) {
        Text("📊 " + m.question, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(
            if (m.pollMulti) "Birden fazla seçenek seçebilirsiniz" else "Bir seçenek seçin",
            color = Color(0xB3FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
        )
        m.pollOptions.forEach { o ->
            val c = counts[o.id] ?: 0
            val picked = mine.contains(o.id)
            val pct = if (voters > 0) Math.round(c * 100f / voters) else 0
            val bar = if (voters > 0) c.toFloat() / maxCount else 0f
            Column(Modifier.fillMaxWidth().clickable { onVote(m, o.id) }.padding(vertical = 7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(20.dp)
                            .clip(if (m.pollMulti) RoundedCornerShape(5.dp) else CircleShape)
                            .background(if (picked) Color(0xFF22C55E) else Color.Transparent)
                            .border(2.dp, if (picked) Color(0xFF22C55E) else Color(0x73FFFFFF), if (m.pollMulti) RoundedCornerShape(5.dp) else CircleShape),
                        contentAlignment = Alignment.Center
                    ) { if (picked) Text("✓", color = Color(0xFF04210F), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    Text(o.text, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f).padding(horizontal = 10.dp))
                    Text("$c", color = Color(0xD9FFFFFF), fontSize = 12.sp)
                }
                Box(
                    Modifier.padding(start = 30.dp, top = 5.dp).fillMaxWidth().height(5.dp)
                        .clip(RoundedCornerShape(50)).background(Color(0x24FFFFFF))
                ) {
                    Box(
                        Modifier.fillMaxWidth(bar).height(5.dp).clip(RoundedCornerShape(50))
                            .background(if (picked) Color(0xFF22C55E) else Color(0x8CFFFFFF))
                    )
                }
                if (voters > 0) Text("%$pct", color = Color(0x99FFFFFF), fontSize = 10.sp, modifier = Modifier.padding(start = 30.dp, top = 2.dp))
            }
        }
        Text("$voters oy", color = Color(0xB3FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun ViewOnceBadge(size: androidx.compose.ui.unit.Dp, color: Color, fontSize: Int) {
    Box(
        Modifier.size(size).border(2.dp, color, CircleShape),
        contentAlignment = Alignment.Center
    ) { Text("1", color = color, fontSize = fontSize.sp, fontWeight = FontWeight.Bold) }
}

/** "Bir kez görüntülenebilir" fotoğraf satırı (web ile aynı üç durum) */
@Composable
private fun ViewOnceRow(m: Message, mine: Boolean, seen: Boolean, onOpen: (Message) -> Unit) {
    val opened = m.imageDelivered || seen || m.imageUrl.isBlank()
    when {
        opened -> Text("✓ Fotoğraf açıldı", color = AuraMuted, fontSize = 13.sp, fontStyle = FontStyle.Italic)
        mine -> Row(verticalAlignment = Alignment.CenterVertically) {
            ViewOnceBadge(22.dp, Color(0xFFE5E7EB), 12)
            Text("  Fotoğraf · henüz açılmadı", color = Color(0xFFE5E7EB), fontSize = 13.sp)
        }
        else -> Row(Modifier.clickable { onOpen(m) }, verticalAlignment = Alignment.CenterVertically) {
            ViewOnceBadge(26.dp, AuraGreen, 13)
            Text("  Fotoğraf · görmek için dokun", color = Color.White, fontSize = 14.sp)
        }
    }
}

@Composable
private fun AudioRow(m: Message) {
    val ctx = LocalContext.current
    val active = AudioPlayer.currentId == m.id
    val playing = active && AudioPlayer.playing
    LaunchedEffect(active, playing) {
        while (active && playing) {
            AudioPlayer.tick()
            delay(200)
        }
    }
    val total = if (active && AudioPlayer.durationMs > 0) AudioPlayer.durationMs else m.audioDuration * 1000
    val prog = if (active && total > 0) AudioPlayer.positionMs.toFloat() / total else 0f
    Row(Modifier.width(250.dp).padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(48.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color(0x59000000))
                .clickable { if (m.audio.isNotEmpty()) AudioPlayer.toggle(ctx, m.id, m.audio) },
            contentAlignment = Alignment.Center
        ) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            LinearProgressIndicator(
                progress = { prog.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = Color.White,
                trackColor = Color(0x4DFFFFFF)
            )
            Text(
                fmtSec(if (active) AudioPlayer.positionMs / 1000 else m.audioDuration),
                color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }
        Icon(Icons.Default.Mic, null, tint = AuraMuted, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun LocationBlock(m: Message, onOpen: (Message) -> Unit) {
    Row(
        Modifier
            .width(220.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x33000000))
            .clickable { onOpen(m) }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.LocationOn, null, tint = Color(0xFFEF4444), modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text("Konum", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text("%.5f, %.5f".format(m.lat, m.lng), color = AuraMuted, fontSize = 12.sp)
            Text("Haritada aç", color = AuraGreen, fontSize = 12.sp)
        }
    }
}

@Composable
private fun DocumentBlock(m: Message, onOpen: (Message) -> Unit) {
    Row(
        Modifier
            .width(220.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x33000000))
            .clickable { onOpen(m) }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Description, null, tint = Color.White, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            m.fileName.ifBlank { "Belge" },
            color = Color.White, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
    }
}

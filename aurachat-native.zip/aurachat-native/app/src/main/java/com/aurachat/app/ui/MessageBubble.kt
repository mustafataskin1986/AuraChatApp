package com.aurachat.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Message
import kotlinx.coroutines.delay

private val TickBlue = AuraTick

private fun fmtSec(s: Int): String = "%d:%02d".format(s / 60, s % 60)

fun messageImages(m: Message): List<String> =
    if (m.images.isNotEmpty()) m.images else if (m.imageUrl.isNotEmpty()) listOf(m.imageUrl) else emptyList()

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(
    m: Message,
    me: String,
    isGroup: Boolean,
    starred: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onQuoteClick: (String) -> Unit,
    onOpenImages: (List<String>, Int) -> Unit,
    onOpenDocument: (Message) -> Unit,
    onOpenLocation: (Message) -> Unit
) {
    if (m.type == "system") {
        Box(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
            Text(
                m.text,
                color = AuraMuted,
                fontSize = 12.sp,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF1B1F21)).padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        return
    }

    val mine = m.senderUid == me
    val bubbleColor = if (mine) AuraMine else AuraTheirs
    val highlight = if (selected) Color(0x4422C55E) else Color.Transparent

    Row(
        Modifier
            .fillMaxWidth()
            .background(highlight)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
    ) {
        Column(horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
            Column(
                Modifier
                    .widthIn(max = 300.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(bubbleColor)
                    .then(if (m.type == "image" && !m.deleted) Modifier.padding(4.dp) else Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            ) {
                if (isGroup && !mine && m.senderName.isNotBlank() && !m.deleted) {
                    Text(m.senderName, color = colorForName(m.senderName), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
                if (m.forwarded && !m.deleted) {
                    Text("↪ İletildi", color = AuraMuted, fontSize = 11.sp, fontStyle = FontStyle.Italic)
                }
                val rq = m.replyTo
                if (rq != null && !m.deleted) {
                    Row(
                        Modifier
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0x33000000))
                            .clickable { onQuoteClick(rq.msgId) }
                            .height(IntrinsicSize.Min)
                    ) {
                        Box(Modifier.width(3.dp).fillMaxHeight().background(AuraGreen))
                        Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                            Text(rq.senderName, color = AuraGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(rq.previewText, color = Color(0xFFD0D5D8), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }

                if (m.deleted || m.type == "deleted") {
                    Text("🚫 Bu mesaj silindi", color = AuraMuted, fontSize = 14.sp, fontStyle = FontStyle.Italic)
                } else when (m.type) {
                    "image" -> ImageBlock(m, onOpenImages)
                    "audio" -> AudioRow(m)
                    "location" -> LocationBlock(m, onOpenLocation)
                    "document" -> DocumentBlock(m, onOpenDocument)
                    "call" -> Text(
                        "📞 " + m.text.ifBlank { "Arama" } + if (m.callDuration > 0) " · ${fmtSec(m.callDuration)}" else "",
                        color = Color.White, fontSize = 15.sp
                    )
                    "missed_call" -> Text(
                        if (m.callType == "audio") "📞 Cevapsız sesli arama" else "📹 Cevapsız görüntülü arama",
                        color = Color(0xFFF87171), fontSize = 15.sp
                    )
                    "declined_call" -> Text(
                        if (m.callType == "audio") "📞 Reddedilen sesli arama" else "📹 Reddedilen görüntülü arama",
                        color = Color.White, fontSize = 15.sp
                    )
                    "call_duration" -> Text(
                        (if (m.callType == "audio") "📞 Sesli arama" else "📹 Görüntülü arama") + " • " + fmtSec(m.callDuration),
                        color = Color.White, fontSize = 15.sp
                    )
                    "poll" -> Text("📊 Anket (bu sürümde henüz desteklenmiyor)", color = AuraMuted, fontSize = 14.sp)
                    else -> Text(m.text, color = Color(0xFFF3F4F6), fontSize = 15.sp)
                }
                if (m.type == "image" && m.text.isNotBlank() && !m.deleted) {
                    Text(m.text, color = Color(0xFFF3F4F6), fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp, start = 6.dp, end = 6.dp))
                }

                Row(
                    Modifier.align(Alignment.End).padding(top = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (starred) {
                        Icon(Icons.Default.Star, null, tint = AuraMuted, modifier = Modifier.size(11.dp))
                        Spacer(Modifier.width(3.dp))
                    }
                    if (m.edited && !m.deleted) {
                        Text("düzenlendi · ", color = Color.White, fontSize = 10.sp)
                    }
                    Text(formatClock(m.time), color = Color.White, fontSize = 10.sp)
                    if (mine && !m.deleted) {
                        Spacer(Modifier.width(3.dp))
                        val seen = if (isGroup) m.readBy.any { it != me } else m.read
                        when {
                            m.pending -> Icon(Icons.Default.Schedule, null, tint = AuraMuted, modifier = Modifier.size(13.dp))
                            seen -> Icon(Icons.Default.DoneAll, null, tint = TickBlue, modifier = Modifier.size(14.dp))
                            else -> Icon(Icons.Default.DoneAll, null, tint = Color(0xFF9CA3AF), modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }
            if (m.reactions.isNotEmpty() && !m.deleted) {
                val grouped = m.reactions.values.groupingBy { it }.eachCount()
                Row(
                    Modifier
                        .padding(top = 2.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF1B1F21))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    grouped.forEach { (emoji, n) ->
                        Text(if (n > 1) "$emoji $n " else "$emoji ", fontSize = 13.sp, color = Color.White)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ImageBlock(m: Message, onOpen: (List<String>, Int) -> Unit) {
    val imgs = messageImages(m)
    if (imgs.isEmpty()) {
        Box(Modifier.size(200.dp, 120.dp).background(Color(0xFF2A2F31)), contentAlignment = Alignment.Center) {
            Text("📷 Fotoğraf yükleniyor…", color = AuraMuted, fontSize = 12.sp)
        }
        return
    }
    if (imgs.size == 1) {
        DataUrlImage(
            imgs[0], 720,
            Modifier.size(230.dp, 230.dp).clip(RoundedCornerShape(8.dp)).clickable { onOpen(imgs, 0) },
            ContentScale.Crop
        )
        return
    }
    val shown = imgs.take(4)
    val extra = imgs.size - shown.size
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        shown.chunked(2).forEachIndexed { r, row ->
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                row.forEachIndexed { c, img ->
                    val idx = r * 2 + c
                    Box(Modifier.size(114.dp).clip(RoundedCornerShape(6.dp)).clickable { onOpen(imgs, idx) }) {
                        DataUrlImage(img, 360, Modifier.size(114.dp), ContentScale.Crop)
                        if (idx == 3 && extra > 0) {
                            Box(Modifier.size(114.dp).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                                Text("+$extra", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AudioRow(m: Message) {
    val ctx = LocalContext.current
    val active = AudioPlayer.currentId == m.id
    val playing = active && AudioPlayer.playing
    LaunchedEffect(active, playing) {
        while (active && playing) {
            AudioPlayer.tick()
            delay(200)
        }
    }
    val total = if (active && AudioPlayer.durationMs > 0) AudioPlayer.durationMs else m.audioDuration * 1000
    val prog = if (active && total > 0) AudioPlayer.positionMs.toFloat() / total else 0f
    Row(Modifier.width(250.dp).padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(48.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color(0x59000000))
                .clickable { if (m.audio.isNotEmpty()) AudioPlayer.toggle(ctx, m.id, m.audio) },
            contentAlignment = Alignment.Center
        ) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            LinearProgressIndicator(
                progress = { prog.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = Color.White,
                trackColor = Color(0x4DFFFFFF)
            )
            Text(
                fmtSec(if (active) AudioPlayer.positionMs / 1000 else m.audioDuration),
                color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }
        Icon(Icons.Default.Mic, null, tint = AuraMuted, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun LocationBlock(m: Message, onOpen: (Message) -> Unit) {
    Row(
        Modifier
            .width(220.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x33000000))
            .clickable { onOpen(m) }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.LocationOn, null, tint = Color(0xFFEF4444), modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text("Konum", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text("%.5f, %.5f".format(m.lat, m.lng), color = AuraMuted, fontSize = 12.sp)
            Text("Haritada aç", color = AuraGreen, fontSize = 12.sp)
        }
    }
}

@Composable
private fun DocumentBlock(m: Message, onOpen: (Message) -> Unit) {
    Row(
        Modifier
            .width(220.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x33000000))
            .clickable { onOpen(m) }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Description, null, tint = Color.White, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            m.fileName.ifBlank { "Belge" },
            color = Color.White, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
    }
}

package com.aurachat.app.ui

import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.drawBehind
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.blur
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material.icons.filled.Image
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.combinedClickable
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Message
import kotlinx.coroutines.delay

private val TickBlue = AuraTick

private fun fmtSec(s: Int): String = "%d:%02d".format(s / 60, s % 60)

fun messageImages(m: Message): List<String> =
    if (m.images.isNotEmpty()) m.images else if (m.imageUrl.isNotEmpty()) listOf(m.imageUrl) else emptyList()

val LocalBubbleLong = androidx.compose.runtime.compositionLocalOf<() -> Unit> { {} }

/** Mesaj içindeki dokunulabilir alanlar (resim, belge…) basılı tutmayı da baloncuğa iletir */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.tapLong(onClick: () -> Unit): Modifier = this.combinedClickable(onClick = onClick, onLongClick = LocalBubbleLong.current)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(
    m: Message,
    me: String,
    isGroup: Boolean,
    starred: Boolean,
    selected: Boolean,
    flash: Boolean = false,
    flashColor: Color = Color(0xFF22C55E),
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onQuoteClick: (String) -> Unit,
    quoteImage: String = "",
    onOpenImages: (List<String>, Int) -> Unit,
    onOpenDocument: (Message) -> Unit,
    onOpenLocation: (Message) -> Unit,
    mineColor: Color = AuraMine,
    viewOnceSeen: Boolean = false,
    onOpenViewOnce: (Message) -> Unit = {},
    onVote: (Message, String) -> Unit = { _, _ -> },
    groupAvatar: Boolean = false,
    groupSpace: Boolean = false,
    onAvatarClick: () -> Unit = {},
    onForward: (() -> Unit)? = null,
    onReactionsClick: () -> Unit = {},
    onCallClick: (Message) -> Unit = {},
    leftAlign: Boolean = false,
    tail: Boolean = true
) {
    androidx.compose.runtime.CompositionLocalProvider(LocalBubbleLong provides onLongClick) {
        MessageBubbleInner(m = m, me = me, isGroup = isGroup, starred = starred, selected = selected, flash = flash, flashColor = flashColor, onClick = onClick, onLongClick = onLongClick, onQuoteClick = onQuoteClick, quoteImage = quoteImage, onOpenImages = onOpenImages, onOpenDocument = onOpenDocument, onOpenLocation = onOpenLocation, mineColor = mineColor, viewOnceSeen = viewOnceSeen, onOpenViewOnce = onOpenViewOnce, onVote = onVote, groupAvatar = groupAvatar, groupSpace = groupSpace, onAvatarClick = onAvatarClick, onForward = onForward, onReactionsClick = onReactionsClick, onCallClick = onCallClick, leftAlign = leftAlign, tail = tail)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubbleInner(
    m: Message,
    me: String,
    isGroup: Boolean,
    starred: Boolean,
    selected: Boolean,
    flash: Boolean = false,
    flashColor: Color = Color(0xFF22C55E),
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onQuoteClick: (String) -> Unit,
    quoteImage: String = "",
    onOpenImages: (List<String>, Int) -> Unit,
    onOpenDocument: (Message) -> Unit,
    onOpenLocation: (Message) -> Unit,
    mineColor: Color = AuraMine,
    viewOnceSeen: Boolean = false,
    onOpenViewOnce: (Message) -> Unit = {},
    onVote: (Message, String) -> Unit = { _, _ -> },
    groupAvatar: Boolean = false,
    groupSpace: Boolean = false,
    onAvatarClick: () -> Unit = {},
    onForward: (() -> Unit)? = null,
    onReactionsClick: () -> Unit = {},
    onCallClick: (Message) -> Unit = {},
    leftAlign: Boolean = false,
    tail: Boolean = true
) {
    if (m.type == "system") {
        Box(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
            Text(
                m.text,
                color = AuraMuted,
                fontSize = 12.sp,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF1B1F21)).padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        return
    }

    val mine = m.senderUid == me
    val alignEnd = mine && !leftAlign
    // WhatsApp gibi: balon ekran genişliğinin yaklaşık %81'ine kadar uzar
    val maxBubble = (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp * 0.81f).dp
    val bubbleColor = if (mine) mineColor else AuraTheirs
    val bubbleShape = RoundedCornerShape(
        topStart = if (tail && !alignEnd) 0.dp else 10.dp, topEnd = if (tail && alignEnd) 0.dp else 10.dp,
        bottomStart = 10.dp, bottomEnd = 10.dp
    )
    val flashA by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (flash) 0.45f else 0f,
        animationSpec = androidx.compose.animation.core.tween(if (flash) 150 else 1400, easing = androidx.compose.animation.core.LinearEasing),
        label = "flash"
    )
    val highlight = if (selected) flashColor.copy(alpha = 0.27f) else if (flashA > 0.001f) flashColor.copy(alpha = flashA) else Color.Transparent

    Row(
        Modifier
            .fillMaxWidth()
            .background(highlight)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = if (mine && !leftAlign) Arrangement.End else Arrangement.Start
    ) {
        val sp by liveProfile(if (isGroup && !mine) m.senderUid else "")
        if (isGroup && !mine && (groupAvatar || groupSpace)) {
            if (groupAvatar) {
                val nm = (sp?.name?.takeIf { it.isNotBlank() } ?: m.senderName).ifBlank { "?" }
                Box(Modifier.size(28.dp).clip(CircleShape).clickable(onClick = onAvatarClick)) {
                    Avatar(nm, sp?.avatar ?: "", 28.dp)
                }
            } else Spacer(Modifier.width(28.dp))
            Spacer(Modifier.width(6.dp))
        }
val canFwd = onForward != null && !m.deleted && !m.viewOnce && (m.type == "image" || m.type == "document" || m.type == "video" || (m.type == "text" && Regex("(https?://|www\\.)", RegexOption.IGNORE_CASE).containsMatchIn(m.text)))
        if (canFwd && mine && !leftAlign) FwdBtn(onForward!!)
                Column(horizontalAlignment = if (mine && !leftAlign) Alignment.End else Alignment.Start) {
            Column(
                Modifier
                    .widthIn(max = maxBubble)
                    .then(if (m.replyTo != null && !m.deleted) Modifier.width(IntrinsicSize.Max) else Modifier)
                    .drawBehind {
                        if (tail) {
                            val tw = 8.dp.toPx(); val th = 11.dp.toPx()
                            val path = androidx.compose.ui.graphics.Path()
                            if (alignEnd) { path.moveTo(size.width, 0f); path.lineTo(size.width + tw, 0f); path.lineTo(size.width, th) }
                            else { path.moveTo(0f, 0f); path.lineTo(-tw, 0f); path.lineTo(0f, th) }
                            path.close()
                            drawPath(path, bubbleColor)
                        }
                    }
                    .clip(bubbleShape)
                    .background(bubbleColor)
                    .then(if ((m.type == "image" || m.type == "video") && !m.deleted && !m.viewOnce) Modifier.padding(4.dp) else Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
            ) {
                if (isGroup && !mine && m.senderName.isNotBlank() && !m.deleted) {
                    Text(
                        sp?.name?.takeIf { it.isNotBlank() } ?: m.senderName,
                        color = senderColor(m.senderUid, m.senderName), fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                    )
                }
                if (m.forwarded && !m.deleted) {
                    Text("↪ İletildi", color = AuraMuted, fontSize = 11.sp, fontStyle = FontStyle.Italic)
                }
                val rq = m.replyTo
                if (rq != null && !m.deleted) {
                    val qc = if (isGroup && rq.senderUid.isNotEmpty()) senderColor(rq.senderUid, rq.senderName, 78) else AuraGreen
                    val qPhoto = rq.previewText.startsWith("\uD83D\uDCF7")
                    QuoteCard(
                        rq.senderName, qc, qc,
                        if (qPhoto) rq.previewText.removePrefix("\uD83D\uDCF7").trim() else rq.previewText, qPhoto, quoteImage,
                        Color(0x33000000), 6.dp, 11f, 40.dp,
                        Modifier.padding(vertical = 2.dp).tapLong { onQuoteClick(rq.msgId) }, textColor = Color(0xFFD0D5D8)
                    )
                }

                val inlineMeta = m.type == "text" && !m.deleted && m.linkPreview == null
                val metaContent: @Composable () -> Unit = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                    if (starred) {
                        Icon(Icons.Default.Star, null, tint = AuraMuted, modifier = Modifier.size(11.dp))
                        Spacer(Modifier.width(3.dp))
                    }
                    if (m.edited && !m.deleted) {
                        Text("düzenlendi · ", color = Color.White, fontSize = 11.sp, lineHeight = 13.sp, letterSpacing = 0.sp)
                    }
                    Text(formatClock(m.time), color = Color(0xB3FFFFFF), fontSize = 11.sp, lineHeight = 13.sp, letterSpacing = 0.sp)
                    if (mine && !m.deleted) {
                        Spacer(Modifier.width(3.dp))
                        val seen = if (isGroup) m.readBy.any { it != me } else m.read
                        when {
                            m.pending -> Icon(Icons.Default.Schedule, null, tint = AuraMuted, modifier = Modifier.size(13.dp))
                            seen -> Icon(Icons.Default.DoneAll, null, tint = TickBlue, modifier = Modifier.size(14.dp))
                            else -> Icon(Icons.Default.DoneAll, null, tint = Color(0xFF9CA3AF), modifier = Modifier.size(14.dp))
                        }
                    }
                    }
                }
                if (m.deleted || m.type == "deleted") {
                    Text("🚫 Bu mesaj silindi", color = AuraMuted, fontSize = 14.sp, fontStyle = FontStyle.Italic)
                } else when (m.type) {
                    "image" -> if (m.viewOnce) ViewOnceRow(m, mine, viewOnceSeen, onOpenViewOnce) else ImageBlock(m, onOpenImages)
                    "audio" -> AudioRow(m)
                    "location" -> LocationBlock(m, onOpenLocation)
                    "document" -> DocumentBlock(m, onOpenDocument)
                    "video" -> VideoBlock(m, onOpenDocument)
                    "call", "missed_call", "declined_call", "call_duration" -> CallCard(m, mine, onCallClick)
                    "poll" -> PollBlock(m, me, onVote)
                    else -> if (inlineMeta) {
                        val full = mentionText(m, me)
                        val raw = full.text
                        val tooLong = raw.length > 700
                        if (tooLong && ReadMore.open[m.id] != true) {
                            val cut = raw.take(700).let { t -> val sp = t.lastIndexOfAny(charArrayOf(' ', '\n')); if (sp > 500) sp else t.length }
                            val shown = androidx.compose.ui.text.buildAnnotatedString {
                                append(full.subSequence(0, cut).let { it.subSequence(0, it.text.trimEnd().length) })
                                append("…")
                            }
                            Column {
                                Text(shown, color = Color(0xFFF3F4F6), style = BubbleText)
                                // "Devamını okuyun" solda, saat/tik aynı satırın sağında (WhatsApp)
                                Row(Modifier.fillMaxWidth().padding(top = 2.dp), verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        "Devamını okuyun", color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.Medium,
                                        modifier = Modifier.clip(RoundedCornerShape(50)).background(Color(0x47000000))
                                            .clickable { ReadMore.open[m.id] = true }.padding(horizontal = 12.dp, vertical = 3.dp)
                                    )
                                    Spacer(Modifier.weight(1f).widthIn(min = 12.dp))
                                    metaContent()
                                }
                            }
                        } else InlineTimeLayout(full, metaContent)
                    } else Column {
                        Text(mentionText(m, me), color = Color(0xFFF3F4F6), style = BubbleText)
                        m.linkPreview?.let { LinkCard(it) }
                    }
                }
                val captionMeta = m.type == "image" && m.text.isNotBlank() && !m.deleted
                if (captionMeta) {
                    // Altyazı ve saat/tik aynı satırda (WhatsApp): saat sağ altta durur, altta fazladan boşluk kalmaz
                    Box(Modifier.width(230.dp).padding(top = 4.dp, start = 6.dp, end = 2.dp)) {
                        InlineTimeLayout(androidx.compose.ui.text.AnnotatedString(m.text), metaContent, fill = true)
                    }
                }

                if (!inlineMeta && !captionMeta) Box(Modifier.align(Alignment.End).padding(top = 2.dp)) { metaContent() }
            }
            if (m.reactions.isNotEmpty() && !m.deleted) {
                val grouped = m.reactions.values.groupingBy { it }.eachCount()
                Row(
                    Modifier
                        .padding(top = 2.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF1B1F21))
                        .clickable(onClick = onReactionsClick)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    grouped.forEach { (emoji, n) ->
                        Text(if (n > 1) "$emoji $n " else "$emoji ", fontSize = 13.sp, color = Color.White)
                    }
                }
            }
        }
        if (canFwd && (!mine || leftAlign)) FwdBtn(onForward!!)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ImageBlock(m: Message, onOpen: (List<String>, Int) -> Unit) {
    val imgs = messageImages(m)
    val total = maxOf(m.imagesCount, m.images.size, imgs.size)
    if (imgs.isEmpty() && total <= 1) {
        BlurThumb(m.thumb, Modifier.size(230.dp).clip(RoundedCornerShape(8.dp)))
        return
    }
    if (imgs.size == 1 && total <= 1) {
        DataUrlImage(
            imgs[0], 720,
            Modifier.size(230.dp, 230.dp).clip(RoundedCornerShape(8.dp)).tapLong { onOpen(imgs, 0) },
            ContentScale.Crop
        )
        return
    }
    val slots = minOf(total, 4)
    val extra = total - slots
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        (0 until slots).toList().chunked(2).forEachIndexed { r, row ->
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                row.forEachIndexed { c, idx ->
                    val img = imgs.getOrNull(idx)
                    Box(Modifier.size(114.dp).clip(RoundedCornerShape(6.dp)).tapLong { if (img != null) onOpen(imgs, idx) }) {
                        if (img != null) DataUrlImage(img, 360, Modifier.size(114.dp), ContentScale.Crop)
                        else BlurThumb(m.thumbs.getOrNull(idx) ?: "", Modifier.size(114.dp))
                        if (idx == 3 && extra > 0) {
                            Box(Modifier.size(114.dp).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                                Text("+$extra", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Mesajdaki @İsim parçalarını mavi vurgular */
private fun mentionText(m: Message, me: String): androidx.compose.ui.text.AnnotatedString {
    if (m.mentionNames.isEmpty() || m.type != "text") return androidx.compose.ui.text.AnnotatedString(m.text)
    val mine = m.mentions.contains(me)
    return androidx.compose.ui.text.buildAnnotatedString {
        append(m.text)
        m.mentionNames.forEach { name ->
            val tok = "@$name"
            var from = 0
            while (true) {
                val i = m.text.indexOf(tok, from)
                if (i < 0) break
                addStyle(
                    androidx.compose.ui.text.SpanStyle(
                        color = Color(0xFF53BDEB), fontWeight = FontWeight.SemiBold,
                        background = if (mine) Color(0x2E53BDEB) else Color.Unspecified
                    ), i, i + tok.length
                )
                from = i + tok.length
            }
        }
    }
}

@Composable
private fun LinkCard(lp: com.aurachat.app.data.LinkPreview) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val host = remember(lp.url) { try { android.net.Uri.parse(lp.url).host?.removePrefix("www.") ?: "" } catch (e: Throwable) { "" } }
    Column(
        Modifier.padding(top = 6.dp).widthIn(min = 200.dp).clip(RoundedCornerShape(10.dp)).background(Color(0x40000000))
            .tapLong {
                try { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(lp.url))) } catch (e: Throwable) {}
            }
    ) {
        if (lp.image.isNotBlank()) {
            val isVideo = host.contains("tiktok") || host.contains("youtu") || host.contains("vimeo") || host.contains("instagram") || host.contains("facebook") || host.contains("fb.watch") || host.contains("twitch")
            Box(Modifier.fillMaxWidth().height(if (isVideo) 220.dp else 140.dp), contentAlignment = Alignment.Center) {
                RemoteImage(lp.image, Modifier.fillMaxSize())
                if (isVideo) {
                    Box(Modifier.size(56.dp).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(36.dp))
                    }
                }
            }
        }
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            if (lp.title.isNotBlank()) Text(lp.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            if (lp.description.isNotBlank()) Text(lp.description, color = Color(0xFFD1D7DB), fontSize = 11.5.sp, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            Text(host, color = Color(0xFF9AA5AB), fontSize = 10.5.sp, modifier = Modifier.padding(top = 3.dp))
        }
    }
}

@Composable
private fun RemoteImage(url: String, modifier: Modifier) {
    val bmp by produceState<android.graphics.Bitmap?>(null, url) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) }
            } catch (e: Throwable) { null }
        }
    }
    val b = bmp
    if (b != null) androidx.compose.foundation.Image(b.asImageBitmap(), null, modifier, contentScale = androidx.compose.ui.layout.ContentScale.Crop, colorFilter = auraImageFilter())
}

@Composable
private fun PollBlock(m: Message, me: String, onVote: (Message, String) -> Unit) {
    val counts = HashMap<String, Int>()
    var voters = 0
    m.votes.values.forEach { arr ->
        if (arr.isNotEmpty()) voters++
        arr.forEach { counts[it] = (counts[it] ?: 0) + 1 }
    }
    val mine = m.votes[me] ?: emptyList()
    val maxCount = maxOf(1, m.pollOptions.maxOfOrNull { counts[it.id] ?: 0 } ?: 0)
    Column(Modifier.widthIn(min = 230.dp, max = 300.dp)) {
        Text("📊 " + m.question, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Text(
            if (m.pollMulti) "Birden fazla seçenek seçebilirsiniz" else "Bir seçenek seçin",
            color = Color(0xB3FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
        )
        m.pollOptions.forEach { o ->
            val c = counts[o.id] ?: 0
            val picked = mine.contains(o.id)
            val pct = if (voters > 0) Math.round(c * 100f / voters) else 0
            val bar = if (voters > 0) c.toFloat() / maxCount else 0f
            Column(Modifier.fillMaxWidth().tapLong { onVote(m, o.id) }.padding(vertical = 7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(20.dp)
                            .clip(if (m.pollMulti) RoundedCornerShape(5.dp) else CircleShape)
                            .background(if (picked) Color(0xFF22C55E) else Color.Transparent)
                            .border(2.dp, if (picked) Color(0xFF22C55E) else Color(0x73FFFFFF), if (m.pollMulti) RoundedCornerShape(5.dp) else CircleShape),
                        contentAlignment = Alignment.Center
                    ) { if (picked) Text("✓", color = Color(0xFF04210F), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    Text(o.text, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f).padding(horizontal = 10.dp))
                    Text("$c", color = Color(0xD9FFFFFF), fontSize = 12.sp)
                }
                Box(
                    Modifier.padding(start = 30.dp, top = 5.dp).fillMaxWidth().height(5.dp)
                        .clip(RoundedCornerShape(50)).background(Color(0x24FFFFFF))
                ) {
                    Box(
                        Modifier.fillMaxWidth(bar).height(5.dp).clip(RoundedCornerShape(50))
                            .background(if (picked) Color(0xFF22C55E) else Color(0x8CFFFFFF))
                    )
                }
                if (voters > 0) Text("%$pct", color = Color(0x99FFFFFF), fontSize = 10.sp, modifier = Modifier.padding(start = 30.dp, top = 2.dp))
            }
        }
        Text("$voters oy", color = Color(0xB3FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun ViewOnceBadge(size: androidx.compose.ui.unit.Dp, color: Color, fontSize: Int) {
    Box(
        Modifier.size(size).border(2.dp, color, CircleShape),
        contentAlignment = Alignment.Center
    ) { Text("1", color = color, fontSize = fontSize.sp, fontWeight = FontWeight.Bold) }
}

/** "Bir kez görüntülenebilir" fotoğraf satırı (web ile aynı üç durum) */
@Composable
private fun ViewOnceRow(m: Message, mine: Boolean, seen: Boolean, onOpen: (Message) -> Unit) {
    val opened = m.imageDelivered || seen || m.imageUrl.isBlank()
    when {
        opened -> Text("✓ Fotoğraf açıldı", color = AuraMuted, fontSize = 13.sp, fontStyle = FontStyle.Italic)
        mine -> Row(verticalAlignment = Alignment.CenterVertically) {
            ViewOnceBadge(22.dp, Color(0xFFE5E7EB), 12)
            Text("  Fotoğraf · henüz açılmadı", color = Color(0xFFE5E7EB), fontSize = 13.sp)
        }
        else -> Row(Modifier.tapLong { onOpen(m) }, verticalAlignment = Alignment.CenterVertically) {
            ViewOnceBadge(26.dp, AuraGreen, 13)
            Text("  Fotoğraf · görmek için dokun", color = Color.White, fontSize = 14.sp)
        }
    }
}

@Composable
private fun AudioRow(m: Message) {
    val ctx = LocalContext.current
    val active = AudioPlayer.currentId == m.id
    val playing = active && AudioPlayer.playing
    LaunchedEffect(active, playing) {
        while (active && playing) {
            AudioPlayer.tick()
            delay(200)
        }
    }
    val total = if (active && AudioPlayer.durationMs > 0) AudioPlayer.durationMs else m.audioDuration * 1000
    val prog = if (active && total > 0) AudioPlayer.positionMs.toFloat() / total else 0f
    Row(Modifier.width(250.dp).padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(48.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color(0x59000000))
                .tapLong { if (m.audio.isNotEmpty()) AudioPlayer.toggle(ctx, m.id, m.audio) },
            contentAlignment = Alignment.Center
        ) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            LinearProgressIndicator(
                progress = { prog.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = Color.White,
                trackColor = Color(0x4DFFFFFF)
            )
            Text(
                fmtSec(if (active) AudioPlayer.positionMs / 1000 else m.audioDuration),
                color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }
        Icon(Icons.Default.Mic, null, tint = AuraMuted, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun LocationBlock(m: Message, onOpen: (Message) -> Unit) {
    Row(
        Modifier
            .width(220.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x33000000))
            .tapLong { onOpen(m) }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.LocationOn, null, tint = Color(0xFFEF4444), modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text("Konum", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text("%.5f, %.5f".format(m.lat, m.lng), color = AuraMuted, fontSize = 12.sp)
            Text("Haritada aç", color = AuraGreen, fontSize = 12.sp)
        }
    }
}

@Composable
private fun DocumentBlock(m: Message, onOpen: (Message) -> Unit) {
    Row(
        Modifier
            .width(220.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x33000000))
            .tapLong { onOpen(m) }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Description, null, tint = Color.White, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            m.fileName.ifBlank { "Belge" },
            color = Color.White, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
    }
}

/** Resim telefonda yokken bulanık önizleme (web buildBlurPlaceholder ile aynı) */
@Composable
private fun BlurThumb(thumb: String, modifier: Modifier) {
    Box(modifier.background(Color(0x33000000)), contentAlignment = Alignment.Center) {
        if (thumb.isNotEmpty()) {
            DataUrlImage(
                thumb, 64,
                Modifier.fillMaxSize().graphicsLayer(scaleX = 1.25f, scaleY = 1.25f)
                    .then(if (android.os.Build.VERSION.SDK_INT >= 31) Modifier.blur(10.dp) else Modifier),
                ContentScale.Crop
            )
        }
        Icon(Icons.Default.Image, null, tint = Color(0xCCD1D5DB), modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.FwdBtn(onClick: () -> Unit) {
    Box(
        Modifier.padding(horizontal = 6.dp).align(Alignment.CenterVertically).size(30.dp).clip(CircleShape)
            .background(Color(0x33000000)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.AutoMirrored.Filled.Reply, "İlet", tint = Color(0xFFD1D5DB), modifier = Modifier.size(17.dp).graphicsLayer(scaleX = -1f)) }
}

@Composable
private fun VideoBlock(m: Message, onOpen: (Message) -> Unit) {
    Box(
        Modifier.size(230.dp, 170.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF0B0F12)).tapLong { onOpen(m) },
        contentAlignment = Alignment.Center
    ) {
        if (m.thumb.isNotEmpty()) DataUrlImage(m.thumb, 400, Modifier.fillMaxSize(), ContentScale.Crop)
        Box(Modifier.size(48.dp).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PlayArrow, "Oynat", tint = Color.White, modifier = Modifier.size(32.dp))
        }
        if (m.audioDuration > 0) Text(
            String.format(java.util.Locale.US, "%d:%02d", m.audioDuration / 60, m.audioDuration % 60),
            color = Color.White, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.BottomStart).padding(8.dp).clip(RoundedCornerShape(6.dp)).background(Color(0x99000000)).padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

/** Metin ve saat/tik: saat sığıyorsa son satırın sağında, sığmıyorsa altında (WhatsApp düzeni) */
@Composable
private fun InlineTimeLayout(text: androidx.compose.ui.text.AnnotatedString, meta: @Composable () -> Unit, fill: Boolean = false) {
    var lastRight by remember(text) { androidx.compose.runtime.mutableFloatStateOf(-1f) }
    val gap = with(androidx.compose.ui.platform.LocalDensity.current) { 8.dp.roundToPx() }
    androidx.compose.ui.layout.Layout(content = {
        Text(text, color = Color(0xFFF3F4F6), style = BubbleText, onTextLayout = { r -> lastRight = r.getLineRight(r.lineCount - 1) })
        Box { meta() }
    }) { ms, c ->
        val tp = ms[0].measure(c.copy(minWidth = 0))
        val mp = ms[1].measure(androidx.compose.ui.unit.Constraints())
        val lr = if (lastRight < 0f) tp.width else lastRight.toInt()
        val fits = lr + gap + mp.width <= c.maxWidth
        val w = if (fill && c.maxWidth != androidx.compose.ui.unit.Constraints.Infinity) c.maxWidth
            else (if (fits) maxOf(tp.width, lr + gap + mp.width) else maxOf(tp.width, mp.width)).coerceAtMost(c.maxWidth)
        val h = if (fits) maxOf(tp.height, mp.height) else tp.height + mp.height
        layout(w, h) {
            tp.placeRelative(0, 0)
            mp.placeRelative(w - mp.width, h - mp.height)
        }
    }
}

private fun callDurLabel(s: Int): String = if (s < 60) "$s sn." else "${s / 60} dk ${s % 60} sn."

/** WhatsApp tarzı arama kartı: ikon, başlık, açıklama; dokununca "Ara" paneli açılır */
@Composable
private fun CallCard(m: Message, mine: Boolean, onClick: (Message) -> Unit) {
    val audio = m.callType == "audio"
    val missed = m.type == "missed_call" || m.type == "declined_call"
    val title = when (m.type) {
        "missed_call" -> if (audio) "Cevapsız sesli arama" else "Cevapsız görüntülü arama"
        "declined_call" -> if (audio) "Reddedilen sesli arama" else "Reddedilen görüntülü arama"
        else -> if (audio) "Sesli arama" else "Görüntülü arama"
    }
    val sub = when {
        m.type == "missed_call" -> if (mine) "Cevap verilmedi" else "Geri aramak için dokunun"
        m.type == "declined_call" -> if (mine) "Reddedildi" else "Geri aramak için dokunun"
        m.callDuration > 0 -> callDurLabel(m.callDuration)
        else -> m.text.ifBlank { "Geri aramak için dokunun" }
    }
    val tint = if (missed) Color(0xFFF87171) else Color(0xFF22C55E)
    val icon = when {
        !audio -> Icons.Default.Videocam
        missed -> Icons.Default.CallMissed
        mine -> Icons.Default.CallMade
        else -> Icons.Default.CallReceived
    }
    Row(
        Modifier.widthIn(min = 200.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x33000000))
            .clickable { onClick(m) }.padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0x33000000)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        }
        Column(Modifier.padding(start = 12.dp)) {
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Color(0xFFB8C0C6), fontSize = 14.sp)
        }
    }
}

/** "Devamını okuyun" ile açılan uzun mesajlar; sohbetten çıkınca temizlenir (tekrar girince yine kısaltılmış görünür) */
object ReadMore {
    val open = androidx.compose.runtime.mutableStateMapOf<String, Boolean>()
}

/** Mesaj yazısı: WhatsApp ölçüsü (boyut, satır aralığı, harf aralığı yok) */
private val BubbleText = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, lineHeight = 18.sp, letterSpacing = 0.sp)

/** Karşı taraf yazarken sohbetin altında beliren "yazıyor" satırı: üç nokta (+ grupta "N kişi yazıyor"); balonsuz, temaya uyumlu */
@Composable
fun TypingBubble(count: Int = 0) {
    val inf = androidx.compose.animation.core.rememberInfiniteTransition(label = "typing")
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.Start, verticalAlignment = Alignment.CenterVertically
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            for (i in 0 until 3) {
                val a by inf.animateFloat(
                    0.35f, 1f,
                    androidx.compose.animation.core.infiniteRepeatable(
                        androidx.compose.animation.core.keyframes {
                            durationMillis = 900
                            0.35f at (i * 150)
                            1f at (i * 150 + 250)
                            0.35f at (i * 150 + 500)
                        }
                    ), label = "dot$i"
                )
                Box(Modifier.size(7.dp).clip(CircleShape).background(AuraMuted.copy(alpha = a)))
            }
        }
        if (count > 0) {
            Text(
                "$count kişi yazıyor", color = AuraMuted,
                style = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, lineHeight = 18.sp),
                modifier = Modifier.padding(start = 10.dp)
            )
        }
    }
}

/** Üç yerde (mesaj balonu, giriş, resim görüntüleyici) aynı alıntı kartı: ad 1 satır, metin en fazla 3 satır, küçük resim kartın tam yüksekliğinde */
@Composable
fun QuoteCard(
    name: String, nameColor: Color, stripe: Color, preview: String, photo: Boolean, thumb: String,
    bg: Color, radius: androidx.compose.ui.unit.Dp, textSp: Float, thumbDp: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier, endPad: androidx.compose.ui.unit.Dp = 0.dp, textColor: Color = Color(0xFFB0BCC4)
) {
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(radius)).background(bg).height(IntrinsicSize.Min)
    ) {
        Box(Modifier.width(3.dp).fillMaxHeight().background(stripe))
        Column(Modifier.weight(1f).padding(start = 8.dp, end = 8.dp + (if (thumb.isBlank()) endPad else 0.dp), top = 4.dp, bottom = 4.dp)) {
            Text(name, color = nameColor, fontSize = textSp.sp, lineHeight = (textSp + 3f).sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            val inl = if (photo) mapOf("ic" to androidx.compose.foundation.text.InlineTextContent(
                androidx.compose.ui.text.Placeholder((textSp + 1f).sp, (textSp + 1f).sp, androidx.compose.ui.text.PlaceholderVerticalAlign.Center)
            ) { Icon(Icons.Default.Image, null, tint = textColor, modifier = Modifier.fillMaxSize()) }) else emptyMap()
            val body = androidx.compose.ui.text.buildAnnotatedString {
                if (photo) { appendInlineContent("ic", "[img]"); append(" ") }
                append(preview)
            }
            Text(
                text = body, inlineContent = inl, color = textColor, fontSize = textSp.sp, lineHeight = (textSp + 3f).sp,
                maxLines = 3, overflow = TextOverflow.Ellipsis
            )
        }
        if (thumb.isNotBlank()) {
            Box(Modifier.width(thumbDp).fillMaxHeight()) {
                DataUrlImage(thumb, 160, Modifier.matchParentSize(), androidx.compose.ui.layout.ContentScale.Crop)
            }
        }
    }
}

fun WebHostIsVideo(url: String): Boolean {
    val h = try { android.net.Uri.parse(url).host?.lowercase() ?: "" } catch (e: Throwable) { "" }
    return h.contains("tiktok") || h.contains("youtu") || h.contains("vimeo") || h.contains("instagram") || h.contains("facebook") || h.contains("fb.watch") || h.contains("twitch")
}

/** Giriş çubuğundaki bağlantı önizlemesi küçük resmi (video sitelerinde oynat simgesiyle) */
@Composable
fun LinkThumb(url: String, video: Boolean, modifier: Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        RemoteImage(url, Modifier.fillMaxSize())
        if (video) {
            Box(Modifier.size(32.dp).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
        }
    }
}

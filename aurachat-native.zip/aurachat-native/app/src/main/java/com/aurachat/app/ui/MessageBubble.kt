package com.aurachat.app.ui

import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.drawBehind
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.blur
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material.icons.filled.Image
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.combinedClickable
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Message
import kotlinx.coroutines.delay

private val TickBlue = AuraTick

/** Açık temada doygun (koyu) giden balonun içi mi? Alt düzen (InlineTimeLayout vb.) sonradan çizildiği için renk bu yerel değerle seçilir */
val LocalDeepBubble = androidx.compose.runtime.compositionLocalOf { false }
@Composable private fun bLc(v: Long): Color = if (LocalDeepBubble.current) Color(v) else auraLc(v)
@Composable private fun bWhite(): Color = if (LocalDeepBubble.current) Color.White else AuraWhite
@Composable private fun bMuted(): Color = if (LocalDeepBubble.current) Color(0xCCFFFFFF) else AuraMuted
@Composable private fun bTick(): Color = if (LocalDeepBubble.current) Color(0xFF53BDEB) else AuraTick

private fun fmtSec(s: Int): String = "%d:%02d".format(s / 60, s % 60)

fun messageImages(m: Message): List<String> =
    if (m.images.isNotEmpty()) m.images else if (m.imageUrl.isNotEmpty()) listOf(m.imageUrl) else emptyList()

/** Silinmiş ya da artık erişilemeyen resim / belge iletilemez: uyarı verir, iletilebilenleri döndürür */
fun fwdCheck(ctx: android.content.Context, msgs: List<Message>): List<Message> {
    val ok = msgs.filter { m ->
        !(m.deleted || (m.type == "image" && messageImages(m).isEmpty()) || (m.type == "document" && m.imageUrl.isEmpty()))
    }
    if (ok.size < msgs.size) {
        val doc = msgs.any { it.type == "document" && !ok.contains(it) }
        val img = msgs.any { it.type == "image" && !ok.contains(it) }
        val what = if (doc && !img) "belge" else if (img && !doc) "resim" else "mesaj"
        android.widget.Toast.makeText(ctx, "Silinen $what iletilemez", android.widget.Toast.LENGTH_SHORT).show()
    }
    return ok
}

val LocalBubbleLong = androidx.compose.runtime.compositionLocalOf<() -> Unit> { {} }

/** Mesaj içindeki dokunulabilir alanlar (resim, belge…) basılı tutmayı da baloncuğa iletir */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.tapLong(onClick: () -> Unit): Modifier = this.combinedClickable(onClick = onClick, onLongClick = LocalBubbleLong.current)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(
    m: Message,
    me: String,
    isGroup: Boolean,
    starred: Boolean,
    selected: Boolean,
    flash: Boolean = false,
    flashColor: Color = auraLc(0xFF22C55E),
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onQuoteClick: (String) -> Unit,
    quoteImage: String = "",
    onOpenImages: (List<String>, Int) -> Unit,
    onOpenDocument: (Message) -> Unit,
    onOpenLocation: (Message) -> Unit,
    mineColor: Color = AuraMine,
    theirColor: Color = AuraTheirs,
    viewOnceSeen: Boolean = false,
    onOpenViewOnce: (Message) -> Unit = {},
    onVote: (Message, String) -> Unit = { _, _ -> },
    groupAvatar: Boolean = false,
    groupSpace: Boolean = false,
    onAvatarClick: () -> Unit = {},
    onForward: (() -> Unit)? = null,
    onReactionsClick: () -> Unit = {},
    onCallClick: (Message) -> Unit = {},
    leftAlign: Boolean = false,
    swipeFade: () -> Float = { 0f },
    tail: Boolean = true
) {
    val deepB = m.senderUid == me && AuraUi.light && mineColor.luminance() < 0.45f
    androidx.compose.runtime.CompositionLocalProvider(LocalDeepBubble provides deepB) {
    DeepBubbleScope(if (m.senderUid == me) mineColor else Color.White) {
    androidx.compose.runtime.CompositionLocalProvider(LocalBubbleLong provides onLongClick) {
        MessageBubbleInner(m = m, me = me, isGroup = isGroup, starred = starred, selected = selected, flash = flash, flashColor = flashColor, onClick = onClick, onLongClick = onLongClick, onQuoteClick = onQuoteClick, quoteImage = quoteImage, onOpenImages = onOpenImages, onOpenDocument = onOpenDocument, onOpenLocation = onOpenLocation, mineColor = mineColor, theirColor = theirColor, viewOnceSeen = viewOnceSeen, onOpenViewOnce = onOpenViewOnce, onVote = onVote, groupAvatar = groupAvatar, groupSpace = groupSpace, onAvatarClick = onAvatarClick, onForward = onForward, onReactionsClick = onReactionsClick, onCallClick = onCallClick, leftAlign = leftAlign, swipeFade = swipeFade, tail = tail)
    }
    }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubbleInner(
    m: Message,
    me: String,
    isGroup: Boolean,
    starred: Boolean,
    selected: Boolean,
    flash: Boolean = false,
    flashColor: Color = auraLc(0xFF22C55E),
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onQuoteClick: (String) -> Unit,
    quoteImage: String = "",
    onOpenImages: (List<String>, Int) -> Unit,
    onOpenDocument: (Message) -> Unit,
    onOpenLocation: (Message) -> Unit,
    mineColor: Color = AuraMine,
    theirColor: Color = AuraTheirs,
    viewOnceSeen: Boolean = false,
    onOpenViewOnce: (Message) -> Unit = {},
    onVote: (Message, String) -> Unit = { _, _ -> },
    groupAvatar: Boolean = false,
    groupSpace: Boolean = false,
    onAvatarClick: () -> Unit = {},
    onForward: (() -> Unit)? = null,
    onReactionsClick: () -> Unit = {},
    onCallClick: (Message) -> Unit = {},
    leftAlign: Boolean = false,
    swipeFade: () -> Float = { 0f },
    tail: Boolean = true
) {
    if (m.type == "system") {
        Box(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
            Text(
                m.text,
                color = bMuted(),
                fontSize = 12.sp,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(bLc(0xFF1B1F21)).padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        return
    }

    val mine = m.senderUid == me
    val alignEnd = mine && !leftAlign
    // WhatsApp gibi: balon ekran genişliğinin yaklaşık %81'ine kadar uzar
    val maxBubble = (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp * 0.81f).dp
    val bubbleColor = if (mine) mineColor else theirColor
    val bubbleShape = RoundedCornerShape(
        topStart = if (tail && !alignEnd) 0.dp else 10.dp, topEnd = if (tail && alignEnd) 0.dp else 10.dp,
        bottomStart = 10.dp, bottomEnd = 10.dp
    )
    val flashA by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (flash) 0.45f else 0f,
        animationSpec = androidx.compose.animation.core.tween(if (flash) 150 else 1400, easing = androidx.compose.animation.core.LinearEasing),
        label = "flash"
    )
    val highlight = if (selected) flashColor.copy(alpha = 0.27f) else if (flashA > 0.001f) flashColor.copy(alpha = flashA) else Color.Transparent

    Row(
        Modifier
            .fillMaxWidth()
            .background(highlight)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(start = if (isGroup && !mine && (groupAvatar || groupSpace)) 9.dp else 14.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
        horizontalArrangement = if (mine && !leftAlign) Arrangement.End else Arrangement.Start
    ) {
        val sp by liveProfile(if (isGroup && !mine) m.senderUid else "")
        if (isGroup && !mine && (groupAvatar || groupSpace)) {
            if (groupAvatar) {
                val nm = (sp?.name?.takeIf { it.isNotBlank() } ?: m.senderName).ifBlank { "?" }
                Box(Modifier.size(28.dp).clip(CircleShape).clickable(onClick = onAvatarClick)) {
                    Avatar(nm, sp?.avatar ?: "", 28.dp)
                }
            } else Spacer(Modifier.width(28.dp))
            Spacer(Modifier.width(6.dp))
        }
val canFwd = onForward != null && !m.deleted && !m.viewOnce && (m.type == "image" || m.type == "document" || m.type == "video" || (m.type == "text" && Regex("(https?://|www\\.)", RegexOption.IGNORE_CASE).containsMatchIn(m.text)))
        if (canFwd && mine && !leftAlign) FwdBtn(swipeFade, onForward!!)
                Column(horizontalAlignment = if (mine && !leftAlign) Alignment.End else Alignment.Start) {
            Column(
                Modifier
                    .widthIn(max = maxBubble)
                    .then(if (m.linkPreview?.image?.isNotBlank() == true && !m.deleted) Modifier.width(minOf(maxBubble, linkCardWidth(m.linkPreview!!.image))) else Modifier)
                    .then(if (m.replyTo != null && !m.deleted) Modifier.width(IntrinsicSize.Max) else Modifier)
                    .drawBehind {
                        if (tail) {
                            val tw = 8.dp.toPx(); val th = 11.dp.toPx()
                            val path = androidx.compose.ui.graphics.Path()
                            if (alignEnd) { path.moveTo(size.width, 0f); path.lineTo(size.width + tw, 0f); path.lineTo(size.width, th) }
                            else { path.moveTo(0f, 0f); path.lineTo(-tw, 0f); path.lineTo(0f, th) }
                            path.close()
                            drawPath(path, bubbleColor)
                        }
                    }
                    .clip(bubbleShape)
                    .background(bubbleColor)
                    .then(if ((m.type == "image" || m.type == "video") && !m.deleted && !m.viewOnce) Modifier.padding(4.dp) else Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
            ) {
                if (isGroup && !mine && m.senderName.isNotBlank() && !m.deleted) {
                    Text(
                        sp?.name?.takeIf { it.isNotBlank() } ?: m.senderName,
                        color = senderColor(m.senderUid, m.senderName), fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                    )
                }
                if (m.forwarded && !m.deleted) {
                    Text("↪ İletildi", color = bMuted(), fontSize = 11.sp, fontStyle = FontStyle.Italic)
                }
                val rq = m.replyTo
                if (rq != null && !m.deleted) {
                    val qc = if (isGroup && rq.senderUid.isNotEmpty()) senderColor(rq.senderUid, rq.senderName, 78) else flashColor
                    val qPhoto = rq.previewText.startsWith("\uD83D\uDCF7")
                    val rqLive = liveProfile(rq.senderUid).value?.name?.takeIf { it.isNotBlank() }
                    QuoteCard(
                        rqLive ?: rq.senderName, qc, qc,
                        if (qPhoto) rq.previewText.removePrefix("\uD83D\uDCF7").trim() else rq.previewText, qPhoto, quoteImage,
                        AuraFrame, 6.dp, 15f, 40.dp,
                        Modifier.padding(vertical = 2.dp).tapLong { onQuoteClick(rq.msgId) }, textColor = bLc(0xFFD0D5D8)
                    )
                }

                val inlineMeta = m.type == "text" && !m.deleted && m.linkPreview == null
                val metaContent: @Composable () -> Unit = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = m.pinned,
                        enter = androidx.compose.animation.scaleIn(androidx.compose.animation.core.spring(0.45f, 400f)) + androidx.compose.animation.expandHorizontally() + androidx.compose.animation.fadeIn(),
                        exit = androidx.compose.animation.scaleOut() + androidx.compose.animation.shrinkHorizontally() + androidx.compose.animation.fadeOut()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PushPin, null, tint = bMuted(), modifier = Modifier.size(11.dp))
                            Spacer(Modifier.width(3.dp))
                        }
                    }
                    // WhatsApp gibi: yıldız eklenirken zıplayarak belirir
                    androidx.compose.animation.AnimatedVisibility(
                        visible = starred,
                        enter = androidx.compose.animation.scaleIn(androidx.compose.animation.core.spring(0.35f, 350f), initialScale = 0.2f) + androidx.compose.animation.expandHorizontally() + androidx.compose.animation.fadeIn(),
                        exit = androidx.compose.animation.scaleOut() + androidx.compose.animation.shrinkHorizontally() + androidx.compose.animation.fadeOut()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, null, tint = bMuted(), modifier = Modifier.size(11.dp))
                            Spacer(Modifier.width(3.dp))
                        }
                    }
                    if (m.edited && !m.deleted) {
                        Text("düzenlendi · ", color = bWhite(), fontSize = 12.sp, lineHeight = 14.sp, letterSpacing = 0.sp)
                    }
                    Text(formatClock(m.time), color = bLc(0xB3FFFFFF), fontSize = 12.sp, lineHeight = 14.sp, letterSpacing = 0.sp)
                    if (mine && !m.deleted) {
                        Spacer(Modifier.width(4.dp))
                        val seen = if (isGroup) m.readBy.any { it != me } else m.read
                        when {
                            m.pending -> Icon(Icons.Default.Schedule, null, tint = bMuted(), modifier = Modifier.size(15.dp))
                            seen -> Icon(Icons.Default.DoneAll, null, tint = bTick(), modifier = Modifier.size(16.dp))
                            else -> Icon(Icons.Default.DoneAll, null, tint = bLc(0xFF9CA3AF), modifier = Modifier.size(16.dp))
                        }
                    }
                    }
                }
                if (m.deleted || m.type == "deleted") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Block, null, tint = bMuted(), modifier = Modifier.size(19.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (mine) "Bu mesajı sildiniz" else "Bu mesaj silindi", color = bMuted(), fontSize = 16.sp, fontStyle = FontStyle.Italic)
                        Spacer(Modifier.width(12.dp))
                        Box(Modifier.padding(top = 6.dp)) { metaContent() }
                    }
                } else when (m.type) {
                    "image" -> if (m.viewOnce) ViewOnceRow(m, mine, viewOnceSeen, onOpenViewOnce) else ImageBlock(m, onOpenImages)
                    "audio" -> AudioRow(m)
                    "location" -> LocationBlock(m, onOpenLocation)
                    "document" -> DocumentBlock(m, onOpenDocument)
                    "video" -> VideoBlock(m, onOpenDocument)
                    "call", "missed_call", "declined_call", "call_duration" -> CallCard(m, mine, onCallClick, metaContent)
                    "poll" -> PollBlock(m, me, onVote)
                    else -> if (inlineMeta) {
                        val full = mentionText(m, me)
                        val raw = full.text
                        val tooLong = raw.length > 700
                        if (tooLong && ReadMore.open[m.id] != true) {
                            val cut = raw.take(700).let { t -> val sp = t.lastIndexOfAny(charArrayOf(' ', '\n')); if (sp > 500) sp else t.length }
                            val shown = androidx.compose.ui.text.buildAnnotatedString {
                                append(full.subSequence(0, cut).let { it.subSequence(0, it.text.trimEnd().length) })
                                append("…")
                            }
                            Column {
                                Text(shown, color = bLc(0xFFF3F4F6), style = BubbleText)
                                // "Devamını okuyun" solda, saat/tik aynı satırın sağında (WhatsApp)
                                Row(Modifier.fillMaxWidth().padding(top = 2.dp), verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        "Devamını okuyun", color = bWhite(), fontSize = 12.5.sp, fontWeight = FontWeight.Medium,
                                        modifier = Modifier.clip(RoundedCornerShape(50)).background(bLc(0x47000000))
                                            .clickable { ReadMore.open[m.id] = true }.padding(horizontal = 12.dp, vertical = 3.dp)
                                    )
                                    Spacer(Modifier.weight(1f).widthIn(min = 12.dp))
                                    metaContent()
                                }
                            }
                        } else InlineTimeLayout(full, metaContent, fill = m.replyTo != null)
                    } else Column {
                        m.linkPreview?.let { LinkCard(it) }
                        if (m.text.isNotBlank()) Text(mentionText(m, me), color = bLc(0xFFF3F4F6), style = BubbleText, modifier = Modifier.padding(top = if (m.linkPreview != null) 6.dp else 0.dp))
                    }
                }
                val captionMeta = m.type == "image" && m.text.isNotBlank() && !m.deleted
                if (captionMeta) {
                    // Altyazı ve saat/tik aynı satırda (WhatsApp): saat sağ altta durur, altta fazladan boşluk kalmaz
                    Box(Modifier.width(260.dp).padding(top = 4.dp, start = 6.dp, end = 2.dp)) {
                        InlineTimeLayout(androidx.compose.ui.text.AnnotatedString(m.text), metaContent, fill = true)
                    }
                }

                val callMeta = m.type == "call" || m.type == "missed_call" || m.type == "declined_call" || m.type == "call_duration"
                if (!inlineMeta && !captionMeta && !callMeta && !(m.deleted || m.type == "deleted")) Box(Modifier.align(Alignment.End).padding(top = 2.dp)) { metaContent() }
            }
            if (m.reactions.isNotEmpty() && !m.deleted) {
                val grouped = m.reactions.values.groupingBy { it }.eachCount()
                Row(
                    Modifier
                        .padding(top = 2.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(bLc(0xFF1B1F21))
                        .clickable(onClick = onReactionsClick)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    grouped.forEach { (emoji, n) ->
                        Text(if (n > 1) "$emoji $n " else "$emoji ", fontSize = 13.sp, color = bWhite())
                    }
                }
            }
        }
        if (canFwd && (!mine || leftAlign)) FwdBtn(swipeFade, onForward!!)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ImageBlock(m: Message, onOpen: (List<String>, Int) -> Unit) {
    val imgs = messageImages(m)
    val total = maxOf(m.imagesCount, m.images.size, imgs.size)
    if (imgs.isEmpty() && total <= 1) {
        BlurThumb(m.thumb, Modifier.size(260.dp).clip(RoundedCornerShape(8.dp)))
        return
    }
    if (imgs.size == 1 && total <= 1) {
        DataUrlImage(
            imgs[0], 720,
            Modifier.size(260.dp, 260.dp).clip(RoundedCornerShape(8.dp)).tapLong { onOpen(imgs, 0) },
            ContentScale.Crop
        )
        return
    }
    val slots = minOf(total, 4)
    val extra = total - slots
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        // 3 resim: üstte tek geniş, altta iki resim (kare boşluk kalmaz); 2 ve 4 resim: ikişerli
        val rows: List<List<Int>> = if (slots == 3) listOf(listOf(0), listOf(1, 2)) else (0 until slots).toList().chunked(2)
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                row.forEach { idx ->
                    val wide = row.size == 1 && slots == 3
                    val bw = if (wide) 260.dp else 129.dp
                    val img = imgs.getOrNull(idx)
                    Box(Modifier.size(bw, 129.dp).clip(RoundedCornerShape(6.dp)).tapLong { if (img != null) onOpen(imgs, idx) }) {
                        if (img != null) DataUrlImage(img, if (wide) 480 else 360, Modifier.size(bw, 129.dp), ContentScale.Crop)
                        else BlurThumb(m.thumbs.getOrNull(idx) ?: "", Modifier.size(bw, 129.dp))
                        if (idx == 3 && extra > 0) {
                            Box(Modifier.size(129.dp).background(bLc(0x99000000)), contentAlignment = Alignment.Center) {
                                Text("+$extra", color = bWhite(), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Mesajdaki @İsim parçalarını mavi vurgular */
private fun mentionText(m: Message, me: String): androidx.compose.ui.text.AnnotatedString {
    if (m.mentionNames.isEmpty() || m.type != "text") return androidx.compose.ui.text.AnnotatedString(m.text)
    val mine = m.mentions.contains(me)
    return androidx.compose.ui.text.buildAnnotatedString {
        append(m.text)
        m.mentionNames.forEach { name ->
            val tok = "@$name"
            var from = 0
            while (true) {
                val i = m.text.indexOf(tok, from)
                if (i < 0) break
                addStyle(
                    androidx.compose.ui.text.SpanStyle(
                        color = auraLc(0xFF53BDEB), fontWeight = FontWeight.SemiBold,
                        background = if (mine) auraLc(0x2E53BDEB) else Color.Unspecified
                    ), i, i + tok.length
                )
                from = i + tok.length
            }
        }
    }
}

/** WhatsApp gibi: dikey/kare resimde dar (215dp), yatay geniş resimde geniş (295dp) kart */
@Composable
private fun linkCardWidth(image: String): androidx.compose.ui.unit.Dp {
    val appCtx = LocalContext.current.applicationContext
    val bmp by produceState<android.graphics.Bitmap?>(LinkImgCache.peek(image), image) {
        if (value == null) value = LinkImgCache.load(appCtx, image)
    }
    val b = bmp ?: return 215.dp
    val r = (b.width.toFloat() / b.height.toFloat())
    val t = ((r - 1.0f) / 0.6f).coerceIn(0f, 1f)
    return (215f + 80f * t).dp
}

@Composable
private fun LinkCard(lp: com.aurachat.app.data.LinkPreview) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val host = remember(lp.url) { try { android.net.Uri.parse(lp.url).host?.removePrefix("www.") ?: "" } catch (e: Throwable) { "" } }
    Column(
        Modifier.padding(top = 6.dp).then(if (lp.image.isNotBlank()) Modifier.fillMaxWidth() else Modifier.widthIn(min = 200.dp)).clip(RoundedCornerShape(12.dp))
            .background(if (AuraUi.light) Color.White.copy(alpha = 0.45f) else Color(0x40000000))
            .tapLong {
                try { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(lp.url))) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("MessageBubble", e) }
            }
    ) {
        if (lp.image.isNotBlank()) {
            val isVideo = host.contains("tiktok") || host.contains("youtu") || host.contains("vimeo") || host.contains("instagram") || host.contains("facebook") || host.contains("fb.watch") || host.contains("twitch")
            val appCtx = LocalContext.current.applicationContext
            val bmp by produceState<android.graphics.Bitmap?>(LinkImgCache.peek(lp.image), lp.image) {
                if (value == null) value = LinkImgCache.load(appCtx, lp.image)
            }
            val bm = bmp
            // WhatsApp gibi: kapak, kendi oranında (dikey en fazla ~0.72, yatay en fazla ~1.91) kırpmadan gösterilir
            val ratio = if (bm != null) (bm.width.toFloat() / bm.height.toFloat()).coerceIn(0.72f, 2.05f) else 1.3f
            Box(Modifier.fillMaxWidth().aspectRatio(ratio).clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)).background(Color(0x22000000)), contentAlignment = Alignment.Center) {
                if (bm != null) androidx.compose.foundation.Image(bm.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                if (isVideo) {
                    Box(Modifier.size(56.dp).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(36.dp))
                    }
                }
            }
        }
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            if (lp.title.isNotBlank()) Text(lp.title, color = bWhite(), fontSize = 15.sp, lineHeight = 19.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            if (lp.description.isNotBlank()) Text(lp.description, color = bLc(0xFFD1D7DB), fontSize = 13.sp, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Link, null, tint = bLc(0xFF9AA5AB), modifier = Modifier.size(16.dp))
                Text(host, color = bWhite(), fontSize = 14.sp, modifier = Modifier.padding(start = 6.dp))
            }
        }
    }
}

@Composable
private fun RemoteImage(url: String, modifier: Modifier) {
    val appCtx = LocalContext.current.applicationContext
    val bmp by produceState<android.graphics.Bitmap?>(LinkImgCache.peek(url), url) {
        if (value == null) value = LinkImgCache.load(appCtx, url)
    }
    val b = bmp
    if (b != null) androidx.compose.foundation.Image(b.asImageBitmap(), null, modifier, contentScale = androidx.compose.ui.layout.ContentScale.Crop, colorFilter = auraImageFilter())
}

@Composable
private fun PollBlock(m: Message, me: String, onVote: (Message, String) -> Unit) {
    val counts = HashMap<String, Int>()
    var voters = 0
    m.votes.values.forEach { arr ->
        if (arr.isNotEmpty()) voters++
        arr.forEach { counts[it] = (counts[it] ?: 0) + 1 }
    }
    val mine = m.votes[me] ?: emptyList()
    val maxCount = maxOf(1, m.pollOptions.maxOfOrNull { counts[it.id] ?: 0 } ?: 0)
    Column(Modifier.widthIn(min = 230.dp, max = 300.dp)) {
        Text("📊 " + m.question, color = bWhite(), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(
            if (m.pollMulti) "Birden fazla seçenek seçebilirsiniz" else "Bir seçenek seçin",
            color = bLc(0xB3FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
        )
        m.pollOptions.forEach { o ->
            val c = counts[o.id] ?: 0
            val picked = mine.contains(o.id)
            val pct = if (voters > 0) Math.round(c * 100f / voters) else 0
            val bar = if (voters > 0) c.toFloat() / maxCount else 0f
            Column(Modifier.fillMaxWidth().tapLong { onVote(m, o.id) }.padding(vertical = 7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(20.dp)
                            .clip(if (m.pollMulti) RoundedCornerShape(5.dp) else CircleShape)
                            .background(if (picked) bLc(0xFF22C55E) else Color.Transparent)
                            .border(2.dp, if (picked) bLc(0xFF22C55E) else bLc(0x73FFFFFF), if (m.pollMulti) RoundedCornerShape(5.dp) else CircleShape),
                        contentAlignment = Alignment.Center
                    ) { if (picked) Text("✓", color = bLc(0xFF04210F), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    Text(o.text, color = bWhite(), fontSize = 15.sp, modifier = Modifier.weight(1f).padding(horizontal = 10.dp))
                    Text("$c", color = bLc(0xD9FFFFFF), fontSize = 12.sp)
                }
                Box(
                    Modifier.padding(start = 30.dp, top = 5.dp).fillMaxWidth().height(5.dp)
                        .clip(RoundedCornerShape(50)).background(bLc(0x24FFFFFF))
                ) {
                    Box(
                        Modifier.fillMaxWidth(bar).height(5.dp).clip(RoundedCornerShape(50))
                            .background(if (picked) bLc(0xFF22C55E) else bLc(0x8CFFFFFF))
                    )
                }
                if (voters > 0) Text("%$pct", color = bLc(0x99FFFFFF), fontSize = 10.sp, modifier = Modifier.padding(start = 30.dp, top = 2.dp))
            }
        }
        Text("$voters oy", color = bLc(0xB3FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun ViewOnceBadge(size: androidx.compose.ui.unit.Dp, color: Color, fontSize: Int) {
    Box(
        Modifier.size(size).border(2.dp, color, CircleShape),
        contentAlignment = Alignment.Center
    ) { Text("1", color = color, fontSize = fontSize.sp, fontWeight = FontWeight.Bold) }
}

/** "Bir kez görüntülenebilir" fotoğraf satırı (web ile aynı üç durum) */
@Composable
private fun ViewOnceRow(m: Message, mine: Boolean, seen: Boolean, onOpen: (Message) -> Unit) {
    val opened = m.imageDelivered || seen || m.imageUrl.isBlank()
    when {
        opened -> Text("✓ Fotoğraf açıldı", color = bMuted(), fontSize = 13.sp, fontStyle = FontStyle.Italic)
        mine -> Row(verticalAlignment = Alignment.CenterVertically) {
            ViewOnceBadge(22.dp, bLc(0xFFE5E7EB), 12)
            Text("  Fotoğraf · henüz açılmadı", color = bLc(0xFFE5E7EB), fontSize = 13.sp)
        }
        else -> Row(Modifier.tapLong { onOpen(m) }, verticalAlignment = Alignment.CenterVertically) {
            ViewOnceBadge(26.dp, AuraGreen, 13)
            Text("  Fotoğraf · görmek için dokun", color = bWhite(), fontSize = 14.sp)
        }
    }
}

@Composable
private fun AudioRow(m: Message) {
    val ctx = LocalContext.current
    val active = AudioPlayer.currentId == m.id
    val playing = active && AudioPlayer.playing
    LaunchedEffect(active, playing) {
        while (active && playing) {
            AudioPlayer.tick()
            delay(200)
        }
    }
    val total = if (active && AudioPlayer.durationMs > 0) AudioPlayer.durationMs else m.audioDuration * 1000
    val prog = if (active && total > 0) AudioPlayer.positionMs.toFloat() / total else 0f
    Row(Modifier.width(250.dp).padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(48.dp).clip(androidx.compose.foundation.shape.CircleShape).background(bLc(0x59000000))
                .tapLong { if (m.audio.isNotEmpty()) AudioPlayer.toggle(ctx, m.id, m.audio) },
            contentAlignment = Alignment.Center
        ) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = bWhite(), modifier = Modifier.size(30.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            LinearProgressIndicator(
                progress = { prog.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = bWhite(),
                trackColor = bLc(0x4DFFFFFF)
            )
            Text(
                fmtSec(if (active) AudioPlayer.positionMs / 1000 else m.audioDuration),
                color = bWhite(), fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }
        Icon(Icons.Default.Mic, null, tint = bMuted(), modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun LocationBlock(m: Message, onOpen: (Message) -> Unit) {
    Row(
        Modifier
            .width(220.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(AuraFrame)
            .tapLong { onOpen(m) }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.LocationOn, null, tint = bLc(0xFFEF4444), modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text("Konum", color = bWhite(), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text("%.5f, %.5f".format(m.lat, m.lng), color = bMuted(), fontSize = 12.sp)
            Text("Haritada aç", color = AuraGreen, fontSize = 12.sp)
        }
    }
}

@Composable
private fun DocumentBlock(m: Message, onOpen: (Message) -> Unit) {
    Row(
        Modifier
            .width(220.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(AuraFrame)
            .tapLong { onOpen(m) }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Description, null, tint = bWhite(), modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            m.fileName.ifBlank { "Belge" },
            color = bWhite(), fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
    }
}

/** Resim telefonda yokken bulanık önizleme (web buildBlurPlaceholder ile aynı) */
@Composable
private fun BlurThumb(thumb: String, modifier: Modifier) {
    Box(modifier.background(if (AuraUi.light) Color(0x1F000000) else Color(0x33000000)), contentAlignment = Alignment.Center) {
        if (thumb.isNotEmpty()) {
            DataUrlImage(
                thumb, 64,
                Modifier.fillMaxSize().graphicsLayer(scaleX = 1.25f, scaleY = 1.25f)
                    .then(if (android.os.Build.VERSION.SDK_INT >= 31) Modifier.blur(10.dp) else Modifier),
                ContentScale.Crop
            )
        }
        Icon(Icons.Default.Image, null, tint = bLc(0xCCD1D5DB), modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.FwdBtn(fade: () -> Float, onClick: () -> Unit) {
    // WhatsApp ölçülerinden: açık temada yarı saydam gri daire, koyu temada koyu gri daire; ok her ikisinde beyaz
    Box(
        Modifier.padding(horizontal = 6.dp).align(Alignment.CenterVertically).size(32.dp)
            .graphicsLayer { val f = 1f - fade(); alpha = f; scaleX = 0.6f + 0.4f * f; scaleY = 0.6f + 0.4f * f }
            .clip(CircleShape)
            .background(if (AuraUi.light) Color(0x59808080) else Color(0xD93B4448)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Canvas(Modifier.size(18.dp)) {
            val u = size.width / 24f
            val st = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.4f * u, cap = androidx.compose.ui.graphics.StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
            val stem = androidx.compose.ui.graphics.Path().apply {
                moveTo(3f * u, 20f * u); lineTo(3f * u, 15f * u)
                quadraticBezierTo(3f * u, 9f * u, 9f * u, 9f * u); lineTo(17f * u, 9f * u)
            }
            drawPath(stem, Color.White, style = st)
            for (dx in listOf(0f, 4.2f)) {
                val ch = androidx.compose.ui.graphics.Path().apply {
                    moveTo((14.2f + dx) * u, 4.6f * u); lineTo((18.4f + dx) * u, 9f * u); lineTo((14.2f + dx) * u, 13.4f * u)
                }
                drawPath(ch, Color.White, style = st)
            }
        }
    }
}

@Composable
private fun VideoBlock(m: Message, onOpen: (Message) -> Unit) {
    Box(
        Modifier.size(230.dp, 170.dp).clip(RoundedCornerShape(8.dp)).background(bLc(0xFF0B0F12)).tapLong { onOpen(m) },
        contentAlignment = Alignment.Center
    ) {
        if (m.thumb.isNotEmpty()) DataUrlImage(m.thumb, 400, Modifier.fillMaxSize(), ContentScale.Crop)
        Box(Modifier.size(48.dp).clip(CircleShape).background(bLc(0x99000000)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PlayArrow, "Oynat", tint = bWhite(), modifier = Modifier.size(32.dp))
        }
        if (m.audioDuration > 0) Text(
            String.format(java.util.Locale.US, "%d:%02d", m.audioDuration / 60, m.audioDuration % 60),
            color = bWhite(), fontSize = 12.sp,
            modifier = Modifier.align(Alignment.BottomStart).padding(8.dp).clip(RoundedCornerShape(6.dp)).background(bLc(0x99000000)).padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

/** Metin ve saat/tik: saat sığıyorsa son satırın sağında, sığmıyorsa altında (WhatsApp düzeni) */
@Composable
private fun InlineTimeLayout(text: androidx.compose.ui.text.AnnotatedString, meta: @Composable () -> Unit, fill: Boolean = false) {
    var lastRight by remember(text) { androidx.compose.runtime.mutableFloatStateOf(-1f) }
    val gap = with(androidx.compose.ui.platform.LocalDensity.current) { 8.dp.roundToPx() }
    val dropPx = with(androidx.compose.ui.platform.LocalDensity.current) { 3.5.dp.roundToPx() }
    androidx.compose.ui.layout.Layout(content = {
        Text(text, color = bLc(0xFFF3F4F6), style = BubbleText, onTextLayout = { r -> lastRight = r.getLineRight(r.lineCount - 1) })
        Box { meta() }
    }) { ms, c ->
        val tp = ms[0].measure(c.copy(minWidth = 0))
        val mp = ms[1].measure(androidx.compose.ui.unit.Constraints())
        val lr = if (lastRight < 0f) tp.width else lastRight.toInt()
        val fits = lr + gap + mp.width <= c.maxWidth
        val w = if (fill && c.maxWidth != androidx.compose.ui.unit.Constraints.Infinity) c.maxWidth
            else (if (fits) maxOf(tp.width, lr + gap + mp.width) else maxOf(tp.width, mp.width)).coerceAtMost(c.maxWidth)
        val h = if (fits) maxOf(tp.height, mp.height) else tp.height + mp.height
        // WhatsApp gibi: saat/tik yazının taban çizgisinden belirgin şekilde aşağıda durur (alt dolguya taşar)
        val drop = if (fits) dropPx else 0
        layout(w, h) {
            tp.placeRelative(0, 0)
            mp.placeRelative(w - mp.width, h - mp.height + drop)
        }
    }
}

private fun callDurLabel(s: Int): String = if (s < 60) "$s sn." else "${s / 60} dk ${s % 60} sn."

/** WhatsApp tarzı arama kartı: ikon, başlık, açıklama; dokununca "Ara" paneli açılır */
@Composable
private fun CallCard(m: Message, mine: Boolean, onClick: (Message) -> Unit, meta: @Composable () -> Unit) {
    val audio = m.callType == "audio"
    val missed = m.type == "missed_call" || m.type == "declined_call"
    val title = when (m.type) {
        "missed_call" -> if (audio) "Cevapsız sesli arama" else "Cevapsız görüntülü arama"
        "declined_call" -> if (audio) "Reddedilen sesli arama" else "Reddedilen görüntülü arama"
        else -> if (audio) "Sesli arama" else "Görüntülü arama"
    }
    val sub = when {
        m.type == "missed_call" -> if (mine) "Cevaplanmadı" else "Geri aramak için dokunun"
        m.type == "declined_call" -> if (mine) "Reddedildi" else "Geri aramak için dokunun"
        m.callDuration > 0 -> callDurLabel(m.callDuration)
        else -> m.text.ifBlank { "Geri aramak için dokunun" }
    }
    val tint = if (missed && !mine) bLc(0xFFE5173F) else bLc(0xFF5F6368)
    val circle = if (AuraUi.light) Color.White.copy(alpha = if (mine) 0.55f else 1f) else Color.White.copy(alpha = 0.12f)
    val icon = when {
        missed && !mine -> Icons.Default.CallMissed
        mine -> Icons.Default.CallMade
        else -> Icons.Default.CallReceived
    }
    Row(
        Modifier.widthIn(min = 230.dp).clickable { onClick(m) }.padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(54.dp).clip(CircleShape).background(circle), contentAlignment = Alignment.Center) {
            if (audio) {
                Icon(Icons.Default.Call, null, tint = tint, modifier = Modifier.size(26.dp))
            } else {
                androidx.compose.foundation.Canvas(Modifier.size(28.dp)) {
                    val w = size.width; val h = size.height
                    // kamera gövdesi + lens
                    drawRoundRect(tint, androidx.compose.ui.geometry.Offset(0f, h * 0.2f), androidx.compose.ui.geometry.Size(w * 0.68f, h * 0.6f), androidx.compose.ui.geometry.CornerRadius(w * 0.1f))
                    val lens = androidx.compose.ui.graphics.Path().apply {
                        moveTo(w * 0.72f, h * 0.45f); lineTo(w, h * 0.27f); lineTo(w, h * 0.73f); lineTo(w * 0.72f, h * 0.55f); close()
                    }
                    drawPath(lens, tint)
                    // ok (gövdenin içinde, daire zemin renginde)
                    val ac = if (AuraUi.light) Color.White else Color(0xFF1F2C34)
                    val sw = w * 0.07f
                    val cx = w * 0.34f; val cy = h * 0.5f; val r = w * 0.15f
                    if (mine) {
                        drawLine(ac, androidx.compose.ui.geometry.Offset(cx - r, cy + r), androidx.compose.ui.geometry.Offset(cx + r, cy - r), sw)
                        drawLine(ac, androidx.compose.ui.geometry.Offset(cx + r * 0.1f, cy - r), androidx.compose.ui.geometry.Offset(cx + r, cy - r), sw)
                        drawLine(ac, androidx.compose.ui.geometry.Offset(cx + r, cy - r), androidx.compose.ui.geometry.Offset(cx + r, cy - r * 0.1f), sw)
                    } else {
                        drawLine(ac, androidx.compose.ui.geometry.Offset(cx + r, cy - r), androidx.compose.ui.geometry.Offset(cx - r, cy + r), sw)
                        drawLine(ac, androidx.compose.ui.geometry.Offset(cx - r * 0.1f, cy + r), androidx.compose.ui.geometry.Offset(cx - r, cy + r), sw)
                        drawLine(ac, androidx.compose.ui.geometry.Offset(cx - r, cy + r), androidx.compose.ui.geometry.Offset(cx - r, cy + r * 0.1f), sw)
                    }
                }
            }
        }
        Column(Modifier.padding(start = 14.dp)) {
            Text(title, color = bWhite(), fontSize = 18.sp, lineHeight = 24.sp, fontWeight = FontWeight.Medium)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(sub, color = bLc(0xFF667781), fontSize = 17.sp, lineHeight = 24.sp)
                Spacer(Modifier.width(14.dp))
                Box(Modifier.padding(bottom = 2.dp)) { meta() }
            }
        }
    }
}

/** "Devamını okuyun" ile açılan uzun mesajlar; sohbetten çıkınca temizlenir (tekrar girince yine kısaltılmış görünür) */
object ReadMore {
    val open = androidx.compose.runtime.mutableStateMapOf<String, Boolean>()
}

/** Mesaj yazısı: WhatsApp ölçüsü (boyut, satır aralığı, harf aralığı yok) */
private val BubbleText = androidx.compose.ui.text.TextStyle(fontSize = 15.sp, lineHeight = 20.sp)

/** Karşı taraf yazarken sohbetin altında beliren "yazıyor" satırı: üç nokta (+ grupta "N kişi yazıyor"); balonsuz, temaya uyumlu */
@Composable
fun TypingBubble(count: Int = 0) {
    val inf = androidx.compose.animation.core.rememberInfiniteTransition(label = "typing")
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.Start, verticalAlignment = Alignment.CenterVertically
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            for (i in 0 until 3) {
                val a by inf.animateFloat(
                    0.35f, 1f,
                    androidx.compose.animation.core.infiniteRepeatable(
                        androidx.compose.animation.core.keyframes {
                            durationMillis = 900
                            0.35f at (i * 150)
                            1f at (i * 150 + 250)
                            0.35f at (i * 150 + 500)
                        }
                    ), label = "dot$i"
                )
                Box(Modifier.size(7.dp).clip(CircleShape).background(AuraMuted.copy(alpha = a)))
            }
        }
        if (count > 0) {
            Text(
                "$count kişi yazıyor", color = AuraMuted,
                style = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, lineHeight = 18.sp),
                modifier = Modifier.padding(start = 10.dp)
            )
        }
    }
}

/** Üç yerde (mesaj balonu, giriş, resim görüntüleyici) aynı alıntı kartı: ad 1 satır, metin en fazla 3 satır, küçük resim kartın tam yüksekliğinde */
@Composable
fun QuoteCard(
    name: String, nameColor: Color, stripe: Color, preview: String, photo: Boolean, thumb: String,
    bg: Color, radius: androidx.compose.ui.unit.Dp, textSp: Float, thumbDp: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier, endPad: androidx.compose.ui.unit.Dp = 0.dp, textColor: Color = bLc(0xFFB0BCC4)
) {
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(radius)).background(bg).height(IntrinsicSize.Min)
    ) {
        Box(Modifier.width(3.dp).fillMaxHeight().background(stripe))
        Column(Modifier.weight(1f).padding(start = 8.dp, end = 8.dp + (if (thumb.isBlank()) endPad else 0.dp), top = 4.dp, bottom = 4.dp)) {
            Text(name, color = nameColor, fontSize = textSp.sp, lineHeight = (textSp + 3f).sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            val inl = if (photo) mapOf("ic" to androidx.compose.foundation.text.InlineTextContent(
                androidx.compose.ui.text.Placeholder((textSp + 1f).sp, (textSp + 1f).sp, androidx.compose.ui.text.PlaceholderVerticalAlign.Center)
            ) { Icon(Icons.Default.Image, null, tint = textColor, modifier = Modifier.fillMaxSize()) }) else emptyMap()
            val body = androidx.compose.ui.text.buildAnnotatedString {
                if (photo) { appendInlineContent("ic", "[img]"); append(" ") }
                append(preview)
            }
            Text(
                text = body, inlineContent = inl, color = textColor, fontSize = textSp.sp, lineHeight = (textSp + 3f).sp,
                maxLines = 3, overflow = TextOverflow.Ellipsis
            )
        }
        if (thumb.isNotBlank()) {
            Box(Modifier.width(thumbDp).fillMaxHeight()) {
                if (thumb.startsWith("http")) RemoteImage(thumb, Modifier.matchParentSize())
                else DataUrlImage(thumb, 160, Modifier.matchParentSize(), androidx.compose.ui.layout.ContentScale.Crop)
            }
        }
    }
}

/** Alıntı kartındaki küçük resim: fotoğraf, video kapağı veya bağlantı önizleme resmi */
fun quoteThumbOf(o: Message?): String {
    if (o == null || o.deleted) return ""
    return when {
        o.type == "image" && !o.viewOnce -> o.images.firstOrNull() ?: o.imageUrl
        o.type == "video" -> o.thumb.ifBlank { o.thumbs.firstOrNull() ?: "" }
        else -> o.linkPreview?.image ?: ""
    }
}

fun WebHostIsVideo(url: String): Boolean {
    val h = try { android.net.Uri.parse(url).host?.lowercase() ?: "" } catch (e: Throwable) { "" }
    return h.contains("tiktok") || h.contains("youtu") || h.contains("vimeo") || h.contains("instagram") || h.contains("facebook") || h.contains("fb.watch") || h.contains("twitch")
}

/** Giriş çubuğundaki bağlantı önizlemesi küçük resmi (video sitelerinde oynat simgesiyle) */
@Composable
fun LinkThumb(url: String, video: Boolean, modifier: Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        RemoteImage(url, Modifier.fillMaxSize())
        if (video) {
            Box(Modifier.size(32.dp).clip(CircleShape).background(auraLc(0x99000000)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = AuraWhite, modifier = Modifier.size(22.dp))
            }
        }
    }
}


/** Link kartı görselleri: bellek + disk önbelleği; sohbet her açıldığında yeniden indirilmez */
object LinkImgCache {
    private val mem = object : android.util.LruCache<String, android.graphics.Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(k: String, v: android.graphics.Bitmap) = v.byteCount
    }

    fun peek(url: String): android.graphics.Bitmap? = if (url.isBlank()) null else mem.get(url)

    private fun decode(f: java.io.File): android.graphics.Bitmap? {
        val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(f.absolutePath, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= 900) sample *= 2
        return android.graphics.BitmapFactory.decodeFile(f.absolutePath, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
    }

    suspend fun load(ctx: android.content.Context, url: String): android.graphics.Bitmap? {
        if (url.isBlank()) return null
        mem.get(url)?.let { return it }
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val dir = java.io.File(ctx.cacheDir, "linkimg").apply { mkdirs() }
                val f = java.io.File(dir, Integer.toHexString(url.hashCode()) + "_" + url.length + ".img")
                if (!f.exists() || f.length() == 0L) {
                    val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                    c.connectTimeout = 8000; c.readTimeout = 8000
                    val tmp = java.io.File(dir, f.name + ".tmp")
                    c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    tmp.renameTo(f)
                }
                decode(f)?.also { mem.put(url, it) }
            } catch (e: Throwable) { null }
        }
    }
}

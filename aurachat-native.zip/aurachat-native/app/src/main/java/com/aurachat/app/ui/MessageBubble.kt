package com.aurachat.app.ui

import com.aurachat.app.data.Media
import com.aurachat.app.data.Repo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.blur
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material.icons.filled.Image
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.combinedClickable
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Message
import kotlinx.coroutines.delay

private val TickBlue = AuraTick

/** Açık temada doygun (koyu) giden balonun içi mi? Alt düzen (InlineTimeLayout vb.) sonradan çizildiği için renk bu yerel değerle seçilir */
val LocalDeepBubble = androidx.compose.runtime.compositionLocalOf { false }
@Composable private fun bLc(v: Long): Color = if (LocalDeepBubble.current) Color(v) else auraLc(v)
@Composable private fun bWhite(): Color = if (LocalDeepBubble.current) Color.White else if (!AuraUi.light) Color(0xFFF5F5F5) else AuraWhite
@Composable private fun bMuted(): Color = if (LocalDeepBubble.current) Color(0xCCFFFFFF) else AuraMuted
@Composable private fun bTick(): Color = if (LocalDeepBubble.current) Color(0xFF53BDEB) else AuraTick

private fun fmtSec(s: Int): String = "%d:%02d".format(s / 60, s % 60)

fun messageImages(m: Message): List<String> =
    if (m.images.isNotEmpty()) m.images else if (m.imageUrl.isNotEmpty()) listOf(m.imageUrl) else emptyList()

/** Silinmiş ya da artık erişilemeyen resim / belge iletilemez: uyarı verir, iletilebilenleri döndürür */
fun fwdCheck(ctx: android.content.Context, msgs: List<Message>): List<Message> {
    val ok = msgs.filter { m ->
        !(m.deleted || (m.type == "image" && messageImages(m).isEmpty()) || (m.type == "document" && m.imageUrl.isEmpty()))
    }
    if (ok.size < msgs.size) {
        val doc = msgs.any { it.type == "document" && !ok.contains(it) }
        val img = msgs.any { it.type == "image" && !ok.contains(it) }
        val what = if (doc && !img) "belge" else if (img && !doc) "resim" else "mesaj"
        android.widget.Toast.makeText(ctx, "Silinen $what iletilemez", android.widget.Toast.LENGTH_SHORT).show()
    }
    return ok
}

val LocalBubbleLong = androidx.compose.runtime.compositionLocalOf<() -> Unit> { {} }

/** Mesaj içindeki dokunulabilir alanlar (resim, belge…) basılı tutmayı da baloncuğa iletir */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.tapLong(onClick: () -> Unit): Modifier = this.combinedClickable(onClick = onClick, onLongClick = LocalBubbleLong.current)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(
    m: Message,
    me: String,
    isGroup: Boolean,
    starred: Boolean,
    selected: Boolean,
    flash: Boolean = false,
    flashColor: Color = auraLc(0xFF22C55E),
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onQuoteClick: (String) -> Unit,
    quoteImage: String = "",
    onOpenImages: (List<String>, Int) -> Unit,
    onOpenDocument: (Message) -> Unit,
    onOpenLocation: (Message) -> Unit,
    mineColor: Color = AuraMine,
    theirColor: Color = AuraTheirs,
    viewOnceSeen: Boolean = false,
    onOpenViewOnce: (Message) -> Unit = {},
    onVote: (Message, String) -> Unit = { _, _ -> },
    groupAvatar: Boolean = false,
    groupSpace: Boolean = false,
    onAvatarClick: () -> Unit = {},
    onForward: (() -> Unit)? = null,
    onReactionsClick: () -> Unit = {},
    onCallClick: (Message) -> Unit = {},
    leftAlign: Boolean = false,
    swipeFade: () -> Float = { 0f },
    tail: Boolean = true,
    topGap: androidx.compose.ui.unit.Dp = 10.7.dp,
    joinAbove: Boolean = false,
    joinBelow: Boolean = false
) {
    val deepB = m.senderUid == me && AuraUi.light && mineColor.luminance() < 0.45f
    androidx.compose.runtime.CompositionLocalProvider(LocalDeepBubble provides deepB) {
    DeepBubbleScope(if (m.senderUid == me) mineColor else Color.White) {
    androidx.compose.runtime.CompositionLocalProvider(LocalBubbleLong provides onLongClick) {
        MessageBubbleInner(m = m, me = me, isGroup = isGroup, starred = starred, selected = selected, flash = flash, flashColor = flashColor, onClick = onClick, onLongClick = onLongClick, onQuoteClick = onQuoteClick, quoteImage = quoteImage, onOpenImages = onOpenImages, onOpenDocument = onOpenDocument, onOpenLocation = onOpenLocation, mineColor = mineColor, theirColor = theirColor, viewOnceSeen = viewOnceSeen, onOpenViewOnce = onOpenViewOnce, onVote = onVote, groupAvatar = groupAvatar, groupSpace = groupSpace, onAvatarClick = onAvatarClick, onForward = onForward, onReactionsClick = onReactionsClick, onCallClick = onCallClick, leftAlign = leftAlign, swipeFade = swipeFade, tail = tail, topGap = topGap, joinAbove = joinAbove, joinBelow = joinBelow)
    }
    }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubbleInner(
    m: Message,
    me: String,
    isGroup: Boolean,
    starred: Boolean,
    selected: Boolean,
    flash: Boolean = false,
    flashColor: Color = auraLc(0xFF22C55E),
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onQuoteClick: (String) -> Unit,
    quoteImage: String = "",
    onOpenImages: (List<String>, Int) -> Unit,
    onOpenDocument: (Message) -> Unit,
    onOpenLocation: (Message) -> Unit,
    mineColor: Color = AuraMine,
    theirColor: Color = AuraTheirs,
    viewOnceSeen: Boolean = false,
    onOpenViewOnce: (Message) -> Unit = {},
    onVote: (Message, String) -> Unit = { _, _ -> },
    groupAvatar: Boolean = false,
    groupSpace: Boolean = false,
    onAvatarClick: () -> Unit = {},
    onForward: (() -> Unit)? = null,
    onReactionsClick: () -> Unit = {},
    onCallClick: (Message) -> Unit = {},
    leftAlign: Boolean = false,
    swipeFade: () -> Float = { 0f },
    tail: Boolean = true,
    topGap: androidx.compose.ui.unit.Dp = 10.7.dp,
    joinAbove: Boolean = false,
    joinBelow: Boolean = false
) {
    if (m.type == "system") {
        // gönderenin adı değişince sohbetteki uyarıda da canlı güncellenir ("X görüntülü grup araması başlattı" vb.)
        val lpSys by liveProfile(if (m.senderUid.isNotBlank() && m.senderName.isNotBlank()) m.senderUid else "")
        val mUids = if (m.type == "system") m.mentions else emptyList()
        val mp0 by liveProfile(mUids.getOrNull(0) ?: "")
        val mp1 by liveProfile(mUids.getOrNull(1) ?: "")
        val mp2 by liveProfile(mUids.getOrNull(2) ?: "")
        var shownText = lpSys?.name?.takeIf { it.isNotBlank() && m.senderName.isNotBlank() && it != m.senderName }?.let { m.text.replace(m.senderName, it) } ?: m.text
        listOf(mp0, mp1, mp2).forEachIndexed { i, pr ->
            val old = m.mentionNames.getOrNull(i) ?: ""
            val nn = pr?.name ?: ""
            if (old.isNotBlank() && nn.isNotBlank() && nn != old) shownText = shownText.replace(old, nn)
        }
        val timerLine = m.text.contains("süreli mesaj")
        val themeLine = m.text.contains("sohbet temasını herkes için") || m.text.contains("Sohbet temasını herkes için")
        // tüm bilgilendirme uyarıları aynı kart stilinde
        val blockLine = true
        if (blockLine) {
            // WhatsApp ölçüsü: kart köşe 8dp, yazı 14.5sp, iç boşluk 11dp yatay / 5dp dikey, kartlar arası ~12dp, yanlardan ~40dp
            // balon kapsamından (forceDark) etkilenmesin diye gerçek tema durumuna göre sabit renkler
            val blkLight = AuraUi.lightReal
            Box(Modifier.fillMaxWidth().padding(start = 38.dp, end = 38.dp, top = 12.dp), contentAlignment = Alignment.Center) {
                Text(
                    if (timerLine) androidx.compose.ui.text.buildAnnotatedString { appendInlineContent("tm", "⏱"); append("  " + shownText) } else if (themeLine && shownText.endsWith("Değiştir")) androidx.compose.ui.text.buildAnnotatedString {
                        append(shownText.removeSuffix("Değiştir"))
                        pushStyle(androidx.compose.ui.text.SpanStyle(fontWeight = FontWeight.SemiBold)); append("Değiştir"); pop()
                    } else androidx.compose.ui.text.AnnotatedString(shownText),
                    inlineContent = if (timerLine) mapOf("tm" to androidx.compose.foundation.text.InlineTextContent(
                        androidx.compose.ui.text.Placeholder(15.sp, 15.sp, androidx.compose.ui.text.PlaceholderVerticalAlign.TextCenter)
                    ) { DisappearBadge(15.dp, if (blkLight) Color(0xFF667781) else Color(0xFF9AA5AB), Color.Transparent) }) else mapOf(),
                    color = if (blkLight) Color(0xFF667781) else Color(0xFF9AA5AB),
                    fontSize = 13.25.sp,
                    lineHeight = 17.75.sp,
                    letterSpacing = 0.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp))
                        .background(if (blkLight) Color(0xFFFDFCFB) else Color(0xFF1B1F21))
                        .then(if (blkLight) Modifier.border(hairline(), Color(0x24000000), RoundedCornerShape(8.dp)) else Modifier)
                        .clickable(onClick = onClick)
                        .padding(horizontal = 7.5.dp, vertical = 4.3.dp)
                )
            }
            return
        }
        Box(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
            Text(
                m.text,
                color = bMuted(),
                fontSize = 13.25.sp,
                lineHeight = 17.75.sp,
                letterSpacing = 0.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(bLc(0xFF1B1F21)).padding(horizontal = 7.5.dp, vertical = 4.3.dp)
            )
        }
        return
    }

    val mine = m.senderUid == me
    val alignEnd = mine && !leftAlign
    // WhatsApp gibi: balon ekran genişliğinin yaklaşık %81'ine kadar uzar
    val maxBubble = (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp * 0.81f).dp
    val bubbleColor = if (mine) mineColor else theirColor
    val bubbleShape = RoundedCornerShape(
        topStart = if (tail && !alignEnd) 0.dp else 10.dp, topEnd = if (tail && alignEnd) 0.dp else 10.dp,
        bottomStart = 10.dp, bottomEnd = 10.dp
    )
    val flashA by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (flash) 0.45f else 0f,
        animationSpec = androidx.compose.animation.core.tween(if (flash) 150 else 1400, easing = androidx.compose.animation.core.LinearEasing),
        label = "flash"
    )
    // WhatsApp ölçüsü: seçili bant balonun VE yazının üstüne, vurgu renginde %30 saydam çizilir (ölçüldü: 0.70×alttaki + 0.30×vurgu)
    val highlight = if (selected) flashColor.copy(alpha = 0.30f) else if (flashA > 0.001f) flashColor.copy(alpha = flashA) else Color.Transparent

    Row(
        Modifier
            .fillMaxWidth()
            // işaretleme bandı WhatsApp gibi balonun tam üstü/altından ~1.2dp taşar (aralığın yarısı); boşluğun tamamını boyamaz
            .drawWithContent {
                drawContent()
                if (highlight.alpha > 0f) {
                    val m = 1.2.dp.toPx()
                    // üstteki mesaj da seçiliyse boşluk dahil tamamen boya (kesintisiz bant); altta seçili varsa taşma yok (alttaki öğe kendi boşluğunu boyar)
                    val top = if (joinAbove) 0f else topGap.toPx() - m
                    val bottomExtra = if (joinBelow) 0f else m
                    drawRect(highlight, androidx.compose.ui.geometry.Offset(0f, top), androidx.compose.ui.geometry.Size(size.width, size.height - top + bottomExtra))
                }
            }
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(start = if (isGroup && !mine && (groupAvatar || groupSpace)) 9.dp else 14.dp, end = 14.dp, top = topGap, bottom = 0.dp),
        horizontalArrangement = if (mine && !leftAlign) Arrangement.End else Arrangement.Start
    ) {
        val sp by liveProfile(if (isGroup && !mine) m.senderUid else "")
        if (isGroup && !mine && (groupAvatar || groupSpace)) {
            if (groupAvatar) {
                val nm = (sp?.name?.takeIf { it.isNotBlank() } ?: m.senderName).ifBlank { "?" }
                Box(Modifier.size(28.dp).clip(CircleShape).clickable(onClick = onAvatarClick)) {
                    Avatar(nm, sp?.avatar ?: "", 28.dp)
                }
            } else Spacer(Modifier.width(28.dp))
            Spacer(Modifier.width(6.dp))
        }
val canFwd = onForward != null && !m.deleted && !m.viewOnce && (m.type == "image" || m.type == "document" || m.type == "video" || (m.type == "text" && Regex("(https?://|www\\.)", RegexOption.IGNORE_CASE).containsMatchIn(m.text)))
        if (canFwd && mine && !leftAlign) FwdBtn(swipeFade, onForward!!)
        // WhatsApp ölçüsü: bağlantı kartı / alıntı olan balonda kart kenardan ~3.5dp içeride (ölçülen 10px), yazı ve saat ek 5.5dp içeriden başlar
        val tightPad = !m.deleted && m.type == "text" && (m.linkPreview != null || m.replyTo != null)
        val tIn = if (tightPad) Modifier.padding(start = 5.5.dp, end = 5.5.dp) else Modifier
                Column(horizontalAlignment = if (mine && !leftAlign) Alignment.End else Alignment.Start) {
            Column(
                Modifier
                    .widthIn(max = if (m.type == "audio" && !m.viewOnce) maxBubble + 8.dp else maxBubble)
                    .then(if ((m.linkPreview?.image?.isNotBlank() == true || isOwnLink(m.linkPreview?.url ?: "")) && !m.deleted) Modifier.width(minOf(maxBubble, linkCardWidth(m.linkPreview!!.image, m.linkPreview!!.url))) else Modifier)
                    .then(if (m.replyTo != null && !m.deleted) Modifier.width(IntrinsicSize.Max) else Modifier)
                    .drawBehind {
                        if (tail) {
                            val tw = 8.dp.toPx(); val th = 11.dp.toPx()
                            val path = androidx.compose.ui.graphics.Path()
                            if (alignEnd) { path.moveTo(size.width, 0f); path.lineTo(size.width + tw, 0f); path.lineTo(size.width, th) }
                            else { path.moveTo(0f, 0f); path.lineTo(-tw, 0f); path.lineTo(0f, th) }
                            path.close()
                            drawPath(path, bubbleColor)
                        }
                    }
                    .clip(bubbleShape)
                    .background(bubbleColor)
                    .then(if (!mine && AuraUi.lightReal && bubbleColor.luminance() > 0.9f) Modifier.border(hairline(), Color(0x24000000), bubbleShape) else Modifier)
                    .then(if (tightPad) Modifier.padding(3.5.dp) else if ((m.type == "image" || m.type == "video") && !m.deleted && !m.viewOnce) Modifier.padding(4.dp) else if (m.type == "call" || m.type == "missed_call" || m.type == "declined_call" || m.type == "call_duration") Modifier.padding(4.dp) else if (m.type == "contact" && !m.deleted) Modifier else Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
            ) {
                if (isGroup && !mine && m.senderName.isNotBlank() && !m.deleted) {
                    val sName = sp?.name?.takeIf { it.isNotBlank() } ?: m.senderName
                    val sPhone = sp?.phone ?: ""
                    val devKeys = DevKeys.set
                    // WhatsApp gibi: rehberde olmayan kişide "~ isim" solda, numara sağda; rehberdeyse yalnız isim
                    val unknown = devKeys != null && sPhone.isNotBlank() && phoneKey(sPhone) !in devKeys
                    if (unknown) {
                        Row(
                            (if (tightPad) Modifier.padding(start = 5.5.dp, end = 5.5.dp, top = 2.5.dp) else Modifier).width(androidx.compose.foundation.layout.IntrinsicSize.Max),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("~ $sName", color = senderColor(m.senderUid, m.senderName), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                            Spacer(Modifier.weight(1f).widthIn(min = 14.dp))
                            Text(prettyPhoneNo(sPhone), color = bMuted(), fontSize = 11.sp, maxLines = 1, softWrap = false)
                        }
                    } else Text(
                        sName,
                        color = senderColor(m.senderUid, m.senderName), fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                        modifier = if (tightPad) Modifier.padding(start = 5.5.dp, end = 5.5.dp, top = 2.5.dp) else Modifier
                    )
                }
                if (m.forwarded && !m.deleted) {
                    Text("↪ İletildi", color = if (bubbleColor.luminance() > 0.5f) androidx.compose.ui.graphics.lerp(bubbleColor, Color.Black, 0.55f) else bMuted(), fontSize = 11.sp, fontStyle = FontStyle.Italic, modifier = if (tightPad) Modifier.padding(start = 5.5.dp, end = 5.5.dp, top = 2.5.dp) else Modifier)
                }
                val rq = m.replyTo
                if (rq != null && !m.deleted) {
                    val qc0 = if (isGroup && rq.senderUid.isNotEmpty()) senderColor(rq.senderUid, rq.senderName, 78) else flashColor
                    // WhatsApp gibi: koyu temada ad ve çizgi açık tonda
                    val qDark = bubbleColor.luminance() < 0.45f
                    val qc = if (!qDark) qc0 else androidx.compose.ui.graphics.lerp(qc0, Color.White, 0.5f)
                    // birebirde WhatsApp ölçüsü: çubuk ve ad rengi temanın tonundan (açıkta koyu yeşil, koyuda canlı yeşil / açık nane)
                    val qGroup = isGroup && rq.senderUid.isNotEmpty()
                    val qWhite = mine && whiteQuote(bubbleColor)
                    val qBar = if (qGroup) qc else if (qWhite) Color.White else flashColor
                    val qName = if (qGroup) qc else if (qWhite) Color.White else if (mine) flashColor else quoteTone(flashColor, qDark, false)
                    val stBody = if (rq.isStatus) rq.previewText.removePrefix("Durum:").trim() else rq.previewText
                    val qPhoto = rq.previewText.startsWith("\uD83D\uDCF7") || (rq.isStatus && stBody == "Fotoğraf")
                    val rqLive = liveProfile(rq.senderUid).value?.name?.takeIf { it.isNotBlank() }
                    // durum yanıtı: "Ad • Durum", altında Fotoğraf / Video (0:20) / yazı, sağda durumun küçük resmi
                    val stThumb = if (rq.isStatus) produceState(Repo.peekStatusMedia(rq.msgId) ?: "", rq.msgId) {
                        value = try { Repo.loadStatusMedia(rq.msgId) } catch (e: Throwable) { value }
                    }.value else quoteImage
                    val qNameFull = (if (rq.senderUid == me) "Siz" else (rqLive ?: rq.senderName)).let { if (rq.isStatus) "$it • Durum" else it }
                    QuoteCard(
                        qNameFull, qName, qBar,
                        if (rq.previewText.startsWith("\uD83D\uDCF7")) rq.previewText.removePrefix("\uD83D\uDCF7").trim() else stBody, qPhoto, stThumb,
                        innerBg(bubbleColor), 10.dp, 14.2f, if (rq.isStatus) 52.dp else 40.dp,
                        Modifier.padding(vertical = 2.dp).tapLong { onQuoteClick(rq.msgId) }, textColor = if (qDark) bLc(0xFFD0D5D8) else Color(0xFF3B4650)
                    )
                }

                val singleImgOverlay = m.type == "image" && !m.viewOnce && !m.deleted && m.text.isBlank() &&
                    messageImages(m).size == 1 && maxOf(m.imagesCount, m.images.size, 1) <= 1
                val noTick = m.type == "call" || m.type == "missed_call" || m.type == "declined_call" || m.type == "call_duration" || m.type == "deleted"
                val inlineMeta = m.type == "text" && !m.deleted && m.linkPreview == null
                val metaContent: @Composable () -> Unit = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = m.pinned,
                        enter = androidx.compose.animation.scaleIn(androidx.compose.animation.core.spring(0.45f, 400f)) + androidx.compose.animation.expandHorizontally() + androidx.compose.animation.fadeIn(),
                        exit = androidx.compose.animation.scaleOut() + androidx.compose.animation.shrinkHorizontally() + androidx.compose.animation.fadeOut()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PushPin, null, tint = bMuted(), modifier = Modifier.size(11.dp))
                            Spacer(Modifier.width(3.dp))
                        }
                    }
                    // WhatsApp gibi: yıldız eklenirken zıplayarak belirir
                    androidx.compose.animation.AnimatedVisibility(
                        visible = starred,
                        enter = androidx.compose.animation.scaleIn(androidx.compose.animation.core.spring(0.35f, 350f), initialScale = 0.2f) + androidx.compose.animation.expandHorizontally() + androidx.compose.animation.fadeIn(),
                        exit = androidx.compose.animation.scaleOut() + androidx.compose.animation.shrinkHorizontally() + androidx.compose.animation.fadeOut()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, null, tint = bMuted(), modifier = Modifier.size(11.dp))
                            Spacer(Modifier.width(3.dp))
                        }
                    }
                    if (m.edited && !m.deleted) {
                        Text("düzenlendi · ", color = bWhite(), fontSize = 12.sp, lineHeight = 14.sp, letterSpacing = 0.sp)
                    }
                    Text(formatClock(m.time), color = bLc(0xB3FFFFFF), fontSize = 12.sp, lineHeight = 14.sp, letterSpacing = 0.sp)
                    if (mine && !m.deleted && !noTick) {
                        Spacer(Modifier.width(4.dp))
                        val seen = if (isGroup) m.readBy.any { it != me } else m.read
                        when {
                            m.pending -> Icon(Icons.Default.Schedule, null, tint = bMuted(), modifier = Modifier.size(15.dp))
                            seen -> Icon(Icons.Default.DoneAll, null, tint = bTick(), modifier = Modifier.size(16.dp))
                            else -> Icon(Icons.Default.DoneAll, null, tint = bLc(0xFF9CA3AF), modifier = Modifier.size(16.dp))
                        }
                    }
                    }
                }
                if (m.deleted || m.type == "deleted") {
                    Row(verticalAlignment = Alignment.Bottom) {
                        // WhatsApp ölçüsü: simge 24dp kutuda (20dp çizim), satır yüksekliğini büyütmez; çizim yazının büyük harf ortasına hizalı
                        Box(Modifier.width(24.dp).height(19.dp).offset(y = (-6.3).dp), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Block, null, tint = bMuted(), modifier = Modifier.requiredSize(24.dp))
                        }
                        Spacer(Modifier.width(5.dp))
                        Text(if (mine) "Bu mesajı sildiniz" else "Bu mesaj silindi", color = bMuted(), fontSize = 16.sp, fontStyle = FontStyle.Italic)
                        Spacer(Modifier.width(12.dp))
                        Box(Modifier.offset(y = 3.5.dp)) { metaContent() }
                    }
                } else when (m.type) {
                    "image" -> if (m.viewOnce) ViewOnceRow(m, mine, viewOnceSeen, onOpenViewOnce) else if (singleImgOverlay) {
                        Box {
                            ImageBlock(m, onOpenImages)
                            Box(
                                Modifier.align(Alignment.BottomEnd).padding(6.dp).clip(RoundedCornerShape(10.dp))
                                    .background(Color(0x66000000)).padding(horizontal = 6.dp, vertical = 2.dp)
                            ) { androidx.compose.runtime.CompositionLocalProvider(LocalDeepBubble provides true) { metaContent() } }
                        }
                    } else ImageBlock(m, onOpenImages)
                    "audio" -> if (m.viewOnce) AudioOnceRow(m, mine, viewOnceSeen, onOpenViewOnce) else AudioRow(m, bubbleColor, metaContent)
                    "location" -> LocationBlock(m, onOpenLocation)
                    "document" -> DocumentBlock(m, onOpenDocument)
                    "video" -> VideoBlock(m, onOpenDocument)
                    "call", "missed_call", "declined_call", "call_duration" -> CallCard(m, mine, onCallClick, metaContent, bubbleColor)
                    "poll" -> PollBlock(m, me, onVote)
                    "contact" -> ContactBlock(m, metaContent)
                    else -> if (inlineMeta) {
                        val full = mentionText(m, me, if (mine && whiteQuote(bubbleColor)) Color.White else flashColor, SearchHl.q, if (bubbleColor.luminance() > 0.5f) Color.Black else Color.White, flashColor, mentionTick(m))
                        val raw = full.text
                        val tooLong = raw.length > 700
                        if (tooLong && ReadMore.open[m.id] != true) {
                            val cut = raw.take(700).let { t -> val sp = t.lastIndexOfAny(charArrayOf(' ', '\n')); if (sp > 500) sp else t.length }
                            val shown = androidx.compose.ui.text.buildAnnotatedString {
                                append(full.subSequence(0, cut).let { it.subSequence(0, it.text.trimEnd().length) })
                                append("…")
                            }
                            Column {
                                var shl by remember(shown) { mutableStateOf<androidx.compose.ui.text.TextLayoutResult?>(null) }
                                Text(shown, color = bLc(0xFFF3F4F6), style = BubbleText, onTextLayout = { shl = it }, modifier = Modifier.phoneTap(shown) { shl })
                                // "Devamını okuyun" solda, saat/tik aynı satırın sağında (WhatsApp)
                                Row(Modifier.fillMaxWidth().padding(top = 2.dp), verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        "Devamını okuyun", color = bWhite(), fontSize = 12.5.sp, fontWeight = FontWeight.Medium,
                                        modifier = Modifier.clip(RoundedCornerShape(50)).background(bLc(0x47000000))
                                            .clickable { ReadMore.open[m.id] = true }.padding(horizontal = 12.dp, vertical = 3.dp)
                                    )
                                    Spacer(Modifier.weight(1f).widthIn(min = 12.dp))
                                    metaContent()
                                }
                            }
                        } else if (tightPad) Box(Modifier.fillMaxWidth().padding(start = 5.5.dp, end = 5.5.dp, bottom = 2.5.dp)) { InlineTimeLayout(full, metaContent, fill = true) }
                        else InlineTimeLayout(full, metaContent, fill = m.replyTo != null)
                    } else Column {
                        m.linkPreview?.let { LinkCard(it, innerBg(bubbleColor), if (tightPad) 0.dp else 6.dp) }
                        if (m.text.isNotBlank()) {
                            val mt = mentionText(m, me, if (mine && whiteQuote(bubbleColor)) Color.White else flashColor, SearchHl.q, if (bubbleColor.luminance() > 0.5f) Color.Black else Color.White, flashColor, mentionTick(m))
                            var mtl by remember(mt) { mutableStateOf<androidx.compose.ui.text.TextLayoutResult?>(null) }
                            Text(mt, color = bLc(0xFFF3F4F6), style = BubbleText, onTextLayout = { mtl = it }, modifier = (if (tightPad) Modifier.padding(start = 5.5.dp, end = 5.5.dp) else Modifier).padding(top = if (m.linkPreview != null) 6.dp else 0.dp).phoneTap(mt) { mtl })
                        }
                    }
                }
                val captionMeta = m.type == "image" && m.text.isNotBlank() && !m.deleted
                if (captionMeta) {
                    // Altyazı ve saat/tik aynı satırda (WhatsApp): saat sağ altta durur, altta fazladan boşluk kalmaz
                    Box(Modifier.width(260.dp).padding(top = 4.dp, start = 6.dp, end = 2.dp)) {
                        InlineTimeLayout(androidx.compose.ui.text.AnnotatedString(m.text), metaContent, fill = true)
                    }
                }

                val callMeta = m.type == "call" || m.type == "missed_call" || m.type == "declined_call" || m.type == "call_duration"
                if (!inlineMeta && !captionMeta && !callMeta && !singleImgOverlay && !(m.type == "audio" && !m.viewOnce) && !(m.deleted || m.type == "deleted")) Box(Modifier.align(Alignment.End).then(if (tightPad) Modifier.padding(end = 5.5.dp, bottom = 2.5.dp) else Modifier).padding(top = 2.dp)) { metaContent() }
            }
            if (m.reactions.isNotEmpty() && !m.deleted) {
                val grouped = m.reactions.values.groupingBy { it }.eachCount()
                val rLight = AuraUi.lightReal
                val pill = RoundedCornerShape(50)
                Row(
                    Modifier
                        .padding(top = 2.dp)
                        .clip(pill)
                        .background(if (rLight) Color.White else bLc(0xFF1B1F21))
                        .then(if (rLight) Modifier.border(hairline(), Color(0x1F000000), pill) else Modifier)
                        .clickable(onClick = onReactionsClick)
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    grouped.keys.forEach { emoji -> Text(emoji, fontSize = 14.sp) }
                    if (m.reactions.size > 1) Text("${m.reactions.size}", fontSize = 13.sp, color = if (rLight) Color(0xFF667781) else bWhite(), modifier = Modifier.padding(start = 2.dp))
                }
            }
        }
        if (canFwd && (!mine || leftAlign)) FwdBtn(swipeFade, onForward!!)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ImageBlock(m: Message, onOpen: (List<String>, Int) -> Unit) {
    val imgs = messageImages(m)
    val total = maxOf(m.imagesCount, m.images.size, imgs.size)
    if (imgs.isEmpty() && total <= 1) {
        BlurThumb(m.thumb, Modifier.size(260.dp).clip(RoundedCornerShape(10.dp)))
        return
    }
    if (imgs.size == 1 && total <= 1) {
        // WhatsApp gibi: dikey resim uzun (en fazla 1,4 kat), yatay resim kısa görünür
        val bmp by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(Media.peek(imgs[0], 720), imgs[0]) {
            value = withContext(Dispatchers.Default) { Media.decode(imgs[0], 720) }
        }
        val ratio = bmp?.let { (it.height.toFloat() / it.width.toFloat()).coerceIn(0.7f, 1.4f) } ?: 1f
        DataUrlImage(
            imgs[0], 720,
            Modifier.size(260.dp, (260f * ratio).dp).clip(RoundedCornerShape(10.dp)).tapLong { onOpen(imgs, 0) },
            ContentScale.Crop
        )
        return
    }
    val slots = minOf(total, 4)
    val extra = total - slots
    // 2 resim (WhatsApp gibi): hücre genişliği sabit (135dp), yüksekliği resimlerin ortalama en/boy oranına göre; dikey resimde uzun (en fazla ~2 kat), yatayda kare
    val two = slots == 2
    fun avgAspect(l: List<String>): Float {
        val a = l.take(2).mapNotNull { d -> Media.peek(d, 360)?.let { it.width.toFloat() / it.height.toFloat() } }
        return if (a.isEmpty()) 1f else (a.sum() / a.size).coerceIn(0.49f, 1f)
    }
    val aspect by androidx.compose.runtime.produceState(if (two) avgAspect(imgs) else 1f, imgs, two) {
        if (two) value = withContext(Dispatchers.Default) {
            val a = imgs.take(2).mapNotNull { d -> Media.decode(d, 360)?.let { it.width.toFloat() / it.height.toFloat() } }
            if (a.isEmpty()) 1f else (a.sum() / a.size).coerceIn(0.49f, 1f)
        }
    }
    val cellW = if (two) 135.dp else 129.dp
    val cellH = if (two) (135f / aspect).dp else 129.dp
    // 3 resim (WhatsApp gibi): ilk resim dikeyse solda uzun (135x275), sağda iki kare (135x135); yataysa üstte geniş, altta iki kare
    if (slots == 3) {
        val firstA by androidx.compose.runtime.produceState(
            imgs.firstOrNull()?.let { d -> Media.peek(d, 360)?.let { it.width.toFloat() / it.height.toFloat() } } ?: 1.5f, imgs.firstOrNull()
        ) {
            val d = imgs.firstOrNull()
            if (d != null) value = withContext(Dispatchers.Default) { Media.decode(d, 360)?.let { it.width.toFloat() / it.height.toFloat() } } ?: value
        }
        @Composable
        fun Cell3(idx: Int, w: androidx.compose.ui.unit.Dp, h: androidx.compose.ui.unit.Dp) {
            val img = imgs.getOrNull(idx)
            Box(Modifier.size(w, h).clip(RoundedCornerShape(6.dp)).tapLong { if (img != null) onOpen(imgs, idx) }) {
                if (img != null) DataUrlImage(img, 480, Modifier.size(w, h), ContentScale.Crop)
                else BlurThumb(m.thumbs.getOrNull(idx) ?: "", Modifier.size(w, h))
            }
        }
        if (firstA < 1f) {
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Cell3(0, 135.dp, 275.dp)
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Cell3(1, 135.dp, 135.dp)
                    Cell3(2, 135.dp, 135.dp)
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Cell3(0, 275.dp, 137.dp)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Cell3(1, 135.dp, 135.dp)
                    Cell3(2, 135.dp, 135.dp)
                }
            }
        }
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        // 3 resim: üstte tek geniş, altta iki resim (kare boşluk kalmaz); 2 ve 4 resim: ikişerli
        val rows: List<List<Int>> = if (slots == 3) listOf(listOf(0), listOf(1, 2)) else (0 until slots).toList().chunked(2)
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(if (two) 5.dp else 2.dp)) {
                row.forEach { idx ->
                    val wide = row.size == 1 && slots == 3
                    val bw = if (wide) 260.dp else cellW
                    val bh = cellH
                    val img = imgs.getOrNull(idx)
                    Box(Modifier.size(bw, bh).clip(RoundedCornerShape(6.dp)).tapLong { if (img != null) onOpen(imgs, idx) }) {
                        if (img != null) DataUrlImage(img, if (wide || two) 480 else 360, Modifier.size(bw, bh), ContentScale.Crop)
                        else BlurThumb(m.thumbs.getOrNull(idx) ?: "", Modifier.size(bw, bh))
                        if (idx == 3 && extra > 0) {
                            Box(Modifier.size(129.dp).background(bLc(0x99000000)), contentAlignment = Alignment.Center) {
                                Text("+$extra", color = bWhite(), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Mesajdaki @İsim parçalarını mavi, bağlantıları alıntı çubuğu renginde vurgular */
private val PhoneRegex = Regex("(?<![\\w+])\\+?\\(?\\d[\\d ().\\-]{8,}\\d(?!\\w)")
private val UrlRegex = Regex("(https?://|www\\.)[^\\s]+", RegexOption.IGNORE_CASE)
/** Sohbette arama açıkken aranan metin: baloncuklarda eşleşen harfler boyanır */
object SearchHl { var q by androidx.compose.runtime.mutableStateOf("") }

/** @etiketlenen kişilerin adı değişince balondaki etiket de güncellensin: profilleri dinler, değişimde yeniden çizdirir */
@Composable
private fun mentionTick(m: Message): String {
    if (m.type != "text" || m.mentions.isEmpty()) return ""
    val a by liveProfile(m.mentions.getOrNull(0) ?: "")
    val b by liveProfile(m.mentions.getOrNull(1) ?: "")
    val c by liveProfile(m.mentions.getOrNull(2) ?: "")
    return (a?.name ?: "") + "|" + (b?.name ?: "") + "|" + (c?.name ?: "")
}

private fun mentionText(m: Message, me: String, linkColor: Color = Color.Unspecified, hl: String = "", hlInk: Color = Color.White, hlBg: Color = Color.Unspecified, tick: String = ""): androidx.compose.ui.text.AnnotatedString {
    if (m.type != "text") return androidx.compose.ui.text.AnnotatedString(m.text)
    val mine = m.mentions.contains(me)
    // etiketlerdeki eski adları güncel adlarla değiştir
    var txt = m.text
    val mNames = m.mentionNames.mapIndexed { i, old ->
        val nn = m.mentions.getOrNull(i)?.let { u -> com.aurachat.app.data.Repo.peekProfile(u)?.name }?.takeIf { it.isNotBlank() }
        if (nn != null && nn != old && txt.contains("@$old")) { txt = txt.replace("@$old", "@$nn"); nn } else old
    }
    return androidx.compose.ui.text.buildAnnotatedString {
        append(txt)
        if (linkColor != Color.Unspecified) {
            val ul = androidx.compose.ui.text.style.TextDecoration.Underline
            val urlRanges = UrlRegex.findAll(txt).map { it.range }.toList()
            UrlRegex.findAll(txt).forEach { um ->
                val r = um.range
                addStyle(androidx.compose.ui.text.SpanStyle(color = linkColor, textDecoration = ul), r.first, r.last + 1)
                val u = um.value.trimEnd('.', ',', ';', ':', '!', '?', ')', '"', '\'')
                addStringAnnotation("url", if (u.startsWith("www.", true)) "https://$u" else u, r.first, r.last + 1)
            }
            // WhatsApp gibi: telefon numaraları da bağlantı rengiyle ve altı çizili
            PhoneRegex.findAll(txt).forEach { r ->
                val digits = r.value.count { it.isDigit() }
                if (digits in 10..15 && urlRanges.none { u -> r.range.first <= u.last && r.range.last >= u.first }) {
                    addStyle(androidx.compose.ui.text.SpanStyle(color = linkColor, textDecoration = ul), r.range.first, r.range.last + 1)
                    addStringAnnotation("phone", r.value.trim(), r.range.first, r.range.last + 1)
                }
            }
        }
        mNames.forEach { name ->
            val tok = "@$name"
            var from = 0
            while (true) {
                val i = txt.indexOf(tok, from)
                if (i < 0) break
                addStyle(
                    androidx.compose.ui.text.SpanStyle(
                        color = auraLc(0xFF53BDEB), fontWeight = FontWeight.SemiBold,
                        background = if (mine) auraLc(0x2E53BDEB) else Color.Unspecified
                    ), i, i + tok.length
                )
                from = i + tok.length
            }
        }
        if (hl.isNotEmpty()) {
            var from = 0
            while (true) {
                val i = txt.indexOf(hl, from, ignoreCase = true)
                if (i < 0) break
                addStyle(
                    androidx.compose.ui.text.SpanStyle(color = hlInk, fontWeight = FontWeight.Bold, background = if (hlBg == Color.Unspecified) Color.Unspecified else hlBg.copy(alpha = 0.45f)),
                    i, i + hl.length
                )
                from = i + hl.length
            }
        }
    }
}

/** WhatsApp gibi: dikey/kare resimde dar (215dp), yatay geniş resimde geniş (295dp) kart */
@Composable
private fun isTallLink(url: String): Boolean {
    val u = try { android.net.Uri.parse(url) } catch (e: Throwable) { return false }
    val h = u.host?.lowercase() ?: ""
    return h.contains("tiktok") || h.contains("facebook") || h.endsWith("fb.watch") || h.endsWith("fb.com") || h.endsWith("fb.me") || h.contains("instagram") ||
        ((h.contains("youtube") || h == "youtu.be") && (u.path ?: "").startsWith("/shorts"))
}

/** TikTok / YouTube / Facebook / Instagram / Vimeo / Twitch gibi video bağlantıları */
private fun isVideoLink(url: String): Boolean {
    val h = try { android.net.Uri.parse(url).host?.lowercase() ?: "" } catch (e: Throwable) { "" }
    return h.contains("tiktok") || h.contains("youtu") || h.contains("vimeo") || h.contains("instagram") || h.contains("facebook") || h.contains("fb.watch") || h.contains("fb.com") || h.contains("fb.me") || h.contains("twitch")
}

@Composable
private fun linkCardWidth(image: String, url: String = ""): androidx.compose.ui.unit.Dp {
    if (isTallLink(url) || isVideoLink(url) || (image.isBlank() && isOwnLink(url))) return 282.dp
    if (image.isBlank()) return 215.dp
    val appCtx = LocalContext.current.applicationContext
    val bmp by produceState<android.graphics.Bitmap?>(LinkImgCache.peek(image), image) {
        if (value == null) value = LinkImgCache.load(appCtx, image)
    }
    val b = bmp ?: return 215.dp
    val r = (b.width.toFloat() / b.height.toFloat())
    val t = ((r - 1.0f) / 0.6f).coerceIn(0f, 1f)
    return (215f + 80f * t).dp
}

/** Alıntı çubuğu / ad rengi (WhatsApp referansından): temanın tonu; açık balonda koyu, koyu balonda canlı. bar=true çubuk, false ad */
fun quoteTone(base: Color, dark: Boolean, bar: Boolean): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(base.toArgb(), hsv)
    val spec = when { !dark && bar -> 0.78f to 0.38f; !dark -> 0.58f to 0.19f; bar -> 0.77f to 0.73f; else -> 0.25f to 0.89f }
    val sat = spec.first.coerceAtMost(maxOf(hsv[1] * 1.05f, 0f))
    return Color(android.graphics.Color.HSVToColor(floatArrayOf(hsv[0], sat, spec.second)))
}

/** Alıntı ve bağlantı kartının iç zemini balon rengine göre: koyu balonda koyu yarı saydam, açık (beyaz) balonda hafif koyu gri; temadan bağımsız */
private fun innerBg(bubble: Color): Color =
    if (bubble.luminance() > 0.5f) Color(0x14000000) else Color(0x40000000)

/** Kendi profil/QR bağlantımız mı */
fun isOwnLink(url: String) = url.contains("aurachat-amber.vercel.app")

/** Kendi bağlantımızın küçük kapağı (iletme/paylaşma/giriş önizlemeleri): zemin simgenin açılmış rengi, ortada simge */
@Composable
fun OwnLinkThumb(modifier: Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val look = rememberOwnLook(ctx, true)
    val dom = look?.second ?: Color(0xFF2A3942)
    Box(modifier.background(androidx.compose.ui.graphics.lerp(dom, Color.White, 0.84f)), contentAlignment = Alignment.Center) {
        look?.first?.let { androidx.compose.foundation.Image(it, null, Modifier.fillMaxSize(0.62f).clip(RoundedCornerShape(10.dp))) }
    }
}

@Composable
private fun LinkCard(lp: com.aurachat.app.data.LinkPreview, cardBg: Color, topPad: androidx.compose.ui.unit.Dp = 6.dp) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val host = remember(lp.url) { try { android.net.Uri.parse(lp.url).host?.removePrefix("www.") ?: "" } catch (e: Throwable) { "" } }
    val isVideo0 = isVideoLink(lp.url)
    val own = lp.image.isBlank() && isOwnLink(lp.url)
    // kendi bağlantımız: simge, kapak olur; kart zemini ve yazı rengi simgenin baskın renginden otomatik türetilir
    val look = rememberOwnLook(ctx, own)
    Column(
        Modifier.padding(top = topPad).then(if (lp.image.isNotBlank() || own) Modifier.fillMaxWidth() else Modifier.widthIn(min = 200.dp)).clip(RoundedCornerShape(10.dp))
            .background(cardBg)
            .tapLong {
                try { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(lp.url))) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("MessageBubble", e) }
            }
    ) {
        if (own) {
            // WhatsApp ölçüsü: kare kapak; zemin simgenin açılmış rengi, ortada simge
            val dom = look?.second ?: Color(0xFF2A3942)
            val cover = androidx.compose.ui.graphics.lerp(dom, Color.White, 0.84f)
            // ölçüler kullanıcının işaretlediği ekran görüntüsünden (kare kapak = 1.0): simge 0.55, üstten 0.10; yazı kutusu üstten 0.76, yüksekliği 0.148, genişliği ~0.40
            androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(1f).background(cover)) {
                val w = maxWidth
                val icn = w * 0.55f
                look?.first?.let { androidx.compose.foundation.Image(it, null, Modifier.align(Alignment.TopCenter).offset(y = w * 0.10f).size(icn).clip(RoundedCornerShape(icn * 0.08f))) }
                val hsv = FloatArray(3)
                android.graphics.Color.colorToHSV(dom.toArgb(), hsv)
                val txtCol = Color(android.graphics.Color.HSVToColor(floatArrayOf(hsv[0], (hsv[1] * 0.9f).coerceAtMost(0.8f), 0.30f)))
                val fs = with(androidx.compose.ui.platform.LocalDensity.current) { (w.toPx() * 0.0926f).toSp() }
                Box(Modifier.align(Alignment.TopCenter).offset(y = w * 0.76f).height(w * 0.148f), contentAlignment = Alignment.Center) {
                    Text("AuraChat", color = txtCol, fontSize = fs, fontWeight = FontWeight.SemiBold, letterSpacing = 0.sp, maxLines = 1)
                }
            }
        }
        if (lp.image.isNotBlank()) {
            val isVideo = host.contains("tiktok") || host.contains("youtu") || host.contains("vimeo") || host.contains("instagram") || host.contains("facebook") || host.contains("fb.watch") || host.contains("twitch")
            val appCtx = LocalContext.current.applicationContext
            val bmp by produceState<android.graphics.Bitmap?>(LinkImgCache.peek(lp.image), lp.image) {
                if (value == null) value = LinkImgCache.load(appCtx, lp.image)
            }
            val bm = bmp
            // WhatsApp gibi: kapak, kendi oranında (dikey en fazla ~0.72, yatay en fazla ~1.91) kırpmadan gösterilir
            val ratio = if (isTallLink(lp.url)) 1f else if (bm != null) (bm.width.toFloat() / bm.height.toFloat()).coerceIn(0.72f, 2.05f) else 1.3f
            Box(Modifier.fillMaxWidth().aspectRatio(ratio).clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp)).background(Color(0x22000000)), contentAlignment = Alignment.Center) {
                if (bm != null) androidx.compose.foundation.Image(bm.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                if (isVideo) {
                    Box(Modifier.size(56.dp).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(36.dp))
                    }
                }
            }
        }
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            if (lp.title.isNotBlank()) Text(lp.title, color = bWhite(), fontSize = 15.sp, lineHeight = 19.sp, fontWeight = if (isVideo0) FontWeight.Normal else FontWeight.SemiBold, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            if (lp.description.isNotBlank() && !isVideo0) Text(lp.description, color = bLc(0xFFD1D7DB), fontSize = 13.sp, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Link, null, tint = bLc(0xFF9AA5AB), modifier = Modifier.size(16.dp))
                Text(host, color = bWhite(), fontSize = 14.sp, modifier = Modifier.padding(start = 6.dp))
            }
        }
    }
}

@Composable
private fun RemoteImage(url: String, modifier: Modifier) {
    val appCtx = LocalContext.current.applicationContext
    val bmp by produceState<android.graphics.Bitmap?>(LinkImgCache.peek(url), url) {
        if (value == null) value = LinkImgCache.load(appCtx, url)
    }
    val b = bmp
    if (b != null) androidx.compose.foundation.Image(b.asImageBitmap(), null, modifier, contentScale = androidx.compose.ui.layout.ContentScale.Crop, colorFilter = auraImageFilter())
}

@Composable
private fun PollBlock(m: Message, me: String, onVote: (Message, String) -> Unit) {
    val counts = HashMap<String, Int>()
    var voters = 0
    m.votes.values.forEach { arr ->
        if (arr.isNotEmpty()) voters++
        arr.forEach { counts[it] = (counts[it] ?: 0) + 1 }
    }
    val mine = m.votes[me] ?: emptyList()
    val maxCount = maxOf(1, m.pollOptions.maxOfOrNull { counts[it.id] ?: 0 } ?: 0)
    Column(Modifier.widthIn(min = 230.dp, max = 300.dp)) {
        Text("📊 " + m.question, color = bWhite(), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(
            if (m.pollMulti) "Birden fazla seçenek seçebilirsiniz" else "Bir seçenek seçin",
            color = bLc(0xB3FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
        )
        m.pollOptions.forEach { o ->
            val c = counts[o.id] ?: 0
            val picked = mine.contains(o.id)
            val pct = if (voters > 0) Math.round(c * 100f / voters) else 0
            val bar = if (voters > 0) c.toFloat() / maxCount else 0f
            Column(Modifier.fillMaxWidth().tapLong { onVote(m, o.id) }.padding(vertical = 7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(20.dp)
                            .clip(if (m.pollMulti) RoundedCornerShape(5.dp) else CircleShape)
                            .background(if (picked) accOr(bLc(0xFF22C55E)) else Color.Transparent)
                            .border(2.dp, if (picked) accOr(bLc(0xFF22C55E)) else bLc(0x73FFFFFF), if (m.pollMulti) RoundedCornerShape(5.dp) else CircleShape),
                        contentAlignment = Alignment.Center
                    ) { if (picked) Text("✓", color = bLc(0xFF04210F), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    Text(o.text, color = bWhite(), fontSize = 15.sp, modifier = Modifier.weight(1f).padding(horizontal = 10.dp))
                    Text("$c", color = bLc(0xD9FFFFFF), fontSize = 12.sp)
                }
                Box(
                    Modifier.padding(start = 30.dp, top = 5.dp).fillMaxWidth().height(5.dp)
                        .clip(RoundedCornerShape(50)).background(bLc(0x24FFFFFF))
                ) {
                    Box(
                        Modifier.fillMaxWidth(bar).height(5.dp).clip(RoundedCornerShape(50))
                            .background(if (picked) accOr(bLc(0xFF22C55E)) else bLc(0x8CFFFFFF))
                    )
                }
                if (voters > 0) Text("%$pct", color = bLc(0x99FFFFFF), fontSize = 10.sp, modifier = Modifier.padding(start = 30.dp, top = 2.dp))
            }
        }
        Text("$voters oy", color = bLc(0xB3FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun ViewOnceBadge(size: androidx.compose.ui.unit.Dp, color: Color, fontSize: Int) {
    Box(
        Modifier.size(size).border(2.dp, color, CircleShape),
        contentAlignment = Alignment.Center
    ) { Text("1", color = color, fontSize = fontSize.sp, fontWeight = FontWeight.Bold) }
}

/** "Bir kez görüntülenebilir" fotoğraf satırı (web ile aynı üç durum) */
@Composable
private fun ViewOnceRow(m: Message, mine: Boolean, seen: Boolean, onOpen: (Message) -> Unit) {
    val opened = m.imageDelivered || seen || m.imageUrl.isBlank()
    when {
        opened -> Text("✓ Fotoğraf açıldı", color = bMuted(), fontSize = 13.sp, fontStyle = FontStyle.Italic)
        mine -> Row(verticalAlignment = Alignment.CenterVertically) {
            ViewOnceBadge(22.dp, bLc(0xFFE5E7EB), 12)
            Text("  Fotoğraf · henüz açılmadı", color = bLc(0xFFE5E7EB), fontSize = 13.sp)
        }
        else -> Row(Modifier.tapLong { onOpen(m) }, verticalAlignment = Alignment.CenterVertically) {
            ViewOnceBadge(26.dp, AuraGreen, 13)
            Text("  Fotoğraf · görmek için dokun", color = bWhite(), fontSize = 14.sp)
        }
    }
}

/** "Bir kez dinlenebilir" ses satırı: dinlenince onOpen(m) çağrılır (ChatScreen sesi siler/işaretler) */
@Composable
private fun AudioOnceRow(m: Message, mine: Boolean, seen: Boolean, onOpen: (Message) -> Unit) {
    val ctx = LocalContext.current
    val opened = m.audioDelivered || seen || m.audio.isBlank()
    val active = AudioPlayer.currentId == m.id
    val playing = active && AudioPlayer.playing
    var started by remember(m.id) { mutableStateOf(false) }
    LaunchedEffect(active, playing) {
        while (active && playing) {
            AudioPlayer.tick()
            delay(200)
        }
    }
    LaunchedEffect(active) {
        if (active) started = true
        else if (started && !opened && !mine) onOpen(m)
    }
    when {
        opened -> Text("✓ Ses dinlendi", color = bMuted(), fontSize = 13.sp, fontStyle = FontStyle.Italic)
        mine -> Row(verticalAlignment = Alignment.CenterVertically) {
            ViewOnceBadge(22.dp, bLc(0xFFE5E7EB), 12)
            Text("  Sesli mesaj · henüz dinlenmedi", color = bLc(0xFFE5E7EB), fontSize = 13.sp)
        }
        else -> {
            val total = if (active && AudioPlayer.durationMs > 0) AudioPlayer.durationMs else m.audioDuration * 1000
            val prog = if (active && total > 0) AudioPlayer.positionMs.toFloat() / total else 0f
            Row(Modifier.width(250.dp).padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(CircleShape).background(AuraGreen)
                        .tapLong { if (m.audio.isNotEmpty()) AudioPlayer.toggle(ctx, m.id, m.audio) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp))
                }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    LinearProgressIndicator(
                        progress = { prog.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                        color = bWhite(),
                        trackColor = bLc(0x4DFFFFFF)
                    )
                    Text(
                        fmtSec(if (active) AudioPlayer.positionMs / 1000 else m.audioDuration),
                        color = bWhite(), fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
                    )
                }
                ViewOnceBadge(24.dp, AuraGreen, 12)
            }
        }
    }
}

/** WhatsApp tarzı ses kartı: gönderenin fotoğrafı + mikrofon rozeti, oynat düğmesi, kaydırılabilir dalga formu, süre */
@Composable
private fun AudioRow(m: Message, bubble: Color, meta: @Composable () -> Unit) {
    // açık renkli baloncukta (ör. beyaz temada karşı taraf) beyaz öğeler görünmez: saat/ekolayzer grisi kullanılır
    val ink = if (bubble.luminance() > 0.5f) bMuted() else Color.White
    val ctx = LocalContext.current
    val active = AudioPlayer.currentId == m.id
    val playing = active && AudioPlayer.playing
    LaunchedEffect(active, playing) {
        while (active && playing) {
            AudioPlayer.tick()
            delay(100)
        }
    }
    val sp by liveProfile(m.senderUid)
    val total = if (active && AudioPlayer.durationMs > 0) AudioPlayer.durationMs else m.audioDuration * 1000
    val prog = if (active && total > 0) AudioPlayer.positionMs.toFloat() / total else 0f
    val played = ink
    val rest = ink.copy(alpha = 0.5f)
    val wave = remember(m.id, m.audioWave) {
        if (m.audioWave.isNotEmpty()) m.audioWave.map { it / 31f }
        else { val r = java.util.Random(m.id.hashCode().toLong()); List(40) { 0.15f + r.nextFloat() * 0.7f } }
    }
    // WhatsApp referansından ölçüldü (2.75x): kart 323x62dp; avatar 48dp, oynat merkezi 87dp, nokta 11dp, çubuk adımı 4.7dp (2.2dp kalın, en çok 16dp), süre 15sp
    androidx.compose.foundation.layout.BoxWithConstraints {
        val w = if (maxWidth < 298.dp) maxWidth else 298.dp
        Box(Modifier.width(w).height(49.dp)) {
            // avatar: dokununca hız 1x → 1.5x → 2x (hız 1x değilken yerinde hız hapı görünür)
            Box(Modifier.size(48.dp).clickable { if (active) AudioPlayer.cycleSpeed() }) {
                if (!active || AudioPlayer.speed == 1f) {
                    Avatar((sp?.name ?: m.senderName).ifBlank { "?" }, sp?.avatar ?: "", 48.dp)
                } else {
                    Box(Modifier.size(48.dp).clip(CircleShape).background(bLc(0x66000000)), contentAlignment = Alignment.Center) {
                        Text(if (AudioPlayer.speed == 1.5f) "1.5×" else "2×", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
                Icon(Icons.Default.Mic, null, tint = ink, modifier = Modifier.align(Alignment.BottomEnd).offset(x = 7.dp, y = 5.dp).size(24.dp))
            }
            Box(
                Modifier.offset(x = 62.dp, y = 6.dp).size(32.dp).clip(CircleShape).tapLong { if (m.audio.isNotEmpty()) AudioPlayer.toggle(ctx, m.id, m.audio) },
                contentAlignment = Alignment.Center
            ) {
                if (playing) Icon(Icons.Default.Pause, null, tint = ink, modifier = Modifier.size(32.dp))
                else androidx.compose.foundation.Canvas(Modifier.size(32.dp)) {
                    // WhatsApp ölçüsü: 18.5x20.7dp, yumuşak köşeli üçgen
                    val tw = 18.5.dp.toPx(); val th = 20.7.dp.toPx(); val r = 1.5.dp.toPx()
                    val l = (size.width - tw) / 2f + r; val t = (size.height - th) / 2f + r
                    val p = androidx.compose.ui.graphics.Path().apply {
                        moveTo(l, t); lineTo(l + tw - 2 * r, t + (th - 2 * r) / 2f); lineTo(l, t + th - 2 * r); close()
                    }
                    drawPath(p, ink)
                    drawPath(p, ink, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2 * r, join = androidx.compose.ui.graphics.StrokeJoin.Round))
                }
            }
            androidx.compose.foundation.Canvas(
                Modifier.offset(x = 96.dp, y = 12.dp).size(width = w - 100.dp, height = 20.dp)
                    .pointerInput(active) {
                        if (active) {
                            detectTapGestures { o -> AudioPlayer.seekTo(o.x / size.width) }
                        }
                    }
                    .pointerInput(active) {
                        if (active) {
                            detectHorizontalDragGestures { c, _ -> AudioPlayer.seekTo(c.position.x / size.width) }
                        }
                    }
            ) {
                val step = 4.7.dp.toPx()
                val bw = 2.2.dp.toPx()
                val start = 16.dp.toPx()
                val n = ((size.width - start - 2.dp.toPx()) / step).toInt().coerceIn(1, 39)
                val cy = size.height / 2f
                val dotX0 = 9.dp.toPx()
                val maxH = 16.dp.toPx()
                for (i in 0 until n) {
                    val v = wave[(i * wave.size) / n]
                    val h = (1.5.dp.toPx() + v * (maxH - 1.5.dp.toPx())).coerceAtMost(maxH)
                    val x = start + i * step
                    val on = (i + 0.5f) / n <= prog
                    drawLine(if (on) played else rest, androidx.compose.ui.geometry.Offset(x, cy - h / 2f), androidx.compose.ui.geometry.Offset(x, cy + h / 2f), bw, androidx.compose.ui.graphics.StrokeCap.Round)
                }
                val endX = start + (n - 1) * step
                val dx = dotX0 + prog * (endX - dotX0)
                drawCircle(played, 5.5.dp.toPx(), androidx.compose.ui.geometry.Offset(dx, cy))
            }
            Text(
                fmtSec(if (active) AudioPlayer.positionMs / 1000 else m.audioDuration),
                color = ink, fontSize = 12.sp, maxLines = 1, softWrap = false,
                modifier = Modifier.offset(x = 104.5.dp, y = 28.5.dp)
            )
            Box(Modifier.align(Alignment.BottomEnd).offset(y = 5.dp)) { meta() }
        }
    }
}

@Composable
private fun LocationBlock(m: Message, onOpen: (Message) -> Unit) {
    Row(
        Modifier
            .width(220.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(AuraFrame)
            .tapLong { onOpen(m) }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.LocationOn, null, tint = bLc(0xFFEF4444), modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text("Konum", color = bWhite(), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text("%.5f, %.5f".format(m.lat, m.lng), color = bMuted(), fontSize = 12.sp)
            Text("Haritada aç", color = AuraGreen, fontSize = 12.sp)
        }
    }
}

@Composable
private fun DocumentBlock(m: Message, onOpen: (Message) -> Unit) {
    Row(
        Modifier
            .width(220.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(AuraFrame)
            .tapLong { onOpen(m) }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Description, null, tint = bWhite(), modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            m.fileName.ifBlank { "Belge" },
            color = bWhite(), fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
    }
}

/** Resim telefonda yokken bulanık önizleme (web buildBlurPlaceholder ile aynı) */
@Composable
private fun BlurThumb(thumb: String, modifier: Modifier) {
    Box(modifier.background(if (AuraUi.light) Color(0x1F000000) else Color(0x33000000)), contentAlignment = Alignment.Center) {
        if (thumb.isNotEmpty()) {
            DataUrlImage(
                thumb, 64,
                Modifier.fillMaxSize().graphicsLayer(scaleX = 1.25f, scaleY = 1.25f)
                    .then(if (android.os.Build.VERSION.SDK_INT >= 31) Modifier.blur(10.dp) else Modifier),
                ContentScale.Crop
            )
        }
        Icon(Icons.Default.Image, null, tint = bLc(0xCCD1D5DB), modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.FwdBtn(fade: () -> Float, onClick: () -> Unit) {
    // WhatsApp ölçülerinden: açık temada yarı saydam gri daire, koyu temada koyu gri daire; ok her ikisinde beyaz
    Box(
        Modifier.padding(horizontal = 6.dp).align(Alignment.CenterVertically).size(32.dp)
            .graphicsLayer { val f = 1f - fade(); alpha = f; scaleX = 0.6f + 0.4f * f; scaleY = 0.6f + 0.4f * f }
            .clip(CircleShape)
            .background(if (AuraUi.lightReal) Color(0x59808080) else Color(0xD93B4448)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Canvas(Modifier.size(18.dp)) {
            val u = size.width / 24f
            val st = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.4f * u, cap = androidx.compose.ui.graphics.StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
            val stem = androidx.compose.ui.graphics.Path().apply {
                moveTo(3f * u, 20f * u); lineTo(3f * u, 15f * u)
                quadraticBezierTo(3f * u, 9f * u, 9f * u, 9f * u); lineTo(17f * u, 9f * u)
            }
            drawPath(stem, Color.White, style = st)
            for (dx in listOf(0f, 4.2f)) {
                val ch = androidx.compose.ui.graphics.Path().apply {
                    moveTo((14.2f + dx) * u, 4.6f * u); lineTo((18.4f + dx) * u, 9f * u); lineTo((14.2f + dx) * u, 13.4f * u)
                }
                drawPath(ch, Color.White, style = st)
            }
        }
    }
}

@Composable
private fun VideoBlock(m: Message, onOpen: (Message) -> Unit) {
    Box(
        Modifier.size(230.dp, 170.dp).clip(RoundedCornerShape(10.dp)).background(bLc(0xFF0B0F12)).tapLong { onOpen(m) },
        contentAlignment = Alignment.Center
    ) {
        if (m.thumb.isNotEmpty()) DataUrlImage(m.thumb, 400, Modifier.fillMaxSize(), ContentScale.Crop)
        Box(Modifier.size(48.dp).clip(CircleShape).background(bLc(0x99000000)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PlayArrow, "Oynat", tint = bWhite(), modifier = Modifier.size(32.dp))
        }
        if (m.audioDuration > 0) Text(
            String.format(java.util.Locale.US, "%d:%02d", m.audioDuration / 60, m.audioDuration % 60),
            color = bWhite(), fontSize = 12.sp,
            modifier = Modifier.align(Alignment.BottomStart).padding(8.dp).clip(RoundedCornerShape(6.dp)).background(bLc(0x99000000)).padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

/** Metin ve saat/tik: saat sığıyorsa son satırın sağında, sığmıyorsa altında (WhatsApp düzeni) */
@Composable
private fun InlineTimeLayout(text: androidx.compose.ui.text.AnnotatedString, meta: @Composable () -> Unit, fill: Boolean = false) {
    var lastRight by remember(text) { androidx.compose.runtime.mutableFloatStateOf(-1f) }
    val gap = with(androidx.compose.ui.platform.LocalDensity.current) { 8.dp.roundToPx() }
    val dropPx = with(androidx.compose.ui.platform.LocalDensity.current) { 3.5.dp.roundToPx() }
    var tLayout by remember(text) { mutableStateOf<androidx.compose.ui.text.TextLayoutResult?>(null) }
    androidx.compose.ui.layout.Layout(content = {
        Text(text, color = bLc(0xFFF3F4F6), style = BubbleText, modifier = Modifier.phoneTap(text) { tLayout }, onTextLayout = { r -> tLayout = r; lastRight = r.getLineRight(r.lineCount - 1) })
        Box { meta() }
    }) { ms, c ->
        val tp = ms[0].measure(c.copy(minWidth = 0))
        val mp = ms[1].measure(androidx.compose.ui.unit.Constraints())
        val lr = if (lastRight < 0f) tp.width else lastRight.toInt()
        val fits = lr + gap + mp.width <= c.maxWidth
        val w = if (fill && c.maxWidth != androidx.compose.ui.unit.Constraints.Infinity) c.maxWidth
            else (if (fits) maxOf(tp.width, lr + gap + mp.width) else maxOf(tp.width, mp.width)).coerceAtMost(c.maxWidth)
        val h = if (fits) maxOf(tp.height, mp.height) else tp.height + mp.height
        // WhatsApp gibi: saat/tik yazının taban çizgisinden belirgin şekilde aşağıda durur (alt dolguya taşar)
        val drop = if (fits) dropPx else 0
        layout(w, h) {
            tp.placeRelative(0, 0)
            mp.placeRelative(w - mp.width, h - mp.height + drop)
        }
    }
}

private fun callDurLabel(s: Int): String = if (s < 60) "$s sn." else "${s / 60} dk ${s % 60} sn."

/** WhatsApp tarzı arama kartı: ikon, başlık, açıklama; dokununca "Ara" paneli açılır */
@Composable
private fun CallCard(m: Message, mine: Boolean, onClick: (Message) -> Unit, meta: @Composable () -> Unit, bubble: Color) {
    val audio = m.callType == "audio"
    val missed = m.type == "missed_call" || m.type == "declined_call"
    // Altta zaten "Cevaplanmadı" / "Reddedildi" yazan kendi aramalarımızda başlıkta "Cevapsız"/"Reddedilen" tekrarlanmaz
    val plain = mine && missed
    val title = when (m.type) {
        "missed_call" -> if (plain) (if (audio) "Sesli arama" else "Görüntülü arama") else if (audio) "Cevapsız sesli arama" else "Cevapsız görüntülü arama"
        "declined_call" -> if (plain) (if (audio) "Sesli arama" else "Görüntülü arama") else if (audio) "Reddedilen sesli arama" else "Reddedilen görüntülü arama"
        else -> if (audio) "Sesli arama" else "Görüntülü arama"
    }
    val sub = when {
        m.type == "missed_call" -> if (mine) "Cevaplanmadı" else "Geri aramak için dokunun"
        m.type == "declined_call" -> if (mine) "Reddedildi" else "Geri aramak için dokunun"
        m.callDuration > 0 -> callDurLabel(m.callDuration)
        else -> m.text.ifBlank { "Geri aramak için dokunun" }
    }
    // WhatsApp kırmızısı (ölçüldü #E90039); açık temanın renk dönüşümü pembeye çeviriyordu, bu yüzden sabit
    val tint = if (missed && !mine) Color(0xFFE90039) else bLc(0xFF5F6368)
    // WhatsApp ölçüsü (referanstan okundu): kart zemini balonun üstüne %12 sıcak gri (beyazda f6f5f3, yeşilde d5f3cf);
    // ikon dairesi açık balonda beyaz %60 (beyaz balonda saf beyaz), koyu balonda balon rengi
    val lightB = bubble.luminance() > 0.5f
    val cardBg = if (lightB) Color(0x1FB4AC9B) else innerBg(bubble)
    val circle = if (!lightB) bubble else if (bubble.luminance() > 0.97f) Color.White else Color.White.copy(alpha = 0.6f)
    val icon = when {
        missed && !mine -> Icons.Default.CallMissed
        mine -> Icons.Default.CallMade
        else -> Icons.Default.CallReceived
    }
    Row(
        Modifier.widthIn(min = 210.dp).width(IntrinsicSize.Max).clip(RoundedCornerShape(10.dp)).background(cardBg)
            .clickable { onClick(m) }.padding(start = 8.dp, end = 9.dp, top = 14.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(circle), contentAlignment = Alignment.Center) {
            if (audio) {
                Icon(Icons.Default.Call, null, tint = tint, modifier = Modifier.size(20.dp))
            } else {
                androidx.compose.foundation.Canvas(Modifier.size(22.dp)) {
                    val w = size.width; val h = size.height
                    // kamera gövdesi + lens
                    drawRoundRect(tint, androidx.compose.ui.geometry.Offset(0f, h * 0.2f), androidx.compose.ui.geometry.Size(w * 0.68f, h * 0.6f), androidx.compose.ui.geometry.CornerRadius(w * 0.1f))
                    val lens = androidx.compose.ui.graphics.Path().apply {
                        moveTo(w * 0.72f, h * 0.45f); lineTo(w, h * 0.27f); lineTo(w, h * 0.73f); lineTo(w * 0.72f, h * 0.55f); close()
                    }
                    drawPath(lens, tint)
                    // ok (gövdenin içinde, daire zemin renginde)
                    val ac = bubble   // ok, ikon dairesiyle (balon rengiyle) aynı renkte
                    val sw = w * 0.07f
                    val cx = w * 0.34f; val cy = h * 0.5f; val r = w * 0.15f
                    if (mine) {
                        drawLine(ac, androidx.compose.ui.geometry.Offset(cx - r, cy + r), androidx.compose.ui.geometry.Offset(cx + r, cy - r), sw)
                        drawLine(ac, androidx.compose.ui.geometry.Offset(cx + r * 0.1f, cy - r), androidx.compose.ui.geometry.Offset(cx + r, cy - r), sw)
                        drawLine(ac, androidx.compose.ui.geometry.Offset(cx + r, cy - r), androidx.compose.ui.geometry.Offset(cx + r, cy - r * 0.1f), sw)
                    } else {
                        drawLine(ac, androidx.compose.ui.geometry.Offset(cx + r, cy - r), androidx.compose.ui.geometry.Offset(cx - r, cy + r), sw)
                        drawLine(ac, androidx.compose.ui.geometry.Offset(cx - r * 0.1f, cy + r), androidx.compose.ui.geometry.Offset(cx - r, cy + r), sw)
                        drawLine(ac, androidx.compose.ui.geometry.Offset(cx - r, cy + r), androidx.compose.ui.geometry.Offset(cx - r, cy + r * 0.1f), sw)
                    }
                }
            }
        }
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(title, color = bWhite(), fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium)
            // açıklama solda, saat sağ kenara dayalı; saat hiç alta kırılmaz (açıklama kısalır)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                Text(sub, color = bLc(0xFF5B6268), fontSize = 13.sp, lineHeight = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                Spacer(Modifier.width(6.dp))
                Box(Modifier.offset(y = 4.5.dp)) { meta() }
            }
        }
    }
}

/** "Devamını okuyun" ile açılan uzun mesajlar; sohbetten çıkınca temizlenir (tekrar girince yine kısaltılmış görünür) */
object ReadMore {
    val open = androidx.compose.runtime.mutableStateMapOf<String, Boolean>()
}

/** Mesaj yazısı: WhatsApp ölçüsü (boyut, satır aralığı, harf aralığı yok) */
private val BubbleText = androidx.compose.ui.text.TextStyle(fontSize = 15.sp, lineHeight = 20.sp)

/** Karşı taraf yazarken sohbetin altında beliren "yazıyor" satırı: üç nokta (+ grupta "N kişi yazıyor"); balonsuz, temaya uyumlu */
@Composable
fun TypingBubble(count: Int = 0, color: Color = AuraTheirs) {
    val inf = androidx.compose.animation.core.rememberInfiniteTransition(label = "typing")
    val shape = RoundedCornerShape(topStart = 0.dp, topEnd = 12.dp, bottomStart = 12.dp, bottomEnd = 12.dp)
    Row(
        Modifier.fillMaxWidth().padding(start = 18.dp, end = 16.dp, top = 2.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.Start, verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier
                .drawBehind {
                    val tw = 8.dp.toPx(); val th = 11.dp.toPx()
                    val path = androidx.compose.ui.graphics.Path()
                    path.moveTo(0f, 0f); path.lineTo(-tw, 0f); path.lineTo(0f, th); path.close()
                    drawPath(path, color)
                }
                .clip(shape).background(color).padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            for (i in 0 until 3) {
                // dalga: noktalar sırayla yukarı çıkıp iner, solukluk da değişir
                val up by inf.animateFloat(
                    0f, 1f,
                    androidx.compose.animation.core.infiniteRepeatable(
                        androidx.compose.animation.core.keyframes {
                            durationMillis = 1100
                            0f at (i * 140)
                            1f at (i * 140 + 260)
                            0f at (i * 140 + 520)
                        }
                    ), label = "dot$i"
                )
                Box(
                    Modifier.graphicsLayer { translationY = -5.dp.toPx() * up }
                        .size(8.dp).clip(CircleShape).background(bMuted().copy(alpha = 0.45f + 0.55f * up))
                )
            }
            if (count > 0) {
                Text(
                    "$count kişi yazıyor", color = bMuted(),
                    style = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, lineHeight = 16.sp),
                    modifier = Modifier.padding(start = 6.dp)
                )
            }
        }
    }
}

/** Üç yerde (mesaj balonu, giriş, resim görüntüleyici) aynı alıntı kartı: ad 1 satır, metin en fazla 3 satır, küçük resim kartın tam yüksekliğinde */
@Composable
fun QuoteCard(
    name: String, nameColor: Color, stripe: Color, preview: String, photo: Boolean, thumb: String,
    bg: Color, radius: androidx.compose.ui.unit.Dp, textSp: Float, thumbDp: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier, endPad: androidx.compose.ui.unit.Dp = 0.dp, textColor: Color = bLc(0xFFB0BCC4)
) {
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(radius)).background(bg).height(IntrinsicSize.Min)
    ) {
        Box(Modifier.width(3.dp).fillMaxHeight().background(stripe))
        Column(Modifier.weight(1f).padding(start = 8.dp, end = 8.dp + (if (thumb.isBlank()) endPad else 0.dp), top = 4.dp, bottom = 4.dp)) {
            Text(name, color = nameColor, fontSize = textSp.sp, lineHeight = (textSp + 4.3f).sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            val inl = if (photo) mapOf("ic" to androidx.compose.foundation.text.InlineTextContent(
                androidx.compose.ui.text.Placeholder((textSp + 1f).sp, (textSp + 1f).sp, androidx.compose.ui.text.PlaceholderVerticalAlign.Center)
            ) { Icon(Icons.Default.Image, null, tint = textColor, modifier = Modifier.fillMaxSize()) }) else emptyMap()
            val body = androidx.compose.ui.text.buildAnnotatedString {
                if (photo) { appendInlineContent("ic", "[img]"); append(" ") }
                append(preview)
            }
            Text(
                text = body, inlineContent = inl, color = textColor, fontSize = textSp.sp, lineHeight = (textSp + 4.3f).sp,
                maxLines = 3, overflow = TextOverflow.Ellipsis
            )
        }
        if (thumb.isNotBlank()) {
            Box(Modifier.width(thumbDp).fillMaxHeight()) {
                if (thumb.startsWith("http")) RemoteImage(thumb, Modifier.matchParentSize())
                else DataUrlImage(thumb, 160, Modifier.matchParentSize(), androidx.compose.ui.layout.ContentScale.Crop)
            }
        }
    }
}

/** Alıntı kartındaki küçük resim: fotoğraf, video kapağı veya bağlantı önizleme resmi */
fun quoteThumbOf(o: Message?): String {
    if (o == null || o.deleted) return ""
    return when {
        o.type == "image" && !o.viewOnce -> o.images.firstOrNull() ?: o.imageUrl
        o.type == "video" -> o.thumb.ifBlank { o.thumbs.firstOrNull() ?: "" }
        else -> o.linkPreview?.image ?: ""
    }
}

fun WebHostIsVideo(url: String): Boolean {
    val h = try { android.net.Uri.parse(url).host?.lowercase() ?: "" } catch (e: Throwable) { "" }
    return h.contains("tiktok") || h.contains("youtu") || h.contains("vimeo") || h.contains("instagram") || h.contains("facebook") || h.contains("fb.watch") || h.contains("twitch")
}

/** Giriş çubuğundaki bağlantı önizlemesi küçük resmi (video sitelerinde oynat simgesiyle) */
@Composable
fun LinkThumb(url: String, video: Boolean, modifier: Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        RemoteImage(url, Modifier.fillMaxSize())
        if (video) {
            Box(Modifier.size(32.dp).clip(CircleShape).background(auraLc(0x99000000)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = AuraWhite, modifier = Modifier.size(22.dp))
            }
        }
    }
}


/** Link kartı görselleri: bellek + disk önbelleği; sohbet her açıldığında yeniden indirilmez */
object LinkImgCache {
    private val mem = object : android.util.LruCache<String, android.graphics.Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(k: String, v: android.graphics.Bitmap) = v.byteCount
    }

    fun peek(url: String): android.graphics.Bitmap? = if (url.isBlank()) null else mem.get(url)

    private fun decode(f: java.io.File): android.graphics.Bitmap? {
        val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(f.absolutePath, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= 900) sample *= 2
        return android.graphics.BitmapFactory.decodeFile(f.absolutePath, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
    }

    suspend fun load(ctx: android.content.Context, url: String): android.graphics.Bitmap? {
        if (url.isBlank()) return null
        mem.get(url)?.let { return it }
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val dir = java.io.File(ctx.cacheDir, "linkimg").apply { mkdirs() }
                val f = java.io.File(dir, Integer.toHexString(url.hashCode()) + "_" + url.length + ".img")
                if (!f.exists() || f.length() == 0L) {
                    val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                    c.connectTimeout = 8000; c.readTimeout = 8000
                    val tmp = java.io.File(dir, f.name + ".tmp")
                    c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    tmp.renameTo(f)
                }
                decode(f)?.also { mem.put(url, it) }
            } catch (e: Throwable) { null }
        }
    }
}


/** Kişi kartına dokunma köprüsü: MainActivity bağlar (adına dokun → kişiyi görüntüle, "Mesaj" → sohbet) */
object ContactNav {
    var view: (Message) -> Unit = {}
    var message: (Message) -> Unit = {}
}

/** Paylaşılan kişi kartı (WhatsApp gibi): avatar + ad, saat, çizgi, "Mesaj" düğmesi */
@Composable
private fun ContactBlock(m: Message, metaContent: @Composable () -> Unit) {
    val lp by liveProfile(m.fileMime)
    val name = lp?.name?.takeIf { it.isNotBlank() } ?: m.text
    Column(Modifier.width(250.dp)) {
        Row(
            Modifier.fillMaxWidth().clickable { ContactNav.view(m) }.padding(start = 10.dp, end = 10.dp, top = 10.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Avatar(name, lp?.avatar, 56.dp)
            Text(name, color = bLc(0xFFF3F4F6), fontSize = 17.sp, letterSpacing = 0.sp, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(start = 12.dp).weight(1f))
        }
        Box(Modifier.fillMaxWidth().padding(end = 9.dp, bottom = 4.dp), contentAlignment = Alignment.CenterEnd) { metaContent() }
        Box(Modifier.fillMaxWidth().height(hairline()).background(bLc(0x33FFFFFF)))
        Box(Modifier.fillMaxWidth().height(44.dp).clickable { ContactNav.message(m) }, contentAlignment = Alignment.Center) {
            Text("Mesaj", color = bLc(0xFFF3F4F6), fontSize = 17.sp, letterSpacing = 0.sp)
        }
    }
}


/** Kendi bağlantı kartının simgesi + baskın rengi. Bellekte tutulur: sohbet kaydırılınca kart yeniden oluşsa bile simge anında gelir (görünüp kaybolmaz). */
private object OwnLookCache {
    var key = -2
    var v: Pair<androidx.compose.ui.graphics.ImageBitmap, Color>? = null
}

@Composable
private fun rememberOwnLook(ctx: android.content.Context, enabled: Boolean): Pair<androidx.compose.ui.graphics.ImageBitmap, Color>? {
    if (!enabled) return null
    val cur = remember { AppIcon.current(ctx) }
    val st = produceState(if (OwnLookCache.key == cur) OwnLookCache.v else null, cur) {
        if (OwnLookCache.key == cur && OwnLookCache.v != null) { value = OwnLookCache.v; return@produceState }
        val r = withContext(kotlinx.coroutines.Dispatchers.Default) {
            AppIcon.iconBitmap(ctx)?.let { it.asImageBitmap() to Color(AppIcon.dominantColor(it)) }
        }
        if (r != null) { OwnLookCache.key = cur; OwnLookCache.v = r }
        value = r
    }
    return st.value
}

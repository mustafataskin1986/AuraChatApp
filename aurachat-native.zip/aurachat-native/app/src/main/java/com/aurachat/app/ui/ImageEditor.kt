package com.aurachat.app.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.compose.foundation.Canvas as UiCanvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aurachat.app.data.Media
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private class Note(var text: String, val color: Int, x: Float, y: Float) {
    var nx by mutableStateOf(x)   // 0..1 (görüntü alanına oranla, sol üst)
    var ny by mutableStateOf(y)
    var txt by mutableStateOf(text)
}

private val editorColors = listOf(
    0xFF000000, 0xFFF44336, 0xFFFFEB3B, 0xFF4CAF50, 0xFF2196F3, 0xFF9C27B0, 0xFFFFFFFF
).map { it.toInt() }

/** Sohbette gönderilecek resmi düzenler: eskiz, not ekle, kırp (eski sürümdeki "işaretleme" ekranı) */
@Composable
fun ImageEditor(dataUrl: String, targetBytes: Int, onDone: (String) -> Unit, onCancel: () -> Unit) {
    val density = LocalDensity.current
    val base = remember(dataUrl) {
        val b = Media.decode(dataUrl, 1600)
        b?.copy(Bitmap.Config.ARGB_8888, true)
    }
    if (base == null) { onCancel(); return }

    val history = remember { mutableStateListOf(base) }
    var idx by remember { mutableIntStateOf(0) }
    val cur = history[idx]
    var tool by remember { mutableStateOf("") }
    var color by remember { mutableIntStateOf(0xFFFFFFFF.toInt()) }
    val notes = remember { mutableStateListOf<Note>() }
    val live = remember { mutableStateListOf<Offset>() }

    // kırpma kutusu (görüntü alanına oranla)
    var cl by remember { mutableStateOf(0.08f) }
    var ct by remember { mutableStateOf(0.08f) }
    var cr by remember { mutableStateOf(0.92f) }
    var cb by remember { mutableStateOf(0.92f) }

    fun push(b: Bitmap) {
        while (history.size > idx + 1) history.removeAt(history.size - 1)
        history.add(b)
        if (history.size > 14) history.removeAt(0)
        idx = history.size - 1
    }

    fun commitStroke(pts: List<Offset>, w: Float, h: Float) {
        if (pts.isEmpty()) return
        val src = history[idx]
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; style = Paint.Style.STROKE
            strokeWidth = out.width * 0.012f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        val sx = out.width / w
        val sy = out.height / h
        if (pts.size == 1) {
            p.style = Paint.Style.FILL
            c.drawCircle(pts[0].x * sx, pts[0].y * sy, p.strokeWidth / 2, p)
        } else {
            val path = Path()
            path.moveTo(pts[0].x * sx, pts[0].y * sy)
            for (i in 1 until pts.size) path.lineTo(pts[i].x * sx, pts[i].y * sy)
            c.drawPath(path, p)
        }
        push(out)
    }

    fun finish() {
        val out = history[idx].copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        notes.forEach { n ->
            if (n.txt.isBlank()) return@forEach
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = n.color; textSize = out.width * 0.045f; typeface = Typeface.DEFAULT_BOLD
                setShadowLayer(out.width * 0.004f, 0f, 0f, 0xAA000000.toInt())
            }
            val maxW = max(1, (out.width * (1f - n.nx)).toInt())
            val sl = StaticLayout.Builder.obtain(n.txt, 0, n.txt.length, tp, maxW)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
            c.save()
            c.translate(n.nx * out.width, n.ny * out.height)
            sl.draw(c)
            c.restore()
        }
        onDone(Media.bitmapToDataUrl(out, targetBytes))
    }

    Dialog(
        onDismissRequest = onCancel,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Color(0x1FFFFFFF)).clickable { onCancel() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Close, "Kapat", tint = Color.White) }
                Text(
                    "Düzenlemeyi bitir", color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White)
                        .clickable { finish() }.padding(horizontal = 20.dp, vertical = 10.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(Color(0x1FFFFFFF))
                            .clickable(enabled = idx > 0) { idx-- },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.AutoMirrored.Filled.Undo, "Geri al", tint = if (idx > 0) Color.White else Color(0x40FFFFFF)) }
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(Color(0x1FFFFFFF))
                            .clickable(enabled = idx < history.size - 1) { idx++ },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.AutoMirrored.Filled.Redo, "İleri al", tint = if (idx < history.size - 1) Color.White else Color(0x40FFFFFF)) }
                }
            }

            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
                val aw = with(density) { maxWidth.toPx() }
                val ah = with(density) { maxHeight.toPx() }
                val sc = min(aw / cur.width, ah / cur.height)
                val dw = cur.width * sc
                val dh = cur.height * sc
                val wDp = with(density) { dw.toDp() }
                val hDp = with(density) { dh.toDp() }

                Box(Modifier.size(wDp, hDp)) {
                    Image(cur.asImageBitmap(), null, Modifier.fillMaxSize())

                    // eskiz katmanı
                    if (tool == "eskiz") {
                        UiCanvas(
                            Modifier.fillMaxSize().pointerInput(color, idx) {
                                detectDragGestures(
                                    onDragStart = { live.clear(); live.add(it) },
                                    onDrag = { ch, _ -> live.add(ch.position) },
                                    onDragEnd = { commitStroke(live.toList(), dw, dh); live.clear() },
                                    onDragCancel = { live.clear() }
                                )
                            }
                        ) {
                            if (live.size > 1) {
                                val path = androidx.compose.ui.graphics.Path()
                                path.moveTo(live[0].x, live[0].y)
                                for (i in 1 until live.size) path.lineTo(live[i].x, live[i].y)
                                drawPath(path, Color(color), style = Stroke(width = dw * 0.012f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                            }
                        }
                    }

                    // notlar
                    notes.forEach { n ->
                        Row(
                            Modifier.offset { IntOffset((n.nx * dw).roundToInt(), (n.ny * dh).roundToInt()) }
                                .clip(RoundedCornerShape(12.dp)).background(Color(0x66000000))
                                .border(1.dp, Color(0x80FFFFFF), RoundedCornerShape(12.dp))
                                .padding(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(28.dp).pointerInput(Unit) {
                                    detectDragGestures { ch, drag ->
                                        ch.consume()
                                        n.nx = (n.nx + drag.x / dw).coerceIn(0f, 0.9f)
                                        n.ny = (n.ny + drag.y / dh).coerceIn(0f, 0.95f)
                                    }
                                },
                                contentAlignment = Alignment.Center
                            ) { Text("✥", color = Color.White, fontSize = 16.sp) }
                            BasicTextField(
                                value = n.txt, onValueChange = { n.txt = it },
                                textStyle = TextStyle(
                                    color = Color(n.color), fontWeight = FontWeight.Bold,
                                    fontSize = with(density) { (dw * 0.045f).toSp() }
                                ),
                                cursorBrush = SolidColor(Color.White),
                                modifier = Modifier.width(wDp * 0.5f)
                            )
                            Box(
                                Modifier.size(24.dp).clickable { notes.remove(n) },
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Default.Close, "Sil", tint = Color.White, modifier = Modifier.size(16.dp)) }
                        }
                    }

                    // kırpma kutusu
                    if (tool == "kirp") {
                        UiCanvas(Modifier.fillMaxSize()) {
                            val l = cl * size.width; val t = ct * size.height
                            val r = cr * size.width; val b = cb * size.height
                            val shade = Color(0x99000000)
                            drawRect(shade, Offset(0f, 0f), androidx.compose.ui.geometry.Size(size.width, t))
                            drawRect(shade, Offset(0f, b), androidx.compose.ui.geometry.Size(size.width, size.height - b))
                            drawRect(shade, Offset(0f, t), androidx.compose.ui.geometry.Size(l, b - t))
                            drawRect(shade, Offset(r, t), androidx.compose.ui.geometry.Size(size.width - r, b - t))
                            drawRect(Color.White, Offset(l, t), androidx.compose.ui.geometry.Size(r - l, b - t), style = Stroke(2f))
                            for (i in 1..2) {
                                val gx = l + (r - l) * i / 3f; val gy = t + (b - t) * i / 3f
                                drawLine(Color(0x66FFFFFF), Offset(gx, t), Offset(gx, b), 1f)
                                drawLine(Color(0x66FFFFFF), Offset(l, gy), Offset(r, gy), 1f)
                            }
                        }
                        val hs = 44.dp
                        @Composable
                        fun Handle(xf: Float, yf: Float, onMove: (Float, Float) -> Unit) {
                            Box(
                                Modifier.offset { IntOffset((xf * dw - hs.toPx() / 2).roundToInt(), (yf * dh - hs.toPx() / 2).roundToInt()) }
                                    .size(hs)
                                    .pointerInput(Unit) {
                                        detectDragGestures { ch, d -> ch.consume(); onMove(d.x / dw, d.y / dh) }
                                    },
                                contentAlignment = Alignment.Center
                            ) { Box(Modifier.size(18.dp).clip(CircleShape).background(Color.White)) }
                        }
                        val minS = 0.12f
                        Handle(cl, ct) { dx, dy -> cl = (cl + dx).coerceIn(0f, cr - minS); ct = (ct + dy).coerceIn(0f, cb - minS) }
                        Handle(cr, ct) { dx, dy -> cr = (cr + dx).coerceIn(cl + minS, 1f); ct = (ct + dy).coerceIn(0f, cb - minS) }
                        Handle(cl, cb) { dx, dy -> cl = (cl + dx).coerceIn(0f, cr - minS); cb = (cb + dy).coerceIn(ct + minS, 1f) }
                        Handle(cr, cb) { dx, dy -> cr = (cr + dx).coerceIn(cl + minS, 1f); cb = (cb + dy).coerceIn(ct + minS, 1f) }
                        Text(
                            "✓ Kırp", color = Color.Black, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp)
                                .clip(RoundedCornerShape(20.dp)).background(Color.White)
                                .clickable {
                                    val src = history[idx]
                                    val x = (cl * src.width).roundToInt().coerceIn(0, src.width - 1)
                                    val y = (ct * src.height).roundToInt().coerceIn(0, src.height - 1)
                                    val w = ((cr - cl) * src.width).roundToInt().coerceIn(1, src.width - x)
                                    val h = ((cb - ct) * src.height).roundToInt().coerceIn(1, src.height - y)
                                    push(Bitmap.createBitmap(src, x, y, w, h))
                                    notes.clear()
                                    cl = 0.08f; ct = 0.08f; cr = 0.92f; cb = 0.92f
                                    tool = ""
                                }
                                .padding(horizontal = 20.dp, vertical = 10.dp)
                        )
                    }
                }
            }

            // renkler
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.Center) {
                editorColors.forEach { c ->
                    Box(
                        Modifier.padding(horizontal = 6.dp).size(28.dp).clip(CircleShape).background(Color(c))
                            .border(if (c == color) 3.dp else 1.dp, if (c == color) Color(0xFF22C55E) else Color(0x66FFFFFF), CircleShape)
                            .clickable { color = c }
                    )
                }
            }
            // araçlar
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                @Composable
                fun Tool(id: String, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onPick: () -> Unit) {
                    val on = tool == id
                    Column(Modifier.clickable { onPick() }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(64.dp).clip(CircleShape).background(if (on) Color.White else Color(0x14FFFFFF)),
                            contentAlignment = Alignment.Center
                        ) { Icon(icon, label, tint = if (on) Color.Black else Color.White, modifier = Modifier.size(26.dp)) }
                        Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
                Tool("eskiz", "Eskiz", Icons.Default.Brush) { tool = if (tool == "eskiz") "" else "eskiz" }
                Tool("not", "Not ekle", Icons.Default.TextFields) {
                    tool = "not"
                    notes.add(Note("", color, 0.12f, 0.4f))
                }
                Tool("kirp", "Kırp", Icons.Default.Crop) { tool = if (tool == "kirp") "" else "kirp" }
            }
        }
    }
}

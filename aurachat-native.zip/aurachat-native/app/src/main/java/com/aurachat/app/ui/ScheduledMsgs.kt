package com.aurachat.app.ui

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.work.CoroutineWorker
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Repo
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** İleri tarihe planlanmış (yalnız metin) mesajlar: cihazda saklanır, vakti gelince WorkManager / açık uygulama gönderir */
object ScheduledMsgs {
    class Item(val id: String, val uid: String, val chatId: String, val isGroup: Boolean, val otherUid: String, val name: String, val text: String, val at: Long, val createdAt: Long)

    val items = mutableStateListOf<Item>()
    private val lock = Any()
    private var loaded = false

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("sched", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        synchronized(lock) {
            if (loaded) return
            loaded = true
            try {
                val a = JSONArray(prefs(ctx).getString("list", "[]"))
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    items.add(Item(o.getString("id"), o.getString("uid"), o.getString("chat"), o.optBoolean("g"), o.getString("other"), o.optString("name"), o.getString("text"), o.getLong("at"), o.optLong("cr")))
                }
            } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ScheduledMsgs", e) }
        }
    }

    private fun save(ctx: Context) {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().put("id", it.id).put("uid", it.uid).put("chat", it.chatId).put("g", it.isGroup).put("other", it.otherUid).put("name", it.name).put("text", it.text).put("at", it.at).put("cr", it.createdAt)) }
        prefs(ctx).edit().putString("list", a.toString()).apply()
    }

    fun add(ctx: Context, uid: String, t: ChatTarget, text: String, at: Long) {
        load(ctx)
        val it = Item(java.util.UUID.randomUUID().toString(), uid, t.chatId, t.isGroup, t.otherUid, t.name, text, at, System.currentTimeMillis())
        synchronized(lock) { items.add(it); items.sortBy { x -> x.at }; save(ctx) }
        arm(ctx, it)
    }

    fun remove(ctx: Context, id: String) {
        load(ctx)
        synchronized(lock) { items.removeAll { it.id == id }; save(ctx) }
        try { WorkManager.getInstance(ctx.applicationContext).cancelUniqueWork("sched-$id") } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ScheduledMsgs", e) }
    }

    fun forChat(chatId: String): List<Item> = items.filter { it.chatId == chatId }

    private fun arm(ctx: Context, it: Item) {
        try {
            val d = (it.at - System.currentTimeMillis()).coerceAtLeast(0L)
            val req = OneTimeWorkRequestBuilder<SchedWorker>()
                .setInitialDelay(d, TimeUnit.MILLISECONDS)
                .setConstraints(androidx.work.Constraints.Builder().setRequiredNetworkType(androidx.work.NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx.applicationContext).enqueueUniqueWork("sched-${it.id}", androidx.work.ExistingWorkPolicy.REPLACE, req)
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ScheduledMsgs", e) }
    }

    /** Vakti gelenleri (ya da id verilmişse onu hemen) gönderir; her öğe gönderilmeden önce listeden çıkarıldığı için iki kez gitmez */
    suspend fun sendDue(ctx: Context, onlyId: String? = null) {
        load(ctx)
        val now = System.currentTimeMillis()
        val due = synchronized(lock) {
            val d = items.filter { if (onlyId != null) it.id == onlyId else it.at <= now }
            if (d.isNotEmpty()) { items.removeAll(d); save(ctx) }
            d
        }
        for (it in due) {
            val me = Repo.peekProfile(it.uid)
            if (me == null) { synchronized(lock) { items.add(it); items.sortBy { x -> x.at }; save(ctx) }; continue }
            try {
                Repo.sendText(me, ChatTarget(it.chatId, it.isGroup, it.otherUid, it.name), it.text, null)
            } catch (e: Throwable) {
                com.aurachat.app.AuraLog.e("ScheduledMsgs", e)
                synchronized(lock) { items.add(it); items.sortBy { x -> x.at }; save(ctx) }
            }
        }
    }

    /** Uygulama yeniden açılınca bekleyenlerin iş kayıtlarını yeniler (cihaz yeniden başlamış olabilir) */
    fun rearmAll(ctx: Context) { load(ctx); items.toList().forEach { arm(ctx, it) } }
}

class SchedWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        ScheduledMsgs.sendDue(applicationContext)
        return if (ScheduledMsgs.items.any { it.at <= System.currentTimeMillis() }) Result.retry() else Result.success()
    }
}

/** Uygulama açıkken 10 sn'de bir vakti gelenleri gönderir */
@androidx.compose.runtime.Composable
fun ScheduledTicker() {
    val ctx = androidx.compose.ui.platform.LocalContext.current.applicationContext
    androidx.compose.runtime.LaunchedEffect(Unit) {
        ScheduledMsgs.load(ctx)
        ScheduledMsgs.rearmAll(ctx)
        while (true) { ScheduledMsgs.sendDue(ctx); delay(10_000) }
    }
}

package com.aurachat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

private const val MAX_Q = 255
private const val MAX_OPT = 100
private const val MAX_OPTIONS = 12

/** "Anket oluşturun" tam ekran formu (eski sürümle aynı düzen) */
@Composable
fun PollCreator(onSend: (String, List<String>, Boolean) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var question by remember { mutableStateOf("") }
    var multi by remember { mutableStateOf(true) }
    val options = remember { mutableStateListOf("", "") }
    val qFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { try { qFocus.requestFocus() } catch (e: Throwable) {} }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Box(Modifier.fillMaxSize().background(Color(0xFF0B1016)).statusBarsPadding().navigationBarsPadding().imePadding()) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color(0xFFE9EDEF)) }
                    Text("Anket oluşturun", color = Color(0xFFE9EDEF), fontSize = 20.sp, modifier = Modifier.padding(start = 10.dp))
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp).padding(bottom = 110.dp)) {
                    Text("Soru", color = Color(0xFF9AA5AD), fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp, bottom = 12.dp))
                    Box(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).border(1.5.dp, Color(0xFF5B6770), RoundedCornerShape(12.dp))
                            .padding(horizontal = 16.dp, vertical = 15.dp)
                    ) {
                        if (question.isEmpty()) Text("Soru sorun", color = Color(0xFF9AA5AD), fontSize = 17.sp)
                        BasicTextField(
                            value = question, onValueChange = { if (it.length <= MAX_Q) question = it },
                            textStyle = TextStyle(color = Color(0xFFE9EDEF), fontSize = 17.sp),
                            cursorBrush = SolidColor(Color(0xFF22C55E)),
                            modifier = Modifier.fillMaxWidth().focusRequester(qFocus)
                        )
                    }
                    Text("${question.length}/$MAX_Q", color = Color(0xFF9AA5AD), fontSize = 13.sp,
                        modifier = Modifier.align(Alignment.End).padding(top = 6.dp, end = 12.dp))

                    Text("Seçenekler", color = Color(0xFF9AA5AD), fontSize = 15.sp, modifier = Modifier.padding(top = 26.dp, bottom = 12.dp))
                    options.forEachIndexed { i, v ->
                        Box(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).border(1.5.dp, Color(0xFF5B6770), RoundedCornerShape(12.dp))
                                .padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.weight(1f).padding(vertical = 3.dp)) {
                                    if (v.isEmpty()) Text("+ Ekleyin", color = Color(0xFF9AA5AD), fontSize = 17.sp)
                                    BasicTextField(
                                        value = v,
                                        onValueChange = {
                                            if (it.length <= MAX_OPT) {
                                                options[i] = it
                                                // son kutu dolunca yeni boş kutu eklenir
                                                if (i == options.size - 1 && it.isNotBlank() && options.size < MAX_OPTIONS) options.add("")
                                            }
                                        },
                                        textStyle = TextStyle(color = Color(0xFFE9EDEF), fontSize = 17.sp),
                                        cursorBrush = SolidColor(Color(0xFF22C55E)),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                if (options.size > 2 && v.isNotBlank()) {
                                    IconButton(onClick = { options.removeAt(i) }, modifier = Modifier.size(36.dp)) {
                                        Icon(Icons.Default.Close, "Sil", tint = Color(0xFF9AA5AD), modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                        Text("${v.length}/$MAX_OPT", color = Color(0xFF9AA5AD), fontSize = 13.sp,
                            modifier = Modifier.align(Alignment.End).padding(top = 6.dp, end = 12.dp, bottom = 14.dp))
                    }
                    Row(
                        Modifier.fillMaxWidth().clickable { multi = !multi }.padding(top = 22.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Birden çok yanıta izin ver", color = Color(0xFFE9EDEF), fontSize = 17.sp, modifier = Modifier.weight(1f))
                        Box(
                            Modifier.size(width = 60.dp, height = 34.dp).clip(CircleShape)
                                .background(if (multi) Color(0xFF22C55E) else Color(0xFF3B4650))
                        ) {
                            Box(
                                Modifier.align(if (multi) Alignment.CenterEnd else Alignment.CenterStart).padding(3.dp)
                                    .size(28.dp).clip(CircleShape).background(Color(0xFF0B1016)),
                                contentAlignment = Alignment.Center
                            ) { if (multi) Text("✓", color = Color(0xFF22C55E), fontSize = 13.sp) }
                        }
                    }
                }
            }
            Box(
                Modifier.align(Alignment.BottomEnd).padding(18.dp).size(64.dp).clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF22C55E))
                    .clickable {
                        val q = question.trim()
                        val texts = options.map { it.trim() }.filter { it.isNotEmpty() }.distinctBy { it.lowercase() }
                        when {
                            q.isEmpty() -> android.widget.Toast.makeText(ctx, "Önce bir soru yaz", android.widget.Toast.LENGTH_SHORT).show()
                            texts.size < 2 -> android.widget.Toast.makeText(ctx, "En az 2 farklı seçenek gerekli", android.widget.Toast.LENGTH_SHORT).show()
                            else -> onSend(q, texts, multi)
                        }
                    },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Filled.Send, "Gönder", tint = Color(0xFF04210F), modifier = Modifier.size(26.dp)) }
        }
    }
}

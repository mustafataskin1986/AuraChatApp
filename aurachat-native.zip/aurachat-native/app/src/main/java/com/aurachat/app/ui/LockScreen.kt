package com.aurachat.app.ui

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.AppState

/** Uygulama kilidi: telefonun ekran kilidiyle (parmak izi / PIN / desen) açılır */
@Composable
fun LockOverlay() {
    if (!AppState.locked.value) return
    val ctx = LocalContext.current
    val km = remember { ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) AppState.locked.value = false
    }
    fun ask() {
        if (!km.isDeviceSecure) { AppState.locked.value = false; return }
        @Suppress("DEPRECATION")
        val i = km.createConfirmDeviceCredentialIntent("AuraChat", "Devam etmek için kimliğini doğrula")
        if (i == null) AppState.locked.value = false else try { launcher.launch(i) } catch (e: Throwable) {}
    }
    BackHandler { }
    LaunchedEffect(Unit) { ask() }
    Box(Modifier.fillMaxSize().background(AuraBlack).clickable(enabled = true) { }, contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Lock, null, tint = AuraGreen, modifier = Modifier.size(56.dp))
            Text("AuraChat kilitli", color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 16.dp))
            Text(
                "Kilidi aç", color = AuraWhite, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 24.dp).clip(RoundedCornerShape(50)).background(AuraBtn)
                    .clickable { ask() }.padding(horizontal = 32.dp, vertical = 12.dp)
            )
        }
    }
}

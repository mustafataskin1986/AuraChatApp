package com.aurachat.app.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/** YouTube / TikTok bağlantılarını uygulama içinde oynatır */
object WebPlay {
    fun host(url: String): String = try { Uri.parse(url).host?.removePrefix("www.")?.removePrefix("m.") ?: "" } catch (e: Throwable) { "" }

    fun youtubeId(url: String): String? {
        val u = try { Uri.parse(url) } catch (e: Throwable) { return null }
        val h = host(url)
        if (h == "youtu.be") return u.lastPathSegment?.takeIf { it.isNotBlank() }
        if (h.endsWith("youtube.com") || h.endsWith("youtube-nocookie.com")) {
            u.getQueryParameter("v")?.let { return it }
            val seg = u.pathSegments
            if (seg.size >= 2 && (seg[0] == "shorts" || seg[0] == "embed" || seg[0] == "live" || seg[0] == "v")) return seg[1]
        }
        return null
    }

    fun tiktokId(url: String): String? = Regex("/video/(\\d+)").find(url)?.groupValues?.get(1)

    fun playable(url: String): Boolean {
        val h = host(url)
        return youtubeId(url) != null || h.endsWith("tiktok.com")
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebPlayerDialog(url: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)) {
        Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.height(44.dp).clickable { onClose() }.padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Close, "Kapat", tint = Color.White)
                }
                Box(Modifier.weight(1f))
                Text(
                    "Dış uygulamada aç", color = Color(0xFF53BDEB), fontSize = 14.sp,
                    modifier = Modifier.clickable {
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Throwable) {}
                    }.padding(12.dp)
                )
            }
            val yt = remember(url) { WebPlay.youtubeId(url) }
            val tt = remember(url) { WebPlay.tiktokId(url) }
            var web: WebView? = null
            DisposableEffect(url) { onDispose { try { web?.stopLoading(); web?.destroy() } catch (e: Throwable) {} } }
            AndroidView(
                modifier = Modifier.fillMaxWidth().weight(1f),
                factory = { c ->
                    WebView(c).also { w ->
                        web = w
                        w.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                        w.setBackgroundColor(android.graphics.Color.BLACK)
                        w.settings.javaScriptEnabled = true
                        w.settings.domStorageEnabled = true
                        w.settings.mediaPlaybackRequiresUserGesture = false
                        w.settings.loadWithOverviewMode = true
                        w.settings.useWideViewPort = true
                        w.webChromeClient = WebChromeClient()
                        w.webViewClient = WebViewClient()
                        when {
                            yt != null -> {
                                val html = "<html><body style='margin:0;background:#000'><iframe width='100%' height='100%' " +
                                    "src='https://www.youtube.com/embed/$yt?autoplay=1&playsinline=1&rel=0' frameborder='0' " +
                                    "allow='autoplay; encrypted-media; picture-in-picture; fullscreen' allowfullscreen " +
                                    "style='position:absolute;top:0;left:0;width:100%;height:100%'></iframe></body></html>"
                                w.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
                            }
                            tt != null -> w.loadUrl("https://www.tiktok.com/embed/v2/$tt")
                            else -> w.loadUrl(url)
                        }
                    }
                }
            )
        }
    }
}

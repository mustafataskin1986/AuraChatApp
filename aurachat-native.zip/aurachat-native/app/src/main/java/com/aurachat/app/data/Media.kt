package com.aurachat.app.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.util.LruCache
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.max

/** Fotoğraf / ses / belge yardımcıları. Mesajlar Firestore'da base64 data URL olarak tutulur (web ile aynı). */
object Media {
    private val bitmapCache = LruCache<String, Bitmap>(160)

    private fun payloadOf(dataUrl: String): String =
        if (dataUrl.startsWith("data:") && dataUrl.contains(",")) dataUrl.substringAfter(",") else dataUrl

    fun bytesOf(dataUrl: String): ByteArray =
        if (dataUrl.startsWith("file:")) File(dataUrl.removePrefix("file:")).readBytes()
        else Base64.decode(payloadOf(dataUrl), Base64.DEFAULT)

    /** "file:<yol>" ise dosyayı data URL'ye çevirir (iletme için); değilse olduğu gibi döner */
    fun dataUrlOf(src: String, mimeHint: String = ""): String {
        if (!src.startsWith("file:")) return src
        val f = File(src.removePrefix("file:"))
        val ext = f.extension.lowercase()
        val mime = when {
            mimeHint.isNotBlank() -> mimeHint
            ext == "jpg" || ext == "jpeg" -> "image/jpeg"
            ext == "png" -> "image/png"
            ext == "m4a" -> "audio/mp4"
            ext == "mp3" -> "audio/mpeg"
            ext == "ogg" -> "audio/ogg"
            ext == "wav" -> "audio/wav"
            ext == "aac" -> "audio/aac"
            ext == "webm" -> "audio/webm"
            else -> "application/octet-stream"
        }
        return fileToDataUrl(f, mime)
    }

    /** Başka uygulamaya açmak için: telefondaki dosya ise önbelleğe kopyalar */
    fun sharableFile(ctx: Context, src: String, fileName: String): File {
        if (!src.startsWith("file:")) return writeCacheFile(ctx, src, fileName)
        val from = File(src.removePrefix("file:"))
        val dir = File(ctx.cacheDir, "media").also { it.mkdirs() }
        val to = File(dir, fileName.replace(Regex("[\\/:*?\"<>|]+"), "_"))
        if (!to.exists() || to.length() != from.length()) from.copyTo(to, overwrite = true)
        return to
    }

    fun mimeOf(dataUrl: String): String =
        if (dataUrl.startsWith("data:")) dataUrl.substringAfter("data:").substringBefore(";").substringBefore(",") else ""

    /** data URL'yi en fazla maxDim piksele küçülterek çözer */
    /** Bellekte hazırsa anında döner (ilk çizimde baş harf yanıp sönmesin) */
    fun peek(dataUrl: String, maxDim: Int): Bitmap? {
        if (dataUrl.isBlank()) return null
        return bitmapCache.get("$maxDim:${dataUrl.length}:${dataUrl.hashCode()}")
    }

    fun decode(dataUrl: String, maxDim: Int): Bitmap? {
        if (dataUrl.isBlank()) return null
        val key = "$maxDim:${dataUrl.length}:${dataUrl.hashCode()}"
        bitmapCache.get(key)?.let { return it }
        return try {
            if (dataUrl.startsWith("file:")) {
                val path = dataUrl.removePrefix("file:")
                val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, b)
                var s = 1
                while (max(b.outWidth, b.outHeight) / s > maxDim * 2) s *= 2
                return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })?.also { bitmapCache.put(key, it) }
            }
            val bytes = bytesOf(dataUrl)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxDim * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)?.also { bitmapCache.put(key, it) }
        } catch (e: Throwable) {
            null
        }
    }

    /** Galeriden/kameradan gelen görseli, belge sınırına (1 MB) sığacak biçimde sıkıştırır */
    fun compress(ctx: Context, uri: Uri, targetBytes: Int): String? {
        return try {
            val cr = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 2048) sample *= 2
            var bmp = cr.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return null

            val orientation = try {
                cr.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (e: Exception) {
                ExifInterface.ORIENTATION_NORMAL
            }
            val rot = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (rot != 0f) {
                val m = Matrix().apply { postRotate(rot) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }

            val maxSide = 1280
            val big = max(bmp.width, bmp.height)
            if (big > maxSide) {
                val f = maxSide.toFloat() / big
                bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * f).toInt().coerceAtLeast(1), (bmp.height * f).toInt().coerceAtLeast(1), true)
            }

            var bytes = ByteArray(0)
            var attempt = 0
            while (true) {
                var q = 85
                var out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, q, out)
                while (out.size() > targetBytes && q > 35) {
                    q -= 10
                    out = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, q, out)
                }
                bytes = out.toByteArray()
                if (bytes.size <= targetBytes || attempt >= 4) break
                attempt++
                bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * 0.8f).toInt().coerceAtLeast(1), (bmp.height * 0.8f).toInt().coerceAtLeast(1), true)
            }
            "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (e: Throwable) {
            null
        }
    }

    /** Alınan fotoğrafı Pictures/AuraChat klasörüne kaydeder (Android 10+) */
    fun saveToGallery(ctx: Context, dataUrl: String, name: String): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val bytes = bytesOf(dataUrl)
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AuraChat")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return false
            true
        } catch (e: Throwable) {
            false
        }
    }

    /** Bitmap'i hedef boyuta (bayt) sığacak biçimde JPEG data URL'ye çevirir */
    fun bitmapToDataUrl(src: Bitmap, targetBytes: Int): String {
        var bmp = src
        var bytes = ByteArray(0)
        var attempt = 0
        while (true) {
            var q = 88
            var out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, q, out)
            while (out.size() > targetBytes && q > 35) {
                q -= 10
                out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, q, out)
            }
            bytes = out.toByteArray()
            if (bytes.size <= targetBytes || attempt >= 4) break
            attempt++
            bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * 0.8f).toInt().coerceAtLeast(1), (bmp.height * 0.8f).toInt().coerceAtLeast(1), true)
        }
        return "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    data class PickedFile(val name: String, val mime: String, val dataUrl: String)

    /** Belge seçimi: 700 KB'a kadar (Firestore belge sınırı) */
    fun readDocument(ctx: Context, uri: Uri): PickedFile? {
        return try {
            val cr = ctx.contentResolver
            var name = "belge"
            cr.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: "belge"
            }
            val mime = cr.getType(uri) ?: "application/octet-stream"
            val bytes = cr.openInputStream(uri)?.use { it.readBytes() } ?: return null
            if (bytes.size > 700 * 1024) return null
            PickedFile(name, mime, "data:$mime;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP))
        } catch (e: Throwable) {
            null
        }
    }

    /** Ses / belge data URL'sini önbellek dosyasına yazar, dosyayı döner */
    fun writeCacheFile(ctx: Context, dataUrl: String, fileName: String): File {
        if (dataUrl.startsWith("file:")) return File(dataUrl.removePrefix("file:"))
        val dir = File(ctx.cacheDir, "media")
        dir.mkdirs()
        val safe = fileName.replace(Regex("[\\\\/:*?\"<>|]+"), "_")
        val f = File(dir, safe)
        if (!f.exists() || f.length() == 0L) f.writeBytes(bytesOf(dataUrl))
        return f
    }

    fun durationMs(file: File): Int {
        return try {
            val r = MediaMetadataRetriever()
            r.setDataSource(file.absolutePath)
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull() ?: 0
            r.release()
            d
        } catch (e: Throwable) {
            0
        }
    }

    fun fileToDataUrl(file: File, mime: String): String =
        "data:$mime;base64," + Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
}

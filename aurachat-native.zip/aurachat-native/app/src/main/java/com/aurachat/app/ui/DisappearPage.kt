package com.aurachat.app.ui

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile

/** Süreli mesajlar ayar sayfası (WhatsApp düzeni): tam ekran, seçince uygular ve kapanır */
@Composable
fun DisappearPage(target: ChatTarget, me: UserProfile, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cur by Repo.disappearFlow(target.chatId).collectAsState(initial = Repo.peekDisappear(target.chatId))
    var info by remember { mutableStateOf(false) }
    var defPage by remember { mutableStateOf(false) }
    // karşı taraf / grup adı canlı: ad değişince bu sayfada da kendiliğinden güncellenir
    val liveOther by remember(target.otherUid) {
        if (target.isGroup) kotlinx.coroutines.flow.flowOf<UserProfile?>(null) else Repo.profileFlow(target.otherUid)
    }.collectAsState(if (target.isGroup) null else Repo.peekProfile(target.otherUid))
    val liveGroup by remember(target.chatId) {
        if (target.isGroup) Repo.groupFlow(target.chatId) else kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.GroupData?>(null)
    }.collectAsState(if (target.isGroup) Repo.peekGroup(target.chatId) else null)
    val shownName = if (target.isGroup) (liveGroup?.name?.takeIf { it.isNotBlank() } ?: target.name) else (liveOther?.name?.takeIf { it.isNotBlank() } ?: target.name)
    var defMs by remember { mutableStateOf(Repo.defaultDisappearMs()) }
    val green = Color(0xFF25D366)
    val page = if (AuraUi.light) Color.White else Color(0xFF0B0F12)
    val h = 3600L * 1000L
    val opts = listOf("24 saat" to 24 * h, "7 gün" to 7 * 24 * h, "90 gün" to 90 * 24 * h, "Kapalı" to 0L)

    Dialog(onDismissRequest = onBack, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        DialogStatusBar(AuraUi.light)
        Column(Modifier.fillMaxSize().background(page).statusBarsPadding().navigationBarsPadding()) {
            // üst bar (WhatsApp ölçüsü: ok merkezi 24dp, başlık 52dp, başlık 20sp / alt yazı 14sp)
            Row(Modifier.fillMaxWidth().height(54.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.offset(x = 0.4.dp)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Spacer(Modifier.width(4.dp))
                Column {
                    Text("Süreli mesajlar", color = AuraWhite, fontSize = 20.sp)
                    Text(if (target.isGroup) shownName else "Siz, " + shownName, color = AuraWhite, fontSize = 14.sp, maxLines = 1)
                }
            }
            Box(Modifier.fillMaxWidth().height(0.5.dp).background(AuraMuted.copy(alpha = 0.25f)))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Box(Modifier.fillMaxWidth().padding(top = 26.dp), contentAlignment = Alignment.Center) { DisappearArt(Modifier.width(176.dp).height(116.dp)) }
                Column(Modifier.padding(start = 24.dp, end = 24.dp, top = 28.dp)) {
                    Text("Bu sohbetteki mesajların kaybolmasını sağlayın", color = AuraMuted, fontSize = 17.sp, lineHeight = 22.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Tutulmadığı takdirde bu sohbetteki yeni mesajlar seçilen sürenin sonunda herkesten kaybolacak.", color = AuraMuted, fontSize = 15.sp, lineHeight = 24.sp)
                    Text(
                        "Daha fazla bilgi", color = green, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { info = true }.padding(vertical = 6.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth().height(0.5.dp).background(AuraMuted.copy(alpha = 0.25f)))
                Text("Mesaj süresi", color = AuraWhite, fontSize = 20.sp, modifier = Modifier.padding(start = 24.dp, top = 22.dp, bottom = 6.dp))
                opts.forEach { (label, ms) ->
                    val on = if (ms == 0L) cur <= 0L else disappearBucket(cur) == ms
                    Row(
                        Modifier.fillMaxWidth().height(49.dp).clickable {
                            Repo.setDisappearAfter(target.chatId, me.name, me.uid, ms, if (target.isGroup) "" else target.otherUid)
                            onBack()
                        }.padding(start = 38.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(20.dp).clip(CircleShape).background(if (on) green else Color.Transparent).then(
                            if (on) Modifier else Modifier.background(Color.Transparent)
                        ), contentAlignment = Alignment.Center) {
                            Canvas(Modifier.size(20.dp)) {
                                drawCircle(if (on) green else AuraMuted.copy(alpha = 0.6f), style = Stroke(width = 2.dp.toPx()))
                                if (on) { drawCircle(page, radius = size.minDimension / 2f - 3.2.dp.toPx()); drawCircle(green, radius = size.minDimension / 2f - 5.2.dp.toPx()) }
                            }
                        }
                        Spacer(Modifier.width(34.dp))
                        Text(label, color = AuraWhite, fontSize = 18.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(0.5.dp).background(AuraMuted.copy(alpha = 0.25f)))
                androidx.compose.foundation.text.ClickableText(
                    text = buildAnnotatedString {
                        withStyle(SpanStyle(color = green)) { append("Varsayılan mesaj sürenizi") }
                        append(" Ayarlar'dan güncelleyebilirsiniz.")
                    },
                    style = androidx.compose.ui.text.TextStyle(color = AuraMuted, fontSize = 16.5.sp, lineHeight = 22.sp),
                    modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 20.dp, bottom = 24.dp),
                    onClick = { off -> if (off < "Varsayılan mesaj sürenizi".length) defPage = true }
                )
            }
        }
    }
    if (defPage) Dialog(onDismissRequest = { defPage = false }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        DialogStatusBar(AuraUi.light)
        DefaultTimerScreen(defMs, onPick = { defMs = it; Repo.setDefaultDisappearMs(it) }, onBack = { defPage = false })
    }
    if (info) AuraAlertDialog(
        onDismissRequest = { info = false }, containerColor = AuraSurface,
        title = { Text("Süreli mesajlar", color = AuraWhite, fontSize = 17.sp) },
        text = { Text("Süre dolunca yeni mesajlar sohbetten herkes için silinir. Önceki mesajlar etkilenmez. Birinin kaydettiği ya da yanıtladığı mesaj, ekran görüntüsü gibi kopyalar silinmeyebilir.", color = AuraMuted, fontSize = 14.sp) },
        confirmButton = { TextButton(onClick = { info = false }) { Text("Tamam", color = AuraGreen) } }
    )
}

/** Kayıtlı süreyi en yakın seçeneğe eşler (24 saat / 7 gün / 90 gün) */
private fun disappearBucket(ms: Long): Long = when {
    ms <= 0L -> 0L
    ms >= 90L * 24 * 3600 * 1000L -> 90L * 24 * 3600 * 1000L
    ms >= 7L * 24 * 3600 * 1000L -> 7L * 24 * 3600 * 1000L
    else -> 24L * 3600 * 1000L
}

/** WhatsApp'takine benzer, kendi çizdiğimiz küçük çizim: yeşil kronometre + balon + baloncuklar */
@Composable
private fun DisappearArt(modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width; val hh = size.height
        val ink = Color(0xFF0B0F12); val green = Color(0xFF25D366); val pale = Color(0xFFD6FBD7); val cream = Color(0xFFFBF3EA)
        // krem konuşma balonu (arkada, sağ üst)
        val bub = Path().apply {
            moveTo(w * 0.52f, hh * 0.02f); lineTo(w * 0.98f, hh * 0.02f); lineTo(w * 0.92f, hh * 0.18f)
            lineTo(w * 0.92f, hh * 0.40f); lineTo(w * 0.74f, hh * 0.55f); lineTo(w * 0.52f, hh * 0.55f); close()
        }
        drawPath(bub, cream)
        // yeşil kronometre
        val c = Offset(w * 0.50f, hh * 0.46f); val r = hh * 0.40f
        drawCircle(green, r, c); drawCircle(ink, r, c, style = Stroke(2.dp.toPx()))
        drawCircle(ink, r * 0.78f, c, style = Stroke(1.5.dp.toPx()))
        listOf(-60f, -30f, 0f, 30f, 60f).forEach { a ->
            val rad = Math.toRadians(a.toDouble()); val p = Offset(c.x + (r * 0.62f * kotlin.math.cos(rad)).toFloat(), c.y + (r * 0.62f * kotlin.math.sin(rad)).toFloat())
            drawCircle(ink, 2.2.dp.toPx(), p, style = Stroke(1.4.dp.toPx()))
        }
        // ibre
        drawLine(ink, c, Offset(c.x - r * 0.25f, c.y + r * 0.18f), strokeWidth = 2.dp.toPx())
        // açık yeşil baloncuklar
        drawCircle(pale, hh * 0.30f, Offset(w * 0.30f, hh * 0.80f)); drawCircle(ink, hh * 0.30f, Offset(w * 0.30f, hh * 0.80f), style = Stroke(0f))
        drawCircle(pale, hh * 0.20f, Offset(w * 0.50f, hh * 0.88f)); drawCircle(ink, hh * 0.20f, Offset(w * 0.50f, hh * 0.88f), style = Stroke(1.5.dp.toPx()))
        drawCircle(pale, hh * 0.13f, Offset(w * 0.12f, hh * 0.18f)); drawCircle(pale, hh * 0.09f, Offset(w * 0.20f, hh * 0.24f)); drawCircle(pale, hh * 0.05f, Offset(w * 0.04f, hh * 0.46f))
    }
}

/** Tam ekran Dialog penceresinde durum çubuğu şeffaf olsun ve simgeler sayfa rengine uysun (açık sayfada koyu simge) */
@Composable
fun DialogStatusBar(lightPage: Boolean) {
    val v = androidx.compose.ui.platform.LocalView.current
    androidx.compose.runtime.SideEffect {
        val w = (v.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
        if (w != null) {
            w.statusBarColor = android.graphics.Color.TRANSPARENT
            w.navigationBarColor = android.graphics.Color.TRANSPARENT
            val ctl = androidx.core.view.WindowCompat.getInsetsController(w, v)
            ctl.isAppearanceLightStatusBars = lightPage
            ctl.isAppearanceLightNavigationBars = lightPage
        }
    }
}

package com.aurachat.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SentimentSatisfiedAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.aurachat.app.data.Media
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import com.google.firebase.firestore.FieldValue
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val SheetBg: Color get() = auraC(0xFF1F2C34)
private val Bubble = Color(0xFF1F2C33)
private val IconGray = Color(0xFF9CA3AF)
private val PencilGreen = Color(0xFF22C55E)

private fun toast(ctx: Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

// ---------------- Avatar değiştirme mantığı (Kamera / Galeri / Sil) ----------------

class AvatarActions(
    val pickGallery: () -> Unit,
    val takeCamera: () -> Unit,
    val remove: () -> Unit,
    val busy: Boolean
)

@Composable
fun rememberAvatarActions(me: UserProfile, onProfile: (UserProfile) -> Unit, onDone: () -> Unit): AvatarActions {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    var cropUri by remember { mutableStateOf<Uri?>(null) }

    fun upload(dataIn: String) {
        scope.launch {
            busy = true
            try {
                val data: String? = dataIn
                if (data == null) {
                    toast(ctx, "Fotoğraf okunamadı")
                } else {
                    onProfile(Repo.updateProfileFields(me, mapOf("avatar" to data)))
                    toast(ctx, "Profil resmi güncellendi")
                    onDone()
                }
            } catch (e: Throwable) {
                toast(ctx, "Kaydedilemedi")
            }
            busy = false
        }
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) cropUri = uri
    }
    var camUri by remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri
        if (ok && u != null) cropUri = u
    }
    val cu = cropUri
    if (cu != null) {
        AvatarCropper(cu, 320, onDone = { d -> cropUri = null; upload(d) }, onCancel = { cropUri = null })
    }
    return AvatarActions(
        pickGallery = { gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
        takeCamera = {
            try {
                val dir = File(ctx.cacheDir, "camera").also { it.mkdirs() }
                val f = File(dir, "avatar_${System.currentTimeMillis()}.jpg")
                val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                camUri = u
                camera.launch(u)
            } catch (e: Throwable) {
                toast(ctx, "Kamera açılamadı")
            }
        },
        remove = {
            scope.launch {
                busy = true
                try {
                    onProfile(Repo.updateProfileFields(me, mapOf("avatar" to FieldValue.delete())))
                    toast(ctx, "Profil resmi silindi")
                    onDone()
                } catch (e: Throwable) {
                    toast(ctx, "Silinemedi")
                }
                busy = false
            }
        },
        busy = busy
    )
}

/** Alttan açılan "Profil resmi" menüsü */
@Composable
fun AvatarSheet(hasAvatar: Boolean, actions: AvatarActions, onDismiss: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(Color(0x99000000)).clickable { onDismiss() })
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(SheetBg).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Box(
                Modifier.align(Alignment.CenterHorizontally).padding(vertical = 6.dp)
                    .width(44.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF4B5961))
            )
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Kapat", tint = Color.White) }
                Text("Profil resmi", color = Color.White, fontSize = 22.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                if (hasAvatar) {
                    IconButton(onClick = { onDismiss(); actions.remove() }) { Icon(Icons.Default.Delete, "Sil", tint = Color.White) }
                } else {
                    Spacer(Modifier.size(48.dp))
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SheetTile("Kamera", Icons.Default.CameraAlt, Modifier.weight(1f)) { onDismiss(); actions.takeCamera() }
                SheetTile("Galeri", Icons.Default.Image, Modifier.weight(1f)) { onDismiss(); actions.pickGallery() }
            }
        }
    }
}

@Composable
private fun SheetTile(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).border(1.dp, Color(0xFF2F3E47), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(vertical = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = PencilGreen, modifier = Modifier.size(34.dp))
        Text(label, color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

// ---------------- Ayarlar ----------------

@Composable
fun SettingsScreen(
    me: UserProfile,
    onBack: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenAbout: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onOpenAppIcon: () -> Unit,
    onOpenBackup: () -> Unit,
    onOpenStorage: () -> Unit = {},
    onDeleteAccount: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val scroll = rememberScrollState()
    val collapsePx = with(androidx.compose.ui.platform.LocalDensity.current) { 190.dp.toPx() }
    val prog = (scroll.value / collapsePx).coerceIn(0f, 1f)
    androidx.compose.runtime.LaunchedEffect(scroll.isScrollInProgress) {
        if (!scroll.isScrollInProgress && scroll.value > 0 && scroll.value < collapsePx.toInt()) {
            val target = if (scroll.value > collapsePx / 2) minOf(collapsePx.toInt(), scroll.maxValue) else 0
            scroll.animateScrollTo(target)
        }
    }
    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
                Text(
                    me.name, color = Color.White, fontSize = 20.sp, maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(start = 8.dp).graphicsLayer { alpha = prog; translationY = (1f - prog) * 12.dp.toPx() }
                )
                IconButton(onClick = onOpenProfile) { Icon(Icons.Default.Edit, "Profili düzenle", tint = Color.White) }
            }
            Column(Modifier.weight(1f).verticalScroll(scroll)) {
            Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 32.dp, start = 24.dp, end = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.clip(RoundedCornerShape(50)).background(Bubble).clickable { onOpenAbout() }
                            .padding(horizontal = 22.dp, vertical = 11.dp)
                    ) {
                        Text(
                            me.about.ifBlank { "Neler oluyor?" },
                            color = if (me.about.isBlank()) Color(0xFF6B7280) else Color(0xFFD1D5DB), fontSize = 17.sp
                        )
                    }
                    Box(Modifier.offset(y = (-6).dp).size(12.dp).rotate(45f).background(Bubble))
                    Spacer(Modifier.height(2.dp))
                }
                Box(Modifier.clip(CircleShape).clickable { onOpenProfile() }) { Avatar(me.name, me.avatar, 136.dp) }
                Text(me.name, color = Color.White, fontSize = 26.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 20.dp))
            }
            SettingsRow(Icons.Default.Lock, "Gizlilik", "Son görülme, okundu bilgisi", onOpenPrivacy)
            SettingsRow(Icons.Default.Palette, "Uygulama ikonu", "Ana ekrandaki simgeyi değiştir", onOpenAppIcon)
            SettingsRow(Icons.Default.Backup, "Sohbet yedeği", "Google Drive'a yedekle ve geri yükle", onOpenBackup)
            SettingsRow(Icons.Default.Storage, "Depolama", "Telefondaki medya dosyaları", onOpenStorage)
            SettingsRow(Icons.Default.Notifications, "Bildirim sesi", "Mesaj bildirimi sesi ve titreşimi") {
                openChannelSettings(ctx, com.aurachat.app.CHANNEL_MESSAGES)
            }
            SettingsRow(Icons.Default.Call, "Arama zil sesi", "Gelen arama sesi ve titreşimi") {
                openChannelSettings(ctx, com.aurachat.app.CHANNEL_CALLS)
            }
            SettingsRow(Icons.Default.DeleteForever, "Hesabı sil", "Hesabın ve verilerin kalıcı olarak silinir", onDeleteAccount)
            }
        }
    }
}

@Composable
private fun SettingsRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = IconGray, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(22.dp))
        Column {
            Text(title, color = Color.White, fontSize = 18.sp)
            Text(sub, color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

// ---------------- Profil ----------------

@Composable
fun ProfileScreen(
    me: UserProfile,
    onProfile: (UserProfile) -> Unit,
    onBack: () -> Unit,
    onOpenPhoto: () -> Unit,
    onOpenAbout: () -> Unit,
    onSignOut: () -> Unit
) {
    var sheet by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(false) }
    val actions = rememberAvatarActions(me, onProfile) { }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val email = FirebaseAuth.getInstance().currentUser?.email ?: ""

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
                Text("Profil", color = Color.White, fontSize = 22.sp, modifier = Modifier.padding(start = 8.dp))
            }
            Box(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 28.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(180.dp)) {
                    Box(Modifier.size(180.dp).clip(CircleShape).clickable { onOpenPhoto() }) { Avatar(me.name, me.avatar, 180.dp) }
                    Box(
                        Modifier.align(Alignment.BottomEnd).size(52.dp).clip(CircleShape).background(PencilGreen)
                            .border(3.dp, AuraBg, CircleShape).clickable { sheet = true },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.CameraAlt, "Profil resmini düzenle", tint = Color.White) }
                }
            }
            ProfileRow(Icons.Default.Person, "Ad", me.name, Color.White, true) { editName = true }
            Text(
                "Bu, kullanıcı adınız veya PIN'iniz değil. Bu ad AuraChat kişilerinize görünür olacaktır.",
                color = Color(0xFF6B7280), fontSize = 15.sp,
                modifier = Modifier.padding(start = 68.dp, end = 20.dp, bottom = 8.dp)
            )
            ProfileRow(
                Icons.Default.Info, "Hakkımda",
                me.about.ifBlank { "Hakkımda bilgisini ayarlayın" },
                if (me.about.isBlank()) PencilGreen else Color.White, true, onOpenAbout
            )
            ProfileRow(Icons.Default.AlternateEmail, "Kullanıcı adı", me.username.ifBlank { email.substringBefore("@").ifBlank { "-" } }, Color.White, false) {}
            ProfileRow(Icons.Default.Call, "Telefon", me.phone.ifBlank { "-" }, Color.White, false) {}
            ProfileRow(Icons.Default.Email, "E-posta", email.ifBlank { "-" }, Color.White, false) {}
            Row(
                Modifier.fillMaxWidth().padding(20.dp).clip(RoundedCornerShape(14.dp))
                    .background(Color(0x1AE11D48)).border(1.dp, Color(0x33E11D48), RoundedCornerShape(14.dp))
                    .clickable { onSignOut() }.padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.AutoMirrored.Filled.ExitToApp, null, tint = Color(0xFFFB7185))
                Spacer(Modifier.width(10.dp))
                Text("Çıkış Yap", color = Color(0xFFFB7185), fontSize = 19.sp)
            }
        }
        if (sheet) AvatarSheet(me.avatar.isNotBlank(), actions) { sheet = false }
        if (actions.busy) {
            Box(Modifier.fillMaxSize().background(Color(0x66000000)), contentAlignment = Alignment.Center) {
                androidx.compose.material3.CircularProgressIndicator(color = AuraGreen)
            }
        }
    }

    if (editName) {
        var v by remember { mutableStateOf(me.name) }
        AlertDialog(
            onDismissRequest = { editName = false },
            containerColor = AuraSurface,
            title = { Text("Adınız", color = Color.White) },
            text = { OutlinedTextField(value = v, onValueChange = { if (it.length <= 25) v = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val n = v.trim()
                    editName = false
                    if (n.isNotEmpty() && n != me.name) {
                        scope.launch {
                            try { onProfile(Repo.updateProfileFields(me, mapOf("name" to n))) } catch (e: Throwable) { toast(ctx, "Kaydedilemedi") }
                        }
                    }
                }) { Text("Kaydet", color = AuraGreen) }
            },
            dismissButton = { TextButton(onClick = { editName = false }) { Text("Vazgeç", color = AuraMuted) } }
        )
    }
}

@Composable
private fun ProfileRow(icon: ImageVector, label: String, value: String, valueColor: Color, editable: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = editable, onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(icon, null, tint = IconGray, modifier = Modifier.padding(top = 4.dp).size(26.dp))
        Spacer(Modifier.width(22.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = AuraMuted, fontSize = 15.sp)
            Text(value, color = valueColor, fontSize = 19.sp, modifier = Modifier.padding(top = 2.dp))
        }
        if (editable) Icon(Icons.Default.Edit, null, tint = PencilGreen, modifier = Modifier.padding(top = 6.dp).size(22.dp))
    }
}

// ---------------- Tam ekran profil resmi ----------------

@Composable
fun ProfilePhotoScreen(me: UserProfile, onProfile: (UserProfile) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var sheet by remember { mutableStateOf(false) }
    val actions = rememberAvatarActions(me, onProfile) { }

    Box(Modifier.fillMaxSize().background(Color(0xFF05080B))) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (me.avatar.isNotBlank()) {
                DataUrlImage(me.avatar, 1600, Modifier.fillMaxWidth(), androidx.compose.ui.layout.ContentScale.FillWidth)
            } else {
                Avatar(me.name, "", 220.dp)
            }
        }
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().height(60.dp).background(Color(0x66000000)).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
            Text("Profil resmi", color = Color.White, fontSize = 22.sp, modifier = Modifier.weight(1f).padding(start = 8.dp))
            IconButton(onClick = { sheet = true }) { Icon(Icons.Default.Edit, "Düzenle", tint = Color.White) }
            IconButton(onClick = {
                if (me.avatar.isBlank()) {
                    toast(ctx, "Paylaşılacak profil resmi yok")
                } else {
                    try {
                        val f = Media.writeCacheFile(ctx, me.avatar, "profil_${me.uid}.jpg")
                        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                        val i = Intent(Intent.ACTION_SEND).apply {
                            type = "image/jpeg"
                            putExtra(Intent.EXTRA_STREAM, u)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(i, "Paylaş"))
                    } catch (e: Throwable) {
                        toast(ctx, "Paylaşılamadı")
                    }
                }
            }) { Icon(Icons.Default.Share, "Paylaş", tint = Color.White) }
        }
        if (sheet) AvatarSheet(me.avatar.isNotBlank(), actions) { sheet = false }
    }
}

// ---------------- Hakkımda ----------------

private val SUGGESTIONS = listOf(
    "" to "Bir varmış, bir yokmuş",
    "🌙" to "Uzakta, mesaj bırak",
    "😴" to "Uyuyorum",
    "💼" to "İşyerinde",
    "✈️" to "Seyahat ediyorum",
    "💪" to "Spor Salonunda"
)

@Composable
fun AboutScreen(me: UserProfile, onProfile: (UserProfile) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf(me.about) }
    var saving by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
                Text("Hakkımda", color = Color.White, fontSize = 22.sp, modifier = Modifier.padding(start = 8.dp))
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp).clip(RoundedCornerShape(14.dp))
                    .border(2.dp, Color(0xFF4B5563), RoundedCornerShape(14.dp)).padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.SentimentSatisfiedAlt, null, tint = PencilGreen, modifier = Modifier.size(34.dp))
                Spacer(Modifier.width(14.dp))
                Box(Modifier.weight(1f)) {
                    if (text.isEmpty()) Text("Neler oluyor?", color = AuraMuted, fontSize = 20.sp)
                    BasicTextField(
                        value = text, onValueChange = { if (it.length <= 139) text = it },
                        textStyle = TextStyle(color = Color.White, fontSize = 20.sp),
                        cursorBrush = SolidColor(PencilGreen), modifier = Modifier.fillMaxWidth()
                    )
                }
                if (text.isNotEmpty()) {
                    Icon(Icons.Default.Cancel, "Temizle", tint = AuraMuted, modifier = Modifier.size(32.dp).clickable { text = "" })
                }
            }
            Text("Öneriler", color = AuraMuted, fontSize = 18.sp, modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 6.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                SUGGESTIONS.forEach { (emoji, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { text = label }.padding(horizontal = 16.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(emoji, fontSize = 28.sp, modifier = Modifier.width(56.dp))
                        Text(label, color = Color.White, fontSize = 20.sp, modifier = Modifier.weight(1f))
                        if (text == label) Icon(Icons.Default.Check, null, tint = PencilGreen)
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.End) {
                FloatingActionButton(
                    onClick = {
                        if (!saving) {
                            saving = true
                            scope.launch {
                                try {
                                    onProfile(Repo.updateProfileFields(me, mapOf("about" to text.trim())))
                                    onBack()
                                } catch (e: Throwable) {
                                    toast(ctx, "Kaydedilemedi")
                                }
                                saving = false
                            }
                        }
                    },
                    containerColor = PencilGreen, contentColor = Color.White, shape = CircleShape
                ) { Icon(Icons.Default.Check, "Kaydet", modifier = Modifier.size(30.dp)) }
            }
        }
    }
}

// ---------------- Gizlilik ----------------

@Composable
fun PrivacyScreen(me: UserProfile, onBack: () -> Unit) {
    var presenceOn by remember { mutableStateOf(!Repo.isPresenceHidden()) }
    var receiptsOn by remember { mutableStateOf(!Repo.isReceiptsHidden()) }
    val pctx = LocalContext.current
    val psp = remember { pctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE) }
    var lockOn by remember { mutableStateOf(psp.getBoolean("applock", false)) }
    var keepArch by remember { mutableStateOf(psp.getBoolean("arch_keep", false)) }
    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
                Text("Gizlilik", color = Color.White, fontSize = 22.sp, modifier = Modifier.padding(start = 8.dp))
            }
            PrivacyRow(Icons.Default.Visibility, "Son görülme", "Kapalıyken kimse son görülmeni görmez", presenceOn) {
                presenceOn = it
                Repo.setPresenceHidden(me.uid, !it)
            }
            PrivacyRow(Icons.Default.DoneAll, "Okundu bilgisi", "Kapalıyken okundu tikini ne sen gönderirsin ne de görürsün", receiptsOn) {
                receiptsOn = it
                Repo.setReceiptsHidden(me.uid, !it)
            }
            PrivacyRow(Icons.Default.Lock, "Uygulama kilidi", "Uygulamayı açarken telefonun ekran kilidi (parmak izi, PIN) istenir", lockOn) {
                val km = pctx.getSystemService(android.content.Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
                if (it && !km.isDeviceSecure) {
                    android.widget.Toast.makeText(pctx, "Önce telefona ekran kilidi koy", android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    lockOn = it
                    psp.edit().putBoolean("applock", it).apply()
                }
            }
            PrivacyRow(Icons.Default.Archive, "Sohbetleri arşivde tut", "Açıkken yeni mesaj gelse de arşivlenen sohbet arşivde kalır", keepArch) {
                keepArch = it
                psp.edit().putBoolean("arch_keep", it).apply()
            }
            val blocked by remember(me.uid) { Repo.blockedFlow(me.uid) }.collectAsState(emptyList())
            Text("Engellenen kişiler", color = AuraBtn, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 6.dp))
            if (blocked.isEmpty()) {
                Text("Kimseyi engellemedin", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            } else {
                Column {
                    blocked.forEach { uid ->
                        val lp by liveProfile(uid)
                        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar((lp?.name ?: "").ifBlank { "?" }, lp?.avatar ?: "", 44.dp)
                            Text((lp?.name ?: "").ifBlank { "Kullanıcı" }, color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f).padding(start = 14.dp))
                            Text(
                                "Engeli kaldır", color = AuraGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { Repo.setBlocked(me.uid, uid, false) }.padding(8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PrivacyRow(icon: ImageVector, title: String, desc: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!on) }.padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = IconGray, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(22.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 18.sp)
            Text(desc, color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
        }
        Switch(
            checked = on, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = AuraBtn, checkedThumbColor = Color.White)
        )
    }
}

private fun openChannelSettings(ctx: android.content.Context, channel: String) {
    try {
        val i = android.content.Intent(
            if (android.os.Build.VERSION.SDK_INT >= 26) android.provider.Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS
            else android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS
        ).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            .putExtra(android.provider.Settings.EXTRA_CHANNEL_ID, channel)
        ctx.startActivity(i)
    } catch (e: Throwable) {}
}

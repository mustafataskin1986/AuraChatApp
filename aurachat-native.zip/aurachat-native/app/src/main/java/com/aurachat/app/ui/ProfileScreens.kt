package com.aurachat.app.ui

import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.zIndex
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.focus.focusRequester
import androidx.compose.runtime.LaunchedEffect
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SentimentSatisfiedAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.layout
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.aurachat.app.data.Media
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import com.google.firebase.firestore.FieldValue
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val SheetBg: Color get() = auraC(0xFF1F2C34)
private val Bubble: Color @Composable get() = AuraBg
private val IconGray: Color get() = auraLc(0xFF9CA3AF)
private val PencilGreen: Color get() = AuraUi.accentColor() ?: auraLc(0xFF22C55E)

private fun toast(ctx: Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

// ---------------- Avatar değiştirme mantığı (Kamera / Galeri / Sil) ----------------

class AvatarActions(
    val pickGallery: () -> Unit,
    val takeCamera: () -> Unit,
    val remove: () -> Unit,
    val busy: Boolean
)

@Composable
fun rememberAvatarActions(me: UserProfile, onProfile: (UserProfile) -> Unit, onDone: () -> Unit): AvatarActions {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    var cropUri by remember { mutableStateOf<Uri?>(null) }

    fun upload(dataIn: String) {
        scope.launch {
            busy = true
            try {
                val data: String? = dataIn
                if (data == null) {
                    toast(ctx, "Fotoğraf okunamadı")
                } else {
                    onProfile(Repo.updateProfileFields(me, mapOf("avatar" to data)))
                    toast(ctx, "Profil resmi güncellendi")
                    onDone()
                }
            } catch (e: Throwable) {
                toast(ctx, "Kaydedilemedi")
            }
            busy = false
        }
    }

    var pickerOpen by remember { mutableStateOf(false) }
    if (pickerOpen) PhotoPickerScreen(onClose = { pickerOpen = false }, onPick = { pickerOpen = false; cropUri = it })
    var camUri by remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri
        if (ok && u != null) cropUri = u
    }
    val cu = cropUri
    if (cu != null) {
        AvatarCropper(cu, 320, onDone = { d -> cropUri = null; upload(d) }, onCancel = { cropUri = null })
    }
    return AvatarActions(
        pickGallery = { pickerOpen = true },
        takeCamera = {
            try {
                val dir = File(ctx.cacheDir, "camera").also { it.mkdirs() }
                val f = File(dir, "avatar_${System.currentTimeMillis()}.jpg")
                val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                camUri = u
                camera.launch(u)
            } catch (e: Throwable) {
                toast(ctx, "Kamera açılamadı")
            }
        },
        remove = {
            scope.launch {
                busy = true
                try {
                    onProfile(Repo.updateProfileFields(me, mapOf("avatar" to FieldValue.delete())))
                    toast(ctx, "Profil resmi silindi")
                    onDone()
                } catch (e: Throwable) {
                    toast(ctx, "Silinemedi")
                }
                busy = false
            }
        },
        busy = busy
    )
}

/** Alttan açılan "Profil resmi" menüsü */
@Composable
fun AvatarSheet(hasAvatar: Boolean, actions: AvatarActions, onDismiss: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(auraLc(0x99000000)).clickable { onDismiss() })
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(SheetBg).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Box(
                Modifier.align(Alignment.CenterHorizontally).padding(vertical = 6.dp)
                    .width(44.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(auraLc(0xFF4B5961))
            )
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Kapat", tint = AuraWhite) }
                Text("Profil resmi", color = AuraWhite, fontSize = 22.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                if (hasAvatar) {
                    IconButton(onClick = { onDismiss(); actions.remove() }) { Icon(Icons.Default.Delete, "Sil", tint = AuraWhite) }
                } else {
                    Spacer(Modifier.size(48.dp))
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SheetTile("Kamera", Icons.Default.CameraAlt, Modifier.weight(1f)) { onDismiss(); actions.takeCamera() }
                SheetTile("Galeri", Icons.Default.Image, Modifier.weight(1f)) { onDismiss(); actions.pickGallery() }
            }
        }
    }
}

@Composable
private fun SheetTile(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).border(1.dp, auraLc(0xFF2F3E47), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(vertical = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = PencilGreen, modifier = Modifier.size(34.dp))
        Text(label, color = AuraWhite, fontSize = 18.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

// ---------------- Ayarlar ----------------

@Composable
fun SettingsScreen(
    me: UserProfile,
    onBack: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenAbout: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onOpenAppIcon: () -> Unit,
    onOpenFont: () -> Unit,
    onOpenBackup: () -> Unit,
    onOpenStorage: () -> Unit = {},
    onOpenQr: () -> Unit = {},
    onOpenInvite: () -> Unit = {},
    onDeleteAccount: () -> Unit = {}
) {
    val ctx = LocalContext.current
    val scroll = rememberScrollState()
    val collapsePx = with(androidx.compose.ui.platform.LocalDensity.current) { 190.dp.toPx() }
    val prog = (scroll.value / collapsePx).coerceIn(0f, 1f)
    androidx.compose.runtime.LaunchedEffect(scroll.isScrollInProgress) {
        if (!scroll.isScrollInProgress && scroll.value > 0 && scroll.value < collapsePx.toInt()) {
            val target = if (scroll.value > collapsePx / 2) minOf(collapsePx.toInt(), scroll.maxValue) else 0
            scroll.animateScrollTo(target)
        }
    }
    val dens = androidx.compose.ui.platform.LocalDensity.current
    var bubbleExtraPx by remember { mutableStateOf(0) }
    var searchOpen by remember { mutableStateOf(false) }
    var sq by remember { mutableStateOf("") }
    var themeDlg by remember { mutableStateOf(false) }
    val items = listOf(
        listOf<Any>(Icons.Default.Lock, "Gizlilik", "Son görülme, okundu bilgisi", onOpenPrivacy),
        listOf<Any>(Icons.Default.Palette, "Uygulama ikonu", "Ana ekrandaki simgeyi değiştir", onOpenAppIcon),
        listOf<Any>(Icons.Default.Brightness6, "Uygulama teması", "Sistem, aydınlık, karanlık ve vurgu rengi", { themeDlg = true }),
        listOf<Any>(Icons.Default.TextFields, "Yazı boyutu ve stili", "Yazı boyutunu ve yazı tipini değiştir", onOpenFont),
        listOf<Any>(Icons.Default.Backup, "Sohbet yedeği", "Google Drive'a yedekle ve geri yükle", onOpenBackup),
        listOf<Any>(Icons.Default.Storage, "Depolama", "Telefondaki medya dosyaları", onOpenStorage),
        listOf<Any>(Icons.Default.Notifications, "Bildirim sesi", "Mesaj bildirimi sesi ve titreşimi", { openChannelSettings(ctx, com.aurachat.app.CHANNEL_MESSAGES) }),
        listOf<Any>(Icons.Default.Call, "Arama zil sesi", "Gelen arama sesi ve titreşimi", { openChannelSettings(ctx, com.aurachat.app.CHANNEL_CALLS) }),
        listOf<Any>(Icons.Default.Group, "Arkadaşlarınızı davet edin", "", onOpenInvite)
    )
    Box(Modifier.fillMaxSize().background(AuraBg)) {
        // WhatsApp gibi doodle desenli üst kapak: kaydırınca yukarı kayar; balon uzadıkça kapak da uzar
        ProfileCover(me.avatar, AuraBg, prog, scroll.value.toFloat(), Modifier.fillMaxWidth().statusBarsPadding().height(198.dp + with(dens) { bubbleExtraPx.toDp() }))
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Column(Modifier.weight(1f).verticalScroll(scroll)) {
            Spacer(Modifier.height(60.dp))
            Column(
                Modifier.fillMaxWidth()
                    .layout { m, c -> val pl = m.measure(c); val up = 20.dp.roundToPx(); layout(pl.width, pl.height - up) { pl.place(0, -up) } }   // başlık bloğu 20 dp yukarı
                    .padding(top = 18.dp, bottom = 32.dp, start = 24.dp, end = 24.dp), horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Sabit yükseklikli yuva: balon alttan sabit, metin uzadıkça yukarı büyür; avatar yerinde kalır
                Box(Modifier.fillMaxWidth().zIndex(1f), contentAlignment = Alignment.TopCenter) {
                    Column(
                        Modifier,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val bShape = RoundedCornerShape(28.dp)
                        val maxW = (androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp * 0.5f).dp
                        Box(
                            Modifier.widthIn(max = maxW)
                                .shadow(if (AuraUi.light) 4.dp else 3.dp, bShape, clip = false)
                                .onSizeChanged { bubbleExtraPx = (it.height - with(dens) { 38.dp.roundToPx() }).coerceAtLeast(0) }
                                .clip(bShape).background(Bubble).clickable { onOpenAbout() }
                                .padding(horizontal = 11.dp, vertical = 11.dp)
                        ) {
                            var fs by androidx.compose.runtime.remember(me.about) { androidx.compose.runtime.mutableStateOf(12.5f) }
                            Text(
                                me.about.ifBlank { "Neler oluyor?" },
                                color = if (me.about.isBlank()) ChipLook.inputFg else AuraWhite, fontSize = fs.sp, lineHeight = (fs * 1.22f).sp,
                                textAlign = TextAlign.Center, maxLines = 3, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                onTextLayout = { if (it.hasVisualOverflow && fs > 8f) fs -= 0.5f }
                            )
                        }
                        // WhatsApp kuyruğu: balonun altında sol tarafta küçük çıkıntı + avatarın üstüne binen nokta
                        Box(Modifier.fillMaxWidth().height(0.dp), contentAlignment = Alignment.TopCenter) {
                            Box(Modifier.offset(x = (-40).dp, y = (-6).dp).requiredSize(10.dp).clip(CircleShape).background(Bubble))
                            Box(Modifier.offset(x = (-27).dp, y = 4.dp).requiredSize(8.dp).clip(CircleShape).background(Bubble))
                        }
                    }
                }
                Box(Modifier.size(128.dp).clip(CircleShape).background(AuraBg).clickable { onOpenProfile() }, contentAlignment = Alignment.Center) { Avatar(me.name, me.avatar, 120.dp) }
                Text(me.name, color = AuraWhite, fontSize = 26.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
            }
            items.forEach { SettingsRow(it[0] as ImageVector, it[1] as String, it[2] as String, it[3] as () -> Unit) }
            }
        }
        Box(Modifier.statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(60.dp).background(AuraBg.copy(alpha = ((scroll.value - collapsePx * 0.8f) / (collapsePx * 0.45f)).coerceIn(0f, 1f))).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Box(Modifier.weight(1f).fillMaxHeight().clipToBounds(), contentAlignment = Alignment.CenterStart) {
                    Text(
                        me.name, color = AuraWhite, fontSize = 20.sp, maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = 8.dp).graphicsLayer {
                            val a = ((prog - 0.25f) / 0.75f).coerceIn(0f, 1f)
                            alpha = a
                        }
                    )
                }
                IconButton(onClick = { sq = ""; searchOpen = true }) { Icon(Icons.Default.Search, "Ara", tint = AuraWhite) }
                IconButton(onClick = onOpenQr) { Icon(Icons.Default.QrCode2, "QR kod", tint = AuraWhite) }
                IconButton(onClick = onOpenProfile) { Icon(Icons.Default.Edit, "Profili düzenle", tint = AuraWhite) }
            }
        }
        if (themeDlg) AppThemePanel { themeDlg = false }
        if (searchOpen) {
            androidx.activity.compose.BackHandler { searchOpen = false }
            val fr = remember { androidx.compose.ui.focus.FocusRequester() }
            androidx.compose.runtime.LaunchedEffect(Unit) { fr.requestFocus() }
            Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).height(56.dp).clip(RoundedCornerShape(28.dp)).background(ChipLook.glass).padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = ChipLook.inputFg, modifier = Modifier.size(26.dp).clip(CircleShape).clickable { searchOpen = false })
                    Spacer(Modifier.width(16.dp))
                    Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                        if (sq.isEmpty()) Text("Ara…", color = ChipLook.inputFg, fontSize = 18.sp)
                        androidx.compose.foundation.text.BasicTextField(
                            value = sq, onValueChange = { sq = it }, singleLine = true,
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Sentences),
                            textStyle = TextStyle(color = ChipLook.inputFg, fontSize = 18.sp),
                            cursorBrush = SolidColor(ChipLook.inputFg),
                            modifier = Modifier.fillMaxWidth().focusRequester(fr)
                        )
                    }
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    val q = sq.trim()
                    items.filter { q.isEmpty() || (it[1] as String).contains(q, ignoreCase = true) || (it[2] as String).contains(q, ignoreCase = true) }
                        .forEach { SettingsRow(it[0] as ImageVector, it[1] as String, it[2] as String, it[3] as () -> Unit) }
                }
            }
        }
    }
}

@Composable
private fun SettingsRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = IconGray, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(22.dp))
        Column {
            Text(title, color = AuraWhite, fontSize = 18.sp)
            if (sub.isNotBlank()) Text(sub, color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

// ---------------- Profil ----------------

@Composable
fun ProfileScreen(
    me: UserProfile,
    onProfile: (UserProfile) -> Unit,
    onBack: () -> Unit,
    onOpenPhoto: () -> Unit,
    onOpenAbout: () -> Unit,
    onSignOut: () -> Unit
) {
    var sheet by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(false) }
    val actions = rememberAvatarActions(me, onProfile) { }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val email = FirebaseAuth.getInstance().currentUser?.email ?: ""

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Text("Profil", color = AuraWhite, fontSize = 22.sp, modifier = Modifier.padding(start = 8.dp))
            }
            Box(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 28.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(180.dp)) {
                    Box(Modifier.size(180.dp).clip(CircleShape).clickable { onOpenPhoto() }) { Avatar(me.name, me.avatar, 180.dp) }
                    Box(
                        Modifier.align(Alignment.BottomEnd).size(52.dp).clip(CircleShape).background(PencilGreen)
                            .border(3.dp, AuraBg, CircleShape).clickable { sheet = true },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.CameraAlt, "Profil resmini düzenle", tint = Color.White) }
                }
            }
            ProfileRow(Icons.Default.Person, "Ad", me.name, AuraWhite, true) { editName = true }
            Text(
                "Bu, kullanıcı adınız veya PIN'iniz değil. Bu ad AuraChat kişilerinize görünür olacaktır.",
                color = auraLc(0xFF6B7280), fontSize = 15.sp,
                modifier = Modifier.padding(start = 68.dp, end = 20.dp, bottom = 8.dp)
            )
            ProfileRow(
                Icons.Default.Info, "Hakkımda",
                me.about.ifBlank { "Hakkımda bilgisini ayarlayın" },
                if (me.about.isBlank()) PencilGreen else AuraWhite, true, onOpenAbout
            )
            ProfileRow(Icons.Default.AlternateEmail, "Kullanıcı adı", me.username.ifBlank { email.substringBefore("@").ifBlank { "-" } }, AuraWhite, false) {}
            ProfileRow(Icons.Default.Call, "Telefon", me.phone.ifBlank { "-" }, AuraWhite, false) {}
            ProfileRow(Icons.Default.Email, "E-posta", email.ifBlank { "-" }, AuraWhite, false) {}
            Row(
                Modifier.fillMaxWidth().padding(20.dp).clip(RoundedCornerShape(14.dp))
                    .background(auraLc(0x1AE11D48)).border(1.dp, auraLc(0x33E11D48), RoundedCornerShape(14.dp))
                    .clickable { onSignOut() }.padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.AutoMirrored.Filled.ExitToApp, null, tint = auraLc(0xFFFB7185))
                Spacer(Modifier.width(10.dp))
                Text("Çıkış Yap", color = auraLc(0xFFFB7185), fontSize = 19.sp)
            }
        }
        if (sheet) AvatarSheet(me.avatar.isNotBlank(), actions) { sheet = false }
        if (actions.busy) {
            Box(Modifier.fillMaxSize().background(auraLc(0x66000000)), contentAlignment = Alignment.Center) {
                androidx.compose.material3.CircularProgressIndicator(color = AuraGreen)
            }
        }
    }

    if (editName) {
        NameEditPage(
            initial = me.name,
            onBack = { editName = false },
            onSave = { n ->
                editName = false
                if (n.isNotEmpty() && n != me.name) {
                    scope.launch {
                        try { onProfile(Repo.updateProfileFields(me, mapOf("name" to n))) } catch (e: Throwable) { toast(ctx, "Kaydedilemedi") }
                    }
                }
            }
        )
    }
}

/** Ad değiştirme sayfası (tam ekran). Zemin, "AuraChat" başlığına dokununca değişen tema rengini izler */
@Composable
private fun NameEditPage(initial: String, onBack: () -> Unit, onSave: (String) -> Unit) {
    var v by remember { mutableStateOf(androidx.compose.ui.text.input.TextFieldValue(initial, androidx.compose.ui.text.TextRange(initial.length))) }
    val focus = remember { androidx.compose.ui.focus.FocusRequester() }
    androidx.activity.compose.BackHandler { onBack() }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ProfileScreens", e) } }
    Box(
        Modifier.fillMaxSize().background(AuraChatBg)
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Text("Ad", color = AuraWhite, fontSize = 22.sp, modifier = Modifier.padding(start = 8.dp))
            }
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
                Box(
                    Modifier.fillMaxWidth().padding(top = 8.dp).height(56.dp)
                        .border(2.dp, AuraBorder, RoundedCornerShape(12.dp)).padding(horizontal = 16.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    androidx.compose.foundation.text.BasicTextField(
                        value = v,
                        onValueChange = { if (it.text.length <= 25) v = it },
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = AuraWhite, fontSize = 19.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(AuraBorder),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Done, capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Sentences),
                        keyboardActions = androidx.compose.foundation.text.KeyboardActions(onDone = { onSave(v.text.trim()) }),
                        modifier = Modifier.fillMaxWidth().focusRequester(focus)
                    )
                }
                Text(
                    "Adınız", color = AuraWhite, fontSize = 14.sp,
                    modifier = Modifier.padding(start = 14.dp).background(AuraChatBg).padding(horizontal = 4.dp)
                )
            }
            Text(
                "${v.text.length}/25", color = AuraMuted, fontSize = 15.sp,
                modifier = Modifier.fillMaxWidth().padding(end = 32.dp, top = 8.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End
            )
            Text(
                "AuraChat'taki kişiler ve katılmaya davet ettiğiniz kişiler adınızı görecek.",
                color = AuraMuted, fontSize = 17.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
            )
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 14.dp).height(52.dp)
                    .clip(RoundedCornerShape(50)).background(AuraGreen).clickable { onSave(v.text.trim()) },
                contentAlignment = Alignment.Center
            ) { Text("Kaydet", color = Color.White, fontSize = 18.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium) }
        }
    }
}

@Composable
private fun ProfileRow(icon: ImageVector, label: String, value: String, valueColor: Color, editable: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = editable, onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(icon, null, tint = IconGray, modifier = Modifier.padding(top = 4.dp).size(26.dp))
        Spacer(Modifier.width(22.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = AuraMuted, fontSize = 15.sp)
            Text(value, color = valueColor, fontSize = 19.sp, modifier = Modifier.padding(top = 2.dp))
        }
        if (editable) Icon(Icons.Default.Edit, null, tint = PencilGreen, modifier = Modifier.padding(top = 6.dp).size(22.dp))
    }
}

// ---------------- Tam ekran profil resmi ----------------

@Composable
fun ProfilePhotoScreen(me: UserProfile, onProfile: (UserProfile) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var sheet by remember { mutableStateOf(false) }
    val actions = rememberAvatarActions(me, onProfile) { }
    ForceLightBarIcons()

    Box(Modifier.fillMaxSize().background(Color(0xFF05080B))) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (me.avatar.isNotBlank()) {
                DataUrlImage(me.avatar, 1600, Modifier.fillMaxWidth(), androidx.compose.ui.layout.ContentScale.FillWidth)
            } else {
                Avatar(me.name, "", 220.dp)
            }
        }
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().height(60.dp).background(Color(0x66000000)).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
            Text("Profil resmi", color = Color.White, fontSize = 22.sp, modifier = Modifier.weight(1f).padding(start = 8.dp))
            IconButton(onClick = { sheet = true }) { Icon(Icons.Default.Edit, "Düzenle", tint = Color.White) }
            IconButton(onClick = {
                if (me.avatar.isBlank()) {
                    toast(ctx, "Paylaşılacak profil resmi yok")
                } else {
                    try {
                        val f = Media.writeCacheFile(ctx, me.avatar, "profil_${me.uid}.jpg")
                        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                        val i = Intent(Intent.ACTION_SEND).apply {
                            type = "image/jpeg"
                            putExtra(Intent.EXTRA_STREAM, u)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(i, "Paylaş"))
                    } catch (e: Throwable) {
                        toast(ctx, "Paylaşılamadı")
                    }
                }
            }) { Icon(Icons.Default.Share, "Paylaş", tint = Color.White) }
        }
        if (sheet) AvatarSheet(me.avatar.isNotBlank(), actions) { sheet = false }
    }
}

// ---------------- Hakkımda ----------------

private val SUGGESTIONS = listOf(
    "" to "Bir varmış, bir yokmuş",
    "🌙" to "Uzakta, mesaj bırak",
    "😴" to "Uyuyorum",
    "💼" to "İşyerinde",
    "✈️" to "Seyahat ediyorum",
    "💪" to "Spor Salonunda"
)

@Composable
fun AboutScreen(me: UserProfile, onProfile: (UserProfile) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val limit = 139
    var text by remember { mutableStateOf(me.about) }
    var saving by remember { mutableStateOf(false) }
    var focused by remember { mutableStateOf(false) }
    var previewOpen by remember { mutableStateOf(true) }
    val aboutPrefs = remember { ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE) }
    var hist by remember { mutableStateOf(aboutPrefs.getString("about_hist", "").orEmpty().split('\u0001').filter { it.isNotBlank() }) }
    var expIdx by remember { mutableStateOf(aboutPrefs.getInt("about_exp", 0)) }
    var audIdx by remember { mutableStateOf(aboutPrefs.getInt("about_aud", 0)) }
    val expLabels = listOf("1 gün", "7 gün", "30 gün", "Süresiz")
    val expHours = listOf(24L, 168L, 720L, 0L)
    val audLabels = listOf("Herkes", "Kişilerim", "Hiç kimse")
    val remaining = limit - text.length
    val canSave = remaining >= 0 && !saving
    val expDate = remember(expIdx, text) {
        if (expHours[expIdx] == 0L) null
        else java.text.SimpleDateFormat("d MMM, HH:mm", java.util.Locale("tr")).format(java.util.Date(System.currentTimeMillis() + expHours[expIdx] * 3600_000L))
    }

    fun doSave() {
        if (!canSave) return
        saving = true
        scope.launch {
            try {
                val t = text.trim()
                val fields = mutableMapOf<String, Any>(
                    "about" to t,
                    "aboutAudience" to audLabels[audIdx],
                    "aboutExpiresAt" to (if (expHours[expIdx] == 0L) 0L else System.currentTimeMillis() + expHours[expIdx] * 3600_000L)
                )
                onProfile(Repo.updateProfileFields(me, fields))
                if (t.isNotEmpty()) {
                    val nh = (listOf(t) + hist.filter { it != t }).take(20)
                    hist = nh
                    aboutPrefs.edit().putString("about_hist", nh.joinToString("\u0001")).apply()
                }
                aboutPrefs.edit().putInt("about_exp", expIdx).putInt("about_aud", audIdx).apply()
                onBack()
            } catch (e: Throwable) {
                toast(ctx, "Kaydedilemedi")
            }
            saving = false
        }
    }

    var showEmoji by remember { mutableStateOf(false) }
    if (showEmoji) ReactEmojiPicker(onPick = { text += it }, onDismiss = { showEmoji = false })
    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Text("Hakkımda", color = AuraWhite, fontSize = 20.sp, modifier = Modifier.padding(start = 8.dp))
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp).clip(RoundedCornerShape(14.dp))
                    .border(2.dp, if (focused) PencilGreen else auraLc(0xFF4B5563), RoundedCornerShape(14.dp)).padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.SentimentSatisfiedAlt, "Emoji", tint = PencilGreen, modifier = Modifier.size(34.dp).clip(CircleShape).clickable { showEmoji = true })
                Spacer(Modifier.width(14.dp))
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (text.isEmpty()) Text("Neler oluyor?", color = AuraMuted, fontSize = 16.sp)
                    AuraTextField(
                        value = text, onValueChange = { text = it },
                        textStyle = TextStyle(color = AuraWhite, fontSize = 16.sp),
                        singleLine = true,
                        cursorBrush = SolidColor(PencilGreen),
                        modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused }
                    )
                }
                if (text.isNotEmpty()) {
                    Icon(Icons.Default.Cancel, "Temizle", tint = AuraMuted, modifier = Modifier.padding(start = 8.dp).size(32.dp).clickable { text = "" })
                }
            }
            Text(
                remaining.toString(), color = if (remaining < 0) auraLc(0xFFEF4444) else AuraMuted, fontSize = 14.sp,
                modifier = Modifier.align(Alignment.End).padding(end = 20.dp)
            )
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                var expMenu by remember { mutableStateOf(false) }
                var audMenu by remember { mutableStateOf(false) }
                Box {
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).border(1.dp, auraLc(0xFF4B5563), RoundedCornerShape(50)).clickable { expMenu = true }.padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Schedule, null, tint = AuraWhite, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(if (text.trim() != me.about.trim() && expDate != null) expDate else expLabels[expIdx], color = AuraWhite, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Icon(Icons.Default.ArrowDropDown, null, tint = AuraWhite)
                    }
                    AuraDropdownMenu(expanded = expMenu, alignEnd = false, onDismissRequest = { expMenu = false }, shape = RoundedCornerShape(16.dp), containerColor = AuraSurface) {
                        expLabels.forEachIndexed { i, l ->
                            androidx.compose.material3.DropdownMenuItem(text = { Text(l, color = AuraWhite, fontSize = 15.sp) }, onClick = { expIdx = i; expMenu = false })
                        }
                    }
                }
                Box {
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).border(1.dp, auraLc(0xFF4B5563), RoundedCornerShape(50)).clickable { audMenu = true }.padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Contacts, null, tint = AuraWhite, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(audLabels[audIdx], color = AuraWhite, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Icon(Icons.Default.ArrowDropDown, null, tint = AuraWhite)
                    }
                    AuraDropdownMenu(expanded = audMenu, alignEnd = false, onDismissRequest = { audMenu = false }, shape = RoundedCornerShape(16.dp), containerColor = AuraSurface) {
                        audLabels.forEachIndexed { i, l ->
                            androidx.compose.material3.DropdownMenuItem(text = { Text(l, color = AuraWhite, fontSize = 15.sp) }, onClick = { audIdx = i; audMenu = false })
                        }
                    }
                }
            }
            Text("Öneriler", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 6.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                hist.forEach { label ->
                    Row(
                        Modifier.fillMaxWidth().clickable { text = label }.padding(horizontal = 16.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Spacer(Modifier.width(56.dp))
                        Text(label, color = AuraWhite, fontSize = 16.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        if (text == label) Icon(Icons.Default.Check, null, tint = PencilGreen)
                    }
                }
                SUGGESTIONS.forEach { (emoji, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { text = label }.padding(horizontal = 16.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(emoji, fontSize = 22.sp, modifier = Modifier.width(56.dp))
                        Text(label, color = AuraWhite, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        if (text == label) Icon(Icons.Default.Check, null, tint = PencilGreen)
                    }
                }
            }
            // Önizleme paneli (WhatsApp): üstü yuvarlak, sağ üstte onay; açılınca sohbet başlığı + balon önizlemesi
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)).background(AuraSurface).padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { previewOpen = !previewOpen }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Önizleme", color = AuraMuted, fontSize = 15.sp)
                        Icon(if (previewOpen) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowUp, null, tint = AuraMuted, modifier = Modifier.padding(start = 6.dp))
                    }
                    Box(
                        Modifier.size(48.dp).clip(CircleShape).background(if (canSave) PencilGreen else Color.Transparent).clickable(enabled = canSave) { doSave() },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Check, "Kaydet", tint = if (canSave) Color.White else AuraMuted.copy(alpha = 0.6f), modifier = Modifier.size(30.dp)) }
                }
                if (previewOpen) {
                    val shown = text.trim().ifBlank { "Neler oluyor?" }
                    Box(
                        Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp)).background(AuraBg)
                            .border(1.dp, AuraMuted.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                    ) {
                        Box(Modifier.matchParentSize().doodleCover(AuraMuted.copy(alpha = 0.18f), Color.Transparent))
                        Column {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Avatar(me.name, me.avatar, 52.dp)
                                Spacer(Modifier.width(14.dp))
                                Column {
                                    Text(me.name, color = AuraWhite, fontSize = 17.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                    Text("Hakkımda bilginizin sohbetlerde diğer kullanıcılara görünür", color = AuraWhite, fontSize = 12.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                }
                            }
                            Box(Modifier.padding(start = 12.dp, top = 2.dp, bottom = 14.dp, end = 40.dp)) {
                                Box(
                                    Modifier.shadow(2.dp, RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp)).background(Bubble).padding(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Text(shown, color = auraLc(0xFFD1D5DB), fontSize = 14.sp, textAlign = TextAlign.Center, maxLines = 3, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- Gizlilik ----------------

@Composable
fun PrivacyScreen(me: UserProfile, onBack: () -> Unit) {
    var presenceOn by remember { mutableStateOf(!Repo.isPresenceHidden()) }
    var receiptsOn by remember { mutableStateOf(!Repo.isReceiptsHidden()) }
    val pctx = LocalContext.current
    val psp = remember { pctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE) }
    var lockOn by remember { mutableStateOf(psp.getBoolean("applock", false)) }
    var keepArch by remember { mutableStateOf(psp.getBoolean("arch_keep", false)) }
    var timerPage by remember { mutableStateOf(false) }
    var defMs by remember { mutableStateOf(Repo.defaultDisappearMs()) }
    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Text("Gizlilik", color = AuraWhite, fontSize = 22.sp, modifier = Modifier.padding(start = 8.dp))
            }
            PrivacyRow(Icons.Default.Visibility, "Son görülme", "Kapalıyken kimse son görülmeni görmez", presenceOn) {
                presenceOn = it
                Repo.setPresenceHidden(me.uid, !it)
            }
            PrivacyRow(Icons.Default.DoneAll, "Okundu bilgisi", "Kapalıyken okundu tikini ne sen gönderirsin ne de görürsün", receiptsOn) {
                receiptsOn = it
                Repo.setReceiptsHidden(me.uid, !it)
            }
            PrivacyRow(Icons.Default.Lock, "Uygulama kilidi", "Uygulamayı açarken telefonun ekran kilidi (parmak izi, PIN) istenir", lockOn) {
                val km = pctx.getSystemService(android.content.Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
                if (it && !km.isDeviceSecure) {
                    android.widget.Toast.makeText(pctx, "Önce telefona ekran kilidi koy", android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    lockOn = it
                    psp.edit().putBoolean("applock", it).apply()
                }
            }
            PrivacyRow(Icons.Default.Archive, "Sohbetleri arşivde tut", "Açıkken yeni mesaj gelse de arşivlenen sohbet arşivde kalır", keepArch) {
                keepArch = it
                psp.edit().putBoolean("arch_keep", it).apply()
            }
            Row(
                Modifier.fillMaxWidth().clickable { timerPage = true }.padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DisappearBadge(26.dp, IconGray, Color.Transparent)
                Spacer(Modifier.width(22.dp))
                Column(Modifier.weight(1f)) {
                    Text("Varsayılan mesaj süresi", color = AuraWhite, fontSize = 18.sp)
                    Text(if (defMs > 0) Repo.disappearLabel(defMs) else "Kapalı", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
                }
            }
            val blocked by remember(me.uid) { Repo.blockedFlow(me.uid) }.collectAsState(emptyList())
            Text("Engellenen kişiler", color = AuraBtn, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 6.dp))
            if (blocked.isEmpty()) {
                Text("Kimseyi engellemedin", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            } else {
                Column {
                    blocked.forEach { uid ->
                        val lp by liveProfile(uid)
                        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar((lp?.name ?: "").ifBlank { "?" }, lp?.avatar ?: "", 44.dp)
                            Text((lp?.name ?: "").ifBlank { "Kullanıcı" }, color = AuraWhite, fontSize = 17.sp, modifier = Modifier.weight(1f).padding(start = 14.dp))
                            Text(
                                "Engeli kaldır", color = AuraGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { Repo.setBlocked(me.uid, uid, false) }.padding(8.dp)
                            )
                        }
                    }
                }
            }
        }
        if (timerPage) DefaultTimerScreen(defMs, onPick = { defMs = it; Repo.setDefaultDisappearMs(it) }, onBack = { timerPage = false })
    }
}

/** Yeni sohbetlere uygulanan varsayılan süreli mesaj süresi sayfası (WhatsApp düzeni) */
@Composable
private fun DefaultTimerScreen(current: Long, onPick: (Long) -> Unit, onBack: () -> Unit) {
    androidx.activity.compose.BackHandler { onBack() }
    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text("Varsayılan mesaj süresi", color = AuraWhite, fontSize = 22.sp, modifier = Modifier.padding(start = 8.dp))
        }
        Text("Yeni sohbetlere şu süreli mesaj süresi ayarıyla başlayın:", color = AuraMuted, fontSize = 16.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp))
        val day = 24L * 3600 * 1000L
        listOf("24 saat" to day, "7 gün" to 7 * day, "90 gün" to 90 * day, "Kapalı" to 0L).forEach { (label, ms) ->
            Row(
                Modifier.fillMaxWidth().clickable { onPick(ms) }.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                androidx.compose.material3.RadioButton(
                    selected = current == ms, onClick = { onPick(ms) },
                    colors = androidx.compose.material3.RadioButtonDefaults.colors(selectedColor = AuraGreen, unselectedColor = AuraMuted)
                )
                Text(label, color = AuraWhite, fontSize = 18.sp, modifier = Modifier.padding(start = 20.dp))
            }
        }
        Text(
            "Bu özellik açıldığında tüm yeni bireysel sohbetler, seçtiğiniz süre dolduğunda kaybolacak süreli mesajlarla başlatılır. Mevcut sohbetleriniz bu ayardan etkilenmez.",
            color = AuraMuted, fontSize = 16.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp)
        )
    }
}

@Composable
private fun PrivacyRow(icon: ImageVector, title: String, desc: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!on) }.padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = IconGray, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(22.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = AuraWhite, fontSize = 18.sp)
            Text(desc, color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
        }
        Switch(
            checked = on, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = AuraBtn, checkedThumbColor = Color.White)
        )
    }
}

private fun openChannelSettings(ctx: android.content.Context, channel: String) {
    try {
        val i = android.content.Intent(
            if (android.os.Build.VERSION.SDK_INT >= 26) android.provider.Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS
            else android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS
        ).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            .putExtra(android.provider.Settings.EXTRA_CHANNEL_ID, channel)
        ctx.startActivity(i)
    } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ProfileScreens", e) }
}

package com.aurachat.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

/** Uygulamanın o anki durumu: bildirimleri bastırmak için kullanılır. */
object AppState {
    @Volatile var foreground = false
    @Volatile var activeChatId: String? = null
    /** İlk ekran çizilmeye hazır mı (splash bunu bekler) */
    @Volatile var ready = false
}

const val CHANNEL_MESSAGES = "aurachat-messages"
const val CHANNEL_CALLS = "aurachat-calls"
const val CHANNEL_CALL_ONGOING = "aurachat-call-ongoing"

class AuraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        com.aurachat.app.data.Repo.init(this)
        com.aurachat.app.call.CallManager.init(this)
        // Ağır başlatmalar ana iş parçacığını bekletmesin
        Thread {
            try { com.google.firebase.firestore.FirebaseFirestore.getInstance() } catch (e: Throwable) {}
            createChannels()
        }.start()
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_MESSAGES, "Mesajlar", NotificationManager.IMPORTANCE_HIGH)
            )
            val ring = NotificationChannel(CHANNEL_CALLS, "Gelen aramalar", NotificationManager.IMPORTANCE_HIGH)
            ring.setSound(
                android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_RINGTONE),
                android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            ring.enableVibration(true)
            ring.vibrationPattern = longArrayOf(0, 400, 300, 400, 1200)
            nm.createNotificationChannel(ring)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_CALL_ONGOING, "Devam eden arama", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }
}

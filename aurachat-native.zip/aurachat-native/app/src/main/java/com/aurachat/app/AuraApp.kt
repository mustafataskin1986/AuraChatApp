package com.aurachat.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

/** Uygulamanın o anki durumu: bildirimleri bastırmak için kullanılır. */
object AppState {
    @Volatile var foreground = false
    @Volatile var activeChatId: String? = null
}

const val CHANNEL_MESSAGES = "aurachat-messages"

class AuraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        com.aurachat.app.data.Repo.init(this)
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_MESSAGES, "Mesajlar", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }
}

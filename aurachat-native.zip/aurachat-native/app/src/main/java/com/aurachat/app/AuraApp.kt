package com.aurachat.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

/** Uygulamanın o anki durumu: bildirimleri bastırmak için kullanılır. */
/** Başka uygulamadan "AuraChat ile paylaş" ile gelen içerik */
data class SharedIn(val text: String, val uris: List<android.net.Uri>, val shortcutChatId: String = "")

object AppState {
    val sharedIn = androidx.compose.runtime.mutableStateOf<SharedIn?>(null)
    @Volatile var foreground = false
    /** Uygulama kilidi: true iken kilit ekranı gösterilir */
    val locked = androidx.compose.runtime.mutableStateOf(false)
    @Volatile var leftAt = 0L
    @Volatile var activeChatId: String? = null
    /** İlk ekran çizilmeye hazır mı (splash bunu bekler) */
    @Volatile var ready = false
    /** Gelen arama bildiriminden açıldı: arama ekranı gelene kadar sohbet yerine "Gelen arama" gösterilir (uptime ms) */
    val callWait = androidx.compose.runtime.mutableLongStateOf(0L)
}

// Kanal ayarları (kayan bildirim izni dahil) ilk oluşturulduğunda kalıcı olarak kaydedilir; v2: ayarlar sıfırlansın, kayan bildirim yeniden açılsın
const val CHANNEL_MESSAGES = "aurachat-messages-v2"
const val CHANNEL_CALLS = "aurachat-calls-v2"
const val CHANNEL_CALL_ONGOING = "aurachat-call-ongoing"

class AuraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 28 && Application.getProcessName().endsWith(":crash")) return
        installCrashScreen()
        com.aurachat.app.data.Repo.init(this)
        com.aurachat.app.ui.AuraUi.load(this)
        com.aurachat.app.ui.Drafts.init(this)
        com.aurachat.app.call.CallManager.init(this)
        // Ağır başlatmalar ana iş parçacığını bekletmesin
        Thread {
            try { com.google.firebase.firestore.FirebaseFirestore.getInstance() } catch (e: Throwable) {}
            createChannels()
            try { com.aurachat.app.ui.UpdateWorker.schedule(this) } catch (e: Throwable) {}
            try { com.google.firebase.messaging.FirebaseMessaging.getInstance().subscribeToTopic("updates") } catch (e: Throwable) {}
        }.start()
    }

    private fun installCrashScreen() {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = java.io.StringWriter()
                e.printStackTrace(java.io.PrintWriter(sw))
                val i = android.content.Intent(this, CrashActivity::class.java)
                    .putExtra("err", sw.toString().take(6000))
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK)
                startActivity(i)
                Thread.sleep(400)
            } catch (x: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            try { nm.deleteNotificationChannel("aurachat-messages") } catch (e: Throwable) {}
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_MESSAGES, "Mesajlar", NotificationManager.IMPORTANCE_HIGH)
            )
            val ring = NotificationChannel(CHANNEL_CALLS, "Gelen aramalar", NotificationManager.IMPORTANCE_HIGH)
            // Zil sesi ve titreşimi uygulama içinden (CallManager) çalınır; bildirimin ayrıca ses çıkarması çift ses yapıyordu
            ring.setSound(null, null)
            ring.enableVibration(false)
            nm.createNotificationChannel(ring)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_CALL_ONGOING, "Devam eden arama", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }
}

package com.aurachat.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.MediaPlayer
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

// =====================================================================
//  VERİ
// =====================================================================
/** Duruma eklenen müzik: iTunes 30 sn'lik önizleme. x/y: çıkartmanın merkezi (çerçeveye oran) */
data class StatusMusic(
    val title: String, val artist: String, val cover: String, val preview: String,
    val durMs: Long = 0L, val x: Float = 0.5f, val y: Float = 0.18f,
    val rot: Float = 0f, val scale: Float = 1f
)

/** Editörde seçili müzik; postStatus bunu okur (imza değiştirmeden taşımak için) */
object StatusMusicHolder {
    @Volatile var selected: StatusMusic? = null
}

internal fun StatusMusic.toMap(): Map<String, Any> = hashMapOf(
    "title" to title, "artist" to artist, "cover" to cover, "preview" to preview,
    "dur" to durMs, "x" to x.toDouble(), "y" to y.toDouble(), "rot" to rot.toDouble(), "sc" to scale.toDouble()
)

internal fun statusMusicFromMap(m: Map<*, *>?): StatusMusic? {
    if (m == null) return null
    val pv = (m["preview"] as? String) ?: ""
    if (pv.isBlank()) return null
    return StatusMusic(
        title = (m["title"] as? String) ?: "", artist = (m["artist"] as? String) ?: "", cover = (m["cover"] as? String) ?: "",
        preview = pv, durMs = (m["dur"] as? Number)?.toLong() ?: 0L,
        x = (m["x"] as? Number)?.toFloat() ?: 0.5f, y = (m["y"] as? Number)?.toFloat() ?: 0.18f,
        rot = (m["rot"] as? Number)?.toFloat() ?: 0f, scale = (m["sc"] as? Number)?.toFloat() ?: 1f
    )
}

internal fun StatusMusic.toJson(): JSONObject = JSONObject().put("t", title).put("a", artist).put("c", cover).put("p", preview).put("d", durMs)
    .put("x", x.toDouble()).put("y", y.toDouble()).put("r", rot.toDouble()).put("s", scale.toDouble())

internal fun statusMusicFromJson(o: JSONObject?): StatusMusic? {
    if (o == null) return null
    val p = o.optString("p")
    if (p.isBlank()) return null
    return StatusMusic(o.optString("t"), o.optString("a"), o.optString("c"), p, o.optLong("d"), o.optDouble("x", 0.5).toFloat(), o.optDouble("y", 0.18).toFloat(), o.optDouble("r", 0.0).toFloat(), o.optDouble("s", 1.0).toFloat())
}

// =====================================================================
//  YILDIZLAR (yerel)
// =====================================================================
private object MusicStars {
    private const val PREF = "aurachat_starred_music"
    fun load(ctx: android.content.Context): List<StatusMusic> = try {
        val a = JSONArray(ctx.getSharedPreferences(PREF, 0).getString("list", "[]") ?: "[]")
        (0 until a.length()).mapNotNull { statusMusicFromJson(a.optJSONObject(it)) }
    } catch (e: Throwable) { emptyList() }

    fun save(ctx: android.content.Context, l: List<StatusMusic>) {
        try {
            val a = JSONArray()
            l.forEach { a.put(it.toJson()) }
            ctx.getSharedPreferences(PREF, 0).edit().putString("list", a.toString()).apply()
        } catch (e: Throwable) { /* yıldız kaydı yoksa sorun değil */ }
    }
}

// =====================================================================
//  ÖNİZLEME OYNATICI
// =====================================================================
object MusicPreview {
    private var mp: MediaPlayer? = null
    var playingUrl by mutableStateOf<String?>(null)
        private set

    fun stop() {
        try { mp?.release() } catch (e: Throwable) { }
        mp = null
        playingUrl = null
    }

    fun play(url: String) {
        stop()
        try {
            val p = MediaPlayer()
            mp = p
            p.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            p.setDataSource(url)
            p.isLooping = true
            p.setOnPreparedListener { if (mp === it) it.start() }
            p.setOnErrorListener { _, _, _ -> if (mp === p) stop(); true }
            playingUrl = url
            p.prepareAsync()
        } catch (e: Throwable) { stop() }
    }

    fun toggle(url: String) { if (playingUrl == url) stop() else play(url) }
}

// =====================================================================
//  KAPAK RESMİ
// =====================================================================
private object CoverCache {
    private val cache = object : android.util.LruCache<String, Bitmap>(40) {}
    fun peek(url: String): Bitmap? = cache.get(url)
    suspend fun load(url: String): Bitmap? {
        cache.get(url)?.let { return it }
        return withContext(Dispatchers.IO) {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                val bm = c.inputStream.use { BitmapFactory.decodeStream(it) }
                c.disconnect()
                if (bm != null) cache.put(url, bm)
                bm
            } catch (e: Throwable) { null }
        }
    }
}

@Composable
private fun MusicCover(url: String, size: Dp, radius: Dp = 10.dp, content: @Composable () -> Unit = {}) {
    val bm by androidx.compose.runtime.produceState<Bitmap?>(CoverCache.peek(url), url) { if (value == null && url.isNotBlank()) value = CoverCache.load(url) }
    Box(Modifier.size(size).clip(RoundedCornerShape(radius)).background(Color(0xFF2B3036)), contentAlignment = Alignment.Center) {
        bm?.let { Image(bitmap = it.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
        content()
    }
}

// =====================================================================
//  ARAMA (iTunes)
// =====================================================================
private suspend fun itunesSearch(term: String): List<StatusMusic>? = withContext(Dispatchers.IO) {
    try {
        val u = "https://itunes.apple.com/search?term=" + URLEncoder.encode(term, "UTF-8") + "&media=music&entity=song&country=TR&limit=25"
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        val txt = c.inputStream.bufferedReader().use { it.readText() }
        c.disconnect()
        val arr = JSONObject(txt).optJSONArray("results") ?: return@withContext emptyList()
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val pv = o.optString("previewUrl")
            if (pv.isBlank()) null
            else StatusMusic(
                title = o.optString("trackName"), artist = o.optString("artistName"),
                cover = o.optString("artworkUrl100").replace("100x100", "200x200"), preview = pv, durMs = o.optLong("trackTimeMillis")
            )
        }.distinctBy { it.preview }
    } catch (e: Throwable) { null }
}

private fun fmtDur(ms: Long): String {
    val s = (ms / 1000).toInt()
    return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
}

private val MuGreen = Color(0xFF25D366)
private val MuSheet = Color(0xFF111614)
private val MuTabs = listOf("Önerilen", "Ruh hali", "Tür", "Yıldızlı")
private val MuTerms = listOf("turkce pop hit", "akustik duygusal turkce", "turkce rap rock")
private val MuHints = listOf("Şarkı arayın", "Sanatçı arayın", "Ruh hali arayın", "Tür arayın")

// =====================================================================
//  ALT SAYFA
// =====================================================================
/**
 * Müzik seçici. Kendi katmanı olarak çizilir (Dialog/ModalBottomSheet değil): açılış ve kapanış her zaman
 * sonuna kadar animasyonla tamamlanır, yarım kalmaz. Listenin başında aşağı çekince kapanır (90dp eşik).
 */
@Composable
fun StatusMusicSheet(currentUrl: String?, onDismiss: () -> Unit, onPick: (StatusMusic) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dens = LocalDensity.current
    val thresholdPx = with(dens) { 90.dp.toPx() }
    val ease = remember { CubicBezierEasing(0.1f, 0.9f, 0.2f, 1f) }

    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<StatusMusic>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var failed by remember { mutableStateOf(false) }
    val stars = remember { mutableStateListOf<StatusMusic>().apply { addAll(MusicStars.load(ctx)) } }
    var chosenUrl by remember { mutableStateOf<String?>(null) }

    var hintIdx by remember { mutableIntStateOf(0) }
    LaunchedEffect(query) {
        while (query.isEmpty()) { delay(2000); hintIdx = (hintIdx + 1) % MuHints.size }
    }

    LaunchedEffect(tab, query) {
        if (tab == 3) { loading = false; failed = false; return@LaunchedEffect }
        loading = true; failed = false
        val q = query.trim()
        if (q.isNotEmpty()) delay(300)
        val r = itunesSearch(if (q.isEmpty()) MuTerms[tab.coerceIn(0, 2)] else q)
        if (r == null) { failed = true; items = emptyList() } else items = r
        loading = false
    }

    DisposableEffect(Unit) {
        onDispose {
            if (chosenUrl == null) {
                MusicPreview.stop()
                if (currentUrl != null) MusicPreview.play(currentUrl)
            }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val sheetH = maxHeight * 0.92f
        val sheetPx = with(dens) { sheetH.toPx() }
        var off by remember { mutableFloatStateOf(sheetPx) }          // açılırken sheetPx -> 0
        var closing by remember { mutableStateOf(false) }
        var job by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }

        fun animTo(target: Float, ms: Int, after: () -> Unit = {}) {
            job?.cancel()
            job = scope.launch {
                animate(off, target, animationSpec = tween(ms, easing = ease)) { v, _ -> off = v }
                after()
            }
        }
        fun close() {
            if (closing) return
            closing = true
            animTo(sheetPx, 260) { onDismiss() }
        }
        fun settle(vel: Float) {
            if (closing) return
            if (off > thresholdPx || vel > 1500f) close() else animTo(0f, 220)
        }

        LaunchedEffect(Unit) { animTo(0f, 340) }
        BackHandler { close() }

        val frac = (1f - (off / sheetPx).coerceIn(0f, 1f))
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f * frac))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { close() }
        )

        val nested = remember {
            object : NestedScrollConnection {
                override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                    if (closing) return Offset.Zero
                    if (off > 0f && available.y < 0f) {
                        job?.cancel()
                        val n = (off + available.y).coerceAtLeast(0f)
                        val used = n - off
                        off = n
                        return Offset(0f, used)
                    }
                    return Offset.Zero
                }
                override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                    if (closing) return Offset.Zero
                    if (available.y > 0f && source == NestedScrollSource.Drag) {
                        job?.cancel()
                        off += available.y
                        return Offset(0f, available.y)
                    }
                    return Offset.Zero
                }
                override suspend fun onPreFling(available: Velocity): Velocity {
                    if (off > 0f && !closing) { settle(available.y); return available }
                    return Velocity.Zero
                }
            }
        }

        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(sheetH)
                .offset { IntOffset(0, off.roundToInt().coerceAtLeast(0)) }
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).background(MuSheet)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
        ) {
            // sürüklenebilir üst kısım
            Column(
                Modifier.fillMaxWidth().pointerInput(Unit) {
                    var vy = 0f
                    detectVerticalDragGestures(
                        onDragStart = { job?.cancel(); vy = 0f },
                        onVerticalDrag = { _, dy -> if (!closing) { off = (off + dy).coerceAtLeast(0f); vy = dy * 60f } },
                        onDragEnd = { settle(vy) }, onDragCancel = { settle(0f) }
                    )
                }
            ) {
                Box(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 12.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.width(40.dp).height(4.dp).clip(CircleShape).background(Color(0xFF3A4540)))
                }
                // arama
                Row(
                    Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(46.dp).clip(RoundedCornerShape(23.dp)).background(Color(0xFF1C2421)).padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search, null, tint = Color(0xFF9CA8A3), modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) {
                            Crossfade(targetState = hintIdx, animationSpec = tween(400), label = "hint") { i ->
                                Text(MuHints[i], color = Color(0xFF7D8A84), fontSize = 15.sp, maxLines = 1)
                            }
                        }
                        BasicTextField(
                            value = query, onValueChange = { query = it }, singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                            cursorBrush = SolidColor(MuGreen), modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (query.isNotEmpty()) {
                        Icon(Icons.Default.Close, "Temizle", tint = Color(0xFF9CA8A3), modifier = Modifier.size(20.dp).clip(CircleShape).clickable { query = "" })
                    }
                }
                Spacer(Modifier.height(12.dp))
                // sekmeler
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MuTabs.forEachIndexed { i, t ->
                        val on = tab == i
                        Box(
                            Modifier.height(34.dp).clip(RoundedCornerShape(17.dp))
                                .background(if (on) Color(0xFF123C29) else Color.Transparent)
                                .border(BorderStroke(1.dp, if (on) Color(0xFF184E36) else Color(0xFF2B3531)), RoundedCornerShape(17.dp))
                                .clickable { tab = i }.padding(horizontal = 14.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(t, color = if (on) Color(0xFF4ADE80) else Color(0xFF9CA8A3), fontSize = 13.sp, fontWeight = FontWeight.Medium) }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            fun pick(t: StatusMusic) {
                chosenUrl = t.preview
                MusicPreview.play(t.preview)
                onPick(t)
                close()
            }
            fun toggleStar(t: StatusMusic) {
                val i = stars.indexOfFirst { it.preview == t.preview }
                if (i >= 0) stars.removeAt(i) else stars.add(0, t)
                MusicStars.save(ctx, stars.toList())
            }

            val shown = if (tab == 3) {
                val q = query.trim().lowercase()
                if (q.isEmpty()) stars.toList() else stars.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
            } else items
            val featured = if (tab == 3) emptyList() else shown.take(3)
            val rest = if (tab == 3) shown else shown.drop(3)

            Box(Modifier.weight(1f).fillMaxWidth().nestedScroll(nested)) {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
                    if (featured.isNotEmpty()) {
                        item(key = "featured") { FeaturedPager(featured, stars.map { it.preview }, { toggleStar(it) }, { pick(it) }) }
                    }
                    items(rest, key = { it.preview }) { t ->
                        MusicRow(t, stars.any { it.preview == t.preview }, { toggleStar(t) }, { pick(t) })
                    }
                    item(key = "navpad") { Spacer(Modifier.navigationBarsPadding().height(8.dp)) }
                }
                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                        CircularProgressIndicator(color = MuGreen, strokeWidth = 2.dp, modifier = Modifier.padding(top = 40.dp).size(28.dp))
                    }
                    failed -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                        Text("Bağlantı hatası, tekrar deneyin", color = Color(0xFF9CA8A3), fontSize = 14.sp, modifier = Modifier.padding(top = 40.dp))
                    }
                    shown.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                        Text(if (tab == 3) "Henüz yıldızlı şarkı yok" else "Sonuç bulunamadı", color = Color(0xFF9CA8A3), fontSize = 14.sp, modifier = Modifier.padding(top = 40.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun FeaturedPager(list: List<StatusMusic>, starred: List<String>, onStar: (StatusMusic) -> Unit, onPick: (StatusMusic) -> Unit) {
    val pager = rememberPagerState { list.size }
    val playing = MusicPreview.playingUrl
    Column(Modifier.padding(bottom = 6.dp)) {
        HorizontalPager(
            state = pager, contentPadding = PaddingValues(start = 16.dp, end = 32.dp), pageSpacing = 10.dp,
            modifier = Modifier.fillMaxWidth()
        ) { i ->
            val t = list[i]
            val first = i == 0
            val bg = if (first) Color(0xFF9CA09E) else Color(0xFF5C3A3A)
            val fg = if (first) Color(0xFF111614) else Color.White
            Row(
                Modifier.fillMaxWidth().height(88.dp).clip(RoundedCornerShape(18.dp)).background(bg)
                    .clickable { MusicPreview.toggle(t.preview) }.padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MusicCover(t.cover, 52.dp) {
                    if (playing == t.preview) Box(Modifier.fillMaxSize().background(Color(0x88000000)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Pause, null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, color = if (playing == t.preview && !first) Color(0xFF4ADE80) else fg, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(t.artist, color = fg.copy(alpha = 0.75f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(
                    if (starred.contains(t.preview)) "★" else "☆", color = if (starred.contains(t.preview)) Color(0xFFFBBF24) else fg.copy(alpha = 0.8f), fontSize = 24.sp,
                    modifier = Modifier.clip(CircleShape).clickable { onStar(t) }.padding(horizontal = 8.dp)
                )
                Box(Modifier.size(36.dp).clip(CircleShape).background(Color(0x33000000)).clickable { onPick(t) }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.ArrowUpward, "Seç", tint = fg, modifier = Modifier.size(20.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.Center) {
            list.indices.forEach { i ->
                Box(Modifier.padding(horizontal = 3.dp).size(6.dp).clip(CircleShape).background(if (pager.currentPage == i) MuGreen else Color(0xFF3A4540)))
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun MusicRow(t: StatusMusic, starred: Boolean, onStar: () -> Unit, onPick: () -> Unit) {
    val playing = MusicPreview.playingUrl == t.preview
    Row(
        Modifier.fillMaxWidth().clickable { MusicPreview.toggle(t.preview) }.padding(horizontal = 16.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        MusicCover(t.cover, 48.dp) {
            Box(Modifier.fillMaxSize().background(Color(if (playing) 0x88000000 else 0x33000000)), contentAlignment = Alignment.Center) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, color = if (playing) MuGreen else Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(t.artist + (if (t.durMs > 0) " · " + fmtDur(t.durMs) else ""), color = Color(0xFF9CA8A3), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(
            if (starred) "★" else "☆", color = if (starred) Color(0xFFFBBF24) else Color(0xFF6B7A74), fontSize = 24.sp,
            modifier = Modifier.clip(CircleShape).clickable { onStar() }.padding(horizontal = 8.dp)
        )
        Spacer(Modifier.width(4.dp))
        Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF222926)).clickable { onPick() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.ArrowUpward, "Seç", tint = Color.White, modifier = Modifier.size(18.dp))
        }
    }
}

// =====================================================================
//  ÇIKARTMA
// =====================================================================
/** Durumun üstündeki müzik kartı. onRemove verilirse sağ üstte kırmızı ✕ çıkar (editör) */
@Composable
fun MusicStickerCard(m: StatusMusic, modifier: Modifier = Modifier, onRemove: (() -> Unit)? = null) {
    Box(modifier) {
        Row(
            Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xD90F172A)).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MusicCover(m.cover, 40.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.widthIn(max = 150.dp).padding(end = 6.dp)) {
                Text(m.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(m.artist, color = Color(0xFF94A3B8), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (onRemove != null) {
            Box(
                Modifier.align(Alignment.TopEnd).offset(6.dp, (-6).dp).size(22.dp).clip(CircleShape).background(Color(0xFFEF4444)).clickable { onRemove() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Close, "Kaldır", tint = Color.White, modifier = Modifier.size(14.dp)) }
        }
    }
}

/** Editörde çıkartma: tek parmakla sürükle, iki parmakla büyüt/döndür (360°); dokununca onTap */
@Composable
fun EditorMusicSticker(
    m: StatusMusic, fw: Float, fh: Float, onChange: (StatusMusic) -> Unit, onRemove: () -> Unit, onTap: () -> Unit
) {
    var sz by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
    val mState = androidx.compose.runtime.rememberUpdatedState(m)
    Box(
        Modifier
            .offset { IntOffset((m.x * fw - sz.width / 2f).roundToInt(), (m.y * fh - sz.height / 2f).roundToInt()) }
            .onSizeChanged { sz = it }
            .graphicsLayer { rotationZ = m.rot; scaleX = m.scale; scaleY = m.scale }
            .pointerInput(fw, fh) {
                detectTransformGestures { _, pan, zoom, rotation ->
                    val cur = mState.value
                    val r = Math.toRadians(cur.rot.toDouble())
                    val dx = ((pan.x * Math.cos(r) - pan.y * Math.sin(r)) * cur.scale).toFloat()
                    val dy = ((pan.x * Math.sin(r) + pan.y * Math.cos(r)) * cur.scale).toFloat()
                    onChange(
                        cur.copy(
                            x = (cur.x + dx / fw).coerceIn(0f, 1f), y = (cur.y + dy / fh).coerceIn(0f, 1f),
                            scale = (cur.scale * zoom).coerceIn(0.5f, 3f), rot = cur.rot + rotation
                        )
                    )
                }
            }
            .pointerInput(Unit) { detectTapGestures { onTap() } }
    ) { MusicStickerCard(m, onRemove = onRemove) }
}

/** Görüntüleyicide: kart + önizleme çalma (aktifken) */
@Composable
fun StatusMusicViewerLayer(m: StatusMusic, play: Boolean) {
    DisposableEffect(m.preview, play) {
        if (play) MusicPreview.play(m.preview)
        onDispose { if (MusicPreview.playingUrl == m.preview) MusicPreview.stop() }
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        var sz by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
        val wPx = with(LocalDensity.current) { maxWidth.toPx() }
        val hPx = with(LocalDensity.current) { maxHeight.toPx() }
        MusicStickerCard(
            m, Modifier
                .offset { IntOffset((m.x * wPx - sz.width / 2f).roundToInt(), (m.y * hPx - sz.height / 2f).roundToInt()) }
                .onSizeChanged { sz = it }
                .graphicsLayer { rotationZ = m.rot; scaleX = m.scale; scaleY = m.scale }
        )
    }
}

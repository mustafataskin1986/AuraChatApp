package com.aurachat.app.ui

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext

/** Sohbet kilidi: kilitli sohbetler yalnızca bu telefonda tutulur, listeden gizlenir, telefonun ekran kilidiyle açılır */
object ChatLock {
    var ver by mutableIntStateOf(0)
    /** Son başarılı doğrulamanın zamanı (ms): kısa süre içinde kilitli sohbet tekrar sormadan açılır */
    var authAt = 0L
    private const val GRACE_MS = 5 * 60 * 1000L

    private fun sp(c: Context) = c.getSharedPreferences("aura", Context.MODE_PRIVATE)

    fun all(c: Context): Set<String> {
        val v = ver
        return if (v >= 0) (sp(c).getStringSet("chat_locked", emptySet()) ?: emptySet()) else emptySet()
    }

    fun isLocked(c: Context, chatId: String): Boolean = all(c).contains(chatId)

    /** Servis/bildirim gibi bileşim dışı yerlerde kullanım */
    fun isLockedRaw(c: Context, chatId: String): Boolean = (sp(c).getStringSet("chat_locked", emptySet()) ?: emptySet()).contains(chatId)

    fun canLock(c: Context): Boolean = (c.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager)?.isDeviceSecure == true

    fun lock(c: Context, ids: Collection<String>) {
        val s = HashSet(all(c)); s.addAll(ids)
        sp(c).edit().putStringSet("chat_locked", s).apply(); ver++
        authAt = 0L
    }

    fun unlock(c: Context, ids: Collection<String>) {
        val s = HashSet(all(c)); s.removeAll(ids.toSet())
        sp(c).edit().putStringSet("chat_locked", s).apply(); ver++
    }

    fun recentlyAuthed(): Boolean = System.currentTimeMillis() - authAt < GRACE_MS
}

/** Telefonun ekran kilidiyle (PIN / desen / parmak izi) kimlik doğrular; başarılıysa verilen işlem çalışır */
@Composable
fun rememberDeviceAuth(): (String, () -> Unit, () -> Unit) -> Unit {
    val ctx = LocalContext.current
    val pending = remember { arrayOfNulls<() -> Unit>(2) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val ok = pending[0]; val no = pending[1]
        pending[0] = null; pending[1] = null
        if (r.resultCode == Activity.RESULT_OK) { ChatLock.authAt = System.currentTimeMillis(); ok?.invoke() } else no?.invoke()
    }
    return remember {
        { reason, onOk, onDenied ->
            val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (!km.isDeviceSecure) {
                Toast.makeText(ctx, "Önce telefona ekran kilidi (PIN, desen veya parmak izi) ayarla", Toast.LENGTH_LONG).show()
                onDenied()
            } else {
                @Suppress("DEPRECATION")
                val i = km.createConfirmDeviceCredentialIntent("Kilitli sohbetler", reason)
                if (i == null) onDenied() else {
                    pending[0] = onOk; pending[1] = onDenied
                    try { launcher.launch(i) } catch (e: Throwable) { pending[0] = null; pending[1] = null; onDenied() }
                }
            }
        }
    }
}

/** Kilitli bir sohbet bildirimden / aramadan açılırsa doğrulama ister; iptal edilirse geri döner */
@Composable
fun ChatLockGate(chatId: String, onDenied: () -> Unit, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val locked = ChatLock.isLocked(ctx, chatId)
    var passed by remember(chatId) { mutableStateOf(!locked || ChatLock.recentlyAuthed()) }
    val auth = rememberDeviceAuth()
    if (!passed) {
        LaunchedEffect(chatId) { auth("Bu sohbet kilitli", { passed = true }, onDenied) }
        androidx.compose.foundation.layout.Box(
            androidx.compose.ui.Modifier.fillMaxSize().background(AuraBlack)
        )
    } else content()
}

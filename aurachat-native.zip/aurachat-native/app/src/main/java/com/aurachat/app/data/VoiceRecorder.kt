package com.aurachat.app.data

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File

/** Sesli mesaj kaydı (AAC/m4a, mono, düşük bit hızı: 2 dk ≈ 500 KB) */
class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var accMs = 0L
    private var segStart = 0L
    var paused = false
        private set

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    fun start(): Boolean {
        return try {
            val f = File(ctx.cacheDir, "rec_${System.currentTimeMillis()}.m4a")
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(32000)
            r.setAudioSamplingRate(16000)
            r.setAudioChannels(1)
            r.setMaxDuration(120000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r
            file = f
            accMs = 0L; segStart = System.currentTimeMillis(); paused = false
            true
        } catch (e: Throwable) {
            cancel()
            false
        }
    }

    fun elapsedSec(): Int = ((accMs + (if (!paused && rec != null) System.currentTimeMillis() - segStart else 0L)) / 1000).toInt()

    fun pause() {
        val r = rec ?: return
        if (paused) return
        try { r.pause(); accMs += System.currentTimeMillis() - segStart; paused = true } catch (e: Throwable) { com.aurachat.app.AuraLog.e("VoiceRecorder", e) }
    }

    fun resume() {
        val r = rec ?: return
        if (!paused) return
        try { r.resume(); segStart = System.currentTimeMillis(); paused = false } catch (e: Throwable) { com.aurachat.app.AuraLog.e("VoiceRecorder", e) }
    }

    /** Anlık ses genliği 0..1 (dalga formu için) */
    fun level(): Float = try { ((rec?.maxAmplitude ?: 0) / 12000f).coerceIn(0f, 1f) } catch (e: Throwable) { 0f }

    /** Kaydı bitirir; dosya ve süre (sn) döner. 1 sn'den kısaysa null. */
    fun stop(): Pair<File, Int>? {
        val r = rec ?: return null
        val f = file
        val sec = elapsedSec()
        rec = null
        file = null
        return try {
            r.stop()
            r.release()
            if (f != null && sec >= 1) Pair(f, sec) else null
        } catch (e: Throwable) {
            try { r.release() } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("VoiceRecorder", ignored) }
            null
        }
    }

    fun cancel() {
        val r = rec
        rec = null
        if (r != null) {
            try { r.stop() } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("VoiceRecorder", ignored) }
            try { r.release() } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("VoiceRecorder", ignored) }
        }
        file?.delete()
        file = null
    }
}

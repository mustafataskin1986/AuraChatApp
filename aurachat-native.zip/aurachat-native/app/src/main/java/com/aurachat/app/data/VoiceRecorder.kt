package com.aurachat.app.data

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File

/** Sesli mesaj kaydı (AAC/m4a, mono, düşük bit hızı: 2 dk ≈ 500 KB) */
class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var startMs = 0L

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    fun start(): Boolean {
        return try {
            val f = File(ctx.cacheDir, "rec_${System.currentTimeMillis()}.m4a")
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(32000)
            r.setAudioSamplingRate(16000)
            r.setAudioChannels(1)
            r.setMaxDuration(120000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r
            file = f
            startMs = System.currentTimeMillis()
            true
        } catch (e: Throwable) {
            cancel()
            false
        }
    }

    fun elapsedSec(): Int = ((System.currentTimeMillis() - startMs) / 1000).toInt()

    /** Kaydı bitirir; dosya ve süre (sn) döner. 1 sn'den kısaysa null. */
    fun stop(): Pair<File, Int>? {
        val r = rec ?: return null
        val f = file
        val sec = elapsedSec()
        rec = null
        file = null
        return try {
            r.stop()
            r.release()
            if (f != null && sec >= 1) Pair(f, sec) else null
        } catch (e: Throwable) {
            try { r.release() } catch (ignored: Throwable) {}
            null
        }
    }

    fun cancel() {
        val r = rec
        rec = null
        if (r != null) {
            try { r.stop() } catch (ignored: Throwable) {}
            try { r.release() } catch (ignored: Throwable) {}
        }
        file?.delete()
        file = null
    }
}

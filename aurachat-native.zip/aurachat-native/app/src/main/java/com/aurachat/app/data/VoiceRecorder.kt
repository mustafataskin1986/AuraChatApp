package com.aurachat.app.data

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.os.Build
import java.io.File
import java.nio.ByteBuffer

/**
 * Ses kaydı. Duraklatınca o ana kadarki parça kapatılır (böylece dinlenebilir), devam edince yeni parça kaydedilir;
 * gönderirken parçalar tek dosyada birleştirilir.
 */
class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var cur: File? = null
    private val segs = ArrayList<File>()
    private var accMs = 0L
    private var segStart = 0L
    private var preview: File? = null
    private var previewCount = -1
    var paused = false
        private set

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    private fun startSegment(): Boolean {
        return try {
            val f = File(ctx.cacheDir, "rec_${System.currentTimeMillis()}_${segs.size}.m4a")
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(32000)
            r.setAudioSamplingRate(16000)
            r.setAudioChannels(1)
            r.setMaxDuration(120000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r
            cur = f
            segStart = System.currentTimeMillis()
            true
        } catch (e: Throwable) {
            try { rec?.release() } catch (ignored: Throwable) { }
            rec = null
            cur = null
            false
        }
    }

    /** Çalışan parçayı kapatır ve listeye ekler */
    private fun endSegment() {
        val r = rec ?: return
        val f = cur
        rec = null
        cur = null
        accMs += System.currentTimeMillis() - segStart
        try {
            r.stop()
            r.release()
            if (f != null) segs.add(f)
        } catch (e: Throwable) {
            try { r.release() } catch (ignored: Throwable) { }
            f?.delete()
        }
    }

    fun start(): Boolean {
        cancel()
        accMs = 0L
        paused = false
        return startSegment()
    }

    /** Taslaktan geri yükle: duraklatılmış kayıt gibi açılır (dinlenebilir, devam edilebilir, gönderilebilir) */
    fun restore(src: File, sec: Int): Boolean {
        cancel()
        return try {
            val f = File(ctx.cacheDir, "rec_${System.currentTimeMillis()}_draft.m4a")
            src.copyTo(f, overwrite = true)
            segs.add(f)
            accMs = sec * 1000L
            paused = true
            true
        } catch (e: Throwable) { false }
    }

    fun elapsedMs(): Long = accMs + (if (!paused && rec != null) System.currentTimeMillis() - segStart else 0L)
    fun elapsedSec(): Int = (elapsedMs() / 1000).toInt()

    fun pause() {
        if (paused || rec == null) return
        endSegment()
        paused = true
    }

    fun resume() {
        if (!paused) return
        if (startSegment()) {
            paused = false
            preview?.delete(); preview = null; previewCount = -1
        }
    }

    /** Anlık ses genliği 0..1 (dalga formu için) */
    fun level(): Float = try { ((rec?.maxAmplitude ?: 0) / 12000f).coerceIn(0f, 1f) } catch (e: Throwable) { 0f }

    /** Duraklatılmışken şimdiye kadarki kaydın dinlenebilir dosyası (parçalar birleştirilir) */
    fun previewFile(): File? {
        if (segs.isEmpty()) return null
        if (segs.size == 1) return segs[0]
        val p = preview
        if (p != null && previewCount == segs.size && p.exists()) return p
        val out = File(ctx.cacheDir, "rec_prev_${System.currentTimeMillis()}.m4a")
        return if (merge(segs, out)) { preview?.delete(); preview = out; previewCount = segs.size; out } else null
    }

    /** Kaydı bitirir; dosya ve süre (sn) döner. 1 sn'den kısaysa null. */
    fun stop(): Pair<File, Int>? {
        if (rec != null) endSegment()
        val sec = (accMs / 1000).toInt()
        paused = false
        val all = ArrayList(segs)
        segs.clear()
        preview?.delete(); preview = null; previewCount = -1
        if (all.isEmpty() || sec < 1) { all.forEach { it.delete() }; return null }
        if (all.size == 1) return Pair(all[0], sec)
        val out = File(ctx.cacheDir, "rec_${System.currentTimeMillis()}.m4a")
        val ok = merge(all, out)
        all.forEach { it.delete() }
        return if (ok) Pair(out, sec) else { out.delete(); null }
    }

    fun cancel() {
        val r = rec
        rec = null
        if (r != null) {
            try { r.stop() } catch (ignored: Throwable) { }
            try { r.release() } catch (ignored: Throwable) { }
        }
        cur?.delete(); cur = null
        segs.forEach { it.delete() }
        segs.clear()
        preview?.delete(); preview = null; previewCount = -1
        accMs = 0L
        paused = false
    }

    private fun merge(list: List<File>, out: File): Boolean {
        var muxer: MediaMuxer? = null
        var started = false
        return try {
            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var track = -1
            var offsetUs = 0L
            val buf = ByteBuffer.allocate(256 * 1024)
            val info = MediaCodec.BufferInfo()
            for (f in list) {
                val ex = MediaExtractor()
                try {
                    ex.setDataSource(f.absolutePath)
                    var ti = -1
                    for (i in 0 until ex.trackCount) {
                        val fmt = ex.getTrackFormat(i)
                        if ((fmt.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                            ti = i
                            if (track < 0) { track = muxer.addTrack(fmt); muxer.start(); started = true }
                            break
                        }
                    }
                    if (ti < 0) continue
                    ex.selectTrack(ti)
                    var lastUs = 0L
                    while (true) {
                        buf.clear()
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) break
                        val t = ex.sampleTime
                        info.set(0, n, t + offsetUs, if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                        muxer.writeSampleData(track, buf, info)
                        lastUs = t
                        ex.advance()
                    }
                    offsetUs += lastUs + 64000L
                } finally {
                    ex.release()
                }
            }
            if (started) muxer.stop()
            muxer.release()
            started
        } catch (e: Throwable) {
            try { if (started) muxer?.stop() } catch (ignored: Throwable) { }
            try { muxer?.release() } catch (ignored: Throwable) { }
            false
        }
    }
}

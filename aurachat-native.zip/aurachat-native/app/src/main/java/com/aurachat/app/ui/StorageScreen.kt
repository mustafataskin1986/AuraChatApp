package com.aurachat.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.LocalMedia
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private data class Cat(val title: String, val dir: String)

private val CATS = listOf(
    Cat("Resimler", "AuraChat Images"),
    Cat("Sesli mesajlar", "AuraChat Audio"),
    Cat("Belgeler", "AuraChat Documents")
)

private fun sizeOf(f: File): Long =
    if (f.isFile) f.length() else (f.listFiles()?.sumOf { sizeOf(it) } ?: 0L)

private fun fmt(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> "${b / 1024} KB"
    b < 1024L * 1024 * 1024 -> String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0)
    else -> String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0)
}

@Composable
fun StorageScreen(onBack: () -> Unit) {
    BackHandler { onBack() }
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    var sizes by remember { mutableStateOf<List<Long>?>(null) }
    var confirm by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(tick) {
        sizes = withContext(Dispatchers.IO) {
            val r = LocalMedia.rootDir()
            CATS.map { c -> if (r == null) 0L else sizeOf(File(r, c.dir)) }
        }
    }
    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Text("Depolama", color = AuraWhite, fontSize = 22.sp, modifier = Modifier.padding(start = 8.dp))
            }
            val s = sizes
            Text(
                if (s == null) "Hesaplanıyor…" else "Toplam: " + fmt(s.sum()),
                color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
            )
            Text(
                "Mesajlardaki medya telefonunda saklanır. Temizlediğin dosyalar telefondan silinir; Drive yedeğin varsa geri yükleyebilirsin.",
                color = AuraMuted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )
            CATS.forEachIndexed { i, c ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.title, color = AuraWhite, fontSize = 18.sp)
                        Text(if (s == null) "…" else fmt(s[i]), color = AuraMuted, fontSize = 14.sp)
                    }
                    if (s != null && s[i] > 0L) Text(
                        "Temizle", color = auraLc(0xFFEF4444), fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { confirm = i }.padding(8.dp)
                    )
                }
            }
        }
    }
    confirm?.let { i ->
        AuraAlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = AuraSurface,
            title = { Text("${CATS[i].title} silinsin mi?", color = AuraWhite, fontSize = 17.sp) },
            text = { Text("Bu dosyalar telefondan kalıcı olarak silinir.", color = AuraMuted) },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    scope.launch {
                        withContext(Dispatchers.IO) {
                            LocalMedia.rootDir()?.let { r -> File(r, CATS[i].dir).deleteRecursively() }
                            LocalMedia.scan()
                        }
                        tick++
                    }
                }) { Text("Sil", color = auraLc(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("İptal", color = AuraMuted) } }
        )
    }
}

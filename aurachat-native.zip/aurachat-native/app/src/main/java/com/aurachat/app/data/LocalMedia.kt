package com.aurachat.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max

/**
 * Yerel depolama (WhatsApp mantığı): gelen fotoğraf / ses / belge telefona
 * Android/media/<paket>/AuraChat/Media/... klasörüne yazılır, ardından Firebase'deki kopyası silinir.
 * Uygulama klasörü tarayıp her dosyayı mesaj kimliğinden geri bulur (uygulama silinse de klasör kalır).
 * Gönderdiklerimizin kopyası Sent alt klasörüne yazılır.
 */
object LocalMedia {
    private var app: Context? = null
    /** Dosya eklendikçe artar; Compose bunu okuyan ekranlar yeniden çizilir */
    var version by mutableIntStateOf(0)
        private set

    private val index = ConcurrentHashMap<String, String>() // "msgId" ya da "msgId_k" -> yol
    private val busy = ConcurrentHashMap.newKeySet<String>()
    private val nameRe = Regex("^AuraChat_\\d{8}_\\d{6}_([A-Za-z0-9]{20})(.*)$")
    private val stampFmt get() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    fun init(ctx: Context) {
        app = ctx.applicationContext
        Thread { scan() }.start()
    }

    private fun root(ctx: Context): File {
        val ext = try { ctx.externalMediaDirs.firstOrNull() } catch (e: Throwable) { null }
        val base = if (ext != null) File(ext, "AuraChat/Media") else File(ctx.filesDir, "AuraChat/Media")
        base.mkdirs()
        return base
    }

    private fun dirFor(ctx: Context, kind: String, sent: Boolean): File {
        val sub = when (kind) {
            "audio" -> "AuraChat Audio"
            "doc" -> "AuraChat Documents"
            else -> "AuraChat Images"
        }
        val d = File(root(ctx), sub)
        d.mkdirs()
        try { File(d, ".nomedia").createNewFile() } catch (e: Throwable) {}
        val out = if (sent) File(d, "Sent") else d
        out.mkdirs()
        return out
    }

    /** Klasörleri tarayıp mesaj kimliği -> dosya eşlemesini kurar */
    fun scan() {
        val ctx = app ?: return
        try {
            val r = root(ctx)
            var found = false
            r.listFiles()?.forEach { sub ->
                if (!sub.isDirectory) return@forEach
                val files = ArrayList<File>()
                sub.listFiles()?.forEach { f ->
                    if (f.isDirectory && f.name == "Sent") f.listFiles()?.let { files.addAll(it) } else files.add(f)
                }
                files.forEach { f ->
                    if (f.isFile && f.length() == 0L && f.name.startsWith("AuraChat_")) { try { f.delete() } catch (e: Throwable) {}; return@forEach }
                    val m = nameRe.find(f.name) ?: return@forEach
                    val id = m.groupValues[1]
                    val rest = m.groupValues[2]
                    val k = Regex("^_(\\d+)\\.").find(rest)?.groupValues?.get(1)
                    index[if (k != null) "${id}_$k" else id] = f.absolutePath
                    found = true
                }
            }
            if (found) version++
        } catch (e: Throwable) {}
    }

    private fun pathOf(key: String): String? {
        val p = index[key] ?: return null
        val f = File(p)
        if (f.exists() && f.length() == 0L) { try { f.delete() } catch (e: Throwable) {} }
        return if (f.exists()) p else { index.remove(key); null }
    }

    /** Dosya telefonda varsa mesajdaki veri alanlarını "file:<yol>" ile değiştirir */
    fun localize(m: Message): Message {
        if (m.deleted || m.viewOnce) return m
        return when (m.type) {
            "image" -> {
                val n = max(m.imagesCount, m.images.size)
                if (n > 1) {
                    var any = false
                    val list = (0 until n).map { i ->
                        val p = pathOf("${m.id}_$i")
                        if (p != null) { any = true; "file:$p" } else m.images.getOrNull(i) ?: ""
                    }.filter { it.isNotEmpty() }
                    if (any) m.copy(images = list) else m
                } else {
                    val p = pathOf(m.id)
                    if (p != null) m.copy(imageUrl = "file:$p") else m
                }
            }
            "audio" -> pathOf(m.id)?.let { m.copy(audio = "file:$it") } ?: m
            "document" -> pathOf(m.id)?.let { m.copy(imageUrl = "file:$it") } ?: m
            else -> m
        }
    }

    /** Telefona yazılması ya da Firebase kopyasının silinmesi gereken veri taşıyan mesaj mı? */
    fun needsIngest(m: Message, me: String, isGroup: Boolean): Boolean {
        if (m.deleted || m.viewOnce) return false
        val ack = m.senderUid != me && !isGroup // alıcıysam Firebase'deki kopya silinecek
        return when (m.type) {
            "image" -> {
                val n = max(m.imagesCount, m.images.size)
                if (n > 1) m.images.any { it.isNotEmpty() } && (ack || (0 until n).any { pathOf("${m.id}_$it") == null })
                else m.imageUrl.isNotEmpty() && !m.imageUrl.startsWith("file:") && (ack || pathOf(m.id) == null)
            }
            "audio" -> m.audio.isNotEmpty() && !m.audio.startsWith("file:") && (ack || pathOf(m.id) == null)
            "document" -> m.imageUrl.isNotEmpty() && !m.imageUrl.startsWith("file:") && (ack || pathOf(m.id) == null)
            else -> false
        }
    }

    /**
     * Mesajın medyasını telefona yazar. Alıcı tarafında (birebir sohbet) yazma doğrulanınca
     * Firebase'deki kopya silinir. Arka plan iş parçacığında çağrılmalıdır (bloklar).
     */
    fun ingestBlocking(chatId: String, m: Message, me: String, isGroup: Boolean) {
        val ctx = app ?: return
        if (m.deleted || m.viewOnce) return
        if (!busy.add(m.id)) return
        try {
            val sent = m.senderUid == me
            val stamp = stampFmt.format(Date(if (m.time > 0) m.time else System.currentTimeMillis()))
            val canAck = !sent && !isGroup
            when (m.type) {
                "image" -> {
                    val list = (if (m.images.isNotEmpty()) m.images else listOf(m.imageUrl)).filter { it.isNotEmpty() }
                    if (list.isEmpty() || list.any { it.startsWith("file:") }) return
                    val album = max(m.imagesCount, m.images.size) > 1
                    var ok = true
                    var wrote = false
                    list.forEachIndexed { k, data ->
                        val key = if (album) "${m.id}_$k" else m.id
                        if (pathOf(key) != null) return@forEachIndexed
                        val ext = if (Media.mimeOf(data).contains("png")) "png" else "jpg"
                        val name = "AuraChat_${stamp}_${m.id}" + (if (album) "_$k" else "") + ".$ext"
                        val f = write(File(dirFor(ctx, "image", sent), name), data)
                        if (f != null) { index[key] = f.absolutePath; wrote = true } else ok = false
                    }
                    if (wrote) version++
                    if (ok && canAck) {
                        if (album) Repo.ackMediaBlocking(chatId, m.id, mapOf("images" to null, "imagesDelivered" to true))
                        else Repo.ackMediaBlocking(chatId, m.id, mapOf("imageUrl" to null, "imageDelivered" to true))
                    }
                }
                "audio" -> {
                    if (m.audio.isEmpty() || m.audio.startsWith("file:")) return
                    var ok = pathOf(m.id) != null
                    if (!ok) {
                        val mime = Media.mimeOf(m.audio)
                        val ext = when {
                            mime.contains("mp4") || mime.contains("m4a") -> "m4a"
                            mime.contains("mpeg") || mime.contains("mp3") -> "mp3"
                            mime.contains("ogg") -> "ogg"
                            mime.contains("wav") -> "wav"
                            mime.contains("aac") -> "aac"
                            else -> "webm"
                        }
                        val f = write(File(dirFor(ctx, "audio", sent), "AuraChat_${stamp}_${m.id}.$ext"), m.audio)
                        if (f != null) { index[m.id] = f.absolutePath; ok = true }
                        version++
                    }
                    if (ok && canAck) Repo.ackMediaBlocking(chatId, m.id, mapOf("audio" to null, "audioDelivered" to true))
                }
                "document" -> {
                    if (m.imageUrl.isEmpty() || m.imageUrl.startsWith("file:")) return
                    var ok = pathOf(m.id) != null
                    if (!ok) {
                        val safe = m.fileName.ifBlank { "belge" }.replace(Regex("[\\\\/:*?\"<>|]+"), "_").take(80)
                        val f = write(File(dirFor(ctx, "doc", sent), "AuraChat_${stamp}_${m.id}__$safe"), m.imageUrl)
                        if (f != null) { index[m.id] = f.absolutePath; ok = true }
                        version++
                    }
                    if (ok && canAck) Repo.ackMediaBlocking(chatId, m.id, mapOf("imageUrl" to null, "imageDelivered" to true))
                }
            }
        } catch (e: Throwable) {
        } finally {
            busy.remove(m.id)
        }
    }

    private fun write(f: File, dataUrl: String): File? = try {
        val bytes = Media.bytesOf(dataUrl)
        if (bytes.isEmpty()) null
        else {
            f.writeBytes(bytes)
            if (f.exists() && f.length() == bytes.size.toLong()) f else { try { f.delete() } catch (e: Throwable) {}; null }
        }
    } catch (e: Throwable) { null }

    /** Bildirim servisi için: mesajı sunucudan okuyup telefona yazar (ağ ve disk işi, bloklar) */
    fun ingestRemoteBlocking(chatId: String, msgId: String, me: String, isGroup: Boolean) {
        val m = Repo.fetchMessageBlocking(chatId, msgId) ?: return
        ingestBlocking(chatId, m, me, isGroup)
    }
}

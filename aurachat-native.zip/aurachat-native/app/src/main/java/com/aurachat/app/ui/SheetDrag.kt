package com.aurachat.app.ui

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Tam ekrana yakın alt sayfaların (Durum ekleyin, Yerleşim) parmakla aşağı çekilip kapanması */
class SheetDrag(
    private val scope: CoroutineScope,
    private val thresholdPx: Float,
    private val farPx: Float,
    var onDismiss: () -> Unit
) {
    var off by mutableFloatStateOf(0f)
    private var closing = false
    private var job: Job? = null

    private fun animTo(target: Float, ms: Int, after: () -> Unit = {}) {
        job?.cancel()
        job = scope.launch {
            animate(off, target, animationSpec = tween(ms)) { v, _ -> off = v }
            after()
        }
    }

    fun settle(vel: Float) {
        if (closing) return
        if (off > thresholdPx || vel > 1500f) {
            closing = true
            animTo(farPx, 220) { onDismiss() }
        } else animTo(0f, 200)
    }

    val nested = object : NestedScrollConnection {
        override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
            if (closing) return Offset.Zero
            if (off > 0f && available.y < 0f) {
                job?.cancel()
                val n = (off + available.y).coerceAtLeast(0f)
                val used = n - off
                off = n
                return Offset(0f, used)
            }
            return Offset.Zero
        }
        override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
            if (closing) return Offset.Zero
            if (available.y > 0f && source == NestedScrollSource.Drag) {
                job?.cancel()
                off += available.y
                return Offset(0f, available.y)
            }
            return Offset.Zero
        }
        override suspend fun onPreFling(available: Velocity): Velocity {
            if (off > 0f && !closing) { settle(available.y); return available }
            return Velocity.Zero
        }
    }
}

@Composable
fun rememberSheetDrag(onDismiss: () -> Unit): SheetDrag {
    val scope = rememberCoroutineScope()
    val d = LocalDensity.current
    val h = LocalConfiguration.current.screenHeightDp
    val sd = remember { SheetDrag(scope, with(d) { 90.dp.toPx() }, with(d) { h.dp.toPx() }, onDismiss) }
    sd.onDismiss = onDismiss
    return sd
}

/** Sayfanın kendisi: parmakla çekilince aşağı kayar; içindeki liste en üstteyken aşağı çekmek de sayfayı kapatır */
fun Modifier.sheetDrag(sd: SheetDrag): Modifier =
    this.offset { IntOffset(0, sd.off.roundToInt().coerceAtLeast(0)) }.nestedScroll(sd.nested)

/** Üst tutamaç / başlık alanı: buradan aşağı sürüklemek sayfayı kapatır */
fun Modifier.sheetHandle(sd: SheetDrag): Modifier = this.pointerInput(sd) {
    var vy = 0f
    detectVerticalDragGestures(
        onDragStart = { vy = 0f },
        onVerticalDrag = { _, dy -> sd.off = (sd.off + dy).coerceAtLeast(0f); vy = dy * 60f },
        onDragEnd = { sd.settle(vy) },
        onDragCancel = { sd.settle(0f) }
    )
}

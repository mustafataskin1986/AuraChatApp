package com.aurachat.app.data

data class UserProfile(
    val uid: String,
    val name: String,
    val phone: String = "",
    val avatar: String = ""
)

/** Bir sohbetin kimliği: birebir ya da grup */
data class ChatTarget(
    val chatId: String,
    val isGroup: Boolean,
    /** birebirde karşı kişinin uid'si, grupta grup id'si */
    val otherUid: String,
    val name: String
)

/** users/{uid}/chats/{chatId} özet dokümanı */
data class ChatSummary(
    val chatId: String,
    val isGroup: Boolean,
    val otherUid: String,
    val name: String,
    val lastMessage: String,
    val lastTime: Long,
    val lastSenderUid: String,
    val lastSenderName: String,
    val lastRead: Boolean,
    val unread: Int,
    val pinned: Boolean,
    val favorite: Boolean,
    val typing: Boolean,
    val clearedAt: Long
)

data class ReplyRef(
    val msgId: String,
    val senderName: String,
    val previewText: String,
    val senderUid: String = ""
)

/** chats/{chatId}/messages/{id} */
data class Message(
    val id: String,
    val type: String,
    val text: String,
    val senderUid: String,
    val senderName: String,
    val time: Long,
    val read: Boolean,
    val readBy: List<String>,
    val deleted: Boolean,
    val deletedFor: List<String>,
    val pending: Boolean,
    val imageUrl: String,
    val images: List<String>,
    val imagesCount: Int,
    val audio: String,
    val audioDuration: Int,
    val lat: Double,
    val lng: Double,
    val hasLocation: Boolean,
    val fileName: String,
    val fileMime: String,
    val replyTo: ReplyRef?,
    val reactions: Map<String, String>,
    val edited: Boolean,
    val forwarded: Boolean,
    val callDuration: Int
)

data class GroupData(
    val id: String,
    val name: String,
    val members: List<String>,
    val admins: List<String>,
    val createdBy: String,
    val photo: String
)

data class StarredItem(
    val key: String,
    val chatId: String,
    val msgId: String,
    val chatName: String,
    val preview: String,
    val senderName: String,
    val msgTime: Long
)

data class OpenChat(val chatId: String, val otherUid: String, val otherName: String)

package com.aurachat.app.data

data class UserProfile(
    val uid: String,
    val name: String,
    val phone: String = "",
    val avatar: String = ""
)

/** users/{uid}/chats/{chatId} özet dokümanı */
data class ChatSummary(
    val chatId: String,
    val otherUid: String,
    val otherName: String,
    val lastMessage: String,
    val lastTime: Long,
    val lastSenderUid: String,
    val lastRead: Boolean,
    val unread: Int,
    val pinned: Boolean,
    val archived: Boolean,
    val typing: Boolean
)

/** chats/{chatId}/messages/{id} */
data class Message(
    val id: String,
    val text: String,
    val senderUid: String,
    val time: Long,
    val read: Boolean,
    val type: String,
    val deleted: Boolean,
    val pending: Boolean
)

data class OpenChat(val chatId: String, val otherUid: String, val otherName: String)

package com.aurachat.app.call

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Vibrator
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class Phase { IDLE, INCOMING, OUTGOING, CONNECTING, CONNECTED, ENDED }

data class CallUi(
    val phase: Phase = Phase.IDLE,
    val chatId: String = "",
    val otherUid: String = "",
    val otherName: String = "",
    val otherAvatar: String = "",
    val video: Boolean = false,
    val isCaller: Boolean = false,
    val micOn: Boolean = true,
    val camOn: Boolean = true,
    val speakerOn: Boolean = false,
    val frontCam: Boolean = true,
    val connectedAt: Long = 0L,
    val message: String = "",
    val remoteVideo: VideoTrack? = null,
    val localVideo: VideoTrack? = null
)

/**
 * Sesli / görüntülü arama motoru. Web ile aynı Firestore sinyalleşmesini kullanır:
 * chats/{chatId}/call/current (offer/answer/status) + callerCandidates / calleeCandidates + incomingCalls/{uid}
 */
object CallManager {
    private const val NOTIF_FG = 7002
    const val CALL_NOTIF_TAG = "aura_call_"

    private lateinit var app: Context
    private val db get() = FirebaseFirestore.getInstance()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _ui = MutableStateFlow(CallUi())
    val ui: StateFlow<CallUi> = _ui

    val egl: EglBase by lazy { EglBase.create() }

    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private var audioSource: org.webrtc.AudioSource? = null
    private var audioTrack: AudioTrack? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var capturer: CameraVideoCapturer? = null
    private var textureHelper: SurfaceTextureHelper? = null

    private var me: UserProfile? = null
    private var incomingReg: ListenerRegistration? = null
    private var incomingForUid: String = ""
    private var callDocReg: ListenerRegistration? = null
    private var candReg: ListenerRegistration? = null
    private var pendingOffer: String? = null
    private var pendingCallerUid: String = ""
    private var remoteSet = false
    private val pendingCands = ArrayList<IceCandidate>()
    private var timeoutJob: Job? = null

    private var ringtone: Ringtone? = null
    private var tone: ToneGenerator? = null
    @Volatile private var callGen = 0
    private var prevAudioMode = AudioManager.MODE_NORMAL
    private var prevSpeaker = false
    private var audioRouted = false

    fun init(ctx: Context) {
        app = ctx.applicationContext
        GroupCallManager.init(ctx)
    }

    fun setMe(p: UserProfile) {
        me = p
    }

    private fun toast(s: String) = Toast.makeText(app, s, Toast.LENGTH_SHORT).show()

    // =====================================================================
    //  GELEN ARAMA DİNLEYİCİSİ (uygulama açıkken)
    // =====================================================================
    fun startWatching(p: UserProfile) {
        me = p
        if (incomingReg != null && incomingForUid == p.uid) return
        incomingReg?.remove()
        incomingForUid = p.uid
        incomingReg = db.collection("incomingCalls").document(p.uid).addSnapshotListener { snap, _ ->
            if (snap == null || !snap.exists()) return@addSnapshotListener
            val chatId = snap.getString("chatId") ?: return@addSnapshotListener
            val at = snap.getLong("at") ?: return@addSnapshotListener
            if (Math.abs(System.currentTimeMillis() - at) > 90_000L) return@addSnapshotListener
            if (snap.getBoolean("isGroup") == true) {
                if (_ui.value.phase == Phase.IDLE && p.uid != (snap.getString("callerUid") ?: "")) {
                    GroupCallManager.onIncoming(
                        chatId, snap.getString("callerName") ?: "", snap.getString("groupName") ?: "",
                        snap.getString("callType") != "audio", snap.getLong("callId") ?: 0L
                    )
                }
                return@addSnapshotListener
            }
            if (_ui.value.phase != Phase.IDLE) return@addSnapshotListener
            if (GroupCallManager.busy()) return@addSnapshotListener
            listenCallDoc(chatId)
        }
    }

    private fun callDoc(chatId: String) = db.collection("chats").document(chatId).collection("call").document("current")
    private fun candCol(chatId: String, who: String) = callDoc(chatId).collection(who)

    private fun listenCallDoc(chatId: String) {
        callDocReg?.remove()
        callDocReg = callDoc(chatId).addSnapshotListener { snap, _ ->
            if (snap != null && snap.exists()) onCallDoc(chatId, snap)
        }
    }

    private fun onCallDoc(chatId: String, d: DocumentSnapshot) {
        val myUid = me?.uid ?: return
        val status = d.getString("status") ?: ""
        val callType = d.getString("callType") ?: "video"
        val cur = _ui.value

        if (cur.phase == Phase.IDLE && status == "ringing" && d.getString("calleeUid") == myUid) {
            val created = d.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time
            if (created != null && Math.abs(System.currentTimeMillis() - created) > 90_000L) return
            val offer = (d.get("offer") as? Map<*, *>)?.get("sdp") as? String ?: return
            showIncoming(
                chatId, d.getString("callerUid") ?: "", d.getString("callerName") ?: "",
                d.getString("callerAvatar") ?: "", callType != "audio", offer
            )
            return
        }
        if (status == "ended" || status == "declined") {
            when (cur.phase) {
                Phase.INCOMING -> { stopRinging(); cancelCallNotif(chatId); resetAll() }
                Phase.OUTGOING, Phase.CONNECTING, Phase.CONNECTED ->
                    finish(if (status == "declined") "Arama reddedildi" else "Arama sonlandı")
                else -> {}
            }
            return
        }
        if (status == "active" && cur.isCaller && cur.phase == Phase.OUTGOING) {
            val answer = (d.get("answer") as? Map<*, *>)?.get("sdp") as? String ?: return
            val p = pc ?: return
            if (remoteSet) return
            scope.launch {
                try {
                    p.setRemote(SessionDescription(SessionDescription.Type.ANSWER, answer))
                    remoteSet = true
                    drainCandidates()
                    stopRingback()
                    timeoutJob?.cancel()
                    _ui.update { it.copy(phase = Phase.CONNECTING, message = "Bağlanıyor...") }
                } catch (e: Throwable) {
                    hangup("Bağlantı kurulamadı")
                }
            }
        }
    }

    private fun showIncoming(chatId: String, callerUid: String, callerName: String, avatar: String, video: Boolean, offer: String) {
        pendingOffer = offer
        pendingCallerUid = callerUid
        _ui.value = CallUi(
            phase = Phase.INCOMING, chatId = chatId, otherUid = callerUid, otherName = callerName.ifBlank { "Bilinmeyen" },
            otherAvatar = avatar, video = video, isCaller = false, speakerOn = video
        )
        cancelCallNotif(chatId)
        startRinging()
        timeoutJob?.cancel()
        timeoutJob = scope.launch {
            delay(60_000)
            if (_ui.value.phase == Phase.INCOMING) {
                stopRinging()
                cancelCallNotif(chatId)
                resetAll()
            }
        }
        if (avatar.isBlank() && callerUid.isNotEmpty()) {
            scope.launch {
                val a = try { Repo.avatarOf(callerUid) } catch (e: Throwable) { "" }
                if (a.isNotEmpty()) _ui.update { if (it.otherUid == callerUid) it.copy(otherAvatar = a) else it }
            }
        }
    }

    // =====================================================================
    //  ARAMA BAŞLAT
    // =====================================================================
    fun startCall(p: UserProfile, target: ChatTarget, video: Boolean) {
        me = p
        if (_ui.value.phase != Phase.IDLE || GroupCallManager.busy()) {
            toast("Zaten bir arama devam ediyor")
            return
        }
        val chatId = target.chatId
        val other = target.otherUid
        if (target.isGroup || other.isEmpty()) {
            toast("Arama yalnızca kişisel sohbetlerde yapılabilir")
            return
        }
        _ui.value = CallUi(
            phase = Phase.OUTGOING, chatId = chatId, otherUid = other, otherName = target.name, video = video,
            isCaller = true, speakerOn = video, message = "Aranıyor..."
        )
        val gen = ++callGen
        scope.launch {
            try {
                launch {
                    val a = try { Repo.avatarOf(other) } catch (e: Throwable) { "" }
                    if (a.isNotEmpty()) _ui.update { if (it.otherUid == other) it.copy(otherAvatar = a) else it }
                }
                clearCandidates(chatId)
                startService()
                setupAudioRoute(video)
                val p2 = createPeer(chatId, "callerCandidates", video)
                val offer = p2.createOfferSuspend(video)
                p2.setLocal(offer)
                if (gen != callGen) { if (idleNow()) releaseMedia(); return@launch }

                val doc = HashMap<String, Any>()
                doc["callerUid"] = p.uid
                doc["callerName"] = p.name
                doc["callerAvatar"] = p.avatar
                doc["calleeUid"] = other
                doc["status"] = "ringing"
                doc["callType"] = if (video) "video" else "audio"
                doc["offer"] = hashMapOf("type" to "offer", "sdp" to offer.description)
                doc["createdAt"] = FieldValue.serverTimestamp()
                callDoc(chatId).set(doc).await()
                if (gen != callGen) {
                    try { callDoc(chatId).update("status", "ended").await() } catch (e: Throwable) {}
                    if (idleNow()) releaseMedia()
                    return@launch
                }

                try {
                    db.collection("incomingCalls").document(other).set(
                        hashMapOf(
                            "chatId" to chatId, "callType" to (if (video) "video" else "audio"), "isGroup" to false,
                            "callerUid" to p.uid, "callerName" to p.name, "at" to System.currentTimeMillis()
                        )
                    ).await()
                } catch (e: Throwable) {}
                launch {
                    Repo.sendCallPush(
                        other, p.name, if (video) "📹 Görüntülü arama yapıyor..." else "📞 Sesli arama yapıyor...",
                        chatId, p.uid, p.name, if (video) "video" else "audio", true
                    )
                }

                if (gen != callGen) { if (idleNow()) releaseMedia(); return@launch }
                listenCallDoc(chatId)
                listenCandidates(chatId, "calleeCandidates")
                startRingback()
                timeoutJob?.cancel()
                timeoutJob = scope.launch {
                    delay(45_000)
                    if (_ui.value.phase == Phase.OUTGOING) hangup("Cevap verilmedi")
                }
            } catch (e: Throwable) {
                if (gen == callGen) finish("Arama başlatılamadı")
            }
        }
    }

    // =====================================================================
    //  CEVAPLA / REDDET / KAPAT
    // =====================================================================
    fun accept() {
        val cur = _ui.value
        if (cur.phase != Phase.INCOMING) return
        val offer = pendingOffer ?: return
        stopRinging()
        _ui.update { it.copy(phase = Phase.CONNECTING, message = "Bağlanıyor...") }
        scope.launch {
            try {
                startService()
                setupAudioRoute(cur.video)
                val p = createPeer(cur.chatId, "calleeCandidates", cur.video)
                p.setRemote(SessionDescription(SessionDescription.Type.OFFER, offer))
                remoteSet = true
                val answer = p.createAnswerSuspend()
                p.setLocal(answer)
                callDoc(cur.chatId).update(
                    mapOf("status" to "active", "answer" to hashMapOf("type" to "answer", "sdp" to answer.description))
                ).await()
                listenCandidates(cur.chatId, "callerCandidates")
                drainCandidates()
            } catch (e: Throwable) {
                hangup("Bağlantı kurulamadı")
            }
        }
    }

    fun decline() {
        val cur = _ui.value
        if (cur.phase != Phase.INCOMING) return
        val my = me
        stopRinging()
        cancelCallNotif(cur.chatId)
        scope.launch {
            try { callDoc(cur.chatId).update("status", "declined").await() } catch (e: Throwable) {}
            if (my != null && cur.otherUid.isNotEmpty()) {
                try {
                    Repo.logDeclinedCall(cur.chatId, cur.otherUid, cur.otherName, my.uid, my.name, if (cur.video) "video" else "audio")
                } catch (e: Throwable) {}
            }
        }
        resetAll()
    }

    fun hangup(message: String = "Arama sonlandı") {
        val cur = _ui.value
        if (cur.phase == Phase.IDLE || cur.phase == Phase.ENDED) return
        if (cur.phase == Phase.INCOMING) { decline(); return }
        val my = me
        val talkSec = if (cur.connectedAt > 0) ((System.currentTimeMillis() - cur.connectedAt) / 1000L).toInt() else 0
        // arayüz hemen kapansın, kayıtlar arka planda yazılsın
        finish(message)
        scope.launch {
            try {
                val snap = callDoc(cur.chatId).get().await()
                val status = snap.getString("status") ?: ""
                val callerUid = snap.getString("callerUid") ?: ""
                val calleeUid = snap.getString("calleeUid") ?: ""
                try { callDoc(cur.chatId).update("status", "ended").await() } catch (e: Throwable) {}
                val type = if (cur.video) "video" else "audio"
                if (my != null) {
                    if (cur.connectedAt > 0 && status == "active" && callerUid.isNotEmpty()) {
                        Repo.logCallDuration(cur.chatId, my.uid, my.name, cur.otherUid, cur.otherName, type, talkSec, callerUid)
                    } else if (status == "ringing" && cur.isCaller && calleeUid.isNotEmpty()) {
                        Repo.logMissedCall(cur.chatId, my.uid, my.name, calleeUid, cur.otherName, type)
                        Repo.sendCallPush(
                            calleeUid, my.name, if (cur.video) "📹 Cevapsız görüntülü arama" else "📞 Cevapsız sesli arama",
                            cur.chatId, my.uid, my.name, type, false
                        )
                    }
                }
            } catch (e: Throwable) {}
        }
    }

    // =====================================================================
    //  KONTROLLER
    // =====================================================================
    fun toggleMic() {
        val on = !_ui.value.micOn
        audioTrack?.setEnabled(on)
        _ui.update { it.copy(micOn = on) }
    }

    fun toggleCam() {
        val on = !_ui.value.camOn
        videoTrack?.setEnabled(on)
        _ui.update { it.copy(camOn = on) }
    }

    fun switchCamera() {
        val c = capturer ?: return
        try {
            c.switchCamera(object : CameraVideoCapturer.CameraSwitchHandler {
                override fun onCameraSwitchDone(isFrontCamera: Boolean) {
                    _ui.update { it.copy(frontCam = isFrontCamera) }
                }
                override fun onCameraSwitchError(errorDescription: String?) {}
            })
        } catch (e: Throwable) {}
    }

    fun toggleSpeaker() {
        val on = !_ui.value.speakerOn
        setSpeaker(on)
        _ui.update { it.copy(speakerOn = on) }
    }

    private fun setSpeaker(on: Boolean) {
        try {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            @Suppress("DEPRECATION")
            am.isSpeakerphoneOn = on
        } catch (e: Throwable) {}
    }

    private fun setupAudioRoute(video: Boolean) {
        try {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            prevAudioMode = am.mode
            @Suppress("DEPRECATION")
            prevSpeaker = am.isSpeakerphoneOn
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            @Suppress("DEPRECATION")
            am.isSpeakerphoneOn = video
            audioRouted = true
        } catch (e: Throwable) {}
    }

    private fun restoreAudioRoute() {
        if (!audioRouted) return
        audioRouted = false
        try {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            @Suppress("DEPRECATION")
            am.isSpeakerphoneOn = prevSpeaker
            am.mode = prevAudioMode
        } catch (e: Throwable) {}
    }

    // =====================================================================
    //  WEBRTC
    // =====================================================================
    fun ensureFactory(): PeerConnectionFactory {
        factory?.let { return it }
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(app).createInitializationOptions()
        )
        val f = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext))
            .createPeerConnectionFactory()
        factory = f
        return f
    }

    private fun createPeer(chatId: String, myCandidates: String, video: Boolean): PeerConnection {
        val f = ensureFactory()
        remoteSet = false
        pendingCands.clear()
        val servers = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )
        val cfg = PeerConnection.RTCConfiguration(servers)
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val p = f.createPeerConnection(cfg, object : PeerConnection.Observer {
            override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                scope.launch {
                    when (s) {
                        PeerConnection.IceConnectionState.CONNECTED, PeerConnection.IceConnectionState.COMPLETED -> onConnected()
                        PeerConnection.IceConnectionState.FAILED -> if (_ui.value.isCaller) hangup("Bağlantı kurulamadı")
                        else -> {}
                    }
                }
            }
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(c: IceCandidate?) {
                if (c == null) return
                val m = hashMapOf<String, Any>(
                    "candidate" to c.sdp, "sdpMid" to (c.sdpMid ?: ""), "sdpMLineIndex" to c.sdpMLineIndex
                )
                candCol(chatId, myCandidates).add(m)
            }
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
            override fun onAddStream(s: MediaStream?) {}
            override fun onRemoveStream(s: MediaStream?) {}
            override fun onDataChannel(d: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver?, s: Array<out MediaStream>?) {
                val t = r?.track()
                if (t is VideoTrack) _ui.update { it.copy(remoteVideo = t) }
            }
            override fun onTrack(t: RtpTransceiver?) {
                val tr = t?.receiver?.track()
                if (tr is VideoTrack) _ui.update { it.copy(remoteVideo = tr) }
            }
        }) ?: throw IllegalStateException("peer")
        pc = p

        // mikrofon
        val aSrc = f.createAudioSource(MediaConstraints())
        audioSource = aSrc
        val aTrack = f.createAudioTrack("aura_audio", aSrc)
        audioTrack = aTrack
        p.addTrack(aTrack, listOf("aura_stream"))

        // kamera
        if (video) {
            val enumerator = Camera2Enumerator(app)
            val names = enumerator.deviceNames
            val front = names.firstOrNull { enumerator.isFrontFacing(it) }
            val name = front ?: names.firstOrNull()
            if (name != null) {
                val cap = enumerator.createCapturer(name, null)
                if (cap != null) {
                    val helper = SurfaceTextureHelper.create("AuraCapture", egl.eglBaseContext)
                    val vSrc = f.createVideoSource(false)
                    cap.initialize(helper, app, vSrc.capturerObserver)
                    cap.startCapture(1280, 720, 30)
                    val vTrack = f.createVideoTrack("aura_video", vSrc)
                    p.addTrack(vTrack, listOf("aura_stream"))
                    capturer = cap
                    textureHelper = helper
                    videoSource = vSrc
                    videoTrack = vTrack
                    _ui.update { it.copy(localVideo = vTrack, frontCam = front != null) }
                }
            }
        }
        return p
    }

    private fun onConnected() {
        val cur = _ui.value
        if (cur.phase == Phase.CONNECTED || cur.phase == Phase.IDLE || cur.phase == Phase.ENDED || cur.phase == Phase.INCOMING) return
        stopRingback()
        timeoutJob?.cancel()
        _ui.update { it.copy(phase = Phase.CONNECTED, connectedAt = System.currentTimeMillis(), message = "") }
    }

    private fun listenCandidates(chatId: String, who: String) {
        candReg?.remove()
        candReg = candCol(chatId, who).addSnapshotListener { snap, _ ->
            if (snap == null) return@addSnapshotListener
            for (ch in snap.documentChanges) {
                if (ch.type != com.google.firebase.firestore.DocumentChange.Type.ADDED) continue
                val d = ch.document
                val sdp = d.getString("candidate") ?: continue
                val mid = d.getString("sdpMid") ?: ""
                val idx = (d.getLong("sdpMLineIndex") ?: 0L).toInt()
                val c = IceCandidate(mid, idx, sdp)
                val p = pc
                if (p != null && remoteSet) {
                    try { p.addIceCandidate(c) } catch (e: Throwable) {}
                } else {
                    pendingCands.add(c)
                }
            }
        }
    }

    private fun drainCandidates() {
        val p = pc ?: return
        for (c in pendingCands) {
            try { p.addIceCandidate(c) } catch (e: Throwable) {}
        }
        pendingCands.clear()
    }

    private suspend fun clearCandidates(chatId: String) {
        try {
            for (who in listOf("callerCandidates", "calleeCandidates")) {
                val snap = candCol(chatId, who).get().await()
                for (d in snap.documents) {
                    try { d.reference.delete().await() } catch (e: Throwable) {}
                }
            }
        } catch (e: Throwable) {}
    }

    // ---- SDP yardımcıları ----
    private suspend fun PeerConnection.createOfferSuspend(video: Boolean): SessionDescription =
        suspendCancellableCoroutine { c ->
            val mc = MediaConstraints()
            mc.mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mc.mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", if (video) "true" else "false"))
            createOffer(object : SdpObserver {
                override fun onCreateSuccess(d: SessionDescription?) { if (d != null) c.resume(d) else c.resumeWithException(Exception("offer")) }
                override fun onSetSuccess() {}
                override fun onCreateFailure(e: String?) { c.resumeWithException(Exception(e ?: "offer")) }
                override fun onSetFailure(e: String?) {}
            }, mc)
        }

    private suspend fun PeerConnection.createAnswerSuspend(): SessionDescription =
        suspendCancellableCoroutine { c ->
            createAnswer(object : SdpObserver {
                override fun onCreateSuccess(d: SessionDescription?) { if (d != null) c.resume(d) else c.resumeWithException(Exception("answer")) }
                override fun onSetSuccess() {}
                override fun onCreateFailure(e: String?) { c.resumeWithException(Exception(e ?: "answer")) }
                override fun onSetFailure(e: String?) {}
            }, MediaConstraints())
        }

    private suspend fun PeerConnection.setLocal(d: SessionDescription) =
        suspendCancellableCoroutine<Unit> { c ->
            setLocalDescription(object : SdpObserver {
                override fun onCreateSuccess(x: SessionDescription?) {}
                override fun onSetSuccess() { c.resume(Unit) }
                override fun onCreateFailure(e: String?) {}
                override fun onSetFailure(e: String?) { c.resumeWithException(Exception(e ?: "setLocal")) }
            }, d)
        }

    private suspend fun PeerConnection.setRemote(d: SessionDescription) =
        suspendCancellableCoroutine<Unit> { c ->
            setRemoteDescription(object : SdpObserver {
                override fun onCreateSuccess(x: SessionDescription?) {}
                override fun onSetSuccess() { c.resume(Unit) }
                override fun onCreateFailure(e: String?) {}
                override fun onSetFailure(e: String?) { c.resumeWithException(Exception(e ?: "setRemote")) }
            }, d)
        }

    // =====================================================================
    //  BİTİR / TEMİZLE
    // =====================================================================
    private fun finish(message: String) {
        val cur = _ui.value
        if (cur.phase == Phase.IDLE || cur.phase == Phase.ENDED) return
        _ui.update { it.copy(phase = Phase.ENDED, message = message) }
        releaseMedia()
        scope.launch {
            delay(900)
            if (_ui.value.phase == Phase.ENDED) _ui.value = CallUi()
        }
    }

    private fun resetAll() {
        releaseMedia()
        _ui.value = CallUi()
    }

    private fun releaseMedia() {
        callGen++
        timeoutJob?.cancel()
        stopRingback()
        stopRinging()
        callDocReg?.remove(); callDocReg = null
        candReg?.remove(); candReg = null
        try { capturer?.stopCapture() } catch (e: Throwable) {}
        try { capturer?.dispose() } catch (e: Throwable) {}
        capturer = null
        try { textureHelper?.dispose() } catch (e: Throwable) {}
        textureHelper = null
        try { videoTrack?.dispose() } catch (e: Throwable) {}
        videoTrack = null
        try { videoSource?.dispose() } catch (e: Throwable) {}
        videoSource = null
        try { audioTrack?.dispose() } catch (e: Throwable) {}
        audioTrack = null
        try { audioSource?.dispose() } catch (e: Throwable) {}
        audioSource = null
        try { pc?.close() } catch (e: Throwable) {}
        try { pc?.dispose() } catch (e: Throwable) {}
        pc = null
        remoteSet = false
        pendingCands.clear()
        pendingOffer = null
        pendingCallerUid = ""
        restoreAudioRoute()
        stopService()
    }

    // =====================================================================
    //  ZİL / GERİ ARAMA SESİ / SERVİS / BİLDİRİM
    // =====================================================================
    private fun startRinging() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val r = RingtoneManager.getRingtone(app, uri)
            if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
            r.play()
            ringtone = r
        } catch (e: Throwable) {}
        try {
            val v = app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            @Suppress("DEPRECATION")
            v?.vibrate(longArrayOf(0, 400, 300, 400, 1200), 0)
        } catch (e: Throwable) {}
    }

    private fun stopRinging() {
        try { ringtone?.stop() } catch (e: Throwable) {}
        ringtone = null
        try {
            val v = app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            v?.cancel()
        } catch (e: Throwable) {}
    }

    private fun idleNow() = _ui.value.phase == Phase.IDLE || _ui.value.phase == Phase.ENDED

    private fun startRingback() {
        if (_ui.value.phase != Phase.OUTGOING) return
        stopRingback()
        try {
            val t = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 70)
            t.startTone(ToneGenerator.TONE_SUP_RINGTONE)
            tone = t
        } catch (e: Throwable) {}
    }

    private fun stopRingback() {
        try { tone?.stopTone() } catch (e: Throwable) {}
        try { tone?.release() } catch (e: Throwable) {}
        tone = null
    }

    private fun startService() {
        try {
            ContextCompat.startForegroundService(app, Intent(app, CallService::class.java))
        } catch (e: Throwable) {}
    }

    private fun stopService() {
        try { app.stopService(Intent(app, CallService::class.java)) } catch (e: Throwable) {}
    }

    fun cancelCallNotif(chatId: String) {
        try {
            androidx.core.app.NotificationManagerCompat.from(app).cancel((CALL_NOTIF_TAG + chatId).hashCode())
        } catch (e: Throwable) {}
    }
}

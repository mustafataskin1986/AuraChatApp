package com.aurachat.app.ui

import android.content.Intent
import androidx.compose.foundation.layout.offset
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile

/** Rehberdeki numarayı "+90 5xx ..." biçiminde gösterir (ülke kodu yoksa Türkiye varsayılır) */
private fun shownPhone(raw: String): String {
    val d = raw.filter { it.isDigit() }
    return when {
        raw.trim().startsWith("+") -> prettyPhoneNo(raw)
        d.length == 11 && d.startsWith("0") -> prettyPhoneNo("90" + d.substring(1))
        d.length == 10 && d.startsWith("5") -> prettyPhoneNo("90$d")
        d.length < 8 -> "+90 $d"
        else -> "+$d"
    }
}

@Composable
fun InviteScreen(me: UserProfile, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val dn = LocalDensity.current
    BackHandler { onBack() }
    val allUsers by remember(me.uid) { Repo.usersFlow(me.uid) }.collectAsState(Repo.cachedUsers())
    val dev by rememberDeviceContacts()
    val askPerm = rememberAskContacts()
    val aura = remember(allUsers) { allUsers?.map { phoneKey(it.phone) }?.toSet() ?: emptySet() }
    var qrKey by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(me.uid) { qrKey = Repo.qrKeyOf(me.uid) }
    var searching by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(searching) { if (searching) try { focus.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Invite", e) } }
    val list = (dev ?: emptyList()).filter { phoneKey(it.phone) !in aura && (q.isBlank() || it.name.contains(q, true) || it.phone.contains(q)) }
    val shareText = "AuraChat'ta sohbet edelim!\nhttps://aurachat-amber.vercel.app/api/u?u=" + me.uid + (if (!qrKey.isNullOrEmpty()) "&k=$qrKey" else "")

    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (searching) { searching = false; q = "" } else onBack() }, modifier = Modifier.offset(x = (-5.6).dp)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            if (searching) {
                Row(Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(50)).background(ChipLook.glass).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    BasicTextField(
                        value = q, onValueChange = { q = it }, singleLine = true,
                        textStyle = TextStyle(color = ChipLook.inputFg, fontSize = with(dn) { 48f.toSp() }), cursorBrush = SolidColor(ChipLook.inputFg),
                        modifier = Modifier.weight(1f).focusRequester(focus)
                    )
                }
                Spacer(Modifier.width(6.dp))
            } else {
                Text("Arkadaşlarınızı davet edin", color = AuraWhite, fontSize = with(dn) { 60f.toSp() }, maxLines = 1, modifier = Modifier.weight(1f).padding(start = 6.dp))
                IconButton(onClick = { searching = true }) { Icon(Icons.Default.Search, "Ara", tint = AuraWhite) }
            }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            item(key = "share") {
                Row(
                    Modifier.fillMaxWidth().clickable {
                        try { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, shareText), null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        catch (e: Throwable) { com.aurachat.app.AuraLog.e("Invite", e) }
                    }.padding(horizontal = with(dn) { 44f.toDp() }, vertical = with(dn) { 20f.toDp() }),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(with(dn) { 110f.toDp() }).clip(CircleShape).background(AuraGreen), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Share, null, tint = Color.White, modifier = Modifier.size(with(dn) { 56f.toDp() }))
                    }
                    Spacer(Modifier.width(with(dn) { 44f.toDp() }))
                    Text("Bağlantıyı paylaş", color = AuraWhite, fontSize = with(dn) { 48f.toSp() })
                }
            }
            item(key = "hdr") {
                Text("Kişilerden", color = AuraMuted, fontSize = with(dn) { 42f.toSp() }, modifier = Modifier.padding(start = with(dn) { 44f.toDp() }, top = with(dn) { 36f.toDp() }, bottom = with(dn) { 12f.toDp() }))
            }
            if (dev == null) item(key = "noperm") {
                Column(Modifier.fillParentMaxHeight(0.6f).fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
                    Text("Kişileri görmek için rehber erişimine izin ver", color = AuraMuted, fontSize = 15.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    Text("İzin ver", color = AuraGreen, fontSize = 16.sp, modifier = Modifier.padding(top = 12.dp).clip(RoundedCornerShape(50)).clickable { askPerm() }.padding(horizontal = 20.dp, vertical = 8.dp))
                }
            }
            items(list, key = { phoneKey(it.phone) }) { c ->
                Row(Modifier.fillMaxWidth().padding(horizontal = with(dn) { 44f.toDp() }, vertical = with(dn) { 16f.toDp() }), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(with(dn) { 108f.toDp() }).clip(CircleShape).background(Color.White.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Person, null, tint = ChipLook.inputFg, modifier = Modifier.size(with(dn) { 56f.toDp() }))
                    }
                    Spacer(Modifier.width(with(dn) { 46f.toDp() }))
                    Column(Modifier.weight(1f)) {
                        Text(c.name, color = AuraWhite, fontSize = with(dn) { 52f.toSp() }, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        Text(shownPhone(c.phone), color = AuraMuted, fontSize = with(dn) { 44f.toSp() }, maxLines = 1)
                    }
                    Text("Davet et", color = AuraGreen, fontSize = with(dn) { 48f.toSp() }, modifier = Modifier.clip(RoundedCornerShape(50)).clickable { inviteTo(ctx, c.phone) }.padding(horizontal = 10.dp, vertical = 8.dp))
                }
            }
        }
    }
}

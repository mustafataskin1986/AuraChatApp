package com.aurachat.app.ui

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.LocalDb
import com.aurachat.app.data.LocalMedia
import com.aurachat.app.data.UserProfile
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.appdata"
private const val BACKUP_NAME = "aurachat-yedek.json"
private const val MEDIA_PREFIX = "aurachat-m-"
private const val THEME_PREFIX = "aurachat-t-"
private val BkGreen = Color(0xFF22C55E)

/** Google Drive (appDataFolder) yedeği: mesajlar (yerel veritabanı), yıldızlılar, tema ayarları ve medya dosyaları */
object Backup {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    var running by mutableStateOf(false)
        private set
    var pct by mutableStateOf(0f)
        private set
    var text by mutableStateOf("")
        private set
    var finished by mutableStateOf(false)
        private set
    var isError by mutableStateOf(false)
        private set

    fun dismiss() { if (!running) { finished = false; isError = false; text = "" } }

    fun lastInfo(ctx: Context): String {
        val ms = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE).getLong("backup_last", 0L)
        if (ms <= 0L) return "Henüz yedek alınmadı"
        return "Son yedek: " + SimpleDateFormat("d MMM yyyy HH:mm", Locale("tr")).format(Date(ms))
    }

    private fun step(p: Float, t: String) { pct = p; text = t }

    fun start(ctx: Context, me: UserProfile, token: String, restore: Boolean) {
        if (running) return
        val app = ctx.applicationContext
        running = true; finished = false; isError = false; pct = 0.02f
        text = if (restore) "Yedek indiriliyor…" else "Yedek hazırlanıyor…"
        scope.launch {
            try {
                val msg = if (restore) doRestore(app, me, token) else doBackup(app, me, token)
                pct = 1f; text = msg; isError = false
            } catch (e: Throwable) {
                isError = true; text = e.message ?: "İşlem başarısız"
            }
            finished = true
            running = false
        }
    }

    // ---------- Drive REST ----------
    private fun call(token: String, method: String, url: String, ctype: String? = null, body: ByteArray? = null): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.setRequestProperty("Authorization", "Bearer $token")
        if (method == "PATCH") {
            c.requestMethod = "POST"
            c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
        } else c.requestMethod = method
        if (body != null) {
            c.doOutput = true
            if (ctype != null) c.setRequestProperty("Content-Type", ctype)
            c.setFixedLengthStreamingMode(body.size)
            c.outputStream.use { it.write(body) }
        }
        val code = c.responseCode
        if (code !in 200..299) {
            val err = try { c.errorStream?.readBytes()?.toString(Charsets.UTF_8) ?: "" } catch (e: Throwable) { "" }
            val m = try { JSONObject(err).getJSONObject("error").optString("message") } catch (e: Throwable) { "" }
            throw RuntimeException("Drive hatası ($code)" + if (m.isNotBlank()) ": $m" else "")
        }
        return c.inputStream.use { it.readBytes() }
    }

    private fun q(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun listFiles(token: String, prefix: String): Map<String, String> {
        val out = HashMap<String, String>()
        var page = ""
        do {
            val url = "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=" + q("name contains '$prefix'") +
                "&fields=nextPageToken,files(id,name)&pageSize=1000" + (if (page.isNotEmpty()) "&pageToken=$page" else "")
            val j = JSONObject(String(call(token, "GET", url), Charsets.UTF_8))
            val arr = j.optJSONArray("files")
            if (arr != null) for (i in 0 until arr.length()) {
                val f = arr.getJSONObject(i)
                val n = f.optString("name")
                if (n.startsWith(prefix)) out[n] = f.optString("id")
            }
            page = j.optString("nextPageToken", "")
        } while (page.isNotEmpty())
        return out
    }

    private fun upload(token: String, existingId: String?, name: String, mime: String, data: ByteArray) {
        val b = "aura" + System.currentTimeMillis()
        val meta = if (existingId != null) JSONObject().put("name", name)
        else JSONObject().put("name", name).put("parents", JSONArray().put("appDataFolder"))
        val bo = ByteArrayOutputStream()
        bo.write(("--$b\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n--$b\r\nContent-Type: $mime\r\n\r\n").toByteArray())
        bo.write(data)
        bo.write("\r\n--$b--".toByteArray())
        val url = if (existingId != null) "https://www.googleapis.com/upload/drive/v3/files/$existingId?uploadType=multipart"
        else "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart"
        call(token, if (existingId != null) "PATCH" else "POST", url, "multipart/related; boundary=$b", bo.toByteArray())
    }

    private fun download(token: String, id: String): ByteArray =
        call(token, "GET", "https://www.googleapis.com/drive/v3/files/$id?alt=media")

    // ---------- Firestore değer dönüşümü ----------
    private fun strip(v: Any?): Any? = when (v) {
        null -> JSONObject.NULL
        is Timestamp -> JSONObject().put("__ts", v.toDate().time)
        is Map<*, *> -> JSONObject().also { o -> v.forEach { (k, x) -> o.put(k.toString(), strip(x)) } }
        is List<*> -> JSONArray().also { a -> v.forEach { a.put(strip(it)) } }
        else -> v
    }

    private fun revive(v: Any?): Any? = when (v) {
        JSONObject.NULL -> null
        is JSONObject -> if (v.length() == 1 && v.has("__ts")) Timestamp(Date(v.getLong("__ts")))
        else v.keys().asSequence().associateWith { k -> revive(v.get(k)) }
        is JSONArray -> (0 until v.length()).map { revive(v.get(it)) }
        else -> v
    }

    // ---------- Yerel dosyalar ----------
    private fun mediaFiles(): List<Pair<String, File>> {
        val root = LocalMedia.rootDir() ?: return emptyList()
        val out = ArrayList<Pair<String, File>>()
        fun walk(d: File) {
            d.listFiles()?.forEach { f ->
                if (f.isDirectory) walk(f)
                else if (f.length() > 0L && f.name != ".nomedia") {
                    val rel = f.relativeTo(root).path.replace(File.separatorChar, '~')
                    out.add((MEDIA_PREFIX + rel) to f)
                }
            }
        }
        walk(root)
        return out
    }

    private fun themeFiles(ctx: Context): List<Pair<String, File>> =
        ctx.filesDir.listFiles()?.filter { it.isFile && it.name.startsWith("theme_") && it.name.endsWith(".jpg") && it.length() > 0L }
            ?.map { (THEME_PREFIX + it.name) to it } ?: emptyList()

    private fun mimeOf(n: String) = when {
        n.endsWith(".jpg", true) || n.endsWith(".jpeg", true) -> "image/jpeg"
        n.endsWith(".png", true) -> "image/png"
        else -> "application/octet-stream"
    }

    // ---------- Yedekle ----------
    private suspend fun doBackup(ctx: Context, me: UserProfile, token: String): String {
        step(0.05f, "Mesajlar okunuyor…")
        val rows = LocalDb.dumpAll()
        val ra = JSONArray()
        rows.forEach { ra.put(JSONArray().put(it[0]).put(it[1]).put(it[2].toLongOrNull() ?: 0L).put(it[3])) }

        step(0.12f, "Yıldızlı mesajlar okunuyor…")
        val starred = JSONArray()
        try {
            val snap = FirebaseFirestore.getInstance().collection("users").document(me.uid).collection("starred").get().await()
            snap.documents.forEach { d ->
                starred.put(JSONObject().put("id", d.id).put("data", strip(d.data ?: emptyMap<String, Any>())))
            }
        } catch (e: Throwable) {}

        val settings = JSONObject()
        val sp = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)
        sp.all.forEach { (k, v) -> if (k.startsWith("theme_") && v is String) settings.put(k, v) }

        val root = JSONObject().put("app", "AuraChat").put("v", 2).put("uid", me.uid)
            .put("createdAt", System.currentTimeMillis()).put("rows", ra).put("starred", starred).put("settings", settings)
        val bytes = root.toString().toByteArray(Charsets.UTF_8)

        step(0.2f, "Drive'a yükleniyor…")
        val existing = listFiles(token, BACKUP_NAME)[BACKUP_NAME]
        upload(token, existing, BACKUP_NAME, "application/json", bytes)

        val local = mediaFiles() + themeFiles(ctx)
        step(0.3f, "Medya kontrol ediliyor…")
        val onDrive = HashSet<String>().apply { addAll(listFiles(token, MEDIA_PREFIX).keys); addAll(listFiles(token, THEME_PREFIX).keys) }
        val todo = local.filter { !onDrive.contains(it.first) }
        var ok = 0; var fail = 0
        todo.forEachIndexed { i, (name, f) ->
            step(0.3f + 0.69f * (i / todo.size.toFloat()), "Medya yükleniyor… ${i + 1}/${todo.size}")
            try { upload(token, null, name, mimeOf(name), f.readBytes()); ok++ } catch (e: Throwable) { fail++ }
        }
        sp.edit().putLong("backup_last", System.currentTimeMillis()).apply()
        val sb = StringBuilder("Yedeklendi: ${rows.size} mesaj, ${starred.length()} yıldızlı, ${local.size} medya")
        if (fail > 0) sb.append(" ($fail dosya yüklenemedi, tekrar dene)")
        return sb.toString()
    }

    // ---------- Geri yükle ----------
    private suspend fun doRestore(ctx: Context, me: UserProfile, token: String): String {
        val id = listFiles(token, BACKUP_NAME)[BACKUP_NAME] ?: throw RuntimeException("Drive'da yedek bulunamadı")
        step(0.06f, "Yedek indiriliyor…")
        val root = JSONObject(String(download(token, id), Charsets.UTF_8))
        if (root.optString("app") != "AuraChat" || root.optString("uid") != me.uid) throw RuntimeException("Bu yedek bu hesaba ait değil")

        step(0.2f, "Mesajlar yazılıyor…")
        val ra = root.optJSONArray("rows") ?: JSONArray()
        val rows = ArrayList<Array<String>>()
        for (i in 0 until ra.length()) {
            val r = ra.getJSONArray(i)
            rows.add(arrayOf(r.getString(0), r.getString(1), r.getLong(2).toString(), r.getString(3)))
        }
        val added = LocalDb.restoreRows(rows)

        step(0.3f, "Yıldızlı mesajlar yazılıyor…")
        val st = root.optJSONArray("starred") ?: JSONArray()
        val coll = FirebaseFirestore.getInstance().collection("users").document(me.uid).collection("starred")
        for (i in 0 until st.length()) {
            val o = st.getJSONObject(i)
            try {
                @Suppress("UNCHECKED_CAST")
                val data = revive(o.getJSONObject("data")) as Map<String, Any?>
                coll.document(o.getString("id")).set(data, SetOptions.merge()).await()
            } catch (e: Throwable) {}
        }

        val sp = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)
        val set = root.optJSONObject("settings")
        if (set != null) {
            val ed = sp.edit()
            set.keys().forEach { k -> if (k.startsWith("theme_") && !sp.contains(k)) ed.putString(k, set.optString(k)) }
            ed.apply()
        }

        step(0.4f, "Medya kontrol ediliyor…")
        val mroot = LocalMedia.rootDir()
        val media = listFiles(token, MEDIA_PREFIX)
        val themes = listFiles(token, THEME_PREFIX)
        val todo = ArrayList<Triple<String, String, File>>()
        media.forEach { (name, fid) ->
            if (mroot == null) return@forEach
            val rel = name.removePrefix(MEDIA_PREFIX).replace('~', File.separatorChar)
            val f = File(mroot, rel)
            val inside = try { f.canonicalPath.startsWith(mroot.canonicalPath + File.separator) } catch (e: Throwable) { false }
            if (inside && !(f.exists() && f.length() > 0L)) todo.add(Triple(name, fid, f))
        }
        themes.forEach { (name, fid) ->
            val f = File(ctx.filesDir, name.removePrefix(THEME_PREFIX))
            if (!f.name.contains('/') && !(f.exists() && f.length() > 0L)) todo.add(Triple(name, fid, f))
        }
        var ok = 0; var fail = 0
        todo.forEachIndexed { i, t ->
            step(0.4f + 0.58f * (i / todo.size.toFloat()), "Medya indiriliyor… ${i + 1}/${todo.size}")
            try {
                t.third.parentFile?.mkdirs()
                t.third.writeBytes(download(token, t.second))
                ok++
            } catch (e: Throwable) { fail++ }
        }
        LocalMedia.scan()
        val sb = StringBuilder("Geri yüklendi: $added mesaj, $ok medya")
        if (fail > 0) sb.append(" ($fail dosya indirilemedi, tekrar dene)")
        sb.append(". Ayarların tam yenilenmesi için uygulamayı kapatıp aç.")
        return sb.toString()
    }
}

@Composable
fun BackupScreen(me: UserProfile, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendingToken by remember { mutableStateOf<CompletableDeferred<String?>?>(null) }
    var info by remember { mutableStateOf(Backup.lastInfo(ctx)) }
    var askRestore by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        val d = pendingToken
        pendingToken = null
        try {
            val res = Identity.getAuthorizationClient(ctx).getAuthorizationResultFromIntent(r.data)
            d?.complete(res.accessToken)
        } catch (e: Throwable) { d?.complete(null) }
    }

    fun run(restore: Boolean) {
        if (Backup.running) return
        scope.launch {
            try {
                val req = AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(DRIVE_SCOPE))).build()
                val res = Identity.getAuthorizationClient(ctx).authorize(req).await()
                val token: String? = if (res.hasResolution()) {
                    val d = CompletableDeferred<String?>()
                    pendingToken = d
                    launcher.launch(IntentSenderRequest.Builder(res.pendingIntent!!.intentSender).build())
                    d.await()
                } else res.accessToken
                if (token.isNullOrBlank()) {
                    android.widget.Toast.makeText(ctx, "Google izni alınamadı", android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    Backup.start(ctx, me, token, restore)
                }
            } catch (e: Throwable) {
                android.widget.Toast.makeText(ctx, "Google izni alınamadı: " + (e.message ?: ""), android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    BackHandler(enabled = Backup.running) { }
    BackHandler(enabled = !Backup.running) { Backup.dismiss(); onBack() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { if (!Backup.running) { Backup.dismiss(); onBack() } }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraMuted)
                }
                Text("Sohbet yedeği", color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(start = 12.dp))
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF1F2937)))
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 20.dp)) {
                Text(
                    "Mesajların, yıldızlıların, sohbet temaların ve telefondaki medya dosyaların Google Drive'daki gizli uygulama klasörüne yedeklenir. Telefonu değiştirirsen aynı hesapla giriş yapıp geri yükleyebilirsin.",
                    color = AuraMuted, fontSize = 15.sp, lineHeight = 22.sp
                )
                Text(info, color = Color(0xFFD1D5DB), fontSize = 14.sp, modifier = Modifier.padding(top = 16.dp, bottom = 20.dp))
                BkButton("Şimdi yedekle", !Backup.running) { run(false) }
                Box(Modifier.height(12.dp))
                BkButton("Yedekten geri yükle", !Backup.running) { askRestore = true }

                if (Backup.running || Backup.finished) {
                    Column(
                        Modifier.padding(top = 24.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF111B21)).padding(18.dp)
                    ) {
                        Text(
                            if (Backup.running) "Çalışıyor…" else if (Backup.isError) "İşlem tamamlanamadı" else "Tamamlandı",
                            color = Color.White, fontSize = 16.sp
                        )
                        Box(Modifier.padding(top = 12.dp).fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x1FFFFFFF))) {
                            Box(
                                Modifier.fillMaxWidth(Backup.pct.coerceIn(0.03f, 1f)).height(6.dp).clip(RoundedCornerShape(3.dp))
                                    .background(if (Backup.isError) Color(0xFFEF4444) else BkGreen)
                            )
                        }
                        Text(
                            Backup.text, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 12.dp),
                            color = if (Backup.isError) Color(0xFFFCA5A5) else Color(0xFFE9EDEF)
                        )
                        if (Backup.running) {
                            Text("Bitene kadar bu ekrandan çıkılamaz.", color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                        } else {
                            Box(Modifier.padding(top = 14.dp).fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                                BkButton("Tamam", true, small = true) { Backup.dismiss(); info = Backup.lastInfo(ctx) }
                            }
                        }
                    }
                }
            }
        }
    }

    if (askRestore) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { askRestore = false },
            containerColor = Color(0xFF111111),
            title = { Text("Yedekten geri yüklensin mi?", color = Color.White, fontSize = 18.sp) },
            text = { Text("Telefonda olmayan mesajlar ve medya eklenir. Telefondaki mevcut veriler silinmez.", color = AuraMuted, fontSize = 14.sp) },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = { askRestore = false; run(true) }) {
                    Text("Geri yükle", color = BkGreen, fontSize = 16.sp)
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { askRestore = false }) { Text("Vazgeç", color = BkGreen, fontSize = 16.sp) }
            }
        )
    }
}

@Composable
private fun BkButton(label: String, enabled: Boolean, small: Boolean = false, onClick: () -> Unit) {
    val c = if (enabled) BkGreen else Color(0xFF4B5563)
    Box(
        Modifier.then(if (small) Modifier else Modifier.fillMaxWidth())
            .clip(RoundedCornerShape(50)).border(1.dp, c, RoundedCornerShape(50))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 26.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = c, fontSize = 16.sp) }
}

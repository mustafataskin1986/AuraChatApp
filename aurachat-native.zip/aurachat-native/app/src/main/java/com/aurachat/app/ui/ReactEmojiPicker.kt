package com.aurachat.app.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/** Tepki çubuğundaki 6 emoji: seçilen yeni emoji öne eklenir, kalıcıdır */
object ReactPrefs {
    val DEFAULT = listOf("👍", "❤️", "😂", "😮", "😢", "🙏")
    var list by mutableStateOf(DEFAULT)
        private set
    private var loaded = false

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val s = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE).getString("react_bar", null)
            val l = s?.split("|")?.filter { it.isNotBlank() }
            if (!l.isNullOrEmpty()) list = l.take(6)
        } catch (_: Throwable) {}
    }

    fun push(ctx: Context, e: String) {
        val n = (listOf(e) + list.filter { it != e }).take(6)
        list = n
        try { ctx.getSharedPreferences("aura", Context.MODE_PRIVATE).edit().putString("react_bar", n.joinToString("|")).apply() } catch (_: Throwable) {}
    }
}

private val EmojiCats: List<Pair<String, String>> = listOf(
    "Yüzler" to "😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 😉 😊 😇 🥰 😍 🤩 😘 😗 😚 😙 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 🤨 😐 😑 😶 😏 😒 🙄 😬 😮‍💨 🤥 😌 😔 😪 🤤 😴 😷 🤒 🤕 🤢 🤮 🤧 🥵 🥶 🥴 😵 🤯 🤠 🥳 😎 🤓 🧐 😕 😟 🙁 ☹️ 😮 😯 😲 😳 🥺 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 😈 👿 💀 ☠️ 💩 🤡 👻 👽 🤖",
    "El" to "👋 🤚 🖐️ ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 💪 🦾 🧠 👀 👁️ 👅 👄",
    "Kalp" to "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ♥️ 💋 💯 💢 💥 💫 💦 💨 🕊️ ✨ ⭐ 🌟 🔥 🎉 🎊 🎈 🎁 🏆 🥇",
    "Hayvan" to "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🐺 🐗 🐴 🦄 🐝 🦋 🐌 🐞 🐢 🐍 🐙 🐬 🐳 🦈 🐘 🦒 🐪 🌸 🌹 🌻 🌲 🍀",
    "Yiyecek" to "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥑 🌽 🥕 🍔 🍟 🍕 🌭 🥪 🌮 🌯 🍗 🍖 🍞 🧀 🍳 🥞 🍩 🍪 🎂 🍰 🍫 🍬 🍭 🍿 ☕ 🍵 🍺 🍷 🥂 🍹",
    "Nesne" to "⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 🥊 🎮 🎯 🎲 🎵 🎶 🎤 🎧 🎸 📱 💻 📷 📚 ✏️ 💡 💰 💎 🔑 🔒 🚗 ✈️ 🚀 ⏰ 🌍 🌈 ☀️ 🌙 ⚡ ❄️ ☔ ✅ ❌ ⭕ ❓ ❗ 💬 💭 👑 🇹🇷"
).map { (n, s) -> n to s }

/** Tepki çubuğundaki "+": tüm emojiler; seçilen emoji tepki olur ve çubuğa eklenir */
@Composable
fun ReactEmojiPicker(onPick: (String) -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().clickable(indication = null, interactionSource = remember2()) { onDismiss() }) {
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(0.55f)
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).background(AuraSurface)
                    .clickable(indication = null, interactionSource = remember2()) { }
            ) {
                LazyVerticalGrid(
                    GridCells.Fixed(8), Modifier.fillMaxSize().navigationBarsPadding(),
                    contentPadding = PaddingValues(start = 8.dp, end = 8.dp, top = 14.dp, bottom = 16.dp)
                ) {
                    EmojiCats.forEach { (name, list) ->
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Text(name, color = AuraMuted, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 6.dp, top = 8.dp, bottom = 4.dp))
                        }
                        val emo = list.split(" ").filter { it.isNotBlank() }
                        items(emo.size) { i ->
                            val e = emo[i]
                            Box(Modifier.height(46.dp).clip(RoundedCornerShape(10.dp)).clickable { onPick(e) }, contentAlignment = Alignment.Center) {
                                Text(e, fontSize = 27.sp, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun remember2() = androidx.compose.runtime.remember { androidx.compose.foundation.interaction.MutableInteractionSource() }

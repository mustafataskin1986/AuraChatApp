package com.aurachat.app.ui

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateMapOf

/** Sohbet taslakları: yazılıp gönderilmeden bırakılan metin (kalıcı) ve bekleyen resimler (bellekte). Sohbet listesinde "Taslak:" olarak görünür */
object Drafts {
    val text = mutableStateMapOf<String, String>()
    val images = mutableStateMapOf<String, List<String>>()
    private var sp: SharedPreferences? = null

    fun init(ctx: Context) {
        if (sp != null) return
        val p = ctx.getSharedPreferences("drafts", Context.MODE_PRIVATE)
        sp = p
        p.all.forEach { (k, v) -> if (v is String && v.isNotBlank()) text[k] = v }
    }

    fun set(chatId: String, t: String, imgs: List<String>) {
        if (t.isBlank()) { text.remove(chatId); sp?.edit()?.remove(chatId)?.apply() }
        else if (text[chatId] != t) { text[chatId] = t; sp?.edit()?.putString(chatId, t)?.apply() }
        if (imgs.isEmpty()) images.remove(chatId) else images[chatId] = imgs
    }

    /** Listede gösterilecek taslak metni (yoksa boş) */
    fun preview(chatId: String): String {
        val t = text[chatId].orEmpty().trim()
        if (t.isNotEmpty()) return t.replace('\n', ' ')
        return if (images[chatId].orEmpty().isNotEmpty()) "📷 Fotoğraf" else ""
    }
}

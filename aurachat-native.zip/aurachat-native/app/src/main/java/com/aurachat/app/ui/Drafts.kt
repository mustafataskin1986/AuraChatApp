package com.aurachat.app.ui

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateMapOf

/** Sohbet taslakları: yazılıp gönderilmeden bırakılan metin (kalıcı) ve bekleyen resimler (bellekte). Sohbet listesinde "Taslak:" olarak görünür */
object Drafts {
    val text = mutableStateMapOf<String, String>()
    val images = mutableStateMapOf<String, List<String>>()
    private var sp: SharedPreferences? = null
    /** Sesli mesaj taslağı: chatId → süre (sn). Dosya filesDir/voice_drafts, dalga formu "voice_drafts" tercihlerinde */
    val voice = mutableStateMapOf<String, Int>()
    private var vp: SharedPreferences? = null

    fun voiceFile(ctx: Context, chatId: String): java.io.File {
        val d = java.io.File(ctx.filesDir, "voice_drafts"); d.mkdirs()
        return java.io.File(d, chatId.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".m4a")
    }

    fun setVoice(ctx: Context, chatId: String, sec: Int, wave: List<Int>) {
        val p = vp ?: ctx.getSharedPreferences("voice_drafts", Context.MODE_PRIVATE).also { vp = it }
        p.edit().putString(chatId, sec.toString() + "|" + wave.joinToString(",")).apply()
        voice[chatId] = sec
    }

    fun voiceWave(chatId: String): List<Int> =
        (vp?.getString(chatId, null) ?: "").substringAfter('|', "").split(',').mapNotNull { it.toIntOrNull() }

    fun clearVoice(ctx: Context, chatId: String) {
        if (!voice.containsKey(chatId)) return
        voice.remove(chatId)
        (vp ?: ctx.getSharedPreferences("voice_drafts", Context.MODE_PRIVATE)).edit().remove(chatId).apply()
        try { voiceFile(ctx, chatId).delete() } catch (ignored: Throwable) { }
    }

    fun init(ctx: Context) {
        if (sp != null) return
        val p = ctx.getSharedPreferences("drafts", Context.MODE_PRIVATE)
        sp = p
        p.all.forEach { (k, v) -> if (v is String && v.isNotBlank()) text[k] = v }
        val v2 = ctx.getSharedPreferences("voice_drafts", Context.MODE_PRIVATE)
        vp = v2
        v2.all.forEach { (k, v) -> val sec = (v as? String)?.substringBefore('|')?.toIntOrNull(); if (sec != null && voiceFile(ctx, k).exists()) voice[k] = sec }
    }

    fun set(chatId: String, t: String, imgs: List<String>) {
        if (t.isBlank()) { text.remove(chatId); sp?.edit()?.remove(chatId)?.apply() }
        else if (text[chatId] != t) { text[chatId] = t; sp?.edit()?.putString(chatId, t)?.apply() }
        if (imgs.isEmpty()) images.remove(chatId) else images[chatId] = imgs
    }

    /** Listede gösterilecek taslak metni (yoksa boş) */
    fun preview(chatId: String): String {
        val t = text[chatId].orEmpty().trim()
        if (t.isNotEmpty()) return t.replace('\n', ' ')
        if (images[chatId].orEmpty().isNotEmpty()) return "📷 Fotoğraf"
        val v = voice[chatId]
        return if (v != null) "Sesli mesaj (%d:%02d)".format(v / 60, v % 60) else ""
    }
}

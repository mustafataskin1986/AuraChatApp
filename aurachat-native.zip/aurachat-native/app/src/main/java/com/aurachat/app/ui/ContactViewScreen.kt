package com.aurachat.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile

/** Sohbetteki kişi kartına dokununca açılan "Kişiyi görüntüle" sayfası: sol simge sohbeti, sağdakiler sesli/görüntülü aramayı açar */
@Composable
fun ContactViewScreen(me: UserProfile, uid: String, name: String, phone: String, onBack: () -> Unit, onMessage: () -> Unit, onCall: (Boolean) -> Unit) {
    BackHandler { onBack() }
    val lp by liveProfile(uid)
    val shownName = lp?.name?.takeIf { it.isNotBlank() } ?: name
    val shownPhone = phone.ifBlank { lp?.phone ?: "" }
    val mine by remember(me.uid) { Repo.blockedFlow(me.uid) }.collectAsState(Repo.peekBlocked(me.uid))
    val theirs by remember(uid) { if (uid.isBlank() || uid == me.uid) kotlinx.coroutines.flow.flowOf(emptyList<String>()) else Repo.blockedFlow(uid) }
        .collectAsState(if (uid.isBlank()) emptyList() else Repo.peekBlocked(uid))
    val iBlocked = uid.isNotBlank() && mine.contains(uid)
    val theyBlocked = uid.isNotBlank() && theirs.contains(me.uid)
    val noUser = uid.isBlank()
    val callsOff = noUser || iBlocked || theyBlocked
    fun offMsg() = when {
        noUser -> "Bu kişi AuraChat kullanmıyor."
        theyBlocked -> "Bu kişi sizi engellediği için onunla iletişim kuramazsınız."
        else -> "Bu kişiyi engellediniz. Arama yapmak için önce engeli kaldırın."
    }
    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text("Kişiyi görüntüle", color = AuraWhite, fontSize = 21.sp, letterSpacing = 0.sp, modifier = Modifier.padding(start = 8.dp))
        }
        HorizontalDivider(color = AuraMuted.copy(alpha = 0.18f))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(shownName, lp?.avatar, 64.dp)
            Text(shownName, color = AuraWhite, fontSize = 22.sp, letterSpacing = 0.sp, modifier = Modifier.padding(start = 16.dp))
        }
        HorizontalDivider(color = AuraMuted.copy(alpha = 0.18f))
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (noUser) com.aurachat.app.ui.CenterToast.show(offMsg()) else onMessage() }) {
                Icon(Icons.Default.Chat, "Mesaj", tint = AuraGreen, modifier = Modifier.size(26.dp))
            }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(shownPhone.ifBlank { "Telefon yok" }, color = AuraWhite, fontSize = 18.sp, letterSpacing = 0.sp)
                Text("Mobil", color = AuraMuted, fontSize = 15.sp, letterSpacing = 0.sp)
            }
            IconButton(onClick = { if (callsOff) com.aurachat.app.ui.CenterToast.show(offMsg()) else onCall(false) }, modifier = Modifier.alpha(if (callsOff) 0.35f else 1f)) {
                Icon(Icons.Default.Call, "Sesli ara", tint = AuraGreen, modifier = Modifier.size(26.dp))
            }
            IconButton(onClick = { if (callsOff) com.aurachat.app.ui.CenterToast.show(offMsg()) else onCall(true) }, modifier = Modifier.alpha(if (callsOff) 0.35f else 1f)) {
                Icon(Icons.Default.Videocam, "Görüntülü ara", tint = AuraGreen, modifier = Modifier.size(28.dp))
            }
        }
        HorizontalDivider(color = AuraMuted.copy(alpha = 0.18f))
    }
}

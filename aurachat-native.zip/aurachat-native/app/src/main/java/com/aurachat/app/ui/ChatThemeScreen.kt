package com.aurachat.app.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Colorize
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val WaGreen = Color(0xFF00A884)

/** Hazır temalar (duvar kağıdı + baloncuk rengi çifti); ana sayfada kategori kategori kartlar olarak gösterilir */
private class Preset(val cat: String, val bg: String, val out: String)
private val Presets = listOf(
    Preset("Öne çıkanlar", "amoled", "1f7a4d"), Preset("Öne çıkanlar", "c_gece", "086b66"), Preset("Öne çıkanlar", "c_mavi", "08529e"),
    Preset("Öne çıkanlar", "c_holo", "803399"), Preset("Öne çıkanlar", "c_aurora", "0a7f6f"), Preset("Öne çıkanlar", "g_gece", "4e38b3"),
    Preset("Doğa", "g_col", "9b153b"), Preset("Doğa", "g_orman", "126d47"), Preset("Doğa", "g_deniz", "0e5d8d"),
    Preset("Doğa", "g_gokyuzu", "803399"), Preset("Doğa", "g_dag", "08529e"), Preset("Doğa", "g_kum", "794b2a"), Preset("Doğa", "g_kar", "0e5d8d"),
    Preset("Canlı", "c_holo", "d82d63"), Preset("Canlı", "c_mavi", "1d5fa8"), Preset("Canlı", "c_aurora", "126d47"),
    Preset("Canlı", "c_seker", "803399"), Preset("Canlı", "c_alev", "a72917"), Preset("Canlı", "c_gece", "4e38b3"),
    Preset("Minimal", "mavi", "1d5fa8"), Preset("Minimal", "orman", "1f7a4d"), Preset("Minimal", "okyanus", "118a9a"),
    Preset("Minimal", "gunbatimi", "b5483a"), Preset("Minimal", "mor", "6d3fc0"), Preset("Minimal", "pembe", "c2347f"),
    Preset("Minimal", "bordo", "a3283d"), Preset("Minimal", "kahve", "8a5a3a"), Preset("Minimal", "celik", "4b6a8a"),
    Preset("Minimal", "s2a7b72", "126d47"), Preset("Minimal", "s3a6073", "08529e"), Preset("Minimal", "s362a63", "4e38b3"),
    Preset("Minimal", "s525252", "53565a"), Preset("Minimal", "s5c6b39", "5e8a27"), Preset("Minimal", "s807328", "c5a300"),
    Preset("Minimal", "s680c1d", "9b153b"), Preset("Minimal", "s1e3b4a", "0e5d8d"), Preset("Minimal", "s0e1114", "0a7f6f"), Preset("Minimal", "s6e2d1b", "9e3f22"),
    Preset("Çiziktirme", "z4e38b3", "4e38b3"), Preset("Çiziktirme", "zd82d63", "d82d63"), Preset("Çiziktirme", "z53565a", "53565a"), Preset("Çiziktirme", "z126d47", "126d47"), Preset("Çiziktirme", "z9e3f22", "9e3f22"), Preset("Çiziktirme", "z08529e", "08529e"), Preset("Çiziktirme", "z803399", "803399"), Preset("Çiziktirme", "z0e5d8d", "0e5d8d"), Preset("Çiziktirme", "z9b153b", "9b153b"), Preset("Çiziktirme", "z5e8a27", "5e8a27")
)
private val PresetCats = Presets.map { it.cat }.distinct()

private fun cardTheme(bgId: String, out: Color, light: Boolean): ResolvedTheme {
    val t = ChatThemes.all.firstOrNull { it.id == bgId }
    return if (t != null && t.id != "default" && !(t.id == "amoled" && light)) ResolvedTheme(t.id, t.stops, null, out, t.id.startsWith("z"), 1f)
    else ResolvedTheme("default", null, null, out, false, 1f)
}

/** Telefon biçimli tema kartı: duvar kağıdı + (istenirse) gelen ve giden balon örneği; seçiliyken kalın halka ve tik */
@Composable
private fun ThemeCard(rt: ResolvedTheme, out: Color?, selected: Boolean, light: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.width(112.dp).aspectRatio(112f / 184f)
            .then(if (selected) Modifier.border(3.dp, AuraWhite, RoundedCornerShape(20.dp)).padding(4.dp) else Modifier)
            .clip(RoundedCornerShape(if (selected) 16.dp else 18.dp))
            .then(if (selected) Modifier else Modifier.border(1.dp, AuraMuted.copy(alpha = 0.18f), RoundedCornerShape(18.dp)))
            .themeBackground(rt).clickable(onClick = onClick)
    ) {
        if (out != null) {
            Box(Modifier.align(Alignment.TopStart).padding(start = 10.dp, top = 18.dp).size(62.dp, 30.dp)
                .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 10.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(if (light) Color.White else Color(0xFF202C33)))
            Box(Modifier.align(Alignment.TopEnd).padding(end = 10.dp, top = 62.dp).size(56.dp, 30.dp)
                .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 3.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(bubbleOf(out)))
        }
        if (selected) Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp).size(28.dp).clip(CircleShape).background(Color(0xB3000000)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
    }
}

@Composable
private fun SubHeader(title: String, menu: @Composable () -> Unit = {}, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(AuraBlack).statusBarsPadding().height(56.dp).padding(start = 6.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
        Text(title, color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 6.dp).weight(1f))
        menu()
    }
}

@Composable
private fun RoundAction(label: String, content: @Composable () -> Unit, onClick: () -> Unit) {
    Column(Modifier.width(110.dp).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.width(72.dp).height(52.dp).clip(RoundedCornerShape(26.dp)).background(AuraSurface), contentAlignment = Alignment.Center) { content() }
        Text(label, color = AuraWhite, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
    }
}

/**
 * Sohbet teması (WhatsApp akışı): ana sayfada hazır tema kartları → dokununca önizleme (sola/sağa kaydır, ✓ uygula).
 * Üstteki iki düğme: Sohbet balonu (renk ızgarası) ve Duvar kağıdı (galeri, düz renkler, kategoriler).
 */
@Composable
fun ChatThemeScreen(chatId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    val savedBg = remember { ChatThemes.savedId(ctx, chatId) }
    val savedOut = remember { ChatThemes.savedOutId(ctx, chatId) }
    val savedDoodle = remember { ChatThemes.doodleOn(ctx, chatId) }
    val savedBright = remember { ChatThemes.bgBright(ctx, chatId) }
    val savedBrightL = remember { ChatThemes.bgBrightLight(ctx, chatId) }

    var bgSel by remember { mutableStateOf(savedBg) }
    var outSel by remember { mutableStateOf(savedOut) }
    var doodleOn by remember { mutableStateOf(savedDoodle) }
    var bgBright by remember { mutableStateOf(savedBright) }
    var bgBrightL by remember { mutableStateOf(savedBrightL) }
    var customBmp by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(ChatThemes.loadCustom(ctx, chatId)) }
    var mode by remember { mutableStateOf(1) }        // önizleme: 0 baloncuk, 1 duvar kağıdı (auto=true iken hazır temalar)
    var auto by remember { mutableStateOf(false) }
    var autoIdx by remember { mutableStateOf(0) }
    var page by remember { mutableStateOf(0) }        // 0: ana, 1: balon, 2: duvar kağıdı, 3: önizleme, 4: düz renkler
    var previewFrom by remember { mutableStateOf(0) }
    var showBright by remember { mutableStateOf(false) }
    var askDiscard by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    val light = AuraUi.light
    val dirty = bgSel != savedBg || outSel != savedOut || doodleOn != savedDoodle || (!light && kotlin.math.abs(bgBright - savedBright) > 0.005f) || (light && kotlin.math.abs(bgBrightL - savedBrightL) > 0.005f)

    fun apply() {
        ChatThemes.set(ctx, chatId, bgSel)
        ChatThemes.setOut(ctx, chatId, outSel)
        ChatThemes.setDoodle(ctx, chatId, doodleOn)
        ChatThemes.setBgBright(ctx, chatId, bgBright)
        ChatThemes.setBgBrightLight(ctx, chatId, bgBrightL)
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                if (ChatThemes.saveCustom(ctx, chatId, uri)) {
                    customBmp = ChatThemes.loadCustom(ctx, chatId)
                    bgSel = "custom"; auto = false; mode = 1; previewFrom = 2; page = 3
                } else Toast.makeText(ctx, "Resim kaydedilemedi", Toast.LENGTH_SHORT).show()
            }
        }
    }

    BackHandler {
        when (page) {
            3 -> page = previewFrom
            4 -> page = 2
            1, 2 -> page = 0
            else -> if (dirty) askDiscard = true else onBack()
        }
    }

    val bubbleList = ChatThemes.bubbleColors.filter { it.id != "default" }
    val bgList = ChatThemes.all.filter { it.id != "default" }
    val bgIds = bgList.map { it.id } + (if (customBmp != null) listOf("custom") else emptyList())
    val outColor = ChatThemes.bubbleColors.firstOrNull { it.id == outSel } ?: ChatThemes.bubbleColors[1]
    val previewBright = if (light) bgBrightL else bgBright
    fun colorOf(id: String): Color = ChatThemes.bubbleColors.firstOrNull { it.id == id }?.color ?: outColor.color

    fun resolvedFor(bgId: String, out: Color): ResolvedTheme {
        val t = ChatThemes.all.firstOrNull { it.id == bgId }
        return when {
            bgId == "custom" && customBmp != null -> ResolvedTheme("custom", null, customBmp, out, doodleOn, previewBright)
            t != null && t.id != "default" && !(t.id == "amoled" && light) -> ResolvedTheme(t.id, t.stops, null, out, doodleOn, previewBright)
            else -> ResolvedTheme("default", null, null, out, doodleOn, previewBright)
        }
    }
    val itemCount = if (auto) Presets.size else if (mode == 0) bubbleList.size else bgIds.size
    val selIdx = if (auto) autoIdx else if (mode == 0) bubbleList.indexOfFirst { it.id == outSel }.coerceAtLeast(0) else bgIds.indexOf(bgSel).coerceAtLeast(0)

    fun openPreviewPreset(i: Int) { auto = true; autoIdx = i; bgSel = Presets[i].bg; outSel = Presets[i].out; previewFrom = 0; page = 3 }
    fun openPreviewBg(id: String, from: Int) { auto = false; mode = 1; bgSel = id; previewFrom = from; page = 3 }

    if (askDiscard) {
        AuraAlertDialog(
            onDismissRequest = { askDiscard = false },
            containerColor = AuraSurface,
            title = { Text("Değişiklikler uygulansın mı?", color = AuraWhite, fontSize = 18.sp) },
            text = { Text("Yaptığın değişiklikler henüz kaydedilmedi.", color = AuraMuted, fontSize = 14.sp) },
            confirmButton = { TextButton(onClick = { apply(); askDiscard = false; onBack() }) { Text("Uygula", color = WaGreen, fontWeight = FontWeight.Medium) } },
            dismissButton = { TextButton(onClick = { askDiscard = false; onBack() }) { Text("Vazgeç", color = AuraMuted) } }
        )
    }

    fun shows(p: Int) = when (p) {
        2 -> page == 2 || page == 4 || (page == 3 && (previewFrom == 2 || previewFrom == 4))
        4 -> page == 4 || (page == 3 && previewFrom == 4)
        else -> page == p
    }
    val slideIn = slideInVertically(tween(250)) { it }
    val slideOut = slideOutVertically(tween(200)) { it }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        // ===== 0: Ana sayfa =====
        Column(Modifier.fillMaxSize()) {
            SubHeader("Sohbet teması", menu = {
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = AuraWhite) }
                    AuraDropdownMenu(expanded = menu, onDismissRequest = { menu = false }, shape = RoundedCornerShape(16.dp), containerColor = AuraSurface) {
                        DropdownMenuItem(text = { Text("Varsayılana dön", color = AuraWhite, fontSize = 16.sp) }, onClick = {
                            menu = false; bgSel = "amoled"; outSel = "1f7a4d"; doodleOn = true; bgBright = 1f; bgBrightL = 1f
                        })
                        DropdownMenuItem(text = { Text("Tüm sohbetlere uygula", color = AuraWhite, fontSize = 16.sp) }, onClick = {
                            menu = false
                            apply()
                            ChatThemes.applyToAll(ctx, chatId, bgSel, outSel, doodleOn, bgBright, bgBrightL)
                            Toast.makeText(ctx, "Tema tüm sohbetlere uygulandı", Toast.LENGTH_SHORT).show()
                            onBack()
                        })
                        if (dirty) DropdownMenuItem(text = { Text("Uygula ve çık", color = WaGreen, fontSize = 16.sp) }, onClick = { menu = false; apply(); onBack() })
                    }
                }
            }) { if (dirty) askDiscard = true else onBack() }
            LazyColumn(Modifier.fillMaxSize().navigationBarsPadding(), contentPadding = PaddingValues(bottom = 24.dp)) {
                item {
                    Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 8.dp), horizontalArrangement = Arrangement.Center) {
                        RoundAction("Sohbet\nbalonu", {
                            Box(
                                Modifier.size(34.dp, 24.dp).clip(RoundedCornerShape(topStart = 3.dp, topEnd = 10.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                                    .background(bubbleOf(outColor.color))
                            )
                        }) { page = 1 }
                        Spacer(Modifier.width(16.dp))
                        RoundAction("Duvar kağıdı", {
                            Box(Modifier.size(26.dp, 34.dp).clip(RoundedCornerShape(6.dp)).themeBackground(resolvedFor(bgSel, outColor.color).let { ResolvedTheme(it.id, it.stops, it.image, outColor.color, false, 1f) }))
                        }) { page = 2 }
                    }
                }
                PresetCats.forEach { cat ->
                    item(key = "cat_$cat") {
                        Text(cat, color = AuraMuted, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 16.dp, top = 22.dp, bottom = 10.dp))
                        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            val idxs = Presets.indices.filter { Presets[it].cat == cat }
                            items(idxs.size) { k ->
                                val i = idxs[k]
                                val p = Presets[i]
                                val oc = colorOf(p.out)
                                ThemeCard(cardTheme(p.bg, oc, light), oc, bgSel == p.bg && outSel == p.out, light) { openPreviewPreset(i) }
                            }
                        }
                    }
                }
            }
        }

        // ===== 1: Sohbet balonu =====
        AnimatedVisibility(visible = page == 1, enter = slideIn, exit = slideOut) {
            Column(Modifier.fillMaxSize().background(AuraBg)) {
                SubHeader("Sohbet balonu") { page = 0 }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(22.dp), horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize().navigationBarsPadding()
                ) {
                    items(bubbleList, key = { it.id }) { b ->
                        val sel = b.id == outSel
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Box(
                                Modifier.size(58.dp).then(if (sel) Modifier.border(2.dp, AuraWhite, CircleShape).padding(4.dp) else Modifier)
                                    .clip(CircleShape).background(bubbleOf(b.color)).clickable { outSel = b.id; page = 0 },
                                contentAlignment = Alignment.Center
                            ) {
                                if (sel) Box(Modifier.size(24.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Check, null, tint = Color(0xFF0D4A30), modifier = Modifier.size(15.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // ===== 2: Duvar kağıdı =====
        AnimatedVisibility(visible = shows(2), enter = slideIn, exit = slideOut) {
            Column(Modifier.fillMaxSize().background(AuraBg)) {
                SubHeader("Duvar kağıdı") { page = 0 }
                LazyColumn(Modifier.fillMaxSize().navigationBarsPadding(), contentPadding = PaddingValues(bottom = 24.dp)) {
                    item {
                        Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 8.dp), horizontalArrangement = Arrangement.Center) {
                            RoundAction("Galeri", { Icon(Icons.Default.PhotoLibrary, null, tint = AuraWhite, modifier = Modifier.size(26.dp)) }) {
                                gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                            Spacer(Modifier.width(16.dp))
                            RoundAction("Renk", { Icon(Icons.Default.Colorize, null, tint = AuraWhite, modifier = Modifier.size(26.dp)) }) { page = 4 }
                        }
                    }
                    PresetCats.filter { it != "Minimal" }.forEach { cat ->
                        item(key = "w_$cat") {
                            Text(cat, color = AuraMuted, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 16.dp, top = 22.dp, bottom = 10.dp))
                            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                val ids = Presets.filter { it.cat == cat }.map { it.bg }.distinct()
                                items(ids.size) { k ->
                                    val id = ids[k]
                                    ThemeCard(cardTheme(id, outColor.color, light), null, bgSel == id, light) { openPreviewBg(id, 2) }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ===== 4: Düz renkler =====
        AnimatedVisibility(visible = shows(4), enter = slideIn, exit = slideOut) {
            Column(Modifier.fillMaxSize().background(AuraBg)) {
                SubHeader("Düz renkler") { page = 2 }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize().navigationBarsPadding()
                ) {
                    items(bgList.filter { it.id.startsWith("s") && it.id.length == 7 }, key = { it.id }) { t ->
                        val sel = bgSel == t.id
                        Box(
                            Modifier.fillMaxWidth().height(144.dp).clip(RoundedCornerShape(16.dp))
                                .border(if (sel) 3.dp else 1.dp, if (sel) AuraWhite else AuraMuted.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                                .themeBackground(ChatThemes.resolveBuiltIn(t))
                                .clickable { openPreviewBg(t.id, 4) },
                            contentAlignment = Alignment.BottomEnd
                        ) {
                            if (sel) Box(Modifier.padding(8.dp).size(24.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Check, null, tint = Color(0xFF0D4A30), modifier = Modifier.size(15.dp))
                            }
                        }
                    }
                }
            }
        }

        // ===== 3: Önizleme =====
        AnimatedVisibility(visible = page == 3, enter = slideIn, exit = slideOut) {
            Column(Modifier.fillMaxSize().background(AuraBg)) {
                Row(
                    Modifier.fillMaxWidth().background(AuraBlack).statusBarsPadding().height(56.dp).padding(start = 6.dp, end = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { page = previewFrom }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                    Text("Önizleme", color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 6.dp).weight(1f))
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(if (light) Color(0xFF1B6B49) else Color(0xFF25D366)).clickable { apply(); onBack() },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Check, "Uygula", tint = if (light) Color.White else Color(0xFF0B141A), modifier = Modifier.size(22.dp)) }
                }

                Box(Modifier.weight(1f).fillMaxWidth()) {
                    androidx.compose.runtime.key(auto, mode, itemCount) {
                        val n = itemCount.coerceAtLeast(1)
                        val pager = androidx.compose.foundation.pager.rememberPagerState(initialPage = n * 500 + selIdx.coerceIn(0, n - 1)) { n * 1000 }
                        val curSel by androidx.compose.runtime.rememberUpdatedState(selIdx)
                        androidx.compose.runtime.LaunchedEffect(pager) {
                            androidx.compose.runtime.snapshotFlow { pager.settledPage % n }.collect { idx ->
                                if (idx == curSel) return@collect
                                if (auto) { autoIdx = idx; outSel = Presets[idx].out; bgSel = Presets[idx].bg }
                                else if (mode == 0) outSel = bubbleList[idx].id
                                else bgSel = bgIds[idx]
                            }
                        }
                        androidx.compose.runtime.LaunchedEffect(selIdx) {
                            if (pager.currentPage % n != selIdx && !pager.isScrollInProgress) pager.scrollToPage(pager.currentPage - pager.currentPage % n + selIdx.coerceIn(0, n - 1))
                        }
                        androidx.compose.foundation.pager.HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { pg ->
                            val i = pg % n
                            val pOut = if (auto) colorOf(Presets[i].out) else if (mode == 0) bubbleList[i].color else outColor.color
                            val pBg = if (auto) Presets[i].bg else if (mode == 1) bgIds[i] else bgSel
                            val rt = resolvedFor(pBg, pOut)
                            Box(Modifier.fillMaxSize().themeBackground(rt)) {
                                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                        Text(
                                            "Bugün", color = auraLc(0xFF9AA5AB), fontSize = 12.sp,
                                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(if (light) Color(0xFFFFFFFF) else Color(0xCC182229)).padding(horizontal = 10.dp, vertical = 3.dp)
                                        )
                                    }
                                    PreviewBubble("Diğer duvar kağıtlarıyla önizleme yapmak için sola veya sağa kaydırın 🏞️✨", false, "09:13", rt.bubble)
                                    DeepBubbleScope(rt.bubble) { PreviewBubble("Yalnızca bu sohbetiniz değişecek. Sohbet temalarınızı yalnızca siz görebilirsiniz.", true, "09:13", rt.bubble) }
                                    DeepBubbleScope(rt.bubble) { PreviewPhotoBubble("09:14", rt.bubble) }
                                    DeepBubbleScope(rt.bubble) { PreviewReplyBubble("Sen", "Yalnızca bu sohbetiniz değişecek.", "Harika görünüyor, beğendim 👍", "09:15", rt.bubble) }
                                }
                            }
                        }
                    }

                    // Parlaklık çubuğu (sağ alttaki düğmeyle açılır/kapanır)
                    if (showBright) {
                        Box(
                            Modifier.align(Alignment.BottomEnd).padding(end = 22.dp, bottom = 96.dp + 0.dp).navigationBarsPadding()
                                .clip(RoundedCornerShape(34.dp)).background(Color(0xFFE9EDEF)).padding(6.dp)
                        ) {
                            Column(
                                Modifier.clip(RoundedCornerShape(28.dp)).background(Color(0xFF111B21)).padding(vertical = 14.dp, horizontal = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.LightMode, null, tint = Color.White, modifier = Modifier.size(24.dp))
                                Box(Modifier.width(44.dp).height(190.dp), contentAlignment = Alignment.Center) {
                                    androidx.compose.material3.Slider(
                                        value = if (light) bgBrightL else bgBright, onValueChange = { if (light) bgBrightL = it else bgBright = it }, valueRange = if (light) 0.6f..1f else 0.4f..1.6f,
                                        colors = androidx.compose.material3.SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color(0x44FFFFFF)),
                                        modifier = Modifier
                                            .layout { m, c ->
                                                val p = m.measure(Constraints(minWidth = c.minHeight, maxWidth = c.maxHeight, minHeight = c.minWidth, maxHeight = c.maxWidth))
                                                layout(p.height, p.width) { p.place(-(p.width / 2 - p.height / 2), -(p.height / 2 - p.width / 2)) }
                                            }
                                            .graphicsLayer { rotationZ = 270f }
                                    )
                                }
                            }
                        }
                    }

                    // Alt kontroller: sol: desen aç/kapa, orta: noktalar, sağ: parlaklık
                    Row(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp).padding(bottom = 22.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            Modifier.size(56.dp).clip(CircleShape).background(Color(0xF2FFFFFF)).clickable { doodleOn = !doodleOn },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.AutoAwesome, "Desen", tint = if (doodleOn) Color(0xFF111B21) else Color(0xFF9CA3AF), modifier = Modifier.size(26.dp)) }

                        Row(
                            Modifier.clip(RoundedCornerShape(50)).background(Color(0xF2FFFFFF)).padding(horizontal = 18.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            for (k in 0 until 6) {
                                val on = k == selIdx % 6
                                Box(Modifier.size(if (on) 10.dp else 8.dp).clip(CircleShape).background(if (on) Color(0xFF111B21) else Color(0x66111B21)))
                            }
                        }

                        Box(
                            Modifier.size(56.dp).clip(CircleShape).background(Color(0xF2FFFFFF)).clickable { showBright = !showBright },
                            contentAlignment = Alignment.Center
                        ) { Icon(if (light) Icons.Default.DarkMode else Icons.Default.LightMode, "Parlaklık", tint = Color(0xFF111B21), modifier = Modifier.size(26.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PreviewBubble(text: String, mine: Boolean, time: String, out: Color) {
    val st = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, lineHeight = 18.sp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Row(
            Modifier.widthIn(max = 290.dp)
                .clip(RoundedCornerShape(topStart = if (mine) 10.dp else 2.dp, topEnd = if (mine) 2.dp else 10.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(if (mine) out else ThemeDefaultIn)
                .padding(start = 9.dp, end = 7.dp, top = 6.dp, bottom = 5.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Text(text, color = AuraWhite, style = st, modifier = Modifier.weight(1f, fill = false))
            Spacer(Modifier.width(8.dp))
            Text(time, color = auraLc(0xB3FFFFFF), style = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, lineHeight = 13.sp))
            if (mine) {
                Spacer(Modifier.width(3.dp))
                Icon(Icons.Default.DoneAll, null, tint = AuraTick, modifier = Modifier.size(15.dp))
            }
        }
    }
}

/** Gelen fotoğraf balonu önizlemesi */
@Composable
private fun PreviewPhotoBubble(time: String, out: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        Box(
            Modifier.width(200.dp).clip(RoundedCornerShape(topStart = 2.dp, topEnd = 10.dp, bottomStart = 10.dp, bottomEnd = 10.dp)).background(ThemeDefaultIn).padding(3.dp)
        ) {
            Box(
                Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(8.dp))
                    .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF5A6B78), Color(0xFF2E3A44)))),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Image, null, tint = Color(0x99FFFFFF), modifier = Modifier.size(38.dp)) }
            Text(time, color = Color.White, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(end = 7.dp, bottom = 4.dp))
        }
    }
}

/** Giden, alıntı yapılmış (yanıt) balon önizlemesi */
@Composable
private fun PreviewReplyBubble(quoteWho: String, quote: String, text: String, time: String, out: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Column(
            Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(topStart = 10.dp, topEnd = 2.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(out).padding(start = 6.dp, end = 7.dp, top = 6.dp, bottom = 5.dp)
        ) {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color(0x33000000))) {
                Box(Modifier.width(4.dp).height(40.dp).background(Color(0xFFB8F5D2)))
                Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Text(quoteWho, color = Color(0xFFB8F5D2), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(quote, color = Color(0xCCFFFFFF), fontSize = 12.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                }
            }
            Row(Modifier.padding(start = 3.dp, top = 4.dp), verticalAlignment = Alignment.Bottom) {
                Text(text, color = AuraWhite, fontSize = 14.sp, lineHeight = 18.sp, modifier = Modifier.weight(1f, fill = false))
                Spacer(Modifier.width(8.dp))
                Text(time, color = auraLc(0xB3FFFFFF), fontSize = 11.sp)
                Spacer(Modifier.width(3.dp))
                Icon(Icons.Default.DoneAll, null, tint = AuraTick, modifier = Modifier.size(15.dp))
            }
        }
    }
}

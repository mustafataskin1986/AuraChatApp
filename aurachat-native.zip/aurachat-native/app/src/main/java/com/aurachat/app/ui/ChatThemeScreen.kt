package com.aurachat.app.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Groups
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.material.icons.filled.Colorize
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.max
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val WaGreen = Color(0xFF00A884)

/** Hazır temalar (duvar kağıdı + baloncuk rengi çifti); ana sayfada kategori kategori kartlar olarak gösterilir */
private class Preset(val cat: String, val bg: String, val out: String)
private val PresetsAll = listOf(
    Preset("Öne çıkanlar", "amoled", "default"), Preset("Öne çıkanlar", "c_gece", "086b66"), Preset("Öne çıkanlar", "c_mavi", "08529e"),
    Preset("Öne çıkanlar", "c_holo", "803399"), Preset("Öne çıkanlar", "c_aurora", "0a7f6f"), Preset("Öne çıkanlar", "g_gece", "4e38b3"),
    Preset("Doğa", "g_col", "9b153b"), Preset("Doğa", "g_orman", "126d47"), Preset("Doğa", "g_deniz", "0e5d8d"),
    Preset("Doğa", "g_gokyuzu", "803399"), Preset("Doğa", "g_dag", "08529e"), Preset("Doğa", "g_kum", "794b2a"), Preset("Doğa", "g_kar", "0e5d8d"),
    Preset("Canlı", "c_holo", "d82d63"), Preset("Canlı", "c_mavi", "08529e"), Preset("Canlı", "c_aurora", "126d47"),
    Preset("Canlı", "c_seker", "803399"), Preset("Canlı", "c_alev", "a72917"), Preset("Canlı", "c_gece", "4e38b3"),
    Preset("Çiziktirme", "z4e38b3", "4e38b3"), Preset("Çiziktirme", "zd82d63", "d82d63"), Preset("Çiziktirme", "z53565a", "53565a"), Preset("Çiziktirme", "z126d47", "126d47"), Preset("Çiziktirme", "z9e3f22", "9e3f22"), Preset("Çiziktirme", "z08529e", "08529e"), Preset("Çiziktirme", "z803399", "803399"), Preset("Çiziktirme", "z0e5d8d", "0e5d8d"), Preset("Çiziktirme", "z9b153b", "9b153b"), Preset("Çiziktirme", "z5e8a27", "5e8a27")
)
private val PresetsDark = PresetsAll.filter { it.cat != "Çiziktirme" }.plus(listOf(
    Preset("Minimal", "mnd0", "3b3d3e"), Preset("Minimal", "mnd1", "631026"), Preset("Minimal", "mnd2", "2c2463"), Preset("Minimal", "mnd3", "532168"), Preset("Minimal", "mnd4", "092e5c"), Preset("Minimal", "mnd5", "0d4a30"), Preset("Minimal", "mnd6", "532b20"), Preset("Minimal", "mnd7", "0c3b52"), Preset("Minimal", "mnd8", "6f1127"), Preset("Minimal", "mnd9", "3c503e")
)).plus(PresetsAll.filter { it.cat == "Çiziktirme" })
private val PresetsLight = PresetsAll.filter { it.cat != "Çiziktirme" }.plus(listOf(
    Preset("Minimal", "mnl0", "53565a"), Preset("Minimal", "mnl1", "691b3b"), Preset("Minimal", "mnl2", "4e38b3"), Preset("Minimal", "mnl3", "803399"), Preset("Minimal", "mnl4", "08529e"), Preset("Minimal", "mnl5", "126d47"), Preset("Minimal", "mnl6", "9e3f22"), Preset("Minimal", "mnl7", "0e5d8d"), Preset("Minimal", "mnl8", "9b153b"), Preset("Minimal", "mnl9", "6f1127")
)).plus(PresetsAll.filter { it.cat == "Çiziktirme" })
/** Minimal kategorisi koyu / açık temada ayrı (WhatsApp gibi koyuda koyu gri, açıkta beyazımsı) kartlar gösterir */
/** Galeriden resim seçiliyse true: önizlemede kaydırınca "Öne çıkanlar" sırayla gelsin diye listenin başına eklenir, desenli varsayılan kart gizlenir */
private var HeadBg by androidx.compose.runtime.mutableStateOf("")
private var HeadOut by androidx.compose.runtime.mutableStateOf("default")
private val Presets: List<Preset> get() {
    // önizlemede kaydırma şu anki temadan (ilk kart) başlar, sonra "Öne çıkanlar" sırayla gelir
    if (HeadBg.isNotBlank()) return listOf(Preset("Öne çıkanlar", HeadBg, HeadOut)) + presetsBase().filter { !(it.cat == "Öne çıkanlar" && it.bg == "amoled") }
    return presetsBase()
}
private fun presetsBase(): List<Preset> {
    val base = if (AuraUi.lightSystem) PresetsLight else PresetsDark
    val photos = Wallpapers.list().map { Preset(it.cat, it.id, it.outHex) }
    if (photos.isEmpty()) return base
    // Resimli duvar kağıtları aynı adlı kategorinin başına girer; yeni kategoriler sona eklenir
    val out = ArrayList<Preset>()
    val seen = HashSet<String>()
    for (p in base) { if (seen.add(p.cat)) out.addAll(photos.filter { it.cat == p.cat }); out.add(p) }
    photos.filter { it.cat !in seen }.forEach { out.add(it) }
    return out
}
private val PresetCats: List<String> get() = Presets.map { it.cat }.distinct()

private fun cardTheme(bgId0: String, out: Color, light: Boolean, outId: String = "default", bright: Float = 1f): ResolvedTheme {
    val bgId = ChatThemes.zAdapt(bgId0, outId)
    // açık temada varsayılan kart hep krem (WhatsApp gibi), koyuda siyah; tema moduna bakmadan sabit çizilir
    if (bgId == "amoled" || bgId == "default") {
        return if (light) ResolvedTheme("cardcream", listOf(0f to Color(0xFFEFEAE2), 1f to Color(0xFFEFEAE2)), null, out, true, bright)
        else ResolvedTheme("cardblack", listOf(0f to Color.Black, 1f to Color.Black), null, out, true, 1f)
    }
    if (Wallpapers.isWall(bgId)) return ResolvedTheme(bgId, null, Wallpapers.thumb(bgId), out, false, bright)
    val t = ChatThemes.all.firstOrNull { it.id == bgId } ?: (if (ChatThemes.isZ(bgId)) ChatThemes.zFollow(bgId.removePrefix("z")) else null)
    return if (t != null && t.id != "default" && !(t.id == "amoled" && light)) ResolvedTheme(t.id, ChatThemes.adaptStops(t.id, t.stops), null, out, t.id.startsWith("z"), bright)
    else ResolvedTheme("default", null, null, out, true, bright)
}

/** Telefon biçimli tema kartı: duvar kağıdı + (istenirse) gelen ve giden balon örneği; seçiliyken kalın halka ve tik */
@Composable
private fun ThemeCard(rt: ResolvedTheme, out: Color?, selected: Boolean, light: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.width(112.dp).aspectRatio(112f / 184f)
            .then(if (selected) Modifier.border(3.dp, AuraWhite, RoundedCornerShape(20.dp)).padding(4.dp) else Modifier)
            .clip(RoundedCornerShape(if (selected) 16.dp else 18.dp))
            .then(if (selected) Modifier else Modifier.border(1.dp, AuraMuted.copy(alpha = 0.18f), RoundedCornerShape(18.dp)))
            .themeBackground(rt).clickable(onClick = onClick)
    ) {
        if (out != null) {
            Box(Modifier.align(Alignment.TopStart).padding(start = 10.dp, top = 18.dp).size(62.dp, 30.dp)
                .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 10.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(if (light && rt.id.startsWith("mnl")) Color(0xFFEEEEEE) else ThemeDefaultIn))
            Box(Modifier.align(Alignment.TopEnd).padding(end = 10.dp, top = 62.dp).size(56.dp, 30.dp)
                .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 3.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(bubbleOf(out)))
        }
        if (selected) Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp).size(28.dp).clip(CircleShape).background(if (AuraUi.light) Color(0xB3000000) else Color.White),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Check, null, tint = if (AuraUi.light) Color.White else Color.Black, modifier = Modifier.size(18.dp)) }
    }
}

@Composable
private fun SubHeader(title: String, menu: @Composable () -> Unit = {}, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(AuraBlack).statusBarsPadding().height(56.dp).padding(start = 6.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
        Text(title, color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 6.dp).weight(1f))
        menu()
    }
}

@Composable
private fun RoundAction(label: String, content: @Composable () -> Unit, onClick: () -> Unit) {
    Column(Modifier.width(110.dp).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.width(72.dp).height(52.dp).clip(RoundedCornerShape(26.dp)).background(ChipLook.glass), contentAlignment = Alignment.Center) { content() }
        Text(label, color = AuraWhite, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
    }
}

/**
 * Sohbet teması (WhatsApp akışı): ana sayfada hazır tema kartları → dokununca önizleme (sola/sağa kaydır, ✓ uygula).
 * Üstteki iki düğme: Sohbet balonu (renk ızgarası) ve Duvar kağıdı (galeri, düz renkler, kategoriler).
 */
@Composable
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
fun ChatThemeScreen(chatId: String, me: com.aurachat.app.data.UserProfile? = null, target: com.aurachat.app.data.ChatTarget? = null, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var askScope by remember { mutableStateOf(false) }      // "Temayı şunun için ayarla": Siz / Herkes (yalnız birebir sohbet)
    var askGroup by remember { mutableStateOf(false) }      // grup: "Tema ayarlansın mı?" + "Mevcut duvar kağıdımı koru"
    var keepWall by remember { mutableStateOf(false) }
    var scopeAll by remember { mutableStateOf(false) }

    var savedBg by remember { mutableStateOf(ChatThemes.savedId(ctx, chatId)) }
    var savedOut by remember { mutableStateOf(ChatThemes.savedOutId(ctx, chatId)) }
    var savedDoodle by remember { mutableStateOf(ChatThemes.doodleOn(ctx, chatId)) }
    var savedBright by remember { mutableStateOf(ChatThemes.bgBright(ctx, chatId).coerceAtMost(1.15f)) }
    var savedBrightL by remember { mutableStateOf(ChatThemes.bgBrightLight(ctx, chatId)) }

    var bgSel by remember { mutableStateOf(savedBg) }
    var outSel by remember { mutableStateOf(savedOut) }
    var doodleOn by remember { mutableStateOf(savedDoodle) }
    var bgBright by remember { mutableStateOf(savedBright) }
    var bgBrightL by remember { mutableStateOf(savedBrightL) }
    var customBmp by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(ChatThemes.loadCustom(ctx, chatId)) }
    androidx.compose.runtime.SideEffect { HeadBg = savedBg; HeadOut = savedOut }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { HeadBg = "" } }
    var mode by remember { mutableStateOf(1) }        // önizleme: 0 baloncuk, 1 duvar kağıdı (auto=true iken hazır temalar)
    var auto by remember { mutableStateOf(false) }
    var autoIdx by remember { mutableStateOf(0) }
    var page by remember { mutableStateOf(0) }        // 0: ana, 1: balon, 2: duvar kağıdı, 3: önizleme, 4: düz renkler
    // Önizlemedeki koyu/açık deneme yalnızca önizleme sayfasında geçerlidir
    androidx.compose.runtime.LaunchedEffect(page) { if (page != 3) AuraUi.previewDark = null }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { AuraUi.previewDark = null } }
    var previewFrom by remember { mutableStateOf(0) }
    var showBubbleSheet by remember { mutableStateOf(false) }
    var askDiscard by remember { mutableStateOf(false) }
    // Galeriden yeni seçilen resim: önizlemede parmakla sürükleyip yakınlaştırarak ayarlanır
    var adjusting by remember { mutableStateOf(false) }
    var rawBmp by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var snap by remember { mutableStateOf<List<Any>?>(null) }
    var zoomV by remember { mutableStateOf(1f) }
    var panXv by remember { mutableStateOf(0f) }
    var panYv by remember { mutableStateOf(0f) }
    var askResetTheme by remember { mutableStateOf(false) }
    var askResetWall by remember { mutableStateOf(false) }
    var wallMenu by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    val light = AuraUi.lightReal
    val dirty = bgSel != savedBg || outSel != savedOut || doodleOn != savedDoodle || kotlin.math.abs(bgBright - savedBright) > 0.005f || kotlin.math.abs(bgBrightL - savedBrightL) > 0.005f

    fun apply() {
        ChatThemes.set(ctx, chatId, bgSel)
        ChatThemes.setOut(ctx, chatId, outSel)
        ChatThemes.setDoodle(ctx, chatId, doodleOn)
        ChatThemes.setBgBright(ctx, chatId, bgBright)
        ChatThemes.setBgBrightLight(ctx, chatId, bgBrightL)
        savedBg = bgSel; savedOut = outSel; savedDoodle = doodleOn; savedBright = bgBright; savedBrightL = bgBrightL
    }

    // karşı taraf temayı herkes için değiştirirse bu sayfadaki önizleme yüzeyi de anında değişir
    androidx.compose.runtime.LaunchedEffect(chatId) {
        if (me == null) return@LaunchedEffect
        com.aurachat.app.data.Repo.chatThemeFlow(chatId).collect { m ->
            if (m != null && ChatThemes.applyRemote(ctx, me.uid, chatId, m)) {
                savedBg = ChatThemes.savedId(ctx, chatId); savedOut = ChatThemes.savedOutId(ctx, chatId)
                savedDoodle = ChatThemes.doodleOn(ctx, chatId); savedBright = ChatThemes.bgBright(ctx, chatId).coerceAtMost(1.15f)
                savedBrightL = ChatThemes.bgBrightLight(ctx, chatId)
                bgSel = savedBg; outSel = savedOut; doodleOn = savedDoodle; bgBright = savedBright; bgBrightL = savedBrightL
                android.widget.Toast.makeText(ctx, "Sohbet teması karşı taraf tarafından değiştirildi", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Önizlemeyi onayla: yalnız bende ya da herkes için
    fun confirmPreview(everyone: Boolean) {
        scope.launch {
            if (adjusting && bgSel == "custom") {
                if (ChatThemes.cropCustom(ctx, chatId, zoomV, panXv, panYv)) customBmp = ChatThemes.loadCustom(ctx, chatId)
            }
            adjusting = false
            apply()
            if (everyone && me != null && target != null && bgSel != "custom") {
                val at = System.currentTimeMillis()
                ChatThemes.markThemeAt(ctx, chatId, at)
                try {
                    com.aurachat.app.data.Repo.setChatTheme(
                        me, target,
                        mapOf("bg" to bgSel, "out" to outSel, "doodle" to doodleOn, "bright" to bgBright, "brightL" to bgBrightL), at
                    )
                } catch (e: Throwable) { android.widget.Toast.makeText(ctx, "Tema herkes için ayarlanamadı", android.widget.Toast.LENGTH_SHORT).show() }
            }
            // WhatsApp gibi: onaylayınca uygulanır ve sohbet teması ana sayfasına dönülür
            snap = null
            previewFrom = 0
            page = 0
        }
    }

    // Önizleme geçicidir: onay tiki yerine geri basılırsa seçim önizlemeden önceki haline döner
    fun takeSnap() { snap = listOf(bgSel, outSel, auto, mode, autoIdx, doodleOn, bgBright, bgBrightL) }
    fun leavePreview() {
        snap?.let { sn ->
            bgSel = sn[0] as String; outSel = sn[1] as String; auto = sn[2] as Boolean; mode = sn[3] as Int; autoIdx = sn[4] as Int
            doodleOn = sn[5] as Boolean; bgBright = sn[6] as Float; bgBrightL = sn[7] as Float
        }
        snap = null
        adjusting = false
        page = previewFrom
    }

    var pickerOpen by remember { mutableStateOf(false) }
    fun useGalleryUri(uri: android.net.Uri?) {
        if (uri != null) {
            scope.launch {
                if (ChatThemes.saveCustom(ctx, chatId, uri)) {
                    customBmp = ChatThemes.loadCustom(ctx, chatId)
                    takeSnap(); bgSel = "custom"; auto = false; mode = 1; previewFrom = 2; page = 3
                    rawBmp = ChatThemes.loadCustomRaw(ctx, chatId); adjusting = rawBmp != null; zoomV = 1f; panXv = 0f; panYv = 0f
                    // koyu temada resim, diğer temalar gibi hafif karartılmış başlar
                    if (!AuraUi.lightSystem) bgBright = 0.5f
                } else Toast.makeText(ctx, "Resim kaydedilemedi", Toast.LENGTH_SHORT).show()
            }
        }
    }
    if (pickerOpen) PhotoPickerScreen(onClose = { pickerOpen = false }, onPick = { pickerOpen = false; useGalleryUri(it) })

    BackHandler {
        when (page) {
            3 -> leavePreview()
            4 -> page = 2
            1, 2 -> page = 0
            else -> { if (dirty) askDiscard = true else onBack() }
        }
    }

    val bubbleList = ChatThemes.bubbleColors.filter { it.id != "default" }
    fun isOut(id: String, cur: String) = id == cur || (cur == "default" && id == "0d4a30")
    val bgList = ChatThemes.all.filter { it.id != "default" }
    val bgIds = bgList.map { it.id } + Wallpapers.list().map { it.id } + (if (customBmp != null) listOf("custom") else emptyList())
    val outColor = ChatThemes.bubbleColors.firstOrNull { it.id == outSel } ?: ChatThemes.bubbleColors[1]
    val previewBright = if (light) bgBrightL else bgBright
    fun colorOf(id: String): Color = ChatThemes.bubbleColors.firstOrNull { it.id == id }?.color ?: outColor.color

    fun resolvedFor(bgId0: String, out: Color, outId: String = outSel): ResolvedTheme {
        val bgId = ChatThemes.zAdapt(bgId0, outId)
        val t = ChatThemes.all.firstOrNull { it.id == bgId } ?: ChatThemes.zFollow(bgId.removePrefix("z").takeIf { ChatThemes.isZ(bgId) } ?: "")
        return when {
            bgId == "custom" && adjusting && rawBmp != null -> ResolvedTheme("custom", null, rawBmp, out, doodleOn, previewBright, zoomV, panXv, panYv)
            bgId == "custom" && customBmp != null -> ResolvedTheme("custom", null, customBmp, out, doodleOn, previewBright)
            Wallpapers.isWall(bgId) && Wallpapers.full(bgId) != null -> ResolvedTheme(bgId, null, Wallpapers.full(bgId), out, doodleOn, previewBright)
            t != null && t.id != "default" && !(t.id == "amoled" && light) -> ResolvedTheme(t.id, ChatThemes.adaptStops(t.id, t.stops), null, out, doodleOn, previewBright)
            else -> ResolvedTheme("default", null, null, out, doodleOn, previewBright)
        }
    }
    val itemCount = if (auto) Presets.size else if (mode == 0) bubbleList.size else bgIds.size
    val selIdx = if (auto) autoIdx else if (mode == 0) bubbleList.indexOfFirst { isOut(it.id, outSel) }.coerceAtLeast(0) else bgIds.indexOf(bgSel).coerceAtLeast(0)

    fun openPreviewPreset(i: Int) { takeSnap(); auto = true; autoIdx = i; bgSel = Presets[i].bg; outSel = Presets[i].out; previewFrom = 0; page = 3 }
    fun openPreviewBg(id: String, from: Int) { takeSnap(); auto = false; mode = 1; bgSel = id; previewFrom = from; page = 3 }

    if (askScope && me != null && target != null) {
        val other by androidx.compose.runtime.produceState<com.aurachat.app.data.UserProfile?>(null, target.otherUid) {
            value = if (target.isGroup) null else try { com.aurachat.app.data.Repo.loadProfile(target.otherUid) } catch (e: Throwable) { null }
        }
        val canAll = bgSel != "custom"
        AuraBottomSheet(
            onDismissRequest = { askScope = false }, containerColor = AuraSurface,
            sheetState = androidx.compose.material3.rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp).padding(bottom = 18.dp)) {
                Box(Modifier.fillMaxWidth().height(52.dp)) {
                    IconButton(onClick = { askScope = false }, modifier = Modifier.align(Alignment.CenterStart)) { Icon(Icons.Default.Close, "Kapat", tint = AuraWhite) }
                    Text("Temayı şunun için ayarla", color = AuraWhite, fontSize = 20.sp, modifier = Modifier.align(Alignment.Center))
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(false to "Siz", true to "Herkes").forEach { (all, label) ->
                        val on = scopeAll == all
                        val enabled = !all || canAll
                        Row(
                            Modifier.weight(1f).height(52.dp).clip(RoundedCornerShape(14.dp))
                                .background(if (on) ChipLook.bg.compositeOver(AuraBg) else AuraBg.copy(alpha = 0.6f).compositeOver(AuraSurface))
                                .clickable(enabled = enabled) { scopeAll = all }
                                .graphicsLayer { alpha = if (enabled) 1f else 0.4f },
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
                        ) {
                            if (!all) Avatar(me.name, me.avatar, 28.dp)
                            else if (target.isGroup) Icon(Icons.Default.Groups, null, tint = if (on) ChipLook.fg else AuraWhite, modifier = Modifier.size(26.dp))
                            else Avatar(other?.name ?: target.name, other?.avatar ?: "", 28.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(label, color = if (on) ChipLook.fg else AuraWhite, fontSize = 17.sp)
                        }
                    }
                }
                Text(
                    if (!canAll) "Kendi resminiz yalnızca sizde görünür."
                    else if (!scopeAll) "Bu temayı yalnızca siz göreceksiniz."
                    else if (target.isGroup) "Siz ve grup üyeleri bu temayı göreceksiniz."
                    else "Siz ve ${target.name} bu temayı göreceksiniz.",
                    color = AuraMuted, fontSize = 16.sp, modifier = Modifier.padding(top = 16.dp, bottom = 20.dp)
                )
                Box(
                    Modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(50)).background(AuraDialogBtn)
                        .clickable { askScope = false; confirmPreview(scopeAll && canAll) },
                    contentAlignment = Alignment.Center
                ) { Text("Temayı ayarla", color = Color(0xFF0B141A), fontSize = 17.sp, fontWeight = FontWeight.Medium) }
            }
        }
    }
    if (askGroup && target != null) {
        AuraAlertDialog(
            onDismissRequest = { askGroup = false },
            containerColor = AuraSurface,
            title = { Text("Tema ayarlansın mı?", color = AuraWhite, fontSize = 22.sp) },
            text = {
                Column {
                    Text("\"${target.name}\" grubundaki mevcut sohbet temanız değiştirilecek. Sohbet temalarınızı yalnızca siz görebilirsiniz.", color = AuraMuted, fontSize = 15.sp)
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp).clickable { keepWall = !keepWall }, verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.Checkbox(
                            checked = keepWall, onCheckedChange = { keepWall = it },
                            colors = androidx.compose.material3.CheckboxDefaults.colors(checkedColor = WaGreen, uncheckedColor = AuraMuted)
                        )
                        Text("Mevcut duvar kağıdımı koru", color = AuraWhite, fontSize = 16.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    askGroup = false
                    if (keepWall) { bgSel = savedBg; bgBright = savedBright; bgBrightL = savedBrightL; doodleOn = savedDoodle; adjusting = false }
                    confirmPreview(false)
                }) { Text("Temayı ayarla", color = WaGreen, fontWeight = FontWeight.Medium) }
            },
            dismissButton = { TextButton(onClick = { askGroup = false }) { Text("İptal", color = WaGreen) } }
        )
    }
    if (askDiscard) {
        AuraAlertDialog(
            onDismissRequest = { askDiscard = false },
            containerColor = AuraSurface,
            title = { Text("Değişiklikler uygulansın mı?", color = AuraWhite, fontSize = 18.sp) },
            text = { Text("Yaptığın değişiklikler henüz kaydedilmedi.", color = AuraMuted, fontSize = 14.sp) },
            confirmButton = { TextButton(onClick = { apply(); askDiscard = false; onBack() }) { Text("Uygula", color = WaGreen, fontWeight = FontWeight.Medium) } },
            dismissButton = { TextButton(onClick = { askDiscard = false; onBack() }) { Text("Vazgeç", color = AuraMuted) } }
        )
    }

    if (askResetTheme) {
        AuraAlertDialog(
            onDismissRequest = { askResetTheme = false },
            containerColor = AuraSurface,
            title = { Text("Tema sıfırlansın mı?", color = AuraWhite, fontSize = 18.sp) },
            text = { Text("Bu sohbetin teması varsayılana döner: açık temada krem zemin ve beyaz bar, koyu temada siyah.", color = AuraMuted, fontSize = 14.sp) },
            confirmButton = { TextButton(onClick = {
                askResetTheme = false
                // Gerçek varsayılan: açık temada krem zemin + beyaz bar, koyuda siyah; hemen kaydedilir
                bgSel = "amoled"; outSel = "default"; doodleOn = true; bgBright = 0.5f; bgBrightL = 1f
                ChatThemes.clearCustom(ctx, chatId); customBmp = ChatThemes.loadCustom(ctx, chatId)
                apply()
            }) { Text("Sıfırla", color = WaGreen, fontWeight = FontWeight.Medium) } },
            dismissButton = { TextButton(onClick = { askResetTheme = false }) { Text("İptal", color = AuraMuted) } }
        )
    }
    if (askResetWall) {
        AuraAlertDialog(
            onDismissRequest = { askResetWall = false },
            containerColor = AuraSurface,
            title = { Text("Duvar kağıdı sıfırlansın mı?", color = AuraWhite, fontSize = 18.sp) },
            text = { Text("Duvar kağıdı varsayılana döner: açık temada krem, koyu temada siyah.", color = AuraMuted, fontSize = 14.sp) },
            confirmButton = { TextButton(onClick = {
                askResetWall = false
                bgSel = "amoled"; doodleOn = true; bgBright = 0.5f; bgBrightL = 1f
                ChatThemes.clearCustom(ctx, chatId); customBmp = ChatThemes.loadCustom(ctx, chatId)
                apply()
            }) { Text("Sıfırla", color = WaGreen, fontWeight = FontWeight.Medium) } },
            dismissButton = { TextButton(onClick = { askResetWall = false }) { Text("İptal", color = AuraMuted) } }
        )
    }

    fun shows(p: Int) = when (p) {
        2 -> page == 2 || page == 4 || (page == 3 && (previewFrom == 2 || previewFrom == 4))
        4 -> page == 4 || (page == 3 && previewFrom == 4)
        1 -> page == 1 || (page == 3 && previewFrom == 1)
        else -> page == p
    }
    val slideIn = slideInVertically(tween(250)) { it }
    val slideOut = slideOutVertically(tween(200)) { it }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        // ===== 0: Ana sayfa =====
        Column(Modifier.fillMaxSize()) {
            SubHeader("Sohbet teması", menu = {
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = AuraWhite) }
                    AuraDropdownMenu(expanded = menu, onDismissRequest = { menu = false }, shape = RoundedCornerShape(16.dp), containerColor = AuraSurface) {
                        DropdownMenuItem(text = { Text("Temayı sıfırla", color = AuraWhite, fontSize = 16.sp) }, onClick = { menu = false; askResetTheme = true })
                        if (dirty) DropdownMenuItem(text = { Text("Uygula ve çık", color = WaGreen, fontSize = 16.sp) }, onClick = { menu = false; apply(); onBack() })
                    }
                }
            }) { if (dirty) askDiscard = true else onBack() }
            LazyColumn(Modifier.fillMaxSize().navigationBarsPadding(), contentPadding = PaddingValues(bottom = 24.dp)) {
                item {
                    Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 8.dp), horizontalArrangement = Arrangement.Center) {
                        RoundAction("Sohbet\nbalonu", {
                            Box(
                                Modifier.size(34.dp, 24.dp).clip(RoundedCornerShape(topStart = 3.dp, topEnd = 10.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                                    .background(bubbleOf(outColor.color))
                            )
                        }) { page = 1 }
                        Spacer(Modifier.width(16.dp))
                        RoundAction("Duvar kağıdı", {
                            Box(Modifier.size(26.dp, 34.dp).clip(RoundedCornerShape(6.dp)).themeBackground(resolvedFor(bgSel, outColor.color).let { ResolvedTheme(it.id, it.stops, it.image, outColor.color, false, 1f) }))
                        }) { page = 2 }
                    }
                }
                PresetCats.forEach { cat ->
                    item(key = "cat_$cat") {
                        Text(cat, color = AuraMuted, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 16.dp, top = 22.dp, bottom = 10.dp))
                        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            // galeri resmi varsa varsayılan (desenli) kartın yerine geçer (WhatsApp gibi)
                            // WhatsApp gibi: "Öne çıkanlar"ın ilk kartı hep şu anki temadır (tik onda); galeri resmi, seçilen kart ya da sıfırlayınca krem/siyah varsayılan
                            val firstCat = cat == PresetCats.firstOrNull()
                            val selP = if (bgSel == "custom") -1 else Presets.indices.firstOrNull { Presets[it].bg == bgSel && Presets[it].out == outSel && Presets[it].bg != "custom" } ?: -1
                            if (firstCat) item(key = "current_card") {
                                val cb = customBmp
                                if (bgSel == "custom" && cb != null) {
                                    ThemeCard(ResolvedTheme("custom", null, cb, outColor.color, false, if (light) savedBrightL else savedBright), outColor.color, true, light) {
                                        if (HeadBg.isNotBlank()) openPreviewPreset(0) else { takeSnap(); bgSel = "custom"; auto = true; autoIdx = 0; previewFrom = 0; page = 3 }
                                    }
                                } else {
                                    val oc0 = colorOf(outSel)
                                    ThemeCard(cardTheme(bgSel, oc0, light, outSel, if (light) savedBrightL else savedBright), oc0, true, light) {
                                        if (HeadBg.isNotBlank()) openPreviewPreset(0) else if (selP >= 0) openPreviewPreset(selP) else openPreviewBg(bgSel, 0)
                                    }
                                }
                            }
                            val pl = Presets
                            // her arka plan sayfada tek kez görünür: şu anki tema ilk kartta, diğer kategorilerdeki kopyalar gizlenir
                            val idxs = pl.indices.filter { pl[it].cat == cat && (it != 0 || HeadBg.isBlank()) && pl[it].bg != bgSel && pl.indexOfFirst { q -> q.bg == pl[it].bg } == it && !(firstCat && pl[it].bg == "amoled") }
                            items(idxs.size) { k ->
                                val i = idxs[k]; val p = Presets[i]; val oc = colorOf(p.out)
                                ThemeCard(cardTheme(p.bg, oc, light), oc, false, light) { openPreviewPreset(i) }
                            }
                        }
                    }
                }
            }
        }

        // ===== 1: Sohbet balonu =====
        AnimatedVisibility(visible = page == 1, enter = slideIn, exit = slideOut) {
            Column(Modifier.fillMaxSize().background(AuraBg)) {
                var bMenu by remember { mutableStateOf(false) }
                SubHeader("Sohbet balonu", menu = {
                    Box {
                        IconButton(onClick = { bMenu = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = AuraWhite) }
                        AuraDropdownMenu(expanded = bMenu, onDismissRequest = { bMenu = false }, shape = RoundedCornerShape(16.dp), containerColor = AuraSurface, floating = true, yGap = 5.dp) {
                            AuraMI(text = { Text("Sohbet balonunu sıfırla", color = AuraWhite) }, onClick = { bMenu = false; takeSnap(); outSel = "default"; auto = false }, leadingIcon = { Icon(Icons.Default.Refresh, null, tint = AuraWhite) })
                        }
                    }
                }) { page = 0 }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(22.dp), horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize().navigationBarsPadding()
                ) {
                    items(bubbleList, key = { it.id }) { b ->
                        val sel = isOut(b.id, outSel)
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Box(
                                Modifier.size(58.dp).then(if (sel) Modifier.border(2.dp, AuraWhite, CircleShape).padding(4.dp) else Modifier)
                                    .clip(CircleShape).background(bubbleOf(b.color)).clickable { takeSnap(); outSel = b.id; auto = false; mode = 0; previewFrom = 1; page = 3 },
                                contentAlignment = Alignment.Center
                            ) {
                                if (sel) Box(Modifier.size(24.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Check, null, tint = Color(0xFF0D4A30), modifier = Modifier.size(15.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // ===== 2: Duvar kağıdı =====
        AnimatedVisibility(visible = shows(2), enter = slideIn, exit = slideOut) {
            Column(Modifier.fillMaxSize().background(AuraBg)) {
                SubHeader("Duvar kağıdı", menu = {
                    Box {
                        IconButton(onClick = { wallMenu = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = AuraWhite) }
                        AuraDropdownMenu(expanded = wallMenu, onDismissRequest = { wallMenu = false }, shape = RoundedCornerShape(16.dp), containerColor = AuraSurface) {
                            DropdownMenuItem(text = { Text("Duvar kağıdını sıfırla", color = AuraWhite, fontSize = 16.sp) }, onClick = { wallMenu = false; askResetWall = true })
                        }
                    }
                }) { page = 0 }
                LazyColumn(Modifier.fillMaxSize().navigationBarsPadding(), contentPadding = PaddingValues(bottom = 24.dp)) {
                    item {
                        Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 8.dp), horizontalArrangement = Arrangement.Center) {
                            RoundAction("Galeri", { Icon(Icons.Default.PhotoLibrary, null, tint = AuraWhite, modifier = Modifier.size(26.dp)) }) {
                                pickerOpen = true
                            }
                            Spacer(Modifier.width(16.dp))
                            RoundAction("Renk", { Icon(Icons.Default.Colorize, null, tint = AuraWhite, modifier = Modifier.size(26.dp)) }) { page = 4 }
                        }
                    }
                    PresetCats.filter { it != "Minimal" }.forEach { cat ->
                        item(key = "w_$cat") {
                            Text(cat, color = AuraMuted, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 16.dp, top = 22.dp, bottom = 10.dp))
                            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                val ids = Presets.filter { it.cat == cat && Presets.first { p -> p.bg == it.bg }.cat == cat }.map { it.bg }.distinct()
                                items(ids.size) { k ->
                                    val id = ids[k]
                                    ThemeCard(cardTheme(id, outColor.color, light, "default", if (bgSel == id) (if (light) savedBrightL else savedBright) else 1f), null, bgSel == id && Presets.first { it.bg == id }.cat == cat, light) { openPreviewBg(id, 2) }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ===== 4: Düz renkler =====
        AnimatedVisibility(visible = shows(4), enter = slideIn, exit = slideOut) {
            Column(Modifier.fillMaxSize().background(AuraBg)) {
                SubHeader("Düz renkler") { page = 2 }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize().navigationBarsPadding()
                ) {
                    items(bgList.filter { it.id.startsWith("s") && it.id.length == 7 }, key = { it.id }) { t ->
                        val sel = bgSel == t.id
                        Box(
                            Modifier.fillMaxWidth().aspectRatio(112f / 184f).clip(RoundedCornerShape(16.dp))
                                .border(if (sel) 3.dp else 1.dp, if (sel) AuraWhite else AuraMuted.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                                .themeBackground(ChatThemes.resolveBuiltIn(t))
                                .clickable { openPreviewBg(t.id, 4) },
                            contentAlignment = Alignment.BottomEnd
                        ) {
                            if (sel) Box(Modifier.padding(8.dp).size(24.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Check, null, tint = Color(0xFF0D4A30), modifier = Modifier.size(15.dp))
                            }
                        }
                    }
                }
            }
        }

        // ===== 3: Önizleme =====
        AnimatedVisibility(visible = page == 3, enter = slideIn, exit = slideOut) {
            Column(Modifier.fillMaxSize().background(AuraBg)) {
                // sohbetteki gibi: durum + üst çubuk, seçili temanın rengini alır (kaydırdıkça yumuşakça değişir)
                var pvBar by remember { mutableStateOf<Color?>(null) }
                var livePg by remember { mutableIntStateOf(-1) }   // parmakla gezilen sayfa (oturmayı beklemeden)
                val barTarget = pvBar ?: themeBarTint(resolvedFor(bgSel, outColor.color)) ?: AuraBlack
                val barNow by androidx.compose.animation.animateColorAsState(barTarget, androidx.compose.animation.core.tween(160), label = "pvBar")
                Row(
                    Modifier.fillMaxWidth().background(barNow).statusBarsPadding().height(56.dp).padding(start = 6.dp, end = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { leavePreview() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                    Text("Önizleme", color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 6.dp).weight(1f))
                    if (bgSel == "custom" && customBmp != null) {
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).clickable {
                                scope.launch {
                                    if (ChatThemes.flipCustom(ctx, chatId)) {
                                        customBmp = ChatThemes.loadCustom(ctx, chatId)
                                        rawBmp = ChatThemes.loadCustomRaw(ctx, chatId)
                                        panXv = -panXv
                                    }
                                }
                            },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Flip, "Aynala", tint = AuraWhite, modifier = Modifier.size(24.dp)) }
                        Spacer(Modifier.width(8.dp))
                    }
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(if (light) Color(0xFF1B6B49) else Color(0xFF25D366)).clickable {
                            if (me != null && target != null) { if (target.isGroup) { keepWall = false; askGroup = true } else { scopeAll = false; askScope = true } } else confirmPreview(false)
                        },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Check, "Uygula", tint = if (light) Color.White else Color(0xFF0B141A), modifier = Modifier.size(22.dp)) }
                }

                Box(Modifier.weight(1f).fillMaxWidth()) {
                    androidx.compose.runtime.key(auto, mode, itemCount) {
                        val n = itemCount.coerceAtLeast(1)
                        val pager = androidx.compose.foundation.pager.rememberPagerState(initialPage = n * 500 + selIdx.coerceIn(0, n - 1)) { n * 1000 }
                        val curSel by androidx.compose.runtime.rememberUpdatedState(selIdx)
                        androidx.compose.runtime.LaunchedEffect(pager) {
                            androidx.compose.runtime.snapshotFlow { pager.settledPage % n }.collect { idx ->
                                if (idx == curSel) return@collect
                                if (auto) { autoIdx = idx; outSel = Presets[idx].out; bgSel = Presets[idx].bg }
                                else if (mode == 0) outSel = bubbleList[idx].id
                                else {
                                    bgSel = bgIds[idx]
                                    if (!light && bgBright > 0.99f && (bgSel == "custom" || Wallpapers.isWall(bgSel))) bgBright = 0.5f
                                }
                            }
                        }
                        // üst çubuk rengi, sayfa ortadan geçer geçmez ilgili sayfanın temasına göre (oturmayı beklemeden) değişir
                        androidx.compose.runtime.LaunchedEffect(pager, auto, mode, previewBright, doodleOn, light) {
                            androidx.compose.runtime.snapshotFlow { pager.currentPage % n }.collect { i ->
                                val po = if (auto) colorOf(Presets[i].out) else if (mode == 0) bubbleList[i].color else outColor.color
                                val pb = if (auto) Presets[i].bg else if (mode == 1) bgIds[i] else bgSel
                                val pid = if (auto) Presets[i].out else if (mode == 0) bubbleList[i].id else outSel
                                livePg = i
                                pvBar = themeBarTint(resolvedFor(pb, po, pid))
                            }
                        }
                        androidx.compose.runtime.LaunchedEffect(selIdx) {
                            if (pager.currentPage % n != selIdx && !pager.isScrollInProgress) pager.scrollToPage(pager.currentPage - pager.currentPage % n + selIdx.coerceIn(0, n - 1))
                        }
                        androidx.compose.foundation.pager.HorizontalPager(state = pager, modifier = Modifier.fillMaxSize(), userScrollEnabled = !(adjusting && !auto && mode == 1 && bgSel == "custom")) { pg ->
                            val i = pg % n
                            val pOut = if (auto) colorOf(Presets[i].out) else if (mode == 0) bubbleList[i].color else outColor.color
                            val pBg = if (auto) Presets[i].bg else if (mode == 1) bgIds[i] else bgSel
                            val pId = if (auto) Presets[i].out else if (mode == 0) bubbleList[i].id else outSel
                            val rt = resolvedFor(pBg, pOut, pId)
                            val adj = adjusting && pBg == "custom"
                            Box(
                                Modifier.fillMaxSize().themeBackground(rt).then(
                                    if (adj) Modifier.pointerInput(Unit) {
                                        detectTransformGestures { _, pan, zoom, _ ->
                                            val rb = rawBmp ?: return@detectTransformGestures
                                            val w = size.width.toFloat(); val h = size.height.toFloat()
                                            val z = (zoomV * zoom).coerceIn(1f, 4f)
                                            val sc = max(w / rb.width, h / rb.height) * z
                                            val halfX = ((rb.width - w / sc) / 2f).coerceAtLeast(0f)
                                            val halfY = ((rb.height - h / sc) / 2f).coerceAtLeast(0f)
                                            zoomV = z
                                            panXv = if (halfX > 0f) (panXv - pan.x / sc / halfX).coerceIn(-1f, 1f) else 0f
                                            panYv = if (halfY > 0f) (panYv - pan.y / sc / halfY).coerceIn(-1f, 1f) else 0f
                                        }
                                    } else Modifier
                                )
                            ) {
                                if (adj) Text(
                                    "Resmi sürükleyin, iki parmakla yakınlaştırın", color = Color.White, fontSize = 13.sp,
                                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 110.dp).clip(RoundedCornerShape(16.dp)).background(Color(0x99000000)).padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                        Text(
                                            "Bugün", color = auraLc(0xFF9AA5AB), fontSize = 12.sp,
                                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(if (light) Color(0xFFFFFFFF) else Color(0xCC182229)).padding(horizontal = 10.dp, vertical = 3.dp)
                                        )
                                    }
                                    PreviewBubble("Diğer duvar kağıtlarıyla önizleme yapmak için sola veya sağa kaydırın 🏞️✨", false, "09:13", rt.bubble, if (light && rt.id.startsWith("mnl")) Color(0xFFEEEEEE) else ThemeDefaultIn)
                                    DeepBubbleScope(rt.bubble) { PreviewBubble("Yalnızca bu sohbetiniz değişecek. Sohbet temalarınızı yalnızca siz görebilirsiniz.", true, "09:13", rt.bubble) }
                                    DeepBubbleScope(rt.bubble) { PreviewPhotoBubble("09:14", rt.bubble) }
                                    DeepBubbleScope(rt.bubble) { PreviewReplyBubble("Sen", "Yalnızca bu sohbetiniz değişecek.", "Harika görünüyor, beğendim 👍", "09:15", rt.bubble) }
                                }
                            }
                        }
                    }

                    // Parlaklık çubuğu (WhatsApp gibi): yalnızca koyu görünümde açık; yukarı = tam parlak, aşağı = duvar kağıdı karardıkça siyaha gider
                    if (!light) {
                        BrightBar(
                            value = bgBright.coerceIn(0f, 1f),
                            onChange = { f -> bgBright = f.coerceAtLeast(0.1f) },
                            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = 90.dp).navigationBarsPadding()
                        )
                    }

                    val liveI = if (livePg in 0 until itemCount) livePg else selIdx
                    val curBg = if (auto) (Presets.getOrNull(liveI)?.bg ?: bgSel) else if (mode == 1) (bgIds.getOrNull(liveI) ?: bgSel) else bgSel
                    // Açık Minimal'de WhatsApp gibi düğmelerin dolgusu yok, sade simgeler
                    val btnBg = if (light && curBg.startsWith("mnl")) Color.Transparent else Color(0xF2FFFFFF)
                    // Alt kontroller: sol: desen aç/kapa, orta: noktalar, sağ: parlaklık
                    Row(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp).padding(bottom = 22.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // WhatsApp gibi: duvar kağıtlarında (Öne çıkanlar, Doğa, Canlı, galeri) balon rengi seçici; düz renk / Minimal / Çiziktirme / varsayılanda desen aç-kapa
                        val doodleKind = curBg == "amoled" || curBg == "default" || curBg.startsWith("mn") || curBg.startsWith("z") ||
                            (curBg.length == 7 && curBg[0] == 's' && curBg.substring(1).all { it.isDigit() || it in 'a'..'f' })
                        if (doodleKind) {
                            Box(
                                Modifier.size(56.dp).clip(CircleShape).background(btnBg).clickable { doodleOn = !doodleOn },
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Default.AutoAwesome, "Desen", tint = if (doodleOn) Color(0xFF111B21) else Color(0xFF9CA3AF), modifier = Modifier.size(26.dp)) }
                        } else {
                            val shownOut = if (auto) colorOf(Presets.getOrNull(liveI)?.out ?: outSel) else if (mode == 0) (bubbleList.getOrNull(liveI)?.color ?: outColor.color) else outColor.color
                            Box(
                                Modifier.size(56.dp).clip(CircleShape).border(2.dp, Color.White, CircleShape).padding(4.dp)
                                    .clip(CircleShape).background(bubbleOf(shownOut)).clickable { showBubbleSheet = true }
                            )
                        }

                        Row(
                            Modifier.clip(RoundedCornerShape(50)).background(btnBg).padding(horizontal = 18.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            for (k in 0 until 6) {
                                val on = k == liveI % 6
                                Box(Modifier.size(if (on) 10.dp else 8.dp).clip(CircleShape).background(if (on) Color(0xFF111B21) else Color(0x66111B21)))
                            }
                        }

                        Box(
                            Modifier.size(56.dp).clip(CircleShape).background(btnBg).clickable { AuraUi.previewDark = light },
                            contentAlignment = Alignment.Center
                        ) { Icon(if (light) Icons.Default.DarkMode else Icons.Default.LightMode, "Parlaklık", tint = Color(0xFF111B21), modifier = Modifier.size(26.dp)) }
                    }

                    if (showBubbleSheet) {
                        val bsState = androidx.compose.material3.rememberModalBottomSheetState()
                        androidx.compose.runtime.LaunchedEffect(bsState.currentValue, bsState.targetValue) {
                            if (bsState.currentValue == androidx.compose.material3.SheetValue.Expanded && bsState.targetValue == androidx.compose.material3.SheetValue.PartiallyExpanded) {
                                bsState.hide(); showBubbleSheet = false
                            }
                        }
                        AuraBottomSheet(onDismissRequest = { showBubbleSheet = false }, sheetState = bsState) {
                            val screenH = androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp.dp
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(4),
                                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(22.dp), horizontalArrangement = Arrangement.spacedBy(14.dp),
                                modifier = Modifier.fillMaxWidth().heightIn(max = screenH * 0.9f).navigationBarsPadding()
                            ) {
                                items(bubbleList, key = { it.id }) { b ->
                                    val cur = if (auto) (Presets.getOrNull(autoIdx)?.out ?: outSel) else outSel
                                    val sel = isOut(b.id, cur)
                                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                        Box(
                                            Modifier.size(58.dp).then(if (sel) Modifier.border(2.dp, AuraWhite, CircleShape).padding(4.dp) else Modifier)
                                                .clip(CircleShape).background(bubbleOf(b.color)).clickable {
                                                    if (auto) { val bg = Presets.getOrNull(autoIdx)?.bg ?: bgSel; auto = false; mode = 1; bgSel = bg }
                                                    outSel = b.id
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (sel) Box(Modifier.size(24.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                                                Icon(Icons.Default.Check, null, tint = Color(0xFF0D4A30), modifier = Modifier.size(15.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PreviewBubble(text: String, mine: Boolean, time: String, out: Color, inCol: Color = ThemeDefaultIn) {
    val st = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, lineHeight = 18.sp)
    val deep = mine && AuraUi.lightReal && out.luminance() < 0.45f
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Row(
            Modifier.widthIn(max = 290.dp)
                .clip(RoundedCornerShape(topStart = if (mine) 10.dp else 2.dp, topEnd = if (mine) 2.dp else 10.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(if (mine) out else inCol)
                .padding(start = 9.dp, end = 7.dp, top = 6.dp, bottom = 5.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Text(text, color = if (deep) Color.White else AuraWhite, style = st, modifier = Modifier.weight(1f, fill = false))
            Spacer(Modifier.width(8.dp))
            Text(time, color = if (deep) Color(0xB3FFFFFF) else auraLc(0xB3FFFFFF), style = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, lineHeight = 13.sp))
            if (mine) {
                Spacer(Modifier.width(3.dp))
                Icon(Icons.Default.DoneAll, null, tint = if (deep) Color(0xFF53BDEB) else AuraTick, modifier = Modifier.size(15.dp))
            }
        }
    }
}

/** Gelen fotoğraf balonu önizlemesi */
@Composable
private fun PreviewPhotoBubble(time: String, out: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        Box(
            Modifier.width(200.dp).clip(RoundedCornerShape(topStart = 2.dp, topEnd = 10.dp, bottomStart = 10.dp, bottomEnd = 10.dp)).background(ThemeDefaultIn).padding(3.dp)
        ) {
            Box(
                Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(8.dp))
                    .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF5A6B78), Color(0xFF2E3A44)))),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Image, null, tint = Color(0x99FFFFFF), modifier = Modifier.size(38.dp)) }
            Text(time, color = Color.White, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(end = 7.dp, bottom = 4.dp))
        }
    }
}

/** Giden, alıntı yapılmış (yanıt) balon önizlemesi */
@Composable
private fun PreviewReplyBubble(quoteWho: String, quote: String, text: String, time: String, out: Color) {
    val deep = AuraUi.lightReal && out.luminance() < 0.45f
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Column(
            Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(topStart = 10.dp, topEnd = 2.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(out).padding(start = 6.dp, end = 7.dp, top = 6.dp, bottom = 5.dp)
        ) {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color(0x33000000))) {
                val qCol = if (whiteQuote(out)) Color.White else Color(0xFFB8F5D2)
                Box(Modifier.width(4.dp).height(40.dp).background(qCol))
                Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Text(quoteWho, color = qCol, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(quote, color = Color(0xCCFFFFFF), fontSize = 12.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                }
            }
            Row(Modifier.padding(start = 3.dp, top = 4.dp), verticalAlignment = Alignment.Bottom) {
                Text(text, color = if (deep) Color.White else AuraWhite, fontSize = 14.sp, lineHeight = 18.sp, modifier = Modifier.weight(1f, fill = false))
                Spacer(Modifier.width(8.dp))
                Text(time, color = if (deep) Color(0xB3FFFFFF) else auraLc(0xB3FFFFFF), fontSize = 11.sp)
                Spacer(Modifier.width(3.dp))
                Icon(Icons.Default.DoneAll, null, tint = if (deep) Color(0xFF53BDEB) else AuraTick, modifier = Modifier.size(15.dp))
            }
        }
    }
}


/** WhatsApp tarzı dikey parlaklık çubuğu: koyu dolgu alttan yukarı, ucunda simge; yukarı = 1 (tam parlak), aşağı = 0 */
@Composable
private fun BrightBar(value: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val cur by androidx.compose.runtime.rememberUpdatedState(onChange)
    var hPx by remember { mutableStateOf(1) }
    val dens = androidx.compose.ui.platform.LocalDensity.current
    val thumb = 41.dp
    val thumbPx = with(dens) { thumb.toPx() }
    fun fromY(y: Float): Float {
        val span = (hPx - thumbPx).coerceAtLeast(1f)
        return (1f - (y - thumbPx / 2f) / span).coerceIn(0f, 1f)
    }
    Box(
        modifier.width(57.dp).height(220.dp).clip(RoundedCornerShape(50)).background(Color(0xFFE9EDEF))
            .padding(horizontal = 8.dp, vertical = 7.dp)
            .onSizeChanged { hPx = it.height }
            .pointerInput(Unit) {
                detectVerticalDragGestures(onDragStart = { o -> cur(fromY(o.y)) }) { c, _ -> c.consume(); cur(fromY(c.position.y)) }
            }
    ) {
        // dolgunun üstündeki ince çizgi
        Box(Modifier.align(Alignment.TopCenter).padding(top = 10.dp).width(3.dp).fillMaxHeight().clip(RoundedCornerShape(50)).background(Color(0xFFAAAFB2)))
        val fillH = thumb + with(dens) { (hPx - thumbPx).coerceAtLeast(0f).toDp() } * value
        Box(
            Modifier.align(Alignment.BottomCenter).width(thumb).height(fillH).clip(RoundedCornerShape(50)).background(Color(0xFF111B21)),
            contentAlignment = Alignment.TopCenter
        ) {
            Box(Modifier.size(thumb), contentAlignment = Alignment.Center) {
                Icon(if (value in 0.15f..0.85f) Icons.Default.BrightnessMedium else Icons.Default.LightMode, null, tint = Color.White, modifier = Modifier.size(24.dp))
            }
        }
    }
}

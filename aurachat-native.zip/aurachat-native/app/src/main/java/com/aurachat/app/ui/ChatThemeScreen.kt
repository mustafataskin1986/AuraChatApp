package com.aurachat.app.ui

import android.widget.Toast
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.Image
import androidx.compose.ui.draw.rotate
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.snapshotFlow
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.animation.fadeOut
import androidx.compose.animation.fadeIn
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.expandVertically
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.text.font.FontWeight
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.abs

private val Emerald: Color get() = auraLc(0xFF10B981)

/** Sohbet teması: Baloncuk rengi / Arka plan rengi / Arka plan resmi açılır bölümleri, canlı önizleme ve "Uygula" */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatThemeScreen(chatId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var savedBg by remember { mutableStateOf(ChatThemes.savedId(ctx, chatId)) }
    var savedOut by remember { mutableStateOf(ChatThemes.savedOutId(ctx, chatId)) }
    var bgSel by remember { mutableStateOf(savedBg) }
    var outSel by remember { mutableStateOf(savedOut) }
    var customBmp by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(ChatThemes.loadCustom(ctx, chatId)) }
    // 0: kapalı, 1: baloncuk, 2: arka plan rengi, 3: arka plan resmi
    var doodleOn by remember { mutableStateOf(ChatThemes.doodleOn(ctx, chatId)) }
    var savedDoodle by remember { mutableStateOf(ChatThemes.doodleOn(ctx, chatId)) }
    var resetKey by remember { mutableStateOf(0) }
    var bgBright by remember { mutableStateOf(ChatThemes.bgBright(ctx, chatId)) }
    var savedBright by remember { mutableStateOf(ChatThemes.bgBright(ctx, chatId)) }
    var open by remember { mutableStateOf(1) }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                if (ChatThemes.saveCustom(ctx, chatId, uri)) {
                    customBmp = ChatThemes.loadCustom(ctx, chatId)
                    bgSel = "custom"
                    ChatThemes.set(ctx, chatId, "custom")
                } else Toast.makeText(ctx, "Resim kaydedilemedi", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val pickPhoto = { gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }

    // en baştaki "Varsayılan" renkler listeden çıkarıldı: Kömür Yeşili ve Kömür artık varsayılan
    val bubbleList = ChatThemes.bubbleColors.filter { it.id != "default" }
    val bgList = ChatThemes.all.filter { it.id != "default" }
    val outColor = ChatThemes.bubbleColors.firstOrNull { it.id == outSel } ?: ChatThemes.bubbleColors[0]
    val bgTheme = ChatThemes.all.firstOrNull { it.id == bgSel }
    val previewBright = if (AuraUi.light) 1f else bgBright
    val preview: ResolvedTheme = when {
        bgSel == "custom" && customBmp != null -> ResolvedTheme("custom", null, customBmp, outColor.color, doodleOn, previewBright)
        bgTheme != null && bgTheme.id != "default" && !(bgTheme.id == "amoled" && AuraUi.light) -> ResolvedTheme(bgTheme.id, bgTheme.stops, null, outColor.color, doodleOn, previewBright)
        else -> ResolvedTheme("default", null, null, outColor.color, doodleOn, previewBright)
    }
    val light = AuraUi.light
    // Açık ve sistem(açık) temada arka plan ışığı hep %100
    val shownBright = if (light) 1f else bgBright

    Box(Modifier.fillMaxSize().background(AuraBlack)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().height(57.dp).background(AuraBlack).padding(start = 6.dp, end = 16.dp, top = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Text("Sohbet teması", color = AuraWhite, fontSize = 20.sp, modifier = Modifier.padding(start = 8.dp).weight(1f))
                Text(if (doodleOn) "Desenli" else "Desensiz", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(end = 6.dp))
                androidx.compose.material3.Switch(
                    checked = doodleOn,
                    onCheckedChange = { doodleOn = it; ChatThemes.setDoodle(ctx, chatId, it); savedDoodle = it },
                    colors = androidx.compose.material3.SwitchDefaults.colors(checkedTrackColor = outColor.color, checkedThumbColor = AuraWhite),
                    modifier = Modifier.graphicsLayer { scaleX = 0.8f; scaleY = 0.8f }
                )
            }

            // Canlı önizleme: seçimler anında uygulanır, paletler saydam olarak önizlemenin üstünde kayar
            Box(Modifier.weight(1f).fillMaxWidth().themeBackground(preview)) {
                Column(
                    Modifier.fillMaxSize().padding(start = 12.dp, end = 12.dp, bottom = 290.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterVertically)
                ) {
                    Box(Modifier.fillMaxWidth().padding(bottom = 2.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "Bugün", color = auraLc(0xFF9AA5AB), fontSize = 13.sp,
                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(if (light) Color(0xFFFFFFFF) else Color(0xCC000000)).padding(horizontal = 9.dp, vertical = 3.dp)
                        )
                    }
                    PreviewBubble("Selam kanka 👋", false, "10:41", preview.out)
                    PreviewBubble("Tema nasıl olmuş?", true, "10:42", preview.out)
                    PreviewBubble("Çok güzel olmuş, tam istediğim gibi", false, "10:42", preview.out)
                    PreviewBubble("Süper, o zaman bunu kullanalım 😎", true, "10:43", preview.out)
                }

                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 8.dp)) {
                    // Üstte kayan: baloncuk renkleri
                    val n1 = bubbleList.size
                    androidx.compose.runtime.key(resetKey) {
                        SwatchStrip(n1, bubbleList.indexOfFirst { it.id == outSel }.coerceAtLeast(0), {
                            outSel = bubbleList[it].id
                            ChatThemes.setOut(ctx, chatId, outSel)
                        }) { i, centered, tap ->
                            Swatch(centered, tap) { Box(Modifier.fillMaxSize().background(lm(bubbleList[i].color))) }
                        }
                    }
                    // Altta kayan: arka plan renkleri
                    val n2 = bgList.size
                    androidx.compose.runtime.key(resetKey) {
                        SwatchStrip(n2, bgList.indexOfFirst { it.id == bgSel }.coerceAtLeast(0), {
                            bgSel = bgList[it].id
                            ChatThemes.set(ctx, chatId, bgSel)
                        }) { i, centered, tap ->
                            val t = bgList[i]
                            Swatch(centered && bgSel != "custom", tap) {
                                Box(Modifier.fillMaxSize().themeBackground(ChatThemes.resolveBuiltIn(t)))
                            }
                        }
                    }
                    if (!light) {
                        // Arka plan ışığı yalnızca koyu temada
                        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Arka plan ışığı", color = Color.White, fontSize = 13.sp)
                            androidx.compose.material3.Slider(
                                value = bgBright,
                                onValueChange = { bgBright = it },
                                onValueChangeFinished = { ChatThemes.setBgBright(ctx, chatId, bgBright); savedBright = bgBright },
                                valueRange = 0.4f..1.6f,
                                colors = androidx.compose.material3.SliderDefaults.colors(thumbColor = outColor.color, activeTrackColor = outColor.color, inactiveTrackColor = Color(0x55FFFFFF)),
                                modifier = Modifier.weight(1f).padding(horizontal = 10.dp)
                            )
                            Text("${((bgBright - 0.4f) / 1.2f * 100).toInt()}%", color = Color.White, fontSize = 13.sp)
                        }
                    }
                    // Altına: varsayılan temayı uygula
                    Box(
                        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).height(44.dp).clip(RoundedCornerShape(50))
                            .background(Color(0x66000000)).clickable {
                                bgSel = "amoled"; outSel = "1f6f5c"; doodleOn = true; bgBright = 1f; resetKey++
                                ChatThemes.set(ctx, chatId, "amoled")
                                ChatThemes.setOut(ctx, chatId, "1f6f5c")
                                ChatThemes.setDoodle(ctx, chatId, true)
                                ChatThemes.setBgBright(ctx, chatId, 1f)
                                onBack()
                            },
                        contentAlignment = Alignment.Center
                    ) { Text("Varsayılan temayı uygula", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
                    // Altında: arka plan ekle
                    Box(
                        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).height(44.dp).clip(RoundedCornerShape(50))
                            .background(Color(0x66000000)).clickable { pickPhoto() },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Image, null, tint = Color.White, modifier = Modifier.size(20.dp))
                            Text("  Arka plan ekle", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}

/** Açılır bölüm başlığı: küçük renk dairesi + ad + seçili değer + ok */
@Composable
private fun ThemeSection(title: String, value: String, expanded: Boolean, onClick: () -> Unit, dot: @Composable () -> Unit) {
    val rot by animateFloatAsState(if (expanded) 180f else 0f, label = "chev")
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        dot()
        Spacer(Modifier.width(14.dp))
        Text(title, color = AuraWhite, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text(value, color = AuraMuted, fontSize = 14.sp, maxLines = 1)
        Spacer(Modifier.width(6.dp))
        Icon(Icons.Default.KeyboardArrowDown, null, tint = AuraMuted, modifier = Modifier.size(22.dp).rotate(rot))
    }
    Box(Modifier.fillMaxWidth().padding(start = 18.dp).height(1.dp).background(auraLc(0xFF1A2026)))
}

/** Ortadaki daire seçilir: kaydırdıkça (yakalama) seçim değişir, dokununca ortaya gelir */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SwatchStrip(
    count: Int, startIdx: Int, onCenter: (Int) -> Unit,
    item: @Composable (Int, Boolean, () -> Unit) -> Unit
) {
    val st = rememberLazyListState()
    val scope = rememberCoroutineScope()
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val pad = ((maxWidth - 56.dp) / 2).coerceAtLeast(0.dp)
        val center by remember {
            derivedStateOf {
                val info = st.layoutInfo
                val mid = (info.viewportStartOffset + info.viewportEndOffset) / 2
                info.visibleItemsInfo.minByOrNull { abs(it.offset + it.size / 2 - mid) }?.index ?: startIdx
            }
        }
        LaunchedEffect(Unit) {
            st.scrollToItem(startIdx)
            withFrameNanos { }
            withFrameNanos { }
            var first = true
            snapshotFlow { center }.collect {
                // açılışta başlangıç konumu seçimi değiştirmesin
                if (first) { first = false; if (it == startIdx) return@collect }
                onCenter(it)
            }
        }
        LazyRow(
            state = st,
            flingBehavior = rememberSnapFlingBehavior(st),
            contentPadding = PaddingValues(horizontal = pad, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(count) { i -> item(i, i == center) { scope.launch { st.animateScrollToItem(i) } } }
        }
    }
}

@Composable
private fun Swatch(centered: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
    val scale by animateFloatAsState(if (centered) 1f else 0.82f, label = "swScale")
    Box(
        Modifier.size(56.dp).graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape).then(if (centered) Modifier.border(3.dp, Color.White, CircleShape) else Modifier.border(1.dp, Color(0x66FFFFFF), CircleShape))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        content()
        if (centered) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun PreviewBubble(text: String, mine: Boolean, time: String, out: Color) {
    val st = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, lineHeight = 18.sp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Row(
            Modifier.widthIn(max = 290.dp)
                .clip(RoundedCornerShape(topStart = if (mine) 10.dp else 2.dp, topEnd = if (mine) 2.dp else 10.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(if (mine) out else ThemeDefaultIn)
                .padding(start = 9.dp, end = 7.dp, top = 6.dp, bottom = 5.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Text(text, color = AuraWhite, style = st, modifier = Modifier.weight(1f, fill = false))
            Spacer(Modifier.width(8.dp))
            Text(time, color = auraLc(0xB3FFFFFF), style = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, lineHeight = 13.sp))
            if (mine) {
                Spacer(Modifier.width(3.dp))
                Icon(Icons.Default.DoneAll, null, tint = AuraTick, modifier = Modifier.size(15.dp))
            }
        }
    }
}

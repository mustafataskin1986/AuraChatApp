package com.aurachat.app.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/**
 * Sohbet teması: üstte canlı önizleme, altta sabit bir panel (Baloncuk / Arka plan sekmeleri, isimli renk seçenekleri,
 * desen ve ışık ayarı). Seçimler önce önizlemede denenir, "Uygula" ile kaydedilir; geri tuşu kaydedilmemiş değişiklikte sorar.
 */
@Composable
fun ChatThemeScreen(chatId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    val savedBg = remember { ChatThemes.savedId(ctx, chatId) }
    val savedOut = remember { ChatThemes.savedOutId(ctx, chatId) }
    val savedDoodle = remember { ChatThemes.doodleOn(ctx, chatId) }
    val savedBright = remember { ChatThemes.bgBright(ctx, chatId) }

    var bgSel by remember { mutableStateOf(savedBg) }
    var outSel by remember { mutableStateOf(savedOut) }
    var doodleOn by remember { mutableStateOf(savedDoodle) }
    var bgBright by remember { mutableStateOf(savedBright) }
    var customBmp by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(ChatThemes.loadCustom(ctx, chatId)) }
    var tab by remember { mutableStateOf(0) }
    var askDiscard by remember { mutableStateOf(false) }

    val light = AuraUi.light
    val dirty = bgSel != savedBg || outSel != savedOut || doodleOn != savedDoodle || (!light && kotlin.math.abs(bgBright - savedBright) > 0.005f)
    val isDefault = bgSel == "amoled" && outSel == "1f7a4d" && doodleOn && kotlin.math.abs(bgBright - 1f) < 0.01f

    fun apply() {
        ChatThemes.set(ctx, chatId, bgSel)
        ChatThemes.setOut(ctx, chatId, outSel)
        ChatThemes.setDoodle(ctx, chatId, doodleOn)
        ChatThemes.setBgBright(ctx, chatId, bgBright)
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                if (ChatThemes.saveCustom(ctx, chatId, uri)) {
                    customBmp = ChatThemes.loadCustom(ctx, chatId)
                    bgSel = "custom"
                } else Toast.makeText(ctx, "Resim kaydedilemedi", Toast.LENGTH_SHORT).show()
            }
        }
    }

    BackHandler { if (dirty) askDiscard = true else onBack() }

    val bubbleList = ChatThemes.bubbleColors.filter { it.id != "default" }
    val bgList = ChatThemes.all.filter { it.id != "default" }
    val outColor = ChatThemes.bubbleColors.firstOrNull { it.id == outSel } ?: ChatThemes.bubbleColors[0]
    val bgTheme = ChatThemes.all.firstOrNull { it.id == bgSel }
    val previewBright = if (light) 1f else bgBright
    val preview: ResolvedTheme = when {
        bgSel == "custom" && customBmp != null -> ResolvedTheme("custom", null, customBmp, outColor.color, doodleOn, previewBright)
        bgTheme != null && bgTheme.id != "default" && !(bgTheme.id == "amoled" && light) -> ResolvedTheme(bgTheme.id, bgTheme.stops, null, outColor.color, doodleOn, previewBright)
        else -> ResolvedTheme("default", null, null, outColor.color, doodleOn, previewBright)
    }

    if (askDiscard) {
        AuraAlertDialog(
            onDismissRequest = { askDiscard = false },
            containerColor = AuraSurface,
            title = { Text("Değişiklikler uygulansın mı?", color = AuraWhite, fontSize = 18.sp) },
            text = { Text("Yaptığın değişiklikler henüz kaydedilmedi.", color = AuraMuted, fontSize = 14.sp) },
            confirmButton = { TextButton(onClick = { apply(); askDiscard = false; onBack() }) { Text("Uygula", color = outColor.color, fontWeight = FontWeight.Medium) } },
            dismissButton = { TextButton(onClick = { askDiscard = false; onBack() }) { Text("Vazgeç", color = AuraMuted) } }
        )
    }

    Column(Modifier.fillMaxSize().background(AuraBlack).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(start = 6.dp, end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (dirty) askDiscard = true else onBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text("Sohbet teması", color = AuraWhite, fontSize = 20.sp, modifier = Modifier.padding(start = 8.dp).weight(1f))
        }

        // Canlı önizleme (her ekranda aynı yerleşim; panel üstüne binmez)
        Box(Modifier.weight(1f).fillMaxWidth().themeBackground(preview), contentAlignment = Alignment.Center) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.fillMaxWidth().padding(bottom = 2.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Bugün", color = auraLc(0xFF9AA5AB), fontSize = 13.sp,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(if (light) Color(0xFFFFFFFF) else Color(0xCC000000)).padding(horizontal = 9.dp, vertical = 3.dp)
                    )
                }
                PreviewBubble("Selam kanka 👋", false, "10:41", preview.bubble)
                PreviewBubble("Tema nasıl olmuş?", true, "10:42", preview.bubble)
                PreviewBubble("Çok güzel olmuş, tam istediğim gibi", false, "10:42", preview.bubble)
                PreviewBubble("Süper, o zaman bunu kullanalım 😎", true, "10:43", preview.bubble)
            }
        }

        // Sabit alt panel
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)).background(AuraSurface)
                .navigationBarsPadding().padding(top = 14.dp, bottom = 12.dp)
        ) {
            // Sekmeler
            Row(
                Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(42.dp).clip(RoundedCornerShape(50)).background(AuraBlack).padding(3.dp)
            ) {
                listOf("Baloncuk" to 0, "Arka plan" to 1).forEach { (label, i) ->
                    val bg by animateColorAsState(if (tab == i) outColor.color else Color.Transparent, label = "tabBg")
                    Box(
                        Modifier.weight(1f).fillMaxSize().clip(RoundedCornerShape(50)).background(bg).clickable { tab = i },
                        contentAlignment = Alignment.Center
                    ) { Text(label, color = if (tab == i) Color.White else AuraMuted, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                }
            }

            // Renk seçenekleri: dokununca seçilir, isimleri altında yazar
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth().height(100.dp)
            ) {
                if (tab == 0) {
                    items(bubbleList, key = { "b" + it.id }) { b ->
                        Swatch(b.name, outSel == b.id, outColor.color, { outSel = b.id }) {
                            Box(Modifier.fillMaxSize().background(bubbleOf(b.color)))
                        }
                    }
                } else {
                    item(key = "gallery") {
                        Swatch("Galeri", bgSel == "custom" && customBmp != null, outColor.color, { gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                            val bmp = customBmp
                            if (bmp != null) Image(bmp, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            else Box(Modifier.fillMaxSize().background(AuraBlack), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Image, null, tint = AuraWhite, modifier = Modifier.size(22.dp))
                            }
                        }
                    }
                    items(bgList, key = { "g" + it.id }) { t ->
                        Swatch(t.name, bgSel == t.id, outColor.color, { bgSel = t.id }) {
                            Box(Modifier.fillMaxSize().themeBackground(ChatThemes.resolveBuiltIn(t)))
                        }
                    }
                }
            }

            // Ayarlar: her iki sekmede de aynı yerde, panel yüksekliği sabit kalır
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(40.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Arka plan deseni", color = AuraWhite, fontSize = 15.sp, modifier = Modifier.weight(1f))
                androidx.compose.material3.Switch(
                    checked = doodleOn, onCheckedChange = { doodleOn = it },
                    colors = androidx.compose.material3.SwitchDefaults.colors(checkedTrackColor = outColor.color, checkedThumbColor = Color.White),
                    modifier = Modifier.graphicsLayer { scaleX = 0.85f; scaleY = 0.85f }
                )
            }
            if (!light) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(40.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Arka plan ışığı", color = AuraWhite, fontSize = 15.sp)
                    androidx.compose.material3.Slider(
                        value = bgBright, onValueChange = { bgBright = it }, valueRange = 0.4f..1.6f,
                        colors = androidx.compose.material3.SliderDefaults.colors(thumbColor = outColor.color, activeTrackColor = outColor.color, inactiveTrackColor = AuraMuted.copy(alpha = 0.3f)),
                        modifier = Modifier.weight(1f).padding(horizontal = 10.dp)
                    )
                    Text("${((bgBright - 0.4f) / 1.2f * 100).toInt()}%", color = AuraMuted, fontSize = 13.sp, modifier = Modifier.widthIn(min = 38.dp), textAlign = TextAlign.End)
                }
            }

            // Alt düğmeler
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(50)).border(1.dp, AuraMuted.copy(alpha = if (isDefault) 0.25f else 0.6f), RoundedCornerShape(50))
                        .clickable(enabled = !isDefault) { bgSel = "amoled"; outSel = "1f7a4d"; doodleOn = true; bgBright = 1f },
                    contentAlignment = Alignment.Center
                ) { Text("Sıfırla", color = AuraWhite.copy(alpha = if (isDefault) 0.4f else 1f), fontSize = 15.sp, fontWeight = FontWeight.Medium) }
                Box(
                    Modifier.weight(1.4f).height(48.dp).clip(RoundedCornerShape(50))
                        .background(if (dirty) outColor.color else AuraMuted.copy(alpha = 0.25f))
                        .clickable(enabled = dirty) { apply(); onBack() },
                    contentAlignment = Alignment.Center
                ) { Text("Uygula", color = if (dirty) Color.White else AuraMuted, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
            }
        }
    }
}

/** İsimli renk dairesi: seçiliyken kalın halka + tik, seçilmemişken hafif küçük */
@Composable
private fun Swatch(label: String, selected: Boolean, ring: Color, onClick: () -> Unit, content: @Composable () -> Unit) {
    val scale by animateFloatAsState(if (selected) 1f else 0.9f, label = "swScale")
    Column(
        Modifier.width(64.dp).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(54.dp).graphicsLayer { scaleX = scale; scaleY = scale }
                .border(if (selected) 3.dp else 1.dp, if (selected) ring else AuraMuted.copy(alpha = 0.4f), CircleShape)
                .padding(if (selected) 4.dp else 0.dp).clip(CircleShape),
            contentAlignment = Alignment.Center
        ) {
            content()
            if (selected) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = if (selected) AuraWhite else AuraMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable
private fun PreviewBubble(text: String, mine: Boolean, time: String, out: Color) {
    val st = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, lineHeight = 18.sp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Row(
            Modifier.widthIn(max = 290.dp)
                .clip(RoundedCornerShape(topStart = if (mine) 10.dp else 2.dp, topEnd = if (mine) 2.dp else 10.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(if (mine) out else ThemeDefaultIn)
                .padding(start = 9.dp, end = 7.dp, top = 6.dp, bottom = 5.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Text(text, color = AuraWhite, style = st, modifier = Modifier.weight(1f, fill = false))
            Spacer(Modifier.width(8.dp))
            Text(time, color = auraLc(0xB3FFFFFF), style = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, lineHeight = 13.sp))
            if (mine) {
                Spacer(Modifier.width(3.dp))
                Icon(Icons.Default.DoneAll, null, tint = AuraTick, modifier = Modifier.size(15.dp))
            }
        }
    }
}

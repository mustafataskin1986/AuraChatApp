package com.aurachat.app.ui

import android.widget.Toast
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.text.font.FontWeight
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.abs

private val Emerald = Color(0xFF10B981)

/** Sohbet teması seçme sayfası: üstte gerçek sohbet gibi canlı önizleme, altta kayan tema şeridi ve "Uygula" düğmesi */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatThemeScreen(chatId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    val savedId = remember { ChatThemes.savedId(ctx, chatId) }
    val saved = remember { ChatThemes.resolve(ctx, chatId) }
    val customBmp = if (saved.id == "custom") saved.image else null
    val entries = remember { listOf("custom") + ChatThemes.all.map { it.id } }
    val startIdx = remember { entries.indexOf(savedId).let { if (it < 0) 1 else it } }
    val listState = rememberLazyListState()

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                if (ChatThemes.saveCustom(ctx, chatId, uri)) {
                    ChatThemes.set(ctx, chatId, "custom")
                    onBack()
                } else Toast.makeText(ctx, "Tema kaydedilemedi", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val pickPhoto = { gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }

    val centerIdx by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val center = (info.viewportStartOffset + info.viewportEndOffset) / 2
            info.visibleItemsInfo.minByOrNull { abs(it.offset + it.size / 2 - center) }?.index ?: startIdx
        }
    }
    val centerId = entries.getOrElse(centerIdx) { "default" }
    val centerTheme = ChatThemes.all.firstOrNull { it.id == centerId }
    val preview: ResolvedTheme = when (centerId) {
        "custom" -> saved
        else -> centerTheme?.let { ChatThemes.resolveBuiltIn(it) } ?: ChatThemes.resolveBuiltIn(ChatThemes.all[0])
    }
    val centerName = if (centerId == "custom") "Kendi resmin" else (centerTheme?.name ?: "")
    val inUse = centerId == savedId && (centerId != "custom" || customBmp != null)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().height(57.dp).background(Color.Black).padding(start = 6.dp, end = 6.dp, top = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
                Text("Sohbet teması", color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(start = 8.dp).weight(1f))
            }

            // Canlı önizleme: gerçek sohbet gibi (tarih, balonlar, saat + tikler, yazı kutusu)
            Box(Modifier.weight(1f).fillMaxWidth().themeBackground(preview)) {
                Column(
                    Modifier.fillMaxSize().padding(start = 12.dp, end = 12.dp, bottom = 62.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterVertically)
                ) {
                    Box(Modifier.fillMaxWidth().padding(bottom = 4.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "Bugün", color = Color(0xFF9AA5AB), fontSize = 13.sp,
                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xCC000000)).padding(horizontal = 9.dp, vertical = 3.dp)
                        )
                    }
                    PreviewBubble("Selam kanka 👋", false, "10:41", preview.out)
                    PreviewBubble("Tema nasıl olmuş?", true, "10:42", preview.out)
                    PreviewBubble("Çok güzel olmuş, tam istediğim gibi", false, "10:42", preview.out)
                    PreviewBubble("Süper, o zaman bunu kullanalım 😎", true, "10:43", preview.out)
                }
                Row(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 10.dp, end = 10.dp, bottom = 10.dp).height(46.dp)
                        .clip(RoundedCornerShape(23.dp)).background(Color.Black)
                        .border(1.dp, AuraBorder, RoundedCornerShape(23.dp)).padding(start = 16.dp, end = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Bir mesaj yazın...", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(26.dp))
                    Box(Modifier.padding(start = 6.dp).size(36.dp).clip(CircleShape).background(preview.out), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Mic, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
            }

            // Alt panel: tema adı, kayan şerit, Uygula
            Column(Modifier.fillMaxWidth().background(Color(0xFF0D1114)).padding(bottom = 10.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(centerName, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                    if (centerId == savedId && (centerId != "custom" || customBmp != null)) {
                        Text(
                            "Kullanımda", color = Emerald, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(Color(0x2210B981)).padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val tw = ((maxWidth - 48.dp) / 3.4f).coerceAtLeast(70.dp)
                    val pad = ((maxWidth - tw) / 2).coerceAtLeast(0.dp)
                    LaunchedEffect(Unit) { listState.scrollToItem(startIdx) }
                    LazyRow(
                        state = listState,
                        flingBehavior = rememberSnapFlingBehavior(listState),
                        contentPadding = PaddingValues(horizontal = pad, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        itemsIndexed(entries) { i, id ->
                            val t = ChatThemes.all.firstOrNull { it.id == id }
                            ThemeTile(
                                id = id,
                                theme = t,
                                customBmp = customBmp,
                                selected = id == savedId,
                                centered = i == centerIdx,
                                width = tw
                            ) {
                                if (id == "custom" && customBmp == null) pickPhoto()
                                else scope.launch { listState.animateScrollToItem(i) }
                            }
                        }
                    }
                }
                val needPhoto = centerId == "custom" && customBmp == null
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(50.dp).clip(RoundedCornerShape(50))
                        .background(if (inUse) Color(0xFF1B2329) else AuraBorder)
                        .clickable(enabled = !inUse) {
                            if (needPhoto) pickPhoto()
                            else { ChatThemes.set(ctx, chatId, centerId); onBack() }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        when { inUse -> "Uygulandı"; needPhoto -> "Galeriden resim seç"; else -> "Uygula" },
                        color = if (inUse) AuraMuted else Color.Black, fontSize = 17.sp, fontWeight = FontWeight.Medium
                    )
                }
                if (centerId == "custom" && customBmp != null) {
                    Text(
                        "Başka resim seç", color = Emerald, fontSize = 15.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().clickable { pickPhoto() }.padding(top = 12.dp, bottom = 2.dp)
                    )
                } else if (savedId != "default") {
                    Text(
                        "Varsayılana dön", color = Emerald, fontSize = 15.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().clickable { ChatThemes.set(ctx, chatId, "default"); onBack() }.padding(top = 12.dp, bottom = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PreviewBubble(text: String, mine: Boolean, time: String, out: Color) {
    val st = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, lineHeight = 18.sp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Row(
            Modifier.widthIn(max = 290.dp)
                .clip(RoundedCornerShape(topStart = if (mine) 10.dp else 2.dp, topEnd = if (mine) 2.dp else 10.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(if (mine) out else ThemeDefaultIn)
                .padding(start = 9.dp, end = 7.dp, top = 6.dp, bottom = 5.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Text(text, color = Color.White, style = st, modifier = Modifier.weight(1f, fill = false))
            Spacer(Modifier.width(8.dp))
            Text(time, color = Color(0xB3FFFFFF), style = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, lineHeight = 13.sp))
            if (mine) {
                Spacer(Modifier.width(3.dp))
                Icon(Icons.Default.DoneAll, null, tint = AuraTick, modifier = Modifier.size(15.dp))
            }
        }
    }
}

@Composable
private fun ThemeTile(
    id: String,
    theme: ChatTheme?,
    customBmp: androidx.compose.ui.graphics.ImageBitmap?,
    selected: Boolean,
    centered: Boolean,
    width: Dp,
    onClick: () -> Unit
) {
    val scale by animateFloatAsState(if (centered) 1f else 0.88f, label = "tileScale")
    val alphaV by animateFloatAsState(if (centered) 1f else 0.65f, label = "tileAlpha")
    val shape = RoundedCornerShape(14.dp)
    val isCustom = id == "custom"
    val res: ResolvedTheme? = when {
        isCustom && customBmp != null -> ResolvedTheme("custom", null, customBmp, ThemeDefaultOut)
        theme != null -> ChatThemes.resolveBuiltIn(theme)
        else -> null
    }
    Box(Modifier.width(width).graphicsLayer { scaleX = scale; scaleY = scale; alpha = alphaV }.clickable { onClick() }) {
        var box = Modifier.fillMaxWidth().aspectRatio(3f / 4f).clip(shape)
        box = if (res != null) box.themeBackground(res) else box.background(auraC(0xFF202C33))
        box = if (centered) box.border(2.dp, Emerald, shape) else box.border(1.dp, Color(0x22FFFFFF), shape)
        if (isCustom && customBmp == null) box = box.drawBehind {
            drawRoundRect(
                Color(0xFF4B5563), cornerRadius = CornerRadius(14.dp.toPx()),
                style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
            )
        }
        Box(box) {
            if (theme != null) {
                Box(
                    Modifier.align(Alignment.TopStart).padding(start = 8.dp, top = 14.dp)
                        .fillMaxWidth(0.5f).height(12.dp).clip(RoundedCornerShape(4.dp)).background(ThemeDefaultIn)
                )
                Box(
                    Modifier.align(Alignment.TopEnd).padding(end = 8.dp, top = 34.dp)
                        .fillMaxWidth(0.62f).height(12.dp).clip(RoundedCornerShape(4.dp)).background(res?.out ?: ThemeDefaultOut)
                )
            } else if (customBmp == null) {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Image, null, tint = Color(0xFFD1D5DB), modifier = Modifier.size(28.dp))
                    Text("Galeri", color = Color(0xFFD1D5DB), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
            if (selected) {
                Icon(
                    Icons.Default.CheckCircle, null, tint = Color(0xFF34D399),
                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(20.dp)
                )
            }
        }
    }
}

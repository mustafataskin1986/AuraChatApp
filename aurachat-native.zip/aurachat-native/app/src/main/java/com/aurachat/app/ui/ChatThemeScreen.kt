package com.aurachat.app.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.abs

private val Emerald = Color(0xFF10B981)

/** Sohbet teması seçme sayfası (eski web sürümüyle aynı): üstte canlı önizleme, altta kayan tema şeridi */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatThemeScreen(chatId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    val savedId = remember { ChatThemes.savedId(ctx, chatId) }
    val saved = remember { ChatThemes.resolve(ctx, chatId) }
    val customBmp = if (saved.id == "custom") saved.image else null
    val entries = remember { listOf("custom") + ChatThemes.all.map { it.id } }
    val startIdx = remember { entries.indexOf(savedId).let { if (it < 0) 1 else it } }
    val listState = rememberLazyListState()

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                if (ChatThemes.saveCustom(ctx, chatId, uri)) {
                    ChatThemes.set(ctx, chatId, "custom")
                    onBack()
                } else Toast.makeText(ctx, "Tema kaydedilemedi", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val centerIdx by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val center = (info.viewportStartOffset + info.viewportEndOffset) / 2
            info.visibleItemsInfo.minByOrNull { abs(it.offset + it.size / 2 - center) }?.index ?: startIdx
        }
    }
    val centerId = entries.getOrElse(centerIdx) { "default" }
    val preview: ResolvedTheme = when (centerId) {
        "custom" -> saved
        else -> ChatThemes.all.firstOrNull { it.id == centerId }?.let { ChatThemes.resolveBuiltIn(it) } ?: ChatThemes.resolveBuiltIn(ChatThemes.all[0])
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().height(65.dp).background(Color.Black).padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraMuted) }
                Text("Sohbet teması", color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(start = 8.dp))
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF1F2A33)))

            // Önizleme
            Column(
                Modifier.weight(1f).fillMaxWidth().themeBackground(preview).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)
            ) {
                PreviewBubble("Selam kanka 👋", false, preview.out)
                PreviewBubble("Tema nasıl olmuş?", true, preview.out)
                PreviewBubble("Çok güzel olmuş, tam istediğim gibi", false, preview.out)
                PreviewBubble("Süper, o zaman bunu kullanalım 😎", true, preview.out)
            }

            // Tema şeridi
            Column(Modifier.fillMaxWidth().background(AuraChatBg).padding(bottom = 8.dp)) {
                Text(
                    "Renkler ve arka planlar · dokununca uygulanır",
                    color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(start = 16.dp, top = 12.dp, end = 16.dp)
                )
                BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val tw = ((maxWidth - 48.dp) / 3).coerceAtLeast(70.dp)
                    val pad = ((maxWidth - tw) / 2).coerceAtLeast(0.dp)
                    LaunchedEffect(Unit) { listState.scrollToItem(startIdx) }
                    LazyRow(
                        state = listState,
                        flingBehavior = rememberSnapFlingBehavior(listState),
                        contentPadding = PaddingValues(horizontal = pad, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        itemsIndexed(entries) { i, id ->
                            val t = ChatThemes.all.firstOrNull { it.id == id }
                            ThemeTile(
                                id = id,
                                label = if (id == "custom") "Galeriden seç" else (t?.name ?: id),
                                theme = t,
                                customBmp = customBmp,
                                selected = id == savedId,
                                centered = i == centerIdx,
                                width = tw
                            ) {
                                if (id == "custom") {
                                    gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                } else {
                                    ChatThemes.set(ctx, chatId, id)
                                    onBack()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PreviewBubble(text: String, mine: Boolean, out: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Text(
            text, color = Color.White, fontSize = 14.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(if (mine) out else ThemeDefaultIn)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun ThemeTile(
    id: String,
    label: String,
    theme: ChatTheme?,
    customBmp: androidx.compose.ui.graphics.ImageBitmap?,
    selected: Boolean,
    centered: Boolean,
    width: Dp,
    onClick: () -> Unit
) {
    val scale by animateFloatAsState(if (centered) 1f else 0.86f, label = "tileScale")
    val alphaV by animateFloatAsState(if (centered) 1f else 0.7f, label = "tileAlpha")
    val shape = RoundedCornerShape(12.dp)
    val isCustom = id == "custom"
    val res: ResolvedTheme? = when {
        isCustom && customBmp != null -> ResolvedTheme("custom", null, customBmp, ThemeDefaultOut)
        theme != null -> ChatThemes.resolveBuiltIn(theme)
        else -> null
    }
    Column(
        Modifier.width(width).graphicsLayer { scaleX = scale; scaleY = scale; alpha = alphaV }.clickable { onClick() }
    ) {
        var box = Modifier.fillMaxWidth().aspectRatio(3f / 4f).clip(shape)
        box = if (res != null) box.themeBackground(res) else box.background(auraC(0xFF202C33))
        if (selected) box = box.border(2.dp, Emerald, shape)
        else if (isCustom) box = box.drawBehind {
            drawRoundRect(
                Color(0xFF4B5563), cornerRadius = CornerRadius(12.dp.toPx()),
                style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
            )
        }
        Box(box) {
            if (theme != null) {
                Box(
                    Modifier.align(Alignment.TopStart).padding(start = 8.dp, top = 12.dp)
                        .fillMaxWidth(0.5f).height(12.dp).clip(RoundedCornerShape(4.dp)).background(ThemeDefaultIn)
                )
                Box(
                    Modifier.align(Alignment.TopEnd).padding(end = 8.dp, top = 36.dp)
                        .fillMaxWidth(0.66f).height(12.dp).clip(RoundedCornerShape(4.dp)).background(res?.out ?: ThemeDefaultOut)
                )
            } else if (customBmp == null) {
                Icon(Icons.Default.Image, null, tint = Color(0xFFD1D5DB), modifier = Modifier.align(Alignment.Center).size(28.dp))
            }
            if (selected) {
                Icon(
                    Icons.Default.CheckCircle, null, tint = Color(0xFF34D399),
                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(20.dp)
                )
            }
        }
        Text(
            label, color = Color(0xFFD1D5DB), fontSize = 12.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
        )
    }
}

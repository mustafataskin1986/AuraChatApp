package com.aurachat.app.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val WaGreen = Color(0xFF00A884)

/** Uyumlu tema çiftleri (baloncuk, arka plan): sihirli değnek açıkken kaydırınca ikisi birlikte değişir */
private val AutoSets = listOf(
    "0d4a30" to "s1e532b", "092e5c" to "s1a5b6e", "4e38b3" to "s362a63", "532168" to "s42141a",
    "9b153b" to "s680c1d", "794b2a" to "s6e2d1b", "395217" to "s5c6b39", "53565a" to "s3d434a"
)

/**
 * Sohbet teması: tam ekran önizleme. Sola/sağa kaydırınca renk değişir; sol alttaki daire baloncuk sayfasını,
 * sağ alttaki daire arka plan sayfasını açar; sihirli değnek uyumlu tema modudur; sağdaki çubuk arka plan ışığıdır.
 */
@Composable
fun ChatThemeScreen(chatId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    val savedBg = remember { ChatThemes.savedId(ctx, chatId) }
    val savedOut = remember { ChatThemes.savedOutId(ctx, chatId) }
    val savedDoodle = remember { ChatThemes.doodleOn(ctx, chatId) }
    val savedBright = remember { ChatThemes.bgBright(ctx, chatId) }

    var bgSel by remember { mutableStateOf(savedBg) }
    var outSel by remember { mutableStateOf(savedOut) }
    var doodleOn by remember { mutableStateOf(savedDoodle) }
    var bgBright by remember { mutableStateOf(savedBright) }
    var customBmp by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(ChatThemes.loadCustom(ctx, chatId)) }
    var mode by remember { mutableStateOf(0) }       // 0: baloncuk, 1: arka plan
    var auto by remember { mutableStateOf(false) }
    var autoIdx by remember { mutableStateOf(0) }
    var page by remember { mutableStateOf(0) }        // 0: önizleme, 1: baloncuk sayfası, 2: arka plan sayfası
    var askDiscard by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    val light = AuraUi.light
    val dirty = bgSel != savedBg || outSel != savedOut || doodleOn != savedDoodle || (!light && kotlin.math.abs(bgBright - savedBright) > 0.005f)

    fun apply() {
        ChatThemes.set(ctx, chatId, bgSel)
        ChatThemes.setOut(ctx, chatId, outSel)
        ChatThemes.setDoodle(ctx, chatId, doodleOn)
        ChatThemes.setBgBright(ctx, chatId, bgBright)
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                if (ChatThemes.saveCustom(ctx, chatId, uri)) {
                    customBmp = ChatThemes.loadCustom(ctx, chatId)
                    bgSel = "custom"; auto = false; mode = 1; page = 0
                } else Toast.makeText(ctx, "Resim kaydedilemedi", Toast.LENGTH_SHORT).show()
            }
        }
    }

    BackHandler { if (page != 0) page = 0 else if (dirty) askDiscard = true else onBack() }

    val bubbleList = ChatThemes.bubbleColors.filter { it.id != "default" }
    val bgList = ChatThemes.all.filter { it.id != "default" }
    val bgIds = bgList.map { it.id } + (if (customBmp != null) listOf("custom") else emptyList())
    val outColor = ChatThemes.bubbleColors.firstOrNull { it.id == outSel } ?: ChatThemes.bubbleColors[1]
    val bgTheme = ChatThemes.all.firstOrNull { it.id == bgSel }
    val previewBright = if (light) 1f else bgBright
    val preview: ResolvedTheme = when {
        bgSel == "custom" && customBmp != null -> ResolvedTheme("custom", null, customBmp, outColor.color, doodleOn, previewBright)
        bgTheme != null && bgTheme.id != "default" && !(bgTheme.id == "amoled" && light) -> ResolvedTheme(bgTheme.id, bgTheme.stops, null, outColor.color, doodleOn, previewBright)
        else -> ResolvedTheme("default", null, null, outColor.color, doodleOn, previewBright)
    }

    fun step(d: Int) {
        if (auto) {
            autoIdx = (autoIdx + d + AutoSets.size) % AutoSets.size
            outSel = AutoSets[autoIdx].first; bgSel = AutoSets[autoIdx].second
        } else if (mode == 0) {
            val n = bubbleList.size
            val i = bubbleList.indexOfFirst { it.id == outSel }.coerceAtLeast(0)
            outSel = bubbleList[(i + d + n) % n].id
        } else {
            val n = bgIds.size
            val i = bgIds.indexOf(bgSel).coerceAtLeast(0)
            bgSel = bgIds[(i + d + n) % n]
        }
    }

    if (askDiscard) {
        AuraAlertDialog(
            onDismissRequest = { askDiscard = false },
            containerColor = AuraSurface,
            title = { Text("Değişiklikler uygulansın mı?", color = AuraWhite, fontSize = 18.sp) },
            text = { Text("Yaptığın değişiklikler henüz kaydedilmedi.", color = AuraMuted, fontSize = 14.sp) },
            confirmButton = { TextButton(onClick = { apply(); askDiscard = false; onBack() }) { Text("Uygula", color = WaGreen, fontWeight = FontWeight.Medium) } },
            dismissButton = { TextButton(onClick = { askDiscard = false; onBack() }) { Text("Vazgeç", color = AuraMuted) } }
        )
    }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize()) {
            // Üst çubuk
            Row(
                Modifier.fillMaxWidth().background(AuraBlack).statusBarsPadding().height(56.dp).padding(start = 6.dp, end = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { if (dirty) askDiscard = true else onBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Text("Önizleme", color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 6.dp).weight(1f))
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = AuraWhite) }
                    AuraDropdownMenu(expanded = menu, onDismissRequest = { menu = false }, shape = RoundedCornerShape(16.dp), containerColor = AuraSurface) {
                        DropdownMenuItem(text = { Text("Varsayılana dön", color = AuraWhite, fontSize = 16.sp) }, onClick = {
                            menu = false; bgSel = "amoled"; outSel = "1f7a4d"; doodleOn = true; bgBright = 1f; auto = false
                        })
                    }
                }
                Spacer(Modifier.width(4.dp))
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(WaGreen).clickable { if (dirty) apply(); onBack() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Check, "Uygula", tint = Color.White, modifier = Modifier.size(22.dp)) }
            }

            // Sohbet alanı: sola/sağa kaydırınca aktif moddaki renk değişir
            Box(
                Modifier.weight(1f).fillMaxWidth().themeBackground(preview).pointerInput(auto, mode, bubbleList.size, bgIds.size) {
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { total = 0f },
                        onHorizontalDrag = { _, dx -> total += dx },
                        onDragEnd = {
                            val th = 40.dp.toPx()
                            if (total < -th) step(1) else if (total > th) step(-1)
                        }
                    )
                }
            ) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            "Bugün", color = auraLc(0xFF9AA5AB), fontSize = 12.sp,
                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(if (light) Color(0xFFFFFFFF) else Color(0xCC182229)).padding(horizontal = 10.dp, vertical = 3.dp)
                        )
                    }
                    PreviewBubble("Diğer renklerin önizlemesini görmek için sola veya sağa kaydırın 🎨✨", false, "09:13", preview.bubble)
                    PreviewBubble("Yalnızca bu sohbetin teması değişecek. Sohbet temalarını yalnızca sen görebilirsin.", true, "09:13", preview.bubble)
                }

                // İpucu bandı
                Text(
                    if (auto) "Uyumlu tema için sola veya sağa kaydırın 🎨✨"
                    else if (mode == 0) "Baloncuk rengini değiştirmek için sola veya sağa kaydırın"
                    else "Arka planı değiştirmek için sola veya sağa kaydırın",
                    color = Color(0xFFD1D5DB), fontSize = 12.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 84.dp + 0.dp).navigationBarsPadding().widthIn(max = 320.dp)
                        .clip(RoundedCornerShape(50)).background(Color(0xCC111B21)).padding(horizontal = 16.dp, vertical = 7.dp)
                )

                // Arka plan ışığı (koyu temada)
                if (!light) {
                    Column(
                        Modifier.align(Alignment.CenterEnd).padding(end = 12.dp).clip(RoundedCornerShape(50)).background(Color(0xE6111B21)).padding(vertical = 14.dp, horizontal = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.LightMode, null, tint = Color(0xFFD1D5DB), modifier = Modifier.size(16.dp))
                        Box(Modifier.width(34.dp).height(120.dp), contentAlignment = Alignment.Center) {
                            androidx.compose.material3.Slider(
                                value = bgBright, onValueChange = { bgBright = it }, valueRange = 0.4f..1.6f,
                                colors = androidx.compose.material3.SliderDefaults.colors(thumbColor = WaGreen, activeTrackColor = WaGreen, inactiveTrackColor = Color(0x55FFFFFF)),
                                modifier = Modifier
                                    .layout { m, c ->
                                        val p = m.measure(Constraints(minWidth = c.minHeight, maxWidth = c.maxHeight, minHeight = c.minWidth, maxHeight = c.maxWidth))
                                        layout(p.height, p.width) { p.place(-(p.width / 2 - p.height / 2), -(p.height / 2 - p.width / 2)) }
                                    }
                                    .graphicsLayer { rotationZ = 270f }
                            )
                        }
                        Icon(Icons.Default.DarkMode, null, tint = Color(0xFF9CA3AF), modifier = Modifier.size(16.dp))
                    }
                }

                // Alt kontroller: baloncuk dairesi (+ sihirli değnek), noktalar, arka plan dairesi
                Row(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp).padding(bottom = 22.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(Modifier.size(52.dp)) {
                        Box(
                            Modifier.align(Alignment.BottomStart).size(44.dp).border(2.dp, Color.White, CircleShape).padding(2.dp).clip(CircleShape)
                                .background(bubbleOf(outColor.color)).clickable { mode = 0; page = 1 }
                        )
                        val ws by animateFloatAsState(if (auto) 1.12f else 1f, label = "wand")
                        Box(
                            Modifier.align(Alignment.TopEnd).size(26.dp).graphicsLayer { scaleX = ws; scaleY = ws }
                                .clip(CircleShape).background(WaGreen)
                                .border(2.dp, if (auto) Color.White else AuraBlack, CircleShape)
                                .clickable {
                                    auto = !auto
                                    if (auto) { outSel = AutoSets[autoIdx].first; bgSel = AutoSets[autoIdx].second }
                                },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.AutoFixHigh, "Uyumlu tema", tint = Color.White, modifier = Modifier.size(13.dp)) }
                    }

                    val curIdx = if (auto) autoIdx else if (mode == 0) bubbleList.indexOfFirst { it.id == outSel }.coerceAtLeast(0) else bgIds.indexOf(bgSel).coerceAtLeast(0)
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).background(Color(0xCC111B21)).padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (k in 0 until 5) {
                            val on = k == curIdx % 5
                            Box(Modifier.size(if (on) 10.dp else 6.dp).clip(CircleShape).background(if (on) Color.White else Color(0x999CA3AF)))
                        }
                    }

                    Box(
                        Modifier.size(44.dp).border(2.dp, Color.White, CircleShape).padding(2.dp).clip(CircleShape)
                            .themeBackground(preview).clickable { mode = 1; page = 2 }
                    )
                }
            }
        }

        // Tam ekran sayfa: Sohbet balonu
        AnimatedVisibility(visible = page == 1, enter = slideInVertically(tween(250)) { it }, exit = slideOutVertically(tween(200)) { it }) {
            Column(Modifier.fillMaxSize().background(AuraBg)) {
                SubHeader("Sohbet balonu") { page = 0 }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(22.dp), horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize().navigationBarsPadding()
                ) {
                    items(bubbleList, key = { it.id }) { b ->
                        val sel = b.id == outSel && !auto
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Box(
                                Modifier.size(58.dp).then(if (sel) Modifier.border(2.dp, AuraWhite, CircleShape).padding(4.dp) else Modifier)
                                    .clip(CircleShape).background(bubbleOf(b.color)).clickable { auto = false; outSel = b.id; mode = 0; page = 0 },
                                contentAlignment = Alignment.Center
                            ) {
                                if (sel) Box(Modifier.size(24.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Check, null, tint = Color(0xFF0D4A30), modifier = Modifier.size(15.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Tam ekran sayfa: Arka plan
        AnimatedVisibility(visible = page == 2, enter = slideInVertically(tween(250)) { it }, exit = slideOutVertically(tween(200)) { it }) {
            Column(Modifier.fillMaxSize().background(AuraBg)) {
                SubHeader("Arka plan", extra = {
                    Text("Desen", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(end = 6.dp))
                    androidx.compose.material3.Switch(
                        checked = doodleOn, onCheckedChange = { doodleOn = it },
                        colors = androidx.compose.material3.SwitchDefaults.colors(checkedTrackColor = WaGreen, checkedThumbColor = Color.White),
                        modifier = Modifier.graphicsLayer { scaleX = 0.8f; scaleY = 0.8f }
                    )
                }) { page = 0 }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize().navigationBarsPadding()
                ) {
                    item(key = "gallery") {
                        Box(
                            Modifier.fillMaxWidth().height(144.dp).clip(RoundedCornerShape(16.dp)).background(AuraBlack)
                                .clickable { gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            contentAlignment = Alignment.Center
                        ) {
                            val bmp = customBmp
                            if (bmp != null) Image(bmp, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            Box(Modifier.fillMaxSize().background(Color(0x66000000)), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Image, null, tint = WaGreen, modifier = Modifier.size(30.dp))
                                    Text("Galeriden Seç", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
                                }
                            }
                        }
                    }
                    items(bgList, key = { it.id }) { t ->
                        val sel = bgSel == t.id && !auto
                        Box(
                            Modifier.fillMaxWidth().height(144.dp).clip(RoundedCornerShape(16.dp))
                                .border(if (sel) 3.dp else 1.dp, if (sel) AuraWhite else AuraMuted.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                                .themeBackground(ChatThemes.resolveBuiltIn(t))
                                .clickable { auto = false; bgSel = t.id; mode = 1; page = 0 },
                            contentAlignment = Alignment.BottomEnd
                        ) {
                            if (sel) Box(Modifier.padding(8.dp).size(24.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Check, null, tint = Color(0xFF0D4A30), modifier = Modifier.size(15.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SubHeader(title: String, extra: @Composable () -> Unit = {}, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(AuraBlack).statusBarsPadding().height(56.dp).padding(start = 6.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
        Text(title, color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 6.dp).weight(1f))
        extra()
    }
}

@Composable
private fun PreviewBubble(text: String, mine: Boolean, time: String, out: Color) {
    val st = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, lineHeight = 18.sp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Row(
            Modifier.widthIn(max = 290.dp)
                .clip(RoundedCornerShape(topStart = if (mine) 10.dp else 2.dp, topEnd = if (mine) 2.dp else 10.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(if (mine) out else ThemeDefaultIn)
                .padding(start = 9.dp, end = 7.dp, top = 6.dp, bottom = 5.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Text(text, color = AuraWhite, style = st, modifier = Modifier.weight(1f, fill = false))
            Spacer(Modifier.width(8.dp))
            Text(time, color = auraLc(0xB3FFFFFF), style = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, lineHeight = 13.sp))
            if (mine) {
                Spacer(Modifier.width(3.dp))
                Icon(Icons.Default.DoneAll, null, tint = AuraTick, modifier = Modifier.size(15.dp))
            }
        }
    }
}

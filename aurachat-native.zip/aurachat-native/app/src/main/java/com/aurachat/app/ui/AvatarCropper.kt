package com.aurachat.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Matrix
import android.graphics.Rect
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aurachat.app.data.Media
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

/**
 * Profil / grup fotoğrafı kırpma (eski image-cropper.js): parmakla kaydır, iki parmakla yakınlaştır,
 * döndür. Sonuç kare JPEG data URL (outSize x outSize) olarak döner.
 */
@Composable
fun AvatarCropper(uri: Uri, outSize: Int = 320, onDone: (String) -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val src by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            try {
                val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, b) }
                var s = 1
                while (max(b.outWidth, b.outHeight) / s > 2048) s *= 2
                ctx.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
                }
            } catch (e: Throwable) { null }
        }
    }
    var rot by remember { mutableIntStateOf(0) }
    val bmp = remember(src, rot) {
        val s = src
        if (s == null || rot % 4 == 0) s
        else Bitmap.createBitmap(s, 0, 0, s.width, s.height, Matrix().apply { postRotate(90f * (rot % 4)) }, true)
    }

    // aydınlık temada da karanlık görünüm (siyah arka plan, açık durum çubuğu simgeleri)
    val light = false
    val bgC = Color.Black
    val fgC = Color.White
    val accC = AuraGreen
    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        // Dialog kendi penceresi: durum çubuğu simgeleri temaya göre görünsün
        val dView = androidx.compose.ui.platform.LocalView.current
        SideEffect {
            val w = (dView.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
            if (w != null) {
                w.statusBarColor = android.graphics.Color.TRANSPARENT
                w.navigationBarColor = android.graphics.Color.TRANSPARENT
                val ctl = androidx.core.view.WindowCompat.getInsetsController(w, dView)
                ctl.isAppearanceLightStatusBars = light
                ctl.isAppearanceLightNavigationBars = light
            }
        }
        val b = src
        if (b == null) {
            Column(Modifier.fillMaxSize().background(bgC).statusBarsPadding().navigationBarsPadding()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("Yükleniyor…", color = Color(0xFF9CA3AF))
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 18.dp)) {
                    Text("İptal", color = accC, fontSize = 18.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, modifier = Modifier.clickable { onCancel() }.padding(8.dp))
                }
            }
        } else {
            CropperContent(b, true, onCancel) { cropped ->
                onDone(Media.bitmapToDataUrl(Bitmap.createScaledBitmap(cropped, outSize, outSize, true), 120 * 1024))
            }
        }
    }
}

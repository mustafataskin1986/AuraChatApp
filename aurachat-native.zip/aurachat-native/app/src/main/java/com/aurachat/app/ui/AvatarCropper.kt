package com.aurachat.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Matrix
import android.graphics.Rect
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aurachat.app.data.Media
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

/**
 * Profil / grup fotoğrafı kırpma (eski image-cropper.js): parmakla kaydır, iki parmakla yakınlaştır,
 * döndür. Sonuç kare JPEG data URL (outSize x outSize) olarak döner.
 */
@Composable
fun AvatarCropper(uri: Uri, outSize: Int = 320, onDone: (String) -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val src by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            try {
                val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, b) }
                var s = 1
                while (max(b.outWidth, b.outHeight) / s > 2048) s *= 2
                ctx.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
                }
            } catch (e: Throwable) { null }
        }
    }
    var rot by remember { mutableIntStateOf(0) }
    val bmp = remember(src, rot) {
        val s = src
        if (s == null || rot % 4 == 0) s
        else Bitmap.createBitmap(s, 0, 0, s.width, s.height, Matrix().apply { postRotate(90f * (rot % 4)) }, true)
    }

    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Column(Modifier.fillMaxSize().background(auraCRaw(0xFF0B141A)).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(CircleShape).clickable { onCancel() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Close, "İptal", tint = Color.White)
                }
                Text("Fotoğrafı kırp", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(start = 12.dp).weight(1f))
            }
            val b = bmp
            if (b == null) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("Yükleniyor…", color = Color(0xFF9CA3AF))
                }
            } else {
                var cropPx by remember { mutableFloatStateOf(0f) }
                var scale by remember(b) { mutableFloatStateOf(1f) }
                var tx by remember(b) { mutableFloatStateOf(0f) }
                var ty by remember(b) { mutableFloatStateOf(0f) }
                val density = LocalDensity.current

                fun minScale() = if (cropPx <= 0f) 1f else cropPx / minOf(b.width, b.height)
                fun clamp() {
                    val ms = minScale()
                    if (scale < ms) scale = ms
                    if (scale > ms * 6f) scale = ms * 6f
                    val maxX = max(0f, (b.width * scale - cropPx) / 2f)
                    val maxY = max(0f, (b.height * scale - cropPx) / 2f)
                    tx = tx.coerceIn(-maxX, maxX)
                    ty = ty.coerceIn(-maxY, maxY)
                }

                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    val boxW = with(density) { maxWidth.toPx() }
                    val boxH = with(density) { maxHeight.toPx() }
                    val side = minOf(boxW, boxH) - with(density) { 48.dp.toPx() }
                    LaunchedEffect(side, b) {
                        cropPx = side
                        scale = minScale()
                        tx = 0f; ty = 0f
                    }
                    Box(
                        Modifier.fillMaxSize().pointerInput(b, cropPx) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale *= zoom
                                tx += pan.x; ty += pan.y
                                clamp()
                            }
                        },
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            bitmap = b.asImageBitmap(), contentDescription = null,
                            modifier = Modifier
                                .requiredSize(with(density) { b.width.toDp() }, with(density) { b.height.toDp() })
                                .graphicsLayer(scaleX = scale, scaleY = scale, translationX = tx, translationY = ty)
                        )
                        Canvas(Modifier.fillMaxSize()) {
                            val l = (size.width - cropPx) / 2f
                            val t = (size.height - cropPx) / 2f
                            val path = Path().apply {
                                fillType = PathFillType.EvenOdd
                                addRect(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height))
                                addRect(androidx.compose.ui.geometry.Rect(l, t, l + cropPx, t + cropPx))
                            }
                            drawPath(path, Color(0x99000000))
                            drawRect(Color(0xB3FFFFFF), Offset(l, t), Size(cropPx, cropPx), style = Stroke(1.5f))
                            for (i in 1..2) {
                                val o = cropPx * i / 3f
                                drawLine(Color(0x66FFFFFF), Offset(l + o, t), Offset(l + o, t + cropPx), 1f)
                                drawLine(Color(0x66FFFFFF), Offset(l, t + o), Offset(l + cropPx, t + o), 1f)
                            }
                            // daire önizleme çizgisi (profil resmi yuvarlak görünür)
                            drawCircle(Color(0x55FFFFFF), cropPx / 2f, Offset(l + cropPx / 2f, t + cropPx / 2f), style = Stroke(1f))
                        }
                    }
                }

                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(CircleShape).clickable { rot++ }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.RotateRight, "Döndür", tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    Box(
                        Modifier.size(56.dp).clip(CircleShape).background(com.aurachat.app.ui.AuraRawBtn).clickable {
                            if (cropPx > 0f) {
                                val srcSize = cropPx / scale
                                val left = b.width / 2f + (-cropPx / 2f - tx) / scale
                                val top = b.height / 2f + (-cropPx / 2f - ty) / scale
                                val out = Bitmap.createBitmap(outSize, outSize, Bitmap.Config.ARGB_8888)
                                AndroidCanvas(out).drawBitmap(
                                    b,
                                    Rect(left.toInt().coerceAtLeast(0), top.toInt().coerceAtLeast(0),
                                        (left + srcSize).toInt().coerceAtMost(b.width), (top + srcSize).toInt().coerceAtMost(b.height)),
                                    Rect(0, 0, outSize, outSize),
                                    android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
                                )
                                onDone(Media.bitmapToDataUrl(out, 120 * 1024))
                            }
                        },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Done, "Tamam", tint = Color.White, modifier = Modifier.size(30.dp)) }
                }
            }
        }
    }
}

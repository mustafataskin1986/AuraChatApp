package com.aurachat.app.ui

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/** Gradyan duvar kağıdı: renk kodu panelinde oluştur ya da başka yerden kopyalanan kodu yapıştır, kaydet, önizle, uygula. Ayrı sayfa; silinirse yalnız bu dosya + 2 bağlantı kalkar. */
private val hexRe = Regex("#?([0-9A-Fa-f]{6})")

private fun gradCodes(ctx: Context): MutableList<String> =
    (ctx.getSharedPreferences("grad_codes", Context.MODE_PRIVATE).getString("list", "") ?: "").split("|").filter { it.isNotBlank() && ChatThemes.gradStops("gr:$it") != null }.toMutableList()

private fun saveGradCodes(ctx: Context, l: List<String>) {
    ctx.getSharedPreferences("grad_codes", Context.MODE_PRIVATE).edit().putString("list", l.joinToString("|")).apply()
}

private fun brushOf(stops: List<Pair<Float, Color>>, w: Float, h: Float): Brush =
    Brush.linearGradient(*stops.toTypedArray(), start = Offset.Zero, end = Offset(w * 0.36f, h))

private fun stopsOf(hexes: List<String>): List<Pair<Float, Color>> {
    val ok = hexes.filter { hexRe.matchEntire(it) != null }.map { it.removePrefix("#").uppercase() }
    val l = if (ok.size >= 2) ok else listOf("0A1016", "1B3A4B")
    return ChatThemes.gradStops("gr:" + l.take(6).joinToString("-")) ?: emptyList()
}

@Composable
fun GradientWallpaperPage(chatId: String, onClose: () -> Unit, onApplied: () -> Unit) {
    val ctx = LocalContext.current
    val hexes = remember { mutableStateListOf("0A1016", "1B3A4B", "22C55E") }
    var code by remember { mutableStateOf("") }
    val saved = remember { mutableStateListOf<String>().also { it.addAll(gradCodes(ctx)) } }
    var preview by remember { mutableStateOf(false) }
    val stops = stopsOf(hexes.toList())
    fun curId(): String? {
        val ok = hexes.filter { hexRe.matchEntire(it) != null }.map { it.removePrefix("#").uppercase() }
        return if (ok.size in 2..6) ok.joinToString("-") else null
    }
    Dialog(onDismissRequest = { if (preview) preview = false else onClose() }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
    Column(Modifier.fillMaxSize().background(AuraBg)) {
        Row(
            Modifier.fillMaxWidth().background(AuraBlack).statusBarsPadding().height(56.dp).padding(start = 6.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose, modifier = Modifier.offset(x = (-5.6).dp)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text("Gradyan duvar kağıdı", color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 6.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
            Box(
                Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(16.dp))
                    .border(1.dp, AuraMuted.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                    .drawBehind { drawRect(brushOf(stops, size.width, size.height)) }
            )
            Spacer(Modifier.height(18.dp))
            Text("Renkler", color = AuraMuted, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            hexes.forEachIndexed { i, h ->
                val valid = hexRe.matchEntire(h) != null
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).border(1.dp, AuraMuted.copy(alpha = 0.3f), CircleShape)
                            .background(if (valid) Color((0xFF000000L or h.removePrefix("#").toLong(16)).toInt()) else Color.Transparent)
                    )
                    Spacer(Modifier.width(12.dp))
                    BasicTextField(
                        value = h, onValueChange = { v -> hexes[i] = v.filter { c -> c.isLetterOrDigit() || c == '#' }.take(7).uppercase() },
                        singleLine = true,
                        textStyle = TextStyle(color = AuraWhite, fontSize = 16.sp, fontFamily = FontFamily.Monospace),
                        cursorBrush = SolidColor(AuraGreen),
                        modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(ChipLook.glass)
                            .border(1.dp, if (valid) Color.Transparent else Color(0xFFE5484D), RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 12.dp)
                    )
                    IconButton(onClick = { if (hexes.size > 2) hexes.removeAt(i) }) {
                        Icon(Icons.Default.Close, "Sil", tint = if (hexes.size > 2) AuraMuted else AuraMuted.copy(alpha = 0.3f))
                    }
                }
            }
            if (hexes.size < 6) Row(
                Modifier.clip(RoundedCornerShape(20.dp)).clickable { hexes.add(hexes.lastOrNull() ?: "FFFFFF") }.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Add, null, tint = AuraGreen, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text("Renk ekle", color = AuraGreen, fontSize = 15.sp)
            }

            Spacer(Modifier.height(20.dp))
            Text("Kod yapıştır", color = AuraMuted, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(
                    value = code, onValueChange = { code = it.take(300) },
                    textStyle = TextStyle(color = AuraWhite, fontSize = 15.sp, fontFamily = FontFamily.Monospace),
                    cursorBrush = SolidColor(AuraGreen),
                    decorationBox = { inner ->
                        if (code.isEmpty()) Text("#0A1016, #1B3A4B, #22C55E", color = AuraMuted.copy(alpha = 0.6f), fontSize = 15.sp, fontFamily = FontFamily.Monospace)
                        inner()
                    },
                    modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(ChipLook.glass).padding(horizontal = 14.dp, vertical = 12.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "AL", color = AuraGreen, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable {
                        val f = hexRe.findAll(code).map { it.groupValues[1].uppercase() }.toList().take(6)
                        if (f.size >= 2) { hexes.clear(); hexes.addAll(f); code = "" }
                        else Toast.makeText(ctx, "Geçerli kod bulunamadı (en az 2 renk)", Toast.LENGTH_SHORT).show()
                    }.padding(horizontal = 10.dp, vertical = 12.dp)
                )
            }
            Text("Virgülle ayrılmış renk kodları ya da CSS gradyan metni yapıştırabilirsin.", color = AuraMuted, fontSize = 12.5.sp, modifier = Modifier.padding(top = 6.dp))

            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Kaydedilenler", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(
                    "KAYDET", color = AuraGreen, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable {
                        val id = curId()
                        if (id == null) Toast.makeText(ctx, "Geçerli renkler gerekli", Toast.LENGTH_SHORT).show()
                        else if (id !in saved) { saved.add(0, id); saveGradCodes(ctx, saved.toList()) }
                    }.padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            if (saved.isEmpty()) Text("Henüz kayıt yok.", color = AuraMuted.copy(alpha = 0.7f), fontSize = 14.sp)
            else Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                saved.toList().forEach { id ->
                    val st = ChatThemes.gradStops("gr:$id") ?: return@forEach
                    Box(Modifier.size(64.dp, 104.dp)) {
                        Box(
                            Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)).border(1.dp, AuraMuted.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .drawBehind { drawRect(brushOf(st, size.width, size.height)) }
                                .clickable { hexes.clear(); hexes.addAll(id.split("-")) }
                        )
                        Box(
                            Modifier.align(Alignment.TopEnd).padding(3.dp).size(22.dp).clip(CircleShape).background(Color(0x99000000))
                                .clickable { saved.remove(id); saveGradCodes(ctx, saved.toList()) },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Close, "Sil", tint = Color.White, modifier = Modifier.size(14.dp)) }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
        Row(Modifier.fillMaxWidth().background(AuraBg).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(24.dp)).border(1.dp, AuraMuted.copy(alpha = 0.4f), RoundedCornerShape(24.dp)).clickable { preview = true },
                contentAlignment = Alignment.Center
            ) { Text("Önizleme", color = AuraWhite, fontSize = 16.sp) }
            Box(
                Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(24.dp)).background(AuraGreen).clickable {
                    val id = curId()
                    if (id == null) { Toast.makeText(ctx, "Geçerli renkler gerekli (2-6 adet)", Toast.LENGTH_SHORT).show(); return@clickable }
                    ChatThemes.set(ctx, chatId, "gr:$id")
                    ChatThemes.setBgBright(ctx, chatId, 1f)
                    ChatThemes.setBgBrightLight(ctx, chatId, 1f)
                    ChatThemes.setDoodle(ctx, chatId, false)
                    ChatThemes.version++
                    onApplied()
                },
                contentAlignment = Alignment.Center
            ) { Text("Uygula", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium) }
        }
    }
    }

    if (preview) Dialog(onDismissRequest = { preview = false }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(
            Modifier.fillMaxSize().drawBehind { drawRect(brushOf(stops, size.width, size.height)) }.clickable { preview = false }.statusBarsPadding().navigationBarsPadding().padding(16.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xE61F2428)).padding(horizontal = 12.dp, vertical = 8.dp)) { Text("Selam, akşam görüşürüz", color = Color.White, fontSize = 15.sp) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Box(Modifier.clip(RoundedCornerShape(12.dp)).background(AuraGreen).padding(horizontal = 12.dp, vertical = 8.dp)) { Text("Tamam, 19:00 uygun mu?", color = Color.White, fontSize = 15.sp) }
                }
                Text("Kapatmak için dokun", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
            }
        }
    }
}

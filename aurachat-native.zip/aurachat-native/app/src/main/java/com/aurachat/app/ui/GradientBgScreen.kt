package com.aurachat.app.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * Gradyan duvar kağıdı: tür (doğrusal / dairesel / konik) + açı + RGB çubuklarıyla renk durakları, kod yapıştırma (CSS gradyan dahil),
 * kaydetme, önizleme, uygulama. Ayrı sayfa; silinirse yalnız bu dosya + ChatThemeScreen'deki gradOpen satırları kalkar.
 */
private class GCode(val style: Char, val angle: Float, val cx: Int, val cy: Int, val stops: List<List<Int>>)   // stop = [r, g, b, konum%]

private fun gradCodes(ctx: Context): MutableList<String> =
    (ctx.getSharedPreferences("grad_codes", Context.MODE_PRIVATE).getString("list", "") ?: "").split("|").filter { it.isNotBlank() && ChatThemes.gradSpec("gr:$it") != null }.toMutableList()

private fun saveGradCodes(ctx: Context, l: List<String>) {
    ctx.getSharedPreferences("grad_codes", Context.MODE_PRIVATE).edit().putString("list", l.joinToString("|")).apply()
}

private fun hex2(v: Int) = v.coerceIn(0, 255).toString(16).padStart(2, '0').uppercase()
private fun hexOf(s: List<Int>) = hex2(s[0]) + hex2(s[1]) + hex2(s[2])

private fun idOf(style: Char, angle: Int, cx: Int, cy: Int, stops: List<List<Int>>): String =
    "$style${angle}_${cx}_$cy:" + stops.sortedBy { it[3] }.joinToString("-") { hexOf(it) + "@" + it[3] }

private val colorRe = Regex("(#[0-9A-Fa-f]{6}\\b|#[0-9A-Fa-f]{3}\\b|rgba?\\(\\s*\\d+\\s*,\\s*\\d+\\s*,\\s*\\d+[^)]*\\))(?:\\s+(\\d+(?:\\.\\d+)?)%)?")
private val bareHexRe = Regex("\\b([0-9A-Fa-f]{6})\\b")

/** CSS gradyan metnini ya da virgüllü renk listesini çözer; çözemezse null */
private fun parseCode(text0: String): GCode? {
    val text = text0.trim()
    val low = text.lowercase()
    val style = when { "radial-gradient" in low -> 'R'; "conic-gradient" in low -> 'C'; else -> 'L' }
    val inner = if (low.contains("gradient(")) text.substring(text.indexOf('(', low.indexOf("gradient(")) + 1).substringBeforeLast(')') else text
    var angle = if (style == 'C') 0f else 180f
    var cx = 50; var cy = 50
    val il = inner.lowercase()
    // açı: "135deg" / "from 90deg" / "to right"
    Regex("(-?\\d+(?:\\.\\d+)?)\\s*deg").find(il)?.let { angle = it.groupValues[1].toFloat() }
        ?: Regex("to\\s+(top|bottom|left|right)(?:\\s+(top|bottom|left|right))?").find(il)?.let { m ->
            val k = setOf(m.groupValues[1], m.groupValues[2].ifBlank { m.groupValues[1] })
            angle = when {
                k == setOf("top") -> 0f; k == setOf("right") -> 90f; k == setOf("bottom") -> 180f; k == setOf("left") -> 270f
                k == setOf("top", "right") -> 45f; k == setOf("bottom", "right") -> 135f; k == setOf("bottom", "left") -> 225f; else -> 315f
            }
        }
    Regex("at\\s+(\\d+(?:\\.\\d+)?)%\\s+(\\d+(?:\\.\\d+)?)%").find(il)?.let { cx = it.groupValues[1].toFloat().toInt().coerceIn(0, 100); cy = it.groupValues[2].toFloat().toInt().coerceIn(0, 100) }
        ?: Regex("at\\s+(top|bottom|left|right|center)(?:\\s+(top|bottom|left|right|center))?").find(il)?.let { m ->
            val a = m.groupValues[1]; val b = m.groupValues[2]
            for (w in listOf(a, b)) when (w) { "left" -> cx = 0; "right" -> cx = 100; "top" -> cy = 0; "bottom" -> cy = 100 }
        }
    val cols = ArrayList<List<Int>>(); val pos = ArrayList<Float?>()
    for (m in colorRe.findAll(inner)) {
        val t = m.groupValues[1]
        val rgb: List<Int> = when {
            t.startsWith("#") && t.length == 4 -> t.substring(1).map { (it.toString() + it).toInt(16) }
            t.startsWith("#") -> listOf(t.substring(1, 3).toInt(16), t.substring(3, 5).toInt(16), t.substring(5, 7).toInt(16))
            else -> Regex("\\d+").findAll(t.substringAfter('(')).take(3).map { it.value.toInt().coerceIn(0, 255) }.toList().also { if (it.size < 3) return null }
        }
        cols.add(rgb); pos.add(m.groupValues[2].takeIf { it.isNotEmpty() }?.toFloat())
    }
    if (cols.size < 2) {
        // "0A1016, 1B3A4B" gibi # işaretsiz liste
        cols.clear(); pos.clear()
        for (m in bareHexRe.findAll(inner)) { val h = m.groupValues[1]; cols.add(listOf(h.substring(0, 2).toInt(16), h.substring(2, 4).toInt(16), h.substring(4, 6).toInt(16))); pos.add(null) }
    }
    if (cols.size < 2) return null
    val n = minOf(cols.size, 6)
    val ps = pos.take(n).toMutableList()
    if (ps[0] == null) ps[0] = 0f
    if (ps[n - 1] == null) ps[n - 1] = 100f
    var i = 0
    while (i < n) {
        if (ps[i] == null) {
            var j = i; while (ps[j] == null) j++
            val a = ps[i - 1]!!; val b = ps[j]!!
            for (k in i until j) ps[k] = a + (b - a) * (k - i + 1) / (j - i + 1)
            i = j
        } else i++
    }
    return GCode(style, angle, cx, cy, (0 until n).map { cols[it] + ps[it]!!.toInt().coerceIn(0, 100) })
}

@Composable
fun GradientWallpaperPage(chatId: String, onClose: () -> Unit, onApplied: () -> Unit) {
    val ctx = LocalContext.current
    var style by remember { mutableStateOf('L') }
    var angle by remember { mutableIntStateOf(180) }
    var cx by remember { mutableIntStateOf(50) }
    var cy by remember { mutableIntStateOf(50) }
    val stops = remember { mutableStateListOf(listOf(10, 16, 22, 0), listOf(27, 58, 75, 55), listOf(34, 197, 94, 100)) }
    var sel by remember { mutableIntStateOf(0) }
    var code by remember { mutableStateOf("") }
    val saved = remember { mutableStateListOf<String>().also { it.addAll(gradCodes(ctx)) } }
    var preview by remember { mutableStateOf(false) }
    fun curId() = idOf(style, angle, cx, cy, stops.toList())
    val spec = ChatThemes.gradSpec("gr:" + curId())
    val selI = sel.coerceIn(0, stops.size - 1)

    Dialog(onDismissRequest = { if (preview) preview = false else onClose() }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
    Column(Modifier.fillMaxSize().background(AuraBg)) {
        Row(
            Modifier.fillMaxWidth().background(AuraBlack).statusBarsPadding().height(56.dp).padding(start = 6.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose, modifier = Modifier.offset(x = (-5.6).dp)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text("Gradyan duvar kağıdı", color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 6.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
            Box(
                Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(16.dp))
                    .border(1.dp, AuraMuted.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                    .drawBehind { if (spec != null) drawGradSpec(spec) }
            )
            Spacer(Modifier.height(16.dp))
            // stil
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf('L' to "Doğrusal", 'R' to "Dairesel", 'C' to "Konik").forEach { (k, name) ->
                    Box(
                        Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(20.dp))
                            .background(if (style == k) AuraGreen else ChipLook.glass).clickable { style = k },
                        contentAlignment = Alignment.Center
                    ) { Text(name, color = if (style == k) Color.White else AuraWhite, fontSize = 14.sp, fontWeight = if (style == k) FontWeight.Medium else FontWeight.Normal) }
                }
            }
            if (style != 'R') {
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Açı", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.width(56.dp))
                    Slider(value = angle.toFloat(), onValueChange = { angle = it.toInt() }, valueRange = 0f..360f, modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = AuraGreen, activeTrackColor = AuraGreen))
                    Text("$angle°", color = AuraWhite, fontSize = 14.sp, textAlign = TextAlign.End, modifier = Modifier.width(44.dp))
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Renkler", color = AuraMuted, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                stops.forEachIndexed { i, s ->
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(Color(s[0], s[1], s[2]))
                            .border(if (i == selI) 3.dp else 1.dp, if (i == selI) AuraWhite else AuraMuted.copy(alpha = 0.35f), CircleShape)
                            .clickable { sel = i }
                    )
                }
                if (stops.size < 6) Box(
                    Modifier.size(40.dp).clip(CircleShape).background(ChipLook.glass).clickable {
                        val l = stops.last(); stops.add(listOf(l[0], l[1], l[2], 100)); sel = stops.size - 1
                    },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Add, "Renk ekle", tint = AuraGreen, modifier = Modifier.size(22.dp)) }
            }
            val cur = stops[selI]
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("#" + hexOf(cur), color = AuraWhite, fontSize = 16.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                if (stops.size > 2) Row(
                    Modifier.clip(RoundedCornerShape(16.dp)).clickable { stops.removeAt(selI); sel = (selI - 1).coerceAtLeast(0) }.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Close, null, tint = AuraMuted, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Sil", color = AuraMuted, fontSize = 14.sp)
                }
            }
            @Composable
            fun Bar(label: String, idx: Int, max: Float, tint: Color, unit: String = "") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(label, color = AuraMuted, fontSize = 14.sp, modifier = Modifier.width(56.dp))
                    Slider(
                        value = cur[idx].toFloat(), onValueChange = { v -> stops[selI] = cur.toMutableList().also { it[idx] = v.toInt() } },
                        valueRange = 0f..max, modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = tint, activeTrackColor = tint)
                    )
                    Text("${cur[idx]}$unit", color = AuraWhite, fontSize = 14.sp, textAlign = TextAlign.End, modifier = Modifier.width(44.dp))
                }
            }
            Bar("R", 0, 255f, Color(0xFFE5484D))
            Bar("G", 1, 255f, Color(0xFF30A46C))
            Bar("B", 2, 255f, Color(0xFF3E63DD))
            Bar("Konum", 3, 100f, AuraMuted, "%")

            Spacer(Modifier.height(18.dp))
            Text("Kod yapıştır", color = AuraMuted, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(
                    value = code, onValueChange = { code = it.take(600) },
                    textStyle = TextStyle(color = AuraWhite, fontSize = 14.sp, fontFamily = FontFamily.Monospace),
                    cursorBrush = SolidColor(AuraGreen),
                    decorationBox = { inner ->
                        if (code.isEmpty()) Text("linear-gradient(135deg, #0A1016, #22C55E)", color = AuraMuted.copy(alpha = 0.6f), fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                        inner()
                    },
                    modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(ChipLook.glass).padding(horizontal = 14.dp, vertical = 12.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "AL", color = AuraGreen, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable {
                        val g = try { parseCode(code) } catch (e: Throwable) { null }
                        if (g != null) {
                            style = g.style; angle = g.angle.toInt(); cx = g.cx; cy = g.cy
                            stops.clear(); stops.addAll(g.stops); sel = 0; code = ""
                        } else Toast.makeText(ctx, "Kod çözülemedi (en az 2 renk gerekli)", Toast.LENGTH_SHORT).show()
                    }.padding(horizontal = 10.dp, vertical = 12.dp)
                )
            }
            Text("CSS gradyanı (linear / radial / conic) ya da virgülle ayrılmış renk kodları yapıştır.", color = AuraMuted, fontSize = 12.5.sp, modifier = Modifier.padding(top = 6.dp))

            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Kaydedilenler", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(
                    "KAYDET", color = AuraGreen, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable {
                        val id = curId()
                        if (id !in saved) { saved.add(0, id); saveGradCodes(ctx, saved.toList()) }
                    }.padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            if (saved.isEmpty()) Text("Henüz kayıt yok.", color = AuraMuted.copy(alpha = 0.7f), fontSize = 14.sp)
            else Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                saved.toList().forEach { id ->
                    val st = ChatThemes.gradSpec("gr:$id") ?: return@forEach
                    Box(Modifier.size(64.dp, 104.dp)) {
                        Box(
                            Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)).border(1.dp, AuraMuted.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .drawBehind { drawGradSpec(st) }
                                .clickable {
                                    // kayıt kimliğinden geri yükle
                                    val head = id.substringBefore(':'); val body = id.substringAfter(':', id)
                                    if (id.contains(':')) {
                                        style = head[0]; val p = head.substring(1).split("_")
                                        angle = p[0].toFloat().toInt(); cx = p.getOrNull(1)?.toFloat()?.toInt() ?: 50; cy = p.getOrNull(2)?.toFloat()?.toInt() ?: 50
                                    } else { style = 'L'; angle = 180 }
                                    val items = body.split("-")
                                    stops.clear()
                                    items.forEachIndexed { i, it ->
                                        val h = it.substringBefore('@')
                                        val ps = if (it.contains('@')) it.substringAfter('@').toInt() else (i * 100 / (items.size - 1))
                                        stops.add(listOf(h.substring(0, 2).toInt(16), h.substring(2, 4).toInt(16), h.substring(4, 6).toInt(16), ps))
                                    }
                                    sel = 0
                                }
                        )
                        Box(
                            Modifier.align(Alignment.TopEnd).padding(3.dp).size(22.dp).clip(CircleShape).background(Color(0x99000000))
                                .clickable { saved.remove(id); saveGradCodes(ctx, saved.toList()) },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Close, "Sil", tint = Color.White, modifier = Modifier.size(14.dp)) }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
        Row(Modifier.fillMaxWidth().background(AuraBg).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(24.dp)).border(1.dp, AuraMuted.copy(alpha = 0.4f), RoundedCornerShape(24.dp)).clickable { preview = true },
                contentAlignment = Alignment.Center
            ) { Text("Önizleme", color = AuraWhite, fontSize = 16.sp) }
            Box(
                Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(24.dp)).background(AuraGreen).clickable {
                    ChatThemes.set(ctx, chatId, "gr:" + curId())
                    ChatThemes.setBgBright(ctx, chatId, 1f)
                    ChatThemes.setBgBrightLight(ctx, chatId, 1f)
                    ChatThemes.setDoodle(ctx, chatId, false)
                    ChatThemes.version++
                    onApplied()
                },
                contentAlignment = Alignment.Center
            ) { Text("Uygula", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium) }
        }
    }
    }

    if (preview) Dialog(onDismissRequest = { preview = false }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(
            Modifier.fillMaxSize().drawBehind { if (spec != null) drawGradSpec(spec) }.clickable { preview = false }.statusBarsPadding().navigationBarsPadding().padding(16.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xE61F2428)).padding(horizontal = 12.dp, vertical = 8.dp)) { Text("Selam, akşam görüşürüz", color = Color.White, fontSize = 15.sp) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Box(Modifier.clip(RoundedCornerShape(12.dp)).background(AuraGreen).padding(horizontal = 12.dp, vertical = 8.dp)) { Text("Tamam, 19:00 uygun mu?", color = Color.White, fontSize = 15.sp) }
                }
                Text("Kapatmak için dokun", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
            }
        }
    }
}

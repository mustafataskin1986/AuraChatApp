package com.aurachat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Ekranın tam ortasında kısa süre görünen uyarı (sistem Toast'ı artık ortaya konamıyor) */
object CenterToast {
    var text by mutableStateOf<String?>(null)
    var stamp by mutableStateOf(0L)
    fun show(s: String) { text = s; stamp = System.nanoTime() }
}

@Composable
fun CenterToastHost() {
    val t = CenterToast.text ?: return
    LaunchedEffect(CenterToast.stamp) { delay(2600); CenterToast.text = null }
    Box(Modifier.fillMaxSize().padding(horizontal = 40.dp), contentAlignment = Alignment.Center) {
        Text(
            t, color = Color.White, fontSize = 15.sp, letterSpacing = 0.sp, textAlign = TextAlign.Center,
            modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xE6202C33)).padding(horizontal = 22.dp, vertical = 16.dp)
        )
    }
}

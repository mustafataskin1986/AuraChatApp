package com.aurachat.app.ui

import androidx.compose.ui.graphics.compositeOver
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.ChatSummary
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun shareThumb(ctx: android.content.Context, uri: android.net.Uri): android.graphics.Bitmap? = try {
    if (android.os.Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(uri, android.util.Size(200, 200), null)
    else {
        val o = android.graphics.BitmapFactory.Options().apply { inSampleSize = 4 }
        ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
    }
} catch (e: Throwable) { null }

/** Başka uygulamadan "AuraChat ile paylaş" ile gelince açılan "Gönder…" sayfası (çoklu seçim, açıklama, önizleme) */
private val PanelBg: Color @Composable get() = if (AuraUi.light) Color(0xFFF9F9F9) else AuraSurface
private val PanelCard: Color @Composable get() = if (AuraUi.light) Color(0xFFF1F1F1) else auraLc(0xFF1B262D)
private val PanelInner: Color @Composable get() = if (AuraUi.light) Color(0xFFE8E8E8) else AuraBg.copy(alpha = 0.5f)

@Composable
fun ShareTargetScreen(
    me: UserProfile,
    summary: String,
    uris: List<android.net.Uri>,
    hasText: Boolean,
    onBack: () -> Unit,
    onStatus: () -> Unit = {},
    text: String = "",
    onSend: (List<ChatTarget>, String) -> Unit
) {
    val ctx = LocalContext.current
    // Ekran açılır açılmaz (kişi seçmeden önce) link önizlemesini ve resmini indir; gönderince sohbette anında hazır olsun
    androidx.compose.runtime.LaunchedEffect(text) {
        val u = Regex("https?://[^\\s<>\"']+", RegexOption.IGNORE_CASE).find(text)?.value?.trimEnd('.', ',', ';', ':', '!', '?', ')', ']')
        if (u != null) try { Repo.fetchLinkPreview(u)?.let { if (it.image.isNotBlank()) LinkImgCache.load(ctx.applicationContext, it.image) } } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ShareTargetScreen", e) }
    }
    val chats by remember(me.uid) { Repo.chatsFlow(me.uid) }.collectAsState(remember(me.uid) { Repo.cachedChats(me.uid) ?: emptyList<ChatSummary>() })
    val users by remember(me.uid) { Repo.usersFlow(me.uid) }.collectAsState(Repo.cachedUsers() ?: emptyList())
    var q by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var picked by remember { mutableStateOf<List<ChatTarget>>(emptyList()) }
    var caption by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    BackHandler { if (searching) { searching = false; q = "" } else onBack() }
    LaunchedEffect(searching) { if (searching) try { focus.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ShareTargetScreen", e) } }

    val recent = visibleChats(chats).filter { it.otherUid != me.uid }.sortedByDescending { it.lastTime }
        .map { ChatTarget(it.chatId, it.isGroup, it.otherUid, it.name) }
    val ids = recent.map { it.chatId }.toSet()
    val others = users.filter { it.uid != me.uid && !ids.contains(Repo.chatId(me.uid, it.uid)) }
        .map { ChatTarget(Repo.chatId(me.uid, it.uid), false, it.uid, it.name) }
    fun f(l: List<ChatTarget>) = l.filter { q.isBlank() || it.name.contains(q, ignoreCase = true) }
    val frequent = if (q.isBlank()) recent.filter { !it.isGroup }.take(4) else emptyList()
    val freqIds = frequent.map { it.chatId }.toSet()
    val rest = if (q.isBlank()) recent.filter { !freqIds.contains(it.chatId) } else f(recent)
    val people = f(others)

    fun toggle(t: ChatTarget) {
        picked = if (picked.any { it.chatId == t.chatId }) picked.filter { it.chatId != t.chatId } else picked + t
    }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { if (searching) { searching = false; q = "" } else onBack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite)
                }
                if (searching) {
                    Row(
                        Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(50)).background(ChipLook.glass).border(1.dp, ChipLook.border, RoundedCornerShape(50)).padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.weight(1f)) {
                            if (q.isEmpty()) Text("Ad ara", color = ChipLook.fg.copy(alpha = 0.7f), fontSize = 16.sp)
                            AuraTextField(
                                value = q, onValueChange = { q = it }, singleLine = true,
                                textStyle = TextStyle(color = ChipLook.fg, fontSize = 16.sp),
                                cursorBrush = SolidColor(ChipLook.fg),
                                modifier = Modifier.fillMaxWidth().focusRequester(focus)
                            )
                        }
                        if (q.isNotEmpty()) Icon(Icons.Default.Close, "Temizle", tint = ChipLook.fg, modifier = Modifier.size(20.dp).clickable { q = "" })
                    }
                    Spacer(Modifier.width(8.dp))
                } else {
                    Text(
                        if (picked.isEmpty()) "Gönder…" else "${picked.size} kişi seçildi",
                        color = AuraWhite, fontSize = 22.sp, modifier = Modifier.weight(1f).padding(start = 8.dp)
                    )
                    IconButton(onClick = { searching = true }) { Icon(Icons.Default.Search, "Ara", tint = AuraWhite) }
                }
            }
            LazyColumn(Modifier.weight(1f)) {
                if (q.isBlank()) item(key = "mystatus") {
                    Row(Modifier.fillMaxWidth().clickable(onClick = onStatus).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp).softCircle(), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text("Durumum", color = AuraWhite, fontSize = 18.sp)
                            Text("24 saat görünür", color = AuraMuted, fontSize = 14.sp)
                        }
                    }
                }
                if (frequent.isNotEmpty()) {
                    item { ShareHeader("Sık görüşülenler") }
                    items(frequent, key = { "f" + it.chatId }) { t -> ShareRow(me, t, picked.any { it.chatId == t.chatId }, searching) { toggle(t) } }
                }
                if (rest.isNotEmpty()) {
                    item { ShareHeader(if (q.isBlank()) "Son sohbetler" else "Sohbetler") }
                    items(rest, key = { "r" + it.chatId }) { t -> ShareRow(me, t, picked.any { it.chatId == t.chatId }, searching) { toggle(t) } }
                }
                if (people.isNotEmpty()) {
                    item { ShareHeader("Kişiler") }
                    items(people, key = { "p" + it.chatId }) { t -> ShareRow(me, t, picked.any { it.chatId == t.chatId }, searching) { toggle(t) } }
                }
            }
            if (picked.isNotEmpty()) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).background(PanelBg).padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 8.dp)) {
                    val shareUrl = remember(text) { Regex("https?://[^\\s<>\"']+", RegexOption.IGNORE_CASE).find(text)?.value?.trimEnd('.', ',', ';', ':', '!', '?', ')', ']') }
                    if (uris.isEmpty() && text.isNotBlank()) {
                        var showCard by remember(text) { mutableStateOf(true) }
                        val lp by produceState<com.aurachat.app.data.LinkPreview?>(null, shareUrl) {
                            value = if (shareUrl != null) try { Repo.fetchLinkPreview(shareUrl) } catch (e: Throwable) { null } else null
                        }
                        val card = lp
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(PanelCard).padding(bottom = 10.dp)) {
                            if (card != null && showCard) {
                                Box(Modifier.fillMaxWidth().padding(10.dp)) {
                                    Row(Modifier.fillMaxWidth().height(androidx.compose.foundation.layout.IntrinsicSize.Min).clip(RoundedCornerShape(14.dp)).background(PanelInner)) {
                                        val bmp by produceState<android.graphics.Bitmap?>(LinkImgCache.peek(card.image), card.image) {
                                            if (value == null) value = LinkImgCache.load(ctx.applicationContext, card.image)
                                        }
                                        if (card.image.isBlank() && isOwnLink(card.url)) OwnLinkThumb(Modifier.width(84.dp).fillMaxHeight().heightIn(min = 84.dp))
                                        else Box(Modifier.width(84.dp).fillMaxHeight().heightIn(min = 84.dp).background(Color.Black)) {
                                            bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                                        }
                                        Column(Modifier.weight(1f).padding(start = 12.dp, end = 30.dp, top = 6.dp, bottom = 6.dp)) {
                                            if (card.title.isNotBlank()) Text(card.title, color = AuraWhite, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                            if (card.description.isNotBlank()) Text(card.description, color = AuraMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(try { android.net.Uri.parse(card.url).host?.removePrefix("www.") ?: "" } catch (e: Throwable) { "" }, color = AuraMuted, fontSize = 13.sp, maxLines = 1)
                                        }
                                    }
                                    Icon(Icons.Default.Close, "Kartı kaldır", tint = AuraMuted, modifier = Modifier.align(Alignment.TopEnd).padding(top = 6.dp, end = 6.dp).size(22.dp).clickable { showCard = false })
                                }
                            }
                            Text(text, color = AuraWhite, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp))
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    if (uris.isNotEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val thumb by produceState<android.graphics.Bitmap?>(null, uris.firstOrNull()) {
                                value = withContext(Dispatchers.IO) { uris.firstOrNull()?.let { shareThumb(ctx, it) } }
                            }
                            Box(Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)).background(auraLc(0xFF1B262D))) {
                                thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, colorFilter = auraImageFilter()) }
                                if (uris.size > 1) Text(
                                    "${uris.size}", color = AuraWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.align(Alignment.BottomEnd).padding(3.dp).clip(RoundedCornerShape(6.dp)).background(auraLc(0x99000000)).padding(horizontal = 5.dp)
                                )
                            }
                            Spacer(Modifier.width(10.dp))
                            Box(
                                Modifier.weight(1f).heightIn48().clip(RoundedCornerShape(50)).background(ChipLook.glass).border(1.dp, ChipLook.border, RoundedCornerShape(50)).padding(horizontal = 16.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                if (caption.isEmpty()) Text("Bir açıklama ekleyin", color = ChipLook.fg.copy(alpha = 0.7f), fontSize = 16.sp)
                                AuraTextField(
                                    value = caption, onValueChange = { caption = it }, maxLines = 3,
                                    textStyle = TextStyle(color = ChipLook.fg, fontSize = 16.sp),
                                    cursorBrush = SolidColor(ChipLook.fg), modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).padding(start = 4.dp)) {
                            Text(picked.joinToString(", ") { it.name }, color = AuraWhite, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Box(
                            Modifier.size(54.dp).clip(CircleShape).background(AuraBtn).clickable { onSend(picked, caption.trim()) },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.AutoMirrored.Filled.Send, "Gönder", tint = Color.White) }
                    }
                }
            }
        }
    }
}

private fun Modifier.heightIn48(): Modifier = this.height(48.dp)

@Composable
internal fun ShareHeader(t: String) {
    Text(t, color = AuraMuted, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 18.dp, top = 18.dp, bottom = 6.dp))
}

@Composable
internal fun ShareRow(me: UserProfile, t: ChatTarget, on: Boolean, circles: Boolean, onClick: () -> Unit) {
    val lp by liveProfile(if (t.isGroup) "" else t.otherUid)
    val gd by remember(t.chatId) { if (t.isGroup) Repo.groupFlow(t.chatId) else kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.GroupData?>(null) }
        .collectAsState(if (t.isGroup) Repo.peekGroup(t.chatId) else null)
    val avatar = if (t.isGroup) (gd?.photo ?: "") else (lp?.avatar ?: "")
    val nm = if (t.isGroup) (gd?.name?.takeIf { it.isNotBlank() } ?: t.name) else (lp?.name?.takeIf { it.isNotBlank() } ?: t.name)
    val memberNames by produceState(
        (gd?.members ?: emptyList()).filter { it != me.uid }.mapNotNull { Repo.peekProfile(it)?.name?.takeIf { n -> n.isNotBlank() } }.joinToString(", "),
        gd?.members
    ) {
        if (t.isGroup) value = (gd?.members ?: emptyList()).filter { it != me.uid }
            .mapNotNull { runCatching { Repo.profileOf(it).name }.getOrNull()?.takeIf { n -> n.isNotBlank() } }.joinToString(", ")
    }
    val sub = if (t.isGroup) memberNames else (lp?.about ?: "")
    Row(
        Modifier.fillMaxWidth().background(if (on) (AuraUi.accentColor()?.copy(alpha = if (AuraUi.light) 0.18f else 0.28f) ?: auraLc(0x4422C55E)) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            Avatar(nm.ifBlank { "?" }, avatar, 48.dp, isGroup = t.isGroup)
            SelTick(on && !circles)
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(nm.ifBlank { "Kullanıcı" }, color = AuraWhite, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotBlank()) Text(sub, color = AuraMuted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (circles) Box(
            Modifier.size(26.dp).clip(CircleShape).then(if (on) Modifier.background(AuraGreen) else Modifier.border(2.dp, auraLc(0xFF8696A0), CircleShape)),
            contentAlignment = Alignment.Center
        ) { if (on) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
    }
}


/** Mesaj iletme sayfası: "Gönder…" sayfasıyla aynı düzen (çoklu seçim, tikler, grup üyeleri / hakkımda satırı) */
@Composable
fun ForwardScreen(me: UserProfile, count: Int, title: String? = null, msgs: List<com.aurachat.app.data.Message> = emptyList(), onStatus: (() -> Unit)? = null, onBack: () -> Unit, onPick: (List<ChatTarget>) -> Unit) {
    val fctx = LocalContext.current
    val chats by remember(me.uid) { Repo.chatsFlow(me.uid) }.collectAsState(remember(me.uid) { Repo.cachedChats(me.uid) ?: emptyList<ChatSummary>() })
    val users by remember(me.uid) { Repo.usersFlow(me.uid) }.collectAsState(Repo.cachedUsers() ?: emptyList())
    var q by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var picked by remember { mutableStateOf<List<ChatTarget>>(emptyList()) }
    val focus = remember { FocusRequester() }
    BackHandler { if (searching) { searching = false; q = "" } else onBack() }
    LaunchedEffect(searching) { if (searching) try { focus.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ShareTargetScreen", e) } }

    val recent = visibleChats(chats).sortedByDescending { it.lastTime }
        .map { ChatTarget(it.chatId, it.isGroup, it.otherUid, if (it.otherUid == me.uid) "Sen" else it.name) }
    val ids = recent.map { it.chatId }.toSet()
    val others = users.filter { it.uid != me.uid && !ids.contains(Repo.chatId(me.uid, it.uid)) }
        .map { ChatTarget(Repo.chatId(me.uid, it.uid), false, it.uid, it.name) }
    fun f(l: List<ChatTarget>) = l.filter { q.isBlank() || it.name.contains(q, ignoreCase = true) }
    val frequent = if (q.isBlank()) recent.filter { !it.isGroup }.take(4) else emptyList()
    val freqIds = frequent.map { it.chatId }.toSet()
    val rest = if (q.isBlank()) recent.filter { !freqIds.contains(it.chatId) } else f(recent)
    val people = f(others)

    fun toggle(t: ChatTarget) {
        picked = if (picked.any { it.chatId == t.chatId }) picked.filter { it.chatId != t.chatId } else picked + t
    }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { if (searching) { searching = false; q = "" } else onBack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite)
                }
                if (searching) {
                    Row(
                        Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(50)).background(ChipLook.glass).border(1.dp, ChipLook.border, RoundedCornerShape(50)).padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.weight(1f)) {
                            if (q.isEmpty()) Text("Ad ara", color = ChipLook.fg.copy(alpha = 0.7f), fontSize = 16.sp)
                            AuraTextField(
                                value = q, onValueChange = { q = it }, singleLine = true,
                                textStyle = TextStyle(color = ChipLook.fg, fontSize = 16.sp),
                                cursorBrush = SolidColor(ChipLook.fg),
                                modifier = Modifier.fillMaxWidth().focusRequester(focus)
                            )
                        }
                        if (q.isNotEmpty()) Icon(Icons.Default.Close, "Temizle", tint = ChipLook.fg, modifier = Modifier.size(20.dp).clickable { q = "" })
                    }
                    Spacer(Modifier.width(8.dp))
                } else {
                    Column(Modifier.weight(1f).padding(start = 8.dp)) {
                        Text(title ?: if (count > 1) "$count mesajı ilet" else "Mesajı ilet", color = AuraWhite, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (picked.isNotEmpty()) Text("${picked.size} kişi seçildi", color = AuraMuted, fontSize = 14.sp)
                    }
                    IconButton(onClick = { searching = true }) { Icon(Icons.Default.Search, "Ara", tint = AuraWhite) }
                }
            }
            LazyColumn(Modifier.weight(1f)) {
                if (q.isBlank() && onStatus != null) item(key = "mystatus") {
                    Row(Modifier.fillMaxWidth().clickable(onClick = onStatus).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp).softCircle(), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text("Durumum", color = AuraWhite, fontSize = 18.sp)
                            Text("24 saat görünür", color = AuraMuted, fontSize = 14.sp)
                        }
                    }
                }
                if (frequent.isNotEmpty()) {
                    item { ShareHeader("Sık görüşülenler") }
                    items(frequent, key = { "f" + it.chatId }) { t -> ShareRow(me, t, picked.any { it.chatId == t.chatId }, true) { toggle(t) } }
                }
                if (rest.isNotEmpty()) {
                    item { ShareHeader(if (q.isBlank()) "Son sohbetler" else "Sohbetler") }
                    items(rest, key = { "r" + it.chatId }) { t -> ShareRow(me, t, picked.any { it.chatId == t.chatId }, true) { toggle(t) } }
                }
                if (people.isNotEmpty()) {
                    item { ShareHeader("Kişiler") }
                    items(people, key = { "p" + it.chatId }) { t -> ShareRow(me, t, picked.any { it.chatId == t.chatId }, true) { toggle(t) } }
                }
            }
            if (picked.isNotEmpty()) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).background(PanelBg).padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 8.dp)) {
                    val m0 = msgs.firstOrNull()
                    if (m0 != null) {
                        val lp = m0.linkPreview
                        val lbmp by produceState<android.graphics.Bitmap?>(if (lp != null) LinkImgCache.peek(lp.image) else null, lp?.image) {
                            if (value == null && lp != null && lp.image.isNotBlank()) value = LinkImgCache.load(fctx.applicationContext, lp.image)
                        }
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(PanelCard).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            val ownL = lp != null && lp.image.isBlank() && isOwnLink(lp.url)
                            val thumbBox = m0.thumb.isNotEmpty() || lbmp != null || ownL
                            if (ownL) {
                                OwnLinkThumb(Modifier.size(64.dp).clip(RoundedCornerShape(10.dp)))
                                Spacer(Modifier.width(12.dp))
                            } else if (thumbBox) {
                                Box(Modifier.size(64.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black)) {
                                    if (m0.thumb.isNotEmpty()) DataUrlImage(m0.thumb, 200, Modifier.fillMaxSize(), ContentScale.Crop)
                                    else lbmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                                }
                                Spacer(Modifier.width(12.dp))
                            }
                            Column(Modifier.weight(1f)) {
                                val title = lp?.title?.takeIf { it.isNotBlank() }
                                if (title != null) Text(title, color = AuraWhite, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    m0.text.ifBlank { Repo.previewOf(m0) }, color = if (title != null) AuraMuted else AuraWhite,
                                    fontSize = if (title != null) 13.sp else 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                                )
                                if (msgs.size > 1) Text("+${msgs.size - 1} mesaj daha", color = AuraMuted, fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            picked.joinToString(", ") { it.name }, color = AuraWhite, fontSize = 16.sp, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(start = 4.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Box(
                            Modifier.size(56.dp).clip(CircleShape).background(AuraBtn).clickable { onPick(picked) },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.AutoMirrored.Filled.Send, "İlet", tint = Color.White) }
                    }
                }
            }
        }
    }
}

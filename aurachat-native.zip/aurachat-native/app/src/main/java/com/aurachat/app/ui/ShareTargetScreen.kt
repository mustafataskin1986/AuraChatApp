package com.aurachat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.BackHandler
import com.aurachat.app.data.ChatSummary
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile

/** Başka uygulamadan "AuraChat ile paylaş" ile gelince açılan "Gönder…" sayfası (çoklu seçim) */
@Composable
fun ShareTargetScreen(me: UserProfile, summary: String, onBack: () -> Unit, onStatus: () -> Unit = {}, onSend: (List<ChatTarget>) -> Unit) {
    BackHandler { onBack() }
    val chats by remember(me.uid) { Repo.chatsFlow(me.uid) }.collectAsState(remember(me.uid) { Repo.cachedChats(me.uid) ?: emptyList<ChatSummary>() })
    val users by remember(me.uid) { Repo.usersFlow(me.uid) }.collectAsState(Repo.cachedUsers() ?: emptyList())
    var q by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var picked by remember { mutableStateOf<List<ChatTarget>>(emptyList()) }

    val recent = visibleChats(chats).sortedByDescending { it.lastTime }
        .map { ChatTarget(it.chatId, it.isGroup, it.otherUid, it.name) }
    val ids = recent.map { it.chatId }.toSet()
    val others = users.filter { it.uid != me.uid && !ids.contains(Repo.chatId(me.uid, it.uid)) }
        .map { ChatTarget(Repo.chatId(me.uid, it.uid), false, it.uid, it.name) }
    fun f(l: List<ChatTarget>) = l.filter { q.isBlank() || it.name.contains(q, ignoreCase = true) }
    val frequent = if (q.isBlank()) recent.take(4) else emptyList()
    val rest = if (q.isBlank()) recent.drop(4) else f(recent)
    val people = f(others)

    fun toggle(t: ChatTarget) {
        picked = if (picked.any { it.chatId == t.chatId }) picked.filter { it.chatId != t.chatId } else picked + t
    }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { if (searching) { searching = false; q = "" } else onBack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White)
                }
                if (searching) {
                    androidx.compose.foundation.text.BasicTextField(
                        value = q, onValueChange = { q = it }, singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 18.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(AuraGreen),
                        modifier = Modifier.weight(1f).padding(start = 8.dp)
                    )
                    if (q.isNotEmpty()) IconButton(onClick = { q = "" }) { Icon(Icons.Default.Close, null, tint = Color.White) }
                } else {
                    Text("Gönder…", color = Color.White, fontSize = 22.sp, modifier = Modifier.weight(1f).padding(start = 8.dp))
                    IconButton(onClick = { searching = true }) { Icon(Icons.Default.Search, "Ara", tint = Color.White) }
                }
            }
            LazyColumn(Modifier.weight(1f)) {
                if (q.isBlank()) item(key = "mystatus") {
                    Row(Modifier.fillMaxWidth().clickable(onClick = onStatus).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp).clip(CircleShape).background(AuraGreen), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text("Durumum", color = Color.White, fontSize = 18.sp)
                            Text("24 saat görünür", color = AuraMuted, fontSize = 14.sp)
                        }
                    }
                }
                if (frequent.isNotEmpty()) {
                    item { ShareHeader("Sık görüşülenler") }
                    items(frequent, key = { "f" + it.chatId }) { t -> ShareRow(t, picked.any { it.chatId == t.chatId }) { toggle(t) } }
                }
                if (rest.isNotEmpty()) {
                    item { ShareHeader(if (q.isBlank()) "Son sohbetler" else "Sohbetler") }
                    items(rest, key = { "r" + it.chatId }) { t -> ShareRow(t, picked.any { it.chatId == t.chatId }) { toggle(t) } }
                }
                if (people.isNotEmpty()) {
                    item { ShareHeader("Kişiler") }
                    items(people, key = { "p" + it.chatId }) { t -> ShareRow(t, picked.any { it.chatId == t.chatId }) { toggle(t) } }
                }
            }
            if (picked.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().background(AuraSurface).padding(start = 16.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(picked.joinToString(", ") { it.name }, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(summary, color = AuraMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Box(
                        Modifier.size(52.dp).clip(CircleShape).background(AuraBtn).clickable { onSend(picked) },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.AutoMirrored.Filled.Send, "Gönder", tint = Color.White) }
                }
            }
        }
    }
}

@Composable
private fun ShareHeader(t: String) {
    Text(t, color = AuraMuted, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 18.dp, top = 18.dp, bottom = 6.dp))
}

@Composable
private fun ShareRow(t: ChatTarget, on: Boolean, onClick: () -> Unit) {
    val lp by liveProfile(if (t.isGroup) "" else t.otherUid)
    val gd by remember(t.chatId) { if (t.isGroup) Repo.groupFlow(t.chatId) else kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.GroupData?>(null) }
        .collectAsState(if (t.isGroup) Repo.peekGroup(t.chatId) else null)
    val avatar = if (t.isGroup) (gd?.photo ?: "") else (lp?.avatar ?: "")
    val nm = if (t.isGroup) (gd?.name?.takeIf { it.isNotBlank() } ?: t.name) else (lp?.name?.takeIf { it.isNotBlank() } ?: t.name)
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box {
            Avatar(nm.ifBlank { "?" }, avatar, 48.dp, isGroup = t.isGroup)
            if (on) Box(
                Modifier.align(Alignment.BottomEnd).size(20.dp).clip(CircleShape).background(AuraGreen).border(2.dp, AuraBg, CircleShape),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(13.dp)) }
        }
        Spacer(Modifier.width(16.dp))
        Text(nm.ifBlank { "Kullanıcı" }, color = Color.White, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

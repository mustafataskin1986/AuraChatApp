package com.aurachat.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

/**
 * Hazır resimli duvar kağıtları: app/src/main/assets/wallpapers/<Kategori>/<sıra>_<ad>__<renk>.jpg
 * - Klasör adı kategori başlığı olur (baştaki "01_" sıra numarası gösterilmez)
 * - Dosya adındaki sıra numarası kart sırasını belirler
 * - "__" sonrasındaki renk adı (kirmizi, yesil, mavi, mor, turuncu, pembe, kahve, turkuaz, sari, lacivert)
 *   ya da 6 haneli renk kodu baloncuk rengi olur; yazılmazsa resmin baskın rengine en yakın renk seçilir
 * Tema kimliği: "w:<klasör>/<dosya>"
 */
object Wallpapers {
    class Item(val cat: String, val id: String, val outHex: String)

    private var app: Context? = null
    private var items: List<Item> = emptyList()
    private val thumbs = HashMap<String, ImageBitmap?>()
    private val fulls = object : android.util.LruCache<String, ImageBitmap>(3) {}

    private val named = mapOf(
        "kirmizi" to "9b153b", "yesil" to "126d47", "mavi" to "08529e", "mor" to "803399",
        "turuncu" to "a72917", "pembe" to "d82d63", "kahve" to "794b2a", "turkuaz" to "086b66",
        "sari" to "c5a300", "lacivert" to "092e5c"
    )

    fun init(ctx: Context) {
        app = ctx.applicationContext
        items = try { scan() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Wallpapers", e); emptyList() }
    }

    fun list(): List<Item> = items
    fun isWall(id: String) = id.startsWith("w:")

    private fun catTitle(folder: String) = folder.replace(Regex("^\\d+_"), "").replace('_', ' ')

    private fun scan(): List<Item> {
        val am = (app ?: return emptyList()).assets
        val out = ArrayList<Item>()
        (am.list("wallpapers") ?: emptyArray()).sorted().forEach { folder ->
            (am.list("wallpapers/$folder") ?: emptyArray())
                .filter { n -> n.lowercase().let { it.endsWith(".jpg") || it.endsWith(".jpeg") || it.endsWith(".png") || it.endsWith(".webp") } }
                .sorted().forEach { f ->
                    val id = "w:$folder/$f"
                    out.add(Item(catTitle(folder), id, outFor(id, f)))
                }
        }
        return out
    }

    private fun validOut(hex: String) = ChatThemes.bubbleColors.any { it.id == hex }

    private fun outFor(id: String, file: String): String {
        val base = file.substringBeforeLast('.')
        val tag = if (base.contains("__")) base.substringAfter("__").lowercase() else ""
        named[tag]?.let { return it }
        if (tag.length == 6 && tag.toLongOrNull(16) != null) {
            if (validOut(tag)) return tag
            return nearest(tag.toLong(16).toInt())
        }
        return nearest(dominant(id))
    }

    /** Resmin, doygunluğa göre ağırlıklı ortalama rengi (RGB) */
    private fun dominant(id: String): Int {
        val b = decode(id, 48) ?: return 0x126d47
        var r = 0.0; var g = 0.0; var bl = 0.0; var wsum = 0.0
        val px = IntArray(b.width * b.height)
        b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
        for (p in px) {
            val rr = (p shr 16) and 255; val gg = (p shr 8) and 255; val bb = p and 255
            val mx = maxOf(rr, gg, bb); val mn = minOf(rr, gg, bb)
            val w = 0.15 + (mx - mn) / 255.0
            r += rr * w; g += gg * w; bl += bb * w; wsum += w
        }
        if (wsum == 0.0) return 0x126d47
        return ((r / wsum).toInt() shl 16) or ((g / wsum).toInt() shl 8) or (bl / wsum).toInt()
    }

    private fun nearest(rgb: Int): String {
        val r = (rgb shr 16) and 255; val g = (rgb shr 8) and 255; val b = rgb and 255
        var best = "126d47"; var bd = Long.MAX_VALUE
        for (bc in ChatThemes.bubbleColors) {
            if (bc.id == "default" || bc.id.length != 6) continue
            val v = bc.id.toLongOrNull(16)?.toInt() ?: continue
            val dr = ((v shr 16) and 255) - r; val dg = ((v shr 8) and 255) - g; val db = (v and 255) - b
            val d = (dr * dr + dg * dg + db * db).toLong()
            if (d < bd) { bd = d; best = bc.id }
        }
        return best
    }

    private fun decode(id: String, minWidth: Int): Bitmap? {
        val ctx = app ?: return null
        val path = "wallpapers/" + id.removePrefix("w:")
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.assets.open(path).use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / (s * 2) >= minWidth) s *= 2
            ctx.assets.open(path).use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Wallpapers", e, id); null }
    }

    @Synchronized
    fun thumb(id: String): ImageBitmap? {
        if (thumbs.containsKey(id)) return thumbs[id]
        val b = decode(id, 360)?.asImageBitmap()
        thumbs[id] = b
        return b
    }

    @Synchronized
    fun full(id: String): ImageBitmap? {
        fulls.get(id)?.let { return it }
        val b = decode(id, 1080)?.asImageBitmap() ?: return null
        fulls.put(id, b)
        return b
    }
}

package com.aurachat.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.ChatSummary
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(
    me: UserProfile,
    onOpen: (ChatSummary) -> Unit,
    onNewChat: () -> Unit,
    onSignOut: () -> Unit
) {
    val chats by remember(me.uid) { Repo.chatsFlow(me.uid) }.collectAsState(emptyList())
    val visible = chats
        .filter { Repo.isDirect(it.chatId) && !it.archived && it.otherUid.isNotEmpty() }
        .sortedWith(compareByDescending<ChatSummary> { it.pinned }.thenByDescending { it.lastTime })
    var menu by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = AuraBg,
        topBar = {
            TopAppBar(
                title = { Text("AuraChat", color = AuraGreen) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AuraSurface),
                actions = {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Çıkış yap") }, onClick = { menu = false; onSignOut() })
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onNewChat, containerColor = AuraGreen, contentColor = Color.Black) {
                Icon(Icons.Default.Add, "Yeni sohbet")
            }
        }
    ) { pad ->
        if (visible.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                Text("Henüz sohbet yok. + ile başla.", color = AuraMuted)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(pad)) {
                items(visible, key = { it.chatId }) { c -> ChatRow(me, c) { onOpen(c) } }
            }
        }
    }
}

@Composable
private fun ChatRow(me: UserProfile, c: ChatSummary, onClick: () -> Unit) {
    val avatar by produceState("", c.otherUid) { value = Repo.avatarOf(c.otherUid) }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(c.otherName, avatar, 52.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(c.otherName, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val preview = when {
                c.typing -> "yazıyor..."
                c.lastSenderUid == me.uid -> (if (c.lastRead) "✓✓ " else "✓ ") + c.lastMessage
                else -> c.lastMessage
            }
            Text(
                preview, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (c.typing) AuraGreen else AuraMuted
            )
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(formatListTime(c.lastTime), fontSize = 12.sp, color = if (c.unread > 0) AuraGreen else AuraMuted)
            if (c.unread > 0) {
                Box(
                    Modifier.size(22.dp).clip(CircleShape).background(AuraGreen),
                    contentAlignment = Alignment.Center
                ) { Text(c.unread.toString(), color = Color.Black, fontSize = 12.sp) }
            } else Spacer(Modifier.size(22.dp))
        }
    }
}

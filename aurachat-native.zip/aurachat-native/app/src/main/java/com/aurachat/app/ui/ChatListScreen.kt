package com.aurachat.app.ui

import androidx.compose.ui.input.nestedscroll.nestedScroll
import com.aurachat.app.AppState
import androidx.compose.material.icons.filled.Check
import androidx.compose.foundation.layout.offset
import androidx.compose.material.icons.filled.Info
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Chat
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Unarchive
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.ui.graphics.toArgb
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.DonutLarge
import androidx.compose.material.icons.filled.People
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.launch
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.animateFloat
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.ChatSummary
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile

/** Silinmiş (clearedAt sonrası mesajı olmayan) sohbetleri gizler */
fun visibleChats(list: List<ChatSummary>): List<ChatSummary> =
    list.filter { c ->
        (c.isGroup || c.otherUid.isNotEmpty()) &&
            (c.keepRow || c.clearedAt <= 0L || c.lastTime > c.clearedAt)
    }

@OptIn(ExperimentalFoundationApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(
    me: UserProfile,
    onOpen: (ChatSummary) -> Unit,
    onNewChat: () -> Unit,
    onNewGroup: () -> Unit,
    onStarred: () -> Unit,
    onSettings: () -> Unit,
    onSignOut: () -> Unit,
    tabIsActive: Boolean = true,
    onAdmin: () -> Unit = {},
    onInfo: (ChatSummary) -> Unit = {},
    onCall: (ChatSummary, Boolean) -> Unit = { _, _ -> },
    onOpenMsg: (ChatSummary, String) -> Unit = { _, _ -> },
    onForwardMsg: (ChatSummary, com.aurachat.app.data.Message) -> Unit = { _, _ -> },
    onEditedImg: (ChatSummary, String) -> Unit = { _, _ -> }
) {
    var sheetChat by remember { mutableStateOf<ChatSummary?>(null) }
    var statusOf by remember { mutableStateOf<String?>(null) }
    statusOf?.let { su -> UserStatusViewer(
        me, su, onMessage = { statusOf = null }, onClose = { statusOf = null },
        actions = StatusMenuActions(
            onCall = { t, v -> statusOf = null; onCall(statusTargetSummary(t), v) },
            onProfile = { t -> statusOf = null; onInfo(statusTargetSummary(t)) }
        )
    ) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val chats by remember(me.uid) { Repo.chatsFlow(me.uid) }.collectAsState(remember(me.uid) { Repo.cachedChats(me.uid) })
    androidx.compose.runtime.LaunchedEffect(chats != null) {
        if (chats != null) com.aurachat.app.AppState.ready = true
    }
    val manualUnread = ManualUnread.all(ctx)
    var filter by remember { mutableStateOf("all") }
    val resume = remember { AppState.searchResume.also { AppState.searchResume = null } }
    var resumeResults by remember { mutableStateOf(resume != null) }
    var query by remember { mutableStateOf(resume?.first ?: "") }
    var menu by remember { mutableStateOf(false) }
    // arama kutusu: büyüteçle aç/kapa, durumu hatırlanır (açılışta son hâliyle gelir; ilk kurulumda açık)
    var searching by remember { mutableStateOf(ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).getBoolean("list_search", true)) }
    var focusSearch by remember { mutableStateOf(false) }
    var searchFocused by remember { mutableStateOf(false) }
    var typeFilter by remember { mutableStateOf<String?>(resume?.second) }
    val recentPrefs = ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE)
    var recents by remember { mutableStateOf((recentPrefs.getString("recent_search", "") ?: "").split(",").filter { it.isNotBlank() }) }
    fun addRecent(id: String) {
        recents = (listOf(id) + recents.filter { it != id }).take(12)
        recentPrefs.edit().putString("recent_search", recents.joinToString(",")).apply()
    }
    val focusMgr = androidx.compose.ui.platform.LocalFocusManager.current
    val kbc = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    var themeDlg by remember { mutableStateOf(false) }
    val focusReq = remember { androidx.compose.ui.focus.FocusRequester() }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    val tabActive = tabIsActive
    androidx.compose.runtime.LaunchedEffect(tabActive) { if (!tabActive) selected = emptySet() }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmWipe by remember { mutableStateOf(false) }
    var errDlg by remember { mutableStateOf(false) }
    if (errDlg) ErrorLogDialog { errDlg = false }
    var muteDlg by remember { mutableStateOf(false) }

    sheetChat?.let { sc ->
        val lp by remember(sc.chatId) { if (sc.isGroup) kotlinx.coroutines.flow.flowOf<UserProfile?>(null) else Repo.profileFlow(sc.otherUid) }.collectAsState(if (sc.isGroup) null else Repo.peekProfile(sc.otherUid))
        val gd by remember(sc.chatId) { if (sc.isGroup) Repo.groupFlow(sc.chatId) else kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.GroupData?>(null) }.collectAsState(if (sc.isGroup) Repo.peekGroup(sc.chatId) else null)
        val nm = if (sc.isGroup) (gd?.name?.takeIf { it.isNotBlank() } ?: sc.name) else (lp?.name?.takeIf { it.isNotBlank() } ?: sc.name)
        val av = if (sc.isGroup) (gd?.photo ?: "") else (lp?.avatar ?: "")
        AvatarPeekDialog(nm, av, sc.isGroup, onDismiss = { sheetChat = null }) { act ->
            sheetChat = null
            when (act) { 0 -> onOpen(sc); 1 -> onCall(sc, false); 2 -> onCall(sc, true); else -> onInfo(sc) }
        }
    }
    val all = visibleChats(chats ?: emptyList())
    val shareCtx = androidx.compose.ui.platform.LocalContext.current.applicationContext
    androidx.compose.runtime.LaunchedEffect(all.take(6).map { it.chatId + it.name }) {
        val top = all.sortedByDescending { it.lastTime }.take(6)
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            top.forEach { com.aurachat.app.push.Notifs.publishShareShortcut(shareCtx, it.chatId, it.isGroup, it.otherUid, it.name) }
        }
    }
    val statuses by remember { Repo.statusesFlow() }.collectAsState(emptyList<com.aurachat.app.data.StatusItem>())
    val ringOf = remember(statuses, me.uid) {
        val now = System.currentTimeMillis()
        val m = HashMap<String, Int>()
        statuses.filter { it.expiresAt > now }.groupBy { it.uid }.forEach { (uid, l) ->
            m[uid] = if (l.any { !it.viewers.contains(me.uid) }) 1 else 2
        }
        m
    }
    val liveNames = remember { androidx.compose.runtime.mutableStateMapOf<String, String>() }
    val directUids = all.filter { !it.isGroup && it.otherUid.isNotEmpty() }.map { it.otherUid }.toSet()
    androidx.compose.runtime.LaunchedEffect(directUids) {
        directUids.forEach { u ->
            launch { Repo.profileFlow(u).collect { p -> if (p != null && p.name.isNotBlank()) liveNames[u] = p.name } }
        }
    }
    // Bildirim izni / ayarı kapalı mı (ekrana dönünce yeniden kontrol edilir)
    var notifOn by remember { mutableStateOf(androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled()) }
    val lifeOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifeOwner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                notifOn = androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled()
            }
        }
        lifeOwner.lifecycle.addObserver(obs)
        onDispose { lifeOwner.lifecycle.removeObserver(obs) }
    }
    var archiveOpen by remember { mutableStateOf(false) }
    var lockedOpen by remember { mutableStateOf(false) }
    val lockedIds = ChatLock.all(ctx)
    val deviceAuth = rememberDeviceAuth()
    run {
        val keep = ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).getBoolean("arch_keep", false)
        if (!keep) androidx.compose.runtime.LaunchedEffect(all.map { it.chatId + it.lastTime + it.archivedChat }) {
            all.filter { it.archivedChat && it.archivedAt > 0L && it.lastTime > it.archivedAt + 2000L && it.lastSenderUid != me.uid }
                .forEach { Repo.setChatArchived(me.uid, it.chatId, false) }
        }
    }
    val archivedAll = all.filter { it.archivedChat && !lockedIds.contains(it.chatId) }
    val lockedAll = all.filter { lockedIds.contains(it.chatId) }
    val shown = all
        .filter { if (lockedOpen) lockedIds.contains(it.chatId) else if (lockedIds.contains(it.chatId)) false else if (archiveOpen) it.archivedChat else !it.archivedChat }
        .filter {
            when (filter) {
                "unread" -> it.unread > 0 || manualUnread.contains(it.chatId)
                "fav" -> it.favorite
                "groups" -> it.isGroup
                else -> true
            }
        }
        .filter { query.isBlank() || (liveNames[it.otherUid] ?: it.name).contains(query, ignoreCase = true) || it.name.contains(query, ignoreCase = true) }
        .sortedWith(compareByDescending<ChatSummary> { it.pinned }.thenByDescending { Drafts.preview(it.chatId).isNotEmpty() }.thenByDescending { it.lastTime })

    val resultsMode = searching && !archiveOpen && !lockedOpen && (searchFocused || query.isNotBlank() || typeFilter != null || resumeResults)

    @androidx.compose.runtime.Composable
    fun ChipsRow() {
        val chipScroll = androidx.compose.foundation.rememberScrollState()
        val edgeHold = remember {
            object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
                var active = false
                override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
                    if (!active && source == androidx.compose.ui.input.nestedscroll.NestedScrollSource.UserInput) {
                        if ((available.x < 0 && chipScroll.canScrollForward) || (available.x > 0 && chipScroll.canScrollBackward)) active = true
                    }
                    return androidx.compose.ui.geometry.Offset.Zero
                }
                override fun onPostScroll(consumed: androidx.compose.ui.geometry.Offset, available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset =
                    if (active) androidx.compose.ui.geometry.Offset(available.x, 0f) else androidx.compose.ui.geometry.Offset.Zero
                override suspend fun onPostFling(consumed: androidx.compose.ui.unit.Velocity, available: androidx.compose.ui.unit.Velocity): androidx.compose.ui.unit.Velocity {
                    val r = if (active) androidx.compose.ui.unit.Velocity(available.x, 0f) else androidx.compose.ui.unit.Velocity.Zero
                    active = false
                    return r
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().nestedScroll(edgeHold).horizontalScroll(chipScroll)
                .padding(horizontal = 13.dp).padding(top = if (searching && !archiveOpen) 12.dp else 8.dp, bottom = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            fun un(c: ChatSummary) = if (c.lastSenderUid != me.uid && c.unread > 0) 1 else 0
            val unreadTotal = all.filter { !it.archivedChat && !lockedIds.contains(it.chatId) }.sumOf { if (un(it) == 0 && manualUnread.contains(it.chatId)) 1 else un(it) }
            val favTotal = all.filter { it.favorite && !it.archivedChat && !lockedIds.contains(it.chatId) }.sumOf { un(it) }
            val grpTotal = all.filter { it.isGroup && !it.archivedChat && !lockedIds.contains(it.chatId) }.sumOf { un(it) }
            fun lbl(t: String, n: Int) = if (n > 0) "$t $n" else t
            listOf(
                "all" to "Tümü",
                "unread" to lbl("Okunmamış", unreadTotal),
                "fav" to lbl("Favoriler", favTotal),
                "groups" to lbl("Gruplar", grpTotal)
            ).forEach { (k, label) ->
                val on = filter == k
                val lt = AuraUi.light
                val acc = AuraUi.accentColor()
                val chipBg = if (on) (if (acc != null) acc.copy(alpha = if (lt) 0.16f else 0.24f) else if (lt) Color(0xFFD9FDD3) else Color(0xFF103629)) else Color.Transparent
                val chipFg = if (on) (if (acc != null) (if (lt) androidx.compose.ui.graphics.lerp(acc, Color.Black, 0.25f) else androidx.compose.ui.graphics.lerp(acc, Color.White, 0.45f)) else if (lt) Color(0xFF0B6B4D) else Color(0xFF25D366)) else (if (lt) Color(0xFF3B4A54) else Color(0xFFA7ADB2))
                val chipBorder = if (lt) (if (on) (acc?.copy(alpha = 0.4f) ?: Color(0xFFA9E5A0)) else Color(0xFFE0E0E0)) else (if (on) (acc?.copy(alpha = 0.55f) ?: Color(0xFF14503B)) else Color(0xFF2C2C2C))
                Text(
                    label,
                    color = chipFg,
                    fontSize = 15.sp,
                    lineHeight = 20.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.clip(RoundedCornerShape(50))
                        .background(chipBg)
                        .border(1.dp, chipBorder, RoundedCornerShape(50))
                        .combinedClickable(onClick = { filter = k })
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }
        }
    }

    BackHandler(enabled = archiveOpen && selected.isEmpty()) { archiveOpen = false }
    BackHandler(enabled = lockedOpen && selected.isEmpty()) { lockedOpen = false }
    BackHandler(enabled = selected.isNotEmpty()) { selected = emptySet() }
    BackHandler(enabled = searching && (query.isNotEmpty() || searchFocused || typeFilter != null || resumeResults) && selected.isEmpty()) { if (typeFilter != null) typeFilter = null else { query = ""; resumeResults = false; focusMgr.clearFocus() } }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize()) {
            // Üst çubuk (seçim modunda çubuk ve durum çubuğu WhatsApp gibi renk değiştirir)
            val selBar = AuraSelBar
            Box(Modifier.fillMaxWidth().background(if (selected.isNotEmpty()) selBar else AuraBg).statusBarsPadding()) {
            if (!(resultsMode && selected.isEmpty())) Row(
                Modifier.fillMaxWidth().height(60.dp).background(if (selected.isNotEmpty()) selBar else AuraBlack).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (selected.isNotEmpty()) {
                    IconButton(onClick = { selected = emptySet() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "İptal", tint = AuraWhite) }
                    Text("${selected.size}", color = AuraWhite, fontSize = 20.sp, modifier = Modifier.weight(1f))
                    val sel = all.filter { selected.contains(it.chatId) }
                    val allPinned = sel.isNotEmpty() && sel.all { it.pinned }
                    val allFav = sel.isNotEmpty() && sel.all { it.favorite }
                    IconButton(onClick = {
                        sel.forEach { Repo.setPinned(me.uid, it.chatId, !allPinned) }
                        selected = emptySet()
                    }) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.PushPin, if (allPinned) "Sabitlemeyi kaldır" else "Sabitle", tint = AuraWhite)
                            if (allPinned) {
                                androidx.compose.foundation.Canvas(Modifier.size(24.dp)) {
                                    drawLine(AuraBlack, androidx.compose.ui.geometry.Offset(size.width * 0.16f, size.height * 0.22f + 2.5f), androidx.compose.ui.geometry.Offset(size.width * 0.84f, size.height * 0.80f + 2.5f), strokeWidth = 5f)
                                    drawLine(AuraWhite, androidx.compose.ui.geometry.Offset(size.width * 0.16f, size.height * 0.22f), androidx.compose.ui.geometry.Offset(size.width * 0.84f, size.height * 0.80f), strokeWidth = 3f)
                                }
                            }
                        }
                    }
                    val allMuted = sel.isNotEmpty() && sel.all { it.muted }
                    val allArch = sel.isNotEmpty() && sel.all { it.archivedChat }
                    IconButton(onClick = {
                        if (allMuted) { sel.forEach { Repo.setMuted(me.uid, it.chatId, false) }; selected = emptySet() }
                        else muteDlg = true
                    }) { Icon(if (allMuted) Icons.Default.Notifications else Icons.Default.NotificationsOff, if (allMuted) "Sesi aç" else "Sessize al", tint = AuraWhite) }
                    IconButton(onClick = {
                        sel.forEach { Repo.setChatArchived(me.uid, it.chatId, !allArch) }
                        selected = emptySet()
                    }) { Icon(if (allArch) Icons.Default.Unarchive else Icons.Default.Archive, if (allArch) "Arşivden çıkar" else "Arşivle", tint = AuraWhite) }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, "Sil", tint = AuraWhite) }
                    Box {
                        var selMenu by remember { mutableStateOf(false) }
                        IconButton(onClick = { selMenu = true }) { Icon(Icons.Default.MoreVert, "Daha fazla", tint = AuraWhite) }
                        AuraDropdownMenu(
                            expanded = selMenu, onDismissRequest = { selMenu = false },
                            shape = RoundedCornerShape(16.dp), containerColor = AuraSurface, selecting = true
                        ) {
                            @Composable
                            fun Item(label: String, onClick: () -> Unit) {
                                DropdownMenuItem(text = { Text(label, color = AuraWhite, fontSize = 16.sp) }, onClick = { selMenu = false; onClick() })
                            }
                            if (sel.size == 1) Item("Sohbet kısayolu ekle") {
                                val c0 = sel[0]
                                val nm0 = liveNames[c0.otherUid] ?: c0.name
                                val ok = com.aurachat.app.push.Notifs.pinChatShortcut(ctx, c0.chatId, c0.isGroup, c0.otherUid, nm0)
                                toast(ctx, if (ok) "Kısayol ekleniyor" else "Bu cihaz kısayol eklemeyi desteklemiyor")
                                selected = emptySet()
                            }
                            if (sel.size == 1) Item(if (sel[0].isGroup) "Grubu görüntüle" else "Kişiyi görüntüle") {
                                val c0 = sel[0]; selected = emptySet(); onInfo(c0)
                            }
                            val allLocked = sel.isNotEmpty() && sel.all { lockedIds.contains(it.chatId) }
                            Item(if (allLocked) "Sohbet kilidini kaldır" else "Sohbeti kilitle") {
                                if (allLocked) { ChatLock.unlock(ctx, sel.map { it.chatId }); toast(ctx, "Kilit kaldırıldı") }
                                else if (!ChatLock.canLock(ctx)) toast(ctx, "Önce telefona ekran kilidi (PIN, desen veya parmak izi) ayarla")
                                else { ChatLock.lock(ctx, sel.map { it.chatId }); toast(ctx, "Sohbet kilitlendi. Listenin başındaki \"Kilitli sohbetler\"den açabilirsin") }
                                selected = emptySet()
                            }
                            Item("Okunmadı olarak işaretle") {
                                ManualUnread.add(ctx, sel.map { it.chatId }); selected = emptySet()
                            }
                            Item("Tümünü seç") { selected = shown.map { it.chatId }.toSet() }
                            Item(if (allFav) "Favoriler'den kaldır" else "Favorilere ekle") {
                                sel.forEach { Repo.setFavorite(me.uid, it.chatId, !allFav) }; selected = emptySet()
                            }
                            Item("Sohbeti temizle") { confirmWipe = true }
                            if (sel.size == 1 && !sel[0].isGroup) Item("Engelle") {
                                val c0 = sel[0]; selected = emptySet()
                                Repo.setBlocked(me.uid, c0.otherUid, true)
                                toast(ctx, "Kişi engellendi")
                            }
                        }
                    }
                } else {
                    if (lockedOpen) {
                        IconButton(onClick = { lockedOpen = false }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                        Text("Kilitli sohbetler", color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    } else if (archiveOpen) {
                        IconButton(onClick = { archiveOpen = false }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                        Text("Arşivlenenler", color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    } else
                    Row(Modifier.weight(1f).padding(start = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        val base = if (!AuraUi.light && AuraUi.accentColor() == null) AuraWhite else AuraGreen
                        val inf = androidx.compose.animation.core.rememberInfiniteTransition(label = "shimmer")
                        val ph by inf.animateFloat(
                            0f, 1f,
                            androidx.compose.animation.core.infiniteRepeatable(
                                androidx.compose.animation.core.tween(28000, easing = androidx.compose.animation.core.LinearEasing)
                            ), label = "ph"
                        )
                        val wPx = with(androidx.compose.ui.platform.LocalDensity.current) { 110.dp.toPx() }
                        val x0 = -wPx * 0.6f + ph * wPx * 2.2f
                        val brush = androidx.compose.ui.graphics.Brush.linearGradient(
                            colors = listOf(base, androidx.compose.ui.graphics.lerp(base, Color.White, 0.4f), base),
                            start = androidx.compose.ui.geometry.Offset(x0, 0f),
                            end = androidx.compose.ui.geometry.Offset(x0 + wPx * 0.9f, 0f),
                            tileMode = androidx.compose.ui.graphics.TileMode.Clamp
                        )
                        Box(Modifier.clip(RoundedCornerShape(8.dp)).clickable { themeDlg = true }.padding(horizontal = 4.dp, vertical = 6.dp)) {
                            val tsty = androidx.compose.ui.text.TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.3).sp, fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif)
                            Text("AuraChat", style = tsty.copy(brush = brush))
                            // gövdeyi kalınlaştıran ince kontur
                            Text("AuraChat", style = tsty.copy(brush = brush, drawStyle = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.6f, join = androidx.compose.ui.graphics.StrokeJoin.Round)))
                        }
                        UpdateChip()
                        if (themeDlg) {
                            AppThemePanel { themeDlg = false }
                        }
                    }
                    IconButton(onClick = {
                        searching = !searching
                        if (searching) focusSearch = true else query = ""
                        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putBoolean("list_search", searching).apply()
                    }, modifier = Modifier.offset(x = 8.dp)) { Icon(Icons.Default.Search, "Ara", tint = AuraWhite) }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = AuraWhite) }
                        AuraDropdownMenu(
                            expanded = menu, onDismissRequest = { menu = false },
                            shape = RoundedCornerShape(16.dp), containerColor = AuraSurface
                        ) {
                            @Composable
                            fun MenuRow(label: String, textColor: Color = AuraWhite, onClick: () -> Unit) {
                                DropdownMenuItem(
                                    text = { Text(label, color = textColor, fontSize = 17.sp) },
                                    onClick = { menu = false; onClick() },
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            }
                            MenuRow("Grup oluştur") { onNewGroup() }
                            if (remember { isAdminAccount() }) MenuRow("Yönetici paneli") { onAdmin() }
                            MenuRow("Yıldızlı mesajlar") { onStarred() }
                            MenuRow("Uygulama teması") { themeDlg = true }
                            MenuRow("Ayarlar") { onSettings() }
                            if (remember { isAdminAccount() }) MenuRow("Hata kayıtları") { errDlg = true }
                            MenuRow("Çıkış yap", auraLc(0xFFFB7185)) { onSignOut() }
                        }
                    }
                }
            }
            }

            // Arama kutusu (WhatsApp ölçülerinde): büyüteç simgesiyle açılıp kapanır, durumu kayıtlıdır
            AnimatedVisibility(visible = searching && !archiveOpen, enter = expandVertically(), exit = shrinkVertically()) {
                Row(Modifier.fillMaxWidth().background(AuraBg).padding(start = 13.dp, end = 13.dp, top = 1.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier.weight(1f).height(49.dp).clip(RoundedCornerShape(50)).background(ChipLook.bg).border(1.dp, ChipLook.border, RoundedCornerShape(50)).padding(start = 16.dp, end = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (resultsMode) Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = ChipLook.fg, modifier = Modifier.size(24.dp).clip(CircleShape).clickable { if (typeFilter != null) typeFilter = null else { query = ""; resumeResults = false; focusMgr.clearFocus() } })
                        else Icon(Icons.Default.Search, null, tint = ChipLook.fg, modifier = Modifier.size(24.dp))
                        typeFilter?.let { tf ->
                            Text(
                                searchTypeLabel(tf), color = if (AuraUi.light) Color.White else Color(0xFF0B141A), fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false,
                                modifier = Modifier.padding(start = 12.dp).clip(RoundedCornerShape(50)).background(ChipLook.fg).padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }
                        Box(Modifier.weight(1f).padding(start = if (typeFilter != null) 10.dp else 14.dp)) {
                            if (query.isEmpty()) Text("Ara", color = ChipLook.fg.copy(alpha = 0.7f), fontSize = 17.sp)
                            AuraTextField(
                                value = query, onValueChange = { query = it }, singleLine = true,
                                textStyle = TextStyle(color = ChipLook.fg, fontSize = 17.sp),
                                cursorBrush = SolidColor(ChipLook.fg),
                                modifier = Modifier.fillMaxWidth().focusRequester(focusReq).onFocusChanged { searchFocused = it.isFocused }
                            )
                        }
                        if (query.isNotEmpty()) {
                            Icon(Icons.Default.Close, "Temizle", tint = ChipLook.fg, modifier = Modifier.size(20.dp).combinedClickable(onClick = { query = "" }))
                        }
                    }
                }
            }
            androidx.compose.runtime.LaunchedEffect(focusSearch, searching) {
                if (focusSearch && searching) {
                    kotlinx.coroutines.delay(120)
                    try { focusReq.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatListScreen", e) }
                    focusSearch = false
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                val listSt = androidx.compose.foundation.lazy.rememberLazyListState(ChatListPos.index, ChatListPos.offset)
                LaunchedEffect(Unit) {
                    snapshotFlow { listSt.firstVisibleItemIndex to listSt.firstVisibleItemScrollOffset }.collect { ChatListPos.index = it.first; ChatListPos.offset = it.second }
                }
                LazyColumn(Modifier.fillMaxSize(), state = listSt) {
                    if (!notifOn) {
                        item(key = "notifwarn") {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)
                                    .clip(RoundedCornerShape(14.dp)).background(auraLc(0xFF3B2A12)).padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Bildirimler kapalı. Mesajları anında almak için aç.", color = auraLc(0xFFFCD34D), fontSize = 13.sp, modifier = Modifier.weight(1f))
                                Text(
                                    "Aç", color = AuraWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(start = 10.dp).clip(RoundedCornerShape(50)).background(AuraBtn)
                                        .clickable {
                                            try {
                                                ctx.startActivity(
                                                    android.content.Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                                        .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                                                )
                                            } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatListScreen", e) }
                                        }
                                        .padding(horizontal = 16.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }
                    item(key = "warn") { SystemWarnings() }
                    item(key = "chips") { ChipsRow() }
                    if (!archiveOpen && !lockedOpen && lockedAll.isNotEmpty() && filter == "all" && query.isBlank()) {
                        item(key = "lockedRow") {
                            val lu = lockedAll.sumOf { if (it.lastSenderUid == me.uid) 0 else it.unread }
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    deviceAuth("Kilitli sohbetlere erişmek için kimliğini doğrula", { lockedOpen = true }, {})
                                }.padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) { Icon(Icons.Default.Lock, null, tint = AuraMuted, modifier = Modifier.size(22.dp)) }
                                Spacer(Modifier.width(20.dp))
                                Text("Kilitli sohbetler", color = AuraWhite, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                                Text(if (lu > 0) lu.toString() else lockedAll.size.toString(), color = if (lu > 0) AuraGreen else AuraMuted, fontSize = 13.sp)
                            }
                        }
                    }
                    if (!archiveOpen && !lockedOpen && archivedAll.isNotEmpty() && filter == "all" && query.isBlank()) {
                        item(key = "archiveRow") {
                            val au = archivedAll.sumOf { if (it.lastSenderUid == me.uid) 0 else it.unread }
                            Row(
                                Modifier.fillMaxWidth().clickable { archiveOpen = true }.padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) { Icon(Icons.Default.Archive, null, tint = AuraMuted, modifier = Modifier.size(22.dp)) }
                                Spacer(Modifier.width(20.dp))
                                Text("Arşivlenenler", color = AuraWhite, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                                Text(if (au > 0) au.toString() else archivedAll.size.toString(), color = if (au > 0) AuraGreen else AuraMuted, fontSize = 13.sp)
                            }
                        }
                    }
                    if (chats == null) {
                        // boş: önbellek/ilk anlık görüntü bekleniyor
                    } else if (shown.isEmpty()) {
                        item(key = "empty") {
                            Box(Modifier.fillMaxWidth().padding(top = 80.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    if (all.isEmpty()) "Henüz sohbet yok. + ile başla." else "Sonuç yok",
                                    color = AuraMuted
                                )
                            }
                        }
                    } else {
                        items(shown, key = { it.chatId }) { c ->
                            ChatRow(
                                me = me, c = c, selected = selected.contains(c.chatId), manualUnread = manualUnread.contains(c.chatId),
                                ring = if (c.isGroup) 0 else (ringOf[c.otherUid] ?: 0),
                                onClick = {
                                    if (selected.isNotEmpty()) {
                                        selected = if (selected.contains(c.chatId)) selected - c.chatId else selected + c.chatId
                                    } else { ManualUnread.remove(ctx, c.chatId); onOpen(c) }
                                },
                                onLongClick = {
                                    selected = if (selected.contains(c.chatId)) selected - c.chatId else selected + c.chatId
                                },
                                onAvatarClick = {
                                    if (selected.isEmpty()) {
                                        if (!c.isGroup && (ringOf[c.otherUid] ?: 0) != 0) statusOf = c.otherUid else sheetChat = c
                                    }
                                }
                            )
                        }
                    }
                }
                FloatingActionButton(
                    onClick = onNewChat,
                    containerColor = (AuraUi.accentColor() ?: if (AuraUi.light) Color(0xFF1B6B49) else Color(0xFF25D366)), contentColor = if (AuraUi.light || AuraUi.accentColor() != null) Color(0xFFFFFFFF) else Color(0xFF0B141A),
                    modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
                ) { Icon(Icons.Default.Add, "Yeni sohbet") }
                if (resultsMode) Box(Modifier.fillMaxSize().background(AuraBg)) {
                    SearchResultsPane(
                        me = me, query = query, chats = all.filter { !lockedIds.contains(it.chatId) }, liveNames = liveNames,
                        onOpen = { c -> addRecent(c.chatId); AppState.searchResume = query to typeFilter; focusMgr.clearFocus(); kbc?.hide(); onOpen(c) },
                        onOpenMsg = { c, id -> addRecent(c.chatId); AppState.searchResume = query to typeFilter; focusMgr.clearFocus(); kbc?.hide(); onOpenMsg(c, id) },
                        onForwardMsg = { c, m -> addRecent(c.chatId); AppState.searchResume = query to typeFilter; onForwardMsg(c, m) },
                        onEditedImg = { c, d -> AppState.searchResume = query to typeFilter; onEditedImg(c, d) },
                        typeFilter = typeFilter, onType = { typeFilter = it },
                        recents = recents, onClearRecents = { recents = emptyList(); recentPrefs.edit().remove("recent_search").apply() }
                    )
                }
            }
        }
    }

    if (muteDlg) {
        val selChats = all.filter { selected.contains(it.chatId) }
        MuteDialog(isGroup = selChats.any { it.isGroup }, onDismiss = { muteDlg = false }) { until ->
            selChats.forEach { Repo.setMuted(me.uid, it.chatId, true, until) }
            muteDlg = false; selected = emptySet()
        }
    }
    if (confirmWipe) {
        val st = starredIn(me.uid, selected)
        var alsoStars by remember { mutableStateOf(false) }
        AuraAlertDialog(
            onDismissRequest = { confirmWipe = false },
            containerColor = AuraSurface,
            title = { Text("Sohbet temizlensin mi?", color = AuraWhite) },
            text = {
                Column {
                    Text("Mesajlar silinir, sohbet listede kalır.", color = AuraMuted)
                    if (st.isNotEmpty()) StarClearRow(alsoStars, st.size) { alsoStars = it }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (alsoStars) Repo.unstarAll(me.uid, st.map { it.key })
                    selected.forEach { Repo.wipeChat(me.uid, it) }
                    selected = emptySet()
                    confirmWipe = false
                }) { Text("Temizle", color = auraLc(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text("Vazgeç", color = AuraGreen) } }
        )
    }
    if (confirmDelete) {
        val st = starredIn(me.uid, selected)
        var alsoStars by remember { mutableStateOf(false) }
        AuraAlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = AuraSurface,
            title = { Text("Sohbet silinsin mi?", color = AuraWhite) },
            text = {
                Column {
                    Text("Mesajlar yalnızca senin listenden silinir.", color = AuraMuted)
                    if (st.isNotEmpty()) StarClearRow(alsoStars, st.size) { alsoStars = it }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (alsoStars) Repo.unstarAll(me.uid, st.map { it.key })
                    selected.forEach { Repo.clearChat(me.uid, it) }
                    selected = emptySet()
                    confirmDelete = false
                }) { Text("Sil", color = auraLc(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Vazgeç", color = AuraGreen) } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatRow(me: UserProfile, c: ChatSummary, selected: Boolean, manualUnread: Boolean, ring: Int, onClick: () -> Unit, onLongClick: () -> Unit, onAvatarClick: () -> Unit = {}, highlight: String = "") {
    val live by remember(c.otherUid, c.isGroup) {
        if (c.isGroup) kotlinx.coroutines.flow.flowOf<UserProfile?>(null) else Repo.profileFlow(c.otherUid)
    }.collectAsState(if (c.isGroup) null else Repo.peekProfile(c.otherUid))
    val gData by remember(c.chatId, c.isGroup) {
        if (c.isGroup) Repo.groupFlow(c.chatId) else kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.GroupData?>(null)
    }.collectAsState(if (c.isGroup) Repo.peekGroup(c.chatId) else null)
    val avatar = if (c.isGroup) (gData?.photo ?: "") else (live?.avatar ?: "")
    val shownName = live?.name?.takeIf { it.isNotBlank() } ?: c.name
    val callSt by com.aurachat.app.call.CallManager.ui.collectAsState()
    val inCall = !c.isGroup && (callSt.phase == com.aurachat.app.call.Phase.CONNECTED || callSt.phase == com.aurachat.app.call.Phase.CONNECTING || callSt.phase == com.aurachat.app.call.Phase.OUTGOING) && callSt.chatId == c.chatId
    val ringNow = if (inCall) 1 else ring
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (selected) (AuraUi.accentColor()?.copy(alpha = if (AuraUi.light) 0.18f else 0.28f) ?: if (AuraUi.light) Color(0xFFD7F5CF) else auraLc(0x4422C55E)) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .height(px(210f)).padding(start = px(34f), end = px(45f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val av = px(133f)
        Box(Modifier.size(av)) {
            Box(
                Modifier.size(av).clip(CircleShape).clickable(onClick = onAvatarClick).then(
                    if (ringNow != 0) Modifier.border(2.5.dp, if (ringNow == 1) (AuraUi.accentColor() ?: auraLc(0xFF22C55E)) else auraLc(0xFF6B7280), CircleShape) else Modifier
                ),
                contentAlignment = Alignment.Center
            ) { Avatar(shownName, avatar, if (ringNow != 0) av - px(8f) else av, isGroup = c.isGroup) }
            SelTick(selected)
        }
        Spacer(Modifier.width(px(34f)))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(hlText(shownName, highlight), color = AuraWhite, fontSize = 17.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
            }
            val preview = when {
                c.typing && !c.isGroup -> "yazıyor..."
                c.lastSenderUid == me.uid -> c.lastMessage
                c.isGroup && c.lastSenderName.isNotBlank() -> c.lastSenderName + ": " + c.lastMessage
                else -> c.lastMessage
            }
            val draft = Drafts.preview(c.chatId)
            val showDraft = draft.isNotEmpty() && !c.typing
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                if (inCall) {
                    Icon(if (callSt.video) Icons.Default.Videocam else Icons.Default.Call, null, tint = AuraGreen, modifier = Modifier.padding(end = 4.dp).size(18.dp))
                    Text(if (callSt.video) "Görüntülü arama" else "Sesli arama", fontSize = 14.sp, lineHeight = 21.sp, color = AuraGreen, maxLines = 1)
                    Text(" • Aramada", fontSize = 14.sp, lineHeight = 21.sp, color = AuraMuted, maxLines = 1)
                } else if (showDraft) {
                    Text("Taslak: ", fontSize = 14.sp, lineHeight = 21.sp, color = AuraGreen, maxLines = 1)
                    Text(draft, fontSize = 14.sp, lineHeight = 21.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = AuraMuted)
                } else {
                if (!c.typing && !c.isGroup && c.lastSenderUid == me.uid) {
                    Icon(
                        Icons.Default.DoneAll, null,
                        tint = if (c.lastRead) AuraTick else auraLc(0xFF9CA3AF),
                        modifier = Modifier.padding(end = 4.dp).size(16.dp)
                    )
                }
                val pvColor = if (c.typing && !c.isGroup) AuraGreen else AuraMuted
                val (pvText, pvInline) = iconizedPreview(preview, pvColor)
                Text(
                    pvText, inlineContent = pvInline, fontSize = 14.sp, lineHeight = 21.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = pvColor
                )
                }
            }
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(formatListTime(c.lastTime), fontSize = 12.sp, lineHeight = 14.sp, color = if (c.unread > 0) AuraGreen else AuraMuted)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (c.muted) Icon(Icons.Default.NotificationsOff, "Sessiz", tint = AuraMuted, modifier = Modifier.size(16.dp))
                if (c.pinned) Icon(Icons.Default.PushPin, "Sabit", tint = AuraMuted, modifier = Modifier.size(16.dp))
                if (c.unread > 0) {
                    val ut = if (c.unread > 99) "99+" else c.unread.toString()
                    Box(
                        (if (ut.length == 1) Modifier.size(21.dp) else Modifier.height(21.dp).widthIn(min = 21.dp).padding(horizontal = 0.dp))
                            .clip(RoundedCornerShape(50)).background((AuraUi.accentColor() ?: if (AuraUi.light) Color(0xFF1B6B49) else Color(0xFF25D366))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            ut, color = if (AuraUi.light || AuraUi.accentColor() != null) Color(0xFFFFFFFF) else Color(0xFF0B141A), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false,
                            lineHeight = 12.sp,
                            style = androidx.compose.ui.text.TextStyle(
                                platformStyle = androidx.compose.ui.text.PlatformTextStyle(includeFontPadding = false),
                                lineHeightStyle = androidx.compose.ui.text.style.LineHeightStyle(
                                    androidx.compose.ui.text.style.LineHeightStyle.Alignment.Center,
                                    androidx.compose.ui.text.style.LineHeightStyle.Trim.Both
                                )
                            ),
                            modifier = Modifier.padding(horizontal = if (ut.length == 1) 0.dp else 6.dp)
                        )
                    }
                } else if (manualUnread) {
                    Box(Modifier.size(12.dp).clip(CircleShape).background((AuraUi.accentColor() ?: if (AuraUi.light) Color(0xFF1B6B49) else Color(0xFF25D366))))
                } else if (!c.pinned && !c.muted) Spacer(Modifier.size(21.dp))
            }
        }
    }
}

/** Önizleme satırındaki renkli emojiler (📷 🎤 📄 ...) yerine alıntılardaki gibi renksiz (gri) simgeler */
private val previewIcons = listOf(
    "\uD83D\uDCF7" to Icons.Default.Image,
    "\uD83C\uDFA4" to Icons.Default.Mic,
    "\uD83D\uDCC4" to Icons.Default.Description,
    "\uD83C\uDFA5" to Icons.Default.Videocam,
    "\uD83D\uDCCD" to Icons.Default.LocationOn,
    "\uD83D\uDCCA" to Icons.Default.Poll,
    "\uD83D\uDEAB" to Icons.Default.Block
)

private fun iconizedPreview(text: String, tint: Color): Pair<androidx.compose.ui.text.AnnotatedString, Map<String, androidx.compose.foundation.text.InlineTextContent>> {
    val hit = previewIcons.map { (e, ic) -> Triple(text.indexOf(e), e, ic) }.filter { it.first >= 0 }.minByOrNull { it.first }
        ?: return androidx.compose.ui.text.AnnotatedString(text) to emptyMap()
    val (idx, emoji, icon) = hit
    val str = androidx.compose.ui.text.buildAnnotatedString {
        append(text.substring(0, idx))
        appendInlineContent("pv", "[ikon]")
        append(text.substring(idx + emoji.length))
    }
    val inl = mapOf(
        "pv" to androidx.compose.foundation.text.InlineTextContent(
            androidx.compose.ui.text.Placeholder(17.sp, 17.sp, androidx.compose.ui.text.PlaceholderVerticalAlign.Center)
        ) { Icon(icon, null, tint = tint, modifier = Modifier.fillMaxSize()) }
    )
    return str to inl
}

private fun toast(ctx: android.content.Context, s: String) =
    android.widget.Toast.makeText(ctx, s, android.widget.Toast.LENGTH_SHORT).show()

/** Bildirim izni kapalıysa veya pil kısıtlaması açıksa listenin üstünde uyarı kartı */
@Composable
private fun SystemWarnings() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(owner) {
        val ob = androidx.lifecycle.LifecycleEventObserver { _, e -> if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    val sp = remember { ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE) }
    var battDismissed by remember { mutableStateOf(sp.getBoolean("batt_warn_off", false)) }
    val notifOff = remember(tick) { !androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val battOn = remember(tick) {
        val pm = ctx.getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
        pm.isIgnoringBatteryOptimizations(ctx.packageName) == false
    }
    if (false) {
    } else if (battOn && !battDismissed && !notifOff) {
        WarnCard("Bildirimler geç gelebilir", "Telefon uygulamayı uyutabilir. Pil kısıtlamasını kaldırırsan mesajlar anında gelir.", "Ayarla", {
            sp.edit().putBoolean("batt_warn_off", true).apply(); battDismissed = true
        }) {
            try {
                ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatListScreen", e) }
        }
    }
}

@Composable
private fun WarnCard(title: String, text: String, action: String, onDismiss: (() -> Unit)?, onAction: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).clip(RoundedCornerShape(12.dp))
            .background(auraC(0xFF1F2C34)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = AuraWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(text, color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        }
        if (onDismiss != null) Text("Kapat", color = AuraMuted, fontSize = 13.sp, modifier = Modifier.clickable(onClick = onDismiss).padding(8.dp))
        Text(action, color = AuraGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onAction).padding(8.dp))
    }
}

@Composable
private fun px(n: Float): androidx.compose.ui.unit.Dp = (n / androidx.compose.ui.platform.LocalDensity.current.density).dp

/** Sohbet listesinin kaydırma konumu: sohbete girip dönünce kaldığı satırdan devam eder */
object ChatListPos { var index = 0; var offset = 0 }

/** Durum menüsünden gelen hedefi liste işlemlerinin beklediği özet kaydına çevirir */
private fun statusTargetSummary(t: com.aurachat.app.data.ChatTarget) =
    ChatSummary(t.chatId, t.isGroup, t.otherUid, t.name, "", 0L, "", "", true, 0, false, false, false, 0L)


/** "Okunmadı olarak işaretle": sadece bu cihazda tutulur, sohbet açılınca kalkar */
object ManualUnread {
    var ver by androidx.compose.runtime.mutableIntStateOf(0)
    private fun sp(c: android.content.Context) = c.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE)
    fun all(c: android.content.Context): Set<String> { val v = ver; return if (v >= 0) (sp(c).getStringSet("man_unread", emptySet()) ?: emptySet()) else emptySet() }
    fun add(c: android.content.Context, ids: Collection<String>) {
        val s = HashSet(all(c)); s.addAll(ids)
        sp(c).edit().putStringSet("man_unread", s).apply(); ver++
    }
    fun remove(c: android.content.Context, id: String) {
        val s = HashSet(all(c))
        if (s.remove(id)) { sp(c).edit().putStringSet("man_unread", s).apply(); ver++ }
    }
}


/** "Mesaj bildirimlerini sessize alın": 8 saat / 1 hafta / Her zaman (her açılışta "Her zaman" seçili gelir). onConfirm(0) = her zaman */
@Composable
fun MuteDialog(isGroup: Boolean, onDismiss: () -> Unit, onConfirm: (Long) -> Unit) {
    var pick by remember { mutableIntStateOf(2) }
    AuraAlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AuraSurface,
        title = { Text("Mesaj bildirimlerini sessize alın", color = AuraWhite, fontSize = 22.sp) },
        text = {
            Column {
                Text(
                    if (isGroup) "Diğer üyeler bu sohbeti sessize aldığınızı göremez. Sizden bahsedildiğinde bildirim almaya devam edersiniz."
                    else "Bu sohbetten bildirim almayacaksınız. Karşı taraf sessize aldığınızı göremez.",
                    color = AuraMuted, fontSize = 15.sp, modifier = Modifier.padding(bottom = 12.dp)
                )
                listOf("8 saat", "1 hafta", "Her zaman").forEachIndexed { i, l ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { pick = i }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        androidx.compose.material3.RadioButton(
                            selected = pick == i, onClick = { pick = i },
                            colors = androidx.compose.material3.RadioButtonDefaults.colors(selectedColor = AuraGreen, unselectedColor = AuraMuted)
                        )
                        Text(l, color = AuraWhite, fontSize = 17.sp, modifier = Modifier.padding(start = 10.dp))
                    }
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = {
                val now = System.currentTimeMillis()
                onConfirm(when (pick) { 0 -> now + 8L * 3600_000L; 1 -> now + 7L * 24 * 3600_000L; else -> 0L })
            }) { Text("Tamam", color = AuraGreen, fontWeight = FontWeight.SemiBold) }
        },
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("İptal", color = AuraGreen, fontWeight = FontWeight.SemiBold) }
        }
    )
}


private fun searchTypeLabel(k: String) = when (k) {
    "unread" -> "Okunmamış"; "image" -> "Fotoğraflar"; "video" -> "Videolar"; "link" -> "Bağlantılar"
    "audio" -> "Sesler"; "document" -> "Belgeler"; else -> k
}

/** Liste sayfasındaki çiplerle aynı görünüm (seçili değilken) */
@Composable
private fun SearchChip(label: String, onClick: () -> Unit) {
    val lt = AuraUi.light
    Text(
        label, color = if (lt) Color(0xFF3B4A54) else Color(0xFFA7ADB2), fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium,
        maxLines = 1, softWrap = false,
        modifier = Modifier.clip(RoundedCornerShape(50)).border(1.dp, if (lt) Color(0xFFE0E0E0) else Color(0xFF2C2C2C), RoundedCornerShape(50))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 4.dp)
    )
}

/** Arama sonuç sayfası (WhatsApp gibi): Sohbetler / Kişiler / Mesajlar bölümleri */
@Composable
private fun SearchResultsPane(
    me: UserProfile, query: String, chats: List<ChatSummary>, liveNames: Map<String, String>,
    onOpen: (ChatSummary) -> Unit, onOpenMsg: (ChatSummary, String) -> Unit,
    onForwardMsg: (ChatSummary, com.aurachat.app.data.Message) -> Unit, onEditedImg: (ChatSummary, String) -> Unit,
    typeFilter: String?, onType: (String?) -> Unit, recents: List<String>, onClearRecents: () -> Unit
) {
    val q = query.trim()
    val users by remember(me.uid) { Repo.usersFlow(me.uid) }.collectAsState(Repo.cachedUsers())
    val msgHits0 by androidx.compose.runtime.produceState<List<Pair<String, com.aurachat.app.data.Message>>>(emptyList(), q) {
        if (q.isEmpty()) { value = emptyList(); return@produceState }
        kotlinx.coroutines.delay(250)
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { com.aurachat.app.data.LocalDb.search(q, 100) }
    }
    // silinmiş / temizlenmiş / "benden sil" yapılmış mesajlar aramada hiç görünmez
    val msgHits = msgHits0.filter { (cid, m) -> me.uid !in m.deletedFor && m.time > Repo.peekClearedAt(me.uid, cid) }
    fun nameOf(c: ChatSummary) = if (c.isGroup) c.name else (liveNames[c.otherUid] ?: c.name)
    val chatHits = if (q.isEmpty()) emptyList() else chats.filter { nameOf(it).contains(q, ignoreCase = true) }
    val userHits = if (q.isEmpty()) emptyList() else (users ?: emptyList()).filter { it.name.contains(q, ignoreCase = true) || (it.phone.isNotBlank() && it.phone.contains(q)) || (it.username.isNotBlank() && it.username.contains(q, ignoreCase = true)) }.take(20)
    val byId = remember(chats) { chats.associateBy { it.chatId } }
    var viewerData by remember { mutableStateOf<SearchViewerData?>(null) }
    var playVideo by remember { mutableStateOf<com.aurachat.app.data.Message?>(null) }
    val paneFocus = androidx.compose.ui.platform.LocalFocusManager.current
    @OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)
    val paneKb = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    val typed by androidx.compose.runtime.produceState<List<Pair<String, com.aurachat.app.data.Message>>>(emptyList(), typeFilter, q) {
        val tf = typeFilter
        if (tf == null || tf == "unread") { value = emptyList(); return@produceState }
        if (q.isNotEmpty()) kotlinx.coroutines.delay(250)
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { com.aurachat.app.data.LocalDb.searchType(tf, q, 300) }
    }

    @Composable
    fun Head(t: String) = Text(t, color = AuraMuted, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 6.dp))

    LazyColumn(Modifier.fillMaxSize()) {
        if (typeFilter != null) {
            if (typeFilter == "unread") {
                val un = chats.filter { it.lastSenderUid != me.uid && it.unread > 0 && (q.isEmpty() || nameOf(it).contains(q, ignoreCase = true)) }
                items(un, key = { "un_" + it.chatId }) { c -> ChatRow(me = me, c = c, selected = false, manualUnread = false, ring = 0, onClick = { onOpen(c) }, onLongClick = {}, highlight = q) }
                if (un.isEmpty()) item { Text("Okunmamış sohbet yok", color = AuraMuted, fontSize = 15.sp, modifier = Modifier.padding(24.dp)) }
            } else {
                val hits = typed.filter { (cid, m) -> byId[cid] != null && me.uid !in m.deletedFor && m.time > Repo.peekClearedAt(me.uid, cid) }
                if (typeFilter == "image" || typeFilter == "video") {
                    // Gösterilecek resmi olmayan (dosyası silinmiş / hiç inmemiş) kareler boş çerçeve bırakmasın
                    fun tileSrc(m: com.aurachat.app.data.Message): String =
                        if (m.type == "image") (messageImages(com.aurachat.app.data.LocalMedia.localize(m)).firstOrNull() ?: m.thumb) else m.thumb
                    fun usable(src: String): Boolean = when {
                        src.isBlank() -> false
                        src.startsWith("file:") -> java.io.File(src.removePrefix("file:")).exists()
                        src.startsWith("/") -> java.io.File(src).exists()
                        else -> true
                    }
                    val gridHits = hits.filter { (_, m) -> usable(tileSrc(m)) }
                    items(gridHits.chunked(3), key = { row -> "g_" + row.first().first + row.first().second.id }) { row ->
                        Row(Modifier.fillMaxWidth().padding(horizontal = 1.dp)) {
                            row.forEach { (cid, m) ->
                                Box(Modifier.weight(1f).aspectRatio(1f).padding(1.dp).clickable {
                                    if (typeFilter == "image") {
                                        // WhatsApp gibi: sohbete gitmeden resmi aç, kaydırınca aramadaki tüm resimler gezilir
                                        paneFocus.clearFocus(); paneKb?.hide()
                                        val flat = gridHits.flatMap { (cid2, m2) ->
                                            val l = messageImages(com.aurachat.app.data.LocalMedia.localize(m2)).ifEmpty { listOf(m2.thumb) }.filter { usable(it) }
                                            l.map { src -> Triple(cid2, m2, src) }
                                        }
                                        val st = flat.indexOfFirst { it.second.id == m.id }.coerceAtLeast(0)
                                        val vItems = flat.map { (cid2, m2, src) ->
                                            val c2 = byId[cid2]
                                            ViewerItem(src, m2.time, if (m2.senderUid == me.uid) me.name else m2.senderName.ifBlank { c2?.let { nameOf(it) } ?: "" }, m2.id, "", m2.senderUid)
                                        }
                                        if (vItems.isNotEmpty()) viewerData = SearchViewerData(vItems, st, flat.associate { it.second.id to (it.first to it.second) }, cid)
                                    } else if (m.type == "video") {
                                        paneFocus.clearFocus(); paneKb?.hide()
                                        playVideo = com.aurachat.app.data.LocalMedia.localize(m)
                                    } else byId[cid]?.let { onOpenMsg(it, m.id) }
                                }) {
                                    val src = tileSrc(m)
                                    if (src.isNotBlank()) DataUrlImage(src, 300, Modifier.fillMaxSize(), ContentScale.Crop)
                                    else Box(Modifier.fillMaxSize().background(AuraSurface))
                                    if (m.type == "video") Icon(Icons.Default.Videocam, null, tint = Color.White, modifier = Modifier.align(Alignment.BottomStart).padding(4.dp).size(18.dp))
                                }
                            }
                            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                } else {
                    items(hits, key = { "t_" + it.first + it.second.id }) { (cid, m) ->
                        val c = byId[cid]
                        if (c != null) Column(Modifier.fillMaxWidth().clickable { onOpenMsg(c, m.id) }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(nameOf(c), color = AuraWhite, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                Text(formatListTime(m.time), color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
                            }
                            val who = if (m.senderUid == me.uid) "Siz: " else if (c.isGroup && m.senderName.isNotBlank()) m.senderName + ": " else ""
                            val lp = m.linkPreview
                            Text(who + (if (typeFilter == "link") m.text else Repo.previewOf(m)).replace('\n', ' '), color = AuraMuted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
                            if (typeFilter == "link" && lp != null) {
                                Row(
                                    Modifier.padding(top = 8.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                        .background(if (AuraUi.light) Color(0xFFF1F1F1) else auraLc(0xFF1B262D))
                                ) {
                                    if (lp.image.isNotBlank()) LinkThumb(lp.image, WebHostIsVideo(lp.url), Modifier.size(92.dp).background(Color.Black))
                                    Column(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 6.dp).align(Alignment.CenterVertically)) {
                                        if (lp.title.isNotBlank()) Text(lp.title, color = AuraWhite, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        if (lp.description.isNotBlank()) Text(lp.description, color = AuraMuted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(try { android.net.Uri.parse(lp.url).host?.removePrefix("www.") ?: "" } catch (e: Throwable) { "" }, color = AuraMuted, fontSize = 12.sp, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                }
                if (hits.isEmpty()) item { Text("Sonuç yok", color = AuraMuted, fontSize = 15.sp, modifier = Modifier.padding(24.dp)) }
            }
        } else if (q.isEmpty()) {
            item(key = "chips") {
                Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal = 13.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("unread", "image", "video", "link", "audio", "document").forEach { k -> SearchChip(searchTypeLabel(k)) { onType(k) } }
                }
            }
            val recChats = recents.mapNotNull { byId[it] }
            if (recChats.isNotEmpty()) {
                item(key = "rec_h") {
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 13.dp, top = 14.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("En son aramalar", color = AuraMuted, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        SearchChip("Tümünü temizle") { onClearRecents() }
                    }
                }
                item(key = "rec_r") {
                    Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal = 10.dp, vertical = 6.dp)) {
                        recChats.forEach { c ->
                            val lv = if (c.isGroup) null else liveProfile(c.otherUid).value
                            val nm = if (c.isGroup) c.name else (lv?.name?.takeIf { it.isNotBlank() } ?: liveNames[c.otherUid] ?: c.name)
                            val av = if (c.isGroup) (Repo.peekGroup(c.chatId)?.photo ?: "") else (lv?.avatar ?: "")
                            Column(Modifier.width(80.dp).clip(RoundedCornerShape(10.dp)).clickable { onOpen(c) }.padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Avatar(nm.ifBlank { "?" }, av, 62.dp, isGroup = c.isGroup)
                                Text(nm, color = AuraMuted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp, start = 4.dp, end = 4.dp))
                            }
                        }
                    }
                }
            } else {
                item { Text("Sohbetlerde, kişilerde ve mesajlarda ara", color = AuraMuted, fontSize = 15.sp, modifier = Modifier.padding(24.dp)) }
            }
        } else {
            if (chatHits.isNotEmpty()) {
                item(key = "h_chats") { Head("Sohbetler") }
                items(chatHits, key = { "c_" + it.chatId }) { c ->
                    ChatRow(me = me, c = c, selected = false, manualUnread = false, ring = 0, onClick = { onOpen(c) }, onLongClick = {}, highlight = q)
                }
            }
            if (userHits.isNotEmpty()) {
                item(key = "h_users") { Head("Kişiler") }
                items(userHits, key = { "u_" + it.uid }) { u ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            val ex = chats.firstOrNull { !it.isGroup && it.otherUid == u.uid }
                            onOpen(ex ?: ChatSummary(Repo.chatId(me.uid, u.uid), false, u.uid, u.name, "", 0L, "", "", true, 0, false, false, false, 0L))
                        }.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(u.name.ifBlank { "?" }, u.avatar, 52.dp)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(hlText(u.name, q), color = AuraWhite, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (u.about.isNotBlank()) Text(u.about, color = AuraMuted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            if (msgHits.isNotEmpty()) {
                item(key = "h_msgs") { Head("Mesajlar") }
                items(msgHits, key = { "m_" + it.first + it.second.id }) { (chatId, m) ->
                    val c = byId[chatId]
                    if (c != null) Column(
                        Modifier.fillMaxWidth().clickable { onOpenMsg(c, m.id) }.padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(nameOf(c), color = AuraWhite, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Text(formatListTime(m.time), color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
                        }
                        val who = if (m.senderUid == me.uid) "Siz: " else if (c.isGroup && m.senderName.isNotBlank()) m.senderName + ": " else ""
                        val idx = m.text.indexOf(q, ignoreCase = true).coerceAtLeast(0)
                        val from = (idx - 18).coerceAtLeast(0)
                        val snip = (if (from > 0) "…" else "") + m.text.substring(from).replace('\n', ' ')
                        val mi = (idx - from + (if (from > 0) 1 else 0)).coerceAtLeast(0)
                        Text(
                            androidx.compose.ui.text.buildAnnotatedString {
                                append(who)
                                append(snip.substring(0, mi.coerceAtMost(snip.length)))
                                pushStyle(androidx.compose.ui.text.SpanStyle(color = AuraGreen, fontWeight = FontWeight.Bold))
                                append(snip.substring(mi.coerceAtMost(snip.length), (mi + q.length).coerceAtMost(snip.length)))
                                pop()
                                append(snip.substring((mi + q.length).coerceAtMost(snip.length)))
                            },
                            color = AuraMuted, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }
            if (chatHits.isEmpty() && userHits.isEmpty() && msgHits.isEmpty()) {
                item { Text("Sonuç yok", color = AuraMuted, fontSize = 15.sp, modifier = Modifier.padding(24.dp)) }
            }
        }
    }
    playVideo?.let { VideoPlayerDialog(it) { playVideo = null } }
    val vd = viewerData
    if (vd != null) {
        fun tgt(c: ChatSummary) = com.aurachat.app.data.ChatTarget(c.chatId, c.isGroup, c.otherUid, c.name)
        val first = byId[vd.startCid]
        if (first != null) {
            MessageImageViewer(
                me = me, target = tgt(first), items = vd.items, startIndex = vd.start, album = false,
                msgFor = { id -> vd.msgs[id]?.second },
                onForward = { m -> vd.msgs[m.id]?.first?.let { cid -> byId[cid] }?.let { c -> viewerData = null; onForwardMsg(c, m) } },
                onShowInChat = { m -> vd.msgs[m.id]?.first?.let { cid -> byId[cid] }?.let { c -> viewerData = null; onOpenMsg(c, m.id) } },
                onEdited = { d -> viewerData = null; onEditedImg(first, d) },
                targetFor = { it2 -> vd.msgs[it2.id]?.first?.let { cid -> byId[cid] }?.let { c -> tgt(c) } ?: tgt(first) },
                onClose = { viewerData = null }
            )
        }
    }
}

/** Tema seçicideki küçük telefon önizlemesi */
@Composable
internal fun ThemeMock(dark: Boolean) {
    val bg = if (dark) Color(0xFF000000) else Color(0xFFFFFFFF)
    val bar = if (dark) Color(0xFF1A1A1A) else Color(0xFFF7F5F3)
    val line = if (dark) Color(0xFF3A3A3A) else Color(0xFFDDD8D0)
    val av = if (dark) Color(0xFF2C2C2C) else Color(0xFFE6E1D8)
    Column(Modifier.fillMaxSize().background(bg)) {
        Box(Modifier.fillMaxWidth().height(26.dp).background(bar))
        Column(Modifier.padding(horizontal = 10.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            repeat(4) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(20.dp).clip(CircleShape).background(av))
                    Column(Modifier.padding(start = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(Modifier.width(44.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(line))
                        Box(Modifier.width(30.dp).height(4.dp).clip(RoundedCornerShape(3.dp)).background(line.copy(alpha = 0.6f)))
                    }
                }
            }
        }
    }
}


/** Arama eşleşmesini vurgu rengiyle işaretler (harf harf, büyük/küçük harf fark etmez) */
@Composable
private fun hlText(t: String, q: String): androidx.compose.ui.text.AnnotatedString {
    val key = q.trim()
    val accent = AuraGreen
    if (key.isEmpty()) return androidx.compose.ui.text.AnnotatedString(t)
    return androidx.compose.ui.text.buildAnnotatedString {
        var i = 0
        while (i < t.length) {
            val j = t.indexOf(key, i, ignoreCase = true)
            if (j < 0) { append(t.substring(i)); break }
            append(t.substring(i, j))
            pushStyle(androidx.compose.ui.text.SpanStyle(color = accent, fontWeight = FontWeight.Bold))
            append(t.substring(j, j + key.length))
            pop()
            i = j + key.length
        }
    }
}


private class SearchViewerData(val items: List<ViewerItem>, val start: Int, val msgs: Map<String, Pair<String, com.aurachat.app.data.Message>>, val startCid: String)

package com.aurachat.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.ui.focus.focusRequester
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.DonutLarge
import androidx.compose.material.icons.filled.People
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import kotlinx.coroutines.launch
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.ChatSummary
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile

/** Silinmiş (clearedAt sonrası mesajı olmayan) sohbetleri gizler */
fun visibleChats(list: List<ChatSummary>): List<ChatSummary> =
    list.filter { c ->
        (c.isGroup || c.otherUid.isNotEmpty()) &&
            (c.keepRow || c.clearedAt <= 0L || c.lastTime > c.clearedAt)
    }

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatListScreen(
    me: UserProfile,
    onOpen: (ChatSummary) -> Unit,
    onNewChat: () -> Unit,
    onNewGroup: () -> Unit,
    onStarred: () -> Unit,
    onSettings: () -> Unit,
    onSignOut: () -> Unit,
    tabIsActive: Boolean = true
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val chats by remember(me.uid) { Repo.chatsFlow(me.uid) }.collectAsState(remember(me.uid) { Repo.cachedChats(me.uid) })
    androidx.compose.runtime.LaunchedEffect(chats != null) {
        if (chats != null) com.aurachat.app.AppState.ready = true
    }
    var filter by remember { mutableStateOf("all") }
    var query by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    val focusReq = remember { androidx.compose.ui.focus.FocusRequester() }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    val tabActive = tabIsActive
    androidx.compose.runtime.LaunchedEffect(tabActive) { if (!tabActive) selected = emptySet() }
    var confirmDelete by remember { mutableStateOf(false) }

    val all = visibleChats(chats ?: emptyList())
    val statuses by remember { Repo.statusesFlow() }.collectAsState(emptyList<com.aurachat.app.data.StatusItem>())
    val ringOf = remember(statuses, me.uid) {
        val now = System.currentTimeMillis()
        val m = HashMap<String, Int>()
        statuses.filter { it.expiresAt > now }.groupBy { it.uid }.forEach { (uid, l) ->
            m[uid] = if (l.any { !it.viewers.contains(me.uid) }) 1 else 2
        }
        m
    }
    val liveNames = remember { androidx.compose.runtime.mutableStateMapOf<String, String>() }
    val directUids = all.filter { !it.isGroup && it.otherUid.isNotEmpty() }.map { it.otherUid }.toSet()
    androidx.compose.runtime.LaunchedEffect(directUids) {
        directUids.forEach { u ->
            launch { Repo.profileFlow(u).collect { p -> if (p != null && p.name.isNotBlank()) liveNames[u] = p.name } }
        }
    }
    // Bildirim izni / ayarı kapalı mı (ekrana dönünce yeniden kontrol edilir)
    var notifOn by remember { mutableStateOf(androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled()) }
    val lifeOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifeOwner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                notifOn = androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled()
            }
        }
        lifeOwner.lifecycle.addObserver(obs)
        onDispose { lifeOwner.lifecycle.removeObserver(obs) }
    }
    val shown = all
        .filter {
            when (filter) {
                "unread" -> it.unread > 0
                "fav" -> it.favorite
                "groups" -> it.isGroup
                else -> true
            }
        }
        .filter { query.isBlank() || (liveNames[it.otherUid] ?: it.name).contains(query, ignoreCase = true) || it.name.contains(query, ignoreCase = true) }
        .sortedWith(compareByDescending<ChatSummary> { it.pinned }.thenByDescending { it.lastTime })

    @androidx.compose.runtime.Composable
    fun ChipsRow() {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState())
                .padding(horizontal = 10.dp).padding(top = 8.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            fun un(c: ChatSummary) = if (c.lastSenderUid == me.uid) 0 else c.unread
            val unreadTotal = all.sumOf { un(it) }
            val favTotal = all.filter { it.favorite }.sumOf { un(it) }
            val grpTotal = all.filter { it.isGroup }.sumOf { un(it) }
            fun lbl(t: String, n: Int) = if (n > 0) "$t $n" else t
            listOf(
                "all" to "Tümü",
                "unread" to lbl("Okunmamış", unreadTotal),
                "fav" to lbl("Favoriler", favTotal),
                "groups" to lbl("Gruplar", grpTotal)
            ).forEach { (k, label) ->
                val on = filter == k
                Text(
                    label,
                    color = if (on) Color.White else Color(0xFFD1D5DB),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.clip(RoundedCornerShape(50))
                        .background(if (on) AuraBtn else AuraSurface)
                        .combinedClickable(onClick = { filter = k })
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                )
            }
        }
    }

    BackHandler(enabled = selected.isNotEmpty()) { selected = emptySet() }
    BackHandler(enabled = searching && selected.isEmpty()) { searching = false; query = "" }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // Üst çubuk
            Row(
                Modifier.fillMaxWidth().height(60.dp).background(Color.Black).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (selected.isNotEmpty()) {
                    IconButton(onClick = { selected = emptySet() }) { Icon(Icons.Default.Close, "İptal", tint = Color.White) }
                    Text("${selected.size}", color = Color.White, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    val sel = all.filter { selected.contains(it.chatId) }
                    val allPinned = sel.isNotEmpty() && sel.all { it.pinned }
                    val allFav = sel.isNotEmpty() && sel.all { it.favorite }
                    IconButton(onClick = {
                        sel.forEach { Repo.setPinned(me.uid, it.chatId, !allPinned) }
                        selected = emptySet()
                    }) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.PushPin, if (allPinned) "Sabitlemeyi kaldır" else "Sabitle", tint = Color.White)
                            if (allPinned) {
                                androidx.compose.foundation.Canvas(Modifier.size(24.dp)) {
                                    drawLine(Color.Black, androidx.compose.ui.geometry.Offset(size.width * 0.16f, size.height * 0.22f + 2.5f), androidx.compose.ui.geometry.Offset(size.width * 0.84f, size.height * 0.80f + 2.5f), strokeWidth = 5f)
                                    drawLine(Color.White, androidx.compose.ui.geometry.Offset(size.width * 0.16f, size.height * 0.22f), androidx.compose.ui.geometry.Offset(size.width * 0.84f, size.height * 0.80f), strokeWidth = 3f)
                                }
                            }
                        }
                    }
                    IconButton(onClick = {
                        sel.forEach { Repo.setFavorite(me.uid, it.chatId, !allFav) }
                        selected = emptySet()
                    }) { Icon(if (allFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favori", tint = if (allFav) AuraGreen else Color.White) }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, "Sil", tint = Color.White) }
                } else if (searching) {
                    IconButton(onClick = { searching = false; query = "" }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kapat", tint = Color.White)
                    }
                    Row(
                        Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(50)).background(AuraSurface).padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.weight(1f)) {
                            if (query.isEmpty()) Text("Ara...", color = AuraMuted, fontSize = 14.sp)
                            BasicTextField(
                                value = query, onValueChange = { query = it }, singleLine = true,
                                textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                                cursorBrush = SolidColor(AuraGreen),
                                modifier = Modifier.fillMaxWidth().focusRequester(focusReq)
                            )
                        }
                        if (query.isNotEmpty()) {
                            Icon(Icons.Default.Close, "Temizle", tint = AuraMuted, modifier = Modifier.size(18.dp).combinedClickable(onClick = { query = "" }))
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    androidx.compose.runtime.LaunchedEffect(Unit) { try { focusReq.requestFocus() } catch (e: Throwable) {} }
                } else {
                    Text(
                        "AuraChat", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f).padding(start = 10.dp)
                    )
                    IconButton(onClick = { searching = true }) { Icon(Icons.Default.Search, "Ara", tint = Color.White) }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = Color.White) }
                        DropdownMenu(
                            expanded = menu, onDismissRequest = { menu = false },
                            shape = RoundedCornerShape(16.dp), containerColor = Color(0xFF0F1419),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A3942))
                        ) {
                            @Composable
                            fun MenuRow(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, label: String, textColor: Color = Color.White, onClick: () -> Unit) {
                                DropdownMenuItem(
                                    leadingIcon = { Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp)) },
                                    text = { Text(label, color = textColor, fontSize = 17.sp) },
                                    onClick = { menu = false; onClick() },
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            }
                            MenuRow(androidx.compose.material.icons.Icons.Default.GroupAdd, Color(0xFF34D399), "Grup oluştur") { onNewGroup() }
                            MenuRow(androidx.compose.material.icons.Icons.Default.Star, Color(0xFFFBBF24), "Yıldızlı mesajlar") { onStarred() }
                            MenuRow(androidx.compose.material.icons.Icons.Default.Settings, Color(0xFF38BDF8), "Ayarlar") { onSettings() }
                            MenuRow(androidx.compose.material.icons.Icons.AutoMirrored.Filled.Logout, Color(0xFFFB7185), "Çıkış yap", Color(0xFFFB7185)) { onSignOut() }
                        }
                    }
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(Modifier.fillMaxSize()) {
                    if (!notifOn) {
                        item(key = "notifwarn") {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)
                                    .clip(RoundedCornerShape(14.dp)).background(Color(0xFF3B2A12)).padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Bildirimler kapalı. Mesajları anında almak için aç.", color = Color(0xFFFCD34D), fontSize = 13.sp, modifier = Modifier.weight(1f))
                                Text(
                                    "Aç", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(start = 10.dp).clip(RoundedCornerShape(50)).background(AuraBtn)
                                        .clickable {
                                            try {
                                                ctx.startActivity(
                                                    android.content.Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                                        .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                                                )
                                            } catch (e: Throwable) {}
                                        }
                                        .padding(horizontal = 16.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }
                    item(key = "chips") { ChipsRow() }
                    if (chats == null) {
                        // boş: önbellek/ilk anlık görüntü bekleniyor
                    } else if (shown.isEmpty()) {
                        item(key = "empty") {
                            Box(Modifier.fillMaxWidth().padding(top = 80.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    if (all.isEmpty()) "Henüz sohbet yok. + ile başla." else "Sonuç yok",
                                    color = AuraMuted
                                )
                            }
                        }
                    } else {
                        items(shown, key = { it.chatId }) { c ->
                            ChatRow(
                                me = me, c = c, selected = selected.contains(c.chatId),
                                ring = if (c.isGroup) 0 else (ringOf[c.otherUid] ?: 0),
                                onClick = {
                                    if (selected.isNotEmpty()) {
                                        selected = if (selected.contains(c.chatId)) selected - c.chatId else selected + c.chatId
                                    } else onOpen(c)
                                },
                                onLongClick = {
                                    selected = if (selected.contains(c.chatId)) selected - c.chatId else selected + c.chatId
                                }
                            )
                        }
                    }
                }
                FloatingActionButton(
                    onClick = onNewChat,
                    containerColor = AuraBtn, contentColor = Color.White,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
                ) { Icon(Icons.Default.Add, "Yeni sohbet") }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = AuraSurface,
            title = { Text("Sohbet silinsin mi?", color = Color.White) },
            text = { Text("Mesajlar yalnızca senin listenden silinir.", color = AuraMuted) },
            confirmButton = {
                TextButton(onClick = {
                    selected.forEach { Repo.clearChat(me.uid, it) }
                    selected = emptySet()
                    confirmDelete = false
                }) { Text("Sil", color = Color(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Vazgeç", color = AuraGreen) } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatRow(me: UserProfile, c: ChatSummary, selected: Boolean, ring: Int, onClick: () -> Unit, onLongClick: () -> Unit) {
    val live by remember(c.otherUid, c.isGroup) {
        if (c.isGroup) kotlinx.coroutines.flow.flowOf<UserProfile?>(null) else Repo.profileFlow(c.otherUid)
    }.collectAsState(if (c.isGroup) null else Repo.peekProfile(c.otherUid))
    val gData by remember(c.chatId, c.isGroup) {
        if (c.isGroup) Repo.groupFlow(c.chatId) else kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.GroupData?>(null)
    }.collectAsState(if (c.isGroup) Repo.peekGroup(c.chatId) else null)
    val avatar = if (c.isGroup) (gData?.photo ?: "") else (live?.avatar ?: "")
    val shownName = live?.name?.takeIf { it.isNotBlank() } ?: c.name
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (selected) Color(0x4422C55E) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val av = (133f / androidx.compose.ui.platform.LocalDensity.current.density).dp
        Box(
            Modifier.size(av + 6.dp).then(
                if (ring != 0) Modifier.border(2.5.dp, if (ring == 1) Color(0xFF22C55E) else Color(0xFF6B7280), CircleShape) else Modifier
            ),
            contentAlignment = Alignment.Center
        ) { Avatar(shownName, avatar, if (ring != 0) av - 2.dp else av, isGroup = c.isGroup) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(shownName, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
            }
            val preview = when {
                c.typing && !c.isGroup -> "yazıyor..."
                c.lastSenderUid == me.uid -> c.lastMessage
                c.isGroup && c.lastSenderName.isNotBlank() -> c.lastSenderName + ": " + c.lastMessage
                else -> c.lastMessage
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!c.typing && !c.isGroup && c.lastSenderUid == me.uid) {
                    Icon(
                        Icons.Default.DoneAll, null,
                        tint = if (c.lastRead) AuraTick else Color(0xFF9CA3AF),
                        modifier = Modifier.padding(end = 4.dp).size(16.dp)
                    )
                }
                Text(
                    preview, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (c.typing && !c.isGroup) AuraGreen else AuraMuted
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (c.muted) Icon(Icons.Default.NotificationsOff, "Sessiz", tint = AuraMuted, modifier = Modifier.padding(end = 4.dp).size(14.dp))
                Text(formatListTime(c.lastTime), fontSize = 11.sp, color = if (c.unread > 0) AuraGreen else AuraMuted)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (c.pinned) Icon(Icons.Default.PushPin, "Sabit", tint = AuraMuted, modifier = Modifier.size(16.dp))
                if (c.unread > 0) {
                    val ut = if (c.unread > 99) "99+" else c.unread.toString()
                    Box(
                        (if (ut.length == 1) Modifier.size(22.dp) else Modifier.height(22.dp).widthIn(min = 22.dp).padding(horizontal = 0.dp))
                            .clip(RoundedCornerShape(50)).background(AuraBtn),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            ut, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false,
                            lineHeight = 12.sp,
                            style = androidx.compose.ui.text.TextStyle(
                                platformStyle = androidx.compose.ui.text.PlatformTextStyle(includeFontPadding = false),
                                lineHeightStyle = androidx.compose.ui.text.style.LineHeightStyle(
                                    androidx.compose.ui.text.style.LineHeightStyle.Alignment.Center,
                                    androidx.compose.ui.text.style.LineHeightStyle.Trim.Both
                                )
                            ),
                            modifier = Modifier.padding(horizontal = if (ut.length == 1) 0.dp else 6.dp)
                        )
                    }
                } else if (!c.pinned) Spacer(Modifier.size(22.dp))
            }
        }
    }
}

private fun toast(ctx: android.content.Context, s: String) =
    android.widget.Toast.makeText(ctx, s, android.widget.Toast.LENGTH_SHORT).show()

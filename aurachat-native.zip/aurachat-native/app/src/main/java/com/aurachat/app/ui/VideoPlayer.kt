package com.aurachat.app.ui

import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aurachat.app.data.Media
import com.aurachat.app.data.Message
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Video mesajını tam ekranda oynatır (yerel dosya ya da veri URL'si) */
@Composable
fun VideoPlayerDialog(m: Message, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val uri by produceState<Uri?>(null, m.id, m.imageUrl) {
        value = withContext(Dispatchers.IO) {
            try {
                if (m.imageUrl.startsWith("file:")) Uri.fromFile(java.io.File(m.imageUrl.removePrefix("file:")))
                else Uri.fromFile(Media.writeCacheFile(ctx, m.imageUrl, "video_${m.id}.mp4"))
            } catch (e: Throwable) { null }
        }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val u = uri
            if (u != null) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c ->
                        VideoView(c).apply {
                            val mc = MediaController(c)
                            mc.setAnchorView(this)
                            setMediaController(mc)
                            setVideoURI(u)
                            setOnPreparedListener { it.isLooping = false; start() }
                        }
                    }
                )
            }
            IconButton(onClick = onClose, modifier = Modifier.align(Alignment.TopStart).statusBarsPadding().padding(4.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White)
            }
        }
    }
}

package com.aurachat.app.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import kotlin.math.max
import kotlin.math.min

private val CI_BAR = 60.dp
private val AV_BIG = 150.dp
private val CI_PAD = 72.dp   // avatarın üst çubuktan uzaklığı (WhatsApp gibi biraz aşağıda)
private val AV_SMALL = 36.dp
private const val NAME_SCALE = 0.75f

/**
 * Kişi bilgisi sayfası (eski web sürümüyle aynı düzen).
 * Aşağı kaydırınca büyük avatar ve isim küçülüp üst çubukta okun yanına yerleşir.
 */
@Composable
fun ContactInfoScreen(
    me: UserProfile,
    target: ChatTarget,
    onBack: () -> Unit,
    onMessage: () -> Unit,
    onSearch: () -> Unit,
    onMedia: () -> Unit = {},
    onStarred: () -> Unit,
    onCall: (Boolean) -> Unit,
    onTheme: () -> Unit,
    group: com.aurachat.app.data.GroupData? = null,
    groupBody: (@Composable () -> Unit)? = null,
    onForward: (List<com.aurachat.app.data.Message>) -> Unit = {},
    onShowInChat: (com.aurachat.app.data.Message) -> Unit = {},
    onEdited: (String) -> Unit = {}
) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val clipboard = LocalClipboardManager.current
    val scroll = rememberScrollState()

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    val liveOther by remember(target.otherUid, group != null) {
        if (group != null) kotlinx.coroutines.flow.flowOf<UserProfile?>(null) else Repo.profileFlow(target.otherUid)
    }.collectAsState(if (group != null) null else Repo.peekProfile(target.otherUid))
    val other = if (group != null) UserProfile(target.chatId, group.name, "", group.photo, "Grup · ${group.members.size} üye")
        else (liveOther?.let { if (it.name.isBlank()) it.copy(name = target.name) else it }
        ?: UserProfile(target.otherUid, target.name))
    val flags by remember(target.chatId) { Repo.chatFlagsFlow(me.uid, target.chatId) }
        .collectAsState(Repo.ChatFlags(false, false, false))
    val blockedList by remember(me.uid) { Repo.blockedFlow(me.uid) }.collectAsState(emptyList())
    val isBlocked = blockedList.contains(target.otherUid)

    val recent by remember(target.chatId) { Repo.messagesFlow(target.chatId, 150) }.collectAsState(emptyList())
    val mver = com.aurachat.app.data.LocalMedia.version
    val mediaMsgs = remember(recent, mver) {
        recent.filter { it.type == "image" && !it.deleted && !it.viewOnce }
            .map { com.aurachat.app.data.LocalMedia.localize(it) }
    }
    val mediaPairs = remember(mediaMsgs) { mediaMsgs.flatMap { m -> messageImages(m).map { Pair(it, m) } } }
    val mediaImages = remember(mediaPairs) { mediaPairs.map { it.first } }
    var mediaViewer by remember { mutableStateOf<Int?>(null) }

    var menu by remember { mutableStateOf(false) }
    var showDisappear by remember { mutableStateOf(false) }
    var showWipe by remember { mutableStateOf(false) }
    var showMute by remember { mutableStateOf(false) }
    if (showMute) MuteDialog(isGroup = target.isGroup, onDismiss = { showMute = false }) { until ->
        Repo.setMuted(me.uid, target.chatId, true, until); showMute = false
        toast("Sohbet sessize alındı")
    }
    var viewer by remember { mutableStateOf<Pair<List<String>, Int>?>(null) }
    var nameSize by remember { mutableStateOf(IntSize.Zero) }

    val sbPx = WindowInsets.statusBars.getTop(density).toFloat()
    val sbDp = with(density) { sbPx.toDp() }
    val barPx = with(density) { CI_BAR.toPx() }
    val bigPx = with(density) { AV_BIG.toPx() }
    val smallPx = with(density) { AV_SMALL.toPx() }
    val collapsePx = with(density) { 140.dp.toPx() }
    val padTopPx = with(density) { CI_PAD.toPx() }
    val namePadPx = with(density) { 16.dp.toPx() }
    val avCx1 = with(density) { 74.dp.toPx() }
    val nameLeft1 = with(density) { 104.dp.toPx() }
    val gutterPx = with(density) { 48.dp.toPx() }
    val rightPx = with(density) { 56.dp.toPx() }

    BoxWithConstraints(Modifier.fillMaxSize().background(AuraChatBg)) {
        val wPx = with(density) { maxWidth.toPx() }
        val st = scroll.value.toFloat()
        val p = (st / collapsePx).coerceIn(0f, 1f)
        fun lerpF(a: Float, b: Float) = a + (b - a) * p
        val bottomSpace = 24.dp

        // Avatarın baskın renginden doodle üst kapak (avatarın ortasına kadar)
        ProfileCover(other.avatar, AuraChatBg, p, st, Modifier.fillMaxWidth().padding(top = sbDp).height(CI_PAD + AV_BIG / 2 + 28.dp))

        // ---------- Kaydırılan içerik ----------
        Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
            Spacer(Modifier.height(sbDp + CI_PAD))
            Spacer(Modifier.height(AV_BIG)) // avatarın yeri (avatar üstte yüzer)
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.Center) {
                Text(
                    other.name, fontSize = 24.sp, color = AuraWhite, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .padding(horizontal = 24.dp)
                        .alpha(0f)
                        .onSizeChanged { nameSize = it }
                )
            }
            if (other.phone.isNotBlank()) {
                Text(
                    other.phone, color = AuraMuted, fontSize = 16.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp, start = 24.dp, end = 24.dp)
                )
            }
            Text(
                if (other.about.isBlank()) "Neler oluyor?" else other.about,
                color = if (other.about.isBlank()) auraLc(0xFF6B7280) else AuraWhite,
                fontSize = 16.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp, start = 24.dp, end = 24.dp)
            )
            Row(
                Modifier.fillMaxWidth().padding(top = 24.dp, start = 24.dp, end = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ActionTile(Icons.Default.Call, "Sesli", Modifier.weight(1f)) { onCall(false) }
                ActionTile(Icons.Default.Videocam, "Görüntülü", Modifier.weight(1f)) { onCall(true) }
                ActionTile(Icons.Default.Search, "Ara", Modifier.weight(1f)) { onSearch() }
            }

            Box(Modifier.padding(top = 24.dp).fillMaxWidth().height(1.dp).background(auraLc(0x99111B21)))
            // Medya bloğu
            Column(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 14.dp)) {
                Row(Modifier.fillMaxWidth().clickable { onMedia() }.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Medya, bağlantı ve belgeler", color = AuraWhite, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Text("${mediaImages.size}", color = AuraMuted, fontSize = 15.sp)
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = AuraMuted)
                }
                if (mediaImages.isNotEmpty()) {
                    val shown = mediaImages.take(20)
                    LazyRow(
                        Modifier.fillMaxWidth().padding(top = 12.dp),
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(shown.size) { i ->
                            DataUrlImage(
                                shown[i], 360,
                                Modifier.size(96.dp).clip(RoundedCornerShape(12.dp)).clickable { mediaViewer = i },
                                ContentScale.Crop
                            )
                        }
                    }
                }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(auraLc(0x99111B21)))

            InfoRow(
                if (flags.fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, auraLc(0xFFF472B6),
                if (flags.fav) "Favorilerden kaldır" else "Favorilere ekle"
            ) {
                if (!flags.exists) toast("Henüz mesajlaşılmamış bir sohbeti favorileyemezsin")
                else {
                    Repo.setFavorite(me.uid, target.chatId, !flags.fav)
                    toast(if (!flags.fav) "Favorilere eklendi" else "Favorilerden kaldırıldı")
                }
            }
            InfoRow(Icons.Default.Star, auraLc(0xFFFBBF24), "Yıldızlı mesajlar") { onStarred() }
            InfoRow(
                if (flags.muted) Icons.Default.Notifications else Icons.Default.NotificationsOff, auraLc(0xFFFBBF24),
                if (flags.muted) "Sohbetin sesini aç" else "Sohbeti sessize al"
            ) {
                if (flags.muted) { Repo.setMuted(me.uid, target.chatId, false); toast("Sohbetin sesi açıldı") }
                else showMute = true
            }
            InfoRow(Icons.Default.Palette, auraLc(0xFFF472B6), "Sohbet teması") { onTheme() }
            InfoRow(Icons.Default.HourglassTop, auraLc(0xFF7DD3FC), "Süreli mesajlar", "Yeni mesajlar için") { showDisappear = true }
            if (group != null && groupBody != null) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(auraLc(0x99111B21)))
                groupBody()
            }
            if (other.phone.isNotBlank()) {
                InfoRow(Icons.Default.ContentCopy, auraLc(0xFFD1D5DB), "Numarayı kopyala") {
                    clipboard.setText(AnnotatedString(other.phone))
                    toast("Numara kopyalandı")
                }
                InfoRow(Icons.Default.PhoneAndroid, auraLc(0xFFD1D5DB), "Telefonla ara") {
                    try {
                        ctx.startActivity(
                            Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + other.phone.filter { it.isDigit() || it == '+' }))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e: Throwable) { toast("Arama uygulaması açılamadı") }
                }
            }
            InfoRow(Icons.Default.Delete, auraLc(0xFFFB7185), "Sohbeti temizle", null, auraLc(0xFFFB7185)) { showWipe = true }
            if (group == null) InfoRow(
                Icons.Default.Block, auraLc(0xFFFB7185),
                if (isBlocked) "Engeli kaldır" else "Engelle", null,
                if (isBlocked) AuraWhite else auraLc(0xFFFB7185)
            ) {
                Repo.setBlocked(me.uid, target.otherUid, !isBlocked, target.chatId)
            }
            Spacer(Modifier.height(bottomSpace))
        }

        // ---------- Üst çubuk (şeffaf → kaydırınca dolar) ----------
        val bt = ((st - collapsePx * 0.6f) / (collapsePx * 0.4f)).coerceIn(0f, 1f)
        Box(Modifier.fillMaxWidth().height(sbDp + CI_BAR).background(AuraChatBg.copy(alpha = bt)))
        Row(
            Modifier.fillMaxWidth().padding(top = sbDp).height(CI_BAR).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Spacer(Modifier.weight(1f))
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = AuraWhite) }
                AuraDropdownMenu(
                    expanded = menu, onDismissRequest = { menu = false },
                    shape = RoundedCornerShape(16.dp), containerColor = auraC(0xFF233138), floating = true, yGap = 5.dp
                ) {
                    AuraMI(
                        text = { Text("Mesaj gönder", color = AuraWhite) },
                        onClick = { menu = false; onMessage() }
                    )
                    if (other.phone.isNotBlank()) {
                        AuraMI(
                            text = { Text("Numarayı kopyala", color = AuraWhite) },
                            onClick = {
                                menu = false
                                clipboard.setText(AnnotatedString(other.phone))
                                toast("Numara kopyalandı")
                            }
                        )
                    }
                }
            }
        }

        // ---------- Yüzen avatar (kaydırınca küçülüp okun yanına gider) ----------
        val avCx = lerpF(wPx / 2f, avCx1)
        val avCy = lerpF(sbPx + padTopPx + bigPx / 2f - st, sbPx + barPx / 2f)
        val avScale = lerpF(1f, smallPx / bigPx)
        Box(
            Modifier
                .size(AV_BIG)
                .graphicsLayer {
                    translationX = avCx - bigPx / 2f
                    translationY = avCy - bigPx / 2f
                    scaleX = avScale
                    scaleY = avScale
                }
                .pointerInput(other.avatar) {
                    detectTapGestures { if (other.avatar.isNotBlank()) viewer = Pair(listOf(other.avatar), 0) }
                }
                .pointerInput(Unit) {
                    // avatar sayfanın üstünde yüzdüğü için üstünden kaydırma da sayfayı kaydırsın
                    detectVerticalDragGestures { _, dy -> scroll.dispatchRawDelta(-dy) }
                }
        ) {
            // avatarın çevresinde sayfa zemini renginde halka (aydınlıkta beyaz, koyuda koyu)
            Box(Modifier.fillMaxSize().clip(CircleShape).background(AuraChatBg), contentAlignment = Alignment.Center) {
                Avatar(other.name, other.avatar, AV_BIG - 10.dp, isGroup = group != null)
            }
        }

        // ---------- Yüzen isim ----------
        val natural = nameSize.width.toFloat()
        val maxBig = wPx - gutterPx
        val maxSmall = (wPx - nameLeft1 - rightPx) / NAME_SCALE
        val nameW = max(40f, min(natural + 2f, min(maxBig, maxSmall)))
        val nameH = if (nameSize.height > 0) nameSize.height.toFloat() else with(density) { 32.dp.toPx() }
        val nameLeft0 = (wPx - nameW) / 2f
        val nameCy0 = sbPx + padTopPx + bigPx + namePadPx + nameH / 2f
        val nl = lerpF(nameLeft0, nameLeft1)
        val ncy = lerpF(nameCy0 - st, sbPx + barPx / 2f)
        val ns = lerpF(1f, NAME_SCALE)
        Text(
            other.name, fontSize = 24.sp, color = AuraWhite, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .width(with(density) { nameW.toDp() })
                .graphicsLayer {
                    translationX = nl
                    translationY = ncy - nameH / 2f
                    scaleX = ns
                    scaleY = ns
                    transformOrigin = TransformOrigin(0f, 0.5f)
                }
        )
    }

    if (showDisappear) {
        AuraAlertDialog(
            onDismissRequest = { showDisappear = false },
            containerColor = AuraSurface,
            title = { Text("Süreli mesajlar (yeni mesajlar için)", color = AuraWhite, fontSize = 17.sp) },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    listOf("Kapalı" to 0L, "24 saat" to 24 * 3600 * 1000L, "7 gün" to 7 * 24 * 3600 * 1000L, "90 gün" to 90L * 24 * 3600 * 1000L).forEach { (label, ms) ->
                        TextButton(onClick = {
                            showDisappear = false
                            Repo.setDisappearAfter(target.chatId, me.name, me.uid, ms)
                            toast(if (ms > 0) "Süreli mesajlar açıldı" else "Süreli mesajlar kapatıldı")
                        }) { Text(label, color = AuraGreen) }
                    }
                    TextButton(onClick = { showDisappear = false }) { Text("İptal", color = AuraMuted) }
                }
            }
        )
    }

    if (showWipe) {
        val st = starredIn(me.uid, listOf(target.chatId))
        var alsoStars by remember { mutableStateOf(false) }
        AuraAlertDialog(
            onDismissRequest = { showWipe = false },
            containerColor = AuraSurface,
            title = { Text("Bu sohbeti kalıcı olarak silmek üzeresiniz", color = AuraWhite, fontSize = 17.sp) },
            text = { if (st.isNotEmpty()) StarClearRow(alsoStars, st.size) { alsoStars = it } },
            confirmButton = {
                TextButton(onClick = {
                    showWipe = false
                    if (alsoStars) Repo.unstarAll(me.uid, st.map { it.key })
                    Repo.wipeChat(me.uid, target.chatId)
                    toast("Sohbet temizlendi")
                }) { Text("Sil", color = auraLc(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { showWipe = false }) { Text("İptal", color = AuraMuted) } }
        )
    }

    val v = viewer
    if (v != null) ImageViewer(v.first, v.second) { viewer = null }
    val mv = mediaViewer
    if (mv != null) {
        val tName = liveChatName(target)
        val vItems = mediaPairs.map { (src, m) ->
            ViewerItem(src, m.time, if (m.senderUid == me.uid) me.name else m.senderName.ifBlank { tName }, m.id, "", m.senderUid)
        }
        MessageImageViewer(
            me = me, target = target, items = vItems, startIndex = mv, album = false,
            msgFor = { id -> mediaMsgs.firstOrNull { it.id == id } },
            onForward = { m -> onForward(listOf(m)) }, onShowInChat = onShowInChat, onEdited = onEdited,
            onClose = { mediaViewer = null }
        )
    }
}

@Composable
private fun ActionTile(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(AuraSurface)
            .border(1.dp, auraLc(0x0FFFFFFF), RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, label, tint = auraLc(0xFFD1D7DB), modifier = Modifier.size(22.dp))
        Text(label, color = auraLc(0xFFD1D7DB), fontSize = 12.sp)
    }
}

@Composable
private fun InfoRow(
    icon: ImageVector,
    tint: Color,
    label: String,
    sub: String? = null,
    labelColor: Color = AuraWhite,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (tint == auraLc(0xFFFB7185)) tint else auraLc(0xFFD1D7DB), modifier = Modifier.size(24.dp))
        Column(Modifier.padding(start = 20.dp)) {
            Text(label, color = labelColor, fontSize = 16.sp)
            if (sub != null) Text(sub, color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

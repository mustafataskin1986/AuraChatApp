package com.aurachat.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

/**
 * Yerel mesaj veritabanı (SQLite): mesajlar telefonda saklanır.
 * - Bildirim geldiğinde servis mesajı buraya yazar
 * - Sohbet açılınca önce buradan anında okunur, Firestore dinleyicisi arkadan günceller
 * - İleride Drive yedeklemesi bu tablodan okunur
 * Büyük data: URL'ler (resim/ses/belge) saklanmaz; onlar LocalMedia dosyalarından gelir.
 */
object LocalDb {
    private var helper: Helper? = null

    private class Helper(ctx: Context) : SQLiteOpenHelper(ctx, "aura_msgs.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE msgs(chat TEXT NOT NULL, id TEXT NOT NULL, t INTEGER NOT NULL, j TEXT NOT NULL, PRIMARY KEY(chat,id))")
            db.execSQL("CREATE INDEX msgs_ct ON msgs(chat,t)")
        }
        override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}
    }

    fun init(ctx: Context) {
        if (helper == null) helper = Helper(ctx.applicationContext)
    }

    private fun strip(s: String) = if (s.startsWith("data:")) "" else s

    private fun toJson(m: Message): String {
        val o = JSONObject()
        o.put("id", m.id).put("type", m.type).put("text", m.text).put("su", m.senderUid).put("sn", m.senderName)
            .put("t", m.time).put("read", m.read).put("rb", JSONArray(m.readBy)).put("del", m.deleted)
            .put("df", JSONArray(m.deletedFor)).put("iu", strip(m.imageUrl))
            .put("imgs", JSONArray(m.images.map { strip(it) }.filter { it.isNotEmpty() })).put("ic", m.imagesCount)
            .put("au", strip(m.audio)).put("ad", m.audioDuration).put("lat", m.lat).put("lng", m.lng)
            .put("hl", m.hasLocation).put("fn", m.fileName).put("fm", m.fileMime)
            .put("ed", m.edited).put("fw", m.forwarded).put("cd", m.callDuration).put("ct", m.callType)
            .put("vo", m.viewOnce).put("q", m.question).put("pm", m.pollMulti)
            .put("men", JSONArray(m.mentions)).put("mn", JSONArray(m.mentionNames))
            .put("th", m.thumb).put("ths", JSONArray(m.thumbs)).put("pn", m.pinned).put("pa", m.pinnedAt).put("pu", m.pinUntil)
        m.replyTo?.let {
            o.put("rp", JSONObject().put("i", it.msgId).put("n", it.senderName).put("p", it.previewText)
                .put("u", it.senderUid).put("s", it.isStatus))
        }
        m.linkPreview?.let { o.put("lp", JSONObject().put("u", it.url).put("t", it.title).put("d", it.description).put("i", it.image)) }
        val r = JSONObject(); m.reactions.forEach { (k, v) -> r.put(k, v) }; o.put("re", r)
        o.put("po", JSONArray(m.pollOptions.map { JSONObject().put("i", it.id).put("t", it.text) }))
        val v = JSONObject(); m.votes.forEach { (k, l) -> v.put(k, JSONArray(l)) }; o.put("vt", v)
        return o.toString()
    }

    private fun strs(a: JSONArray?): List<String> =
        if (a == null) emptyList() else (0 until a.length()).map { a.optString(it) }

    fun parse(s: String): Message? = fromJson(s)

    private fun fromJson(s: String): Message? = try {
        val o = JSONObject(s)
        val rp = o.optJSONObject("rp")
        val re = o.optJSONObject("re")
        val vt = o.optJSONObject("vt")
        val po = o.optJSONArray("po")
        Message(
            id = o.getString("id"), type = o.optString("type"), text = o.optString("text"),
            senderUid = o.optString("su"), senderName = o.optString("sn"), time = o.optLong("t"),
            read = o.optBoolean("read"), readBy = strs(o.optJSONArray("rb")), deleted = o.optBoolean("del"),
            deletedFor = strs(o.optJSONArray("df")), pending = false, imageUrl = o.optString("iu"),
            images = strs(o.optJSONArray("imgs")).filter { it.isNotEmpty() }, imagesCount = o.optInt("ic"), audio = o.optString("au"),
            audioDuration = o.optInt("ad"), lat = o.optDouble("lat", 0.0), lng = o.optDouble("lng", 0.0),
            hasLocation = o.optBoolean("hl"), fileName = o.optString("fn"), fileMime = o.optString("fm"),
            replyTo = rp?.let { ReplyRef(it.optString("i"), it.optString("n"), it.optString("p"), it.optString("u"), it.optBoolean("s")) },
            reactions = re?.keys()?.asSequence()?.associateWith { k -> re.optString(k) } ?: emptyMap(),
            edited = o.optBoolean("ed"), forwarded = o.optBoolean("fw"), callDuration = o.optInt("cd"),
            callType = o.optString("ct"), viewOnce = o.optBoolean("vo"),
            question = o.optString("q"),
            pollOptions = if (po == null) emptyList() else (0 until po.length()).mapNotNull { i ->
                po.optJSONObject(i)?.let { PollOption(it.optString("i"), it.optString("t")) }
            },
            pollMulti = o.optBoolean("pm"),
            votes = vt?.keys()?.asSequence()?.associateWith { k -> strs(vt.optJSONArray(k)) } ?: emptyMap(),
            mentions = strs(o.optJSONArray("men")), mentionNames = strs(o.optJSONArray("mn")),
            thumb = o.optString("th"), thumbs = strs(o.optJSONArray("ths")),
            pinned = o.optBoolean("pn"), pinnedAt = o.optLong("pa"), pinUntil = o.optLong("pu"),
            linkPreview = o.optJSONObject("lp")?.let { LinkPreview(it.optString("u"), it.optString("t"), it.optString("d"), it.optString("i")) }
        )
    } catch (e: Throwable) { null }

    @Synchronized
    fun upsert(chatId: String, list: List<Message>) {
        val db = helper?.writableDatabase ?: return
        if (list.isEmpty()) return
        try {
            db.beginTransaction()
            for (m in list) {
                if (m.pending || m.id.isBlank()) continue
                val cv = ContentValues()
                cv.put("chat", chatId); cv.put("id", m.id); cv.put("t", m.time); cv.put("j", toJson(m))
                db.insertWithOnConflict("msgs", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("LocalDb", e) } finally {
            try { db.endTransaction() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("LocalDb", e) }
        }
    }

    /** Sunucudan tam gelen pencerede olmayan (silinmiş) mesajları yerelden de kaldırır */
    @Synchronized
    fun pruneWindow(chatId: String, fromTime: Long, keep: Set<String>) {
        val db = helper?.writableDatabase ?: return
        try {
            val c = db.rawQuery("SELECT id FROM msgs WHERE chat=? AND t>=?", arrayOf(chatId, fromTime.toString()))
            val del = ArrayList<String>()
            while (c.moveToNext()) { val id = c.getString(0); if (!keep.contains(id)) del.add(id) }
            c.close()
            del.forEach { db.delete("msgs", "chat=? AND id=?", arrayOf(chatId, it)) }
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("LocalDb", e) }
    }

    @Synchronized
    fun get(chatId: String, id: String): Message? {
        val db = helper?.readableDatabase ?: return null
        return try {
            val c = db.rawQuery("SELECT j FROM msgs WHERE chat=? AND id=?", arrayOf(chatId, id))
            val m = if (c.moveToFirst()) fromJson(c.getString(0)) else null
            c.close()
            m
        } catch (e: Throwable) { null }
    }

    @Synchronized
    fun recent(chatId: String, limit: Int): List<Message> {
        val db = helper?.readableDatabase ?: return emptyList()
        return try {
            val c = db.rawQuery("SELECT j FROM msgs WHERE chat=? ORDER BY t DESC LIMIT ?", arrayOf(chatId, limit.toString()))
            val out = ArrayList<Message>()
            while (c.moveToNext()) fromJson(c.getString(0))?.let { out.add(it) }
            c.close()
            out
        } catch (e: Throwable) { emptyList() }
    }

    /** Tüm sohbetlerde mesaj metni arar (en yeniden eskiye); sohbet listesindeki arama sonuçları için */
    @Synchronized
    fun search(q: String, limit: Int = 100): List<Pair<String, Message>> {
        val db = helper?.readableDatabase ?: return emptyList()
        val qs = q.trim().replace("%", "").replace("_", "")
        if (qs.isEmpty()) return emptyList()
        val tr = java.util.Locale("tr")
        val variants = linkedSetOf(qs, qs.lowercase(tr), qs.uppercase(tr), qs.lowercase(), qs.uppercase(), qs.replaceFirstChar { it.uppercase(tr) })
        return try {
            val where = variants.joinToString(" OR ") { "j LIKE ?" }
            val c = db.rawQuery("SELECT chat, j FROM msgs WHERE $where ORDER BY t DESC LIMIT 500", variants.map { "%$it%" }.toTypedArray())
            val out = ArrayList<Pair<String, Message>>()
            while (c.moveToNext() && out.size < limit) {
                val m = fromJson(c.getString(1)) ?: continue
                if (!m.deleted && m.text.contains(qs, ignoreCase = true)) out.add(c.getString(0) to m)
            }
            c.close()
            out
        } catch (e: Throwable) { emptyList() }
    }

    /** Arama sayfasındaki türe göre çipler: image, video, link, audio, document (en yeniden eskiye) */
    @Synchronized
    fun searchType(kind: String, q: String, limit: Int = 300): List<Pair<String, Message>> {
        val db = helper?.readableDatabase ?: return emptyList()
        val qs = q.trim()
        val where = when (kind) {
            "image" -> "j LIKE '%\"type\":\"image\"%'"
            "video" -> "j LIKE '%\"type\":\"video\"%'"
            "audio" -> "j LIKE '%\"type\":\"audio\"%'"
            "document" -> "j LIKE '%\"type\":\"document\"%'"
            "link" -> "(j LIKE '%\"lp\":%' OR j LIKE '%http%')"
            else -> return emptyList()
        }
        return try {
            val c = db.rawQuery("SELECT chat, j FROM msgs WHERE $where ORDER BY t DESC LIMIT 3000", null)
            val out = ArrayList<Pair<String, Message>>()
            while (c.moveToNext() && out.size < limit) {
                val m = fromJson(c.getString(1)) ?: continue
                if (m.deleted) continue
                val ok = when (kind) {
                    "image" -> m.type == "image" && !m.viewOnce
                    "video" -> m.type == "video"
                    "audio" -> m.type == "audio"
                    "document" -> m.type == "document"
                    else -> m.type == "text" && (m.linkPreview != null || Regex("https?://", RegexOption.IGNORE_CASE).containsMatchIn(m.text))
                }
                if (!ok) continue
                if (qs.isNotEmpty() && !(m.text.contains(qs, true) || m.fileName.contains(qs, true) || (m.linkPreview?.title ?: "").contains(qs, true))) continue
                out.add(c.getString(0) to m)
            }
            c.close()
            out
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("LocalDb", e); emptyList() }
    }

    /** Yedekleme: tüm satırlar [chat, id, t, json] */
    @Synchronized
    fun dumpAll(): List<Array<String>> {
        val db = helper?.readableDatabase ?: return emptyList()
        val out = ArrayList<Array<String>>()
        try {
            val c = db.rawQuery("SELECT chat,id,t,j FROM msgs ORDER BY chat,t", null)
            while (c.moveToNext()) out.add(arrayOf(c.getString(0), c.getString(1), c.getLong(2).toString(), c.getString(3)))
            c.close()
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("LocalDb", e) }
        return out
    }

    /** Geri yükleme: telefonda zaten olan mesajın üstüne yazmaz. Eklenen sayıyı döndürür */
    @Synchronized
    fun restoreRows(rows: List<Array<String>>): Int {
        val db = helper?.writableDatabase ?: return 0
        var n = 0
        try {
            db.beginTransaction()
            for (r in rows) {
                val cv = ContentValues()
                cv.put("chat", r[0]); cv.put("id", r[1]); cv.put("t", r[2].toLongOrNull() ?: 0L); cv.put("j", r[3])
                if (db.insertWithOnConflict("msgs", null, cv, SQLiteDatabase.CONFLICT_IGNORE) != -1L) n++
            }
            db.setTransactionSuccessful()
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("LocalDb", e) } finally {
            try { db.endTransaction() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("LocalDb", e) }
        }
        return n
    }

    @Synchronized
    fun clearChat(chatId: String) {
        try { helper?.writableDatabase?.delete("msgs", "chat=?", arrayOf(chatId)) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("LocalDb", e) }
    }
}

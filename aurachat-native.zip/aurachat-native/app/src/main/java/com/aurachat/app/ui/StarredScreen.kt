package com.aurachat.app.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.aurachat.app.data.LocalMedia
import com.aurachat.app.data.Media
import com.aurachat.app.data.Message
import com.aurachat.app.data.Repo
import com.aurachat.app.data.StarredItem
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val msgCache = java.util.concurrent.ConcurrentHashMap<String, Message>()

/** Yıldızlı mesajlar (WhatsApp düzeni): gönderen ▸ alan, tarih, altında gerçek mesaj balonu */
@Composable
fun StarredScreen(
    me: UserProfile,
    onBack: () -> Unit,
    onForward: (List<Message>) -> Unit,
    onOpen: (StarredItem) -> Unit
) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val starred by remember(me.uid) { Repo.starredFlow(me.uid) }.collectAsState(emptyList())
    val sorted = remember(starred) { starred.sortedByDescending { it.msgTime } }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var viewer by remember { mutableStateOf<Pair<List<String>, Int>?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val loaded = remember { mutableStateMapOf<String, Message>() }
    androidx.activity.compose.BackHandler(enabled = selected.isNotEmpty()) { selected = emptySet() }

    fun selMsgs(): List<Pair<StarredItem, Message>> =
        sorted.filter { selected.contains(it.key) }.mapNotNull { s -> loaded[s.key]?.let { s to it } }

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (selected.isNotEmpty()) selected = emptySet() else onBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White)
            }
            if (selected.isEmpty()) {
                Text("Yıldızlı mesajlar", color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(start = 6.dp))
            } else {
                Text("${selected.size}", color = Color.White, fontSize = 22.sp, modifier = Modifier.padding(start = 6.dp).weight(1f))
                IconButton(onClick = {
                    selMsgs().forEach { (s, _) -> Repo.unstarKey(me.uid, s.key) }
                    selected = emptySet()
                }) { Icon(Icons.Default.StarBorder, "Yıldızı kaldır", tint = Color.White) }
                IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, "Sil", tint = Color.White) }
                IconButton(onClick = {
                    val t = selMsgs().map { it.second.text }.filter { it.isNotBlank() }.joinToString("\n")
                    if (t.isNotBlank()) clipboard.setText(AnnotatedString(t))
                    selected = emptySet()
                }) { Icon(Icons.Default.ContentCopy, "Kopyala", tint = Color.White) }
                IconButton(onClick = {
                    val l = selMsgs().map { it.second }
                    selected = emptySet()
                    if (l.isNotEmpty()) onForward(l)
                }) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "İlet", tint = Color.White) }
            }
        }
        if (sorted.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Yıldızlı mesaj yok", color = AuraMuted) }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(sorted, key = { it.key }) { s ->
                    val ver = LocalMedia.version
                    val msg by produceState<Message?>(msgCache[s.key], s.key, ver) {
                        val raw = msgCache[s.key] ?: withContext(Dispatchers.IO) {
                            Repo.fetchMessageBlocking(s.chatId, s.msgId)?.also { msgCache[s.key] = it }
                        }
                        value = raw?.let { LocalMedia.localize(it) }
                        raw?.let { loaded[s.key] = it }
                    }
                    val isSel = selected.contains(s.key)
                    val m = msg
                    val mine = m?.senderUid == me.uid
                    val senderUid = m?.senderUid ?: ""
                    val prof by produceState<UserProfile?>(if (senderUid.isNotEmpty()) Repo.peekProfile(senderUid) else null, senderUid) {
                        if (senderUid.isNotEmpty()) value = Repo.profileOf(senderUid)
                    }
                    val from = if (mine) "Siz" else s.senderName.ifBlank { prof?.name?.ifBlank { null } ?: "Kullanıcı" }
                    val to = if (mine) s.chatName else if (s.chatName == from) "Siz" else s.chatName.ifBlank { "Siz" }
                    Column(
                        Modifier.fillMaxWidth().background(if (isSel) Color(0x4422C55E) else Color.Transparent)
                    ) {
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                if (selected.isNotEmpty()) selected = if (isSel) selected - s.key else selected + s.key else onOpen(s)
                            }.padding(start = 12.dp, end = 12.dp, top = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(if (mine) me.name else from, if (mine) me.avatar else (prof?.avatar ?: ""), 36.dp)
                            Text(from, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.padding(start = 10.dp))
                            Text("  ▸  ", color = AuraMuted, fontSize = 11.sp)
                            Text(to, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                            Spacer(Modifier.weight(1f))
                            Text(
                                if (s.msgTime > 0) SimpleDateFormat("dd.MM.yyyy", Locale("tr")).format(Date(s.msgTime)) else "",
                                color = AuraMuted, fontSize = 13.sp
                            )
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = AuraMuted, modifier = Modifier.size(18.dp))
                        }
                        if (m != null) {
                            MessageBubble(
                                m = m, me = me.uid, isGroup = false, starred = true, selected = false,
                                onClick = { if (selected.isNotEmpty()) selected = if (isSel) selected - s.key else selected + s.key else onOpen(s) },
                                onLongClick = { selected = if (isSel) selected - s.key else selected + s.key },
                                onQuoteClick = {},
                                onOpenImages = { l, i -> if (selected.isEmpty()) viewer = Pair(l, i) },
                                onOpenDocument = { dm ->
                                    try {
                                        val f = Media.sharableFile(ctx, dm.imageUrl, dm.fileName.ifBlank { "belge" })
                                        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                                        ctx.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, dm.fileMime.ifBlank { "*/*" })
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        })
                                    } catch (e: Throwable) {}
                                },
                                onOpenLocation = {}
                            )
                        } else {
                            Text(
                                s.preview, color = Color.White, fontSize = 15.sp, maxLines = 3, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp)
                            )
                        }
                        Box(Modifier.padding(top = 6.dp, start = 12.dp, end = 12.dp).fillMaxWidth().height(1.dp).background(Color(0xFF1B2329)))
                    }
                }
            }
        }
    }
    val v = viewer
    if (v != null) ImageViewer(v.first, v.second) { viewer = null }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = AuraSurface,
            title = { Text("Seçili mesajlar senden silinsin mi?", color = Color.White, fontSize = 17.sp) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    sorted.filter { selected.contains(it.key) }.forEach { s ->
                        Repo.deleteForMe(me.uid, s.chatId, s.msgId)
                        Repo.unstarKey(me.uid, s.key)
                    }
                    selected = emptySet()
                }) { Text("Sil", color = Color(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Vazgeç", color = AuraMuted) } }
        )
    }
}

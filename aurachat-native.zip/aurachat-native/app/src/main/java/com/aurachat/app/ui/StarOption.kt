package com.aurachat.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Repo
import com.aurachat.app.data.StarredItem

/** Verilen sohbetlerdeki yıldızlı mesajlar */
@Composable
fun starredIn(meUid: String, chatIds: Collection<String>): List<StarredItem> {
    val all by remember(meUid) { Repo.starredFlow(meUid) }.collectAsState(emptyList())
    return all.filter { it.chatId in chatIds }
}

/** Sohbeti temizle / sil uyarısındaki "Yıldızlı mesajları temizle" kutusu (varsayılan işaretsiz: yıldızlılar yıldızlı mesajlar sayfasında kalır) */
@Composable
fun StarClearRow(checked: Boolean, count: Int, onChange: (Boolean) -> Unit) {
    Column {
        Row(Modifier.clickable { onChange(!checked) }.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = onChange, colors = CheckboxDefaults.colors(checkedColor = AuraGreen, uncheckedColor = AuraMuted))
            Text("Yıldızlı mesajları temizle ($count)", color = AuraWhite, fontSize = 15.sp)
        }
        Text(
            if (checked) "Yıldızlı mesajlar da silinir." else "Yıldızlı mesajlar, Yıldızlı mesajlar sayfasında kalır.",
            color = AuraMuted, fontSize = 13.sp, modifier = Modifier.padding(start = 12.dp, top = 2.dp)
        )
    }
}

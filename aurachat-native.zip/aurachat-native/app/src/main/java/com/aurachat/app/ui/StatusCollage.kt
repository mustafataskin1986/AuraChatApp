package com.aurachat.app.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Media
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

// =====================================================================
//  YERLEŞİM (kolaj): 6 fotoğrafa kadar, hazır ızgara düzenleri
// =====================================================================
private class CRect(val x: Float, val y: Float, val w: Float, val h: Float)

private class CTemplate(val cells: List<CRect>, val lines: List<FloatArray>)

private val CollageTemplates: List<CTemplate> = listOf(
    CTemplate(
        listOf(CRect(0f, 0f, .5f, .5f), CRect(.5f, 0f, .5f, .5f), CRect(0f, .5f, .5f, .5f), CRect(.5f, .5f, .5f, .5f)),
        listOf(floatArrayOf(12f, 4f, 12f, 20f), floatArrayOf(4f, 12f, 20f, 12f))
    ),
    CTemplate(
        listOf(CRect(0f, 0f, 1f, 1f / 3), CRect(0f, 1f / 3, 1f, 1f / 3), CRect(0f, 2f / 3, 1f, 1f / 3)),
        listOf(floatArrayOf(4f, 9.3f, 20f, 9.3f), floatArrayOf(4f, 14.7f, 20f, 14.7f))
    ),
    CTemplate(
        listOf(CRect(0f, 0f, 1f, .5f), CRect(0f, .5f, .5f, .5f), CRect(.5f, .5f, .5f, .5f)),
        listOf(floatArrayOf(4f, 12f, 20f, 12f), floatArrayOf(12f, 12f, 12f, 20f))
    ),
    CTemplate(
        listOf(CRect(0f, 0f, 1f, .5f), CRect(0f, .5f, 1f, .5f)),
        listOf(floatArrayOf(4f, 12f, 20f, 12f))
    ),
    CTemplate(
        listOf(CRect(0f, 0f, .5f, .5f), CRect(.5f, 0f, .5f, .5f), CRect(0f, .5f, 1f / 3, .5f), CRect(1f / 3, .5f, 1f / 3, .5f), CRect(2f / 3, .5f, 1f / 3, .5f)),
        listOf(floatArrayOf(4f, 12f, 20f, 12f), floatArrayOf(12f, 4f, 12f, 12f), floatArrayOf(9.3f, 12f, 9.3f, 20f), floatArrayOf(14.7f, 12f, 14.7f, 20f))
    ),
    CTemplate(
        listOf(
            CRect(0f, 0f, .5f, 1f / 3), CRect(.5f, 0f, .5f, 1f / 3), CRect(0f, 1f / 3, .5f, 1f / 3),
            CRect(.5f, 1f / 3, .5f, 1f / 3), CRect(0f, 2f / 3, .5f, 1f / 3), CRect(.5f, 2f / 3, .5f, 1f / 3)
        ),
        listOf(floatArrayOf(12f, 4f, 12f, 20f), floatArrayOf(4f, 9.3f, 20f, 9.3f), floatArrayOf(4f, 14.7f, 20f, 14.7f))
    )
)

private class CSlot(val bmp: Bitmap) {
    var scale by mutableFloatStateOf(1f)
    var panX by mutableFloatStateOf(0f)
    var panY by mutableFloatStateOf(0f)
}

private fun autoLayout(count: Int) = when {
    count >= 6 -> 5
    count == 5 -> 4
    count == 4 -> 0
    count == 3 -> 1
    else -> 3
}

private suspend fun loadSlotBitmap(ctx: android.content.Context, u: Uri): Bitmap? = withContext(Dispatchers.IO) {
    val d = Media.compress(ctx, u, 300 * 1024) ?: return@withContext null
    Media.decode(d, 1600)
}

// =====================================================================
//  1) FOTOĞRAF SEÇİMİ ("Yerleşim oluşturun", en fazla 6)
// =====================================================================
@Composable
fun StatusLayoutPicker(onClose: () -> Unit, onDone: (List<Uri>) -> Unit) {
    var album by remember { mutableStateOf<String?>(null) }
    var albums by remember { mutableStateOf<List<Pair<String, Int>>>(emptyList()) }
    var albumMenu by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<List<Uri>>(emptyList()) }
    val ctx = LocalContext.current
    BackHandler { onClose() }
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(auraLc(0x8C000000)).clickable { onClose() })
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxSize().statusBarsPadding().padding(top = 10.dp)
                .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)).background(auraC(0xFF1A1F24))
        ) {
            Box(Modifier.fillMaxWidth().padding(top = 10.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.width(40.dp).height(4.dp).clip(CircleShape).background(auraLc(0xFF6B7280)))
            }
            Box(Modifier.fillMaxWidth().padding(top = 10.dp).height(48.dp)) {
                IconButton(onClick = onClose, modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp)) {
                    Icon(Icons.Default.Close, "Kapat", tint = AuraWhite)
                }
                Text("Yerleşim oluşturun", color = AuraWhite, fontSize = 22.sp, modifier = Modifier.align(Alignment.Center))
            }
            Text(
                "Yerleşiminiz için 6 adede kadar fotoğraf seçin.", color = AuraWhite, fontSize = 17.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 18.dp)
            )
            Box(Modifier.padding(start = 20.dp, bottom = 10.dp)) {
                Row(Modifier.clip(RoundedCornerShape(10.dp)).clickable { albumMenu = true }.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(album ?: "Son kullanılanlar", color = auraLc(0xFFD1D5DB), fontSize = 22.sp, fontWeight = FontWeight.Medium)
                    Icon(Icons.Default.KeyboardArrowDown, null, tint = auraLc(0xFFD1D5DB), modifier = Modifier.padding(start = 6.dp).size(26.dp))
                }
                AuraDropdownMenu(expanded = albumMenu, onDismissRequest = { albumMenu = false }, containerColor = AuraSurface, alignEnd = false) {
                    DropdownMenuItem(text = { Text("Son kullanılanlar", color = AuraWhite) }, onClick = { album = null; albumMenu = false })
                    albums.forEach { (n, c) ->
                        DropdownMenuItem(text = { Text("$n  ($c)", color = AuraWhite) }, onClick = { album = n; albumMenu = false })
                    }
                }
            }
            GalleryStrip(
                accent = Color(0xFF25D366), maxPick = 6, selected = selected, onSelected = { selected = it },
                modifier = Modifier.weight(1f), grid = true, album = album, onAlbums = { albums = it }, columns = 3
            )
            if (selected.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFF1A1F24)).navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        itemsIndexed(selected) { _, u ->
                            val bm by androidx.compose.runtime.produceState<Bitmap?>(null, u) { value = withContext(Dispatchers.IO) { loadThumb(ctx, u) } }
                            Box(Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF2B3036)).clickable { selected = selected - u }) {
                                bm?.let { Image(bitmap = it.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                            }
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.size(56.dp).clip(CircleShape).background(Color(0xFF25D366)).clickable { onDone(selected) }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Check, "Tamam", tint = Color(0xFF0B141A))
                    }
                }
            }
        }
    }
}

// =====================================================================
//  2) KOLAJ DÜZENLEYİCİ
// =====================================================================
@Composable
fun StatusCollageEditor(uris: List<Uri>, onBack: () -> Unit, onDone: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dens = LocalDensity.current
    val slots = remember { mutableStateListOf<CSlot?>(null, null, null, null, null, null) }
    var loading by remember { mutableStateOf(true) }
    var layoutIdx by remember { mutableIntStateOf(autoLayout(uris.size.coerceAtMost(6))) }
    var exporting by remember { mutableStateOf(false) }
    var pendingSlot by remember { mutableIntStateOf(-1) }
    var dragFrom by remember { mutableIntStateOf(-1) }
    var dragPos by remember { mutableStateOf(Offset.Zero) }
    var dropTo by remember { mutableIntStateOf(-1) }

    androidx.compose.runtime.LaunchedEffect(uris) {
        uris.take(6).forEachIndexed { i, u -> loadSlotBitmap(ctx, u)?.let { slots[i] = CSlot(it) } }
        loading = false
    }

    val single = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        val at = pendingSlot
        pendingSlot = -1
        if (u != null && at in 0..5) scope.launch { loadSlotBitmap(ctx, u)?.let { slots[at] = CSlot(it) } }
    }

    BackHandler { onBack() }

    Box(Modifier.fillMaxSize().background(Color(0xFF0B141A)).statusBarsPadding().navigationBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().height(62.dp).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color(0xFFE9EDEF)) }
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier.clip(RoundedCornerShape(22.dp)).background(Color.White).clickable(enabled = !exporting && !loading) {
                        exporting = true
                        val tpl = CollageTemplates[layoutIdx]
                        val list = slots.toList()
                        scope.launch {
                            val d = withContext(Dispatchers.Default) { renderCollage(tpl, list, boardWRef, boardHRef) }
                            exporting = false
                            if (d != null) onDone(d)
                        }
                    }.padding(horizontal = 22.dp, vertical = 9.dp)
                ) { Text("Bitti", color = Color(0xFF0B141A), fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
            }

            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp), contentAlignment = Alignment.Center) {
                val availW = constraints.maxWidth.toFloat()
                val availH = constraints.maxHeight.toFloat()
                val bw = minOf(availW, availH * 9f / 16f)
                val bh = bw * 16f / 9f
                boardWRef = bw; boardHRef = bh
                val tpl = CollageTemplates[layoutIdx]
                Box(
                    Modifier.size(with(dens) { bw.toDp() }, with(dens) { bh.toDp() }).clip(RoundedCornerShape(14.dp)).background(Color(0xFF111111))
                ) {
                    tpl.cells.forEachIndexed { idx, r ->
                        val cx = r.x * bw; val cy = r.y * bh; val cw = r.w * bw; val ch = r.h * bh
                        val slot = slots[idx]
                        Box(
                            Modifier
                                .offset { IntOffset(cx.roundToInt(), cy.roundToInt()) }
                                .size(with(dens) { cw.toDp() }, with(dens) { ch.toDp() })
                                .alpha(if (dragFrom == idx) 0.28f else 1f)
                                .background(Color(0xFF202020))
                                .border(0.5.dp, Color(0xFF111111))
                                .clipToBounds()
                        ) {
                            if (slot == null) {
                                Box(
                                    Modifier.fillMaxSize().clickable { pendingSlot = idx; single.launch("image/*") },
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.AddPhotoAlternate, "Ekle", tint = Color(0xFF7C7C7C), modifier = Modifier.size(30.dp)) }
                            } else {
                                val img = remember(slot) { slot.bmp.asImageBitmap() }
                                Canvas(
                                    Modifier.fillMaxSize()
                                        .pointerInput(slot, layoutIdx) {
                                            detectTransformGestures { _, pan, zoom, _ ->
                                                slot.scale = (slot.scale * zoom).coerceIn(1f, 4f)
                                                slot.panX += pan.x; slot.panY += pan.y
                                            }
                                        }
                                        .pointerInput(slot, layoutIdx, bw, bh) {
                                            detectDragGesturesAfterLongPress(
                                                onDragStart = { o -> dragFrom = idx; dragPos = Offset(cx, cy) + o; dropTo = -1 },
                                                onDrag = { c, d ->
                                                    c.consume()
                                                    dragPos += d
                                                    var hit = -1
                                                    tpl.cells.forEachIndexed { j, rr ->
                                                        if (j != idx && dragPos.x >= rr.x * bw && dragPos.x <= (rr.x + rr.w) * bw && dragPos.y >= rr.y * bh && dragPos.y <= (rr.y + rr.h) * bh) hit = j
                                                    }
                                                    dropTo = hit
                                                },
                                                onDragEnd = {
                                                    if (dropTo >= 0 && dropTo != idx) {
                                                        val t = slots[idx]; slots[idx] = slots[dropTo]; slots[dropTo] = t
                                                    }
                                                    dragFrom = -1; dropTo = -1
                                                },
                                                onDragCancel = { dragFrom = -1; dropTo = -1 }
                                            )
                                        }
                                ) {
                                    val w = size.width; val h = size.height
                                    val nw = slot.bmp.width; val nh = slot.bmp.height
                                    val base = max(w / nw, h / nh)
                                    val dw = nw * base * slot.scale; val dh = nh * base * slot.scale
                                    val mx = max(0f, (dw - w) / 2); val my = max(0f, (dh - h) / 2)
                                    val px = slot.panX.coerceIn(-mx, mx); val py = slot.panY.coerceIn(-my, my)
                                    drawImage(
                                        img, srcSize = IntSize(nw, nh),
                                        dstOffset = IntOffset(((w - dw) / 2 + px).roundToInt(), ((h - dh) / 2 + py).roundToInt()),
                                        dstSize = IntSize(dw.roundToInt(), dh.roundToInt())
                                    )
                                }
                            }
                            if (dropTo == idx) Box(Modifier.fillMaxSize().background(Color(0x2925D366)).border(2.5.dp, Color(0xFF25D366)))
                        }
                    }
                    // sürüklenen kart
                    val from = dragFrom
                    val fs = if (from >= 0) slots[from] else null
                    if (from >= 0 && fs != null) {
                        val gr = tpl.cells[from]
                        val gw = gr.w * bw * 0.85f; val gh = gr.h * bh * 0.85f
                        Box(
                            Modifier
                                .offset { IntOffset((dragPos.x - gw / 2).roundToInt(), (dragPos.y - gh / 2).roundToInt()) }
                                .size(with(dens) { gw.toDp() }, with(dens) { gh.toDp() })
                                .shadow(12.dp, RoundedCornerShape(12.dp)).clip(RoundedCornerShape(12.dp)).alpha(0.94f).background(Color.Black)
                        ) {
                            Image(bitmap = fs.bmp.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        }
                    }
                }
            }

            // alt: ızgara seçici
            Row(
                Modifier.fillMaxWidth().height(82.dp).padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically
            ) {
                CollageTemplates.forEachIndexed { i, t ->
                    val on = i == layoutIdx
                    val fg = if (on) Color(0xFF0B141A) else Color(0xFFE9EDEF)
                    Box(
                        Modifier.size(46.dp).clip(CircleShape).background(if (on) Color.White else Color.Transparent).clickable { layoutIdx = i },
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(Modifier.size(24.dp)) {
                            val k = size.width / 24f
                            drawRoundRect(fg, topLeft = Offset(4f * k, 4f * k), size = androidx.compose.ui.geometry.Size(16f * k, 16f * k), cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.5f * k), style = Stroke(1.8f * k))
                            t.lines.forEach { l -> drawLine(fg, Offset(l[0] * k, l[1] * k), Offset(l[2] * k, l[3] * k), strokeWidth = 1.6f * k, cap = StrokeCap.Butt) }
                        }
                    }
                }
            }
        }
        if (loading || exporting) Box(Modifier.fillMaxSize().background(Color(0x66000000)).clickable(enabled = true) { }, contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White)
        }
    }
}

// tahtanın piksel ölçüsü (dışa aktarımda kaydırma oranı için)
private var boardWRef = 1f
private var boardHRef = 1f

private fun renderCollage(tpl: CTemplate, slots: List<CSlot?>, bw: Float, bh: Float): String? = try {
    val outW = 1080; val outH = 1920
    val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(out)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG)
    c.drawColor(0xFF111111.toInt())
    val rx = outW / bw.coerceAtLeast(1f); val ry = outH / bh.coerceAtLeast(1f)
    tpl.cells.forEachIndexed { i, r ->
        val cx = r.x * outW; val cy = r.y * outH; val cw = r.w * outW; val ch = r.h * outH
        val s = slots.getOrNull(i)
        if (s == null) {
            p.color = 0xFF202020.toInt(); c.drawRect(cx, cy, cx + cw, cy + ch, p)
        } else {
            c.save()
            c.clipRect(cx, cy, cx + cw, cy + ch)
            val nw = s.bmp.width; val nh = s.bmp.height
            val base = max(cw / nw, ch / nh)
            val dw = nw * base * s.scale; val dh = nh * base * s.scale
            // ekrandaki kaydırma sınırı (hücre piksel ölçüsüne göre) ile aynı kısıtlama
            val bcw = r.w * bw; val bch = r.h * bh
            val bBase = max(bcw / nw, bch / nh)
            val bdw = nw * bBase * s.scale; val bdh = nh * bBase * s.scale
            val mx = max(0f, (bdw - bcw) / 2); val my = max(0f, (bdh - bch) / 2)
            val px = s.panX.coerceIn(-mx, mx) * rx; val py = s.panY.coerceIn(-my, my) * ry
            val dx = cx + (cw - dw) / 2 + px; val dy = cy + (ch - dh) / 2 + py
            c.drawBitmap(s.bmp, null, android.graphics.RectF(dx, dy, dx + dw, dy + dh), p)
            c.restore()
        }
    }
    val bo = java.io.ByteArrayOutputStream()
    out.compress(Bitmap.CompressFormat.JPEG, 86, bo)
    "data:image/jpeg;base64," + android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP)
} catch (e: Throwable) { null }

package com.aurachat.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

val AuraGreen = Color(0xFF22C55E)
val AuraBg = Color(0xFF000000)
val AuraSurface = Color(0xFF1B1F21)
val AuraMine = Color(0xFF0F5A36)
val AuraTheirs = Color(0xFF26292B)
val AuraMuted = Color(0xFF9AA3A8)

private val scheme = darkColorScheme(
    primary = AuraGreen,
    onPrimary = Color.Black,
    background = AuraBg,
    surface = AuraSurface,
    onBackground = Color.White,
    onSurface = Color.White,
    surfaceVariant = AuraSurface
)

@Composable
fun AuraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}

fun formatListTime(ms: Long): String {
    if (ms <= 0L) return ""
    val now = Calendar.getInstance()
    val t = Calendar.getInstance().apply { timeInMillis = ms }
    val sameDay = now.get(Calendar.YEAR) == t.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == t.get(Calendar.DAY_OF_YEAR)
    val pattern = if (sameDay) "HH:mm" else "dd.MM.yyyy"
    return SimpleDateFormat(pattern, Locale("tr")).format(Date(ms))
}

fun formatClock(ms: Long): String =
    if (ms <= 0L) "" else SimpleDateFormat("HH:mm", Locale("tr")).format(Date(ms))

// ---------- Avatar (web sürümünde base64 data URL olarak saklanıyor) ----------
private val bitmapCache = LruCache<String, Bitmap>(80)

private fun decodeAvatar(data: String): Bitmap? {
    val key = data.length.toString() + ":" + data.hashCode()
    bitmapCache.get(key)?.let { return it }
    return try {
        val b64 = if (data.contains(",")) data.substringAfter(",") else data
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 256) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)?.also { bitmapCache.put(key, it) }
    } catch (e: Throwable) {
        null
    }
}

private val palette = listOf(0xFF3B82F6, 0xFFEF4444, 0xFFF59E0B, 0xFF8B5CF6, 0xFFEC4899, 0xFF14B8A6, 0xFFF97316)

@Composable
fun Avatar(name: String, avatar: String?, size: Dp = 48.dp) {
    val bmp by produceState<Bitmap?>(null, avatar) {
        value = if (avatar.isNullOrBlank()) null else withContext(Dispatchers.Default) { decodeAvatar(avatar) }
    }
    val shape = CircleShape
    val b = bmp
    if (b != null) {
        Image(
            bitmap = b.asImageBitmap(),
            contentDescription = name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(shape)
        )
    } else {
        val color = Color(palette[(name.hashCode() and 0x7fffffff) % palette.size])
        Box(Modifier.size(size).clip(shape).background(color), contentAlignment = Alignment.Center) {
            val initials = name.trim().split(" ").filter { it.isNotEmpty() }.take(2)
                .joinToString("") { it.first().uppercase() }.ifEmpty { "?" }
            Text(initials, color = Color.White, fontSize = (size.value * 0.4f).sp)
        }
    }
}

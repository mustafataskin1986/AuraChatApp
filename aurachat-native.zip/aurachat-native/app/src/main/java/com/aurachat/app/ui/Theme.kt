package com.aurachat.app.ui

import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Groups
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import com.aurachat.app.data.Media
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Eski web sürümündeki renkler (Tailwind): emerald-500/600/400, #005c4b, #212121, #202c33, #0b141a */
val AuraGreen: Color get() = lm(Color(0xFF10B981))      // emerald-500: başlık, vurgu, bağlantı
val AuraBtn: Color get() = lm(Color(0xFF059669))       // emerald-600: gönder/mikrofon, aktif çip
val AuraBorder: Color get() = lm(Color(0xFF22C55E))    // yazı kutusu kenarlığı
val AuraBg: Color get() = lm(Color(0xFF000000))
val AuraChatBg: Color get() = lm(if (AuraUi.black) Color.Black else Color(0xFF0B141A))
val AuraSurface: Color get() = lm(if (AuraUi.black) Color(0xFF121212) else Color(0xFF202C33))
val AuraMine: Color get() = lm(Color(0xFF005C4B))
val AuraTheirs: Color get() = lm(Color(0xFF212121))
val AuraMuted: Color get() = lm(Color(0xFF9CA3AF))     // gray-400
val AuraTick: Color get() = lm(Color(0xFF53BDEB))

// Ham (açık temada dönüştürülmeyen) karşılıklar: görüntüleyici, arama gibi hep koyu ekranlar için
val AuraRawGreen = Color(0xFF10B981)
val AuraRawBtn = Color(0xFF059669)
val AuraRawBorder = Color(0xFF22C55E)
val AuraRawBg = Color(0xFF000000)
val AuraRawChatBg: Color get() = if (AuraUi.black) Color.Black else Color(0xFF0B141A)
val AuraRawSurface: Color get() = if (AuraUi.black) Color(0xFF121212) else Color(0xFF202C33)
val AuraRawMine = Color(0xFF005C4B)
val AuraRawTheirs = Color(0xFF212121)
val AuraRawMuted = Color(0xFF9CA3AF)
val AuraRawTick = Color(0xFF53BDEB)
fun auraRaw(v: Long): Color = Color(v)

/** Açık temada koyu paletin karşılığı (parlaklık ters, ton korunur). Gerçek açık tema: filtre yok, resimler ham kalır */
/** WhatsApp açık teması: bilinen koyu renklerin birebir açık karşılıkları */
private val lightMap: Map<Int, Int> = mapOf(
    0x000000 to 0xFFFFFF,   // ekran zemini
    0xFFFFFF to 0x111B21,   // yazı
    0x121212 to 0xF0F2F5,   // kart / menü yüzeyi
    0x202C33 to 0xF0F2F5,
    0x1F2C34 to 0xF0F2F5,
    0x1F2C33 to 0xF0F2F5,
    0x111B21 to 0xFFFFFF,
    0x233138 to 0xFFFFFF,
    0x0B141A to 0xEFEAE2,   // sohbet zemini
    0x1B252B to 0xF0F2F5,
    0x2A3942 to 0xD1D7DB,
    0x2A3239 to 0xD1D7DB,
    0x2A2F31 to 0xE9EDEF,
    0x005C4B to 0xD9FDD3,   // giden balon
    0x212121 to 0xFFFFFF,   // gelen balon
    0x9CA3AF to 0x667781,   // ikincil yazı
    0x8696A0 to 0x667781,
    0xD1D7DB to 0x54656F,   // simge gri
    0x9AA3A9 to 0x54656F,
    0x8A9096 to 0x8696A0,
    0x10B981 to 0x00A884,   // vurgu yeşili
    0x059669 to 0x00A884,
    0x22C55E to 0x00A884
)

fun lm(c: Color): Color {
    if (!AuraUi.light) return c
    val key = ((c.red * 255f + 0.5f).toInt() shl 16) or ((c.green * 255f + 0.5f).toInt() shl 8) or (c.blue * 255f + 0.5f).toInt()
    val hit = lightMap[key]
    if (hit != null) return Color(0xFF000000.toInt() or hit).copy(alpha = c.alpha)
    val r = c.red; val g = c.green; val b = c.blue
    fun cl(v: Float) = v.coerceIn(0f, 1f)
    return Color(
        cl(0.574f * r - 1.430f * g - 0.144f * b + 1f),
        cl(-0.426f * r - 0.430f * g - 0.144f * b + 1f),
        cl(-0.426f * r - 1.430f * g + 0.856f * b + 1f),
        c.alpha
    )
}
private fun hsl(c: Color): FloatArray {
    val r = c.red; val g = c.green; val b = c.blue
    val mx = maxOf(r, g, b); val mn = minOf(r, g, b)
    val l = (mx + mn) / 2f
    val d = mx - mn
    if (d < 1e-4f) return floatArrayOf(0f, 0f, l)
    val sat = d / (1f - kotlin.math.abs(2f * l - 1f))
    val h = when (mx) {
        r -> ((g - b) / d) % 6f
        g -> (b - r) / d + 2f
        else -> (r - g) / d + 4f
    } * 60f
    return floatArrayOf(if (h < 0) h + 360f else h, sat.coerceIn(0f, 1f), l)
}

private fun fromHsl(h: Float, s: Float, l: Float): Color {
    val c = (1f - kotlin.math.abs(2f * l - 1f)) * s
    val x = c * (1f - kotlin.math.abs((h / 60f) % 2f - 1f))
    val m = l - c / 2f
    val (r, g, b) = when {
        h < 60f -> Triple(c, x, 0f)
        h < 120f -> Triple(x, c, 0f)
        h < 180f -> Triple(0f, c, x)
        h < 240f -> Triple(0f, x, c)
        h < 300f -> Triple(x, 0f, c)
        else -> Triple(c, 0f, x)
    }
    return Color(r + m, g + m, b + m)
}

private fun isDefaultGreen(c: Color): Boolean {
    val k = ((c.red * 255f + 0.5f).toInt() shl 16) or ((c.green * 255f + 0.5f).toInt() shl 8) or (c.blue * 255f + 0.5f).toInt()
    return k == 0x005C4B || k == 0x1F6F5C
}

/** Her renk çiftinin koyu olanı: açık temada solgun (pastel) balon olur; diğerleri WhatsApp gibi doygun kalır */
private val paleKeys = setOf(
    0x0d4a30, 0x092e5c, 0x2c2463, 0x0c3b52, 0x532168, 0x3b3d3e, 0x532b20, 0x29362a, 0x064643, 0x631026, 0x3f2716,
    0x43372b, 0x065248, 0x736000, 0x395217, 0x691b3b, 0x6f1127, 0x5c130b, 0x584b23, 0x1a3a8a
)

/** Giden balon rengi: koyuda seçilen renk; açıkta WhatsApp gibi ya doygun ton (beyaz yazılı) ya da aynı tonun pastel hâli (varsayılan: #D9FDD3) */
fun bubbleOf(c: Color): Color {
    if (!AuraUi.light) return c
    if (isDefaultGreen(c)) return Color(0xFFD9FDD3)
    val k = ((c.red * 255f + 0.5f).toInt() shl 16) or ((c.green * 255f + 0.5f).toInt() shl 8) or (c.blue * 255f + 0.5f).toInt()
    val h = hsl(c)
    if (k in paleKeys) return fromHsl(h[0], h[1].coerceIn(0.45f, 0.9f), 0.89f)
    return fromHsl(h[0], if (h[1] < 0.2f) h[1] else h[1].coerceIn(0.5f, 0.85f), h[2].coerceIn(0.38f, 0.46f))
}

/** Açık temada doygun (koyu) giden balonun içeriği koyu temadaki beyaz yazı renkleriyle çizilir */
@androidx.compose.runtime.Composable
fun DeepBubbleScope(bubble: Color, content: @androidx.compose.runtime.Composable () -> Unit) {
    val deep = AuraUi.light && bubble.luminance() < 0.45f
    if (deep) {
        AuraUi.forceDark = true
        try { content() } finally { AuraUi.forceDark = false }
    } else content()
}

/** Vurgu (gönder düğmesi, kenarlık, seçim): açıkta rengin koyuluğu çok düşükse biraz açılır (varsayılan: #00A884) */
/** Açık temada rengin çok soluk tonu (zemin / üst çubuk boyası); koyuda aynen döner */
fun paleTint(c: Color, l: Float): Color {
    val h = hsl(c)
    return fromHsl(h[0], h[1].coerceIn(0.5f, 0.9f), l)
}

fun accentOf(c: Color): Color {
    if (!AuraUi.light) return c
    if (isDefaultGreen(c)) return Color(0xFF00A884)
    val h = hsl(c)
    return fromHsl(h[0], h[1], h[2].coerceIn(0.38f, 0.5f))
}

fun auraCRaw(normal: Long): Color =
    if (!AuraUi.black) Color(normal) else if (normal == 0xFF0B141AL) Color.Black else Color(0xFF121212)
fun auraLc(v: Long): Color = lm(Color(v))
/** Balon içindeki çerçeve / yuva zemini: koyuda siyah gölge, açıkta belirgin hafif gri */
val AuraFrame: Color get() = if (AuraUi.light) Color(0x1F000000) else Color(0x33000000)
val AuraWhite: Color get() = lm(Color.White)
val AuraBlack: Color get() = lm(Color.Black)

/** Arayüz anahtarı: koyu (varsayılan, saf siyah) / aydınlık. Aydınlık mod, koyu renklerin parlaklığını ters çevirir (renk tonu korunur) */
object AuraUi {
    /** Eskiden "siyah / lacivert" idi; artık renk değerleri hep siyah tabanlıdır */
    val black: Boolean get() = true

    /** 0 = koyu, 1 = açık, 2 = sistem (Android temasını izler) */
    var mode by androidx.compose.runtime.mutableIntStateOf(0)
        private set
    var systemDark by androidx.compose.runtime.mutableStateOf(true)
    /** Açık temada koyu (doygun) giden balonun içi için geçici olarak koyu renkleri açar; bkz. DeepBubbleScope */
    var forceDark = false
    val light: Boolean get() = !forceDark && (mode == 1 || (mode == 2 && !systemDark))

    fun load(ctx: android.content.Context) {
        val sp = ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE)
        mode = if (sp.contains("theme_mode")) sp.getInt("theme_mode", 0) else if (sp.getBoolean("light_ui", false)) 1 else 0
        systemDark = (ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) != android.content.res.Configuration.UI_MODE_NIGHT_NO
    }

    fun setMode(ctx: android.content.Context, m: Int) {
        mode = m.coerceIn(0, 2)
        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putInt("theme_mode", mode).apply()
    }

    /** Koyu -> Açık -> Sistem -> Koyu */
    fun toggle(ctx: android.content.Context): String {
        mode = (mode + 1) % 3
        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putInt("theme_mode", mode).apply()
        return when (mode) { 0 -> "Koyu tema"; 1 -> "Açık tema"; else -> "Sistem teması" }
    }
}

/** invert(1) hue-rotate(180°): parlaklığı ters çevirir, renk tonunu korur. Kendi tersidir (iki kez uygulanırsa özgün renk). */
val AuraInvertFilter: androidx.compose.ui.graphics.ColorFilter = androidx.compose.ui.graphics.ColorFilter.colorMatrix(
    androidx.compose.ui.graphics.ColorMatrix(
        floatArrayOf(
            0.574f, -1.430f, -0.144f, 0f, 255f,
            -0.426f, -0.430f, -0.144f, 0f, 255f,
            -0.426f, -1.430f, 0.856f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f
        )
    )
)

/** Aydınlık katmanın penceresi (ana pencere). Dialog / BottomSheet gibi ayrı pencereler bu katmanın dışında kalır. */
val LocalAuraRoot = androidx.compose.runtime.compositionLocalOf<android.view.View?> { null }

/** Aydınlık katmanın içindeki görseller kendi renklerini korusun diye ters filtre uygulanır; ayrı pencerelerde uygulanmaz */
@Composable
fun auraImageFilter(): androidx.compose.ui.graphics.ColorFilter? = null

/** İçeriği tek katmanda çizer ve renk filtresi uygular */
fun Modifier.auraInvert(): Modifier = this.drawWithContent {
    drawIntoCanvas { canvas ->
        val paint = androidx.compose.ui.graphics.Paint().apply { colorFilter = AuraInvertFilter }
        canvas.saveLayer(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height), paint)
        drawContent()
        canvas.restore()
    }
}

/** Uygulamanın ana içeriği: renkler tema paletinden gelir (filtre yok) */
@Composable
fun AuraLightLayer(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier.background(AuraBg)) { content() }
}

/** Aydınlık katmanın içinde bile koyu kalması gereken tam ekran alan (durum görüntüleyici vb.) */
/** Hep koyu tam ekran (görüntüleyici, arama, durum): açık temada bile durum / gezinme çubuğu simgeleri beyaz olsun */
@Composable
fun ForceLightBarIcons() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.runtime.DisposableEffect(Unit) {
        var c: android.content.Context? = ctx
        while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext
        val w = (c as? android.app.Activity)?.window
        val ctl = w?.let { androidx.core.view.WindowCompat.getInsetsController(it, it.decorView) }
        ctl?.isAppearanceLightStatusBars = false
        ctl?.isAppearanceLightNavigationBars = false
        onDispose {
            ctl?.isAppearanceLightStatusBars = AuraUi.light
            ctl?.isAppearanceLightNavigationBars = AuraUi.light
        }
    }
}

@Composable
fun AuraDarkIsland(modifier: Modifier = Modifier.fillMaxSize(), content: @Composable () -> Unit) {
    ForceLightBarIcons()
    Box(modifier) { content() }
}

private fun makeScheme(): androidx.compose.material3.ColorScheme {
    val d = darkColorScheme(
        primary = AuraRawBtn,
        onPrimary = Color.Black,
        background = AuraRawBg,
        surface = AuraRawSurface,
        onBackground = Color.White,
        onSurface = Color.White,
        surfaceVariant = AuraRawSurface
    )
    if (!AuraUi.light) return d
    return d.copy(
        primary = lm(d.primary), onPrimary = lm(d.onPrimary), primaryContainer = lm(d.primaryContainer), onPrimaryContainer = lm(d.onPrimaryContainer),
        inversePrimary = lm(d.inversePrimary), secondary = lm(d.secondary), onSecondary = lm(d.onSecondary),
        secondaryContainer = lm(d.secondaryContainer), onSecondaryContainer = lm(d.onSecondaryContainer),
        tertiary = lm(d.tertiary), onTertiary = lm(d.onTertiary), tertiaryContainer = lm(d.tertiaryContainer), onTertiaryContainer = lm(d.onTertiaryContainer),
        background = lm(d.background), onBackground = lm(d.onBackground), surface = lm(d.surface), onSurface = lm(d.onSurface),
        surfaceVariant = lm(d.surfaceVariant), onSurfaceVariant = lm(d.onSurfaceVariant), surfaceTint = lm(d.surfaceTint),
        inverseSurface = lm(d.inverseSurface), inverseOnSurface = lm(d.inverseOnSurface),
        error = lm(d.error), onError = lm(d.onError), errorContainer = lm(d.errorContainer), onErrorContainer = lm(d.onErrorContainer),
        outline = lm(d.outline), outlineVariant = lm(d.outlineVariant), scrim = d.scrim,
        surfaceBright = lm(d.surfaceBright), surfaceDim = lm(d.surfaceDim), surfaceContainer = lm(d.surfaceContainer),
        surfaceContainerHigh = lm(d.surfaceContainerHigh), surfaceContainerHighest = lm(d.surfaceContainerHighest),
        surfaceContainerLow = lm(d.surfaceContainerLow), surfaceContainerLowest = lm(d.surfaceContainerLowest)
    )
}

@Composable
fun AuraTheme(content: @Composable () -> Unit) {
    // Durum / gezinme çubuğu simgeleri aydınlık modda koyu olsun
    val act = androidx.compose.ui.platform.LocalContext.current.let { var c = it; while (c is android.content.ContextWrapper && c !is androidx.activity.ComponentActivity) c = c.baseContext; c as? androidx.activity.ComponentActivity }
    AuraUi.systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    androidx.compose.runtime.LaunchedEffect(AuraUi.light) {
        act?.enableEdgeToEdge(
            statusBarStyle = if (AuraUi.light) androidx.activity.SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) else androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = if (AuraUi.light) androidx.activity.SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) else androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
    }
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.foundation.text.selection.LocalTextSelectionColors provides
            androidx.compose.foundation.text.selection.TextSelectionColors(AuraBtn, AuraBtn.copy(alpha = 0.7f))
    ) {
        MaterialTheme(colorScheme = makeScheme(), content = content)
    }
}

fun formatListTime(ms: Long): String {
    if (ms <= 0L) return ""
    val now = Calendar.getInstance()
    val t = Calendar.getInstance().apply { timeInMillis = ms }
    val sameDay = now.get(Calendar.YEAR) == t.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == t.get(Calendar.DAY_OF_YEAR)
    if (sameDay) return SimpleDateFormat("HH:mm", Locale("tr")).format(Date(ms))
    val y = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    if (y.get(Calendar.YEAR) == t.get(Calendar.YEAR) && y.get(Calendar.DAY_OF_YEAR) == t.get(Calendar.DAY_OF_YEAR)) return "Dün"
    return SimpleDateFormat("dd.MM.yyyy", Locale("tr")).format(Date(ms))
}

fun formatClock(ms: Long): String =
    if (ms <= 0L) "" else SimpleDateFormat("HH:mm", Locale("tr")).format(Date(ms))

// ---------- Avatar (web sürümünde base64 data URL olarak saklanıyor) ----------
private val palette = listOf(0xFF3B82F6, 0xFFEF4444, 0xFFF59E0B, 0xFF8B5CF6, 0xFFEC4899, 0xFF14B8A6, 0xFFF97316)

fun colorForName(name: String): Color = Color(palette[(name.hashCode() and 0x7fffffff) % palette.size])

@Composable
fun Avatar(name: String, avatar: String?, size: Dp = 48.dp, isGroup: Boolean = false) {
    val bmp by produceState<Bitmap?>(if (avatar.isNullOrBlank()) null else Media.peek(avatar, 256), avatar) {
        value = if (avatar.isNullOrBlank()) null else withContext(Dispatchers.Default) { Media.decode(avatar, 256) }
    }
    val shape = CircleShape
    val b = bmp
    if (b != null) {
        Image(
            bitmap = b.asImageBitmap(),
            contentDescription = name,
            contentScale = ContentScale.Crop,
            colorFilter = auraImageFilter(),
            modifier = Modifier.size(size).clip(shape)
        )
    } else {
        // Fotoğrafı olmayanlar (webview ile aynı): kişi → tek siluet, grup → çift siluet
        // aydınlık modda filtre tersleyeceği için renkleri önceden çevir; sonuçta özgün renk görünür
        val inv = auraImageFilter() != null
        Box(Modifier.size(size).clip(shape).background(if (inv) auraWinColor(colorForName(name)) else colorForName(name)), contentAlignment = Alignment.Center) {
            androidx.compose.material3.Icon(
                if (isGroup) androidx.compose.material.icons.Icons.Default.Groups else androidx.compose.material.icons.Icons.Default.Person,
                contentDescription = name, tint = if (inv) auraWinColor(Color.White) else Color.White, modifier = Modifier.size(size * 0.58f)
            )
        }
    }
}

/** data URL görseli (mesaj fotoğrafı) arka planda çözüp gösterir */
@Composable
fun DataUrlImage(
    data: String,
    maxDim: Int,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop
) {
    val bmp by produceState<Bitmap?>(null, data, maxDim) {
        value = withContext(Dispatchers.Default) { Media.decode(data, maxDim) }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b.asImageBitmap(), contentDescription = null, contentScale = contentScale, colorFilter = auraImageFilter(), modifier = modifier)
    } else {
        Box(modifier.background(Color(0xFF2A2F31)))
    }
}

/** Bir kullanıcının profilini canlı izler (ad / avatar değişince ekran kendiliğinden güncellenir) */
@androidx.compose.runtime.Composable
fun liveProfile(uid: String): androidx.compose.runtime.State<com.aurachat.app.data.UserProfile?> =
    androidx.compose.runtime.remember(uid) {
        if (uid.isEmpty()) kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.UserProfile?>(null)
        else com.aurachat.app.data.Repo.profileFlow(uid)
    }.collectAsState(if (uid.isEmpty()) null else com.aurachat.app.data.Repo.peekProfile(uid))

/** Web ile aynı: her göndericiye kimliğinden hesaplanan sabit renk (light: 66 isim, 38 avatar, 78 alıntı) */
fun senderColor(uid: String, name: String, light: Int = 66): Color {
    val key = uid.ifEmpty { name.ifEmpty { "?" } }
    var h = 0
    for (ch in key) h = h * 31 + ch.code
    val idx = (h.toUInt() % 12u).toInt()
    return hslColor((idx * 30 + 8).toFloat(), 0.68f, light / 100f)
}

private fun hslColor(h: Float, s: Float, l: Float): Color {
    val c = (1f - kotlin.math.abs(2f * l - 1f)) * s
    val hp = h / 60f
    val x = c * (1f - kotlin.math.abs(hp % 2f - 1f))
    val (r, g, b) = when (hp.toInt()) {
        0 -> Triple(c, x, 0f)
        1 -> Triple(x, c, 0f)
        2 -> Triple(0f, c, x)
        3 -> Triple(0f, x, c)
        4 -> Triple(x, 0f, c)
        else -> Triple(c, 0f, x)
    }
    val m = l - c / 2f
    return Color(r + m, g + m, b + m)
}

/** Siyah arayüz açıkken web ile aynı: 0B141A -> saf siyah, diğer koyu yüzeyler -> #121212 */
fun auraC(normal: Long): Color =
    lm(if (!AuraUi.black) Color(normal) else if (normal == 0xFF0B141AL) Color.Black else Color(0xFF121212))


/** Sohbetin güncel adı: birebirde karşı kişinin profil adı, grupta grup adı. Ad değişince her yer anında güncellenir. */
@androidx.compose.runtime.Composable
fun liveChatName(t: com.aurachat.app.data.ChatTarget): String {
    val lp = androidx.compose.runtime.remember(t.chatId) {
        if (t.isGroup) kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.UserProfile?>(null)
        else com.aurachat.app.data.Repo.profileFlow(t.otherUid)
    }.collectAsState(if (t.isGroup) null else com.aurachat.app.data.Repo.peekProfile(t.otherUid))
    val gd = androidx.compose.runtime.remember(t.chatId) {
        if (t.isGroup) com.aurachat.app.data.Repo.groupFlow(t.chatId)
        else kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.GroupData?>(null)
    }.collectAsState(if (t.isGroup) com.aurachat.app.data.Repo.peekGroup(t.chatId) else null)
    return if (t.isGroup) (gd.value?.name?.takeIf { it.isNotBlank() } ?: t.name)
    else (lp.value?.name?.takeIf { it.isNotBlank() } ?: t.name)
}

/** Aydınlık modda ayrı pencerelerin (menü, sheet, dialog) yüzey rengini filtreyle aynı matematikle çevirir */
fun auraWinColor(c: Color): Color = c

/** Ayrı pencerenin içeriği: aydınlık modda ters filtre + görseller kendi rengini korur */
@Composable
fun AuraWinLayer(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier) { content() }
}

@Composable
fun AuraAlertDialog(
    onDismissRequest: () -> Unit,
    containerColor: Color = AuraSurface,
    title: (@Composable () -> Unit)? = null,
    text: (@Composable () -> Unit)? = null,
    confirmButton: @Composable () -> Unit,
    dismissButton: (@Composable () -> Unit)? = null
) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismissRequest,
        containerColor = auraWinColor(containerColor),
        title = title?.let { t -> { AuraWinLayer { t() } } },
        text = text?.let { t -> { AuraWinLayer { t() } } },
        confirmButton = { AuraWinLayer { confirmButton() } },
        dismissButton = dismissButton?.let { t -> { AuraWinLayer { t() } } }
    )
}

@Composable
fun AuraDropdownMenu(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    shape: androidx.compose.ui.graphics.Shape = androidx.compose.material3.MenuDefaults.shape,
    containerColor: Color = AuraSurface,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    androidx.compose.material3.DropdownMenu(
        expanded = expanded, onDismissRequest = onDismissRequest, modifier = modifier,
        shape = shape, containerColor = auraWinColor(containerColor)
    ) {
        AuraWinLayer { androidx.compose.foundation.layout.Column { content() } }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun AuraBottomSheet(
    onDismissRequest: () -> Unit,
    containerColor: Color = AuraSurface,
    shape: androidx.compose.ui.graphics.Shape = androidx.compose.foundation.shape.RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    androidx.compose.material3.ModalBottomSheet(
        onDismissRequest = onDismissRequest, containerColor = auraWinColor(containerColor), shape = shape
    ) {
        AuraWinLayer { androidx.compose.foundation.layout.Column { content() } }
    }
}

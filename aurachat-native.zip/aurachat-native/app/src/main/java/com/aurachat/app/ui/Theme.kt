package com.aurachat.app.ui

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Groups
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.toArgb
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.remember
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import com.aurachat.app.data.Media
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Eski web sürümündeki renkler (Tailwind): emerald-500/600/400, #005c4b, #212121, #202c33, #0b141a */
val AuraGreen: Color get() = AuraUi.accentColor() ?: lm(Color(0xFF10B981))      // emerald-500: başlık, vurgu, bağlantı
val AuraBtn: Color get() = AuraUi.accentColor()?.let { androidx.compose.ui.graphics.lerp(it, Color.Black, 0.15f) } ?: lm(Color(0xFF059669))       // emerald-600: gönder/mikrofon, aktif çip
val AuraBorder: Color get() = lm(Color(0xFF22C55E))    // yazı kutusu kenarlığı
val AuraBg: Color get() = lm(Color(0xFF000000))
val AuraChatBg: Color get() = lm(if (AuraUi.black) Color.Black else Color(0xFF0B141A))
val AuraSurface: Color get() = lm(if (AuraUi.black) Color(0xFF121212) else Color(0xFF202C33))
val AuraMine: Color get() = lm(Color(0xFF005C4B))
val AuraTheirs: Color get() = lm(Color(0xFF252525))
val AuraMuted: Color get() = lm(Color(0xFF9CA3AF))     // gray-400
val AuraTick: Color get() = lm(Color(0xFF53BDEB))

// Ham (açık temada dönüştürülmeyen) karşılıklar: görüntüleyici, arama gibi hep koyu ekranlar için
val AuraRawGreen = Color(0xFF10B981)
val AuraRawBtn = Color(0xFF059669)
val AuraRawBorder = Color(0xFF22C55E)
val AuraRawBg = Color(0xFF000000)
val AuraRawChatBg: Color get() = if (AuraUi.black) Color.Black else Color(0xFF0B141A)
val AuraRawSurface: Color get() = if (AuraUi.black) Color(0xFF121212) else Color(0xFF202C33)
val AuraRawMine = Color(0xFF005C4B)
val AuraRawTheirs = Color(0xFF212121)
val AuraRawMuted = Color(0xFF9CA3AF)
val AuraRawTick = Color(0xFF53BDEB)
fun auraRaw(v: Long): Color = Color(v)

/** Açık temada koyu paletin karşılığı (parlaklık ters, ton korunur). Gerçek açık tema: filtre yok, resimler ham kalır */
/** WhatsApp açık teması: bilinen koyu renklerin birebir açık karşılıkları */
private val lightMap: Map<Int, Int> = mapOf(
    0x000000 to 0xFFFFFF,   // ekran zemini
    0xFFFFFF to 0x111B21,   // yazı
    0x121212 to 0xF0F2F5,   // kart / menü yüzeyi
    0x202C33 to 0xF0F2F5,
    0x1F2C34 to 0xF0F2F5,
    0x1F2C33 to 0xF0F2F5,
    0x111B21 to 0xFFFFFF,
    0x233138 to 0xFFFFFF,
    0x0B141A to 0xEFEAE2,   // sohbet zemini
    0x1B252B to 0xF0F2F5,
    0x2A3942 to 0xD1D7DB,
    0x2A3239 to 0xD1D7DB,
    0x2A2F31 to 0xE9EDEF,
    0x005C4B to 0xD5F3CF,   // giden balon
    0x212121 to 0xFFFFFF,   // gelen balon
    0x9CA3AF to 0x667781,   // ikincil yazı
    0x8696A0 to 0x667781,
    0xD1D7DB to 0x54656F,   // simge gri
    0x9AA3A9 to 0x54656F,
    0x8A9096 to 0x8696A0,
    0x10B981 to 0x00A884,   // vurgu yeşili
    0x059669 to 0x00A884,
    0x22C55E to 0x00A884
)

fun lm(c: Color): Color {
    if (!AuraUi.light) return if (c.alpha == 1f && c.red == 0f && c.green == 0f && c.blue == 0f) (BgLab.color ?: c) else c  // BgLab (deneme)
    val key = ((c.red * 255f + 0.5f).toInt() shl 16) or ((c.green * 255f + 0.5f).toInt() shl 8) or (c.blue * 255f + 0.5f).toInt()
    val hit = lightMap[key]
    if (hit != null) return Color(0xFF000000.toInt() or hit).copy(alpha = c.alpha)
    val r = c.red; val g = c.green; val b = c.blue
    fun cl(v: Float) = v.coerceIn(0f, 1f)
    return Color(
        cl(0.574f * r - 1.430f * g - 0.144f * b + 1f),
        cl(-0.426f * r - 0.430f * g - 0.144f * b + 1f),
        cl(-0.426f * r - 1.430f * g + 0.856f * b + 1f),
        c.alpha
    )
}
private fun hsl(c: Color): FloatArray {
    val r = c.red; val g = c.green; val b = c.blue
    val mx = maxOf(r, g, b); val mn = minOf(r, g, b)
    val l = (mx + mn) / 2f
    val d = mx - mn
    if (d < 1e-4f) return floatArrayOf(0f, 0f, l)
    val sat = d / (1f - kotlin.math.abs(2f * l - 1f))
    val h = when (mx) {
        r -> ((g - b) / d) % 6f
        g -> (b - r) / d + 2f
        else -> (r - g) / d + 4f
    } * 60f
    return floatArrayOf(if (h < 0) h + 360f else h, sat.coerceIn(0f, 1f), l)
}

private fun fromHsl(h: Float, s: Float, l: Float): Color {
    val c = (1f - kotlin.math.abs(2f * l - 1f)) * s
    val x = c * (1f - kotlin.math.abs((h / 60f) % 2f - 1f))
    val m = l - c / 2f
    val (r, g, b) = when {
        h < 60f -> Triple(c, x, 0f)
        h < 120f -> Triple(x, c, 0f)
        h < 180f -> Triple(0f, c, x)
        h < 240f -> Triple(0f, x, c)
        h < 300f -> Triple(x, 0f, c)
        else -> Triple(c, 0f, x)
    }
    return Color(r + m, g + m, b + m)
}

private fun isDefaultGreen(c: Color): Boolean {
    val k = ((c.red * 255f + 0.5f).toInt() shl 16) or ((c.green * 255f + 0.5f).toInt() shl 8) or (c.blue * 255f + 0.5f).toInt()
    return k == 0x005C4B || k == 0x1F6F5C || k == 0x0D4A30
}

/** Her renk çiftinin koyu olanı: açık temada solgun (pastel) balon olur; diğerleri WhatsApp gibi doygun kalır */
private val paleKeys = setOf(
    0x0d4a30, 0x092e5c, 0x2c2463, 0x0c3b52, 0x532168, 0x3b3d3e, 0x532b20, 0x29362a, 0x064643, 0x631026, 0x3f2716,
    0x43372b, 0x065248, 0x736000, 0x395217, 0x691b3b, 0x6f1127, 0x5c130b, 0x584b23, 0x1a3a8a
)

/** WhatsApp açık tema tablosu (ekran görüntülerinden): balon kodu → [üst çubuk/durum çubuğu, seçim çubuğu, balon, gönder düğmesi/vurgu] */
private val waSet: Map<Int, IntArray> = mapOf(
    0x126d47 to intArrayOf(0xf5f1eb, 0xf7f5f3, 0x1daa61, 0x15603e), // sıra 1
    0x0d4a30 to intArrayOf(0xffffff, 0xf7f5f3, 0xd9fdd3, 0x15603e), // sıra 2
    0x08529e to intArrayOf(0xe6effa, 0xd3d9ee, 0x2d68eb, 0x073d76), // sıra 3
    0x092e5c to intArrayOf(0xe6effa, 0xd3d9ee, 0xd2e8fe, 0x073d76), // sıra 4
    0x4e38b3 to intArrayOf(0xffebf1, 0xe8e0ff, 0x5e47de, 0x3a327b), // sıra 5
    0x2c2463 to intArrayOf(0xffebf1, 0xe8e0ff, 0xe8e0ff, 0x3a327b), // sıra 6
    0x0e5d8d to intArrayOf(0xedf3f7, 0xd3e3ee, 0x0b4b79, 0x074b6a), // sıra 7
    0x0c3b52 to intArrayOf(0xedf3f7, 0xd3e3ee, 0xd3e3ee, 0x074b6a), // sıra 8
    0x803399 to intArrayOf(0xffebe6, 0xfee2d8, 0xc15add, 0x4b215a), // sıra 9
    0x532168 to intArrayOf(0xffebe6, 0xfee2d8, 0xf1d9f7, 0x4b215a), // sıra 10
    0x53565a to intArrayOf(0xeaebeb, 0xeaebeb, 0x333333, 0x424445), // sıra 11
    0x3b3d3e to intArrayOf(0xeaebeb, 0xeaebeb, 0xdadcdc, 0x424445), // sıra 12
    0x9e3f22 to intArrayOf(0xfcf4e5, 0xfee2d8, 0xe56d53, 0x6b3424), // sıra 13
    0x532b20 to intArrayOf(0xfcf4e5, 0xfee2d8, 0xfee2d8, 0x6b3424), // sıra 14
    0x3c503e to intArrayOf(0xf4f5f0, 0xdfe8df, 0x3c503a, 0x626a21), // sıra 15
    0x29362a to intArrayOf(0xf4f5f0, 0xdfe8df, 0xdfe8df, 0x626a21), // sıra 16
    0x086b66 to intArrayOf(0xf5f1eb, 0xcbf2ee, 0x028377, 0x074d4a), // sıra 17
    0x064643 to intArrayOf(0xf5f1eb, 0xcbf2ee, 0xcbf2ee, 0x074d4a), // sıra 18
    0x9b153b to intArrayOf(0xf1ede7, 0xfdced9, 0x731a2f, 0x61182e), // sıra 19
    0x631026 to intArrayOf(0xf1ede7, 0xfdced9, 0xfdced9, 0x61182e), // sıra 20
    0x794b2a to intArrayOf(0xfcede3, 0xf4ded1, 0x9e6947, 0x5b3c29), // sıra 21
    0x3f2716 to intArrayOf(0xfcede3, 0xf4ded1, 0xf4ded1, 0x5b3c29), // sıra 22
    0x8d7053 to intArrayOf(0xfaf8f5, 0xefe9e0, 0xc1a886, 0x504334), // sıra 23
    0x43372b to intArrayOf(0xfaf8f5, 0xefe9e0, 0xefe9e0, 0x504334), // sıra 24
    0x0a7f6f to intArrayOf(0xf0fff9, 0xd5fded, 0x00a884, 0x125c4e), // sıra 25
    0x065248 to intArrayOf(0xf0fff9, 0xd5fded, 0xd5fded, 0x125c4e), // sıra 26
    0xc5a300 to intArrayOf(0xfefde6, 0xfefcdc, 0xe5cb00, 0x80770e), // sıra 27
    0x736000 to intArrayOf(0xfefde6, 0xfefcdc, 0xfdf8af, 0x80770e), // sıra 28
    0x5e8a27 to intArrayOf(0xf4fee6, 0xe6fbcb, 0x72a432, 0x5c7b34), // sıra 29
    0x395217 to intArrayOf(0xf4fee6, 0xe6fbcb, 0xe3ffbd, 0x5c7b34), // sıra 30
    0xd82d63 to intArrayOf(0xffebf1, 0xffebf1, 0xe63371, 0x6d1e3e), // sıra 31
    0x691b3b to intArrayOf(0xffebf1, 0xffebf1, 0xffdae7, 0x6d1e3e), // sıra 32
    0xca1236 to intArrayOf(0xfde8eb, 0xfbd8dc, 0xea0038, 0x61182e), // sıra 33
    0x6f1127 to intArrayOf(0xf7e3e5, 0xfbd8dc, 0xfbd8dc, 0x61182e), // sıra 34
    0xa72917 to intArrayOf(0xffede6, 0xffdbcc, 0xe5381d, 0x57140a), // sıra 35
    0x5c130b to intArrayOf(0xffede6, 0xffdbcc, 0xffdbcc, 0x57140a), // sıra 36
    0xb6862b to intArrayOf(0xfff7e5, 0xfff0d4, 0xe5b61a, 0x6d4e26), // sıra 37
    0x584b23 to intArrayOf(0xfff7e5, 0xfff0d4, 0xfff0d4, 0x6d4e26), // sıra 38
)

private val lightBubble: Map<Int, Int> by lazy { waSet.mapValues { it.value[2] } }

private val waByBubble: Map<Int, IntArray> by lazy { waSet.values.associateBy { it[2] } }

/** Balon rengi (koyu kod ya da açık temadaki görünen renk) → tablo satırı */
private fun waRow(c: Color): IntArray? {
    val k = ((c.red * 255f + 0.5f).toInt() shl 16) or ((c.green * 255f + 0.5f).toInt() shl 8) or (c.blue * 255f + 0.5f).toInt()
    return waSet[k] ?: waByBubble[k]
}


/** Giden balon rengi: koyuda seçilen renk; açıkta WhatsApp gibi ya doygun ton (beyaz yazılı) ya da aynı tonun pastel hâli (varsayılan: #D9FDD3) */
fun bubbleOf(c: Color): Color {
    if (!AuraUi.light) return c
    val k = ((c.red * 255f + 0.5f).toInt() shl 16) or ((c.green * 255f + 0.5f).toInt() shl 8) or (c.blue * 255f + 0.5f).toInt()
    lightBubble[k]?.let { return Color(0xFF000000.toInt() or it) }
    if (isDefaultGreen(c)) return Color(0xFFD8FDD2)
    val h = hsl(c)
    if (k in paleKeys) return fromHsl(h[0], h[1].coerceIn(0.45f, 0.9f), 0.89f)
    if (h[1] < 0.2f) return fromHsl(h[0], h[1], (h[2] * 0.62f).coerceIn(0.12f, 0.4f))   // gri: WhatsApp gibi koyu antrasit
    return fromHsl(h[0], h[1].coerceIn(0.5f, 0.85f), h[2].coerceIn(0.38f, 0.46f))
}

/** Sohbet balonu sayfasında 1. ve 3. sıradaki (doygun) renkler: alıntı adı, alıntı çubuğu ve bağlantılar beyaz; açık ve koyu temada aynı */
private val whiteQuoteSet: Set<Int> by lazy {
    val s = HashSet<Int>()
    for ((k, v) in lightBubble) if (k !in paleKeys) { s.add(k); s.add(v) }
    s
}

fun whiteQuote(c: Color): Boolean {
    val k = ((c.red * 255f + 0.5f).toInt() shl 16) or ((c.green * 255f + 0.5f).toInt() shl 8) or (c.blue * 255f + 0.5f).toInt()
    return k in whiteQuoteSet
}

/** Doygun (koyu) balon kodu → pastel eşi (Sohbet balonu sayfasında 2. ve 4. sıradaki renk) */
private val deepToPale: Map<Int, Int> by lazy {
    val m = HashMap<Int, Int>()
    for ((pale, deep) in palePair) m[deep] = pale
    m[0x126d47] = 0x0d4a30
    m[0x08529e] = 0x092e5c
    m
}

/** Mesaja basılı tutunca açılan seçim çubuğunun rengi: seçili balonun pastel (açık) tonu; açık ve koyu temada aynı. Eşi yoksa null */
fun selBarColor(c: Color): Color? {
    val r = waRow(c) ?: return if (isDefaultGreen(c)) Color(0xFFF7F5F3) else null
    return Color(0xFF000000.toInt() or r[1])
}

/** Açık temada doygun (koyu) giden balonun içeriği koyu temadaki beyaz yazı renkleriyle çizilir */
@androidx.compose.runtime.Composable
fun DeepBubbleScope(bubble: Color, content: @androidx.compose.runtime.Composable () -> Unit) {
    val deep = AuraUi.light && bubble.luminance() < 0.45f
    if (deep) {
        AuraUi.forceDark = true
        content()
        AuraUi.forceDark = false
    } else content()
}

/** Vurgu (gönder düğmesi, kenarlık, seçim): açıkta rengin koyuluğu çok düşükse biraz açılır (varsayılan: #00A884) */
/** Açık temada rengin çok soluk tonu (zemin / üst çubuk boyası); koyuda aynen döner */
fun paleTint(c: Color, l: Float): Color {
    val h = hsl(c)
    return fromHsl(h[0], h[1].coerceIn(0.5f, 0.9f), l)
}

/** WhatsApp'taki gibi çok soluk, az doygun zemin tonu (baloncuk rengine göre boyanan sohbet zemini ve çubuk) */
fun softTint(c: Color, l: Float): Color {
    val h = hsl(c)
    return fromHsl(h[0], h[1].coerceIn(0.5f, 0.85f), l)
}

/** WhatsApp açık tema: zemin ve üst çubuk AYNI renk (#F4FEE6 gibi), baloncuk tonunda, doygun ama çok açık */
/** WhatsApp'ın açık temada koyu balon rengine karşılık seçtiği zemin rengi (ekran görüntülerinden ölçüldü): balon kodu → zemin. Her renk için tona göre kayma sabit değil, bu yüzden tablo */
private val waWall: Map<Int, Int> = mapOf(
    0x126d47 to 0xf3efe7, // yeşil (varsayılan): krem
    0x0d4a30 to 0xf3efe7, // açık yeşil (varsayılan): krem
    0x4e38b3 to 0xfde9f4, // mor
    0x9e3f22 to 0xfbf2e3, // mercan
    0x803399 to 0xfde9e8, // orkide
    0x086b66 to 0xf0efea, // petrol yeşili (nötr)
    0x794b2a to 0xfae9de, // kahve
    0x0a7f6f to 0xeefdf8, // zümrüt
    0x5e8a27 to 0xf2fce4, // fıstık yeşili
    0xca1236 to 0xfde6e9, // kırmızı
    0xb6862b to 0xfef5e0, // sarı
    0x08529e to 0xe1ebfa, // mavi
    0x0e5d8d to 0xe9f0f6, // lacivert
    0x53565a to 0xe7e9e8, // gri
    0x3c503e to 0xf1f3ed, // koyu yeşil
    0x9b153b to 0xefebe4, // bordo
    0x8d7053 to 0xf8f6f2, // bej
    0xc5a300 to 0xfcfce4, // limon sarısı
    0xd82d63 to 0xfee8f0, // pembe
    0xa72917 to 0xfeeae2, // kiremit kırmızısı
)

/** Açık (pastel) balon kodu → koyu eşi */
private val palePair: Map<Int, Int> = mapOf(
    0x092e5c to 0x08529e, 0x2c2463 to 0x4e38b3, 0x0c3b52 to 0x0e5d8d, 0x532168 to 0x803399, 0x3b3d3e to 0x53565a,
    0x532b20 to 0x9e3f22, 0x29362a to 0x3c503e, 0x064643 to 0x086b66, 0x631026 to 0x9b153b, 0x3f2716 to 0x794b2a,
    0x43372b to 0x8d7053, 0x065248 to 0x0a7f6f, 0x736000 to 0xc5a300, 0x395217 to 0x5e8a27, 0x691b3b to 0xd82d63,
    0x6f1127 to 0xca1236, 0x5c130b to 0xa72917, 0x584b23 to 0xb6862b
)

fun waTint(c: Color): Color {
    val key = ((c.red * 255f + 0.5f).toInt() shl 16) or ((c.green * 255f + 0.5f).toInt() shl 8) or (c.blue * 255f + 0.5f).toInt()
    waSet[key]?.let { return Color(0xFF000000.toInt() or it[0]) }
    waWall[key]?.let { return Color(0xFF000000.toInt() or it) }
    // açık (pastel) balon, koyu eşiyle aynı zemini kullanır (WhatsApp'ta ölçüldü: mor, orkide, mercan)
    palePair[key]?.let { waWall[it]?.let { w -> return Color(0xFF000000.toInt() or w) } }
    val h = hsl(c)
    return fromHsl(h[0], h[1].coerceIn(0.6f, 0.95f), 0.949f)
}

/** Düz renkler, açık temada: aynı tonun çok açık (pastel) hâli; zemin ve üst çubuk bunu paylaşır */
fun pastelOf(c: Color): Color {
    val h = hsl(c)
    return fromHsl(h[0], h[1].coerceAtMost(0.85f), 0.93f)
}

fun accentOf(c: Color): Color {
    if (!AuraUi.light) return c
    waRow(c)?.let { return Color(0xFF000000.toInt() or it[3]) }
    if (isDefaultGreen(c)) return Color(0xFF15603E)
    val h = hsl(c)
    return fromHsl(h[0], h[1], h[2].coerceIn(0.38f, 0.5f))
}

fun auraCRaw(normal: Long): Color =
    if (!AuraUi.black) Color(normal) else if (normal == 0xFF0B141AL) Color.Black else Color(0xFF121212)
fun auraLc(v: Long): Color = lm(Color(v))
/** Balon içindeki çerçeve / yuva zemini: koyuda siyah gölge, açıkta belirgin hafif gri */
val AuraFrame: Color get() = if (AuraUi.light) Color(0x1F000000) else Color(0x33000000)
val AuraWhite: Color get() = lm(Color.White)
val AuraBlack: Color get() = lm(Color.Black)

/** Arayüz anahtarı: koyu (varsayılan, saf siyah) / aydınlık. Aydınlık mod, koyu renklerin parlaklığını ters çevirir (renk tonu korunur) */
object AuraUi {
    /** Eskiden "siyah / lacivert" idi; artık renk değerleri hep siyah tabanlıdır */
    val black: Boolean get() = true

    /** 0 = koyu, 1 = açık, 2 = sistem (Android temasını izler) */
    var mode by androidx.compose.runtime.mutableIntStateOf(0)
        private set
    var systemDark by androidx.compose.runtime.mutableStateOf(true)
    /** Uygulama vurgu rengi: palet sırası (0 = varsayılan zümrüt, 1..19 = palet) */
    var accent by androidx.compose.runtime.mutableIntStateOf(0)
        private set

    /** Aydınlık ve karanlık için ayrı paletler (WhatsApp'tan birebir) */
    val accentLight = longArrayOf(
        0x1DAB61, 0x333333, 0x009DE2, 0xC15ADD, 0xE63472, 0x2D68EA, 0x0B4B79, 0x5E47DF, 0x72A431, 0x00A884,
        0x018377, 0x3D503A, 0xE6CB00, 0xC1A987, 0x9E6947, 0x731A2E, 0xE4B61A, 0xE56D54, 0xE90039, 0xE6381D
    )
    val accentDark = longArrayOf(
        0x176F47, 0x4C4C4C, 0x05597E, 0x713082, 0xBC275E, 0x04488F, 0x0B4B79, 0x433597, 0x577D26, 0x0C7360,
        0x045D57, 0x3D503A, 0xB39A00, 0x7B654D, 0x5B3C28, 0x7E112E, 0x9D792B, 0x853A23, 0xA71136, 0x8A1F0F
    )

    /** Seçili vurgu rengi (varsayılansa null); aktif temanın paletinden gelir */
    /** Sohbet sayfası açıkken vurgu devre dışı (sohbet kendi tema rengini kullanır) */
    var accentOff by androidx.compose.runtime.mutableStateOf(false)

    /** Sohbet sayfası muaf olsa bile resimsiz avatarlar vurgu rengini alsın */
    fun accentRaw(): Color? = when {
        accent == 20 -> customAdapted()
        accent <= 0 || accent > 19 -> null
        else -> Color(0xFF000000 or (if (light) accentLight else accentDark)[accent])
    }

    /** Özel renk: seçilen tonu koruyup açık temada canlı, koyu temada koyu tona uyarlar */
    fun customAdapted(): Color {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(0xFF000000.toInt() or customRgb, hsv)
        hsv[2] = if (light) hsv[2].coerceIn(0.6f, 0.92f) else (hsv[2] * 0.62f).coerceIn(0.2f, 0.55f)
        return Color(android.graphics.Color.HSVToColor(hsv))
    }

    /** Resimsiz avatar zemini: vurgu seçili değilse bile paletin ilk rengi */
    fun avatarBase(): Color = accentRaw() ?: Color(0xFF000000 or (if (light) accentLight else accentDark)[0])

    fun accentColor(): Color? = if (accentOff) null else accentRaw()

    /** Özel (RGB / hex) vurgu rengi; accent == 20 iken geçerli */
    var customRgb by androidx.compose.runtime.mutableIntStateOf(0x1DAB61)
        private set

    fun setCustom(ctx: android.content.Context, rgb: Int) {
        customRgb = rgb and 0xFFFFFF
        accent = 20
        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putInt("accent_idx", 20).putInt("accent_custom", customRgb).apply()
    }

    /** Palet kutusunda gösterilen renk */
    fun swatch(i: Int, lightPalette: Boolean): Color =
        if (i == 0) Color(0xFF10B981) else Color(0xFF000000 or (if (lightPalette) accentLight else accentDark)[i])

    fun setAccent(ctx: android.content.Context, i: Int) {
        accent = i.coerceIn(0, 20)
        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putInt("accent_idx", accent).apply()
    }
    /** Açık temada koyu (doygun) giden balonun içi için geçici olarak koyu renkleri açar; bkz. DeepBubbleScope */
    var forceDark = false
    val light: Boolean get() = !forceDark && lightReal
    /** Balon içi geçici koyu kapsamdan (forceDark) etkilenmez: duvar kağıdı / tema ekranları bunu kullanır */
    /** Sohbet teması önizlemesinde koyu / açık görünümü geçici denemek için (null = gerçek tema); sayfadan çıkınca sıfırlanır */
    var previewDark by androidx.compose.runtime.mutableStateOf<Boolean?>(null)
    /** Gerçek (önizleme geçersiz kılmasından bağımsız) açık tema durumu */
    val lightSystem: Boolean get() = mode == 1 || (mode == 2 && !systemDark)
    val lightReal: Boolean get() = previewDark?.let { !it } ?: lightSystem

    fun load(ctx: android.content.Context) {
        val sp = ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE)
        mode = if (sp.contains("theme_mode")) sp.getInt("theme_mode", 0) else if (sp.getBoolean("light_ui", false)) 1 else 0
        accent = sp.getInt("accent_idx", 0)
        customRgb = sp.getInt("accent_custom", 0x1DAB61)
        systemDark = (ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) != android.content.res.Configuration.UI_MODE_NIGHT_NO
    }

    fun setMode(ctx: android.content.Context, m: Int) {
        mode = m.coerceIn(0, 2)
        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putInt("theme_mode", mode).apply()
    }

    /** Koyu -> Açık -> Sistem -> Koyu */
    fun toggle(ctx: android.content.Context): String {
        mode = (mode + 1) % 3
        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putInt("theme_mode", mode).apply()
        return when (mode) { 0 -> "Koyu tema"; 1 -> "Açık tema"; else -> "Sistem teması" }
    }
}

/** invert(1) hue-rotate(180°): parlaklığı ters çevirir, renk tonunu korur. Kendi tersidir (iki kez uygulanırsa özgün renk). */
val AuraInvertFilter: androidx.compose.ui.graphics.ColorFilter = androidx.compose.ui.graphics.ColorFilter.colorMatrix(
    androidx.compose.ui.graphics.ColorMatrix(
        floatArrayOf(
            0.574f, -1.430f, -0.144f, 0f, 255f,
            -0.426f, -0.430f, -0.144f, 0f, 255f,
            -0.426f, -1.430f, 0.856f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f
        )
    )
)

/** Aydınlık katmanın penceresi (ana pencere). Dialog / BottomSheet gibi ayrı pencereler bu katmanın dışında kalır. */
val LocalAuraRoot = androidx.compose.runtime.compositionLocalOf<android.view.View?> { null }

/** Aydınlık katmanın içindeki görseller kendi renklerini korusun diye ters filtre uygulanır; ayrı pencerelerde uygulanmaz */
@Composable
fun auraImageFilter(): androidx.compose.ui.graphics.ColorFilter? = null

/** İçeriği tek katmanda çizer ve renk filtresi uygular */
fun Modifier.auraInvert(): Modifier = this.drawWithContent {
    drawIntoCanvas { canvas ->
        val paint = androidx.compose.ui.graphics.Paint().apply { colorFilter = AuraInvertFilter }
        canvas.saveLayer(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height), paint)
        drawContent()
        canvas.restore()
    }
}

/** Uygulamanın ana içeriği: renkler tema paletinden gelir (filtre yok) */
@Composable
fun AuraLightLayer(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier.background(AuraBg)) { content() }
}

/** Aydınlık katmanın içinde bile koyu kalması gereken tam ekran alan (durum görüntüleyici vb.) */
/** Hep koyu tam ekran (görüntüleyici, arama, durum): açık temada bile durum / gezinme çubuğu simgeleri beyaz olsun */
@Composable
fun ForceLightBarIcons() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.runtime.DisposableEffect(Unit) {
        var c: android.content.Context? = ctx
        while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext
        val w = (c as? android.app.Activity)?.window
        val ctl = w?.let { androidx.core.view.WindowCompat.getInsetsController(it, it.decorView) }
        ctl?.isAppearanceLightStatusBars = false
        ctl?.isAppearanceLightNavigationBars = false
        onDispose {
            ctl?.isAppearanceLightStatusBars = AuraUi.light
            ctl?.isAppearanceLightNavigationBars = AuraUi.light
        }
    }
}

/** Durum görüntüleyicide sistem çubuklarını gizler (WhatsApp gibi tam ekran); çıkınca geri getirir */
@Composable
fun HideStatusBar() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.runtime.DisposableEffect(Unit) {
        var c: android.content.Context? = ctx
        while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext
        val w = (c as? android.app.Activity)?.window
        val ctl = w?.let { androidx.core.view.WindowCompat.getInsetsController(it, it.decorView) }
        ctl?.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctl?.hide(androidx.core.view.WindowInsetsCompat.Type.statusBars())
        onDispose { ctl?.show(androidx.core.view.WindowInsetsCompat.Type.statusBars()) }
    }
}

@Composable
fun AuraDarkIsland(modifier: Modifier = Modifier.fillMaxSize(), content: @Composable () -> Unit) {
    ForceLightBarIcons()
    Box(modifier) { content() }
}

private fun makeScheme(): androidx.compose.material3.ColorScheme {
    val d = darkColorScheme(
        primary = AuraRawBtn,
        onPrimary = Color.Black,
        background = BgLab.color ?: AuraRawBg,  // BgLab (deneme)
        surface = AuraRawSurface,
        onBackground = Color.White,
        onSurface = Color.White,
        surfaceVariant = AuraRawSurface
    )
    if (!AuraUi.light) return d
    return d.copy(
        primary = lm(d.primary), onPrimary = lm(d.onPrimary), primaryContainer = lm(d.primaryContainer), onPrimaryContainer = lm(d.onPrimaryContainer),
        inversePrimary = lm(d.inversePrimary), secondary = lm(d.secondary), onSecondary = lm(d.onSecondary),
        secondaryContainer = lm(d.secondaryContainer), onSecondaryContainer = lm(d.onSecondaryContainer),
        tertiary = lm(d.tertiary), onTertiary = lm(d.onTertiary), tertiaryContainer = lm(d.tertiaryContainer), onTertiaryContainer = lm(d.onTertiaryContainer),
        background = lm(d.background), onBackground = lm(d.onBackground), surface = lm(d.surface), onSurface = lm(d.onSurface),
        surfaceVariant = lm(d.surfaceVariant), onSurfaceVariant = lm(d.onSurfaceVariant), surfaceTint = lm(d.surfaceTint),
        inverseSurface = lm(d.inverseSurface), inverseOnSurface = lm(d.inverseOnSurface),
        error = lm(d.error), onError = lm(d.onError), errorContainer = lm(d.errorContainer), onErrorContainer = lm(d.onErrorContainer),
        outline = lm(d.outline), outlineVariant = lm(d.outlineVariant), scrim = d.scrim,
        surfaceBright = lm(d.surfaceBright), surfaceDim = lm(d.surfaceDim), surfaceContainer = lm(d.surfaceContainer),
        surfaceContainerHigh = lm(d.surfaceContainerHigh), surfaceContainerHighest = lm(d.surfaceContainerHighest),
        surfaceContainerLow = lm(d.surfaceContainerLow), surfaceContainerLowest = lm(d.surfaceContainerLowest)
    )
}

@Composable
fun AuraTheme(content: @Composable () -> Unit) {
    // Durum / gezinme çubuğu simgeleri aydınlık modda koyu olsun
    val act = androidx.compose.ui.platform.LocalContext.current.let { var c = it; while (c is android.content.ContextWrapper && c !is androidx.activity.ComponentActivity) c = c.baseContext; c as? androidx.activity.ComponentActivity }
    AuraUi.systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    androidx.compose.runtime.LaunchedEffect(AuraUi.light) {
        act?.enableEdgeToEdge(
            statusBarStyle = if (AuraUi.light) androidx.activity.SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) else androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = if (AuraUi.light) androidx.activity.SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) else androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        act?.window?.let { w ->
            val ctl = androidx.core.view.WindowCompat.getInsetsController(w, w.decorView)
            ctl.isAppearanceLightStatusBars = AuraUi.light
            ctl.isAppearanceLightNavigationBars = AuraUi.light
        }
    }
    val baseDensity = androidx.compose.ui.platform.LocalDensity.current
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(baseDensity.density, baseDensity.fontScale * AuraFont.scale),
        androidx.compose.foundation.text.selection.LocalTextSelectionColors provides
            (AuraUi.accentRaw() ?: AuraBtn).let { sc -> androidx.compose.foundation.text.selection.TextSelectionColors(sc, sc.copy(alpha = 0.35f)) }
    ) {
        MaterialTheme(colorScheme = makeScheme(), typography = auraTypography(AuraFont.family())) {
            androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
                content()
                AuraPanelHostLayer()
            }
        }
    }
}

fun formatListTime(ms: Long): String {
    if (ms <= 0L) return ""
    val now = Calendar.getInstance()
    val t = Calendar.getInstance().apply { timeInMillis = ms }
    val sameDay = now.get(Calendar.YEAR) == t.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == t.get(Calendar.DAY_OF_YEAR)
    if (sameDay) return SimpleDateFormat("HH:mm", Locale("tr")).format(Date(ms))
    val y = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    if (y.get(Calendar.YEAR) == t.get(Calendar.YEAR) && y.get(Calendar.DAY_OF_YEAR) == t.get(Calendar.DAY_OF_YEAR)) return "Dün"
    return SimpleDateFormat("dd.MM.yyyy", Locale("tr")).format(Date(ms))
}

fun formatClock(ms: Long): String =
    if (ms <= 0L) "" else SimpleDateFormat("HH:mm", Locale("tr")).format(Date(ms))

// ---------- Avatar (web sürümünde base64 data URL olarak saklanıyor) ----------
private val palette = listOf(0xFF3B82F6, 0xFFEF4444, 0xFFF59E0B, 0xFF8B5CF6, 0xFFEC4899, 0xFF14B8A6, 0xFFF97316)

fun colorForName(name: String): Color = Color(palette[(name.hashCode() and 0x7fffffff) % palette.size])

/** Avatarın sağ altında beliren seçim tiki: çıkarken büyüyerek belirir, kalkarken küçülüp kaybolur (WhatsApp gibi) */
@Composable
fun androidx.compose.foundation.layout.BoxScope.SelTick(visible: Boolean) {
    androidx.compose.animation.AnimatedVisibility(
        visible = visible,
        modifier = Modifier.align(Alignment.BottomEnd),
        enter = androidx.compose.animation.scaleIn(androidx.compose.animation.core.spring(dampingRatio = 0.55f, stiffness = 500f), initialScale = 0.2f) + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(120)),
        exit = androidx.compose.animation.scaleOut(androidx.compose.animation.core.tween(140), targetScale = 0.2f) + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(140))
    ) {
        Box(Modifier.size(20.dp).clip(CircleShape).background(AuraGreen).then(Modifier.border(2.dp, AuraBg, CircleShape)), contentAlignment = Alignment.Center) {
            androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(13.dp))
        }
    }
}

@Composable
fun Avatar(name: String, avatar: String?, size: Dp = 48.dp, isGroup: Boolean = false, accentAlways: Boolean = false) {
    val bmp by produceState<Bitmap?>(if (avatar.isNullOrBlank()) null else Media.peek(avatar, 256), avatar) {
        value = if (avatar.isNullOrBlank()) null else withContext(Dispatchers.Default) { Media.decode(avatar, 256) }
    }
    val shape = CircleShape
    val b = bmp
    // Çerçeve rengi ("Tümü" çipiyle aynı): fotoğraflı ve fotoğrafsız tüm avatarlarda
    val accB = AuraUi.accentRaw()
    val ltB = AuraUi.light
    val bd = if (ltB) (accB?.copy(alpha = 0.4f) ?: Color(0xFFA9E5A0)) else (accB?.copy(alpha = 0.55f) ?: Color(0xFF14503B))
    if (b != null) {
        Image(
            bitmap = b.asImageBitmap(),
            contentDescription = name,
            contentScale = ContentScale.Crop,
            colorFilter = auraImageFilter(),
            modifier = Modifier.size(size).clip(shape)   // fotoğraflı avatarda çember yok; boş (siluet) avatarda var
        )
    } else {
        // Fotoğrafı olmayanlar (webview ile aynı): kişi → tek siluet, grup → çift siluet
        // aydınlık modda filtre tersleyeceği için renkleri önceden çevir; sonuçta özgün renk görünür
        // "Tümü" çipiyle aynı renkler: açık temada açık zemin + koyu simge, koyu temada koyu zemin + açık simge
        val acc0 = AuraUi.accentRaw()
        val lt0 = AuraUi.light
        val bg = if (acc0 == null) (if (lt0) Color(0xFFD9FDD3) else Color(0xFF103629))
                 else acc0.copy(alpha = if (lt0) 0.16f else 0.24f).compositeOver(AuraBg)
        val iconC = if (acc0 == null) (if (lt0) Color(0xFF0B6B4D) else Color(0xFF25D366))
                    else if (lt0) androidx.compose.ui.graphics.lerp(acc0, Color.Black, 0.25f) else androidx.compose.ui.graphics.lerp(acc0, Color.White, 0.45f)
        Box(Modifier.size(size).clip(shape).background(bg).border(1.dp, bd, shape), contentAlignment = Alignment.Center) {
            androidx.compose.material3.Icon(
                if (isGroup) androidx.compose.material.icons.Icons.Default.Groups else androidx.compose.material.icons.Icons.Default.Person,
                contentDescription = name, tint = iconC, modifier = Modifier.size(size * 0.58f)
            )
        }
    }
}

/** Avatarın baskın (en doygun ve en yaygın) rengi; renksiz / gri fotoğraflarda null */
fun dominantColor(src: Bitmap?): Color? {
    if (src == null) return null
    val b = Bitmap.createScaledBitmap(src, 32, 32, true)
    val wSum = FloatArray(12); val r = FloatArray(12); val g = FloatArray(12); val bl = FloatArray(12)
    val hsv = FloatArray(3)
    for (y in 0 until 32) for (x in 0 until 32) {
        val p = b.getPixel(x, y)
        android.graphics.Color.colorToHSV(p, hsv)
        if (hsv[1] < 0.22f || hsv[2] < 0.2f) continue
        val w = hsv[1] * hsv[2]
        val k = ((hsv[0] / 30f).toInt()).coerceIn(0, 11)
        wSum[k] += w
        r[k] += w * android.graphics.Color.red(p); g[k] += w * android.graphics.Color.green(p); bl[k] += w * android.graphics.Color.blue(p)
    }
    var best = 0
    for (i in 1 until 12) if (wSum[i] > wSum[best]) best = i
    if (wSum[best] < 12f) return null   // yeterince renkli piksel yok
    val w = wSum[best]
    return Color(r[best] / w / 255f, g[best] / w / 255f, bl[best] / w / 255f)
}

@Composable
fun rememberAvatarDominant(avatar: String?): Color? {
    val c by produceState<Color?>(null, avatar) {
        value = if (avatar.isNullOrBlank()) null else withContext(Dispatchers.Default) { dominantColor(Media.decode(avatar, 64)) }
    }
    return c
}

/**
 * Profil / kişi / grup sayfası üst kapağı: doodle deseni, alt köşeleri yuvarlak; avatarın baskın renginin açık tonuyla boyanır
 * (renk çıkmazsa sayfa zemini). Kaydırınca silinerek kaybolur.
 */
@Composable
fun ProfileCover(avatar: String?, base: Color, prog: Float, scrollPx: Float, modifier: Modifier) {
    val dom = rememberAvatarDominant(avatar)
    val hsv = FloatArray(3)
    val light = AuraUi.light
    val (bgT, patT) = if (dom == null) {
        base to (if (light) Color(0x14000000) else Color(0x1FFFFFFF))
    } else {
        android.graphics.Color.colorToHSV(dom.toArgb(), hsv)
        val h = hsv[0]
        if (light) Color(android.graphics.Color.HSVToColor(floatArrayOf(h, 0.22f, 0.98f))) to Color(android.graphics.Color.HSVToColor(40, floatArrayOf(h, 0.5f, 0.55f)))
        else Color(android.graphics.Color.HSVToColor(floatArrayOf(h, 0.55f, 0.20f))) to Color(android.graphics.Color.HSVToColor(36, floatArrayOf(h, 0.35f, 1f)))
    }
    val bg = bgT
    val pat = patT
    // WhatsApp gibi: kapak dikdörtgen; sayfa gövdesi (zemin rengi) üst köşeleri yuvarlak şekilde kapağın altına biner
    // çerçeve sabit (durum çubuğunun altında kırpar); kapağın kendisi içerikle aynı hızda yukarı kayar
    Box(modifier.clipToBounds().graphicsLayer { alpha = (1f - prog * 1.4f).coerceIn(0f, 1f) }) {
        Box(Modifier.fillMaxSize().graphicsLayer { translationY = -scrollPx }.background(bg)) {
            Box(Modifier.fillMaxSize().doodleCover(pat, Color.Transparent))
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(28.dp)
                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(base)
            )
        }
    }
}

/** data URL görseli (mesaj fotoğrafı) arka planda çözüp gösterir */
@Composable
fun DataUrlImage(
    data: String,
    maxDim: Int,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop
) {
    val bmp by produceState<Bitmap?>(null, data, maxDim) {
        value = withContext(Dispatchers.Default) { Media.decode(data, maxDim) }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b.asImageBitmap(), contentDescription = null, contentScale = contentScale, colorFilter = auraImageFilter(), modifier = modifier)
    } else {
        Box(modifier.background(Color(0xFF2A2F31)))
    }
}

/** Bir kullanıcının profilini canlı izler (ad / avatar değişince ekran kendiliğinden güncellenir) */
@androidx.compose.runtime.Composable
fun liveProfile(uid: String): androidx.compose.runtime.State<com.aurachat.app.data.UserProfile?> =
    androidx.compose.runtime.remember(uid) {
        if (uid.isEmpty()) kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.UserProfile?>(null)
        else com.aurachat.app.data.Repo.profileFlow(uid)
    }.collectAsState(if (uid.isEmpty()) null else com.aurachat.app.data.Repo.peekProfile(uid))

/** Web ile aynı: her göndericiye kimliğinden hesaplanan sabit renk (light: 66 isim, 38 avatar, 78 alıntı) */
fun senderColor(uid: String, name: String, light: Int = 66): Color {
    val key = uid.ifEmpty { name.ifEmpty { "?" } }
    var h = 0
    for (ch in key) h = h * 31 + ch.code
    val idx = (h.toUInt() % 12u).toInt()
    return hslColor((idx * 30 + 8).toFloat(), 0.68f, light / 100f)
}

private fun hslColor(h: Float, s: Float, l: Float): Color {
    val c = (1f - kotlin.math.abs(2f * l - 1f)) * s
    val hp = h / 60f
    val x = c * (1f - kotlin.math.abs(hp % 2f - 1f))
    val (r, g, b) = when (hp.toInt()) {
        0 -> Triple(c, x, 0f)
        1 -> Triple(x, c, 0f)
        2 -> Triple(0f, c, x)
        3 -> Triple(0f, x, c)
        4 -> Triple(x, 0f, c)
        else -> Triple(c, 0f, x)
    }
    val m = l - c / 2f
    return Color(r + m, g + m, b + m)
}

/** Siyah arayüz açıkken web ile aynı: 0B141A -> saf siyah, diğer koyu yüzeyler -> #121212 */
fun auraC(normal: Long): Color =
    lm(if (!AuraUi.black) Color(normal) else if (normal == 0xFF0B141AL) Color.Black else Color(0xFF121212))


/** Sohbetin güncel adı: birebirde karşı kişinin profil adı, grupta grup adı. Ad değişince her yer anında güncellenir. */
@androidx.compose.runtime.Composable
fun liveChatName(t: com.aurachat.app.data.ChatTarget): String {
    val lp = androidx.compose.runtime.remember(t.chatId) {
        if (t.isGroup) kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.UserProfile?>(null)
        else com.aurachat.app.data.Repo.profileFlow(t.otherUid)
    }.collectAsState(if (t.isGroup) null else com.aurachat.app.data.Repo.peekProfile(t.otherUid))
    val gd = androidx.compose.runtime.remember(t.chatId) {
        if (t.isGroup) com.aurachat.app.data.Repo.groupFlow(t.chatId)
        else kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.GroupData?>(null)
    }.collectAsState(if (t.isGroup) com.aurachat.app.data.Repo.peekGroup(t.chatId) else null)
    return if (t.isGroup) (gd.value?.name?.takeIf { it.isNotBlank() } ?: t.name)
    else (lp.value?.name?.takeIf { it.isNotBlank() } ?: t.name)
}

/** Aydınlık modda ayrı pencerelerin (menü, sheet, dialog) yüzey rengini filtreyle aynı matematikle çevirir */
fun auraWinColor(c: Color): Color = c

/** Ayrı pencerenin içeriği: aydınlık modda ters filtre + görseller kendi rengini korur */
@Composable
fun AuraWinLayer(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier) { content() }
}

@Composable
fun AuraAlertDialog(
    onDismissRequest: () -> Unit,
    containerColor: Color = AuraSurface,
    title: (@Composable () -> Unit)? = null,
    text: (@Composable () -> Unit)? = null,
    confirmButton: @Composable () -> Unit,
    dismissButton: (@Composable () -> Unit)? = null
) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismissRequest,
        containerColor = auraWinColor(containerColor),
        title = title?.let { t -> { AuraWinLayer { t() } } },
        text = text?.let { t -> { AuraWinLayer { t() } } },
        confirmButton = { AuraWinLayer { confirmButton() } },
        dismissButton = dismissButton?.let { t -> { AuraWinLayer { t() } } }
    )
}

/** Seçim barı / üç nokta menü rengi: koyuda 1A1A1A, açıkta krem-gri */
val AuraSelBar: Color get() {
    val base = if (AuraUi.light) Color(0xFFF7F5F3) else Color(0xFF1A1A1A)
    val acc = AuraUi.accentColor() ?: return base
    // vurgu rengine çok açık tint: seçili satır vurgusuyla aynı aile
    return androidx.compose.ui.graphics.lerp(base, acc, if (AuraUi.light) 0.14f else 0.22f)
}

/** Tüm 3 nokta menü satırları sohbet sayfasındaki menüyle aynı: yükseklik 49dp, yanlardan 16dp, yazı 17sp normal kalınlık (Material'ın "Medium" varsayılanı yerine) */
@Composable
fun AuraMI(
    text: @Composable () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    trailingIcon: (@Composable () -> Unit)? = null,
    leadingIcon: (@Composable () -> Unit)? = null,
    contentPadding: androidx.compose.foundation.layout.PaddingValues = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
    enabled: Boolean = true
) {
    androidx.compose.material3.DropdownMenuItem(
        text = {
            androidx.compose.material3.ProvideTextStyle(androidx.compose.ui.text.TextStyle(fontSize = 17.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Normal)) { text() }
        },
        onClick = onClick,
        modifier = modifier.height(49.dp),
        leadingIcon = leadingIcon,
        trailingIcon = trailingIcon,
        contentPadding = contentPadding,
        enabled = enabled
    )
}

@Composable
fun AuraDropdownMenu(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    shape: androidx.compose.ui.graphics.Shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
    containerColor: Color = AuraSurface,
    alignEnd: Boolean = true,
    selecting: Boolean = false,
    forceDark: Boolean = false,
    yGap: androidx.compose.ui.unit.Dp = 4.dp,
    floating: Boolean = false,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    if (!expanded) return
    // floating (sohbet menüsü, WhatsApp ölçüleri): sağdan 4dp boşluk, 12.5dp köşe, 3dp gölge; renk koyuda aynı kalır, beyazda beyaz
    val fl = floating
    val edge = (4f * androidx.compose.ui.platform.LocalDensity.current.density).toInt()
    val gap = (yGap.value * androidx.compose.ui.platform.LocalDensity.current.density).toInt()
    val bg = if (alignEnd) (ChatBar.tint ?: (if (selecting) AuraSelBar else AuraBlack)) else containerColor
    val provider = remember(alignEnd, gap, fl) {
        object : androidx.compose.ui.window.PopupPositionProvider {
            override fun calculatePosition(
                anchorBounds: androidx.compose.ui.unit.IntRect, windowSize: androidx.compose.ui.unit.IntSize,
                layoutDirection: androidx.compose.ui.unit.LayoutDirection, popupContentSize: androidx.compose.ui.unit.IntSize
            ): androidx.compose.ui.unit.IntOffset {
                val x = if (alignEnd) windowSize.width - popupContentSize.width - (if (fl) edge else 0)
                        else anchorBounds.left.coerceIn(0, (windowSize.width - popupContentSize.width).coerceAtLeast(0))
                val y = (anchorBounds.bottom + gap).coerceIn(0, (windowSize.height - popupContentSize.height).coerceAtLeast(0))
                return androidx.compose.ui.unit.IntOffset(x, y)
            }
        }
    }
    // Menü odak almaz: klavye açıksa açık, kapalıysa kapalı kalır (focusable=true klavyeyi kapatıp menü kapanınca geri açıyordu).
    // Dışarı dokunma için tam ekran şeffaf bir katman, geri tuşu için BackHandler kullanılır.
    androidx.activity.compose.BackHandler(enabled = true) { onDismissRequest() }
    androidx.compose.ui.window.Popup(
        popupPositionProvider = object : androidx.compose.ui.window.PopupPositionProvider {
            override fun calculatePosition(anchorBounds: androidx.compose.ui.unit.IntRect, windowSize: androidx.compose.ui.unit.IntSize, layoutDirection: androidx.compose.ui.unit.LayoutDirection, popupContentSize: androidx.compose.ui.unit.IntSize) = androidx.compose.ui.unit.IntOffset(0, 0)
        },
        properties = androidx.compose.ui.window.PopupProperties(focusable = false, clippingEnabled = false)
    ) {
        Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onDismissRequest() } })
    }
    androidx.compose.ui.window.Popup(
        popupPositionProvider = provider,
        properties = androidx.compose.ui.window.PopupProperties(focusable = false)
    ) {
        androidx.compose.material3.Surface(
            modifier = modifier, shape = if (fl) androidx.compose.foundation.shape.RoundedCornerShape(12.5.dp) else if (alignEnd) androidx.compose.foundation.shape.RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp, bottomEnd = 0.dp, bottomStart = 16.dp) else shape,
            color = if (fl && AuraUi.light) Color.White else if (forceDark) Color(0xFF111B21) else auraWinColor(bg), shadowElevation = if (fl) 3.dp else 0.dp
        ) {
            val inner: @Composable () -> Unit = {
                androidx.compose.foundation.layout.Column(
                    Modifier.width(androidx.compose.foundation.layout.IntrinsicSize.Max)
                        .widthIn(min = 112.dp, max = 280.dp)
                        .padding(vertical = if (fl) 12.dp else 8.dp)
                        .verticalScroll(androidx.compose.foundation.rememberScrollState())
                ) { content() }
            }
            if (forceDark) inner() else AuraWinLayer { inner() }
        }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun AuraBottomSheet(
    onDismissRequest: () -> Unit,
    containerColor: Color = AuraSurface,
    shape: androidx.compose.ui.graphics.Shape = androidx.compose.foundation.shape.RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    sheetState: androidx.compose.material3.SheetState = androidx.compose.material3.rememberModalBottomSheetState(),
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    androidx.compose.material3.ModalBottomSheet(
        onDismissRequest = onDismissRequest, sheetState = sheetState, containerColor = auraWinColor(containerColor), shape = shape
    ) {
        // Sheet kendi pencerisinde açıldığı için durum çubuğu simgeleri sistem temasına dönüyordu; uygulamanın temasına sabitle
        val sheetView = androidx.compose.ui.platform.LocalView.current
        val sheetLight = AuraUi.light
        androidx.compose.runtime.SideEffect {
            val w = (sheetView.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
            if (w != null) {
                val ctl = androidx.core.view.WindowCompat.getInsetsController(w, sheetView)
                ctl.isAppearanceLightStatusBars = sheetLight
                ctl.isAppearanceLightNavigationBars = sheetLight
            }
        }
        AuraWinLayer { androidx.compose.foundation.layout.Column { content() } }
    }
}

/** Ekranda tam 1 piksellik çizgi kalınlığı (yoğunluktan bağımsız) */
@androidx.compose.runtime.Composable
fun hairline(): androidx.compose.ui.unit.Dp = (1f / androidx.compose.ui.platform.LocalDensity.current.density).dp

/** WhatsApp'taki gibi süreli mesaj rozeti: kesik halka ve akrep; avatarın köşesine konur */
@androidx.compose.runtime.Composable
fun DisappearBadge(size: androidx.compose.ui.unit.Dp, tint: Color, bg: Color, modifier: Modifier = Modifier) {
    androidx.compose.foundation.layout.Box(
        modifier.size(size).clip(androidx.compose.foundation.shape.CircleShape).background(bg),
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        androidx.compose.foundation.Canvas(Modifier.size(size * 0.82f)) {
            val sw = this.size.minDimension * 0.11f
            val r = (this.size.minDimension - sw) / 2f
            val circ = (2 * Math.PI * r).toFloat()
            drawCircle(tint, radius = r, style = androidx.compose.ui.graphics.drawscope.Stroke(width = sw, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(circ / 16f, circ / 16f))))
            val c = center
            val a = Math.toRadians(-50.0)
            drawLine(tint, c, androidx.compose.ui.geometry.Offset(c.x + (r * 0.62f * Math.cos(a)).toFloat(), c.y + (r * 0.62f * Math.sin(a)).toFloat()), strokeWidth = sw, cap = androidx.compose.ui.graphics.StrokeCap.Round)
            drawCircle(tint, radius = sw * 0.8f, center = c)
        }
    }
}

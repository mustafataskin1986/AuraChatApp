package com.aurachat.app.ui

import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Groups
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import com.aurachat.app.data.Media
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Eski web sürümündeki renkler (Tailwind): emerald-500/600/400, #005c4b, #212121, #202c33, #0b141a */
val AuraGreen = Color(0xFF10B981)      // emerald-500: başlık, vurgu, bağlantı
val AuraBtn = Color(0xFF059669)        // emerald-600: gönder/mikrofon, aktif çip
val AuraBorder = Color(0xFF22C55E)     // yazı kutusu kenarlığı
val AuraBg = Color(0xFF000000)
val AuraChatBg = Color(0xFF0B141A)
val AuraSurface = Color(0xFF202C33)
val AuraMine = Color(0xFF005C4B)
val AuraTheirs = Color(0xFF212121)
val AuraMuted = Color(0xFF9CA3AF)      // gray-400
val AuraTick = Color(0xFF53BDEB)

private val scheme = darkColorScheme(
    primary = AuraBtn,
    onPrimary = Color.Black,
    background = AuraBg,
    surface = AuraSurface,
    onBackground = Color.White,
    onSurface = Color.White,
    surfaceVariant = AuraSurface
)

@Composable
fun AuraTheme(content: @Composable () -> Unit) {
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.foundation.text.selection.LocalTextSelectionColors provides
            androidx.compose.foundation.text.selection.TextSelectionColors(AuraBtn, AuraBtn.copy(alpha = 0.4f))
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

fun formatListTime(ms: Long): String {
    if (ms <= 0L) return ""
    val now = Calendar.getInstance()
    val t = Calendar.getInstance().apply { timeInMillis = ms }
    val sameDay = now.get(Calendar.YEAR) == t.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == t.get(Calendar.DAY_OF_YEAR)
    val pattern = if (sameDay) "HH:mm" else "dd.MM.yyyy"
    return SimpleDateFormat(pattern, Locale("tr")).format(Date(ms))
}

fun formatClock(ms: Long): String =
    if (ms <= 0L) "" else SimpleDateFormat("HH:mm", Locale("tr")).format(Date(ms))

// ---------- Avatar (web sürümünde base64 data URL olarak saklanıyor) ----------
private val palette = listOf(0xFF3B82F6, 0xFFEF4444, 0xFFF59E0B, 0xFF8B5CF6, 0xFFEC4899, 0xFF14B8A6, 0xFFF97316)

fun colorForName(name: String): Color = Color(palette[(name.hashCode() and 0x7fffffff) % palette.size])

@Composable
fun Avatar(name: String, avatar: String?, size: Dp = 48.dp, isGroup: Boolean = false) {
    val bmp by produceState<Bitmap?>(if (avatar.isNullOrBlank()) null else Media.peek(avatar, 256), avatar) {
        value = if (avatar.isNullOrBlank()) null else withContext(Dispatchers.Default) { Media.decode(avatar, 256) }
    }
    val shape = CircleShape
    val b = bmp
    if (b != null) {
        Image(
            bitmap = b.asImageBitmap(),
            contentDescription = name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(shape)
        )
    } else {
        // Fotoğrafı olmayanlar (webview ile aynı): kişi → tek siluet, grup → çift siluet
        Box(Modifier.size(size).clip(shape).background(colorForName(name)), contentAlignment = Alignment.Center) {
            androidx.compose.material3.Icon(
                if (isGroup) androidx.compose.material.icons.Icons.Default.Groups else androidx.compose.material.icons.Icons.Default.Person,
                contentDescription = name, tint = Color.White, modifier = Modifier.size(size * 0.58f)
            )
        }
    }
}

/** data URL görseli (mesaj fotoğrafı) arka planda çözüp gösterir */
@Composable
fun DataUrlImage(
    data: String,
    maxDim: Int,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop
) {
    val bmp by produceState<Bitmap?>(null, data, maxDim) {
        value = withContext(Dispatchers.Default) { Media.decode(data, maxDim) }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b.asImageBitmap(), contentDescription = null, contentScale = contentScale, modifier = modifier)
    } else {
        Box(modifier.background(Color(0xFF2A2F31)))
    }
}

/** Bir kullanıcının profilini canlı izler (ad / avatar değişince ekran kendiliğinden güncellenir) */
@androidx.compose.runtime.Composable
fun liveProfile(uid: String): androidx.compose.runtime.State<com.aurachat.app.data.UserProfile?> =
    androidx.compose.runtime.remember(uid) {
        if (uid.isEmpty()) kotlinx.coroutines.flow.flowOf<com.aurachat.app.data.UserProfile?>(null)
        else com.aurachat.app.data.Repo.profileFlow(uid)
    }.collectAsState(if (uid.isEmpty()) null else com.aurachat.app.data.Repo.peekProfile(uid))

/** Web ile aynı: her göndericiye kimliğinden hesaplanan sabit renk (light: 66 isim, 38 avatar, 78 alıntı) */
fun senderColor(uid: String, name: String, light: Int = 66): Color {
    val key = uid.ifEmpty { name.ifEmpty { "?" } }
    var h = 0
    for (ch in key) h = h * 31 + ch.code
    val idx = (h.toUInt() % 12u).toInt()
    return Color.hsl((idx * 30 + 8).toFloat(), 0.68f, light / 100f)
}

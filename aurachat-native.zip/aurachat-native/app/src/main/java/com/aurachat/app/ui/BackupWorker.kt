package com.aurachat.app.ui

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.aurachat.app.R
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.concurrent.TimeUnit

private const val BK_CHANNEL = "aurachat-backup"
private const val BK_NOTIF = 7101
private const val BK_NOTIF_DONE = 7102

/** Yedekleme / geri yükleme işçisi: ön plan bildirimiyle çalışır, uygulama arka plana gitse de kesilmez */
class BackupWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private fun ensureChannel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(BK_CHANNEL, "Yedekleme", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun build(c: Context, pct: Float, text: String, title: String): Notification {
        ensureChannel(c)
        return NotificationCompat.Builder(c, BK_CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, (pct * 100).toInt().coerceIn(0, 100), false)
            .build()
    }

    private fun info(c: Context, pct: Float, text: String, title: String): ForegroundInfo {
        val n = build(c, pct, text, title)
        return if (Build.VERSION.SDK_INT >= 29) ForegroundInfo(BK_NOTIF, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(BK_NOTIF, n)
    }

    override suspend fun getForegroundInfo(): ForegroundInfo {
        val restore = inputData.getBoolean("restore", false)
        return info(applicationContext, 0.02f, "Hazırlanıyor…", if (restore) "Geri yükleniyor" else "Yedekleniyor")
    }

    private fun postResult(c: Context, text: String, error: Boolean) {
        try {
            ensureChannel(c)
            val n = NotificationCompat.Builder(c, BK_CHANNEL)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(if (error) "Yedekleme tamamlanamadı" else "Yedekleme tamamlandı")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .build()
            c.getSystemService(NotificationManager::class.java).notify(BK_NOTIF_DONE, n)
        } catch (e: Throwable) {}
    }

    override suspend fun doWork(): Result {
        val c = applicationContext
        val restore = inputData.getBoolean("restore", false)
        val manual = inputData.getBoolean("manual", false)
        val title = if (restore) "Geri yükleniyor" else "Yedekleniyor"
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid == null) {
            if (manual) Backup.endErr("Giriş yapılmamış")
            return Result.success()
        }
        if (!Backup.running) Backup.begin(restore)
        try { setForeground(info(c, 0.02f, "Hazırlanıyor…", title)) } catch (e: Throwable) {}

        val token = try { Backup.silentToken(c) } catch (e: Throwable) { null }
        if (token.isNullOrBlank()) {
            val msg = "Google Drive izni gerekli. Uygulamayı açıp Ayarlar > Sohbet yedeği'nden bir kez yedekle."
            Backup.endErr(msg)
            if (!manual) postResult(c, msg, true)
            return Result.success()
        }

        val nm = c.getSystemService(NotificationManager::class.java)
        var last = 0L
        Backup.progressSink = { p, t ->
            val now = System.currentTimeMillis()
            if (now - last > 1000) {
                last = now
                try { nm.notify(BK_NOTIF, build(c, p, t, title)) } catch (e: Throwable) {}
            }
        }
        return try {
            val msg = withContext(Dispatchers.IO) { Backup.run(c, uid, token, restore) }
            Backup.endOk(msg)
            if (!manual) postResult(c, msg, false)
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            Backup.endErr("Yedekleme yarıda kaldı, tekrar dene")
            throw e
        } catch (e: Throwable) {
            val msg = e.message ?: "İşlem başarısız"
            Backup.endErr(msg)
            if (!manual && runAttemptCount < 3) Result.retry()
            else {
                if (!manual) postResult(c, msg, true)
                Result.failure()
            }
        } finally {
            Backup.progressSink = null
        }
    }
}

/** Otomatik yedekleme zamanlayıcısı (WhatsApp gibi: günlük / haftalık / aylık, isteğe bağlı sadece Wi-Fi) */
object BackupSchedule {
    private const val NAME = "aura_backup_auto"

    private fun sp(c: Context) = c.getSharedPreferences("aura", Context.MODE_PRIVATE)

    fun freq(c: Context): String = sp(c).getString("backup_freq", "off") ?: "off"
    fun wifiOnly(c: Context): Boolean = sp(c).getBoolean("backup_wifi", true)

    fun set(c: Context, freq: String, wifi: Boolean) {
        sp(c).edit().putString("backup_freq", freq).putBoolean("backup_wifi", wifi).apply()
        schedule(c)
    }

    fun schedule(c: Context) {
        val wm = WorkManager.getInstance(c.applicationContext)
        val f = freq(c)
        if (f == "off") { wm.cancelUniqueWork(NAME); return }
        val days = when (f) { "daily" -> 1L; "weekly" -> 7L; else -> 30L }
        // ilk çalışma bir sonraki 03:00'te
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 3); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_MONTH, 1)
        }
        val delay = cal.timeInMillis - System.currentTimeMillis()
        val cons = Constraints.Builder()
            .setRequiredNetworkType(if (wifiOnly(c)) NetworkType.UNMETERED else NetworkType.CONNECTED)
            .setRequiresBatteryNotLow(true)
            .build()
        val req = PeriodicWorkRequestBuilder<BackupWorker>(days, TimeUnit.DAYS)
            .setConstraints(cons)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("restore" to false, "manual" to false))
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
            .build()
        wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}

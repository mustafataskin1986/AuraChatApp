package com.aurachat.app.ui

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.aurachat.app.R
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.concurrent.TimeUnit

private const val BK_CHANNEL = "aurachat-backup"
private const val BK_NOTIF = 7101
private const val BK_NOTIF_DONE = 7102

/** Yedekleme / geri yükleme işçisi: ön plan bildirimiyle çalışır, uygulama arka plana gitse de kesilmez */
class BackupWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private fun ensureChannel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(BK_CHANNEL, "Yedekleme", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun build(c: Context, pct: Float, text: String, title: String): Notification {
        ensureChannel(c)
        return NotificationCompat.Builder(c, BK_CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, (pct * 100).toInt().coerceIn(0, 100), false)
            // işlem ölürse bildirim takılı kalmasın: her güncellemede süre yenilenir
            .setTimeoutAfter(120_000L)
            .apply {
                val launch = c.packageManager.getLaunchIntentForPackage(c.packageName)
                if (launch != null) {
                    launch.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    launch.putExtra("openBackup", true)
                    setContentIntent(android.app.PendingIntent.getActivity(c, BK_NOTIF, launch, android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE))
                }
            }
            .build()
    }

    private fun info(c: Context, pct: Float, text: String, title: String): ForegroundInfo {
        val n = build(c, pct, text, title)
        return if (Build.VERSION.SDK_INT >= 29) ForegroundInfo(BK_NOTIF, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(BK_NOTIF, n)
    }

    override suspend fun getForegroundInfo(): ForegroundInfo {
        val restore = inputData.getBoolean("restore", false)
        return info(applicationContext, 0.02f, "Hazırlanıyor…", if (restore) "Geri yükleniyor" else "Yedekleniyor")
    }

    private fun postResult(c: Context, text: String, error: Boolean) {
        try {
            ensureChannel(c)
            val n = NotificationCompat.Builder(c, BK_CHANNEL)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(if (error) "Yedekleme tamamlanamadı" else "Yedekleme tamamlandı")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .apply {
                    // dokununca uygulama açılsın (contentIntent yoksa bildirim ne tıklanır ne de kapanır)
                    val launch = c.packageManager.getLaunchIntentForPackage(c.packageName)
                    if (launch != null) {
                        launch.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        launch.putExtra("openBackup", true)
                        setContentIntent(android.app.PendingIntent.getActivity(c, BK_NOTIF_DONE, launch, android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE))
                    }
                }
                .build()
            c.getSystemService(NotificationManager::class.java).notify(BK_NOTIF_DONE, n)
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("BackupWorker", e) }
    }

    override suspend fun doWork(): Result {
        val c = applicationContext
        val restore = inputData.getBoolean("restore", false)
        val manual = inputData.getBoolean("manual", false)
        val title = if (restore) "Geri yükleniyor" else "Yedekleniyor"
        val auto = !manual && !restore
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid == null) {
            if (manual) Backup.endErr("Giriş yapılmamış")
            return Result.success()
        }
        if (!Backup.running) Backup.begin(restore)
        try { setForeground(info(c, 0.02f, "Hazırlanıyor…", title)) } catch (e: Throwable) { /* uygulama arka plandayken Android izin vermez; yedek yine de çalışır, hata değil */ }

        val token = try { Backup.silentToken(c) } catch (e: Throwable) { null }
        if (token.isNullOrBlank()) {
            val msg = "Google Drive izni gerekli. Uygulamayı açıp Ayarlar > Sohbet yedeği'nden bir kez yedekle."
            // güncelleme sonrası Google izni geçici olarak okunamayabilir: otomatik yedekte önce sessizce tekrar dene, hâlâ olmazsa bildir
            if (!manual && runAttemptCount < 2) { Backup.endErr(msg); return Result.retry() }
            Backup.endErr(msg)
            if (!manual) postResult(c, msg, true)
            if (auto) BackupSchedule.next(c)
            return Result.success()
        }

        val nm = c.getSystemService(NotificationManager::class.java)
        var last = 0L
        Backup.progressSink = { p, t ->
            val now = System.currentTimeMillis()
            if (now - last > 1000) {
                last = now
                try { nm.notify(BK_NOTIF, build(c, p, t, title)) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("BackupWorker", e) }
            }
        }
        return try {
            val msg = withContext(Dispatchers.IO) { Backup.run(c, uid, token, restore) }
            Backup.endOk(msg)
            if (!manual) postResult(c, msg, false)
            if (auto) BackupSchedule.next(c)
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            Backup.endErr("Yedekleme yarıda kaldı, tekrar dene")
            throw e
        } catch (e: Throwable) {
            val msg = e.message ?: "İşlem başarısız"
            Backup.endErr(msg)
            if (!manual && runAttemptCount < 3) Result.retry()
            else {
                if (!manual) postResult(c, msg, true)
                if (auto) BackupSchedule.next(c)
                Result.failure()
            }
        } finally {
            Backup.progressSink = null
            // ön plan servisi başlatılamadıysa ilerleme bildirimini biz kaldırırız
            try { nm.cancel(BK_NOTIF) } catch (e: Throwable) { }
        }
    }
}

/** Otomatik yedekleme zamanlayıcısı (WhatsApp gibi: günlük / haftalık / aylık, isteğe bağlı sadece Wi-Fi).
 *  Her yedek tek seferlik iş olarak sıradaki 03:00'e kurulur; 03:00'te şartlar uymazsa şartlar sağlanır sağlanmaz aynı gün çalışır,
 *  bittikten sonra bir sonraki 03:00'e yeniden kurulur (saat öğleye kayıp kalmaz). */
object BackupSchedule {
    private const val OLD = "aura_backup_auto"
    private const val A = "aura_backup_auto_a"
    private const val B = "aura_backup_auto_b"

    private fun sp(c: Context) = c.getSharedPreferences("aura", Context.MODE_PRIVATE)

    fun freq(c: Context): String = sp(c).getString("backup_freq", "off") ?: "off"
    fun wifiOnly(c: Context): Boolean = sp(c).getBoolean("backup_wifi", true)
    private fun days(c: Context): Long = when (freq(c)) { "daily" -> 1L; "weekly" -> 7L; else -> 30L }

    fun set(c: Context, freq: String, wifi: Boolean) {
        sp(c).edit().putString("backup_freq", freq).putBoolean("backup_wifi", wifi).apply()
        schedule(c)
    }

    /** İlk kurulum / ayar değişimi: sıradaki 03:00'e */
    fun schedule(c: Context) = enqueue(c, 0L, false)

    /** Bir yedek bittikten sonra: bugünün 03:00'ünden [gün] sonraya (günlükte yarın 03:00) */
    fun next(c: Context) = enqueue(c, days(c), true)

    /** Eski (periyodik) kayıttan yeni düzene bir kez geçiş */
    fun migrate(c: Context) {
        if (sp(c).getBoolean("backup_v2", false)) return
        sp(c).edit().putBoolean("backup_v2", true).apply()
        try { WorkManager.getInstance(c.applicationContext).cancelUniqueWork(OLD) } catch (e: Throwable) { }
        if (freq(c) != "off") schedule(c)
    }

    private fun enqueue(c: Context, extraDays: Long, fromWorker: Boolean) {
        val wm = WorkManager.getInstance(c.applicationContext)
        val cur = sp(c).getString("backup_slot", "a") ?: "a"
        val curName = if (cur == "a") A else B
        val newSlot = if (cur == "a") "b" else "a"
        val newName = if (newSlot == "a") A else B
        if (freq(c) == "off") { wm.cancelUniqueWork(A); wm.cancelUniqueWork(B); wm.cancelUniqueWork(OLD); return }
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 3); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (extraDays > 0) add(Calendar.DAY_OF_MONTH, extraDays.toInt())
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_MONTH, 1)
        }
        val delay = cal.timeInMillis - System.currentTimeMillis()
        val cons = Constraints.Builder()
            .setRequiredNetworkType(if (wifiOnly(c)) NetworkType.UNMETERED else NetworkType.CONNECTED)
            .setRequiresBatteryNotLow(true)
            .build()
        val req = androidx.work.OneTimeWorkRequestBuilder<BackupWorker>()
            .setConstraints(cons)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("restore" to false, "manual" to false))
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
            .build()
        sp(c).edit().putString("backup_slot", newSlot).apply()
        wm.enqueueUniqueWork(newName, androidx.work.ExistingWorkPolicy.REPLACE, req)
        // çalışan iş kendi kaydını iptal etmesin; ayar değişiminde eskisi kaldırılır
        if (!fromWorker) wm.cancelUniqueWork(curName)
    }
}

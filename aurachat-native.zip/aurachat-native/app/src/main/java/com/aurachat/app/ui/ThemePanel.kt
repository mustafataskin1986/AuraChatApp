package com.aurachat.app.ui

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.ui.draw.rotate
import androidx.compose.foundation.horizontalScroll
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider

/** Üstten açılan panelin içeriği; Dialog yerine uygulamanın kendi penceresinde çizilir (durum çubuğu simgeleri uygulama temasına uysun diye) */
object AuraPanelHost {
    var content by androidx.compose.runtime.mutableStateOf<(@Composable () -> Unit)?>(null)
    var onDismiss: () -> Unit = {}
    var top by androidx.compose.runtime.mutableStateOf(60.dp)
    var fromLeft by androidx.compose.runtime.mutableStateOf(false)
    /** Sohbet listesinde sağa kaydırınca tema panelini açma isteği */
    var openRequest by androidx.compose.runtime.mutableStateOf(false)
    /** Sohbet listesinde parmak panel açıyor mu (panel parmağı izler) ve ne kadar açık (0..1) */
    var dragging by androidx.compose.runtime.mutableStateOf(false)
    var dragFrac by androidx.compose.runtime.mutableFloatStateOf(0f)
    var dragStarted = false
    /** Bırakırken hız: 1 = hızlı sağa (aç), -1 = hızlı sola (kapat), 0 = konuma göre */
    var flick = 0
}

@Composable
fun AuraTopPanel(
    onDismissRequest: () -> Unit,
    topBarHeight: androidx.compose.ui.unit.Dp = 60.dp,
    fromLeft: Boolean = false,
    content: @Composable () -> Unit
) {
    SideEffect {
        AuraPanelHost.content = content
        AuraPanelHost.onDismiss = onDismissRequest
        AuraPanelHost.top = topBarHeight
        AuraPanelHost.fromLeft = fromLeft
    }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { AuraPanelHost.content = null } }
}

@Composable
fun AuraPanelHostLayer() {
    val c = AuraPanelHost.content ?: return
    if (AuraPanelHost.fromLeft) { LeftPanelLayer(c); return }
    val st = remember { MutableTransitionState(false).apply { targetState = true } }
    LaunchedEffect(st.currentState, st.targetState) {
        if (!st.targetState && st.isIdle) AuraPanelHost.onDismiss()
    }
    androidx.activity.compose.BackHandler { st.targetState = false }
    Box(
        Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { st.targetState = false }
    ) {
        Box((if (AuraPanelHost.fromLeft) Modifier.fillMaxSize() else Modifier.fillMaxSize().statusBarsPadding()).padding(top = AuraPanelHost.top).clipToBounds()) {
            AnimatedVisibility(
                visibleState = st,
                enter = if (AuraPanelHost.fromLeft) androidx.compose.animation.slideInHorizontally(tween(320)) { -it } else slideInVertically(tween(320)) { -it },
                exit = if (AuraPanelHost.fromLeft) androidx.compose.animation.slideOutHorizontally(tween(260)) { -it } else slideOutVertically(tween(260)) { -it }
            ) {
                Box(
                    Modifier.fillMaxSize().background(AuraBg)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                ) { c() }
            }
        }
    }
}

/** Soldan açılan panel: parmakla sürüklenerek açılabilir (sekme geçişi gibi parmağı izler), bırakınca açılır ya da geri kapanır */
@Composable
private fun LeftPanelLayer(c: @Composable () -> Unit) {
    val prog = remember { androidx.compose.animation.core.Animatable(0f) }
    var closing by remember { mutableStateOf(false) }
    var widthPx by remember { mutableStateOf(1f) }
    LaunchedEffect(AuraPanelHost.dragging, AuraPanelHost.dragFrac) {
        if (AuraPanelHost.dragging) prog.snapTo(AuraPanelHost.dragFrac)
    }
    LaunchedEffect(AuraPanelHost.dragging) {
        if (AuraPanelHost.dragging) return@LaunchedEffect
        if (AuraPanelHost.dragStarted) {
            AuraPanelHost.dragStarted = false
            val open = when (AuraPanelHost.flick) { 1 -> true; -1 -> false; else -> prog.value > 0.35f }
            AuraPanelHost.flick = 0
            if (open) prog.animateTo(1f, tween(220)) else { prog.animateTo(0f, tween(180)); AuraPanelHost.onDismiss() }
        } else prog.animateTo(1f, tween(320))
    }
    LaunchedEffect(closing) {
        if (closing) { prog.animateTo(0f, tween(260)); AuraPanelHost.onDismiss() }
    }
    androidx.activity.compose.BackHandler { closing = true }
    Box(
        Modifier.fillMaxSize().onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }.clipToBounds()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { closing = true }
    ) {
        Box(
            Modifier.fillMaxSize().padding(top = AuraPanelHost.top)
                .graphicsLayer { translationX = -(1f - prog.value) * widthPx }
                .background(AuraBg)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
        ) { c() }
    }
}

internal fun rgbToHsv(rgb: Int): FloatArray {
    val a = FloatArray(3)
    android.graphics.Color.colorToHSV(0xFF000000.toInt() or rgb, a)
    return a
}

internal fun hsvToRgb(h: Float, s: Float, v: Float): Int =
    android.graphics.Color.HSVToColor(floatArrayOf(h.coerceIn(0f, 359.99f), s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))) and 0xFFFFFF

@Composable
internal fun GradBar(frac: Float, colors: List<Color>, onFrac: (Float) -> Unit) {
    var w by remember { mutableStateOf(1f) }
    val thumbCol = Color(0xFFFFFFFF)
    Box(
        Modifier.fillMaxWidth().height(34.dp).onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) { detectTapGestures { onFrac((it.x / w).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) { detectDragGestures { c, _ -> c.consume(); onFrac((c.position.x / w).coerceIn(0f, 1f)) } }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val h = 16.dp.toPx()
            val top = (size.height - h) / 2f
            drawRoundRect(Brush.horizontalGradient(colors), Offset(0f, top), Size(size.width, h), androidx.compose.ui.geometry.CornerRadius(h / 2f))
            val cx = (frac * size.width).coerceIn(0f, size.width)
            drawCircle(Color(0x55000000), 14.dp.toPx(), Offset(cx, size.height / 2f))
            drawCircle(thumbCol, 12.dp.toPx(), Offset(cx, size.height / 2f))
            drawCircle(colors.let { c -> lerpList(c, frac) }, 8.dp.toPx(), Offset(cx, size.height / 2f))
        }
    }
}

private fun lerpList(c: List<Color>, f: Float): Color {
    if (c.size == 1) return c[0]
    val p = f.coerceIn(0f, 1f) * (c.size - 1)
    val i = p.toInt().coerceAtMost(c.size - 2)
    return androidx.compose.ui.graphics.lerp(c[i], c[i + 1], p - i)
}

/** "Vurgu" başlığı + hex kutusu + kayar renk çubukları */
@Composable
fun AccentCustomHeader() {
    val ctx = LocalContext.current
    // doygunluk ve parlaklık, seçili palet rengine bağlı: palet rengi değişince çubuklar o renge göre kurulur
    val baseRgb = if (AuraUi.accent == 20) AuraUi.customRgb else AuraUi.swatch(AuraUi.accent, AuraUi.light).let { (Math.round(it.red * 255) shl 16) or (Math.round(it.green * 255) shl 8) or Math.round(it.blue * 255) }
    var hsv by remember { mutableStateOf(rgbToHsv(baseRgb)) }
    var hex by remember { mutableStateOf("%06X".format(baseRgb)) }
    // yalnızca palet rengi seçilince çubuklar yeniden kurulur; çubuk sürüklenirken (özel renge geçişte) sıfırlanmaz
    androidx.compose.runtime.LaunchedEffect(AuraUi.accent, AuraUi.light) {
        if (AuraUi.accent != 20) { hsv = rgbToHsv(baseRgb); hex = "%06X".format(baseRgb) }
    }
    val cur = Color(0xFF000000L or hsvToRgb(hsv[0], hsv[1], hsv[2]).toLong())
    fun apply(h: Float, s: Float, vv: Float) {
        hsv = floatArrayOf(h, s, vv)
        val rgb = hsvToRgb(h, s, vv)
        hex = "%06X".format(rgb)
        AuraUi.setCustom(ctx, rgb)
    }
    Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Vurgu", color = AuraMuted, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Box(Modifier.size(22.dp).clip(CircleShape).background(cur))
        Spacer(Modifier.width(8.dp))
        Row(
            Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, AuraMuted.copy(alpha = 0.4f), RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("#", color = AuraMuted, fontSize = 15.sp)
            BasicTextField(
                value = hex,
                onValueChange = { raw ->
                    val f = raw.filter { it.isDigit() || it.lowercaseChar() in 'a'..'f' }.take(6).uppercase()
                    hex = f
                    if (f.length == 6) {
                        val rgb = f.toInt(16)
                        hsv = rgbToHsv(rgb)
                        AuraUi.setCustom(ctx, rgb)
                    }
                },
                singleLine = true,
                textStyle = TextStyle(color = AuraWhite, fontSize = 15.sp, fontWeight = FontWeight.Medium),
                cursorBrush = Brush.verticalGradient(listOf(AuraGreen, AuraGreen)),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                modifier = Modifier.width(72.dp)
            )
        }
    }
    Text("Ton", color = AuraMuted, fontSize = 13.sp)
    GradBar(
        hsv[0] / 360f, listOf(Color(0xFFFF0000), Color(0xFFFFFF00), Color(0xFF00FF00), Color(0xFF00FFFF), Color(0xFF0000FF), Color(0xFFFF00FF), Color(0xFFFF0000))
    ) { apply(it * 360f, hsv[1], hsv[2]) }
    Text("Doygunluk", color = AuraMuted, fontSize = 13.sp)
    GradBar(
        hsv[1], listOf(Color(0xFF000000L or hsvToRgb(hsv[0], 0f, hsv[2]).toLong()), Color(0xFF000000L or hsvToRgb(hsv[0], 1f, hsv[2]).toLong()))
    ) { apply(hsv[0], it, hsv[2]) }
    Text("Parlaklık", color = AuraMuted, fontSize = 13.sp)
    GradBar(
        hsv[2], listOf(Color.Black, Color(0xFF000000L or hsvToRgb(hsv[0], hsv[1], 1f).toLong()))
    ) { apply(hsv[0], hsv[1], it) }
    Spacer(Modifier.height(18.dp))
}


/** Hazır paket: vurgu rengi + koyu arka plan birlikte. accRgb null = varsayılan zümrüt, bgRgb null = varsayılan siyah */
private class ThemePack(val name: String, val accRgb: Int?, val bgRgb: Long?)

private val ThemePacks = listOf(
    ThemePack("Zümrüt", null, null),
    ThemePack("Okyanus", 0x0EA5E9, 0x0B1C2CL),
    ThemePack("Alacakaranlık", 0xEC4899, 0x24122EL),
    ThemePack("Aurora", 0x8B5CF6, 0x1A1020L),
    ThemePack("Kehribar", 0xF97316, 0x2B1B17L),
    ThemePack("Grafit", 0x94A3B8, 0x121212L),
    ThemePack("Bordo", 0xEF4444, 0x1C0E11L)
)

private fun packOn(p: ThemePack): Boolean {
    val accOk = if (p.accRgb == null) AuraUi.accent == 0 else AuraUi.accent == 20 && AuraUi.customRgb == p.accRgb
    val bgOk = BgLab.color == p.bgRgb?.let { Color(0xFF000000.toInt() or it.toInt()) }
    return accOk && bgOk
}

private fun applyPack(ctx: android.content.Context, p: ThemePack) {
    if (p.accRgb == null) AuraUi.setAccent(ctx, 0) else AuraUi.setCustom(ctx, p.accRgb)
    // arka plan rengi yalnızca karanlık temada geçerli: açıkta mod değişmesin diye atlanır
    if (p.bgRgb == null) BgLab.set(ctx, null) else if (!AuraUi.light) BgLab.set(ctx, p.bgRgb)
}

/** Seçimin canlı önizlemesi: gerçek tema renkleriyle çizilen küçük sohbet listesi */
@Composable
private fun ThemePreview() {
    val shape = RoundedCornerShape(24.dp)
    Box(Modifier.fillMaxWidth().height(250.dp).clip(shape).background(AuraBg).border(1.dp, AuraMuted.copy(alpha = 0.3f), shape)) {
        Column(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(46.dp).background(ChipLook.bg.compositeOver(AuraBg)), contentAlignment = Alignment.CenterStart) {
                Text("AuraChat", color = ChipLook.fg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 16.dp))
            }
            listOf(Triple("Ayşe", "Akşam görüşürüz", "09:41"), Triple("Proje grubu", "Dosyayı gönderdim", "Dün"), Triple("Anne", "Tamam kızım", "Pzt")).forEachIndexed { i, r ->
                Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(CircleShape).background(AuraGreen.copy(alpha = 0.35f).compositeOver(AuraBg)))
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(r.first, color = AuraWhite, fontSize = 14.5.sp, fontWeight = FontWeight.Medium)
                        Text(r.second, color = AuraMuted, fontSize = 13.sp)
                    }
                    Text(r.third, color = if (i == 0) AuraGreen else AuraMuted, fontSize = 12.sp)
                }
            }
        }
        Box(
            Modifier.align(Alignment.BottomEnd).padding(16.dp).size(46.dp).clip(RoundedCornerShape(14.dp)).background(AuraGreen),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Add, null, tint = Color(0xFF07140D), modifier = Modifier.size(24.dp)) }
    }
}

@Composable
private fun PackThumb(p: ThemePack, sel: Boolean, onClick: () -> Unit) {
    val bg = Color(0xFF000000.toInt() or (p.bgRgb ?: 0L).toInt())
    val ac = Color(0xFF000000.toInt() or (p.accRgb ?: 0x10B981))
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.width(92.dp).clickable { onClick() }, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(92.dp, 112.dp).clip(shape).background(bg)
                .border(if (sel) 2.5.dp else 1.dp, if (sel) AuraWhite else AuraMuted.copy(alpha = 0.3f), shape)
        ) {
            Box(Modifier.fillMaxWidth().height(14.dp).background(ac.copy(alpha = 0.25f).compositeOver(bg)))
            Column(Modifier.padding(top = 24.dp, start = 8.dp, end = 8.dp)) {
                Box(Modifier.fillMaxWidth(0.7f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF3A454B)))
                Spacer(Modifier.height(5.dp))
                Box(Modifier.fillMaxWidth(0.5f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF2A343A)))
            }
            Box(Modifier.align(Alignment.BottomEnd).padding(8.dp).size(16.dp).clip(RoundedCornerShape(5.dp)).background(ac))
        }
        Text(p.name, color = AuraWhite, fontSize = 12.5.sp, modifier = Modifier.padding(top = 7.dp))
    }
}

/** Uygulama teması açılır paneli (sohbet listesi başlığı, menü ve ayarlar aynı paneli kullanır) */
@Composable
fun AppThemePanel(onDismiss: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var fine by remember { mutableStateOf(false) }
AuraTopPanel(onDismissRequest = onDismiss, topBarHeight = 0.dp, fromLeft = true) {
    Column(
        Modifier.fillMaxWidth().verticalScroll(androidx.compose.foundation.rememberScrollState())
            .navigationBarsPadding().padding(bottom = 24.dp)
    ) {
        // başlık alanı vurgu rengine göre boyanır; sağda Sistem / Aydınlık / Karanlık seçici
        Row(
            Modifier.fillMaxWidth().background(ChipLook.bg.compositeOver(AuraBg)).statusBarsPadding().padding(start = 20.dp, end = 14.dp, top = 14.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Uygulama teması", color = ChipLook.fg, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Text("Seçtiğin hemen uygulanır", color = ChipLook.fg.copy(alpha = 0.8f), fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
            }
            Row(Modifier.clip(RoundedCornerShape(50)).background(ChipLook.fg.copy(alpha = 0.12f)).padding(3.dp)) {
                listOf(2 to Icons.Default.PhoneAndroid, 1 to Icons.Default.LightMode, 0 to Icons.Default.DarkMode).forEach { (mode, icon) ->
                    val on = AuraUi.mode == mode
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).background(if (on) ChipLook.fg.copy(alpha = 0.25f) else Color.Transparent)
                            .clickable { AuraUi.setMode(ctx, mode) },
                        contentAlignment = Alignment.Center
                    ) { Icon(icon, when (mode) { 2 -> "Sistem"; 1 -> "Aydınlık"; else -> "Karanlık" }, tint = ChipLook.fg.copy(alpha = if (on) 1f else 0.65f), modifier = Modifier.size(20.dp)) }
                }
            }
        }
        Column(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 16.dp)) {
            ThemePreview()

            val cur = ThemePacks.firstOrNull { packOn(it) }
            Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Hazır paketler", color = AuraWhite, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(cur?.name ?: "Özel", color = AuraMuted, fontSize = 13.sp)
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ThemePacks.forEach { p -> PackThumb(p, cur === p) { applyPack(ctx, p) } }
            }

            val fshape = RoundedCornerShape(16.dp)
            Row(
                Modifier.fillMaxWidth().padding(top = 20.dp).clip(fshape).background(AuraMuted.copy(alpha = 0.12f))
                    .border(1.dp, AuraMuted.copy(alpha = 0.25f), fshape).clickable { fine = !fine }.padding(horizontal = 16.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("İnce ayar", color = AuraWhite, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Icon(Icons.Default.KeyboardArrowDown, null, tint = AuraMuted, modifier = Modifier.size(22.dp).rotate(if (fine) 180f else 0f))
            }
            if (fine) {
                Text("Tüm vurgu renkleri", color = AuraMuted, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 20.dp, bottom = 12.dp))
                val palLight = AuraUi.light
                (0 until 20).toList().chunked(5).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        row.forEach { c ->
                            val on = AuraUi.accent == c
                            Box(
                                Modifier.size(52.dp).then(if (on) Modifier.border(2.dp, AuraWhite, CircleShape).padding(4.dp) else Modifier)
                                    .clip(CircleShape).background(AuraUi.swatch(c, palLight)).clickable { AuraUi.setAccent(ctx, c) },
                                contentAlignment = Alignment.Center
                            ) { if (on) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
                        }
                    }
                }
                AccentCustomHeader()
                Text("Arka plan rengi", color = AuraMuted, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp, bottom = 12.dp))
                BgLabBar()
            }

            Box(
                Modifier.padding(top = 20.dp).clip(RoundedCornerShape(50)).clickable { AuraUi.setAccent(ctx, 0); BgLab.set(ctx, null) }
                    .padding(horizontal = 6.dp, vertical = 10.dp)
            ) { Text("Sıfırla", color = AuraMuted, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
        }
    }
}
}

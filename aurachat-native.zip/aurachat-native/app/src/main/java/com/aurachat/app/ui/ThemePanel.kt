package com.aurachat.app.ui

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.ui.draw.rotate
import androidx.compose.foundation.horizontalScroll
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider

/** Üstten açılan panelin içeriği; Dialog yerine uygulamanın kendi penceresinde çizilir (durum çubuğu simgeleri uygulama temasına uysun diye) */
object AuraPanelHost {
    var content by androidx.compose.runtime.mutableStateOf<(@Composable () -> Unit)?>(null)
    var onDismiss: () -> Unit = {}
    var top by androidx.compose.runtime.mutableStateOf(60.dp)
    var fromLeft by androidx.compose.runtime.mutableStateOf(false)
    /** Sohbet listesinde sağa kaydırınca tema panelini açma isteği */
    var openRequest by androidx.compose.runtime.mutableStateOf(false)
    /** Sohbet listesinde parmak panel açıyor mu (panel parmağı izler) ve ne kadar açık (0..1) */
    var dragging by androidx.compose.runtime.mutableStateOf(false)
    var dragFrac by androidx.compose.runtime.mutableFloatStateOf(0f)
    var dragStarted = false
    /** Bırakırken hız: 1 = hızlı sağa (aç), -1 = hızlı sola (kapat), 0 = konuma göre */
    var flick = 0
}

@Composable
fun AuraTopPanel(
    onDismissRequest: () -> Unit,
    topBarHeight: androidx.compose.ui.unit.Dp = 60.dp,
    fromLeft: Boolean = false,
    content: @Composable () -> Unit
) {
    SideEffect {
        AuraPanelHost.content = content
        AuraPanelHost.onDismiss = onDismissRequest
        AuraPanelHost.top = topBarHeight
        AuraPanelHost.fromLeft = fromLeft
    }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { AuraPanelHost.content = null } }
}

@Composable
fun AuraPanelHostLayer() {
    val c = AuraPanelHost.content ?: return
    if (AuraPanelHost.fromLeft) { LeftPanelLayer(c); return }
    val st = remember { MutableTransitionState(false).apply { targetState = true } }
    LaunchedEffect(st.currentState, st.targetState) {
        if (!st.targetState && st.isIdle) AuraPanelHost.onDismiss()
    }
    androidx.activity.compose.BackHandler { st.targetState = false }
    Box(
        Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { st.targetState = false }
    ) {
        Box((if (AuraPanelHost.fromLeft) Modifier.fillMaxSize() else Modifier.fillMaxSize().statusBarsPadding()).padding(top = AuraPanelHost.top).clipToBounds()) {
            AnimatedVisibility(
                visibleState = st,
                enter = if (AuraPanelHost.fromLeft) androidx.compose.animation.slideInHorizontally(tween(320)) { -it } else slideInVertically(tween(320)) { -it },
                exit = if (AuraPanelHost.fromLeft) androidx.compose.animation.slideOutHorizontally(tween(260)) { -it } else slideOutVertically(tween(260)) { -it }
            ) {
                Box(
                    Modifier.fillMaxSize().background(AuraBg)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                ) { c() }
            }
        }
    }
}

/** Soldan açılan panel: parmakla sürüklenerek açılabilir (sekme geçişi gibi parmağı izler), bırakınca açılır ya da geri kapanır */
@Composable
private fun LeftPanelLayer(c: @Composable () -> Unit) {
    val prog = remember { androidx.compose.animation.core.Animatable(0f) }
    var closing by remember { mutableStateOf(false) }
    var widthPx by remember { mutableStateOf(1f) }
    LaunchedEffect(AuraPanelHost.dragging, AuraPanelHost.dragFrac) {
        if (AuraPanelHost.dragging) prog.snapTo(AuraPanelHost.dragFrac)
    }
    LaunchedEffect(AuraPanelHost.dragging) {
        if (AuraPanelHost.dragging) return@LaunchedEffect
        if (AuraPanelHost.dragStarted) {
            AuraPanelHost.dragStarted = false
            val open = when (AuraPanelHost.flick) { 1 -> true; -1 -> false; else -> prog.value > 0.35f }
            AuraPanelHost.flick = 0
            if (open) prog.animateTo(1f, tween(220)) else { prog.animateTo(0f, tween(180)); AuraPanelHost.onDismiss() }
        } else prog.animateTo(1f, tween(320))
    }
    LaunchedEffect(closing) {
        if (closing) { prog.animateTo(0f, tween(260)); AuraPanelHost.onDismiss() }
    }
    androidx.activity.compose.BackHandler { closing = true }
    Box(
        Modifier.fillMaxSize().onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }.clipToBounds()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { closing = true }
    ) {
        Box(
            Modifier.fillMaxSize().padding(top = AuraPanelHost.top)
                .graphicsLayer { translationX = -(1f - prog.value) * widthPx }
                .background(AuraBg)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
        ) { c() }
    }
}

/** Hex kutusu: 6 haneli geçerli kod yazılınca anında uygular; odaklanınca klavyenin üstüne kayar */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun HexField(rgb: Int, onCommit: (Int) -> Unit) {
    val cur = String.format("%06X", rgb and 0xFFFFFF)
    var text by remember(cur) { mutableStateOf(cur) }
    val req = remember { BringIntoViewRequester() }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    Row(
        Modifier.clip(RoundedCornerShape(8.dp)).background(AuraMuted.copy(alpha = 0.15f)).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("#", color = AuraMuted, fontSize = 13.sp)
        BasicTextField(
            value = text,
            onValueChange = { v ->
                val t = v.uppercase().filter { it in "0123456789ABCDEF" }.take(6)
                text = t
                if (t.length == 6) onCommit(t.toInt(16))
            },
            singleLine = true,
            textStyle = TextStyle(color = AuraWhite, fontSize = 13.sp, fontWeight = FontWeight.Medium),
            cursorBrush = SolidColor(AuraGreen),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
            modifier = Modifier.width(62.dp).bringIntoViewRequester(req).onFocusChanged { st ->
                if (st.isFocused) scope.launch { kotlinx.coroutines.delay(350); req.bringIntoView() }
            }
        )
    }
}

internal fun rgbToHsv(rgb: Int): FloatArray {
    val a = FloatArray(3)
    android.graphics.Color.colorToHSV(0xFF000000.toInt() or rgb, a)
    return a
}

internal fun hsvToRgb(h: Float, s: Float, v: Float): Int =
    android.graphics.Color.HSVToColor(floatArrayOf(h.coerceIn(0f, 359.99f), s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))) and 0xFFFFFF

@Composable
internal fun GradBar(frac: Float, colors: List<Color>, onFrac: (Float) -> Unit) {
    var w by remember { mutableStateOf(1f) }
    val thumbCol = Color(0xFFFFFFFF)
    Box(
        Modifier.fillMaxWidth().height(34.dp).onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) { detectTapGestures { onFrac((it.x / w).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) { detectDragGestures { c, _ -> c.consume(); onFrac((c.position.x / w).coerceIn(0f, 1f)) } }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val h = 16.dp.toPx()
            val top = (size.height - h) / 2f
            drawRoundRect(Brush.horizontalGradient(colors), Offset(0f, top), Size(size.width, h), androidx.compose.ui.geometry.CornerRadius(h / 2f))
            val cx = (frac * size.width).coerceIn(0f, size.width)
            drawCircle(Color(0x55000000), 14.dp.toPx(), Offset(cx, size.height / 2f))
            drawCircle(thumbCol, 12.dp.toPx(), Offset(cx, size.height / 2f))
            drawCircle(colors.let { c -> lerpList(c, frac) }, 8.dp.toPx(), Offset(cx, size.height / 2f))
        }
    }
}

private fun lerpList(c: List<Color>, f: Float): Color {
    if (c.size == 1) return c[0]
    val p = f.coerceIn(0f, 1f) * (c.size - 1)
    val i = p.toInt().coerceAtMost(c.size - 2)
    return androidx.compose.ui.graphics.lerp(c[i], c[i + 1], p - i)
}

/** Hazır paket: vurgu rengi + koyu arka plan birlikte. accRgb null = varsayılan zümrüt, bgRgb null = varsayılan siyah */
private class ThemePack(val name: String, val accRgb: Int?, val darkBg: Long? = null, val inputRgb: Long? = null, val lightHue: Int? = null) {
    private val hsv: FloatArray? get() = (lightHue ?: accRgb)?.let { rgbToHsv(it) }
    /** Koyu zemin: vurgu renginin tonunda, siyaha yakın (renkli ama koyu). Gri vurguda hafif gri. Varsayılanda saf siyah */
    val bgRgb: Long? get() {
        if (darkBg != null) return darkBg
        val h = hsv ?: return null
        return hsvToRgb(h[0], if (h[1] < 0.35f) 0.10f else 0.55f, 0.14f).toLong()
    }
    /** Açık zemin: vurgu renginin tonunda, beyaza yakın (renkli ama açık). Gri vurguda açık gri. Varsayılanda beyaz */
    val lightBg: Long? get() {
        val h = hsv ?: return null
        return hsvToRgb(h[0], if (h[1] < 0.35f) 0.03f else 0.09f, 0.965f).toLong()
    }
}

private val ThemePacks = listOf(
    ThemePack("Zümrüt", null),
    ThemePack("Okyanus", 0x21C054, darkBg = 0x0A1016L, inputRgb = 0x8D9699L, lightHue = 0x0EA5E9),
    ThemePack("Günbatımı", 0xEC4899),
    ThemePack("Aurora", 0x8B5CF6),
    ThemePack("Kehribar", 0xF97316),
    ThemePack("Grafit", 0x94A3B8),
    ThemePack("Bordo", 0xEF4444),
    ThemePack("Orman", 0x22C55E),
    ThemePack("Gece mavisi", 0x3B82F6),
    ThemePack("Turkuaz", 0x14B8A6),
    ThemePack("Altın", 0xEAB308),
    ThemePack("Lavanta", 0xA78BFA),
    ThemePack("Mercan", 0xFB7185),
    ThemePack("Nane", 0x34D399),
    ThemePack("Gökyüzü", 0x38BDF8),
    ThemePack("Mürdüm", 0xD946EF)
)

private fun packOn(p: ThemePack): Boolean {
    val accOk = if (p.accRgb == null) AuraUi.accent == 0 else AuraUi.accent == 20 && AuraUi.customRgb == p.accRgb
    val bgOk = if (AuraUi.light) BgLab.lightColor == p.lightBg?.let { Color(0xFF000000.toInt() or it.toInt()) }
        else BgLab.color == p.bgRgb?.let { Color(0xFF000000.toInt() or it.toInt()) } &&
            BgLab.input == p.inputRgb?.let { Color(0xFF000000.toInt() or it.toInt()) }
    return accOk && bgOk
}

private fun applyPack(ctx: android.content.Context, p: ThemePack) {
    if (p.accRgb == null) AuraUi.setAccent(ctx, 0) else AuraUi.setCustom(ctx, p.accRgb)
    // arka plan: açık temada paketin açık tonu, koyuda koyu tonu (ikisi ayrı saklanır)
    if (AuraUi.light) BgLab.setLight(ctx, p.lightBg) else { BgLab.set(ctx, p.bgRgb); BgLab.setInput(ctx, p.inputRgb) }
}

/** Paket değerleri yüzde olarak (renk = ton çemberi, ton = koyu→açık, zeminler = ton çubuğu konumu) */
private fun statsLine(accRgb: Int, darkBg: Long?, lightBg: Long?): String {
    val h = FloatArray(3)
    androidx.core.graphics.ColorUtils.colorToHSL(0xFF000000.toInt() or accRgb, h)
    val dv = darkBg?.let { rgbToHsv(it.toInt())[2] } ?: 0f
    val lv = lightBg?.let { rgbToHsv(it.toInt())[2] } ?: 1f
    fun pc(x: Float) = Math.round(x.coerceIn(0f, 1f) * 100f)
    return "renk %" + pc(h[0] / 360f) + " · ton %" + pc((h[2] - 0.25f) / 0.55f) + " · koyu zemin %" + pc(dv / 0.25f) + " · açık zemin %" + pc((1f - lv) / 0.2f)
}

/** Seçimin canlı önizlemesi: gerçek tema renkleriyle çizilen küçük sohbet listesi */
@Composable
private fun ThemePreview() {
    val shape = RoundedCornerShape(24.dp)
    Box(Modifier.fillMaxWidth().height(250.dp).clip(shape).background(AuraBg).border(1.dp, AuraMuted.copy(alpha = 0.3f), shape)) {
        Column(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(46.dp).background(ChipLook.bg.compositeOver(AuraBg)), contentAlignment = Alignment.CenterStart) {
                Text("AuraChat", color = if (AuraUi.light) ChipLook.fg else AuraWhite, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 16.dp))
            }
            listOf(Triple("Ayşe", "Akşam görüşürüz", "09:41"), Triple("Proje grubu", "Dosyayı gönderdim", "Dün"), Triple("Anne", "Tamam kızım", "Pzt")).forEachIndexed { i, r ->
                Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(CircleShape).background(AuraGreen.copy(alpha = 0.35f).compositeOver(AuraBg)))
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(r.first, color = AuraWhite, fontSize = 14.5.sp, fontWeight = FontWeight.Medium)
                        Text(r.second, color = AuraMuted, fontSize = 13.sp)
                    }
                    Text(r.third, color = if (i == 0) AuraGreen else AuraMuted, fontSize = 12.sp)
                }
            }
        }
        Box(
            Modifier.align(Alignment.BottomEnd).padding(16.dp).size(46.dp).clip(RoundedCornerShape(14.dp)).background(AuraGreen),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Add, null, tint = Color(0xFF07140D), modifier = Modifier.size(24.dp)) }
    }
}

@Composable
private fun PackThumb(p: ThemePack, num: Int, sel: Boolean, onClick: () -> Unit) {
    val lt = AuraUi.light
    val bg = if (lt) Color(0xFF000000.toInt() or (p.lightBg ?: 0xFFFFFFL).toInt()) else Color(0xFF000000.toInt() or (p.bgRgb ?: 0L).toInt())
    val ac = Color(0xFF000000.toInt() or (p.accRgb ?: 0x10B981))
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.width(92.dp).clickable { onClick() }, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(92.dp, 112.dp).clip(shape).background(bg)
                .border(if (sel) 2.5.dp else 1.dp, if (sel) AuraWhite else AuraMuted.copy(alpha = 0.3f), shape)
        ) {
            Box(Modifier.fillMaxWidth().height(14.dp).background(ac.copy(alpha = 0.25f).compositeOver(bg)))
            Column(Modifier.padding(top = 24.dp, start = 8.dp, end = 8.dp)) {
                Box(Modifier.fillMaxWidth(0.7f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(if (lt) Color(0xFFC9D0D4) else Color(0xFF3A454B)))
                Spacer(Modifier.height(5.dp))
                Box(Modifier.fillMaxWidth(0.5f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(if (lt) Color(0xFFE0E5E8) else Color(0xFF2A343A)))
            }
            Box(Modifier.align(Alignment.BottomEnd).padding(8.dp).size(16.dp).clip(RoundedCornerShape(5.dp)).background(ac))
            Text(num.toString(), color = if (lt) Color(0xFF3B4A54) else Color(0xFFA7ADB2), fontSize = 12.sp, modifier = Modifier.align(Alignment.BottomStart).padding(start = 9.dp, bottom = 7.dp))
        }
        Text(p.name, color = AuraWhite, fontSize = 12.5.sp, modifier = Modifier.padding(top = 7.dp))
    }
}

/** Uygulama teması açılır paneli (sohbet listesi başlığı, menü ve ayarlar aynı paneli kullanır) */
@Composable
fun AppThemePanel(onDismiss: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
AuraTopPanel(onDismissRequest = onDismiss, topBarHeight = 0.dp, fromLeft = true) {
    Column(Modifier.fillMaxSize().imePadding()) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 8.dp, end = 16.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(44.dp).clip(CircleShape).clickable { onDismiss() }, contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite)
            }
            Text("Uygulama teması", color = AuraWhite, fontSize = 19.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f).padding(start = 8.dp))
            Row(Modifier.clip(RoundedCornerShape(50)).background(AuraMuted.copy(alpha = 0.15f)).padding(3.dp)) {
                listOf(2 to Icons.Default.PhoneAndroid, 1 to Icons.Default.LightMode, 0 to Icons.Default.DarkMode).forEach { (mode, icon) ->
                    val on = AuraUi.mode == mode
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).background(if (on) AuraMuted.copy(alpha = 0.3f) else Color.Transparent)
                            .clickable { AuraUi.setMode(ctx, mode) },
                        contentAlignment = Alignment.Center
                    ) { Icon(icon, when (mode) { 2 -> "Sistem"; 1 -> "Aydınlık"; else -> "Karanlık" }, tint = AuraWhite.copy(alpha = if (on) 1f else 0.6f), modifier = Modifier.size(20.dp)) }
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 16.dp)) {
            ThemePreview()

            val cur = ThemePacks.firstOrNull { packOn(it) }
            Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Hazır paketler", color = AuraWhite, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(cur?.name ?: "Özel", color = AuraMuted, fontSize = 13.sp)
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ThemePacks.forEachIndexed { i, p -> PackThumb(p, i + 1, cur === p) { applyPack(ctx, p) } }
            }

            run {
                val idx = ThemePacks.indexOf(cur)
                val accNow = if (AuraUi.accent == 20) AuraUi.customRgb
                    else AuraUi.swatch(AuraUi.accent, AuraUi.light).let { (Math.round(it.red * 255) shl 16) or (Math.round(it.green * 255) shl 8) or Math.round(it.blue * 255) }
                fun rgbL(c: Color?): Long? = c?.let { ((Math.round(it.red * 255) shl 16) or (Math.round(it.green * 255) shl 8) or Math.round(it.blue * 255)).toLong() }
                val line = if (cur != null) "Paket " + (idx + 1) + " · " + cur.name + ": " + statsLine(cur.accRgb ?: 0x10B981, cur.bgRgb, cur.lightBg)
                    else "Özel: " + statsLine(accNow, rgbL(BgLab.color), rgbL(BgLab.lightColor))
                Text(line, color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            }
            val curRgb = if (AuraUi.accent == 20) AuraUi.customRgb
                else AuraUi.swatch(AuraUi.accent, AuraUi.light).let { (Math.round(it.red * 255) shl 16) or (Math.round(it.green * 255) shl 8) or Math.round(it.blue * 255) }
            val chsv = rgbToHsv(curRgb)
            val hsl = FloatArray(3).also { androidx.core.graphics.ColorUtils.colorToHSL(0xFF000000.toInt() or curRgb, it) }   // ton 0..360, doygunluk 0..1, açıklık 0..1
            val hueSat = hsl[1].coerceAtLeast(0.5f)
            fun hslRgb(h: Float, sat: Float, l: Float): Int = androidx.core.graphics.ColorUtils.HSLToColor(floatArrayOf(h, sat, l)) and 0xFFFFFF
            Column(Modifier.fillMaxWidth().padding(top = 20.dp).clip(RoundedCornerShape(16.dp)).background(AuraMuted.copy(alpha = 0.12f)).padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Vurgu rengi", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text("%" + Math.round(hsl[0] / 360f * 100f), color = AuraMuted, fontSize = 13.sp, modifier = Modifier.padding(end = 8.dp))
                    HexField(curRgb) { AuraUi.setCustom(ctx, it) }
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.size(20.dp).clip(CircleShape).background(AuraGreen))
                }
                GradBar(
                    hsl[0] / 360f,
                    listOf(Color(0xFFFF0000), Color(0xFFFFFF00), Color(0xFF00FF00), Color(0xFF00FFFF), Color(0xFF0000FF), Color(0xFFFF00FF), Color(0xFFFF0000))
                ) { f -> AuraUi.setCustom(ctx, hslRgb(f * 360f, hueSat, hsl[2])) }
                // vurgu tonu: aynı rengin koyudan açığa tonu
                Row(Modifier.padding(top = 8.dp)) {
                    Text("Vurgu tonu", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text("%" + Math.round(((hsl[2] - 0.25f) / 0.55f).coerceIn(0f, 1f) * 100f), color = AuraMuted, fontSize = 13.sp, modifier = Modifier.padding(end = 8.dp))
                    HexField(curRgb) { AuraUi.setCustom(ctx, it) }
                }
                GradBar(
                    ((hsl[2] - 0.25f) / 0.55f).coerceIn(0f, 1f),
                    listOf(Color(0xFF000000L or hslRgb(hsl[0], hsl[1], 0.25f).toLong()), Color(0xFF000000L or hslRgb(hsl[0], hsl[1], 0.8f).toLong()))
                ) { f -> AuraUi.setCustom(ctx, hslRgb(hsl[0], hsl[1], 0.25f + 0.55f * f)) }
                if (AuraUi.light) {
                    // açık temada: beyazdan krem / gri tonlara
                    val lc = BgLab.lightColor
                    val lv = if (lc == null) 1f else rgbToHsv((Math.round(lc.red * 255) shl 16) or (Math.round(lc.green * 255) shl 8) or Math.round(lc.blue * 255))[2]
                    Row(Modifier.padding(top = 8.dp)) {
                        Text("Arka plan tonu", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text("%" + Math.round(((1f - lv) / 0.2f).coerceIn(0f, 1f) * 100f), color = AuraMuted, fontSize = 13.sp, modifier = Modifier.padding(end = 8.dp))
                        HexField(if (lc == null) 0xFFFFFF else (Math.round(lc.red * 255) shl 16) or (Math.round(lc.green * 255) shl 8) or Math.round(lc.blue * 255)) { BgLab.setLight(ctx, it.toLong()) }
                    }
                    GradBar(
                        ((1f - lv) / 0.2f).coerceIn(0f, 1f),
                        listOf(Color.White, Color(0xFF000000L or hsvToRgb(chsv[0], 0.14f, 0.8f).toLong()))
                    ) { f ->
                        if (f < 0.02f) BgLab.setLight(ctx, null)
                        else BgLab.setLight(ctx, hsvToRgb(chsv[0], 0.14f * f, 1f - 0.2f * f).toLong())
                    }
                } else {
                    val bg = BgLab.color
                    val bhsv = if (bg == null) floatArrayOf(chsv[0], 0.35f, 0f)
                        else rgbToHsv((Math.round(bg.red * 255) shl 16) or (Math.round(bg.green * 255) shl 8) or Math.round(bg.blue * 255))
                    Row(Modifier.padding(top = 8.dp)) {
                        Text("Arka plan koyuluğu", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text("%" + Math.round((bhsv[2] / 0.25f).coerceIn(0f, 1f) * 100f), color = AuraMuted, fontSize = 13.sp, modifier = Modifier.padding(end = 8.dp))
                        val bgShown = bg ?: AuraBg
                        HexField((Math.round(bgShown.red * 255) shl 16) or (Math.round(bgShown.green * 255) shl 8) or Math.round(bgShown.blue * 255)) { BgLab.set(ctx, it.toLong()) }
                    }
                    GradBar(
                        (bhsv[2] / 0.25f).coerceIn(0f, 1f),
                        listOf(Color.Black, Color(0xFF000000L or hsvToRgb(bhsv[0], bhsv[1].coerceAtLeast(0.2f), 0.25f).toLong()))
                    ) { f ->
                        if (f < 0.02f) BgLab.set(ctx, null)
                        else BgLab.set(ctx, hsvToRgb(bhsv[0], bhsv[1].coerceAtLeast(0.2f), f * 0.25f).toLong())
                    }
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(AuraMuted.copy(alpha = 0.2f)))
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 14.dp, end = 20.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.clip(RoundedCornerShape(50)).clickable { AuraUi.setAccent(ctx, 0); BgLab.set(ctx, null); BgLab.setLight(ctx, null); BgLab.setInput(ctx, null) }.padding(horizontal = 6.dp, vertical = 14.dp)
            ) { Text("Sıfırla", color = AuraMuted, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.weight(1f).height(50.dp).clip(RoundedCornerShape(25.dp)).background(AuraGreen).clickable { onDismiss() },
                contentAlignment = Alignment.Center
            ) { Text("Uygula", color = Color(0xFF07140D), fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}
}

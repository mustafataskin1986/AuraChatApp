package com.aurachat.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider

/** Üst çubuğun hemen altından, boşluksuz, aşağı kayarak alta kadar inen panel */
@Composable
fun AuraTopPanel(
    onDismissRequest: () -> Unit,
    topBarHeight: androidx.compose.ui.unit.Dp = 60.dp,
    content: @Composable () -> Unit
) {
    val st = remember { MutableTransitionState(false).apply { targetState = true } }
    LaunchedEffect(st.currentState, st.targetState) {
        if (!st.targetState && st.isIdle) onDismissRequest()
    }
    Dialog(
        onDismissRequest = { st.targetState = false },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        val v = LocalView.current
        val lightUi = AuraUi.light
        SideEffect {
            val w = (v.parent as? DialogWindowProvider)?.window
            if (w != null) {
                w.setDimAmount(0f)
                val ctl = androidx.core.view.WindowCompat.getInsetsController(w, v)
                ctl.isAppearanceLightStatusBars = lightUi
                ctl.isAppearanceLightNavigationBars = lightUi
            }
        }
        Box(
            Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { st.targetState = false }
        ) {
            Box(Modifier.fillMaxSize().statusBarsPadding().padding(top = topBarHeight).clipToBounds()) {
                AnimatedVisibility(
                    visibleState = st,
                    enter = slideInVertically(tween(320)) { -it },
                    exit = slideOutVertically(tween(260)) { -it }
                ) {
                    Box(
                        Modifier.fillMaxSize().background(auraWinColor(AuraSurface))
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    ) { content() }
                }
            }
        }
    }
}

private fun rgbToHsv(rgb: Int): FloatArray {
    val a = FloatArray(3)
    android.graphics.Color.colorToHSV(0xFF000000.toInt() or rgb, a)
    return a
}

private fun hsvToRgb(h: Float, s: Float, v: Float): Int =
    android.graphics.Color.HSVToColor(floatArrayOf(h.coerceIn(0f, 359.99f), s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))) and 0xFFFFFF

@Composable
private fun GradBar(frac: Float, colors: List<Color>, onFrac: (Float) -> Unit) {
    var w by remember { mutableStateOf(1f) }
    val thumbCol = Color(0xFFFFFFFF)
    Box(
        Modifier.fillMaxWidth().height(34.dp).onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) { detectTapGestures { onFrac((it.x / w).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) { detectDragGestures { c, _ -> c.consume(); onFrac((c.position.x / w).coerceIn(0f, 1f)) } }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val h = 16.dp.toPx()
            val top = (size.height - h) / 2f
            drawRoundRect(Brush.horizontalGradient(colors), Offset(0f, top), Size(size.width, h), androidx.compose.ui.geometry.CornerRadius(h / 2f))
            val cx = (frac * size.width).coerceIn(0f, size.width)
            drawCircle(Color(0x55000000), 14.dp.toPx(), Offset(cx, size.height / 2f))
            drawCircle(thumbCol, 12.dp.toPx(), Offset(cx, size.height / 2f))
            drawCircle(colors.let { c -> lerpList(c, frac) }, 8.dp.toPx(), Offset(cx, size.height / 2f))
        }
    }
}

private fun lerpList(c: List<Color>, f: Float): Color {
    if (c.size == 1) return c[0]
    val p = f.coerceIn(0f, 1f) * (c.size - 1)
    val i = p.toInt().coerceAtMost(c.size - 2)
    return androidx.compose.ui.graphics.lerp(c[i], c[i + 1], p - i)
}

/** "Vurgu" başlığı + hex kutusu + kayar renk çubukları */
@Composable
fun AccentCustomHeader() {
    val ctx = LocalContext.current
    var hsv by remember { mutableStateOf(rgbToHsv(AuraUi.customRgb)) }
    var hex by remember { mutableStateOf("%06X".format(AuraUi.customRgb)) }
    val cur = Color(0xFF000000L or hsvToRgb(hsv[0], hsv[1], hsv[2]).toLong())
    fun apply(h: Float, s: Float, vv: Float) {
        hsv = floatArrayOf(h, s, vv)
        val rgb = hsvToRgb(h, s, vv)
        hex = "%06X".format(rgb)
        AuraUi.setCustom(ctx, rgb)
    }
    Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Vurgu", color = AuraMuted, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Box(Modifier.size(22.dp).clip(CircleShape).background(cur))
        Spacer(Modifier.width(8.dp))
        Row(
            Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, AuraMuted.copy(alpha = 0.4f), RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("#", color = AuraMuted, fontSize = 15.sp)
            BasicTextField(
                value = hex,
                onValueChange = { raw ->
                    val f = raw.filter { it.isDigit() || it.lowercaseChar() in 'a'..'f' }.take(6).uppercase()
                    hex = f
                    if (f.length == 6) {
                        val rgb = f.toInt(16)
                        hsv = rgbToHsv(rgb)
                        AuraUi.setCustom(ctx, rgb)
                    }
                },
                singleLine = true,
                textStyle = TextStyle(color = AuraWhite, fontSize = 15.sp, fontWeight = FontWeight.Medium),
                cursorBrush = Brush.verticalGradient(listOf(AuraGreen, AuraGreen)),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                modifier = Modifier.width(72.dp)
            )
        }
    }
    Text("Ton", color = AuraMuted, fontSize = 13.sp)
    GradBar(
        hsv[0] / 360f,
        (0..12).map { Color(0xFF000000L or hsvToRgb(it * 30f, 1f, 1f).toLong()) }
    ) { apply(it * 359.99f, if (hsv[1] < 0.15f) 0.85f else hsv[1], if (hsv[2] < 0.2f) 0.9f else hsv[2]) }
    Text("Doygunluk", color = AuraMuted, fontSize = 13.sp)
    GradBar(
        hsv[1], listOf(Color(0xFF000000L or hsvToRgb(hsv[0], 0f, hsv[2]).toLong()), Color(0xFF000000L or hsvToRgb(hsv[0], 1f, hsv[2]).toLong()))
    ) { apply(hsv[0], it, hsv[2]) }
    Text("Parlaklık", color = AuraMuted, fontSize = 13.sp)
    GradBar(
        hsv[2], listOf(Color.Black, Color(0xFF000000L or hsvToRgb(hsv[0], hsv[1], 1f).toLong()))
    ) { apply(hsv[0], hsv[1], it) }
    Spacer(Modifier.height(18.dp))
}

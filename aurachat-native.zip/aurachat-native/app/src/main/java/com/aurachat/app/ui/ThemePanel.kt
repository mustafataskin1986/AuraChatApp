package com.aurachat.app.ui

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material.icons.filled.Check
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider

/** Üstten açılan panelin içeriği; Dialog yerine uygulamanın kendi penceresinde çizilir (durum çubuğu simgeleri uygulama temasına uysun diye) */
object AuraPanelHost {
    var content by androidx.compose.runtime.mutableStateOf<(@Composable () -> Unit)?>(null)
    var onDismiss: () -> Unit = {}
    var top by androidx.compose.runtime.mutableStateOf(60.dp)
}

@Composable
fun AuraTopPanel(
    onDismissRequest: () -> Unit,
    topBarHeight: androidx.compose.ui.unit.Dp = 60.dp,
    content: @Composable () -> Unit
) {
    SideEffect {
        AuraPanelHost.content = content
        AuraPanelHost.onDismiss = onDismissRequest
        AuraPanelHost.top = topBarHeight
    }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { AuraPanelHost.content = null } }
}

@Composable
fun AuraPanelHostLayer() {
    val c = AuraPanelHost.content ?: return
    val st = remember { MutableTransitionState(false).apply { targetState = true } }
    LaunchedEffect(st.currentState, st.targetState) {
        if (!st.targetState && st.isIdle) AuraPanelHost.onDismiss()
    }
    androidx.activity.compose.BackHandler { st.targetState = false }
    Box(
        Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { st.targetState = false }
    ) {
        Box(Modifier.fillMaxSize().statusBarsPadding().padding(top = AuraPanelHost.top).clipToBounds()) {
            AnimatedVisibility(
                visibleState = st,
                enter = slideInVertically(tween(320)) { -it },
                exit = slideOutVertically(tween(260)) { -it }
            ) {
                Box(
                    Modifier.fillMaxSize().background(if (AuraUi.light) Color.White else Color.Black)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                ) { c() }
            }
        }
    }
}

private fun rgbToHsv(rgb: Int): FloatArray {
    val a = FloatArray(3)
    android.graphics.Color.colorToHSV(0xFF000000.toInt() or rgb, a)
    return a
}

private fun hsvToRgb(h: Float, s: Float, v: Float): Int =
    android.graphics.Color.HSVToColor(floatArrayOf(h.coerceIn(0f, 359.99f), s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))) and 0xFFFFFF

@Composable
private fun GradBar(frac: Float, colors: List<Color>, onFrac: (Float) -> Unit) {
    var w by remember { mutableStateOf(1f) }
    val thumbCol = Color(0xFFFFFFFF)
    Box(
        Modifier.fillMaxWidth().height(34.dp).onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) { detectTapGestures { onFrac((it.x / w).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) { detectDragGestures { c, _ -> c.consume(); onFrac((c.position.x / w).coerceIn(0f, 1f)) } }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val h = 16.dp.toPx()
            val top = (size.height - h) / 2f
            drawRoundRect(Brush.horizontalGradient(colors), Offset(0f, top), Size(size.width, h), androidx.compose.ui.geometry.CornerRadius(h / 2f))
            val cx = (frac * size.width).coerceIn(0f, size.width)
            drawCircle(Color(0x55000000), 14.dp.toPx(), Offset(cx, size.height / 2f))
            drawCircle(thumbCol, 12.dp.toPx(), Offset(cx, size.height / 2f))
            drawCircle(colors.let { c -> lerpList(c, frac) }, 8.dp.toPx(), Offset(cx, size.height / 2f))
        }
    }
}

private fun lerpList(c: List<Color>, f: Float): Color {
    if (c.size == 1) return c[0]
    val p = f.coerceIn(0f, 1f) * (c.size - 1)
    val i = p.toInt().coerceAtMost(c.size - 2)
    return androidx.compose.ui.graphics.lerp(c[i], c[i + 1], p - i)
}

/** "Vurgu" başlığı + hex kutusu + kayar renk çubukları */
@Composable
fun AccentCustomHeader() {
    val ctx = LocalContext.current
    // doygunluk ve parlaklık, seçili palet rengine bağlı: palet rengi değişince çubuklar o renge göre kurulur
    val baseRgb = if (AuraUi.accent == 20) AuraUi.customRgb else AuraUi.swatch(AuraUi.accent, AuraUi.light).let { (Math.round(it.red * 255) shl 16) or (Math.round(it.green * 255) shl 8) or Math.round(it.blue * 255) }
    var hsv by remember { mutableStateOf(rgbToHsv(baseRgb)) }
    var hex by remember { mutableStateOf("%06X".format(baseRgb)) }
    // yalnızca palet rengi seçilince çubuklar yeniden kurulur; çubuk sürüklenirken (özel renge geçişte) sıfırlanmaz
    androidx.compose.runtime.LaunchedEffect(AuraUi.accent, AuraUi.light) {
        if (AuraUi.accent != 20) { hsv = rgbToHsv(baseRgb); hex = "%06X".format(baseRgb) }
    }
    val cur = Color(0xFF000000L or hsvToRgb(hsv[0], hsv[1], hsv[2]).toLong())
    fun apply(h: Float, s: Float, vv: Float) {
        hsv = floatArrayOf(h, s, vv)
        val rgb = hsvToRgb(h, s, vv)
        hex = "%06X".format(rgb)
        AuraUi.setCustom(ctx, rgb)
    }
    Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Vurgu", color = AuraMuted, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Box(Modifier.size(22.dp).clip(CircleShape).background(cur))
        Spacer(Modifier.width(8.dp))
        Row(
            Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, AuraMuted.copy(alpha = 0.4f), RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("#", color = AuraMuted, fontSize = 15.sp)
            BasicTextField(
                value = hex,
                onValueChange = { raw ->
                    val f = raw.filter { it.isDigit() || it.lowercaseChar() in 'a'..'f' }.take(6).uppercase()
                    hex = f
                    if (f.length == 6) {
                        val rgb = f.toInt(16)
                        hsv = rgbToHsv(rgb)
                        AuraUi.setCustom(ctx, rgb)
                    }
                },
                singleLine = true,
                textStyle = TextStyle(color = AuraWhite, fontSize = 15.sp, fontWeight = FontWeight.Medium),
                cursorBrush = Brush.verticalGradient(listOf(AuraGreen, AuraGreen)),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                modifier = Modifier.width(72.dp)
            )
        }
    }
    Text("Doygunluk", color = AuraMuted, fontSize = 13.sp)
    GradBar(
        hsv[1], listOf(Color(0xFF000000L or hsvToRgb(hsv[0], 0f, hsv[2]).toLong()), Color(0xFF000000L or hsvToRgb(hsv[0], 1f, hsv[2]).toLong()))
    ) { apply(hsv[0], it, hsv[2]) }
    Text("Parlaklık", color = AuraMuted, fontSize = 13.sp)
    GradBar(
        hsv[2], listOf(Color.Black, Color(0xFF000000L or hsvToRgb(hsv[0], hsv[1], 1f).toLong()))
    ) { apply(hsv[0], hsv[1], it) }
    Spacer(Modifier.height(18.dp))
}


/** Uygulama teması açılır paneli (sohbet listesi başlığı, menü ve ayarlar aynı paneli kullanır) */
@Composable
fun AppThemePanel(onDismiss: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
AuraTopPanel(onDismissRequest = onDismiss) {
    Column(
        Modifier.fillMaxWidth().verticalScroll(androidx.compose.foundation.rememberScrollState())
            .navigationBarsPadding().padding(start = 20.dp, end = 20.dp, top = 6.dp, bottom = 24.dp)
    ) {
        Text("Uygulama teması", color = AuraWhite, fontSize = 20.sp, fontWeight = FontWeight.Medium)
        Text("Seçtiğin hemen uygulanır", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp, bottom = 16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(Triple(2, "Sistem", 0), Triple(1, "Aydınlık", 1), Triple(0, "Karanlık", 2)).forEach { (mode, label, kind) ->
                val sel = AuraUi.mode == mode
                Box(
                    Modifier.weight(1f).aspectRatio(0.72f).clip(RoundedCornerShape(16.dp))
                        .border(if (sel) 2.5.dp else 1.dp, if (sel) AuraGreen else AuraMuted.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                        .clickable { AuraUi.setMode(ctx, mode) }
                ) {
                    if (kind != 1) ThemeMock(true)
                    if (kind == 1) ThemeMock(false)
                    if (kind == 0) Box(
                        Modifier.fillMaxSize().clip(androidx.compose.foundation.shape.GenericShape { sz, _ ->
                            moveTo(sz.width * 0.58f, 0f); lineTo(sz.width, 0f); lineTo(sz.width, sz.height); lineTo(sz.width * 0.42f, sz.height); close()
                        })
                    ) { ThemeMock(false) }
                    Text(
                        label, color = if (kind == 1) Color(0xFF111B21) else Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp)
                            .clip(RoundedCornerShape(50)).background(if (kind == 1) Color(0x99FFFFFF) else Color(0x66000000)).padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                    if (sel) Box(
                        Modifier.align(Alignment.TopEnd).padding(8.dp).size(22.dp).clip(CircleShape).background(AuraGreen),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(15.dp)) }
                }
            }
        }
        // iki sekme: Vurgu rengi / Arka plan rengi; parmakla sağa-sola kaydırınca (ya da çipe basınca) geçiş baloncuklu
        var tab by androidx.compose.runtime.mutableIntStateOf(0)
        val pos by androidx.compose.animation.core.animateFloatAsState(tab.toFloat(), androidx.compose.animation.core.spring(0.65f, 380f), label = "tabpos")
        Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Vurgu rengi", "Arka plan rengi").forEachIndexed { i, label ->
                val f = (1f - kotlin.math.abs(pos - i)).coerceIn(0f, 1f)
                Box(
                    Modifier.clip(RoundedCornerShape(50))
                        .background(ChipLook.bg.copy(alpha = ChipLook.bg.alpha * f))
                        .border(1.dp, androidx.compose.ui.graphics.lerp(AuraMuted.copy(alpha = 0.35f), ChipLook.border, f), RoundedCornerShape(50))
                        .clickable { tab = i }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) { Text(label, color = androidx.compose.ui.graphics.lerp(AuraMuted, ChipLook.fg, f), fontSize = 14.sp, fontWeight = FontWeight.Medium) }
            }
        }
        Box(
            Modifier.fillMaxWidth().pointerInput(Unit) {
                var dx = 0f
                detectHorizontalDragGestures(
                    onDragStart = { dx = 0f },
                    onDragEnd = { if (dx < -70f) tab = 1 else if (dx > 70f) tab = 0 },
                    onHorizontalDrag = { _, d -> dx += d }
                )
            }
        ) {
            androidx.compose.animation.AnimatedContent(
                targetState = tab, label = "themetab",
                transitionSpec = {
                    val fwd = targetState > initialState
                    (androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.spring(0.8f, 380f)) { if (fwd) it else -it } + androidx.compose.animation.fadeIn()) togetherWith
                        (androidx.compose.animation.slideOutHorizontally(androidx.compose.animation.core.spring(0.8f, 380f)) { if (fwd) -it else it } + androidx.compose.animation.fadeOut())
                }
            ) { t ->
                Column(Modifier.fillMaxWidth()) {
                    if (t == 0) {
                        AccentCustomHeader()
                        val palLight = AuraUi.light
        (0 until 20).toList().chunked(5).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                row.forEach { c ->
                    val on = AuraUi.accent == c
                    Box(
                        Modifier.size(52.dp).then(if (on) Modifier.border(2.dp, AuraWhite, CircleShape).padding(4.dp) else Modifier)
                            .clip(CircleShape).background(AuraUi.swatch(c, palLight)).clickable { AuraUi.setAccent(ctx, c) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (on) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(26.dp))
                    }
                }
            }
        }
                    } else BgLabBar()
                }
            }
        }
    }
}
}

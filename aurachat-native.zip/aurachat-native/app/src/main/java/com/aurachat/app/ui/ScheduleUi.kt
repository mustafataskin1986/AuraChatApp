package com.aurachat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale

private val trDays = arrayOf("Paz", "Pzt", "Sal", "Çar", "Per", "Cum", "Cmt")
private val trMonths = arrayOf("Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık")

private fun dayStart(offset: Int): Calendar = Calendar.getInstance().apply {
    add(Calendar.DAY_OF_YEAR, offset); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}

private fun dayName(c: Calendar) = "${c.get(Calendar.DAY_OF_MONTH)} ${trMonths[c.get(Calendar.MONTH)]}"

/** "Bugün 13:35" / "Yarın 09:00" / "25 Kasım 17:00" */
fun schedLabel(ms: Long): String {
    val c = Calendar.getInstance().apply { timeInMillis = ms }
    val t = String.format(Locale("tr"), "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
    val today = dayStart(0).timeInMillis
    val d = ((ms - today) / 86_400_000L).toInt()
    return (when { ms >= today && d == 0 -> "Bugün"; d == 1 -> "Yarın"; else -> dayName(c) }) + " " + t
}

@Composable
private fun Wheel(count: Int, initial: Int, infinite: Boolean, label: (Int) -> String, onSel: (Int) -> Unit, modifier: Modifier) {
    val dn = LocalDensity.current
    val itemH = with(dn) { 110f.toDp() }
    val itemPx = with(dn) { 110f }
    val total = if (infinite) count * 400 else count
    val start = if (infinite) count * 200 + initial else initial
    val st = rememberLazyListState(initialFirstVisibleItemIndex = start)
    val sel by remember { derivedStateOf { (st.firstVisibleItemIndex + if (st.firstVisibleItemScrollOffset > itemPx / 2) 1 else 0).coerceIn(0, total - 1) } }
    androidx.compose.runtime.LaunchedEffect(sel) { onSel(if (infinite) sel % count else sel) }
    LazyColumn(
        state = st, flingBehavior = rememberSnapFlingBehavior(st),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = itemH * 2),
        modifier = modifier.height(itemH * 5)
    ) {
        items(total) { i ->
            Box(Modifier.height(itemH).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    label(if (infinite) i % count else i),
                    color = if (i == sel) AuraWhite else AuraMuted.copy(alpha = 0.55f),
                    fontSize = with(dn) { 52f.toSp() }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleSheet(btnColor: Color, onDismiss: () -> Unit, onPick: (Long) -> Unit) {
    val dn = LocalDensity.current
    val ctx = LocalContext.current
    val now = remember { Calendar.getInstance() }
    // varsayılan: bir sonraki tam saat
    val defTime = remember { Calendar.getInstance().apply { add(Calendar.HOUR_OF_DAY, 1); set(Calendar.MINUTE, 0) } }
    val dayOff0 = remember { if (defTime.get(Calendar.DAY_OF_YEAR) != now.get(Calendar.DAY_OF_YEAR)) 1 else 0 }
    var dayI by remember { mutableStateOf(dayOff0) }
    var hourI by remember { mutableStateOf(defTime.get(Calendar.HOUR_OF_DAY)) }
    var minI by remember { mutableStateOf(0) }
    val days = remember { (0 until 60).map { dayStart(it) } }
    val at = remember(dayI, hourI, minI) { (days[dayI.coerceIn(0, 59)].clone() as Calendar).apply { set(Calendar.HOUR_OF_DAY, hourI); set(Calendar.MINUTE, minI) }.timeInMillis }
    val sheetBg = auraLc(0xFF12171B)
    ModalBottomSheet(
        onDismissRequest = onDismiss, containerColor = sheetBg,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = {
            Box(Modifier.padding(top = with(dn) { 24f.toDp() }, bottom = with(dn) { 6f.toDp() }).width(with(dn) { 88f.toDp() }).height(with(dn) { 12f.toDp() }).clip(RoundedCornerShape(50)).background(AuraMuted.copy(alpha = 0.6f)))
        }
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Mesaj planlayın", color = AuraWhite, fontSize = with(dn) { 60f.toSp() }, modifier = Modifier.padding(top = with(dn) { 36f.toDp() }, bottom = with(dn) { 26f.toDp() }))
            Box(Modifier.fillMaxWidth()) {
                Box(Modifier.align(Alignment.Center).fillMaxWidth().padding(horizontal = with(dn) { 22f.toDp() }).height(with(dn) { 110f.toDp() }).clip(RoundedCornerShape(with(dn) { 26f.toDp() })).background(Color.White.copy(alpha = 0.10f)))
                Row(Modifier.fillMaxWidth()) {
                    Wheel(days.size, dayOff0, false, { i -> if (i == 0) "Bugün" else dayName(days[i]) + " " + trDays[days[i].get(Calendar.DAY_OF_WEEK) - 1] }, { dayI = it }, Modifier.weight(1.4f))
                    Wheel(24, defTime.get(Calendar.HOUR_OF_DAY), true, { String.format("%02d", it) }, { hourI = it }, Modifier.weight(1f))
                    Wheel(60, 0, true, { String.format("%02d", it) }, { minI = it }, Modifier.weight(1f))
                }
            }
            val lbl = schedLabel(at).let { s -> if (s.startsWith("Bugün") || s.startsWith("Yarın")) s.replaceFirstChar { it.lowercase() } else s }
            Box(
                Modifier.padding(horizontal = with(dn) { 62f.toDp() }, vertical = with(dn) { 36f.toDp() }).fillMaxWidth().height(with(dn) { 110f.toDp() })
                    .clip(RoundedCornerShape(50)).background(btnColor)
                    .clickable {
                        if (at <= System.currentTimeMillis() + 5_000L) android.widget.Toast.makeText(ctx, "Geçmiş bir zaman seçilemez", android.widget.Toast.LENGTH_SHORT).show()
                        else onPick(at)
                    },
                contentAlignment = Alignment.Center
            ) {
                Text("$lbl saatinde gönderin", color = if (btnColor.luminance() < 0.5f) Color.White else Color(0xFF111B21), fontSize = with(dn) { 46f.toSp() }, fontWeight = FontWeight.Normal)
            }
        }
    }
}

/** Sohbette "Bir mesaj planladınız. Görüntüle" baloncuğu */
@Composable
fun SchedChip(count: Int, onOpen: () -> Unit) {
    val dn = LocalDensity.current
    Box(Modifier.fillMaxWidth().padding(vertical = with(dn) { 12f.toDp() }), contentAlignment = Alignment.Center) {
        Row(
            Modifier.clip(RoundedCornerShape(with(dn) { 16f.toDp() })).background(if (AuraUi.lightReal) Color(0xFFFDFCFB) else AuraSurface.copy(alpha = 0.78f))
                .clickable { onOpen() }.padding(horizontal = with(dn) { 28f.toDp() }, vertical = with(dn) { 20f.toDp() }),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Schedule, null, tint = AuraMuted, modifier = Modifier.height(with(dn) { 40f.toDp() }).width(with(dn) { 40f.toDp() }))
            Spacer(Modifier.width(with(dn) { 16f.toDp() }))
            Text(
                (if (count > 1) "$count mesaj planladınız. " else "Bir mesaj planladınız. ") + "Görüntüle",
                color = AuraMuted, fontSize = with(dn) { 38f.toSp() }, maxLines = 1
            )
        }
    }
}

/** Planlanmış mesajlar sayfası (tam ekran) */
@Composable
fun ScheduledPage(chatId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val dn = LocalDensity.current
    val scope = rememberCoroutineScope()
    androidx.activity.compose.BackHandler { onBack() }
    val list = ScheduledMsgs.items.filter { it.chatId == chatId }
    var pick by remember { mutableStateOf<ScheduledMsgs.Item?>(null) }
    androidx.compose.runtime.LaunchedEffect(list.isEmpty()) { if (list.isEmpty()) onBack() }
    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text("Planlanmış mesajlar", color = AuraWhite, fontSize = with(dn) { 60f.toSp() }, modifier = Modifier.padding(start = 6.dp))
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { m ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        schedLabel(m.at) + " için planlandı", color = AuraMuted, fontSize = with(dn) { 38f.toSp() },
                        modifier = Modifier.clip(RoundedCornerShape(with(dn) { 16f.toDp() })).background(AuraSurface.copy(alpha = 0.78f)).padding(horizontal = with(dn) { 26f.toDp() }, vertical = with(dn) { 14f.toDp() })
                    )
                    Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.CenterEnd) {
                        Text(
                            m.text, color = Color.White, fontSize = with(dn) { 52f.toSp() },
                            modifier = Modifier.clip(RoundedCornerShape(with(dn) { 30f.toDp() })).background(AuraMine).clickable { pick = m }
                                .padding(horizontal = with(dn) { 28f.toDp() }, vertical = with(dn) { 20f.toDp() })
                        )
                    }
                }
            }
        }
    }
    pick?.let { m ->
        AuraAlertDialog(
            onDismissRequest = { pick = null },
            title = { Text("Planlanmış mesaj", color = AuraWhite, fontWeight = FontWeight.Bold) },
            text = { Text(m.text, color = AuraMuted, maxLines = 6) },
            confirmButton = {
                TextButton(onClick = { pick = null; scope.launch { ScheduledMsgs.sendDue(ctx.applicationContext, m.id) } }) { Text("Şimdi gönder", color = AuraGreen, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { pick = null }) { Text("Vazgeç", color = AuraWhite) }
                    TextButton(onClick = { pick = null; ScheduledMsgs.remove(ctx.applicationContext, m.id) }) { Text("Sil", color = Color(0xFFF15C6D)) }
                }
            }
        )
    }
}

package com.aurachat.app.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.launch

private const val QR_PREFIX = "aurachat://u/"

private fun makeQr(text: String): Bitmap? = try {
    val hints = mapOf(EncodeHintType.MARGIN to 0, EncodeHintType.CHARACTER_SET to "UTF-8")
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, hints)
    val scale = 10
    val bmp = Bitmap.createBitmap(m.width * scale, m.height * scale, Bitmap.Config.ARGB_8888)
    val px = IntArray(bmp.width * bmp.height)
    for (y in 0 until bmp.height) for (x in 0 until bmp.width) {
        px[y * bmp.width + x] = if (m.get(x / scale, y / scale)) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
    }
    bmp.setPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
    bmp
} catch (e: Throwable) { null }

/** QR kodum / Kodu tara: sayfadayken ekran parlaklığı tam olur, çıkınca eski hâline döner */
@Composable
fun QrScreen(me: UserProfile, onBack: () -> Unit, onOpenChat: (ChatTarget) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    BackHandler { onBack() }

    // ekran ışığı: telefonda kısık olsa bile bu sayfalarda tam
    DisposableEffect(Unit) {
        var c: android.content.Context? = ctx
        while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext
        val w = (c as? android.app.Activity)?.window
        if (w != null) w.attributes = w.attributes.also { it.screenBrightness = 1f }
        onDispose {
            if (w != null) w.attributes = w.attributes.also { it.screenBrightness = android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE }
        }
    }

    fun handle(raw: String) {
        val uid = Regex("(?:aurachat://u/|[?&]u=)([A-Za-z0-9]{10,64})").find(raw)?.groupValues?.get(1)
        if (uid == null) { Toast.makeText(ctx, "Bu bir AuraChat QR kodu değil", Toast.LENGTH_SHORT).show(); return }
        if (uid == me.uid) { Toast.makeText(ctx, "Bu senin kodun", Toast.LENGTH_SHORT).show(); return }
        scope.launch {
            val p = try { Repo.loadProfile(uid) } catch (e: Throwable) { null }
            if (p == null) { Toast.makeText(ctx, "Kişi bulunamadı", Toast.LENGTH_SHORT).show(); return@launch }
            onOpenChat(ChatTarget(Repo.chatId(me.uid, uid), false, uid, p.name))
        }
    }

    val scanLauncher = androidx.activity.compose.rememberLauncherForActivityResult(ScanContract()) { r ->
        r.contents?.let { handle(it) }
    }
    fun startScan() {
        try {
            val o = ScanOptions()
                .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                .setPrompt("")
                .setBeepEnabled(false)
                .setOrientationLocked(true)
            scanLauncher.launch(o)
        } catch (e: Throwable) { Toast.makeText(ctx, "Tarayıcı açılamadı", Toast.LENGTH_SHORT).show() }
    }
    LaunchedEffect(tab) { if (tab == 1) startScan() }

    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text("Profil paylaşımı", color = AuraWhite, fontSize = 21.sp, modifier = Modifier.padding(start = 8.dp))
        }
        androidx.compose.material3.HorizontalDivider(color = AuraMuted.copy(alpha = 0.18f))
        // iki parçalı seçici: Profili paylaş | Kodu tara
        val segBorder = AuraMuted.copy(alpha = 0.45f)
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 16.dp).fillMaxWidth().height(44.dp)
                .clip(RoundedCornerShape(50)).border(1.5.dp, segBorder, RoundedCornerShape(50))
        ) {
            listOf("Profili paylaş", "Kodu tara").forEachIndexed { i, l ->
                Box(
                    Modifier.weight(1f).fillMaxSize().background(if (tab == i) ChipLook.bg.compositeOver(AuraBg) else Color.Transparent).clickable { tab = i },
                    contentAlignment = Alignment.Center
                ) { Text(l, color = if (tab == i) ChipLook.fg else AuraWhite, fontSize = 16.sp, fontWeight = FontWeight.Medium) }
            }
        }
        if (tab == 0) {
            val bmp = remember(me.uid) { makeQr(QR_PREFIX + me.uid) }
            val link = "aurachat-amber.vercel.app/api/u?u=" + me.uid
            val shareText = "AuraChat'te benimle sohbet et: https://" + link
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(30.dp))
                Box(Modifier.padding(horizontal = 28.dp).fillMaxWidth()) {
                    Column(
                        Modifier.padding(top = 24.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(AuraSurface).padding(top = 34.dp, bottom = 22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(me.name, color = AuraWhite, fontSize = 21.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp, bottom = 16.dp))
                        Box(Modifier.size(180.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFFFFFFF)).padding(12.dp)) {
                            if (bmp != null) Image(bmp.asImageBitmap(), "QR kodum", Modifier.fillMaxSize(), colorFilter = auraImageFilter())
                        }
                        Text(
                            link, color = AuraGreen, fontSize = 14.sp, textAlign = TextAlign.Center, maxLines = 2,
                            modifier = Modifier.padding(top = 18.dp, start = 16.dp, end = 16.dp)
                        )
                    }
                    Box(Modifier.align(Alignment.TopCenter).size(52.dp).clip(CircleShape).background(AuraBg).padding(3.dp)) { Avatar(me.name, me.avatar, 46.dp) }
                }
                Text(
                    "QR kodunuzu paylaşmanız kullanıcıların sizi kişilerine eklemesini sağlar. Bağlantınızı paylaşmanız ise kullanıcıların sizinle sohbet başlatmasını sağlar.",
                    color = AuraMuted, fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 28.dp, vertical = 22.dp)
                )
                androidx.compose.material3.HorizontalDivider(color = AuraMuted.copy(alpha = 0.18f))
                Text("Şu yolla bağlantı gönderin:", color = AuraMuted, fontSize = 17.sp, modifier = Modifier.align(Alignment.Start).padding(start = 18.dp, top = 18.dp, bottom = 14.dp))
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceEvenly) {
                    val acts = listOf<Triple<androidx.compose.ui.graphics.vector.ImageVector, String, () -> Unit>>(
                        Triple(Icons.Default.Share, "Paylaş", {
                            try {
                                ctx.startActivity(android.content.Intent.createChooser(
                                    android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain").putExtra(android.content.Intent.EXTRA_TEXT, shareText), null
                                ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Throwable) { Toast.makeText(ctx, "Paylaşılamadı", Toast.LENGTH_SHORT).show() }
                        }),
                        Triple(Icons.Default.Sms, "SMS", {
                            try {
                                ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:")).putExtra("sms_body", shareText).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Throwable) { Toast.makeText(ctx, "SMS uygulaması bulunamadı", Toast.LENGTH_SHORT).show() }
                        }),
                        Triple(Icons.Default.ContentCopy, "Kopyala", {
                            val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            cm.setPrimaryClip(android.content.ClipData.newPlainText("AuraChat", "https://" + link))
                            Toast.makeText(ctx, "Bağlantı kopyalandı", Toast.LENGTH_SHORT).show()
                        }),
                        Triple(Icons.Default.Email, "E-posta", {
                            try {
                                ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("mailto:"))
                                    .putExtra(android.content.Intent.EXTRA_SUBJECT, "AuraChat").putExtra(android.content.Intent.EXTRA_TEXT, shareText).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Throwable) { Toast.makeText(ctx, "E-posta uygulaması bulunamadı", Toast.LENGTH_SHORT).show() }
                        })
                    )
                    acts.forEach { (ic, label, act) ->
                        Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable { act() }.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(58.dp).clip(CircleShape).background(AuraSurface), contentAlignment = Alignment.Center) {
                                Icon(ic, label, tint = AuraWhite, modifier = Modifier.size(26.dp))
                            }
                            Text(label, color = AuraWhite, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        } else {
            Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
                Icon(Icons.Default.QrCodeScanner, null, tint = AuraMuted, modifier = Modifier.size(72.dp))
                Text("Bir kişinin AuraChat QR kodunu tara", color = AuraWhite, fontSize = 16.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 16.dp))
                Box(
                    Modifier.padding(top = 20.dp).clip(RoundedCornerShape(50)).background(AuraGreen).clickable { startScan() }.padding(horizontal = 28.dp, vertical = 12.dp)
                ) { Text("Taramayı başlat", color = AuraBlack, fontSize = 16.sp, fontWeight = FontWeight.Medium) }
            }
        }
    }
}

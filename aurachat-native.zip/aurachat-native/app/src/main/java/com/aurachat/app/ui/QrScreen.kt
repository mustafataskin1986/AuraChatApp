package com.aurachat.app.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.offset
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.launch

private const val QR_PREFIX = "aurachat://u/"

private fun makeQr(text: String): Bitmap? = try {
    val hints = mapOf(EncodeHintType.MARGIN to 0, EncodeHintType.CHARACTER_SET to "UTF-8")
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, hints)
    val scale = 10
    val bmp = Bitmap.createBitmap(m.width * scale, m.height * scale, Bitmap.Config.ARGB_8888)
    val px = IntArray(bmp.width * bmp.height)
    for (y in 0 until bmp.height) for (x in 0 until bmp.width) {
        px[y * bmp.width + x] = if (m.get(x / scale, y / scale)) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
    }
    bmp.setPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
    bmp
} catch (e: Throwable) { null }


/** Galeriden seçilen resimdeki QR kodu çözer; bulunamazsa null */
private fun decodeQrFromUri(ctx: android.content.Context, uri: android.net.Uri): String? = try {
    val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, opts) }
    var sample = 1
    while (opts.outWidth / sample > 2200 || opts.outHeight / sample > 2200) sample *= 2
    val bmp = ctx.contentResolver.openInputStream(uri)?.use {
        android.graphics.BitmapFactory.decodeStream(it, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
    }
    if (bmp == null) null else {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
        val hints = mapOf(
            com.google.zxing.DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
            com.google.zxing.DecodeHintType.TRY_HARDER to true
        )
        val src = com.google.zxing.RGBLuminanceSource(w, h, px)
        val reader = com.google.zxing.MultiFormatReader()
        try { reader.decode(com.google.zxing.BinaryBitmap(com.google.zxing.common.HybridBinarizer(src)), hints).text }
        catch (e: Throwable) {
            try { reader.decode(com.google.zxing.BinaryBitmap(com.google.zxing.common.HybridBinarizer(src.invert())), hints).text } catch (e2: Throwable) { null }
        }
    }
} catch (e: Throwable) { null }

/** QR kodum / Kodu tara: sayfadayken ekran parlaklığı tam olur, çıkınca eski hâline döner */
@Composable
fun QrScreen(me: UserProfile, onBack: () -> Unit, onOpenChat: (ChatTarget) -> Unit, startTab: Int = 0) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(startTab) }
    var qrKey by remember { mutableStateOf<String?>(null) }
    var topMenu by remember { mutableStateOf(false) }
    LaunchedEffect(me.uid) { qrKey = Repo.qrKeyOf(me.uid) }
    BackHandler { onBack() }

    // ekran ışığı: telefonda kısık olsa bile bu sayfalarda tam
    DisposableEffect(Unit) {
        var c: android.content.Context? = ctx
        while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext
        val w = (c as? android.app.Activity)?.window
        if (w != null) w.attributes = w.attributes.also { it.screenBrightness = 1f }
        onDispose {
            if (w != null) w.attributes = w.attributes.also { it.screenBrightness = android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE }
        }
    }

    // --- Kodu tara: sayfa içinde kamera ---
    var hasCam by remember { mutableStateOf(androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) }
    val camLauncher = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { hasCam = it }
    LaunchedEffect(tab) { if (tab == 1 && !hasCam) camLauncher.launch(android.Manifest.permission.CAMERA) }
    var busy by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<UserProfile?>(null) }
    var showHint by remember { mutableStateOf(false) }
    var torch by remember { mutableStateOf(false) }
    var scanView by remember { mutableStateOf<com.journeyapps.barcodescanner.DecoratedBarcodeView?>(null) }

    fun handle(raw: String) {
        val uid = Regex("(?:aurachat://u/|[?&]u=)([A-Za-z0-9]{10,64})").find(raw)?.groupValues?.get(1)
        if (uid == null) {
            Toast.makeText(ctx, "Bu bir AuraChat QR kodu değil", Toast.LENGTH_SHORT).show()
            scope.launch { kotlinx.coroutines.delay(1500); busy = false }
            return
        }
        scope.launch {
            if (uid != me.uid) {
                val tk = Repo.qrKeyOf(uid)
                val sk = Regex("[?&]k=([A-Za-z0-9]{6,32})").find(raw)?.groupValues?.get(1) ?: ""
                if (tk.isNotEmpty() && tk != sk) {
                    Toast.makeText(ctx, "Bu QR kodu geçersiz ya da sıfırlanmış", Toast.LENGTH_SHORT).show()
                    kotlinx.coroutines.delay(1500); busy = false
                    return@launch
                }
            }
            val p = if (uid == me.uid) me else try { Repo.loadProfile(uid) } catch (e: Throwable) { null }
            if (p == null) {
                Toast.makeText(ctx, "Kişi bulunamadı", Toast.LENGTH_SHORT).show()
                kotlinx.coroutines.delay(1500); busy = false
                return@launch
            }
            found = p
        }
    }

    // 10 sn içinde kod okunmazsa yardım penceresi
    LaunchedEffect(tab, hasCam) {
        if (tab == 1 && hasCam) {
            kotlinx.coroutines.delay(10_000)
            if (found == null) showHint = true
        }
    }

    // galeriden QR resmi seç
    val pickImage = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val text = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { decodeQrFromUri(ctx, uri) }
            if (text == null) Toast.makeText(ctx, "Resimde QR kod bulunamadı", Toast.LENGTH_SHORT).show()
            else { busy = true; handle(text) }
        }
    }

    // kamera yaşam döngüsü
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    DisposableEffect(scanView, lifecycleOwner) {
        val v = scanView
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) v?.resume()
            if (e == androidx.lifecycle.Lifecycle.Event.ON_PAUSE) v?.pause()
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)) v?.resume()
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs); v?.pause() }
    }

    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text("Profil paylaşımı", color = AuraWhite, fontSize = 21.sp, letterSpacing = 0.sp, modifier = Modifier.padding(start = 8.dp).weight(1f))
            if (tab == 0) Box {
                IconButton(onClick = { topMenu = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = AuraWhite) }
                AuraDropdownMenu(expanded = topMenu, onDismissRequest = { topMenu = false }, shape = RoundedCornerShape(16.dp), containerColor = AuraSurface) {
                    androidx.compose.material3.DropdownMenuItem(text = { Text("QR kodunu sıfırla", color = AuraWhite, fontSize = 16.sp) }, onClick = {
                        topMenu = false
                        scope.launch {
                            val k = try { Repo.resetQrKey(me.uid) } catch (e: Throwable) { null }
                            if (k == null) Toast.makeText(ctx, "QR sıfırlanamadı", Toast.LENGTH_SHORT).show()
                            else { qrKey = k; Toast.makeText(ctx, "QR kodu sıfırlandı", Toast.LENGTH_SHORT).show() }
                        }
                    })
                }
            }
        }
        androidx.compose.material3.HorizontalDivider(color = AuraMuted.copy(alpha = 0.18f))
        // iki parçalı seçici: Profili paylaş | Kodu tara
        val segBorder = AuraMuted.copy(alpha = 0.45f)
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 16.dp).fillMaxWidth().height(44.dp)
                .clip(RoundedCornerShape(50)).border(1.5.dp, segBorder, RoundedCornerShape(50))
        ) {
            listOf("Profili paylaş", "Kodu tara").forEachIndexed { i, l ->
                Box(
                    Modifier.weight(1f).fillMaxSize().background(if (tab == i) ChipLook.bg.compositeOver(AuraBg) else Color.Transparent).clickable { tab = i },
                    contentAlignment = Alignment.Center
                ) { Text(l, color = if (tab == i) ChipLook.fg else AuraWhite, fontSize = 16.sp, letterSpacing = 0.sp, fontWeight = FontWeight.Medium) }
            }
        }
        if (tab == 0) {
            val kq = qrKey ?: ""
            val bmp = remember(me.uid, qrKey) { makeQr(QR_PREFIX + me.uid + (if (kq.isNotEmpty()) "?k=" + kq else "")) }
            val link = "aurachat-amber.vercel.app/api/u?u=" + me.uid + (if (kq.isNotEmpty()) "&k=" + kq else "")
            val shareText = "AuraChat'te benimle sohbet et: https://" + link
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(39.dp))
                Box(Modifier.padding(horizontal = 50.dp).fillMaxWidth()) {
                    Column(
                        Modifier.padding(top = 24.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(AuraSurface).padding(top = 34.dp, bottom = 22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(me.name, color = AuraWhite, fontSize = 17.5.sp, letterSpacing = 0.sp, modifier = Modifier.padding(top = 8.dp, bottom = 16.dp))
                        Box(Modifier.size(174.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFFFFFFF)).padding(12.dp)) {
                            if (bmp != null) Image(bmp.asImageBitmap(), "QR kodum", Modifier.fillMaxSize(), colorFilter = auraImageFilter())
                        }
                        Text(
                            link, color = AuraGreen, fontSize = 16.sp, letterSpacing = 0.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, maxLines = 2,
                            modifier = Modifier.padding(top = 18.dp, start = 16.dp, end = 16.dp)
                        )
                    }
                    Box(Modifier.align(Alignment.TopCenter).size(52.dp).clip(CircleShape).background(AuraBg).padding(3.dp)) { Avatar(me.name, me.avatar, 46.dp) }
                }
                Text(
                    "QR kodunuzu paylaşmanız kullanıcıların sizi kişilerine eklemesini sağlar. Bağlantınızı paylaşmanız ise kullanıcıların sizinle sohbet başlatmasını sağlar.",
                    color = AuraMuted, fontSize = 12.sp, lineHeight = 18.sp, letterSpacing = 0.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(start = 42.dp, end = 42.dp, top = 16.dp, bottom = 22.dp)
                )
                androidx.compose.material3.HorizontalDivider(color = AuraMuted.copy(alpha = 0.18f))
                Text("Şu yolla bağlantı gönderin:", color = AuraMuted, fontSize = 15.sp, letterSpacing = 0.sp, modifier = Modifier.align(Alignment.Start).padding(start = 18.dp, top = 18.dp, bottom = 14.dp))
                Row(Modifier.fillMaxWidth().padding(start = 8.dp)) {
                    val acts = listOf<Triple<androidx.compose.ui.graphics.vector.ImageVector, String, () -> Unit>>(
                        Triple(Icons.Default.Share, "Paylaş", {
                            try {
                                ctx.startActivity(android.content.Intent.createChooser(
                                    android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain").putExtra(android.content.Intent.EXTRA_TEXT, shareText), null
                                ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Throwable) { Toast.makeText(ctx, "Paylaşılamadı", Toast.LENGTH_SHORT).show() }
                        }),
                        Triple(Icons.Default.Sms, "SMS", {
                            try {
                                ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:")).putExtra("sms_body", shareText).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Throwable) { Toast.makeText(ctx, "SMS uygulaması bulunamadı", Toast.LENGTH_SHORT).show() }
                        }),
                        Triple(Icons.Default.ContentCopy, "Kopyala", {
                            val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            cm.setPrimaryClip(android.content.ClipData.newPlainText("AuraChat", "https://" + link))
                            Toast.makeText(ctx, "Bağlantı kopyalandı", Toast.LENGTH_SHORT).show()
                        }),
                        Triple(Icons.Default.Email, "E-posta", {
                            try {
                                ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("mailto:"))
                                    .putExtra(android.content.Intent.EXTRA_SUBJECT, "AuraChat").putExtra(android.content.Intent.EXTRA_TEXT, shareText).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Throwable) { Toast.makeText(ctx, "E-posta uygulaması bulunamadı", Toast.LENGTH_SHORT).show() }
                        })
                    )
                    acts.forEach { (ic, label, act) ->
                        Column(Modifier.width(76.dp).clip(RoundedCornerShape(12.dp)).clickable { act() }.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(48.dp).clip(CircleShape).background(AuraSurface), contentAlignment = Alignment.Center) {
                                Icon(ic, label, tint = AuraWhite, modifier = Modifier.size(24.dp))
                            }
                            Text(label, color = AuraWhite, fontSize = 13.5.sp, letterSpacing = 0.sp, modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        } else {
            androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
                val frame = 294.dp
                val frameTop = maxHeight * 0.30f
                if (hasCam) {
                    androidx.compose.ui.viewinterop.AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { c ->
                            com.journeyapps.barcodescanner.DecoratedBarcodeView(c).apply {
                                viewFinder.visibility = android.view.View.GONE
                                statusView.visibility = android.view.View.GONE
                                barcodeView.decoderFactory = com.journeyapps.barcodescanner.DefaultDecoderFactory(listOf(com.google.zxing.BarcodeFormat.QR_CODE))
                                decodeContinuous(object : com.journeyapps.barcodescanner.BarcodeCallback {
                                    override fun barcodeResult(result: com.journeyapps.barcodescanner.BarcodeResult?) {
                                        val t = result?.text ?: return
                                        if (busy) return
                                        busy = true
                                        handle(t)
                                    }
                                    override fun possibleResultPoints(resultPoints: List<com.google.zxing.ResultPoint>) {}
                                })
                                scanView = this
                            }
                        },
                        onRelease = { it.pause(); if (scanView === it) scanView = null }
                    )
                    // karartma + yuvarlak köşeli tarama çerçevesi
                    androidx.compose.foundation.Canvas(
                        Modifier.fillMaxSize().graphicsLayer(compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.Offscreen)
                    ) {
                        val fw = frame.toPx(); val left = (size.width - fw) / 2f; val top = frameTop.toPx(); val r = 22.dp.toPx()
                        drawRect(Color.Black.copy(alpha = 0.55f))
                        drawRoundRect(Color.Transparent, androidx.compose.ui.geometry.Offset(left, top), androidx.compose.ui.geometry.Size(fw, fw),
                            androidx.compose.ui.geometry.CornerRadius(r), blendMode = androidx.compose.ui.graphics.BlendMode.Clear)
                        drawRoundRect(Color.White.copy(alpha = 0.9f), androidx.compose.ui.geometry.Offset(left, top), androidx.compose.ui.geometry.Size(fw, fw),
                            androidx.compose.ui.geometry.CornerRadius(r), style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
                    }
                    Text(
                        "Bir AuraChat QR kodu tarayın", color = Color.White.copy(alpha = 0.75f), fontSize = 15.sp, letterSpacing = 0.sp,
                        modifier = Modifier.align(Alignment.TopCenter).padding(top = frameTop + frame + 18.dp)
                    )
                } else {
                    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
                        Icon(Icons.Default.QrCodeScanner, null, tint = AuraMuted, modifier = Modifier.size(72.dp))
                        Text("QR kodu taramak için kamera izni gerekli", color = Color.White, fontSize = 16.sp, letterSpacing = 0.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 16.dp))
                        Box(
                            Modifier.padding(top = 20.dp).clip(RoundedCornerShape(50)).background(AuraGreen).clickable { camLauncher.launch(android.Manifest.permission.CAMERA) }.padding(horizontal = 28.dp, vertical = 12.dp)
                        ) { Text("İzin ver", color = AuraBlack, fontSize = 16.sp, letterSpacing = 0.sp, fontWeight = FontWeight.Medium) }
                    }
                }
                // sol alt: galeriden QR resmi, sağ alt: flaş
                Box(
                    Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(start = 14.dp, bottom = 22.dp).size(48.dp).clip(CircleShape)
                        .clickable { pickImage.launch(androidx.activity.result.PickVisualMediaRequest(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.PhotoLibrary, "Galeri", tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(28.dp)) }
                if (hasCam && ctx.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_CAMERA_FLASH)) {
                    Box(
                        Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 14.dp, bottom = 22.dp).size(48.dp).clip(CircleShape)
                            .clickable { torch = !torch; if (torch) scanView?.setTorchOn() else scanView?.setTorchOff() },
                        contentAlignment = Alignment.Center
                    ) { Icon(if (torch) Icons.Default.FlashOn else Icons.Default.FlashOff, "Flaş", tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(28.dp)) }
                }
            }
        }
    }

    // 10 sn bekleme: nasıl taranır penceresi
    if (showHint) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showHint = false }) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).background(AuraSurface).padding(horizontal = 20.dp, vertical = 22.dp)) {
                Text("AuraChat QR kodunu tara", color = AuraWhite, fontSize = 17.sp, letterSpacing = 0.sp)
                Box(Modifier.fillMaxWidth().height(190.dp).padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.align(Alignment.Center).offset(x = (-30).dp, y = 8.dp).size(width = 80.dp, height = 92.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF2B2E31)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.QrCode2, null, tint = Color.White.copy(alpha = 0.45f), modifier = Modifier.size(38.dp).offset(x = (-10).dp))
                    }
                    Box(Modifier.align(Alignment.Center).offset(x = 22.dp).size(width = 80.dp, height = 153.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF363636)), contentAlignment = Alignment.TopCenter) {
                        Icon(Icons.Default.QrCode2, null, tint = Color.White, modifier = Modifier.padding(top = 55.dp).size(38.dp))
                    }
                }
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(40.dp).clip(RoundedCornerShape(50)).background(AuraGreen).clickable { showHint = false },
                    contentAlignment = Alignment.Center
                ) { Text("Tamam", color = AuraBlack, fontSize = 17.sp, letterSpacing = 0.sp) }
            }
        }
    }

    // kod okununca: hesap bulundu
    found?.let { p ->
        val self = p.uid == me.uid
        val close = { found = null; busy = false }
        AuraBottomSheet(
            onDismissRequest = close, containerColor = AuraSurface,
            sheetState = androidx.compose.material3.rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 20.dp)) {
                Text("AuraChat hesabı bulundu", color = AuraWhite, fontSize = 18.sp, letterSpacing = 0.sp, modifier = Modifier.padding(top = 8.dp, bottom = 18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(p.name, p.avatar, 54.dp)
                    Column(Modifier.padding(start = 20.dp)) {
                        Text(p.name, color = AuraWhite, fontSize = 20.sp, letterSpacing = 0.sp)
                        if (self) Text("Siz", color = AuraMuted, fontSize = 16.sp, letterSpacing = 0.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
                Box(
                    Modifier.padding(top = 22.dp).fillMaxWidth().height(40.dp).clip(RoundedCornerShape(50)).background(AuraGreen)
                        .clickable { if (self) close() else { found = null; onOpenChat(ChatTarget(Repo.chatId(me.uid, p.uid), false, p.uid, p.name)) } },
                    contentAlignment = Alignment.Center
                ) { Text(if (self) "Tamam" else "Mesaj gönder", color = AuraBlack, fontSize = 17.sp, letterSpacing = 0.sp) }
            }
        }
    }
}

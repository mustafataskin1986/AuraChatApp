package com.aurachat.app.ui

import android.content.Context
import android.media.MediaPlayer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.aurachat.app.data.Media

/** Tek oynatıcı: aynı anda yalnızca bir sesli mesaj çalar. Durum Compose'a yansır. */
object AudioPlayer {
    var currentId by mutableStateOf<String?>(null)
    var playing by mutableStateOf(false)
    var positionMs by mutableIntStateOf(0)
    var durationMs by mutableIntStateOf(0)
    private var mp: MediaPlayer? = null

    fun toggle(ctx: Context, id: String, dataUrl: String) {
        val cur = mp
        if (cur != null && currentId == id) {
            if (playing) {
                cur.pause()
                playing = false
            } else {
                cur.start()
                playing = true
            }
            return
        }
        stop()
        try {
            val f = Media.writeCacheFile(ctx, dataUrl, "aud_$id")
            val p = MediaPlayer()
            p.setDataSource(f.absolutePath)
            p.prepare()
            durationMs = p.duration
            p.setOnCompletionListener {
                playing = false
                positionMs = 0
                currentId = null
                try { it.release() } catch (ignored: Throwable) {}
                if (mp === it) mp = null
            }
            p.start()
            mp = p
            currentId = id
            positionMs = 0
            playing = true
        } catch (e: Throwable) {
            stop()
        }
    }

    fun tick() {
        val p = mp ?: return
        if (playing) {
            try { positionMs = p.currentPosition } catch (ignored: Throwable) {}
        }
    }

    fun stop() {
        val p = mp
        mp = null
        if (p != null) {
            try { p.stop() } catch (ignored: Throwable) {}
            try { p.release() } catch (ignored: Throwable) {}
        }
        playing = false
        positionMs = 0
        currentId = null
    }
}

package com.aurachat.app.ui

import android.content.Context
import android.media.MediaPlayer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.aurachat.app.data.Media

/** Tek oynatıcı: aynı anda yalnızca bir sesli mesaj çalar. Durum Compose'a yansır. */
object AudioPlayer {
    var currentId by mutableStateOf<String?>(null)
    var playing by mutableStateOf(false)
    var positionMs by mutableIntStateOf(0)
    var durationMs by mutableIntStateOf(0)
    private var mp: MediaPlayer? = null
    /** 1x / 1.5x / 2x; sonraki seslerde de korunur */
    var speed by androidx.compose.runtime.mutableFloatStateOf(1f)

    private fun applySpeed(p: MediaPlayer) {
        try { if (speed != 1f) p.playbackParams = p.playbackParams.setSpeed(speed) else p.playbackParams = p.playbackParams.setSpeed(1f) } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("Audio", ignored) }
    }

    fun cycleSpeed() {
        speed = when (speed) { 1f -> 1.5f; 1.5f -> 2f; else -> 1f }
        val p = mp
        if (p != null && playing) applySpeed(p)
    }

    fun toggle(ctx: Context, id: String, dataUrl: String) {
        val cur = mp
        if (cur != null && currentId == id) {
            if (playing) {
                cur.pause()
                playing = false
            } else {
                cur.start()
                applySpeed(cur)
                playing = true
            }
            return
        }
        stop()
        try {
            val f = Media.writeCacheFile(ctx, dataUrl, "aud_$id")
            val p = MediaPlayer()
            p.setDataSource(f.absolutePath)
            p.prepare()
            durationMs = p.duration
            p.setOnCompletionListener {
                playing = false
                positionMs = 0
                currentId = null
                try { it.release() } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("Audio", ignored) }
                if (mp === it) mp = null
            }
            p.start()
            applySpeed(p)
            mp = p
            currentId = id
            positionMs = 0
            playing = true
        } catch (e: Throwable) {
            stop()
        }
    }

    fun seekTo(frac: Float) {
        val p = mp ?: return
        try {
            val t = (p.duration * frac.coerceIn(0f, 1f)).toInt()
            p.seekTo(t)
            positionMs = t
        } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("Audio", ignored) }
    }

    fun tick() {
        val p = mp ?: return
        if (playing) {
            try { positionMs = p.currentPosition } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("Audio", ignored) }
        }
    }

    fun stop() {
        val p = mp
        mp = null
        if (p != null) {
            try { p.stop() } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("Audio", ignored) }
            try { p.release() } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("Audio", ignored) }
        }
        playing = false
        positionMs = 0
        currentId = null
    }
}

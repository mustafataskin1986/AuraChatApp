package com.aurachat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.runtime.remember
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy

/** "Bir kez görüntülenebilir" fotoğraf: ekran görüntüsü engelli tam ekran; kapanınca fotoğraf tüketilir. */
@Composable
fun ViewOnceViewer(image: String, onReply: ((String) -> Unit)? = null, onClose: () -> Unit) {
    var reply by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false,
            securePolicy = SecureFlagPolicy.SecureOn
        )
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black).clickable { onClose() }) {
            DataUrlImage(image, 2048, Modifier.fillMaxSize(), ContentScale.Fit)
            Row(Modifier.statusBarsPadding().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Kapat", tint = Color.White) }
                Text("Bir kez görüntülenebilir", color = Color.White, fontSize = 15.sp)
            }
            if (onReply != null) {
                Row(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().imePadding()
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .clip(RoundedCornerShape(26.dp)).background(Color(0xFF1F2C34)).padding(start = 18.dp, end = 6.dp)
                        .clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = reply, onValueChange = { reply = it },
                        textStyle = TextStyle(color = Color.White, fontSize = 16.sp), cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.weight(1f).padding(vertical = 14.dp),
                        decorationBox = { inner -> if (reply.isEmpty()) Text("Cevapla…", color = Color(0xFF9CA3AF), fontSize = 16.sp); inner() }
                    )
                    if (reply.isNotBlank()) IconButton(onClick = { val t = reply.trim(); reply = ""; onReply(t); onClose() }) {
                        Icon(Icons.AutoMirrored.Filled.Send, "Gönder", tint = Color(0xFF25D366))
                    }
                }
            }
        }
    }
}

package com.aurachat.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.GroupData

/** Karttan / menüden grup bilgisi sayfası açılırken orada hemen yapılacak iş (rename, add, photo, perms) */
/** Birebir sohbetten "Yeni grup" açılırken sohbetteki kişi hazır seçili gelsin */
object NewGroupSeed {
    @Volatile var uid: String? = null
    fun take(): String? { val p = uid; uid = null; return p }
}

object GroupAction {
    @Volatile var pending: String? = null
    fun take(): String? { val p = pending; pending = null; return p }
}

/** Grubu kuran kişi sohbeti açtığında geçmişin en üstünde görünen tanıtım kartı (WhatsApp ölçüsü, ekran görüntüsünden) */
@Composable
fun GroupIntroCard(g: GroupData, onOpenInfo: () -> Unit) {
    fun go(a: String) { GroupAction.pending = a; onOpenInfo() }
    val light = AuraUi.light
    val green = if (light) Color(0xFF15603E) else Color(0xFF22C55E)
    val sub = if (light) Color(0xFF5A6265) else Color(0xFF8696A0)
    val txt = if (light) Color(0xFF090E13) else Color(0xFFE9EDEF)
    Box(Modifier.fillMaxWidth().padding(horizontal = 29.dp, vertical = 10.dp)) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                .background(if (light) Color(0xFFFEFEFC) else Color(0xFF1C2226))
                .padding(start = 26.dp, end = 26.dp, top = 19.dp, bottom = 23.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(63.dp).clickable { go("photo") }) {
                Avatar(g.name, g.photo, 63.dp, isGroup = true, accentAlways = true)
                Box(
                    Modifier.align(Alignment.BottomEnd).size(21.dp).clip(CircleShape).background(Color(0xFF15603E)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.CameraAlt, null, tint = Color.White, modifier = Modifier.size(12.dp)) }
            }
            Spacer(Modifier.height(14.dp))
            Text("Bu grubu siz oluşturdunuz", color = txt, fontSize = 17.sp)
            Spacer(Modifier.height(5.dp))
            Text("Grup · ${g.members.size} üye", color = sub, fontSize = 16.sp)
            Spacer(Modifier.height(12.dp))
            Text(
                buildAnnotatedString {
                    append(if (g.permAdd) "Üyeler başka kişileri ekleyebilir.\n" else "Yalnızca yöneticiler başka kişileri ekleyebilir.\n")
                    pushStyle(SpanStyle(color = green, fontWeight = FontWeight.Medium)); append("Düzenle"); pop()
                },
                color = sub, fontSize = 15.5.sp, lineHeight = 21.sp, textAlign = TextAlign.Center,
                modifier = Modifier.clickable { go("perms") }
            )
            Spacer(Modifier.height(19.dp))
            @Composable
            fun Btn(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, act: String) {
                Row(
                    Modifier.fillMaxWidth().height(38.dp).clip(RoundedCornerShape(19.dp))
                        .background(Color.Transparent, RoundedCornerShape(19.dp))
                        .clickable { go(act) }
                        .then(Modifier.androidBorder(if (light) Color(0xFFCFD0D2) else Color(0xFF2E373C))),
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(icon, null, tint = green, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(9.dp))
                    Text(label, color = green, fontSize = 15.5.sp)
                }
            }
            Btn(Icons.Default.Edit, "Bu gruba ad ver", "rename")
            Spacer(Modifier.height(8.dp))
            Btn(Icons.Default.PersonAdd, "Üye ekle", "add")
        }
    }
}

private fun Modifier.androidBorder(c: Color): Modifier =
    this.then(Modifier.border(BorderStroke(1.dp, c), RoundedCornerShape(19.dp)))

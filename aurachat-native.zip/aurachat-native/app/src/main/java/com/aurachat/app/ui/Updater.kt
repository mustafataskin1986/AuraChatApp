package com.aurachat.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Uygulama içi güncelleme: GitHub'daki "apk-latest" sürümüne bakar, yeni derleme varsa indirip kurulum ekranını açar */
object Updater {
    private const val RELEASE = "https://api.github.com/repos/mustafataskin1986/AuraChatApp/releases/tags/apk-latest"

    class Info(val build: Long, val url: String)

    var info by mutableStateOf<Info?>(null)
    var dialog by mutableStateOf(false)
    var progress by mutableFloatStateOf(-1f)
    private var checked = false
    /** Kurulum izni için ayarlara gönderildiyse, geri dönünce indirme kendiliğinden başlar */
    var pendingAfterPermission = false

    fun canInstall(ctx: Context): Boolean = Build.VERSION.SDK_INT < 26 || ctx.packageManager.canRequestPackageInstalls()

    /** İzin yoksa önce ayar ekranını açar (indirmeden önce); true dönerse devam edilebilir */
    fun ensurePermission(ctx: Context): Boolean {
        if (canInstall(ctx)) return true
        pendingAfterPermission = true
        Toast.makeText(ctx, "AuraChat'e kurulum izni ver, geri dönünce güncelleme başlayacak", Toast.LENGTH_LONG).show()
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return false
    }

    @Suppress("DEPRECATION")
    private fun current(ctx: Context): Long = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
    } catch (e: Exception) { Long.MAX_VALUE }

    suspend fun check(ctx: Context) {
        if (checked) return
        checked = true
        val found = withContext(Dispatchers.IO) {
            try {
                val c = URL(RELEASE).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val build = Regex("build (\\d+)").find(json.optString("body"))?.groupValues?.get(1)?.toLongOrNull() ?: return@withContext null
                val assets = json.optJSONArray("assets") ?: return@withContext null
                if (assets.length() == 0) return@withContext null
                val url = assets.getJSONObject(0).optString("browser_download_url")
                if (build > current(ctx) && url.isNotBlank()) Info(build, url) else null
            } catch (e: Exception) { null }
        }
        if (found != null) { info = found; dialog = true }
    }

    suspend fun downloadAndInstall(ctx: Context) {
        val i = info ?: return
        if (!ensurePermission(ctx)) return
        pendingAfterPermission = false
        progress = 0f
        val file = withContext(Dispatchers.IO) {
            try {
                val f = File(ctx.cacheDir, "update.apk")
                val c = URL(i.url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 30000
                val total = c.contentLengthLong
                c.inputStream.use { inp ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        var last = 0f
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val p = done.toFloat() / total
                                if (p - last > 0.01f) { last = p; progress = p }
                            }
                        }
                    }
                }
                f
            } catch (e: Exception) { null }
        }
        progress = -1f
        if (file != null) dialog = false
        if (file == null) { Toast.makeText(ctx, "İndirilemedi, bağlantını kontrol et", Toast.LENGTH_LONG).show(); return }
        install(ctx, file)
    }

    /** PackageInstaller oturumu: Android 12+ ve kurucu uygulama aynıysa onay ekranı çıkmadan arka planda kurulur */
    private fun install(ctx: Context, f: File) {
        try {
            val installer = ctx.packageManager.packageInstaller
            val params = android.content.pm.PackageInstaller.SessionParams(android.content.pm.PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(android.content.pm.PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
            val id = installer.createSession(params)
            installer.openSession(id).use { sess ->
                f.inputStream().use { inp ->
                    sess.openWrite("aurachat", 0, f.length()).use { out ->
                        inp.copyTo(out)
                        sess.fsync(out)
                    }
                }
                val pi = android.app.PendingIntent.getBroadcast(
                    ctx, id, Intent(ctx, UpdateReceiver::class.java).setPackage(ctx.packageName),
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) android.app.PendingIntent.FLAG_MUTABLE else 0)
                )
                sess.commit(pi.intentSender)
            }
        } catch (e: Exception) {
            Toast.makeText(ctx, "Kurulum başlatılamadı: " + (e.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }
}

/** Kurulum sonucunu alır: onay gerekiyorsa sistem kurulum ekranını açar, hata varsa bildirir */
class UpdateReceiver : android.content.BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.getIntExtra(android.content.pm.PackageInstaller.EXTRA_STATUS, -1)) {
            android.content.pm.PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) ctx.startActivity(confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            android.content.pm.PackageInstaller.STATUS_SUCCESS -> {}
            else -> Toast.makeText(ctx, "Güncelleme kurulamadı: " + (intent.getStringExtra(android.content.pm.PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""), Toast.LENGTH_LONG).show()
        }
    }
}

/** Açılışta güncelleme varsa "güncellemek ister misiniz?" penceresi */
@Composable
fun UpdateOverlay() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { Updater.check(ctx.applicationContext) }
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(owner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME && Updater.pendingAfterPermission && Updater.canInstall(ctx)) {
                scope.launch { Updater.downloadAndInstall(ctx) }
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    if (Updater.dialog && Updater.info != null) {
        val busy = Updater.progress >= 0f
        AlertDialog(
            onDismissRequest = { if (!busy) Updater.dialog = false },
            containerColor = AuraSurface,
            title = { Text("Yeni güncelleme mevcut", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(if (busy) "İndiriliyor… %" + (Updater.progress * 100).toInt() else "AuraChat'in yeni bir sürümü hazır. Güncellemek ister misiniz?", color = AuraMuted)
                    if (busy) {
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(progress = { Updater.progress }, modifier = Modifier.fillMaxWidth(), color = AuraGreen)
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = { scope.launch { Updater.downloadAndInstall(ctx) } }) {
                    Text("Güncelle", color = AuraGreen, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(enabled = !busy, onClick = { Updater.dialog = false }) { Text("Sonra", color = Color.White) }
            }
        )
    }
}

/** AuraChat başlığının yanındaki küçük "Güncelle" düğmesi: basınca pencere açmadan doğrudan indirip kurar, yüzdesini düğmede gösterir */
@Composable
fun UpdateChip() {
    if (Updater.info == null) return
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val busy = Updater.progress >= 0f
    Text(
        if (busy) "%" + (Updater.progress * 100).toInt() else "Güncelle",
        color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false,
        modifier = Modifier.padding(start = 8.dp).clip(RoundedCornerShape(50)).background(AuraGreen)
            .clickable(enabled = !busy) { scope.launch { Updater.downloadAndInstall(ctx) } }.padding(horizontal = 10.dp, vertical = 5.dp)
    )
}

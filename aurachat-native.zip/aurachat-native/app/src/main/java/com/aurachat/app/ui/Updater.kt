package com.aurachat.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Uygulama içi güncelleme: GitHub'daki "apk-latest" sürümüne bakar, yeni derleme varsa indirip kurulum ekranını açar */
object Updater {
    private const val RELEASE = "https://api.github.com/repos/mustafataskin1986/AuraChatApp/releases/tags/apk-latest"

    class Info(val build: Long, val url: String)

    var info by mutableStateOf<Info?>(null)
    var dialog by mutableStateOf(false)
    var progress by mutableFloatStateOf(-1f)
    private var checked = false

    @Suppress("DEPRECATION")
    private fun current(ctx: Context): Long = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
    } catch (e: Exception) { Long.MAX_VALUE }

    suspend fun check(ctx: Context) {
        if (checked) return
        checked = true
        val found = withContext(Dispatchers.IO) {
            try {
                val c = URL(RELEASE).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val build = Regex("build (\\d+)").find(json.optString("body"))?.groupValues?.get(1)?.toLongOrNull() ?: return@withContext null
                val assets = json.optJSONArray("assets") ?: return@withContext null
                if (assets.length() == 0) return@withContext null
                val url = assets.getJSONObject(0).optString("browser_download_url")
                if (build > current(ctx) && url.isNotBlank()) Info(build, url) else null
            } catch (e: Exception) { null }
        }
        if (found != null) { info = found; dialog = true }
    }

    suspend fun downloadAndInstall(ctx: Context) {
        val i = info ?: return
        progress = 0f
        val file = withContext(Dispatchers.IO) {
            try {
                val f = File(ctx.cacheDir, "update.apk")
                val c = URL(i.url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 30000
                val total = c.contentLengthLong
                c.inputStream.use { inp ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        var last = 0f
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val p = done.toFloat() / total
                                if (p - last > 0.01f) { last = p; progress = p }
                            }
                        }
                    }
                }
                f
            } catch (e: Exception) { null }
        }
        progress = -1f
        if (file == null) { Toast.makeText(ctx, "İndirilemedi, bağlantını kontrol et", Toast.LENGTH_LONG).show(); return }
        install(ctx, file)
    }

    private fun install(ctx: Context, f: File) {
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(ctx, "AuraChat'e kurulum izni ver, sonra tekrar Güncelle'ye bas", Toast.LENGTH_LONG).show()
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

/** Açılışta güncelleme varsa "güncellemek ister misiniz?" penceresi */
@Composable
fun UpdateOverlay() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { Updater.check(ctx.applicationContext) }
    if (Updater.dialog && Updater.info != null) {
        val busy = Updater.progress >= 0f
        AlertDialog(
            onDismissRequest = { if (!busy) Updater.dialog = false },
            containerColor = AuraSurface,
            title = { Text("Yeni güncelleme mevcut", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(if (busy) "İndiriliyor… %" + (Updater.progress * 100).toInt() else "AuraChat'in yeni bir sürümü hazır. Güncellemek ister misiniz?", color = AuraMuted)
                    if (busy) {
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(progress = { Updater.progress }, modifier = Modifier.fillMaxWidth(), color = AuraGreen)
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = { scope.launch { Updater.downloadAndInstall(ctx) } }) {
                    Text("Güncelle", color = AuraGreen, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(enabled = !busy, onClick = { Updater.dialog = false }) { Text("Sonra", color = Color.White) }
            }
        )
    }
}

/** AuraChat başlığının yanındaki küçük "Güncelle" düğmesi (güncelleme varsa görünür) */
@Composable
fun UpdateChip() {
    if (Updater.info == null) return
    Text(
        "Güncelle", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 8.dp).clip(RoundedCornerShape(50)).background(AuraGreen)
            .clickable { Updater.dialog = true }.padding(horizontal = 10.dp, vertical = 5.dp)
    )
}

package com.aurachat.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Uygulama içi güncelleme: GitHub'daki "apk-latest" sürümüne bakar, yeni derleme varsa indirip kurulum ekranını açar */
object Updater {
    private const val RELEASE = "https://api.github.com/repos/mustafataskin1986/AuraChatApp/releases/tags/apk-latest"

    class Info(val build: Long, val url: String)

    var info by mutableStateOf<Info?>(null)
    var dialog by mutableStateOf(false)
    var progress by mutableFloatStateOf(-1f)
    private var checked = false
    /** Kurulum izni için ayarlara gönderildiyse, geri dönünce indirme kendiliğinden başlar */
    var pendingAfterPermission = false

    fun canInstall(ctx: Context): Boolean = Build.VERSION.SDK_INT < 26 || ctx.packageManager.canRequestPackageInstalls()

    /** İzin yoksa önce ayar ekranını açar (indirmeden önce); true dönerse devam edilebilir */
    fun ensurePermission(ctx: Context): Boolean {
        if (canInstall(ctx)) return true
        pendingAfterPermission = true
        Toast.makeText(ctx, "AuraChat'e kurulum izni ver, geri dönünce güncelleme başlayacak", Toast.LENGTH_LONG).show()
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return false
    }

    @Suppress("DEPRECATION")
    private fun current(ctx: Context): Long = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
    } catch (e: Exception) { Long.MAX_VALUE }

    /** GitHub'daki en son derlemeyi okur; kendinden yeniyse bilgisini döner (arka plan işçisi de kullanır) */
    suspend fun fetchLatest(ctx: Context): Info? = withContext(Dispatchers.IO) {
        try {
            val c = URL(RELEASE).openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000
            c.setRequestProperty("Accept", "application/vnd.github+json")
            val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val build = Regex("build (\\d+)").find(json.optString("body"))?.groupValues?.get(1)?.toLongOrNull() ?: return@withContext null
            val assets = json.optJSONArray("assets") ?: return@withContext null
            if (assets.length() == 0) return@withContext null
            val url = assets.getJSONObject(0).optString("browser_download_url")
            if (build > current(ctx) && url.isNotBlank()) Info(build, url) else null
        } catch (e: Exception) { null }
    }

    suspend fun check(ctx: Context) {
        if (checked) return
        checked = true
        val found = fetchLatest(ctx)
        if (found != null) { info = found; if (dialog) { dialog = false; start(ctx) } }
    }

    /** İndirme (engelleyici; arka plan iş parçacığında çağrılır) */
    fun downloadTo(ctx: Context, url: String, onProgress: (Float) -> Unit): File? = try {
        val f = File(ctx.cacheDir, "update.apk")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        val total = c.contentLengthLong
        c.inputStream.use { inp ->
            f.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                var last = 0f
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val p = done.toFloat() / total
                        if (p - last > 0.01f) { last = p; onProgress(p) }
                    }
                }
            }
        }
        f
    } catch (e: Exception) { null }

    /** Kullanıcı "Güncelle"ye bastıysa onay ekranı hemen açılabilir; arka plan kurulumunda bildirim gösterilir */
    @Volatile var userInitiated = false

    /** Bildirime dokunuldu: indirilmiş dosya varsa taze oturumla kurulum onayını aç, yoksa güncelleme penceresini göster */
    fun installFromNotification(ctx: Context) {
        userInitiated = true
        val f = File(ctx.cacheDir, "update.apk")
        if (f.exists() && f.length() > 0L) {
            try { (ctx.getSystemService(android.app.NotificationManager::class.java)).cancel(7300) } catch (e: Throwable) {}
            Thread { install(ctx, f) }.start()
        } else if (info != null) {
            start(ctx)
        } else {
            dialog = true
        }
    }

    private val appScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.Main)

    /** Pencereden bağımsız başlatır (pencere kapansa / ekran yeniden kurulsa da indirme sürer) */
    fun start(ctx: Context) {
        if (progress >= 0f) return
        val c = ctx.applicationContext
        appScope.launch { downloadAndInstall(c) }
    }

    suspend fun downloadAndInstall(ctx: Context) {
        val i = info ?: return
        if (!ensurePermission(ctx)) return
        pendingAfterPermission = false
        progress = 0f
        userInitiated = true
        val file = withContext(Dispatchers.IO) { downloadTo(ctx, i.url) { progress = it } }
        progress = -1f
        if (file != null) dialog = false
        if (file == null) { Toast.makeText(ctx, "İndirilemedi, bağlantını kontrol et", Toast.LENGTH_LONG).show(); return }
        install(ctx, file)
    }

    /** PackageInstaller oturumu: Android 12+ ve kurucu uygulama aynıysa onay ekranı çıkmadan arka planda kurulur */
    @Synchronized
    fun install(ctx: Context, f: File) {
        try {
            val installer = ctx.packageManager.packageInstaller
            // yarım kalan eski kurulum oturumları birikince "Too many active sessions" hatası çıkar: önce hepsini temizle
            try { installer.mySessions.forEach { if (!it.isActive) try { installer.abandonSession(it.sessionId) } catch (e: Exception) {} } } catch (e: Exception) {}
            val params = android.content.pm.PackageInstaller.SessionParams(android.content.pm.PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(android.content.pm.PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
            val id = installer.createSession(params)
            var committed = false
            try {
            installer.openSession(id).use { sess ->
                f.inputStream().use { inp ->
                    sess.openWrite("aurachat", 0, f.length()).use { out ->
                        inp.copyTo(out)
                        sess.fsync(out)
                    }
                }
                val pi = android.app.PendingIntent.getBroadcast(
                    ctx, id, Intent(ctx, UpdateReceiver::class.java).setPackage(ctx.packageName),
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) android.app.PendingIntent.FLAG_MUTABLE else 0)
                )
                sess.commit(pi.intentSender)
                committed = true
            }
            } finally {
                if (!committed) try { installer.abandonSession(id) } catch (e: Exception) {}
            }
        } catch (e: Exception) {
            toast(ctx, "Kurulum başlatılamadı: " + (e.message ?: ""))
        }
    }

    fun toast(ctx: Context, msg: String) {
        android.os.Handler(android.os.Looper.getMainLooper()).post { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() }
    }

    const val CHANNEL = "aurachat-update"

    /** Kayan (heads-up) "yeni sürüm" bildirimi; aynı derleme için bir kez gösterilir */
    fun notifyUpdate(ctx: Context, build: Long, title: String, text: String, action: Intent? = null) {
        val prefs = ctx.getSharedPreferences("update", Context.MODE_PRIVATE)
        val key = "notified-" + (if (action != null) "action" else "ready")
        if (prefs.getLong(key, 0L) == build) return
        prefs.edit().putLong(key, build).apply()
        val nm = ctx.getSystemService(android.app.NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(android.app.NotificationChannel(CHANNEL, "Güncellemeler", android.app.NotificationManager.IMPORTANCE_HIGH))
        }
        // Eski oturumun onay intent'i başka kurulum oturumu açılınca geçersiz kalıyordu (dokununca hiçbir şey olmuyordu):
        // bildirim uygulamayı açar, uygulama indirilmiş dosyayla taze bir kurulum oturumu başlatır
        val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (action != null) launch?.putExtra("installUpdate", true)
        val tap = android.app.PendingIntent.getActivity(
            ctx, if (action != null) 7301 else 7300, launch,
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = androidx.core.app.NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(com.aurachat.app.R.drawable.ic_notification)
            .setContentTitle(title).setContentText(text)
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
            .setDefaults(androidx.core.app.NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true).setContentIntent(tap).build()
        try { nm.notify(7300, n) } catch (e: Throwable) {}
    }
}

/** Arka planda birkaç saatte bir yeni sürüme bakar: izin varsa indirip sessiz kurmayı dener, olmazsa kayan bildirim gösterir */
class UpdateWorker(ctx: Context, params: androidx.work.WorkerParameters) : androidx.work.CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val c = applicationContext
        val info = Updater.fetchLatest(c) ?: return Result.success()
        if (Build.VERSION.SDK_INT < 31 || !Updater.canInstall(c)) {
            Updater.notifyUpdate(c, info.build, "AuraChat'in yeni sürümü hazır", "Güncellemek için dokunun")
            return Result.success()
        }
        val prefs = c.getSharedPreferences("update", Context.MODE_PRIVATE)
        val f = File(c.cacheDir, "update.apk")
        if (prefs.getLong("downloaded", 0L) != info.build || !f.exists()) {
            val ok = withContext(Dispatchers.IO) { Updater.downloadTo(c, info.url) { } }
            if (ok == null) return Result.retry()
            prefs.edit().putLong("downloaded", info.build).apply()
        }
        Updater.userInitiated = false
        Updater.install(c, f)
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val net = androidx.work.Constraints.Builder().setRequiredNetworkType(androidx.work.NetworkType.CONNECTED).build()
            val wm = androidx.work.WorkManager.getInstance(ctx)
            // Her açılışta hemen bir kez, sonra Android'in izin verdiği en sık aralıkla (15 dk) kontrol eder
            wm.enqueueUniqueWork("aurachat-update-now", androidx.work.ExistingWorkPolicy.REPLACE,
                androidx.work.OneTimeWorkRequestBuilder<UpdateWorker>().setConstraints(net).build())
            val req = androidx.work.PeriodicWorkRequestBuilder<UpdateWorker>(15, java.util.concurrent.TimeUnit.MINUTES).setConstraints(net).build()
            wm.enqueueUniquePeriodicWork("aurachat-update", androidx.work.ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}

/** Kurulum sonucunu alır: onay gerekiyorsa sistem kurulum ekranını açar, hata varsa bildirir */
class UpdateReceiver : android.content.BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.getIntExtra(android.content.pm.PackageInstaller.EXTRA_STATUS, -1)) {
            android.content.pm.PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                var confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                // Çift uygulama / ikinci alanda sistemin kurulum ekranı bulunamayabilir ("No Activity found"): çökmesin, yedek yol dene
                if (confirm != null && confirm.resolveActivity(ctx.packageManager) == null) {
                    confirm.setPackage(null)
                    if (confirm.resolveActivity(ctx.packageManager) == null) {
                        confirm = try {
                            val apk = File(ctx.cacheDir, "update.apk")
                            val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", apk)
                            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                                .takeIf { it.resolveActivity(ctx.packageManager) != null }
                        } catch (e: Throwable) { null }
                    }
                    if (confirm == null) {
                        Updater.toast(ctx, "Bu kopyada kurulum ekranı açılamadı. Güncelleme dosyasını indirip dosya yöneticisinden kur.")
                        return
                    }
                }
                if (confirm != null) {
                    if (Updater.userInitiated || com.aurachat.app.AppState.foreground) { try { ctx.startActivity(confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Throwable) { Updater.toast(ctx, "Kurulum ekranı açılamadı") } }
                    else Updater.notifyUpdate(ctx, ctx.getSharedPreferences("update", Context.MODE_PRIVATE).getLong("downloaded", 1L), "AuraChat güncellemesi hazır", "Kurmak için dokunun", confirm)
                }
            }
            android.content.pm.PackageInstaller.STATUS_SUCCESS, android.content.pm.PackageInstaller.STATUS_FAILURE_ABORTED -> {}
            else -> Toast.makeText(ctx, "Güncelleme kurulamadı: " + (intent.getStringExtra(android.content.pm.PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""), Toast.LENGTH_LONG).show()
        }
    }
}

/** Açılışta güncelleme varsa "güncellemek ister misiniz?" penceresi */
@Composable
fun UpdateOverlay() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { Updater.check(ctx.applicationContext) }
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(owner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME && Updater.pendingAfterPermission && Updater.canInstall(ctx)) {
                scope.launch { Updater.downloadAndInstall(ctx) }
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    if (Updater.dialog && Updater.info != null) {
        val busy = Updater.progress >= 0f
        AuraAlertDialog(
            onDismissRequest = { if (!busy) Updater.dialog = false },
            containerColor = AuraSurface,
            title = { Text("Yeni güncelleme mevcut", color = AuraWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(if (busy) "İndiriliyor… %" + (Updater.progress * 100).toInt() else "AuraChat'in yeni bir sürümü hazır. Güncellemek ister misiniz?", color = AuraMuted)
                    if (busy) {
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(progress = { Updater.progress }, modifier = Modifier.fillMaxWidth(), color = AuraGreen)
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = { Updater.start(ctx) }) {
                    Text("Güncelle", color = AuraGreen, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(enabled = !busy, onClick = { Updater.dialog = false }) { Text("Sonra", color = AuraWhite) }
            }
        )
    }
}

/** AuraChat başlığının yanındaki küçük "Güncelle" düğmesi: basınca pencere açmadan doğrudan indirip kurar, yüzdesini düğmede gösterir */
@Composable
fun UpdateChip() {
    if (Updater.info == null) return
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val busy = Updater.progress >= 0f
    // yüzde yazısı yok: ilerleme, durum çubuğunun altında soldan sağa dolan yeşil çubukta (UpdateProgressBar) gösterilir
    Text(
        if (busy) "İndiriliyor…" else "Güncelle",
        color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false,
        modifier = Modifier.padding(start = 8.dp).clip(RoundedCornerShape(50)).background(AuraGreen)
            .clickable(enabled = !busy) { Updater.start(ctx) }.padding(horizontal = 10.dp, vertical = 5.dp)
    )
}


/** Güncelleme inerken durum çubuğunun hemen altında soldan sağa dolan ince yeşil ilerleme çubuğu (tüm ekranlarda görünür) */
@Composable
fun UpdateProgressBar() {
    val p = Updater.progress
    if (p < 0f) return
    val a by androidx.compose.animation.core.animateFloatAsState(p.coerceIn(0f, 1f), androidx.compose.animation.core.tween(300), label = "updbar")
    androidx.compose.foundation.layout.Box(
        Modifier.fillMaxWidth().statusBarsPadding().height(3.dp).background((AuraUi.accentColor() ?: Color(0xFF22C55E)).copy(alpha = 0.2f))
    ) {
        androidx.compose.foundation.layout.Box(Modifier.fillMaxHeight().fillMaxWidth(a).background(AuraUi.accentColor() ?: Color(0xFF22C55E)))
    }
}

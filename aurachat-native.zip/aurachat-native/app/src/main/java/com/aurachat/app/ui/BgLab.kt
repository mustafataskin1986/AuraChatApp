package com.aurachat.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * DENEME: koyu temadaki saf siyah arka planların yerine seçilen rengi koyar.
 * Kaldırmak için: bu dosyayı sil, Theme.kt'deki lm() başındaki "BgLab" satırını,
 * MainActivity/AuraApp'taki "BgLab.load" satırlarını ve ThemePanel.kt'deki "BgLabBar()" satırını sil.
 */
object BgLab {
    var color by androidx.compose.runtime.mutableStateOf<Color?>(null)
        private set

    fun load(ctx: android.content.Context) {
        val v = ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).getLong("bglab_color", -1L)
        color = if (v < 0) null else Color(0xFF000000.toInt() or v.toInt())
    }

    fun set(ctx: android.content.Context, rgb: Long?) {
        // arka plan rengi yalnızca karanlık temada geçerli: açıktaysa karanlığa geç
        if (rgb != null && AuraUi.light) AuraUi.setMode(ctx, 0)
        color = rgb?.let { Color(0xFF000000.toInt() or it.toInt()) }
        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putLong("bglab_color", rgb ?: -1L).apply()
    }

    val swatches = listOf(
        0x0B1014L, 0x0B141AL, 0x111B21L, 0x121212L, 0x1E1E1EL, 0x202C33L,
        0x0A0A0FL, 0x0F172AL, 0x0B1C2CL, 0x14213DL, 0x0D1F17L, 0x10261BL,
        0x1A1020L, 0x24122EL, 0x2B1B17L, 0x1F1F2EL
    )
}

@Composable
fun BgLabBar() {
    val ctx = LocalContext.current
    val cur = BgLab.color
    val all: List<Long?> = listOf<Long?>(null) + BgLab.swatches
    fun rgbOf(c: Color?) = if (c == null) 0 else (Math.round(c.red * 255) shl 16) or (Math.round(c.green * 255) shl 8) or Math.round(c.blue * 255)
    var hsv by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(rgbToHsv(rgbOf(cur))) }
    var hex by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("%06X".format(rgbOf(cur))) }
    // palet rengi seçilince çubuklar o renge göre kurulur; çubuk sürüklenirken sıfırlanmaz
    androidx.compose.runtime.LaunchedEffect(cur) {
        val r = rgbOf(cur)
        if (r != hsvToRgb(hsv[0], hsv[1], hsv[2])) { hsv = rgbToHsv(r); hex = "%06X".format(r) }
    }
    val shown = Color(0xFF000000L or hsvToRgb(hsv[0], hsv[1], hsv[2]).toLong())
    fun apply(h: Float, s: Float, v: Float) {
        hsv = floatArrayOf(h, s, v)
        val rgb = hsvToRgb(h, s, v)
        hex = "%06X".format(rgb)
        BgLab.set(ctx, rgb.toLong())
    }
    Column(Modifier.fillMaxWidth()) {
        all.chunked(5).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                row.forEach { rgb ->
                    val c = if (rgb == null) Color.Black else Color(0xFF000000.toInt() or rgb.toInt())
                    val on = if (rgb == null) cur == null else cur == c
                    Box(
                        Modifier.size(52.dp).clip(CircleShape).background(c)
                            .border(if (on) 2.5.dp else 1.dp, if (on) AuraWhite else AuraMuted.copy(alpha = 0.4f), CircleShape)
                            .clickable { BgLab.set(ctx, rgb) },
                        contentAlignment = Alignment.Center
                    ) { if (on) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
                }
                repeat(5 - row.size) { Box(Modifier.size(52.dp)) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Arka plan", color = AuraMuted, fontSize = 15.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, modifier = Modifier.weight(1f))
            Box(Modifier.size(22.dp).clip(CircleShape).background(shown))
            androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp))
            Row(
                Modifier.clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp)).border(1.dp, AuraMuted.copy(alpha = 0.4f), androidx.compose.foundation.shape.RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("#", color = AuraMuted, fontSize = 15.sp)
                androidx.compose.foundation.text.BasicTextField(
                    value = hex,
                    onValueChange = { raw ->
                        val f = raw.filter { it.isDigit() || it.lowercaseChar() in 'a'..'f' }.take(6).uppercase()
                        hex = f
                        if (f.length == 6) {
                            val rgb = f.toInt(16)
                            hsv = rgbToHsv(rgb)
                            BgLab.set(ctx, rgb.toLong())
                        }
                    },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = AuraWhite, fontSize = 15.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium),
                    cursorBrush = androidx.compose.ui.graphics.Brush.verticalGradient(listOf(AuraGreen, AuraGreen)),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Ascii),
                    modifier = Modifier.width(72.dp)
                )
            }
        }
        Text("Doygunluk", color = AuraMuted, fontSize = 13.sp)
        GradBar(hsv[1], listOf(Color(0xFF000000L or hsvToRgb(hsv[0], 0f, hsv[2]).toLong()), Color(0xFF000000L or hsvToRgb(hsv[0], 1f, hsv[2]).toLong()))) { apply(hsv[0], it, hsv[2]) }
        Text("Parlaklık", color = AuraMuted, fontSize = 13.sp)
        GradBar(hsv[2], listOf(Color.Black, Color(0xFF000000L or hsvToRgb(hsv[0], hsv[1], 1f).toLong()))) { apply(hsv[0], hsv[1], it) }
        Text("Karanlık temada siyah olan yerlerin rengi değişir.", color = AuraMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

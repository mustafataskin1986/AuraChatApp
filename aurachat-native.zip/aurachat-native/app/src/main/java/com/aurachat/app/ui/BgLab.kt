package com.aurachat.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * DENEME: koyu temadaki saf siyah arka planların yerine seçilen rengi koyar.
 * Kaldırmak için: bu dosyayı sil, Theme.kt'deki lm() başındaki "BgLab" satırını,
 * MainActivity/AuraApp'taki "BgLab.load" satırlarını ve ThemePanel.kt'deki "BgLabBar()" satırını sil.
 */
object BgLab {
    var color by androidx.compose.runtime.mutableStateOf<Color?>(null)
        private set

    fun load(ctx: android.content.Context) {
        val v = ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).getLong("bglab_color", -1L)
        color = if (v < 0) null else Color(0xFF000000.toInt() or v.toInt())
    }

    fun set(ctx: android.content.Context, rgb: Long?) {
        color = rgb?.let { Color(0xFF000000.toInt() or it.toInt()) }
        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putLong("bglab_color", rgb ?: -1L).apply()
    }

    val swatches = listOf(
        0x0B1014L, 0x0B141AL, 0x111B21L, 0x121212L, 0x1E1E1EL, 0x202C33L,
        0x0A0A0FL, 0x0F172AL, 0x0B1C2CL, 0x14213DL, 0x0D1F17L, 0x10261BL,
        0x1A1020L, 0x24122EL, 0x2B1B17L, 0x1F1F2EL
    )
}

@Composable
fun BgLabBar() {
    val ctx = LocalContext.current
    val cur = BgLab.color
    val all: List<Long?> = listOf<Long?>(null) + BgLab.swatches
    Column(Modifier.fillMaxWidth()) {
        all.chunked(5).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                row.forEach { rgb ->
                    val c = if (rgb == null) Color.Black else Color(0xFF000000.toInt() or rgb.toInt())
                    val on = if (rgb == null) cur == null else cur == c
                    Box(
                        Modifier.size(52.dp).clip(CircleShape).background(c)
                            .border(if (on) 2.5.dp else 1.dp, if (on) AuraWhite else AuraMuted.copy(alpha = 0.4f), CircleShape)
                            .clickable { BgLab.set(ctx, rgb) },
                        contentAlignment = Alignment.Center
                    ) { if (on) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
                }
                repeat(5 - row.size) { Box(Modifier.size(52.dp)) }
            }
        }
        Text("Karanlık temada siyah olan yerlerin rengi değişir.", color = AuraMuted, fontSize = 12.sp)
    }
}

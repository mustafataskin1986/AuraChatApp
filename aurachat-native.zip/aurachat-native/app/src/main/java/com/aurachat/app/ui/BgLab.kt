package com.aurachat.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * DENEME: koyu temadaki saf siyah arka planların yerine seçilen rengi koyar.
 * Kaldırmak için: bu dosyayı sil, Theme.kt'deki lm() başındaki "BgLab" satırını,
 * MainActivity/AuraApp'taki "BgLab.load" satırlarını ve ThemePanel.kt'deki "BgLabBar()" satırını sil.
 */
object BgLab {
    var color by androidx.compose.runtime.mutableStateOf<Color?>(Color(0xFF0A1016))
        private set

    /** Açık temadaki ekran zemini (null = beyaz) */
    var lightColor by androidx.compose.runtime.mutableStateOf<Color?>(null)
        private set

    /** Koyu temada input (arama kutusu vb.) iç rengi; null = vurgudan türer */
    var input by androidx.compose.runtime.mutableStateOf<Color?>(null)
        private set

    fun setInput(ctx: android.content.Context, rgb: Long?) {
        input = rgb?.let { Color(0xFF000000.toInt() or it.toInt()) }
        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putLong("bglab_input", rgb ?: -1L).apply()
    }

    fun load(ctx: android.content.Context) {
        val sp = ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE)
        val inp = sp.getLong("bglab_input", -1L)
        input = if (inp < 0) null else Color(0xFF000000.toInt() or inp.toInt())
        val v = sp.getLong("bglab_color", -1L)
        color = Color(0xFF000000.toInt() or (if (v < 0) DEFAULT_DARK.toInt() else v.toInt()))
        val l = sp.getLong("bglab_light", -1L)
        lightColor = if (l < 0) null else Color(0xFF000000.toInt() or l.toInt())
    }

    /** Koyu temadaki arka plan rengi */
    /** Koyu temanın varsayılan zemini (Okyanus paketi) */
    const val DEFAULT_DARK = 0x0A1016L

    fun set(ctx: android.content.Context, rgb: Long?) {
        val v = rgb ?: DEFAULT_DARK
        color = Color(0xFF000000.toInt() or v.toInt())
        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putLong("bglab_color", v).apply()
    }

    /** Açık temadaki arka plan rengi */
    fun setLight(ctx: android.content.Context, rgb: Long?) {
        lightColor = rgb?.let { Color(0xFF000000.toInt() or it.toInt()) }
        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putLong("bglab_light", rgb ?: -1L).apply()
    }

    val swatches = listOf(
        0x0B1014L, 0x0B141AL, 0x111B21L, 0x121212L, 0x1E1E1EL, 0x202C33L,
        0x0A0A0FL, 0x0F172AL, 0x0B1C2CL, 0x14213DL, 0x0D1F17L, 0x10261BL,
        0x1A1020L, 0x24122EL, 0x2B1B17L, 0x1F1F2EL
    )
}

package com.aurachat.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntSize
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

/** Sohbet teması: arka plan (gradyan) + giden balon rengi. Kişiye özeldir, sadece bu cihazda tutulur. */
class ChatTheme(val id: String, val name: String, val stops: List<Pair<Float, Color>>?, val out: Color?)
class BubbleColor(val id: String, val name: String, val color: Color)

/** Sohbete uygulanmış hâli: gradyan, özel resim ya da varsayılan */
class ResolvedTheme(val id: String, val stops: List<Pair<Float, Color>>?, val image: ImageBitmap?, private val outRaw: Color, val doodle: Boolean = true, val bright: Float = 1f) {
    val isDefaultOut: Boolean = outRaw == ThemeDefaultOut
    val out: Color get() = accentOf(outRaw)
    val bubble: Color get() = bubbleOf(outRaw)
    /** Gelen balon rengi: açık Minimal temada WhatsApp gibi açık gri; diğerlerinde varsayılan */
    val theirs: Color? get() = if (AuraUi.light && id.startsWith("mnl")) Color(0xFFEEEEEE) else null
}

val ThemeDefaultOut = Color(0xFF005C4B)
val ThemeDefaultIn: Color get() = auraLc(0xFF212121)

private fun c(rgb: Long) = Color(0xFF000000 or rgb)
private fun grad(vararg v: Pair<Float, Color>) = v.toList()
/** Çiziktirme zemini: renk %14 karışımla neredeyse siyaha çekilir, desen ise rengin kendisiyle boyanır */
private fun zbg(rgb: Long): Color {
    val r = ((rgb shr 16) and 255) * 0.14f; val g = ((rgb shr 8) and 255) * 0.14f; val b = (rgb and 255) * 0.14f
    return Color(0xFF000000.toInt() or (r.toInt() shl 16) or (g.toInt() shl 8) or b.toInt())
}
/** Minimal (koyu): rengin %5'i kadar tonla neredeyse siyah gri zemin */
private fun mnDark(rgb: Long): Color {
    val r = ((rgb shr 16) and 255) * 0.04f + 11; val g = ((rgb shr 8) and 255) * 0.04f + 17; val b = (rgb and 255) * 0.04f + 22
    return Color(0xFF000000.toInt() or (r.toInt() shl 16) or (g.toInt() shl 8) or b.toInt())
}
/** Minimal (açık): beyaza yakın, rengin %4'ü kadar tonlu zemin */
private fun mnLight(rgb: Long): Color {
    val r = 255 - (255 - ((rgb shr 16) and 255)) * 0.015f; val g = 255 - (255 - ((rgb shr 8) and 255)) * 0.015f; val b = 255 - (255 - (rgb and 255)) * 0.015f
    return Color(0xFF000000.toInt() or (r.toInt() shl 16) or (g.toInt() shl 8) or b.toInt())
}
private fun solid(col: Color) = listOf(0f to col, 1f to col)

object ChatThemes {
    val all: List<ChatTheme> = listOf(
        ChatTheme("default", "Varsayılan", null, null),
        ChatTheme("amoled", "Kömür", solid(c(0x000000)), c(0x1f6f5c)),
        ChatTheme("mavi", "Gece Mavisi", grad(0f to c(0x0a1929), 1f to c(0x12304d)), c(0x1d5fa8)),
        ChatTheme("orman", "Orman", grad(0f to c(0x0b1f14), 1f to c(0x14402a)), c(0x1f7a4d)),
        ChatTheme("okyanus", "Okyanus", grad(0f to c(0x04222b), 1f to c(0x0b5563)), c(0x118a9a)),
        ChatTheme("gunbatimi", "Gün Batımı", grad(0f to c(0x2b1020), 0.6f to c(0x5a2a3a), 1f to c(0x7a3f2a)), c(0xb5483a)),
        ChatTheme("mor", "Mor Gece", grad(0f to c(0x160b2e), 1f to c(0x3a1b6b)), c(0x6d3fc0)),
        ChatTheme("pembe", "Pembe", grad(0f to c(0x2a0f22), 1f to c(0x5a1f4a)), c(0xc2347f)),
        ChatTheme("bordo", "Bordo", grad(0f to c(0x2a0d12), 1f to c(0x5a1a26)), c(0xa3283d)),
        ChatTheme("kahve", "Kahve", grad(0f to c(0x1f1510), 1f to c(0x3d2a1f)), c(0x8a5a3a)),
        ChatTheme("celik", "Çelik", grad(0f to c(0x14171c), 1f to c(0x2a3038)), c(0x4b6a8a)),
        ChatTheme("g_col", "Çöl", grad(0f to c(0xf0a58f), 0.5f to c(0xd9795f), 1f to c(0x8a3b2e)), null),
        ChatTheme("g_orman", "Sisli Orman", grad(0f to c(0xcfe3d4), 0.5f to c(0x6a9b7c), 1f to c(0x1f4d3a)), null),
        ChatTheme("g_deniz", "Turkuaz Kıyı", grad(0f to c(0x9fe0e6), 0.5f to c(0x2ea7b8), 1f to c(0x0b4f63)), null),
        ChatTheme("g_gokyuzu", "Alacakaranlık", grad(0f to c(0x3b4cc0), 0.55f to c(0xb07cc6), 1f to c(0xf2b38b)), null),
        ChatTheme("g_dag", "Dağ Sabahı", grad(0f to c(0xb8d4ec), 0.5f to c(0x7aa3c9), 1f to c(0x34506e)), null),
        ChatTheme("g_gece", "Yıldızlı Gece", grad(0f to c(0x05070f), 0.55f to c(0x101b3a), 1f to c(0x1b2a55)), null),
        ChatTheme("g_kum", "Kum", grad(0f to c(0xf3e2c3), 0.5f to c(0xd9b98a), 1f to c(0xa77b4f)), null),
        ChatTheme("g_kar", "Kar Mavisi", grad(0f to c(0xeef4fb), 0.5f to c(0xb9cfe6), 1f to c(0x7d9bbd)), null),
        ChatTheme("c_holo", "Holografik", grad(0f to c(0xf6c1e4), 0.3f to c(0xb9d6ff), 0.55f to c(0xc9f3e1), 0.8f to c(0xf7e3b5), 1f to c(0xe1b8f5)), null),
        ChatTheme("c_aurora", "Aurora", grad(0f to c(0x041b2b), 0.45f to c(0x0b5d5a), 0.75f to c(0x2d9c7a), 1f to c(0x141a45)), null),
        ChatTheme("c_mavi", "Gökyüzü", grad(0f to c(0x2f5bea), 0.5f to c(0x7db0f5), 0.8f to c(0xcfe9ff), 1f to c(0xe6f0b8)), null),
        ChatTheme("c_gece", "Gece Yarısı", grad(0f to c(0x05090f), 0.5f to c(0x0a1b33), 0.8f to c(0x1a2f66), 1f to c(0x0b0b14)), null),
        ChatTheme("c_seker", "Şeker", grad(0f to c(0xff9ac7), 0.5f to c(0xc08cff), 1f to c(0x7fb7ff)), null),
        ChatTheme("c_alev", "Alev", grad(0f to c(0xff8a3d), 0.5f to c(0xe5383b), 1f to c(0x6a040f)), null),
        ChatTheme("z4e38b3", "Çiziktirme", solid(zbg(0x4e38b3)), null),
        ChatTheme("zd82d63", "Çiziktirme", solid(zbg(0xd82d63)), null),
        ChatTheme("z53565a", "Çiziktirme", solid(zbg(0x53565a)), null),
        ChatTheme("z126d47", "Çiziktirme", solid(zbg(0x126d47)), null),
        ChatTheme("z9e3f22", "Çiziktirme", solid(zbg(0x9e3f22)), null),
        ChatTheme("z08529e", "Çiziktirme", solid(zbg(0x08529e)), null),
        ChatTheme("z803399", "Çiziktirme", solid(zbg(0x803399)), null),
        ChatTheme("z0e5d8d", "Çiziktirme", solid(zbg(0x0e5d8d)), null),
        ChatTheme("z9b153b", "Çiziktirme", solid(zbg(0x9b153b)), null),
        ChatTheme("z5e8a27", "Çiziktirme", solid(zbg(0x5e8a27)), null),
        ChatTheme("mnd0", "Minimal", solid(mnDark(0x3b3d3e)), null),
        ChatTheme("mnd1", "Minimal", solid(mnDark(0x631026)), null),
        ChatTheme("mnd2", "Minimal", solid(mnDark(0x2c2463)), null),
        ChatTheme("mnd3", "Minimal", solid(mnDark(0x532168)), null),
        ChatTheme("mnd4", "Minimal", solid(mnDark(0x092e5c)), null),
        ChatTheme("mnd5", "Minimal", solid(mnDark(0x0d4a30)), null),
        ChatTheme("mnd6", "Minimal", solid(mnDark(0x532b20)), null),
        ChatTheme("mnd7", "Minimal", solid(mnDark(0x0c3b52)), null),
        ChatTheme("mnd8", "Minimal", solid(mnDark(0x6f1127)), null),
        ChatTheme("mnd9", "Minimal", solid(mnDark(0x3c503e)), null),
        ChatTheme("mnl0", "Minimal", solid(mnLight(0x53565a)), null),
        ChatTheme("mnl1", "Minimal", solid(mnLight(0x691b3b)), null),
        ChatTheme("mnl2", "Minimal", solid(mnLight(0x4e38b3)), null),
        ChatTheme("mnl3", "Minimal", solid(mnLight(0x803399)), null),
        ChatTheme("mnl4", "Minimal", solid(mnLight(0x08529e)), null),
        ChatTheme("mnl5", "Minimal", solid(mnLight(0x126d47)), null),
        ChatTheme("mnl6", "Minimal", solid(mnLight(0x9e3f22)), null),
        ChatTheme("mnl7", "Minimal", solid(mnLight(0x0e5d8d)), null),
        ChatTheme("mnl8", "Minimal", solid(mnLight(0x9b153b)), null),
        ChatTheme("mnl9", "Minimal", solid(mnLight(0x6f1127)), null),
        ChatTheme("s2a7b72", "Düz", solid(c(0x2a7b72)), null),
        ChatTheme("s2d6a4f", "Düz", solid(c(0x2d6a4f)), null),
        ChatTheme("s1e532b", "Düz", solid(c(0x1e532b)), null),
        ChatTheme("s3a6073", "Düz", solid(c(0x3a6073)), null),
        ChatTheme("s1a5b6e", "Düz", solid(c(0x1a5b6e)), null),
        ChatTheme("s174355", "Düz", solid(c(0x174355)), null),
        ChatTheme("s362a63", "Düz", solid(c(0x362a63)), null),
        ChatTheme("s525252", "Düz", solid(c(0x525252)), null),
        ChatTheme("s5c6b39", "Düz", solid(c(0x5c6b39)), null),
        ChatTheme("s807328", "Düz", solid(c(0x807328)), null),
        ChatTheme("s6b5a0a", "Düz", solid(c(0x6b5a0a)), null),
        ChatTheme("sb85b00", "Düz", solid(c(0xb85b00)), null),
        ChatTheme("s680c1d", "Düz", solid(c(0x680c1d)), null),
        ChatTheme("s4a0e0e", "Düz", solid(c(0x4a0e0e)), null),
        ChatTheme("s300808", "Düz", solid(c(0x300808)), null),
        ChatTheme("s42141a", "Düz", solid(c(0x42141a)), null),
        ChatTheme("s6e2d1b", "Düz", solid(c(0x6e2d1b)), null),
        ChatTheme("s2e2528", "Düz", solid(c(0x2e2528)), null),
        ChatTheme("s263d3c", "Düz", solid(c(0x263d3c)), null),
        ChatTheme("s1e3b4a", "Düz", solid(c(0x1e3b4a)), null),
        ChatTheme("s182538", "Düz", solid(c(0x182538)), null),
        ChatTheme("s3d434a", "Düz", solid(c(0x3d434a)), null),
        ChatTheme("s0e1114", "Düz", solid(c(0x0e1114)), null),
        ChatTheme("s1c121e", "Düz", solid(c(0x1c121e)), null),
        ChatTheme("s546e7a", "Düz", solid(c(0x546e7a)), null),
        ChatTheme("s667009", "Düz", solid(c(0x667009)), null),
        ChatTheme("s757d42", "Düz", solid(c(0x757d42)), null)
    )

    /** Giden balon renkleri (arka plandan bağımsız seçilir) */
    val bubbleColors: List<BubbleColor> = listOf(
        BubbleColor("default", "Varsayılan", ThemeDefaultOut),
        BubbleColor("126d47", "Renk", c(0x126d47)),
        BubbleColor("0d4a30", "Renk", c(0x0d4a30)),
        BubbleColor("08529e", "Renk", c(0x08529e)),
        BubbleColor("092e5c", "Renk", c(0x092e5c)),
        BubbleColor("4e38b3", "Renk", c(0x4e38b3)),
        BubbleColor("2c2463", "Renk", c(0x2c2463)),
        BubbleColor("0e5d8d", "Renk", c(0x0e5d8d)),
        BubbleColor("0c3b52", "Renk", c(0x0c3b52)),
        BubbleColor("803399", "Renk", c(0x803399)),
        BubbleColor("532168", "Renk", c(0x532168)),
        BubbleColor("53565a", "Renk", c(0x53565a)),
        BubbleColor("3b3d3e", "Renk", c(0x3b3d3e)),
        BubbleColor("9e3f22", "Renk", c(0x9e3f22)),
        BubbleColor("532b20", "Renk", c(0x532b20)),
        BubbleColor("3c503e", "Renk", c(0x3c503e)),
        BubbleColor("29362a", "Renk", c(0x29362a)),
        BubbleColor("086b66", "Renk", c(0x086b66)),
        BubbleColor("064643", "Renk", c(0x064643)),
        BubbleColor("9b153b", "Renk", c(0x9b153b)),
        BubbleColor("631026", "Renk", c(0x631026)),
        BubbleColor("794b2a", "Renk", c(0x794b2a)),
        BubbleColor("3f2716", "Renk", c(0x3f2716)),
        BubbleColor("8d7053", "Renk", c(0x8d7053)),
        BubbleColor("43372b", "Renk", c(0x43372b)),
        BubbleColor("0a7f6f", "Renk", c(0x0a7f6f)),
        BubbleColor("065248", "Renk", c(0x065248)),
        BubbleColor("c5a300", "Renk", c(0xc5a300)),
        BubbleColor("736000", "Renk", c(0x736000)),
        BubbleColor("5e8a27", "Renk", c(0x5e8a27)),
        BubbleColor("395217", "Renk", c(0x395217)),
        BubbleColor("d82d63", "Renk", c(0xd82d63)),
        BubbleColor("691b3b", "Renk", c(0x691b3b)),
        BubbleColor("ca1236", "Renk", c(0xca1236)),
        BubbleColor("6f1127", "Renk", c(0x6f1127)),
        BubbleColor("a72917", "Renk", c(0xa72917)),
        BubbleColor("5c130b", "Renk", c(0x5c130b)),
        BubbleColor("b6862b", "Renk", c(0xb6862b)),
        BubbleColor("584b23", "Renk", c(0x584b23)),
        BubbleColor("1f7a4d", "Orman Yeşili", c(0x1f7a4d)),
        BubbleColor("118a9a", "Turkuaz", c(0x118a9a)),
        BubbleColor("1d5fa8", "Mavi", c(0x1d5fa8)),
        BubbleColor("1a3a8a", "Lacivert", c(0x1a3a8a)),
        BubbleColor("6d3fc0", "Mor", c(0x6d3fc0)),
        BubbleColor("c2347f", "Pembe", c(0xc2347f)),
        BubbleColor("a3283d", "Bordo", c(0xa3283d)),
        BubbleColor("d32f2f", "Kırmızı", c(0xd32f2f)),
        BubbleColor("b5483a", "Kiremit", c(0xb5483a)),
        BubbleColor("c2570f", "Turuncu", c(0xc2570f)),
        BubbleColor("b8860b", "Altın", c(0xb8860b)),
        BubbleColor("8a5a3a", "Kahve", c(0x8a5a3a)),
        BubbleColor("4b6a8a", "Çelik", c(0x4b6a8a)),
        BubbleColor("4b5563", "Gri", c(0x4b5563))
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)

    /** Kayıtlı balon rengi; eski sürümde balon rengi temaya bağlıydı, onu da korur */
    fun savedOutId(ctx: Context, chatId: String): String {
        (prefs(ctx).getString("out_$chatId", null) ?: prefs(ctx).getString("out_all", null))?.let { return if (it == "default" || it == "1f6f5c") "default" else it }
        val legacy = all.firstOrNull { it.id == savedId(ctx, chatId) }?.out ?: return "default"
        return bubbleColors.firstOrNull { it.color == legacy }?.id ?: "default"
    }

    fun doodleOn(ctx: Context, chatId: String): Boolean = prefs(ctx).getBoolean("doodle_$chatId", prefs(ctx).getBoolean("doodle_all", true))

    /** Arka plan parlaklığı: 1 = olduğu gibi, altı koyulaşır, üstü açılır */
    fun bgBright(ctx: Context, chatId: String): Float = prefs(ctx).getFloat("bright_$chatId", prefs(ctx).getFloat("bright_all", 1f))

    fun setBgBright(ctx: Context, chatId: String, v: Float) {
        prefs(ctx).edit().putFloat("bright_$chatId", v).apply()
    }

    /** Açık temada arka plan ışığı (en çok %100, en az %60) ayrı kaydedilir */
    fun bgBrightLight(ctx: Context, chatId: String): Float = prefs(ctx).getFloat("brightl_$chatId", prefs(ctx).getFloat("brightl_all", 1f)).coerceIn(0.6f, 1f)

    fun setBgBrightLight(ctx: Context, chatId: String, v: Float) {
        prefs(ctx).edit().putFloat("brightl_$chatId", v).apply()
    }

    fun setDoodle(ctx: Context, chatId: String, on: Boolean) {
        prefs(ctx).edit().putBoolean("doodle_$chatId", on).apply()
    }

    /** Seçilen temayı tüm sohbetlere uygular: genel değerler yazılır, sohbete özel kayıtlar silinir */
    fun applyToAll(ctx: Context, chatId: String, bg: String, out: String, doodle: Boolean, bright: Float, brightLight: Float) {
        val ed = prefs(ctx).edit()
        for (k in prefs(ctx).all.keys.toList()) {
            if (k.startsWith("theme_") || k.startsWith("out_") || k.startsWith("doodle_") || k.startsWith("bright_") || k.startsWith("brightl_")) ed.remove(k)
        }
        ed.putString("theme_all", bg).putString("out_all", out).putBoolean("doodle_all", doodle)
            .putFloat("bright_all", bright).putFloat("brightl_all", brightLight).apply()
        if (bg == "custom") try { customFile(ctx, chatId).copyTo(customFile(ctx, "_all"), overwrite = true) } catch (e: Throwable) {}
    }

    fun setOut(ctx: Context, chatId: String, id: String) {
        prefs(ctx).edit().putString("out_$chatId", id).apply()
    }

    fun hasCustom(ctx: Context, chatId: String) = customFile(ctx, chatId).exists()

    fun loadCustom(ctx: Context, chatId: String): ImageBitmap? =
        try {
            val f = customFile(ctx, chatId).takeIf { it.exists() } ?: customFile(ctx, "_all")
            BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap()
        } catch (e: Throwable) { null }

    fun savedId(ctx: Context, chatId: String): String =
        (prefs(ctx).getString("theme_$chatId", null) ?: prefs(ctx).getString("theme_all", null) ?: "amoled").let { if (it == "default") "amoled" else it }

    fun set(ctx: Context, chatId: String, id: String) {
        prefs(ctx).edit().putString("theme_$chatId", if (id == "default") "amoled" else id).apply()
    }

    private fun customFile(ctx: Context, chatId: String) =
        File(ctx.filesDir, "theme_" + chatId.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".jpg")

    fun resolve(ctx: Context, chatId: String): ResolvedTheme {
        val id0 = savedId(ctx, chatId)
        // Minimal temaları koyu / açık moda göre eşleşir (mnd↔mnl)
        val id = if (id0.startsWith("mn") && id0.length == 4) (if (AuraUi.light) "mnl" else "mnd") + id0.substring(3) else id0
        val outId = savedOutId(ctx, chatId)
        val out = bubbleColors.firstOrNull { it.id == outId }?.color ?: ThemeDefaultOut
        val dd = doodleOn(ctx, chatId)
        // açık / sistem(açık) temada arka plan ışığı hep %100
        val br = if (AuraUi.light) bgBrightLight(ctx, chatId) else bgBright(ctx, chatId)
        if (id == "custom") {
            val bmp = loadCustom(ctx, chatId)
            if (bmp != null) return ResolvedTheme("custom", null, bmp, out, true, br)
        }
        // Varsayılan (Kömür): açık / sistem(açık) temada krem, koyuda siyah arka plan
        val t = all.firstOrNull { it.id == id && it.id != "default" && !(it.id == "amoled" && AuraUi.light) }
        return if (t != null) ResolvedTheme(t.id, t.stops, null, out, dd, br)
        else ResolvedTheme("default", null, null, out, dd, br)
    }

    fun resolveBuiltIn(t: ChatTheme): ResolvedTheme =
        if (t.id == "default" || (t.id == "amoled" && AuraUi.light)) ResolvedTheme("default", null, null, ThemeDefaultOut)
        else ResolvedTheme(t.id, t.stops, null, t.out ?: ThemeDefaultOut)

    /** Galeriden seçilen resmi 9:16 ortadan kırpıp (540x960) kaydeder */
    suspend fun saveCustom(ctx: Context, chatId: String, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val cr = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 1080 && bounds.outHeight / (sample * 2) >= 1920) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return@withContext false
            val orientation = try {
                cr.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (e: Throwable) { ExifInterface.ORIENTATION_NORMAL }
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val bmp = if (deg != 0f) {
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, Matrix().apply { postRotate(deg) }, true)
            } else decoded
            val target = 9f / 16f
            val ratio = bmp.width.toFloat() / bmp.height
            var cw = bmp.width
            var ch = bmp.height
            if (ratio > target) cw = (bmp.height * target).toInt() else ch = (bmp.width / target).toInt()
            val cropped = Bitmap.createBitmap(bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, max(1, cw), max(1, ch))
            val scaled = Bitmap.createScaledBitmap(cropped, 540, 960, true)
            FileOutputStream(customFile(ctx, chatId)).use { scaled.compress(Bitmap.CompressFormat.JPEG, 70, it) }
            true
        } catch (e: Throwable) {
            false
        }
    }
}

/** Sohbet arka planı: gradyan, özel resim ya da varsayılan renk (+ isteğe bağlı ikon deseni) */
fun Modifier.themeBackground(t: ResolvedTheme): Modifier =
    if (!t.doodle || t.image != null) this.drawBehind { drawThemeBase(t, null, Color.Transparent) }
    else this.composed {
        val ctx = androidx.compose.ui.platform.LocalContext.current
        val mask = remember {
            try { BitmapFactory.decodeResource(ctx.resources, com.aurachat.app.R.drawable.doodle_pattern)?.asImageBitmap() } catch (e: Throwable) { null }
        }
        val col = doodleColor(t)
        this.drawBehind { drawThemeBase(t, mask, col) }
    }

/** Çiziktirme temasının ana rengi (id "z"+hex), değilse null */
private fun zBase(t: ResolvedTheme): Color? =
    if (t.id.startsWith("z") && t.id.length == 7) t.id.substring(1).toLongOrNull(16)?.let { Color(0xFF000000 or it) } else null

/** Açık temada çiziktirme zemini: rengin soluk tonu; WhatsApp gibi üst çubuk ve durum çubuğu da bununla hafifçe boyanır */
fun themeBarTint(t: ResolvedTheme): Color? {
    // çiziktirme: ana rengin soluk tonu
    zBase(t)?.let { if (AuraUi.light) return paleTint(it, 0.935f) }
    // diğer temalar: duvar kağıdının en üstteki rengine en yakın ton
    val top: Color = when {
        t.image != null -> topAverage(t.image)
        t.stops != null -> t.stops.first().second
        else -> return null
    }
    val white = Color.White; val black = Color.Black
    return if (AuraUi.light) {
        val m = androidx.compose.ui.graphics.lerp(top, white, 0.86f)
        m
    } else androidx.compose.ui.graphics.lerp(top, black, 0.80f)
}

/** Resmin üst %8'lik şeridinin ortalama rengi */
private fun topAverage(img: ImageBitmap): Color {
    return try {
        val h = (img.height * 0.08f).toInt().coerceAtLeast(1)
        val px = IntArray(img.width * h)
        img.readPixels(px, 0, 0, img.width, h)
        var r = 0L; var g = 0L; var b = 0L
        val step = 7
        var n = 0
        var i = 0
        while (i < px.size) { val c = px[i]; r += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255; n++; i += step }
        if (n == 0) Color.Gray else Color(r.toInt() / n, g.toInt() / n, b.toInt() / n)
    } catch (e: Throwable) { Color.Gray }
}

private fun themeLightBg(t: ResolvedTheme): Color? {
    if (!AuraUi.light) return null
    val b = zBase(t) ?: return null
    return paleTint(b, 0.895f)
}

/** Sohbet ekranının üst çubuk boyası (tema yoksa normal) */
object ChatBar {
    private val st = androidx.compose.runtime.mutableStateOf<Color?>(null)
    var tint: Color?
        get() = st.value
        set(v) { st.value = v }
}

private fun doodleColor(t: ResolvedTheme): Color =
    if (AuraUi.light && zBase(t) != null) {
        zBase(t)!!.copy(alpha = 0.30f)
    } else if (t.id.startsWith("z") && t.id.length == 7) {
        val v = t.id.substring(1).toLongOrNull(16) ?: 0x888888L
        // renk kutusu: desen, rengin açılmış hâliyle yumuşakça karışır (WhatsApp'taki gibi)
        val r = ((v shr 16) and 255) / 255f; val g = ((v shr 8) and 255) / 255f; val b = (v and 255) / 255f
        Color(r * 0.6f + 0.4f, g * 0.6f + 0.4f, b * 0.6f + 0.4f, 0.26f)
    } else if (t.stops == null && AuraUi.light) Color(0xCCCFC6B2) else Color(0x30FFFFFF)

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawThemeBase(t: ResolvedTheme, mask: ImageBitmap?, col: Color) {
    val img = t.image
    val stops = t.stops
    if (img != null) {
        val w = size.width
        val h = size.height
        val scale = max(w / img.width, h / img.height)
        val srcW = (w / scale).toInt().coerceIn(1, img.width)
        val srcH = (h / scale).toInt().coerceIn(1, img.height)
        drawImage(
            img,
            srcOffset = IntOffset((img.width - srcW) / 2, (img.height - srcH) / 2),
            srcSize = IntSize(srcW, srcH),
            dstSize = IntSize(w.toInt(), h.toInt())
        )
    } else if (themeLightBg(t) != null) {
        drawRect(themeLightBg(t)!!)
        if (mask != null) drawDoodle(mask, col)
    } else if (stops != null) {
        drawRect(Brush.linearGradient(*stops.toTypedArray(), start = Offset.Zero, end = Offset(size.width * 0.36f, size.height)))
        if (mask != null) drawDoodle(mask, col)
    } else {
        // Varsayılan duvar kağıdı: açık temada WhatsApp gibi krem, koyuda siyah
        drawRect(if (AuraUi.light) Color(0xFFEFEAE2) else AuraChatBg)
        if (mask != null) drawDoodle(mask, col)
    }
    // arka plan parlaklığı (tema sayfasındaki çubuk): koyulaştır ya da aç
    if (t.bright < 0.99f) drawRect(Color.Black.copy(alpha = ((1f - t.bright)).coerceIn(0f, 0.8f)))
    else if (t.bright > 1.01f) drawRect(Color.White.copy(alpha = ((t.bright - 1f) * 0.5f).coerceIn(0f, 0.4f)))
}

/** Desen maskesi: genişliğe sığdırılır, dikeyde tekrarlanır, renk verilen tonla boyanır */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawDoodle(mask: ImageBitmap, col: Color) {
    val w = size.width.toInt().coerceAtLeast(1)
    val tileH = (w.toFloat() * mask.height / mask.width).toInt().coerceAtLeast(1)
    val tint = androidx.compose.ui.graphics.ColorFilter.tint(col, androidx.compose.ui.graphics.BlendMode.SrcIn)
    var y = 0
    while (y < size.height) {
        drawImage(mask, srcOffset = IntOffset.Zero, srcSize = IntSize(mask.width, mask.height), dstOffset = IntOffset(0, y), dstSize = IntSize(w, tileH), colorFilter = tint)
        y += tileH
    }
}

/** Desen karosu: elle çizilmiş çizgi şekiller (ikon kütüphanesi gerekmez), konum ve açı karışık, dikişsiz tekrarlanır */
private fun buildDoodleTile(color: Color, density: androidx.compose.ui.unit.Density, dir: androidx.compose.ui.unit.LayoutDirection): ImageBitmap {
    val d = density.density
    val cell = 52f * d
    val n = 7
    val side = (cell * n).toInt()
    val bmp = ImageBitmap(side, side)
    val canvas = androidx.compose.ui.graphics.Canvas(bmp)
    val st = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f * d, cap = androidx.compose.ui.graphics.StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
    androidx.compose.ui.graphics.drawscope.CanvasDrawScope().draw(density, dir, canvas, androidx.compose.ui.geometry.Size(side.toFloat(), side.toFloat())) {
        for (j in 0 until n) for (i in 0 until n) {
            val h = (i * 73856093) xor (j * 19349663) xor 0x5bd1e995
            val k = ((h ushr 3) and 0x7fffffff) % 12
            val jx = (((h ushr 8) and 15) / 15f - 0.5f) * cell * 0.45f
            val jy = (((h ushr 12) and 15) / 15f - 0.5f) * cell * 0.45f
            val deg = (((h ushr 16) and 63) - 32).toFloat()
            val r = (8f + ((h ushr 22) and 3)) * d
            val cx = i * cell + cell / 2 + jx + (if (j % 2 == 1) cell / 2 else 0f)
            val cy = j * cell + cell / 2 + jy
            for (ox in intArrayOf(-side, 0, side)) for (oy in intArrayOf(-side, 0, side)) {
                val x = cx + ox
                val y = cy + oy
                if (x < -r * 2 || y < -r * 2 || x > side + r * 2 || y > side + r * 2) continue
                withTransform({ translate(x, y); rotate(deg, pivot = Offset.Zero) }) {
                    drawDoodleShape(k, r, color, st)
                }
            }
        }
    }
    return bmp
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawDoodleShape(k: Int, r: Float, color: Color, st: androidx.compose.ui.graphics.drawscope.Stroke) {
    val p = androidx.compose.ui.graphics.Path()
    when (k) {
        0 -> { // konuşma balonu
            p.addRoundRect(androidx.compose.ui.geometry.RoundRect(-r, -r * 0.8f, r, r * 0.55f, androidx.compose.ui.geometry.CornerRadius(r * 0.4f)))
            p.moveTo(-r * 0.4f, r * 0.55f); p.lineTo(-r * 0.6f, r * 1.0f); p.lineTo(0f, r * 0.55f)
        }
        1 -> { // kalp
            p.moveTo(0f, r * 0.9f)
            p.cubicTo(-r * 1.4f, -r * 0.1f, -r * 0.7f, -r * 1.0f, 0f, -r * 0.35f)
            p.cubicTo(r * 0.7f, -r * 1.0f, r * 1.4f, -r * 0.1f, 0f, r * 0.9f)
        }
        2 -> { // yıldız
            for (a in 0 until 10) {
                val rad = if (a % 2 == 0) r else r * 0.45f
                val t = (-90.0 + a * 36.0) * Math.PI / 180.0
                val px = (rad * Math.cos(t)).toFloat(); val py = (rad * Math.sin(t)).toFloat()
                if (a == 0) p.moveTo(px, py) else p.lineTo(px, py)
            }
            p.close()
        }
        3 -> p.addOval(androidx.compose.ui.geometry.Rect(-r * 0.8f, -r * 0.8f, r * 0.8f, r * 0.8f))
        4 -> { // artı
            p.moveTo(-r * 0.8f, 0f); p.lineTo(r * 0.8f, 0f); p.moveTo(0f, -r * 0.8f); p.lineTo(0f, r * 0.8f)
        }
        5 -> { // dalga
            p.moveTo(-r, 0f)
            p.cubicTo(-r * 0.6f, -r * 0.9f, -r * 0.2f, -r * 0.9f, 0f, 0f)
            p.cubicTo(r * 0.2f, r * 0.9f, r * 0.6f, r * 0.9f, r, 0f)
        }
        6 -> { // nota
            p.moveTo(r * 0.5f, -r); p.lineTo(r * 0.5f, r * 0.55f)
            p.addOval(androidx.compose.ui.geometry.Rect(-r * 0.2f, r * 0.2f, r * 0.5f, r * 0.9f))
            p.moveTo(r * 0.5f, -r); p.lineTo(r * 1.0f, -r * 0.5f)
        }
        7 -> { // bulut
            p.moveTo(-r * 0.8f, r * 0.5f)
            p.cubicTo(-r * 1.4f, r * 0.5f, -r * 1.2f, -r * 0.4f, -r * 0.5f, -r * 0.3f)
            p.cubicTo(-r * 0.4f, -r * 1.1f, r * 0.7f, -r * 1.0f, r * 0.7f, -r * 0.2f)
            p.cubicTo(r * 1.4f, -r * 0.2f, r * 1.4f, r * 0.5f, r * 0.8f, r * 0.5f)
            p.close()
        }
        8 -> { // elmas
            p.moveTo(0f, -r); p.lineTo(r * 0.8f, 0f); p.lineTo(0f, r); p.lineTo(-r * 0.8f, 0f); p.close()
        }
        9 -> { // yaprak
            p.moveTo(-r * 0.8f, r * 0.8f)
            p.cubicTo(-r * 1.0f, -r * 0.6f, r * 0.2f, -r * 1.0f, r * 0.9f, -r * 0.9f)
            p.cubicTo(r * 1.0f, r * 0.2f, -r * 0.1f, r * 1.0f, -r * 0.8f, r * 0.8f)
            p.moveTo(-r * 0.8f, r * 0.8f); p.lineTo(r * 0.2f, -r * 0.2f)
        }
        10 -> { // güneş
            p.addOval(androidx.compose.ui.geometry.Rect(-r * 0.4f, -r * 0.4f, r * 0.4f, r * 0.4f))
            for (a in 0 until 8) {
                val t = a * Math.PI / 4
                val c = Math.cos(t).toFloat(); val s = Math.sin(t).toFloat()
                p.moveTo(c * r * 0.7f, s * r * 0.7f); p.lineTo(c * r, s * r)
            }
        }
        else -> { // üçgen
            p.moveTo(0f, -r * 0.9f); p.lineTo(r * 0.9f, r * 0.7f); p.lineTo(-r * 0.9f, r * 0.7f); p.close()
        }
    }
    drawPath(p, color, style = st)
}

package com.aurachat.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

/** Sohbet teması: arka plan (gradyan) + giden balon rengi. Kişiye özeldir, sadece bu cihazda tutulur. */
class ChatTheme(val id: String, val name: String, val stops: List<Pair<Float, Color>>?, val out: Color?)
class BubbleColor(val id: String, val name: String, val color: Color)

/** Sohbete uygulanmış hâli: gradyan, özel resim ya da varsayılan */
class ResolvedTheme(val id: String, val stops: List<Pair<Float, Color>>?, val image: ImageBitmap?, val out: Color)

val ThemeDefaultOut = Color(0xFF005C4B)
val ThemeDefaultIn = Color(0xFF212121)

private fun c(rgb: Long) = Color(0xFF000000 or rgb)
private fun grad(vararg v: Pair<Float, Color>) = v.toList()
private fun solid(col: Color) = listOf(0f to col, 1f to col)

object ChatThemes {
    val all: List<ChatTheme> = listOf(
        ChatTheme("default", "Varsayılan", null, null),
        ChatTheme("amoled", "Kömür", solid(c(0x000000)), c(0x1f6f5c)),
        ChatTheme("mavi", "Gece Mavisi", grad(0f to c(0x0a1929), 1f to c(0x12304d)), c(0x1d5fa8)),
        ChatTheme("orman", "Orman", grad(0f to c(0x0b1f14), 1f to c(0x14402a)), c(0x1f7a4d)),
        ChatTheme("okyanus", "Okyanus", grad(0f to c(0x04222b), 1f to c(0x0b5563)), c(0x118a9a)),
        ChatTheme("gunbatimi", "Gün Batımı", grad(0f to c(0x2b1020), 0.6f to c(0x5a2a3a), 1f to c(0x7a3f2a)), c(0xb5483a)),
        ChatTheme("mor", "Mor Gece", grad(0f to c(0x160b2e), 1f to c(0x3a1b6b)), c(0x6d3fc0)),
        ChatTheme("pembe", "Pembe", grad(0f to c(0x2a0f22), 1f to c(0x5a1f4a)), c(0xc2347f)),
        ChatTheme("bordo", "Bordo", grad(0f to c(0x2a0d12), 1f to c(0x5a1a26)), c(0xa3283d)),
        ChatTheme("kahve", "Kahve", grad(0f to c(0x1f1510), 1f to c(0x3d2a1f)), c(0x8a5a3a)),
        ChatTheme("celik", "Çelik", grad(0f to c(0x14171c), 1f to c(0x2a3038)), c(0x4b6a8a))
    )

    /** Giden balon renkleri (arka plandan bağımsız seçilir) */
    val bubbleColors: List<BubbleColor> = listOf(
        BubbleColor("default", "Varsayılan", ThemeDefaultOut),
        BubbleColor("1f6f5c", "Kömür Yeşili", c(0x1f6f5c)),
        BubbleColor("1f7a4d", "Orman Yeşili", c(0x1f7a4d)),
        BubbleColor("118a9a", "Turkuaz", c(0x118a9a)),
        BubbleColor("1d5fa8", "Mavi", c(0x1d5fa8)),
        BubbleColor("1a3a8a", "Lacivert", c(0x1a3a8a)),
        BubbleColor("6d3fc0", "Mor", c(0x6d3fc0)),
        BubbleColor("c2347f", "Pembe", c(0xc2347f)),
        BubbleColor("a3283d", "Bordo", c(0xa3283d)),
        BubbleColor("d32f2f", "Kırmızı", c(0xd32f2f)),
        BubbleColor("b5483a", "Kiremit", c(0xb5483a)),
        BubbleColor("c2570f", "Turuncu", c(0xc2570f)),
        BubbleColor("b8860b", "Altın", c(0xb8860b)),
        BubbleColor("8a5a3a", "Kahve", c(0x8a5a3a)),
        BubbleColor("4b6a8a", "Çelik", c(0x4b6a8a)),
        BubbleColor("4b5563", "Gri", c(0x4b5563))
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)

    /** Kayıtlı balon rengi; eski sürümde balon rengi temaya bağlıydı, onu da korur */
    fun savedOutId(ctx: Context, chatId: String): String {
        prefs(ctx).getString("out_$chatId", null)?.let { return it }
        val legacy = all.firstOrNull { it.id == savedId(ctx, chatId) }?.out ?: return "default"
        return bubbleColors.firstOrNull { it.color == legacy }?.id ?: "default"
    }

    fun setOut(ctx: Context, chatId: String, id: String) {
        prefs(ctx).edit().putString("out_$chatId", id).apply()
    }

    fun hasCustom(ctx: Context, chatId: String) = customFile(ctx, chatId).exists()

    fun loadCustom(ctx: Context, chatId: String): ImageBitmap? =
        try { BitmapFactory.decodeFile(customFile(ctx, chatId).absolutePath)?.asImageBitmap() } catch (e: Throwable) { null }

    fun savedId(ctx: Context, chatId: String): String = prefs(ctx).getString("theme_$chatId", "default") ?: "default"

    fun set(ctx: Context, chatId: String, id: String) {
        prefs(ctx).edit().apply { if (id == "default") remove("theme_$chatId") else putString("theme_$chatId", id) }.apply()
    }

    private fun customFile(ctx: Context, chatId: String) =
        File(ctx.filesDir, "theme_" + chatId.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".jpg")

    fun resolve(ctx: Context, chatId: String): ResolvedTheme {
        val id = savedId(ctx, chatId)
        val outId = savedOutId(ctx, chatId)
        val out = bubbleColors.firstOrNull { it.id == outId }?.color ?: ThemeDefaultOut
        if (id == "custom") {
            val bmp = loadCustom(ctx, chatId)
            if (bmp != null) return ResolvedTheme("custom", null, bmp, out)
        }
        val t = all.firstOrNull { it.id == id && it.id != "default" }
        return if (t != null) ResolvedTheme(t.id, t.stops, null, out)
        else ResolvedTheme("default", null, null, out)
    }

    fun resolveBuiltIn(t: ChatTheme): ResolvedTheme =
        if (t.id == "default") ResolvedTheme("default", null, null, ThemeDefaultOut)
        else ResolvedTheme(t.id, t.stops, null, t.out ?: ThemeDefaultOut)

    /** Galeriden seçilen resmi 9:16 ortadan kırpıp (540x960) kaydeder */
    suspend fun saveCustom(ctx: Context, chatId: String, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val cr = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 1080 && bounds.outHeight / (sample * 2) >= 1920) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return@withContext false
            val orientation = try {
                cr.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (e: Throwable) { ExifInterface.ORIENTATION_NORMAL }
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val bmp = if (deg != 0f) {
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, Matrix().apply { postRotate(deg) }, true)
            } else decoded
            val target = 9f / 16f
            val ratio = bmp.width.toFloat() / bmp.height
            var cw = bmp.width
            var ch = bmp.height
            if (ratio > target) cw = (bmp.height * target).toInt() else ch = (bmp.width / target).toInt()
            val cropped = Bitmap.createBitmap(bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, max(1, cw), max(1, ch))
            val scaled = Bitmap.createScaledBitmap(cropped, 540, 960, true)
            FileOutputStream(customFile(ctx, chatId)).use { scaled.compress(Bitmap.CompressFormat.JPEG, 70, it) }
            true
        } catch (e: Throwable) {
            false
        }
    }
}

/** Sohbet arka planı: gradyan, özel resim ya da varsayılan renk */
fun Modifier.themeBackground(t: ResolvedTheme): Modifier = this.drawBehind {
    val img = t.image
    val stops = t.stops
    if (img != null) {
        val w = size.width
        val h = size.height
        val scale = max(w / img.width, h / img.height)
        val srcW = (w / scale).toInt().coerceIn(1, img.width)
        val srcH = (h / scale).toInt().coerceIn(1, img.height)
        drawImage(
            img,
            srcOffset = IntOffset((img.width - srcW) / 2, (img.height - srcH) / 2),
            srcSize = IntSize(srcW, srcH),
            dstSize = IntSize(w.toInt(), h.toInt()),
            colorFilter = if (AuraUi.light) AuraInvertFilter else null
        )
    } else if (stops != null) {
        drawRect(Brush.linearGradient(*stops.toTypedArray(), start = Offset.Zero, end = Offset(size.width * 0.36f, size.height)), colorFilter = if (AuraUi.light) AuraInvertFilter else null)
    } else {
        drawRect(AuraChatBg)
    }
}

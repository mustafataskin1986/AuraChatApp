package com.aurachat.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntSize
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

/** Sohbet teması: arka plan (gradyan) + giden balon rengi. Kişiye özeldir, sadece bu cihazda tutulur. */
class ChatTheme(val id: String, val name: String, val stops: List<Pair<Float, Color>>?, val out: Color?)
class BubbleColor(val id: String, val name: String, val color: Color)

/** Sohbete uygulanmış hâli: gradyan, özel resim ya da varsayılan */
class ResolvedTheme(val id: String, val stops: List<Pair<Float, Color>>?, val image: ImageBitmap?, val out: Color, val doodle: Boolean = true, val bright: Float = 1f)

val ThemeDefaultOut = Color(0xFF005C4B)
val ThemeDefaultIn = Color(0xFF212121)

private fun c(rgb: Long) = Color(0xFF000000 or rgb)
private fun grad(vararg v: Pair<Float, Color>) = v.toList()
private fun solid(col: Color) = listOf(0f to col, 1f to col)

object ChatThemes {
    val all: List<ChatTheme> = listOf(
        ChatTheme("default", "Varsayılan", null, null),
        ChatTheme("amoled", "Kömür", solid(c(0x000000)), c(0x1f6f5c)),
        ChatTheme("mavi", "Gece Mavisi", grad(0f to c(0x0a1929), 1f to c(0x12304d)), c(0x1d5fa8)),
        ChatTheme("orman", "Orman", grad(0f to c(0x0b1f14), 1f to c(0x14402a)), c(0x1f7a4d)),
        ChatTheme("okyanus", "Okyanus", grad(0f to c(0x04222b), 1f to c(0x0b5563)), c(0x118a9a)),
        ChatTheme("gunbatimi", "Gün Batımı", grad(0f to c(0x2b1020), 0.6f to c(0x5a2a3a), 1f to c(0x7a3f2a)), c(0xb5483a)),
        ChatTheme("mor", "Mor Gece", grad(0f to c(0x160b2e), 1f to c(0x3a1b6b)), c(0x6d3fc0)),
        ChatTheme("pembe", "Pembe", grad(0f to c(0x2a0f22), 1f to c(0x5a1f4a)), c(0xc2347f)),
        ChatTheme("bordo", "Bordo", grad(0f to c(0x2a0d12), 1f to c(0x5a1a26)), c(0xa3283d)),
        ChatTheme("kahve", "Kahve", grad(0f to c(0x1f1510), 1f to c(0x3d2a1f)), c(0x8a5a3a)),
        ChatTheme("celik", "Çelik", grad(0f to c(0x14171c), 1f to c(0x2a3038)), c(0x4b6a8a))
    )

    /** Giden balon renkleri (arka plandan bağımsız seçilir) */
    val bubbleColors: List<BubbleColor> = listOf(
        BubbleColor("default", "Varsayılan", ThemeDefaultOut),
        BubbleColor("1f6f5c", "Kömür Yeşili", c(0x1f6f5c)),
        BubbleColor("1f7a4d", "Orman Yeşili", c(0x1f7a4d)),
        BubbleColor("118a9a", "Turkuaz", c(0x118a9a)),
        BubbleColor("1d5fa8", "Mavi", c(0x1d5fa8)),
        BubbleColor("1a3a8a", "Lacivert", c(0x1a3a8a)),
        BubbleColor("6d3fc0", "Mor", c(0x6d3fc0)),
        BubbleColor("c2347f", "Pembe", c(0xc2347f)),
        BubbleColor("a3283d", "Bordo", c(0xa3283d)),
        BubbleColor("d32f2f", "Kırmızı", c(0xd32f2f)),
        BubbleColor("b5483a", "Kiremit", c(0xb5483a)),
        BubbleColor("c2570f", "Turuncu", c(0xc2570f)),
        BubbleColor("b8860b", "Altın", c(0xb8860b)),
        BubbleColor("8a5a3a", "Kahve", c(0x8a5a3a)),
        BubbleColor("4b6a8a", "Çelik", c(0x4b6a8a)),
        BubbleColor("4b5563", "Gri", c(0x4b5563))
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)

    /** Kayıtlı balon rengi; eski sürümde balon rengi temaya bağlıydı, onu da korur */
    fun savedOutId(ctx: Context, chatId: String): String {
        prefs(ctx).getString("out_$chatId", null)?.let { return if (it == "default") "1f6f5c" else it }
        val legacy = all.firstOrNull { it.id == savedId(ctx, chatId) }?.out ?: return "1f6f5c"
        return bubbleColors.firstOrNull { it.color == legacy }?.id ?: "1f6f5c"
    }

    fun doodleOn(ctx: Context, chatId: String): Boolean = prefs(ctx).getBoolean("doodle_$chatId", true)

    /** Arka plan parlaklığı: 1 = olduğu gibi, altı koyulaşır, üstü açılır */
    fun bgBright(ctx: Context, chatId: String): Float = prefs(ctx).getFloat("bright_$chatId", 1f)

    fun setBgBright(ctx: Context, chatId: String, v: Float) {
        prefs(ctx).edit().apply { if (kotlin.math.abs(v - 1f) < 0.01f) remove("bright_$chatId") else putFloat("bright_$chatId", v) }.apply()
    }

    fun setDoodle(ctx: Context, chatId: String, on: Boolean) {
        prefs(ctx).edit().apply { if (on) remove("doodle_$chatId") else putBoolean("doodle_$chatId", false) }.apply()
    }

    fun setOut(ctx: Context, chatId: String, id: String) {
        prefs(ctx).edit().putString("out_$chatId", id).apply()
    }

    fun hasCustom(ctx: Context, chatId: String) = customFile(ctx, chatId).exists()

    fun loadCustom(ctx: Context, chatId: String): ImageBitmap? =
        try { BitmapFactory.decodeFile(customFile(ctx, chatId).absolutePath)?.asImageBitmap() } catch (e: Throwable) { null }

    fun savedId(ctx: Context, chatId: String): String = (prefs(ctx).getString("theme_$chatId", "amoled") ?: "amoled").let { if (it == "default") "amoled" else it }

    fun set(ctx: Context, chatId: String, id: String) {
        prefs(ctx).edit().apply { if (id == "default" || id == "amoled") remove("theme_$chatId") else putString("theme_$chatId", id) }.apply()
    }

    private fun customFile(ctx: Context, chatId: String) =
        File(ctx.filesDir, "theme_" + chatId.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".jpg")

    fun resolve(ctx: Context, chatId: String): ResolvedTheme {
        val id = savedId(ctx, chatId)
        val outId = savedOutId(ctx, chatId)
        val out = bubbleColors.firstOrNull { it.id == outId }?.color ?: ThemeDefaultOut
        val dd = doodleOn(ctx, chatId)
        val br = bgBright(ctx, chatId)
        if (id == "custom") {
            val bmp = loadCustom(ctx, chatId)
            if (bmp != null) return ResolvedTheme("custom", null, bmp, out, true, br)
        }
        val t = all.firstOrNull { it.id == id && it.id != "default" }
        return if (t != null) ResolvedTheme(t.id, t.stops, null, out, dd, br)
        else ResolvedTheme("default", null, null, out, dd, br)
    }

    fun resolveBuiltIn(t: ChatTheme): ResolvedTheme =
        if (t.id == "default") ResolvedTheme("default", null, null, ThemeDefaultOut)
        else ResolvedTheme(t.id, t.stops, null, t.out ?: ThemeDefaultOut)

    /** Galeriden seçilen resmi 9:16 ortadan kırpıp (540x960) kaydeder */
    suspend fun saveCustom(ctx: Context, chatId: String, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val cr = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 1080 && bounds.outHeight / (sample * 2) >= 1920) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return@withContext false
            val orientation = try {
                cr.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (e: Throwable) { ExifInterface.ORIENTATION_NORMAL }
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val bmp = if (deg != 0f) {
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, Matrix().apply { postRotate(deg) }, true)
            } else decoded
            val target = 9f / 16f
            val ratio = bmp.width.toFloat() / bmp.height
            var cw = bmp.width
            var ch = bmp.height
            if (ratio > target) cw = (bmp.height * target).toInt() else ch = (bmp.width / target).toInt()
            val cropped = Bitmap.createBitmap(bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, max(1, cw), max(1, ch))
            val scaled = Bitmap.createScaledBitmap(cropped, 540, 960, true)
            FileOutputStream(customFile(ctx, chatId)).use { scaled.compress(Bitmap.CompressFormat.JPEG, 70, it) }
            true
        } catch (e: Throwable) {
            false
        }
    }
}

/** Sohbet arka planı: gradyan, özel resim ya da varsayılan renk */
fun Modifier.themeBackground(t: ResolvedTheme): Modifier = this.drawBehind {
    val img = t.image
    val stops = t.stops
    if (img != null) {
        val w = size.width
        val h = size.height
        val scale = max(w / img.width, h / img.height)
        val srcW = (w / scale).toInt().coerceIn(1, img.width)
        val srcH = (h / scale).toInt().coerceIn(1, img.height)
        drawImage(
            img,
            srcOffset = IntOffset((img.width - srcW) / 2, (img.height - srcH) / 2),
            srcSize = IntSize(srcW, srcH),
            dstSize = IntSize(w.toInt(), h.toInt()),
            colorFilter = if (AuraUi.light) AuraInvertFilter else null
        )
    } else if (stops != null) {
        drawRect(Brush.linearGradient(*stops.toTypedArray(), start = Offset.Zero, end = Offset(size.width * 0.36f, size.height)), colorFilter = if (AuraUi.light) AuraInvertFilter else null)
        if (t.doodle) drawDoodles(auraWinColor(Color(0x16FFFFFF)))
    } else {
        val light = AuraUi.light
        // aydınlıkta filtre tersleyeceği için önceden çevrilmiş krem renk çiziyoruz
        drawRect(if (light) auraWinColor(Color(0xFFEFE6D6)) else AuraChatBg)
        if (t.doodle) drawDoodles(if (light) auraWinColor(Color(0xFFD8CCB6)) else Color(0x16FFFFFF))
    }
    // arka plan parlaklığı (tema sayfasındaki çubuk): koyulaştır ya da aç
    if (t.bright < 0.99f) drawRect(Color.Black.copy(alpha = ((1f - t.bright)).coerceIn(0f, 0.8f)))
    else if (t.bright > 1.01f) drawRect(Color.White.copy(alpha = ((t.bright - 1f) * 0.5f).coerceIn(0f, 0.4f)))
}

/** Bol küçük çizgi-desen (daire, yıldız, artı, dalga, kalp) ile WhatsApp tarzı arka plan dokusu */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawDoodles(color: Color) {
    val cell = 58.dp.toPx()
    val st = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.4.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
    val cols = (size.width / cell).toInt() + 2
    val rows = (size.height / cell).toInt() + 2
    val r = 7.dp.toPx()
    for (j in 0 until rows) for (i in 0 until cols) {
        val h = (i * 73856093) xor (j * 19349663)
        val k = ((h ushr 3) and 0x7fffffff) % 6
        val ox = ((h ushr 8) and 15) / 15f * cell * 0.3f
        val oy = ((h ushr 12) and 15) / 15f * cell * 0.3f
        val cx = i * cell + cell / 2 + ox + (if (j % 2 == 1) cell / 2 else 0f) - cell / 2
        val cy = j * cell + cell / 2 + oy
        val c = Offset(cx, cy)
        val p = androidx.compose.ui.graphics.Path()
        when (k) {
            0 -> p.addOval(androidx.compose.ui.geometry.Rect(c, r))
            1 -> { for (a in 0 until 5) { val t1 = -Math.PI / 2 + a * 2 * Math.PI / 5; val t2 = t1 + Math.PI * 4 / 5
                    val x1 = cx + r * Math.cos(t1).toFloat(); val y1 = cy + r * Math.sin(t1).toFloat()
                    val x2 = cx + r * Math.cos(t2).toFloat(); val y2 = cy + r * Math.sin(t2).toFloat()
                    if (a == 0) p.moveTo(x1, y1); p.lineTo(x2, y2) }; p.close() }
            2 -> { p.moveTo(cx - r, cy); p.lineTo(cx + r, cy); p.moveTo(cx, cy - r); p.lineTo(cx, cy + r) }
            3 -> { p.moveTo(cx - r * 1.4f, cy); p.cubicTo(cx - r, cy - r, cx - r / 3, cy - r, cx, cy); p.cubicTo(cx + r / 3, cy + r, cx + r, cy + r, cx + r * 1.4f, cy) }
            4 -> { p.moveTo(cx, cy + r); p.cubicTo(cx - r * 1.6f, cy - r * 0.2f, cx - r * 0.7f, cy - r * 1.3f, cx, cy - r * 0.35f)
                   p.cubicTo(cx + r * 0.7f, cy - r * 1.3f, cx + r * 1.6f, cy - r * 0.2f, cx, cy + r) }
            else -> p.addRoundRect(androidx.compose.ui.geometry.RoundRect(androidx.compose.ui.geometry.Rect(c, r * 0.8f), androidx.compose.ui.geometry.CornerRadius(3.dp.toPx())))
        }
        drawPath(p, color, style = st)
    }
}

package com.aurachat.app.ui

import androidx.compose.ui.draw.clipToBounds
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntSize
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

/** Sohbet teması: arka plan (gradyan) + giden balon rengi. Kişiye özeldir, sadece bu cihazda tutulur. */
class ChatTheme(val id: String, val name: String, val stops: List<Pair<Float, Color>>?, val out: Color?)
class BubbleColor(val id: String, val name: String, val color: Color)

/** Sohbete uygulanmış hâli: gradyan, özel resim ya da varsayılan */
class ResolvedTheme(val id: String, val stops: List<Pair<Float, Color>>?, val image: ImageBitmap?, private val outRaw: Color, val doodle: Boolean = true, val bright: Float = 1f,
    /** Özel resim ayarı: yakınlaştırma (1+) ve kaydırma (-1..1, izin verilen aralığa oranla) */
    val zoom: Float = 1f, val panX: Float = 0f, val panY: Float = 0f) {
    val isDefaultOut: Boolean = outRaw == ThemeDefaultOut
    val out: Color get() = accentOf(outRaw)
    val bubble: Color get() = bubbleOf(outRaw)
    /** Gelen balon rengi: açık Minimal temada WhatsApp gibi açık gri; diğerlerinde varsayılan */
    val theirs: Color? get() = if (AuraUi.lightReal && id.startsWith("mnl")) Color(0xFFEEEEEE) else null
}

val ThemeDefaultOut = Color(0xFF0D4A30)   // palette'te seçili görünen 2. renkle aynı
val ThemeDefaultIn: Color get() = auraLc(0xFF212121)

private fun c(rgb: Long) = Color(0xFF000000 or rgb)
private fun grad(vararg v: Pair<Float, Color>) = v.toList()
/** Çiziktirme zemini: renk %14 karışımla neredeyse siyaha çekilir, desen ise rengin kendisiyle boyanır */
private fun zbg(rgb: Long): Color {
    val r = ((rgb shr 16) and 255) * 0.14f; val g = ((rgb shr 8) and 255) * 0.14f; val b = (rgb and 255) * 0.14f
    return Color(0xFF000000.toInt() or (r.toInt() shl 16) or (g.toInt() shl 8) or b.toInt())
}
/** Minimal (koyu): rengin %5'i kadar tonla neredeyse siyah gri zemin */
private fun mnDark(rgb: Long): Color {
    val r = ((rgb shr 16) and 255) * 0.04f + 11; val g = ((rgb shr 8) and 255) * 0.04f + 17; val b = (rgb and 255) * 0.04f + 22
    return Color(0xFF000000.toInt() or (r.toInt() shl 16) or (g.toInt() shl 8) or b.toInt())
}
/** Minimal (açık): beyaza yakın, rengin %4'ü kadar tonlu zemin */
private fun mnLight(rgb: Long): Color {
    val r = 255 - (255 - ((rgb shr 16) and 255)) * 0.015f; val g = 255 - (255 - ((rgb shr 8) and 255)) * 0.015f; val b = 255 - (255 - (rgb and 255)) * 0.015f
    return Color(0xFF000000.toInt() or (r.toInt() shl 16) or (g.toInt() shl 8) or b.toInt())
}
private fun solid(col: Color) = listOf(0f to col, 1f to col)

object ChatThemes {
    val all: List<ChatTheme> = listOf(
        ChatTheme("default", "Varsayılan", null, null),
        ChatTheme("amoled", "Kömür", solid(c(0x000000)), c(0x1f6f5c)),
        ChatTheme("mavi", "Gece Mavisi", grad(0f to c(0x0a1929), 1f to c(0x12304d)), c(0x1d5fa8)),
        ChatTheme("orman", "Orman", grad(0f to c(0x0b1f14), 1f to c(0x14402a)), c(0x1f7a4d)),
        ChatTheme("okyanus", "Okyanus", grad(0f to c(0x04222b), 1f to c(0x0b5563)), c(0x118a9a)),
        ChatTheme("gunbatimi", "Gün Batımı", grad(0f to c(0x2b1020), 0.6f to c(0x5a2a3a), 1f to c(0x7a3f2a)), c(0xb5483a)),
        ChatTheme("mor", "Mor Gece", grad(0f to c(0x160b2e), 1f to c(0x3a1b6b)), c(0x6d3fc0)),
        ChatTheme("pembe", "Pembe", grad(0f to c(0x2a0f22), 1f to c(0x5a1f4a)), c(0xc2347f)),
        ChatTheme("bordo", "Bordo", grad(0f to c(0x2a0d12), 1f to c(0x5a1a26)), c(0xa3283d)),
        ChatTheme("kahve", "Kahve", grad(0f to c(0x1f1510), 1f to c(0x3d2a1f)), c(0x8a5a3a)),
        ChatTheme("celik", "Çelik", grad(0f to c(0x14171c), 1f to c(0x2a3038)), c(0x4b6a8a)),
        ChatTheme("g_col", "Çöl", grad(0f to c(0xf0a58f), 0.5f to c(0xd9795f), 1f to c(0x8a3b2e)), null),
        ChatTheme("g_orman", "Sisli Orman", grad(0f to c(0xcfe3d4), 0.5f to c(0x6a9b7c), 1f to c(0x1f4d3a)), null),
        ChatTheme("g_deniz", "Turkuaz Kıyı", grad(0f to c(0x9fe0e6), 0.5f to c(0x2ea7b8), 1f to c(0x0b4f63)), null),
        ChatTheme("g_gokyuzu", "Alacakaranlık", grad(0f to c(0x3b4cc0), 0.55f to c(0xb07cc6), 1f to c(0xf2b38b)), null),
        ChatTheme("g_dag", "Dağ Sabahı", grad(0f to c(0xb8d4ec), 0.5f to c(0x7aa3c9), 1f to c(0x34506e)), null),
        ChatTheme("g_gece", "Yıldızlı Gece", grad(0f to c(0x05070f), 0.55f to c(0x101b3a), 1f to c(0x1b2a55)), null),
        ChatTheme("g_kum", "Kum", grad(0f to c(0xf3e2c3), 0.5f to c(0xd9b98a), 1f to c(0xa77b4f)), null),
        ChatTheme("g_kar", "Kar Mavisi", grad(0f to c(0xeef4fb), 0.5f to c(0xb9cfe6), 1f to c(0x7d9bbd)), null),
        ChatTheme("c_holo", "Holografik", grad(0f to c(0xf6c1e4), 0.3f to c(0xb9d6ff), 0.55f to c(0xc9f3e1), 0.8f to c(0xf7e3b5), 1f to c(0xe1b8f5)), null),
        ChatTheme("c_aurora", "Aurora", grad(0f to c(0x041b2b), 0.45f to c(0x0b5d5a), 0.75f to c(0x2d9c7a), 1f to c(0x141a45)), null),
        ChatTheme("c_mavi", "Gökyüzü", grad(0f to c(0x2f5bea), 0.5f to c(0x7db0f5), 0.8f to c(0xcfe9ff), 1f to c(0xe6f0b8)), null),
        ChatTheme("c_gece", "Gece Yarısı", grad(0f to c(0x05090f), 0.5f to c(0x0a1b33), 0.8f to c(0x1a2f66), 1f to c(0x0b0b14)), null),
        ChatTheme("c_seker", "Şeker", grad(0f to c(0xff9ac7), 0.5f to c(0xc08cff), 1f to c(0x7fb7ff)), null),
        ChatTheme("c_alev", "Alev", grad(0f to c(0xff8a3d), 0.5f to c(0xe5383b), 1f to c(0x6a040f)), null),
        ChatTheme("z4e38b3", "Çiziktirme", solid(zbg(0x4e38b3)), null),
        ChatTheme("zd82d63", "Çiziktirme", solid(zbg(0xd82d63)), null),
        ChatTheme("z53565a", "Çiziktirme", solid(zbg(0x53565a)), null),
        ChatTheme("z126d47", "Çiziktirme", solid(zbg(0x126d47)), null),
        ChatTheme("z9e3f22", "Çiziktirme", solid(zbg(0x9e3f22)), null),
        ChatTheme("z08529e", "Çiziktirme", solid(zbg(0x08529e)), null),
        ChatTheme("z803399", "Çiziktirme", solid(zbg(0x803399)), null),
        ChatTheme("z0e5d8d", "Çiziktirme", solid(zbg(0x0e5d8d)), null),
        ChatTheme("z9b153b", "Çiziktirme", solid(zbg(0x9b153b)), null),
        ChatTheme("z5e8a27", "Çiziktirme", solid(zbg(0x5e8a27)), null),
        ChatTheme("mnd0", "Minimal", solid(mnDark(0x3b3d3e)), null),
        ChatTheme("mnd1", "Minimal", solid(mnDark(0x631026)), null),
        ChatTheme("mnd2", "Minimal", solid(mnDark(0x2c2463)), null),
        ChatTheme("mnd3", "Minimal", solid(mnDark(0x532168)), null),
        ChatTheme("mnd4", "Minimal", solid(mnDark(0x092e5c)), null),
        ChatTheme("mnd5", "Minimal", solid(mnDark(0x0d4a30)), null),
        ChatTheme("mnd6", "Minimal", solid(mnDark(0x532b20)), null),
        ChatTheme("mnd7", "Minimal", solid(mnDark(0x0c3b52)), null),
        ChatTheme("mnd8", "Minimal", solid(mnDark(0x6f1127)), null),
        ChatTheme("mnd9", "Minimal", solid(mnDark(0x3c503e)), null),
        ChatTheme("mnl0", "Minimal", solid(mnLight(0x53565a)), null),
        ChatTheme("mnl1", "Minimal", solid(mnLight(0x691b3b)), null),
        ChatTheme("mnl2", "Minimal", solid(mnLight(0x4e38b3)), null),
        ChatTheme("mnl3", "Minimal", solid(mnLight(0x803399)), null),
        ChatTheme("mnl4", "Minimal", solid(mnLight(0x08529e)), null),
        ChatTheme("mnl5", "Minimal", solid(mnLight(0x126d47)), null),
        ChatTheme("mnl6", "Minimal", solid(mnLight(0x9e3f22)), null),
        ChatTheme("mnl7", "Minimal", solid(mnLight(0x0e5d8d)), null),
        ChatTheme("mnl8", "Minimal", solid(mnLight(0x9b153b)), null),
        ChatTheme("mnl9", "Minimal", solid(mnLight(0x6f1127)), null),
        ChatTheme("s2a7b72", "Düz", solid(c(0x2d7778)), null),
        ChatTheme("s2d6a4f", "Düz", solid(c(0x336952)), null),
        ChatTheme("s1e532b", "Düz", solid(c(0x255d42)), null),
        ChatTheme("s3a6073", "Düz", solid(c(0x2f5481)), null),
        ChatTheme("s1a5b6e", "Düz", solid(c(0x1b6163)), null),
        ChatTheme("s174355", "Düz", solid(c(0x1d535f)), null),
        ChatTheme("s362a63", "Düz", solid(c(0x2c2062)), null),
        ChatTheme("s525252", "Düz", solid(c(0x525252)), null),
        ChatTheme("s5c6b39", "Düz", solid(c(0x5b683c)), null),
        ChatTheme("s807328", "Düz", solid(c(0x7b7328)), null),
        ChatTheme("s6b5a0a", "Düz", solid(c(0x615002)), null),
        ChatTheme("sb85b00", "Düz", solid(c(0xa05d02)), null),
        ChatTheme("s680c1d", "Düz", solid(c(0x5c0202)), null),
        ChatTheme("s4a0e0e", "Düz", solid(c(0x510102)), null),
        ChatTheme("s300808", "Düz", solid(c(0x490210)), null),
        ChatTheme("s42141a", "Düz", solid(c(0x390d1a)), null),
        ChatTheme("s6e2d1b", "Düz", solid(c(0x642514)), null),
        ChatTheme("s2e2528", "Düz", solid(c(0x281f20)), null),
        ChatTheme("s263d3c", "Düz", solid(c(0x203232)), null),
        ChatTheme("s1e3b4a", "Düz", solid(c(0x153a4c)), null),
        ChatTheme("s182538", "Düz", solid(c(0x162238)), null),
        ChatTheme("s3d434a", "Düz", solid(c(0x2d3236)), null),
        ChatTheme("s0e1114", "Düz", solid(c(0x0d0e10)), null),
        ChatTheme("s1c121e", "Düz", solid(c(0x130c14)), null),
        ChatTheme("s546e7a", "Düz", solid(c(0x51686e)), null),
        ChatTheme("s667009", "Düz", solid(c(0x606000)), null),
        ChatTheme("s757d42", "Düz", solid(c(0x72753c)), null)
    )

    /** Giden balon renkleri (arka plandan bağımsız seçilir) */
    val bubbleColors: List<BubbleColor> = listOf(
        BubbleColor("default", "Varsayılan", ThemeDefaultOut),
        BubbleColor("126d47", "Renk", c(0x126d47)),
        BubbleColor("0d4a30", "Renk", c(0x0d4a30)),
        BubbleColor("08529e", "Renk", c(0x08529e)),
        BubbleColor("092e5c", "Renk", c(0x092e5c)),
        BubbleColor("4e38b3", "Renk", c(0x4e38b3)),
        BubbleColor("2c2463", "Renk", c(0x2c2463)),
        BubbleColor("0e5d8d", "Renk", c(0x0e5d8d)),
        BubbleColor("0c3b52", "Renk", c(0x0c3b52)),
        BubbleColor("803399", "Renk", c(0x803399)),
        BubbleColor("532168", "Renk", c(0x532168)),
        BubbleColor("53565a", "Renk", c(0x53565a)),
        BubbleColor("3b3d3e", "Renk", c(0x3b3d3e)),
        BubbleColor("9e3f22", "Renk", c(0x9e3f22)),
        BubbleColor("532b20", "Renk", c(0x532b20)),
        BubbleColor("3c503e", "Renk", c(0x3c503e)),
        BubbleColor("29362a", "Renk", c(0x29362a)),
        BubbleColor("086b66", "Renk", c(0x086b66)),
        BubbleColor("064643", "Renk", c(0x064643)),
        BubbleColor("9b153b", "Renk", c(0x9b153b)),
        BubbleColor("631026", "Renk", c(0x631026)),
        BubbleColor("794b2a", "Renk", c(0x794b2a)),
        BubbleColor("3f2716", "Renk", c(0x3f2716)),
        BubbleColor("8d7053", "Renk", c(0x8d7053)),
        BubbleColor("43372b", "Renk", c(0x43372b)),
        BubbleColor("0a7f6f", "Renk", c(0x0a7f6f)),
        BubbleColor("065248", "Renk", c(0x065248)),
        BubbleColor("c5a300", "Renk", c(0xc5a300)),
        BubbleColor("736000", "Renk", c(0x736000)),
        BubbleColor("5e8a27", "Renk", c(0x5e8a27)),
        BubbleColor("395217", "Renk", c(0x395217)),
        BubbleColor("d82d63", "Renk", c(0xd82d63)),
        BubbleColor("691b3b", "Renk", c(0x691b3b)),
        BubbleColor("ca1236", "Renk", c(0xca1236)),
        BubbleColor("6f1127", "Renk", c(0x6f1127)),
        BubbleColor("a72917", "Renk", c(0xa72917)),
        BubbleColor("5c130b", "Renk", c(0x5c130b)),
        BubbleColor("b6862b", "Renk", c(0xb6862b)),
        BubbleColor("584b23", "Renk", c(0x584b23)),
        BubbleColor("1f7a4d", "Orman Yeşili", c(0x1f7a4d)),
        BubbleColor("118a9a", "Turkuaz", c(0x118a9a)),
        BubbleColor("1d5fa8", "Mavi", c(0x1d5fa8)),
        BubbleColor("1a3a8a", "Lacivert", c(0x1a3a8a)),
        BubbleColor("6d3fc0", "Mor", c(0x6d3fc0)),
        BubbleColor("c2347f", "Pembe", c(0xc2347f)),
        BubbleColor("a3283d", "Bordo", c(0xa3283d)),
        BubbleColor("d32f2f", "Kırmızı", c(0xd32f2f)),
        BubbleColor("b5483a", "Kiremit", c(0xb5483a)),
        BubbleColor("c2570f", "Turuncu", c(0xc2570f)),
        BubbleColor("b8860b", "Altın", c(0xb8860b)),
        BubbleColor("8a5a3a", "Kahve", c(0x8a5a3a)),
        BubbleColor("4b6a8a", "Çelik", c(0x4b6a8a)),
        BubbleColor("4b5563", "Gri", c(0x4b5563))
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)

    /** Kayıtlı balon rengi; eski sürümde balon rengi temaya bağlıydı, onu da korur */
    fun savedOutId(ctx: Context, chatId: String): String {
        (prefs(ctx).getString("out_$chatId", null) ?: prefs(ctx).getString("out_all", null))?.let { return if (it == "default" || it == "1f6f5c") "default" else it }
        val legacy = all.firstOrNull { it.id == savedId(ctx, chatId) }?.out ?: return "default"
        return bubbleColors.firstOrNull { it.color == legacy }?.id ?: "default"
    }

    fun doodleOn(ctx: Context, chatId: String): Boolean = prefs(ctx).getBoolean("doodle_$chatId", prefs(ctx).getBoolean("doodle_all", true))

    /** Arka plan parlaklığı: 1 = olduğu gibi, altı koyulaşır, üstü açılır */
    fun bgBright(ctx: Context, chatId: String): Float = prefs(ctx).getFloat("bright_$chatId", prefs(ctx).getFloat("bright_all", 1f)).coerceAtMost(1.15f)

    fun setBgBright(ctx: Context, chatId: String, v: Float) {
        prefs(ctx).edit().putFloat("bright_$chatId", v).apply()
    }

    /** Açık temada arka plan ışığı (en çok %100, en az %60) ayrı kaydedilir */
    fun bgBrightLight(ctx: Context, chatId: String): Float = prefs(ctx).getFloat("brightl_$chatId", prefs(ctx).getFloat("brightl_all", 1f)).coerceIn(0.6f, 1f)

    fun setBgBrightLight(ctx: Context, chatId: String, v: Float) {
        prefs(ctx).edit().putFloat("brightl_$chatId", v).apply()
    }

    fun setDoodle(ctx: Context, chatId: String, on: Boolean) {
        prefs(ctx).edit().putBoolean("doodle_$chatId", on).apply()
    }

    /** Seçilen temayı tüm sohbetlere uygular: genel değerler yazılır, sohbete özel kayıtlar silinir */
    fun applyToAll(ctx: Context, chatId: String, bg: String, out: String, doodle: Boolean, bright: Float, brightLight: Float) {
        val ed = prefs(ctx).edit()
        for (k in prefs(ctx).all.keys.toList()) {
            if (k.startsWith("theme_") || k.startsWith("out_") || k.startsWith("doodle_") || k.startsWith("bright_") || k.startsWith("brightl_")) ed.remove(k)
        }
        ed.putString("theme_all", bg).putString("out_all", out).putBoolean("doodle_all", doodle)
            .putFloat("bright_all", bright).putFloat("brightl_all", brightLight).apply()
        if (bg == "custom") try { customFile(ctx, chatId).copyTo(customFile(ctx, "_all"), overwrite = true) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatThemes", e) }
    }

    fun setOut(ctx: Context, chatId: String, id: String) {
        prefs(ctx).edit().putString("out_$chatId", id).apply()
    }

    /** Cihazın tam ekran boyutu (durum ve gezinme çubukları dahil) */
    private fun screenSize(ctx: Context): Pair<Int, Int> = try {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val dm = android.util.DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }
    } catch (e: Throwable) { Pair(1080, 1920) }

    fun hasCustom(ctx: Context, chatId: String) = customFile(ctx, chatId).exists()

    fun loadCustom(ctx: Context, chatId: String): ImageBitmap? =
        try {
            val f = customFile(ctx, chatId).takeIf { it.exists() } ?: customFile(ctx, "_all")
            BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap()
        } catch (e: Throwable) { null }

    fun savedId(ctx: Context, chatId: String): String =
        (prefs(ctx).getString("theme_$chatId", null) ?: prefs(ctx).getString("theme_all", null) ?: "amoled").let { if (it == "default") "amoled" else it }

    /** Ayarlar'daki varsayılan (tüm sohbetler) tema değerleri; sıfırlamada kullanılır */
    fun allBg(ctx: Context): String = (prefs(ctx).getString("theme_all", null) ?: "amoled").let { if (it == "default") "amoled" else it }
    fun allOut(ctx: Context): String = (prefs(ctx).getString("out_all", null) ?: "default").let { if (it == "default" || it == "1f6f5c") "default" else it }
    fun allDoodle(ctx: Context): Boolean = prefs(ctx).getBoolean("doodle_all", true)
    fun allBright(ctx: Context): Float = prefs(ctx).getFloat("bright_all", 1f)
    fun allBrightLight(ctx: Context): Float = prefs(ctx).getFloat("brightl_all", 1f).coerceIn(0.6f, 1f)
    /** Varsayılan duvar kağıdı kendi resmiyse, o resmi bu sohbete kopyalar */
    fun copyAllCustom(ctx: Context, chatId: String): Boolean = try {
        val src = customFile(ctx, "_all")
        if (src.exists()) { src.copyTo(customFile(ctx, chatId), overwrite = true); true } else false
    } catch (e: Throwable) { false }

    fun set(ctx: Context, chatId: String, id: String) {
        prefs(ctx).edit().putString("theme_$chatId", if (id == "default") "amoled" else id).apply()
    }

    private fun rawFile(ctx: Context, chatId: String) =
        File(ctx.filesDir, "theme_" + chatId.replace(Regex("[^A-Za-z0-9_-]"), "_") + "_raw.jpg")

    /** Galeriden seçilen resmin kırpılmamış hâli (önizlemede parmakla ayarlamak için) */
    fun loadCustomRaw(ctx: Context, chatId: String): ImageBitmap? =
        try { rawFile(ctx, chatId).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath)?.asImageBitmap() } } catch (e: Throwable) { null }

    /** Parmakla ayarlanan konum/yakınlaştırmaya göre özel resmi yeniden kırpar (çizimle aynı hesap) */
    suspend fun cropCustom(ctx: Context, chatId: String, zoom: Float, panX: Float, panY: Float): Boolean = withContext(Dispatchers.IO) {
        try {
            val raw = BitmapFactory.decodeFile(rawFile(ctx, chatId).absolutePath) ?: return@withContext false
            val (sw, sh) = screenSize(ctx)
            val scale = max(sw.toFloat() / raw.width, sh.toFloat() / raw.height) * zoom.coerceAtLeast(1f)
            val srcW = (sw / scale).toInt().coerceIn(1, raw.width)
            val srcH = (sh / scale).toInt().coerceIn(1, raw.height)
            val left = ((raw.width - srcW) / 2f * (1f + panX.coerceIn(-1f, 1f))).toInt().coerceIn(0, raw.width - srcW)
            val top = ((raw.height - srcH) / 2f * (1f + panY.coerceIn(-1f, 1f))).toInt().coerceIn(0, raw.height - srcH)
            val cropped = Bitmap.createBitmap(raw, left, top, srcW, srcH)
            val outW = min(1080, cropped.width)
            val outH = max(1, (outW.toFloat() * sh / sw).toInt())
            val scaled = Bitmap.createScaledBitmap(cropped, outW, outH, true)
            FileOutputStream(customFile(ctx, chatId)).use { scaled.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            true
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatThemes", e); false }
    }

    /** Sohbetin galeriden seçilmiş özel duvar kağıdını siler (tema sıfırlanınca kart listesinden kalkar) */
    fun clearCustom(ctx: Context, chatId: String) {
        try { customFile(ctx, chatId).delete(); rawFile(ctx, chatId).delete() } catch (e: Throwable) { }
    }

    private fun customFile(ctx: Context, chatId: String) =
        File(ctx.filesDir, "theme_" + chatId.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".jpg")

    fun resolve(ctx: Context, chatId: String): ResolvedTheme {
        val id0 = savedId(ctx, chatId)
        // Minimal temaları koyu / açık moda göre eşleşir (mnd↔mnl)
        val id = if (id0.startsWith("mn") && id0.length == 4) (if (AuraUi.lightReal) "mnl" else "mnd") + id0.substring(3) else id0
        val outId = savedOutId(ctx, chatId)
        val out = bubbleColors.firstOrNull { it.id == outId }?.color ?: ThemeDefaultOut
        val dd = doodleOn(ctx, chatId)
        // açık / sistem(açık) temada arka plan ışığı hep %100
        val br = if (AuraUi.lightReal) bgBrightLight(ctx, chatId) else bgBright(ctx, chatId)
        if (id == "custom") {
            val bmp = loadCustom(ctx, chatId)
            if (bmp != null) return ResolvedTheme("custom", null, bmp, out, true, br)
        }
        if (Wallpapers.isWall(id)) {
            val bmp = Wallpapers.full(id)
            if (bmp != null) return ResolvedTheme(id, null, bmp, out, true, br)
        }
        // Varsayılan (Kömür): açık / sistem(açık) temada krem, koyuda siyah arka plan
        val t = all.firstOrNull { it.id == id && it.id != "default" && !(it.id == "amoled" && AuraUi.lightReal) }
        // Çiziktirme: zemin, üst bar ve desen baloncuk rengini takip eder
        if (((t != null && isZ(t.id)) || isDefaultBg(id)) && tintOut(outId)) zFollow(outId)?.let { return ResolvedTheme(it.id, it.stops, null, out, dd, br) }
        return if (t != null) ResolvedTheme(t.id, adaptStops(t.id, t.stops), null, out, dd, br)
        else ResolvedTheme("default", null, null, out, dd, br)
    }

    fun isZ(id: String) = id.startsWith("z") && id.length == 7

    /** Düz renklerin açık tema karşılıkları (kullanıcının seçtiği tonlar) */
    private val solidLight: Map<String, Color> = mapOf(
        "s2a7b72" to c(0xbbe5e4),
        "s2d6a4f" to c(0xaed9c8),
        "s1e532b" to c(0x7acaa5),
        "s3a6073" to c(0xcbdaed),
        "s1a5b6e" to c(0x66d2d5),
        "s174355" to c(0x64bdcf),
        "s362a63" to c(0xd5d0f0),
        "s525252" to c(0xcecece),
        "s5c6b39" to c(0xd1dabf),
        "s807328" to c(0xe5e1b1),
        "s6b5a0a" to c(0xfef0a9),
        "sb85b00" to c(0xfed196),
        "s680c1d" to c(0xfd9b9c),
        "s4a0e0e" to c(0xfd6769),
        "s300808" to c(0xfb4667),
        "s42141a" to c(0x922041),
        "s6e2d1b" to c(0xdc6d4f),
        "s2e2528" to c(0x634c52),
        "s263d3c" to c(0x517f7f),
        "s1e3b4a" to c(0x308fbb),
        "s182538" to c(0x35548a),
        "s3d434a" to c(0x556370),
        "s0e1114" to c(0x1e2327),
        "s1c121e" to c(0x301e34),
        "s546e7a" to c(0xe5e9ea),
        "s667009" to c(0xfffea2),
        "s757d42" to c(0xe6e8d2)
    )

    /** Düz renk ("s"+hex) mi */
    fun isSolidId(id: String) = id.startsWith("s") && id.length == 7 && id.substring(1).toLongOrNull(16) != null

    /** Açık temada düz renkler pastel olur (koyu temada aynen) */
    fun adaptStops(id: String, stops: List<Pair<Float, Color>>?): List<Pair<Float, Color>>? =
        if (stops != null && AuraUi.lightReal && isSolidId(id)) { val p = solidLight[id] ?: pastelOf(stops.first().second); listOf(0f to p, 1f to p) } else stops

    /** Baloncuk rengine göre çiziktirme teması üretir (id "z"+hex) */
    fun zFollow(outHex: String): ChatTheme? {
        val v = outHex.toLongOrNull(16) ?: return null
        return ChatTheme("z$outHex", "Çiziktirme", solid(zbg(v)), null)
    }

    /** Önizleme için: çiziktirme arka planı seçili baloncuk rengine uyar */
    fun zAdapt(bgId: String, outId: String): String =
        if ((isZ(bgId) || isDefaultBg(bgId)) && tintOut(outId)) "z$outId" else bgId

    /** Varsayılan (krem / siyah) duvar kağıdı mı */
    fun isDefaultBg(bgId: String) = bgId == "amoled" || bgId == "default"

    /** İlk iki (koyu / açık yeşil) dışındaki baloncuk renkleri zemini ve üst çubuğu kendi tonuna boyar (WhatsApp gibi) */
    fun tintOut(outId: String) = outId != "default" && outId != "126d47" && outId.length == 6 && outId.toLongOrNull(16) != null

    fun resolveBuiltIn(t: ChatTheme): ResolvedTheme =
        if (t.id == "default" || (t.id == "amoled" && AuraUi.lightReal)) ResolvedTheme("default", null, null, ThemeDefaultOut)
        else ResolvedTheme(t.id, adaptStops(t.id, t.stops), null, t.out ?: ThemeDefaultOut)

    /** Galeriden seçilen resmi 9:16 ortadan kırpıp (540x960) kaydeder */
    suspend fun saveCustom(ctx: Context, chatId: String, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val cr = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 1080 && bounds.outHeight / (sample * 2) >= 1920) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return@withContext false
            val orientation = try {
                cr.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (e: Throwable) { ExifInterface.ORIENTATION_NORMAL }
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val bmp = if (deg != 0f) {
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, Matrix().apply { postRotate(deg) }, true)
            } else decoded
            // kırpılmamış hâli de saklanır (önizlemede parmakla ayarlanabilsin)
            try {
                val k = minOf(1f, 2400f / max(bmp.width, bmp.height))
                val rawOut = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true) else bmp
                FileOutputStream(rawFile(ctx, chatId)).use { rawOut.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatThemes", e) }
            // WhatsApp gibi: resim ne boyutta olursa olsun ekranın tamamını (örn. 1080x2152) kaplayacak oranda ortadan kırpılır
            val (sw, sh) = screenSize(ctx)
            val target = sw.toFloat() / sh.toFloat()
            val ratio = bmp.width.toFloat() / bmp.height
            var cw = bmp.width
            var ch = bmp.height
            if (ratio > target) cw = (bmp.height * target).toInt() else ch = (bmp.width / target).toInt()
            val cropped = Bitmap.createBitmap(bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, max(1, cw), max(1, ch))
            val outW = min(1080, cropped.width)
            val outH = max(1, (outW / target).toInt())
            val scaled = Bitmap.createScaledBitmap(cropped, outW, outH, true)
            FileOutputStream(customFile(ctx, chatId)).use { scaled.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            true
        } catch (e: Throwable) {
            false
        }
    }
}

/** Sohbet arka planı: gradyan, özel resim ya da varsayılan renk (+ isteğe bağlı ikon deseni) */
fun Modifier.themeBackground(t: ResolvedTheme): Modifier =
    if (!t.doodle || t.image != null) this.drawBehind { drawThemeBase(t, null, Color.Transparent) }
    else this.composed {
        val ctx = androidx.compose.ui.platform.LocalContext.current
        val mask = remember {
            try { BitmapFactory.decodeResource(ctx.resources, com.aurachat.app.R.drawable.doodle_pattern)?.asImageBitmap() } catch (e: Throwable) { null }
        }
        val col = doodleColor(t)
        this.drawBehind { drawThemeBase(t, mask, col) }
    }

/** Ayarlar sayfasının üst kapağı: yalnızca doodle deseni (altı yumuşakça zemine karışır) */
fun Modifier.doodleCover(col: Color, fade: Color): Modifier = this.composed {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val mask = remember {
        try { BitmapFactory.decodeResource(ctx.resources, com.aurachat.app.R.drawable.doodle_pattern)?.asImageBitmap() } catch (e: Throwable) { null }
    }
    this.clipToBounds().drawBehind {
        if (mask != null) drawDoodle(mask, col)
        drawRect(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, fade), startY = size.height * 0.7f, endY = size.height))
    }
}

/** Çiziktirme temasının ana rengi (id "z"+hex), değilse null */
private fun zBase(t: ResolvedTheme): Color? =
    if (t.id.startsWith("z") && t.id.length == 7) t.id.substring(1).toLongOrNull(16)?.let { Color(0xFF000000 or it) } else null

/** Açık temada çiziktirme zemini: rengin soluk tonu; WhatsApp gibi üst çubuk ve durum çubuğu da bununla hafifçe boyanır */
fun themeBarTint(t: ResolvedTheme): Color? {
    // düz renk (açık tema): üst çubuk zeminle birebir aynı
    if (AuraUi.lightReal && ChatThemes.isSolidId(t.id)) t.stops?.let { return it.first().second }
    // çiziktirme: ana rengin soluk tonu
    zBase(t)?.let { if (AuraUi.lightReal) return waTint(it) }
    // galeriden seçilen resim: üst çubuk ve menüler baloncuk rengini izler (WhatsApp gibi); varsayılan yeşilde resmin üst tonu
    if (t.id == "custom" && t.image != null && !t.isDefaultOut) {
        return if (AuraUi.lightReal) waTint(t.out) else androidx.compose.ui.graphics.lerp(t.out, Color.Black, 0.8f)
    }
    // diğer temalar: duvar kağıdının en üstteki rengine en yakın ton
    val top: Color = when {
        t.image != null -> topAverage(t.image)
        t.stops != null -> t.stops.first().second
        else -> return null
    }
    val white = Color.White; val black = Color.Black
    return if (AuraUi.lightReal) {
        val m = androidx.compose.ui.graphics.lerp(top, white, 0.86f)
        m
    } else androidx.compose.ui.graphics.lerp(top, black, 0.80f)
}

/** Resmin üst %8'lik şeridinin ortalama rengi */
private fun topAverage(img: ImageBitmap): Color {
    return try {
        val h = (img.height * 0.08f).toInt().coerceAtLeast(1)
        val px = IntArray(img.width * h)
        img.readPixels(px, 0, 0, img.width, h)
        var r = 0L; var g = 0L; var b = 0L
        val step = 7
        var n = 0
        var i = 0
        while (i < px.size) { val c = px[i]; r += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255; n++; i += step }
        if (n == 0) Color.Gray else Color(r.toInt() / n, g.toInt() / n, b.toInt() / n)
    } catch (e: Throwable) { Color.Gray }
}

private fun themeLightBg(t: ResolvedTheme): Color? {
    if (!AuraUi.lightReal) return null
    val b = zBase(t) ?: return null
    return waTint(b)
}

/** Sohbet ekranının üst çubuk boyası (tema yoksa normal) */
object ChatBar {
    private val sl = androidx.compose.runtime.mutableStateOf(false)
    var sel: Boolean
        get() = sl.value
        set(v) { sl.value = v }
    private val st = androidx.compose.runtime.mutableStateOf<Color?>(null)
    var tint: Color?
        get() = st.value
        set(v) { st.value = v }
}

private fun doodleColor(t: ResolvedTheme): Color =
    if (AuraUi.lightReal && zBase(t) != null) {
        zBase(t)!!.copy(alpha = 0.14f)
    } else if (t.id.startsWith("z") && t.id.length == 7) {
        val v = t.id.substring(1).toLongOrNull(16) ?: 0x888888L
        // renk kutusu: desen, rengin açılmış hâliyle yumuşakça karışır (WhatsApp'taki gibi)
        val r = ((v shr 16) and 255) / 255f; val g = ((v shr 8) and 255) / 255f; val b = (v and 255) / 255f
        Color(r * 0.6f + 0.4f, g * 0.6f + 0.4f, b * 0.6f + 0.4f, 0.26f)
    } else if (AuraUi.lightReal && ChatThemes.isSolidId(t.id)) Color(0x14000000)
    else if (t.id == "cardcream" || (t.stops == null && AuraUi.lightReal)) Color(0xA6CFC6B2) else Color(0x30FFFFFF)

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawThemeBase(t: ResolvedTheme, mask: ImageBitmap?, col: Color) {
    val img = t.image
    val stops = t.stops
    if (img != null) {
        val w = size.width
        val h = size.height
        val scale = max(w / img.width, h / img.height) * t.zoom.coerceAtLeast(1f)
        val srcW = (w / scale).toInt().coerceIn(1, img.width)
        val srcH = (h / scale).toInt().coerceIn(1, img.height)
        val left = ((img.width - srcW) / 2f * (1f + t.panX.coerceIn(-1f, 1f))).toInt().coerceIn(0, img.width - srcW)
        val top = ((img.height - srcH) / 2f * (1f + t.panY.coerceIn(-1f, 1f))).toInt().coerceIn(0, img.height - srcH)
        drawImage(
            img,
            srcOffset = IntOffset(left, top),
            srcSize = IntSize(srcW, srcH),
            dstSize = IntSize(w.toInt(), h.toInt())
        )
    } else if (themeLightBg(t) != null) {
        drawRect(themeLightBg(t)!!)
        if (mask != null) drawDoodle(mask, col)
    } else if (stops != null) {
        drawRect(Brush.linearGradient(*stops.toTypedArray(), start = Offset.Zero, end = Offset(size.width * 0.36f, size.height)))
        if (mask != null) drawDoodle(mask, col)
    } else {
        // Varsayılan duvar kağıdı: açık temada WhatsApp gibi krem, koyuda siyah
        drawRect(if (AuraUi.lightReal) Color(0xFFEFEAE2) else AuraChatBg)
        if (mask != null) drawDoodle(mask, col)
    }
    // arka plan parlaklığı (tema sayfasındaki çubuk): koyulaştır ya da aç
    if (t.bright < 0.99f) drawRect(Color.Black.copy(alpha = ((1f - t.bright)).coerceIn(0f, 0.9f)))
    else if (t.bright > 1.01f) drawRect(Color.White.copy(alpha = ((t.bright - 1f) * 0.5f).coerceIn(0f, 0.4f)))
}

/** Desen maskesi: genişliğe sığdırılır, dikeyde tekrarlanır, renk verilen tonla boyanır */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawDoodle(mask: ImageBitmap, col: Color) {
    val w = size.width.toInt().coerceAtLeast(1)
    val tileH = (w.toFloat() * mask.height / mask.width).toInt().coerceAtLeast(1)
    val tint = androidx.compose.ui.graphics.ColorFilter.tint(col, androidx.compose.ui.graphics.BlendMode.SrcIn)
    var y = 0
    while (y < size.height) {
        drawImage(mask, srcOffset = IntOffset.Zero, srcSize = IntSize(mask.width, mask.height), dstOffset = IntOffset(0, y), dstSize = IntSize(w, tileH), colorFilter = tint)
        y += tileH
    }
}

/** Desen karosu: elle çizilmiş çizgi şekiller (ikon kütüphanesi gerekmez), konum ve açı karışık, dikişsiz tekrarlanır */
private fun buildDoodleTile(color: Color, density: androidx.compose.ui.unit.Density, dir: androidx.compose.ui.unit.LayoutDirection): ImageBitmap {
    val d = density.density
    val cell = 52f * d
    val n = 7
    val side = (cell * n).toInt()
    val bmp = ImageBitmap(side, side)
    val canvas = androidx.compose.ui.graphics.Canvas(bmp)
    val st = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f * d, cap = androidx.compose.ui.graphics.StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
    androidx.compose.ui.graphics.drawscope.CanvasDrawScope().draw(density, dir, canvas, androidx.compose.ui.geometry.Size(side.toFloat(), side.toFloat())) {
        for (j in 0 until n) for (i in 0 until n) {
            val h = (i * 73856093) xor (j * 19349663) xor 0x5bd1e995
            val k = ((h ushr 3) and 0x7fffffff) % 12
            val jx = (((h ushr 8) and 15) / 15f - 0.5f) * cell * 0.45f
            val jy = (((h ushr 12) and 15) / 15f - 0.5f) * cell * 0.45f
            val deg = (((h ushr 16) and 63) - 32).toFloat()
            val r = (8f + ((h ushr 22) and 3)) * d
            val cx = i * cell + cell / 2 + jx + (if (j % 2 == 1) cell / 2 else 0f)
            val cy = j * cell + cell / 2 + jy
            for (ox in intArrayOf(-side, 0, side)) for (oy in intArrayOf(-side, 0, side)) {
                val x = cx + ox
                val y = cy + oy
                if (x < -r * 2 || y < -r * 2 || x > side + r * 2 || y > side + r * 2) continue
                withTransform({ translate(x, y); rotate(deg, pivot = Offset.Zero) }) {
                    drawDoodleShape(k, r, color, st)
                }
            }
        }
    }
    return bmp
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawDoodleShape(k: Int, r: Float, color: Color, st: androidx.compose.ui.graphics.drawscope.Stroke) {
    val p = androidx.compose.ui.graphics.Path()
    when (k) {
        0 -> { // konuşma balonu
            p.addRoundRect(androidx.compose.ui.geometry.RoundRect(-r, -r * 0.8f, r, r * 0.55f, androidx.compose.ui.geometry.CornerRadius(r * 0.4f)))
            p.moveTo(-r * 0.4f, r * 0.55f); p.lineTo(-r * 0.6f, r * 1.0f); p.lineTo(0f, r * 0.55f)
        }
        1 -> { // kalp
            p.moveTo(0f, r * 0.9f)
            p.cubicTo(-r * 1.4f, -r * 0.1f, -r * 0.7f, -r * 1.0f, 0f, -r * 0.35f)
            p.cubicTo(r * 0.7f, -r * 1.0f, r * 1.4f, -r * 0.1f, 0f, r * 0.9f)
        }
        2 -> { // yıldız
            for (a in 0 until 10) {
                val rad = if (a % 2 == 0) r else r * 0.45f
                val t = (-90.0 + a * 36.0) * Math.PI / 180.0
                val px = (rad * Math.cos(t)).toFloat(); val py = (rad * Math.sin(t)).toFloat()
                if (a == 0) p.moveTo(px, py) else p.lineTo(px, py)
            }
            p.close()
        }
        3 -> p.addOval(androidx.compose.ui.geometry.Rect(-r * 0.8f, -r * 0.8f, r * 0.8f, r * 0.8f))
        4 -> { // artı
            p.moveTo(-r * 0.8f, 0f); p.lineTo(r * 0.8f, 0f); p.moveTo(0f, -r * 0.8f); p.lineTo(0f, r * 0.8f)
        }
        5 -> { // dalga
            p.moveTo(-r, 0f)
            p.cubicTo(-r * 0.6f, -r * 0.9f, -r * 0.2f, -r * 0.9f, 0f, 0f)
            p.cubicTo(r * 0.2f, r * 0.9f, r * 0.6f, r * 0.9f, r, 0f)
        }
        6 -> { // nota
            p.moveTo(r * 0.5f, -r); p.lineTo(r * 0.5f, r * 0.55f)
            p.addOval(androidx.compose.ui.geometry.Rect(-r * 0.2f, r * 0.2f, r * 0.5f, r * 0.9f))
            p.moveTo(r * 0.5f, -r); p.lineTo(r * 1.0f, -r * 0.5f)
        }
        7 -> { // bulut
            p.moveTo(-r * 0.8f, r * 0.5f)
            p.cubicTo(-r * 1.4f, r * 0.5f, -r * 1.2f, -r * 0.4f, -r * 0.5f, -r * 0.3f)
            p.cubicTo(-r * 0.4f, -r * 1.1f, r * 0.7f, -r * 1.0f, r * 0.7f, -r * 0.2f)
            p.cubicTo(r * 1.4f, -r * 0.2f, r * 1.4f, r * 0.5f, r * 0.8f, r * 0.5f)
            p.close()
        }
        8 -> { // elmas
            p.moveTo(0f, -r); p.lineTo(r * 0.8f, 0f); p.lineTo(0f, r); p.lineTo(-r * 0.8f, 0f); p.close()
        }
        9 -> { // yaprak
            p.moveTo(-r * 0.8f, r * 0.8f)
            p.cubicTo(-r * 1.0f, -r * 0.6f, r * 0.2f, -r * 1.0f, r * 0.9f, -r * 0.9f)
            p.cubicTo(r * 1.0f, r * 0.2f, -r * 0.1f, r * 1.0f, -r * 0.8f, r * 0.8f)
            p.moveTo(-r * 0.8f, r * 0.8f); p.lineTo(r * 0.2f, -r * 0.2f)
        }
        10 -> { // güneş
            p.addOval(androidx.compose.ui.geometry.Rect(-r * 0.4f, -r * 0.4f, r * 0.4f, r * 0.4f))
            for (a in 0 until 8) {
                val t = a * Math.PI / 4
                val c = Math.cos(t).toFloat(); val s = Math.sin(t).toFloat()
                p.moveTo(c * r * 0.7f, s * r * 0.7f); p.lineTo(c * r, s * r)
            }
        }
        else -> { // üçgen
            p.moveTo(0f, -r * 0.9f); p.lineTo(r * 0.9f, r * 0.7f); p.lineTo(-r * 0.9f, r * 0.7f); p.close()
        }
    }
    drawPath(p, color, style = st)
}

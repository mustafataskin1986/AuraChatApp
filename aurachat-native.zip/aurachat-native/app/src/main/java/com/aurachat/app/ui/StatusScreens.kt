package com.aurachat.app.ui

import androidx.compose.material.icons.filled.ArrowUpward
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.aurachat.app.data.ChatSummary
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Media
import com.aurachat.app.data.ReplyRef
import com.aurachat.app.data.Repo
import com.aurachat.app.data.StatusItem
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

private val StBgColors = listOf(
    "#128c7e", "#075e54", "#6a1b9a", "#c2185b", "#d84315",
    "#1565c0", "#37474f", "#2e7d32", "#ad1457", "#4527a0"
)
/** Durum görüntüleyicideki üç nokta menüsünün dış işlemleri (arama, profil, gizleme) */
class StatusMenuActions(
    val onCall: (ChatTarget, Boolean) -> Unit = { _, _ -> },
    val onProfile: (ChatTarget) -> Unit = {},
    val onHide: (String) -> Unit = {}
)

private val StPanel: Color get() = auraC(0xFF202C33)
private val StMenuBg: Color get() = auraC(0xFF111B21)
private val StBar: Color get() = auraC(0xFF1F2C34)
private val StPanelR: Color get() = auraCRaw(0xFF202C33)
private val StMenuBgR: Color get() = auraCRaw(0xFF111B21)
private val StBarR: Color get() = auraCRaw(0xFF1F2C34)
private val StRingNew: Color get() = auraLc(0xFF22C55E)
private val StRingSeen: Color get() = auraLc(0xFF6B7280)

private fun stToast(ctx: android.content.Context, s: String) =
    Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

private fun parseBg(s: String): Color =
    try { Color(android.graphics.Color.parseColor(s)) } catch (e: Throwable) { auraLc(0xFF128C7E) }

fun statusTimeLabel(ms: Long): String {
    val diff = System.currentTimeMillis() - ms
    if (diff < 60_000L) return "Az önce"
    if (diff < 3_600_000L) return (diff / 60_000L).toString() + " dk önce"
    val a = Calendar.getInstance().apply { timeInMillis = ms }
    val b = Calendar.getInstance()
    val same = a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    if (same) return "Bugün " + formatClock(ms)
    val y = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    if (a.get(Calendar.YEAR) == y.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)) return "Dün " + formatClock(ms)
    return java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale("tr")).format(java.util.Date(ms))
}

private data class StatusGroup(val uid: String, val list: List<StatusItem>)
private data class ViewerReq(val groups: List<StatusGroup>, val start: Int)
private data class ComposerReq(val mode: String, val uri: Uri?, val initial: String = "")

@Composable
private fun RingAvatar(name: String, avatar: String, size: Dp, ring: Color?) {
    val outer = size + 10.dp
    Box(
        Modifier.size(outer).then(if (ring != null) Modifier.border(2.5.dp, ring, CircleShape) else Modifier),
        contentAlignment = Alignment.Center
    ) { Avatar(name, avatar, size) }
}

// =====================================================================
//  DURUM SEKMESİ
// =====================================================================
@Composable
fun StatusScreen(
    me: UserProfile,
    onFullscreen: (Boolean) -> Unit,
    onMessage: (ChatTarget) -> Unit,
    onCall: (ChatTarget, Boolean) -> Unit = { _, _ -> },
    onProfile: (ChatTarget) -> Unit = {}
) {
    val ctx = LocalContext.current
    var hidden by remember { mutableStateOf(ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).getStringSet("status_hidden", emptySet()) ?: emptySet()) }
    fun setHidden(n: Set<String>) {
        hidden = n
        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putStringSet("status_hidden", n).apply()
    }
    val all by remember { Repo.statusesFlow() }.collectAsState(emptyList<StatusItem>())
    val chats by remember(me.uid) { Repo.chatsFlow(me.uid) }.collectAsState(null as List<ChatSummary>?)
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(me.uid) {
        Repo.cleanupMyStatuses(me.uid)
        while (true) {
            delay(30_000)
            now = System.currentTimeMillis()
        }
    }

    val active = all.filter { it.expiresAt > now }
    val mine = active.filter { it.uid == me.uid }.sortedBy { it.createdAt }
    val seeable: Set<String>? = chats?.filter { !it.isGroup }?.map { it.otherUid }?.toSet()
    val groups = active
        .filter { it.uid != me.uid && !hidden.contains(it.uid) && (seeable == null || seeable.contains(it.uid)) }
        .groupBy { it.uid }
        .map { (uid, l) -> StatusGroup(uid, l.sortedBy { it.createdAt }) }
        .sortedWith(
            compareByDescending<StatusGroup> { g -> g.list.any { !it.viewers.contains(me.uid) } }
                .thenByDescending { g -> g.list.last().createdAt }
        )

    var viewer by remember { mutableStateOf<ViewerReq?>(null) }
    var composer by remember { mutableStateOf<ComposerReq?>(null) }
    var addSheet by remember { mutableStateOf(false) }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) composer = ComposerReq("image", uri)
    }
    var camUri by remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri
        if (ok && u != null) composer = ComposerReq("image", u)
    }
    fun openCamera() {
        try {
            val dir = File(ctx.cacheDir, "camera").also { it.mkdirs() }
            val f = File(dir, "status_${System.currentTimeMillis()}.jpg")
            val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            camUri = u
            camera.launch(u)
        } catch (e: Throwable) {
            stToast(ctx, "Kamera açılamadı")
        }
    }
    fun openGallery() {
        gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    BackHandler(enabled = addSheet) { addSheet = false }
    val full = viewer != null || composer != null || addSheet
    LaunchedEffect(full) { onFullscreen(full) }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { onFullscreen(false) } }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Text(
                "Durum", color = AuraWhite, fontSize = 22.sp,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp)
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(Modifier.fillMaxSize()) {
                    item {
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable {
                                    if (mine.isEmpty()) addSheet = true
                                    else viewer = ViewerReq(listOf(StatusGroup(me.uid, mine)), 0)
                                }
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(68.dp)) {
                                RingAvatar(me.name, me.avatar, 58.dp, if (mine.isNotEmpty()) StRingNew else null)
                                Box(
                                    Modifier.align(Alignment.BottomEnd).size(26.dp).clip(CircleShape)
                                        .background(AuraGreen).border(2.dp, AuraBg, CircleShape)
                                        .clickable { addSheet = true },
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.Add, "Durum ekle", tint = AuraWhite, modifier = Modifier.size(16.dp)) }
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Durumum", color = AuraWhite, fontSize = 18.sp)
                                Text(
                                    if (mine.isNotEmpty()) statusTimeLabel(mine.last().createdAt) else "Durum güncellemesi ekle",
                                    color = AuraMuted, fontSize = 15.sp
                                )
                            }
                        }
                    }
                    item {
                        Text(
                            "SON GÜNCELLEMELER", color = AuraMuted, fontSize = 13.sp, letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 6.dp)
                        )
                    }
                    if (groups.isEmpty()) {
                        item {
                            Text(
                                "Henüz kimse durum paylaşmadı.", color = AuraMuted, fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 40.dp)
                            )
                        }
                    } else {
                        items(groups, key = { it.uid }) { g ->
                            val prof by liveProfile(g.uid)
                            val p = prof
                            val unseen = g.list.any { !it.viewers.contains(me.uid) }
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable {
                                        viewer = ViewerReq(groups, groups.indexOfFirst { it.uid == g.uid }.coerceAtLeast(0))
                                    }
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(68.dp), contentAlignment = Alignment.Center) {
                                    RingAvatar(p?.name ?: "", p?.avatar ?: "", 54.dp, if (unseen) StRingNew else StRingSeen)
                                }
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p?.name ?: "", color = AuraWhite, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(statusTimeLabel(g.list.last().createdAt), color = AuraMuted, fontSize = 15.sp)
                                }
                            }
                        }
                    }
                    if (hidden.isNotEmpty()) {
                        item(key = "hidden-h") {
                            Text(
                                "GİZLENEN DURUMLAR", color = AuraMuted, fontSize = 13.sp, letterSpacing = 0.5.sp,
                                modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 6.dp)
                            )
                        }
                        items(hidden.toList(), key = { "hid-$it" }) { hu ->
                            val hp by liveProfile(hu)
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Avatar(hp?.name ?: "?", hp?.avatar ?: "", 44.dp)
                                Text(hp?.name ?: "", color = AuraWhite, fontSize = 16.sp, modifier = Modifier.weight(1f).padding(start = 14.dp))
                                Text(
                                    "Göster", color = StRingNew, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { setHidden(hidden - hu) }.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
                Column(
                    Modifier.align(Alignment.BottomEnd).padding(end = 22.dp, bottom = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Box(
                        Modifier.size(46.dp).clip(CircleShape).background(StPanel).clickable { composer = ComposerReq("text", null) },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Edit, "Yazı durumu", tint = auraLc(0xFFE5E7EB), modifier = Modifier.size(22.dp)) }
                    Box(
                        Modifier.size(66.dp).clip(CircleShape).background(AuraGreen).clickable { addSheet = true },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.CameraAlt, "Kamera", tint = AuraWhite, modifier = Modifier.size(30.dp)) }
                }
            }
        }

        if (addSheet) {
            AddStatusSheet(
                onClose = { addSheet = false },
                onCamera = { addSheet = false; openCamera() },
                onText = { addSheet = false; composer = ComposerReq("text", null) },
                onPick = { u ->
                    val isVideo = (ctx.contentResolver.getType(u) ?: "").startsWith("video")
                    if (isVideo) stToast(ctx, "Video durumu yakında")
                    else { addSheet = false; composer = ComposerReq("image", u) }
                },
                onSoon = { stToast(ctx, "$it yakında") }
            )
        }

        val cr = composer
        if (cr != null) {
            AuraDarkIsland { StatusComposer(me, cr, onClose = { composer = null }) }
        }

        val vr = viewer
        if (vr != null) {
            AuraDarkIsland {
                StatusViewer(
                    me = me, groups = vr.groups, live = all, startUser = vr.start,
                    onMessage = { viewer = null; onMessage(it) },
                    onClose = { viewer = null },
                    actions = StatusMenuActions(
                        onCall = { t, v -> viewer = null; onCall(t, v) },
                        onProfile = { viewer = null; onProfile(it) },
                        onHide = { setHidden(hidden + it) }
                    )
                )
            }
        }
    }
}

/** WhatsApp tarzı "Durum ekleyin" sayfası: üstte seçenek düğmeleri, altta albüm seçimi ve galeri ızgarası */
@Composable
private fun AddStatusSheet(
    onClose: () -> Unit, onCamera: () -> Unit, onText: () -> Unit, onPick: (Uri) -> Unit, onSoon: (String) -> Unit
) {
    var album by remember { mutableStateOf<String?>(null) }
    var albums by remember { mutableStateOf<List<Pair<String, Int>>>(emptyList()) }
    var albumMenu by remember { mutableStateOf(false) }
    val bg = auraC(0xFF1A1F24)
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(auraLc(0x8C000000)).clickable { onClose() })
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxSize().statusBarsPadding().padding(top = 10.dp)
                .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)).background(bg)
        ) {
            Box(Modifier.fillMaxWidth().padding(top = 10.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.width(40.dp).height(4.dp).clip(CircleShape).background(auraLc(0xFF6B7280)))
            }
            Box(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 18.dp).height(48.dp)) {
                IconButton(onClick = onClose, modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp)) {
                    Icon(Icons.Default.Close, "Kapat", tint = AuraWhite)
                }
                Text("Durum ekleyin", color = AuraWhite, fontSize = 22.sp, modifier = Modifier.align(Alignment.Center))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf(
                    Triple("Metin", Icons.Default.Edit, onText),
                    Triple("Müzik", Icons.Default.MusicNote, { onSoon("Müzik") }),
                    Triple("Yerleşim", Icons.Default.GridView, { onSoon("Yerleşim") }),
                    Triple("Ses", Icons.Default.Mic, { onSoon("Ses") })
                ).forEach { (label, icon, act) ->
                    Column(Modifier.weight(1f).clickable(
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null
                    ) { act() }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.width(74.dp).height(54.dp).clip(RoundedCornerShape(27.dp)).background(auraC(0xFF2B3036)), contentAlignment = Alignment.Center) {
                            Icon(icon, label, tint = AuraWhite, modifier = Modifier.size(26.dp))
                        }
                        Text(label, color = auraLc(0xFFE5E7EB), fontSize = 17.sp, modifier = Modifier.padding(top = 10.dp))
                    }
                }
            }
            Box(Modifier.padding(start = 20.dp, top = 22.dp, bottom = 12.dp)) {
                Row(Modifier.clip(RoundedCornerShape(10.dp)).clickable { albumMenu = true }.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(album ?: "Son kullanılanlar", color = auraLc(0xFFD1D5DB), fontSize = 22.sp, fontWeight = FontWeight.Medium)
                    Icon(Icons.Default.KeyboardArrowDown, null, tint = auraLc(0xFFD1D5DB), modifier = Modifier.padding(start = 6.dp).size(26.dp))
                }
                AuraDropdownMenu(expanded = albumMenu, onDismissRequest = { albumMenu = false }, containerColor = StMenuBg) {
                    DropdownMenuItem(text = { Text("Son kullanılanlar", color = AuraWhite) }, onClick = { album = null; albumMenu = false })
                    albums.forEach { (n, c) ->
                        DropdownMenuItem(text = { Text("$n  ($c)", color = AuraWhite) }, onClick = { album = n; albumMenu = false })
                    }
                }
            }
            GalleryStrip(
                accent = StRingNew, maxPick = 1, selected = emptyList(),
                onSelected = { l -> l.firstOrNull()?.let { onPick(it) } },
                modifier = Modifier.weight(1f), grid = true, album = album, onAlbums = { albums = it },
                columns = 3,
                leading = {
                    Column(
                        Modifier.fillMaxSize().background(auraC(0xFF11161A)).clickable { onCamera() },
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.CameraAlt, "Kamera", tint = StRingNew, modifier = Modifier.size(40.dp))
                        Text("Kamera", color = AuraMuted, fontSize = 20.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            )
        }
    }
}

// =====================================================================
//  OLUŞTURUCU (yazı / fotoğraf)
// =====================================================================
@Composable
private fun StatusComposer(me: UserProfile, req: ComposerReq, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val isText = req.mode == "text"
    var bgIdx by remember { mutableIntStateOf((System.currentTimeMillis() % StBgColors.size).toInt()) }
    var text by remember { mutableStateOf(req.initial.take(300)) }
    var caption by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    // metindeki ilk bağlantı için önizleme kartı (TikTok / YouTube / Facebook ...), X ile kaldırılır
    val linkUrl = remember(text) { Regex("https?://\\S+").find(text)?.value?.trimEnd('.', ',', ')') ?: "" }
    var link by remember { mutableStateOf<com.aurachat.app.data.LinkPreview?>(null) }
    var dismissedUrl by remember { mutableStateOf("") }
    LaunchedEffect(linkUrl) {
        if (linkUrl.isEmpty()) { link = null; return@LaunchedEffect }
        if (linkUrl == dismissedUrl || link?.url == linkUrl) return@LaunchedEffect
        delay(500)
        link = try { Repo.fetchLinkPreview(linkUrl) } catch (e: Throwable) { null }
    }

    val image by produceState<String?>(null, req.uri) {
        if (!isText && req.uri != null) {
            val d = withContext(Dispatchers.IO) { Media.compress(ctx, req.uri, 300 * 1024) }
            if (d == null) {
                stToast(ctx, "Fotoğraf açılamadı")
                onClose()
            } else value = d
        }
    }

    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        if (isText) {
            delay(100)
            try { focus.requestFocus() } catch (e: Throwable) {}
        }
    }
    BackHandler { onClose() }

    fun send() {
        if (busy) return
        val t = text.trim()
        if (isText && t.isEmpty()) {
            stToast(ctx, "Önce bir şey yazın")
            return
        }
        if (!isText && image == null) return
        busy = true
        scope.launch {
            try {
                if (isText) Repo.postStatus(me, "text", t, StBgColors[bgIdx], "", null, if (linkUrl.isNotEmpty() && linkUrl != dismissedUrl) link else null)
                else Repo.postStatus(me, "image", "", "", caption.trim(), image)
                stToast(ctx, "Durum paylaşıldı")
                onClose()
            } catch (e: Throwable) {
                busy = false
                stToast(ctx, "Paylaşılamadı, tekrar deneyin")
            }
        }
    }

    Box(Modifier.fillMaxSize().background(if (isText) parseBg(StBgColors[bgIdx]) else Color.Black)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Kapat", tint = Color.White) }
                Spacer(Modifier.weight(1f))
                if (isText) {
                    IconButton(onClick = { bgIdx = (bgIdx + 1) % StBgColors.size }) {
                        Icon(Icons.Default.Palette, "Renk", tint = Color.White)
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp), contentAlignment = Alignment.Center) {
                if (isText) {
                  Column(Modifier.fillMaxWidth().verticalScroll(androidx.compose.foundation.rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    val lk = link
                    if (lk != null && linkUrl.isNotEmpty() && linkUrl != dismissedUrl) {
                        StatusLinkCard(lk, onRemove = { dismissedUrl = linkUrl; link = null })
                        Spacer(Modifier.height(20.dp))
                    }
                    AuraTextField(
                        value = text,
                        onValueChange = { if (it.length <= 300) text = it },
                        textStyle = TextStyle(color = Color.White, fontSize = if (linkUrl.isNotEmpty()) 24.sp else 30.sp, textAlign = TextAlign.Center,
                            textDecoration = if (text.trim() == linkUrl && linkUrl.isNotEmpty()) androidx.compose.ui.text.style.TextDecoration.Underline else null),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.fillMaxWidth().focusRequester(focus),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.Center) {
                                if (text.isEmpty()) Text("Bir durum yazın", color = Color(0x99FFFFFF), fontSize = 30.sp, textAlign = TextAlign.Center)
                                inner()
                            }
                        }
                    )
                  }
                } else {
                    val img = image
                    if (img == null) CircularProgressIndicator(color = Color.White)
                    else DataUrlImage(img, 1600, Modifier.fillMaxSize(), ContentScale.Fit)
                }
            }
            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                if (!isText) {
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(50)).background(StPanelR)
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        AuraTextField(
                            value = caption,
                            onValueChange = { if (it.length <= 200) caption = it },
                            textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                            cursorBrush = SolidColor(Color.White),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            decorationBox = { inner ->
                                if (caption.isEmpty()) Text("Açıklama ekleyin...", color = AuraRawMuted, fontSize = 15.sp)
                                inner()
                            }
                        )
                    }
                } else {
                    Box(Modifier.clip(RoundedCornerShape(50)).background(StPanelR).padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Text("Durum (tüm kişiler)", color = Color.White, fontSize = 15.sp)
                    }
                    Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.width(10.dp))
                Box(
                    Modifier.size(52.dp).clip(CircleShape).background(StRingNew.copy(alpha = if (busy) 0.6f else 1f))
                        .clickable { send() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.ArrowUpward, "Paylaş", tint = Color.White) }
            }
        }
    }
}

// =====================================================================
//  GÖRÜNTÜLEYİCİ
// =====================================================================
/** Durum görüntüleyici: kullanıcılar arası geçiş parmağı izleyen küp efektiyle (iki yüz aynı anda görünür) */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun StatusViewer(
    me: UserProfile,
    groups: List<StatusGroup>,
    live: List<StatusItem>,
    startUser: Int,
    onMessage: (ChatTarget) -> Unit,
    onClose: () -> Unit,
    actions: StatusMenuActions = StatusMenuActions()
) {
    val pager = androidx.compose.foundation.pager.rememberPagerState(initialPage = startUser.coerceIn(0, groups.size - 1)) { groups.size }
    val scope = rememberCoroutineScope()
    val camDist = 14f * androidx.compose.ui.platform.LocalDensity.current.density
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        androidx.compose.foundation.pager.HorizontalPager(
            state = pager, modifier = Modifier.fillMaxSize(), key = { groups[it].uid }
        ) { page ->
            Box(
                Modifier.fillMaxSize().graphicsLayer {
                    val off = (pager.currentPage - page) + pager.currentPageOffsetFraction   // sağdaki sayfa: negatif
                    rotationY = -90f * off.coerceIn(-1f, 1f)
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(if (off < 0f) 0f else 1f, 0.5f)
                    cameraDistance = camDist
                }
            ) {
                StatusUserPage(
                    me = me, group = groups[page], live = live,
                    isCurrent = pager.currentPage == page && !pager.isScrollInProgress,
                    hasNext = page < groups.size - 1, hasPrev = page > 0,
                    onUser = { d ->
                        scope.launch {
                            pager.animateScrollToPage(
                                (pager.currentPage + d).coerceIn(0, groups.size - 1),
                                animationSpec = androidx.compose.animation.core.tween(380)
                            )
                        }
                    },
                    onMessage = onMessage, onClose = onClose, actions = actions
                )
            }
        }
    }
}

@Composable
private fun StatusUserPage(
    me: UserProfile,
    group: StatusGroup,
    live: List<StatusItem>,
    isCurrent: Boolean,
    hasNext: Boolean,
    hasPrev: Boolean,
    onUser: (Int) -> Unit,
    onMessage: (ChatTarget) -> Unit,
    onClose: () -> Unit,
    actions: StatusMenuActions = StatusMenuActions()
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirmReport by remember { mutableStateOf(false) }
    var deleted by remember { mutableStateOf<Set<String>>(emptySet()) }
    var sIdx by remember {
        mutableIntStateOf(
            run {
                val g = group
                if (g.uid == me.uid) 0 else maxOf(0, g.list.indexOfFirst { !it.viewers.contains(me.uid) })
            }
        )
    }
    var progress by remember { mutableFloatStateOf(0f) }
    var hold by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var viewersSheet by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var inputFocus by remember { mutableStateOf(false) }

    val list = group.list.filter { !deleted.contains(it.id) }
    if (list.isEmpty()) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    val idx = sIdx.coerceIn(0, list.size - 1)
    val base = list[idx]
    val cur = live.firstOrNull { it.id == base.id } ?: base
    val uid = group.uid
    val mineStatus = uid == me.uid

    fun next() {
        if (idx < list.size - 1) sIdx = idx + 1
        else if (hasNext) onUser(1)
        else onClose()
    }
    fun prev() {
        if (idx > 0) sIdx = idx - 1
        else if (hasPrev) onUser(-1)
        else progress = 0f
    }
    val nextFn = rememberUpdatedState(newValue = { next() })
    val prevFn = rememberUpdatedState(newValue = { prev() })
    val closeFn = rememberUpdatedState(newValue = onClose)

    val paused = !isCurrent || hold || menuOpen || viewersSheet || confirmDelete || inputFocus
    val pausedState = rememberUpdatedState(newValue = paused)

    val mediaPair by produceState<Pair<String, String>?>(null, base.id) {
        value = base.id to (if (base.type == "image") Repo.loadStatusMedia(base.id) else "")
    }
    val media: String? = mediaPair?.takeIf { it.first == base.id }?.second
    val loaded = media != null

    LaunchedEffect(isCurrent, idx, loaded) {
        progress = 0f
        if (!loaded || !isCurrent) return@LaunchedEffect
        val dur = if (base.type == "text") 5000f else 6000f
        var last = androidx.compose.runtime.withFrameNanos { it }
        while (progress < 1f) {
            val t = androidx.compose.runtime.withFrameNanos { it }
            if (!pausedState.value) progress = (progress + (t - last) / 1_000_000f / dur).coerceAtMost(1f)
            last = t
        }
        nextFn.value()
    }

    // görüldü işaretle + sonrakini önden yükle
    LaunchedEffect(base.id, isCurrent) {
        if (!isCurrent) return@LaunchedEffect
        if (!mineStatus && !base.viewers.contains(me.uid)) Repo.markStatusViewed(base.id, me.uid)
        list.getOrNull(idx + 1)?.let { if (it.type == "image") Repo.loadStatusMedia(it.id) }
    }

    val live by liveProfile(if (uid == me.uid) "" else uid)
    val prof = if (uid == me.uid) me else live
    val p = prof?.takeIf { it.uid == uid }
    val ownerName = if (mineStatus) "Durumum" else (p?.name ?: "")

    BackHandler(enabled = isCurrent) { onClose() }
    BackHandler(enabled = isCurrent && viewersSheet) { viewersSheet = false }

    val stageBg = if (base.type == "text") parseBg(base.bg) else Color.Black

    Box(
        Modifier.fillMaxSize()
            .background(stageBg)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        hold = true
                        tryAwaitRelease()
                        hold = false
                    },
                    onTap = { o -> if (o.x < size.width * 0.35f) prevFn.value() else nextFn.value() }
                )
            }
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { if (acc > 300f) closeFn.value() },
                    onVerticalDrag = { _, dy -> acc += dy }
                )
            }
    ) {
        // sahne
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (base.type == "text") {
                Column(Modifier.padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    val lk = base.link
                    if (lk != null) {
                        StatusLinkCard(lk, onRemove = null)
                        Spacer(Modifier.height(20.dp))
                    }
                    Text(base.text, color = Color.White, fontSize = if (lk != null) 22.sp else 30.sp, textAlign = TextAlign.Center)
                }
            } else {
                when {
                    media == null -> CircularProgressIndicator(color = Color.White)
                    media.isEmpty() -> Text("Fotoğraf yüklenemedi", color = AuraRawMuted, fontSize = 14.sp)
                    else -> DataUrlImage(media, 1600, Modifier.fillMaxSize(), ContentScale.Fit)
                }
            }
        }

        // üst: ilerleme çubukları + başlık
        Column(
            Modifier.fillMaxWidth().align(Alignment.TopCenter)
                .background(Brush.verticalGradient(listOf(Color(0x8C000000), Color.Transparent)))
                .statusBarsPadding().padding(start = 10.dp, end = 4.dp, top = 10.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(end = 6.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                list.forEachIndexed { i, _ ->
                    val f = if (i < idx) 1f else if (i == idx) progress else 0f
                    Box(Modifier.weight(1f).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x59FFFFFF))) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(f.coerceIn(0f, 1f)).background(Color.White))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
                Avatar(ownerName, if (mineStatus) me.avatar else (p?.avatar ?: ""), 40.dp)
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(ownerName, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(statusTimeLabel(base.createdAt), color = Color(0xFFD1D5DB), fontSize = 13.sp)
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = Color.White) }
                    AuraDropdownMenu(
                        expanded = menuOpen,
                        onDismissRequest = { menuOpen = false },
                        containerColor = StMenuBgR
                    ) {
                        if (mineStatus) {
                            DropdownMenuItem(
                                text = { Text("Sil", color = Color.White, fontSize = 17.sp) },
                                onClick = { menuOpen = false; confirmDelete = true }
                            )
                        } else {
                            val tgt = ChatTarget(Repo.chatId(me.uid, uid), false, uid, p?.name ?: "")
                            val flags by remember(uid) { Repo.chatFlagsFlow(me.uid, Repo.chatId(me.uid, uid)) }.collectAsState(null as Repo.ChatFlags?)
                            @Composable
                            fun Row1(label: String, color: Color = Color.White, act: () -> Unit) {
                                DropdownMenuItem(text = { Text(label, color = color, fontSize = 17.sp) }, onClick = { menuOpen = false; act() })
                            }
                            Row1("Mesaj") { onMessage(tgt) }
                            Row1("Sesli arama") { actions.onCall(tgt, false) }
                            Row1("Görüntülü arama") { actions.onCall(tgt, true) }
                            Row1("Kişiyi görüntüle") { actions.onProfile(tgt) }
                            Row1(if (flags?.muted == true) "Bildirimler al" else "Bildirimleri kapat") {
                                if (flags?.exists == true) Repo.setMuted(me.uid, tgt.chatId, flags?.muted != true)
                                else stToast(ctx, "Önce bir sohbet başlatın")
                            }
                            Row1("Gizle") { actions.onHide(uid); stToast(ctx, "Durumları gizlendi"); onClose() }
                            Row1("Şikayet et") { confirmReport = true }
                        }
                    }
                }
            }
        }

        // açıklama
        if (base.caption.isNotBlank()) {
            Text(
                base.caption, color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 96.dp)
                    .background(Color(0x73000000)).padding(horizontal = 20.dp, vertical = 10.dp)
            )
        }

        // alt: kendi durumum → görüntülenme; başkası → cevap çubuğu
        if (mineStatus) {
            Row(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp)
                    .clip(RoundedCornerShape(50)).clickable { viewersSheet = true }.padding(horizontal = 18.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Visibility, "Görenler", tint = Color.White, modifier = Modifier.size(22.dp))
                Text("  " + cur.viewers.size, color = Color.White, fontSize = 17.sp)
            }
        } else {
            ReplyBar(
                modifier = Modifier.align(Alignment.BottomCenter),
                onFocus = { inputFocus = it },
                onSend = { txt ->
                    scope.launch {
                        val preview = ("Durum: " + base.caption.ifBlank { base.text }.ifBlank { "Fotoğraf" }).take(80)
                        try {
                            Repo.sendText(
                                me,
                                ChatTarget(Repo.chatId(me.uid, uid), false, uid, p?.name ?: ""),
                                txt,
                                ReplyRef(base.id, p?.name ?: "", preview, uid, true)
                            )
                            stToast(ctx, "Cevap gönderildi")
                        } catch (e: Throwable) {
                            stToast(ctx, "Gönderilemedi")
                        }
                    }
                }
            )
        }

        if (viewersSheet) {
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize().background(Color(0x80000000)).clickable { viewersSheet = false })
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                        .background(StPanelR).navigationBarsPadding().padding(top = 16.dp, bottom = 20.dp)
                ) {
                    Row(Modifier.padding(start = 20.dp, end = 20.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Visibility, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Text("  " + cur.viewers.size + " görüntülenme", color = Color.White, fontSize = 15.sp)
                    }
                    if (cur.viewers.isEmpty()) {
                        Text("Henüz kimse görmedi.", color = AuraRawMuted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp))
                    } else {
                        Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                            cur.viewers.forEach { vu -> ViewerRow(vu) }
                        }
                    }
                }
            }
        }
    }

    if (confirmReport) {
        AuraAlertDialog(
            onDismissRequest = { confirmReport = false },
            containerColor = StPanelR,
            title = { Text("Bu durum şikayet edilsin mi?", color = Color.White) },
            confirmButton = {
                TextButton(onClick = {
                    confirmReport = false
                    Repo.reportStatus(me.uid, uid, base.id)
                    stToast(ctx, "Şikayetiniz alındı")
                }) { Text("Şikayet et", color = Color(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { confirmReport = false }) { Text("İptal", color = StRingNew) } }
        )
    }

    if (confirmDelete) {
        AuraAlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = StPanelR,
            title = { Text("Bu durum silinsin mi?", color = Color.White) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    val id = base.id
                    scope.launch {
                        try {
                            Repo.deleteStatus(id)
                            deleted = deleted + id
                            sIdx = minOf(idx, maxOf(0, list.size - 2))
                        } catch (e: Throwable) {
                            stToast(ctx, "Silinemedi")
                        }
                    }
                }) { Text("Sil", color = Color(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("İptal", color = StRingNew) } }
        )
    }
}

@Composable
private fun ViewerRow(uid: String) {
    val prof by liveProfile(uid)
    val p = prof
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(p?.name ?: "", p?.avatar ?: "", 40.dp)
        Text(
            (p?.name ?: "").ifBlank { "Kullanıcı" }, color = Color.White, fontSize = 14.sp,
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}

@Composable
private fun ReplyBar(modifier: Modifier, onFocus: (Boolean) -> Unit, onSend: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    var liked by remember { mutableStateOf(false) }
    Row(
        modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000))))
            .imePadding().navigationBarsPadding()
            .padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier.weight(1f).clip(RoundedCornerShape(50)).background(StBarR).padding(start = 18.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.weight(1f).padding(vertical = 13.dp)) {
                AuraTextField(
                    value = text,
                    onValueChange = { if (it.length <= 500) text = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Color.White),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().onFocusChanged { onFocus(it.isFocused) },
                    decorationBox = { inner ->
                        if (text.isEmpty()) Text("Cevapla", color = AuraRawMuted, fontSize = 16.sp)
                        inner()
                    }
                )
            }
            if (text.isBlank()) {
                Text("😍", fontSize = 26.sp, modifier = Modifier.clickable { onSend("😍") }.padding(horizontal = 8.dp))
                Text("😂", fontSize = 26.sp, modifier = Modifier.clickable { onSend("😂") }.padding(horizontal = 8.dp))
            } else {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(StRingNew).clickable {
                        val t = text
                        text = ""
                        onSend(t)
                    },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.ArrowUpward, "Gönder", tint = Color.White, modifier = Modifier.size(20.dp)) }
            }
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.size(50.dp).clip(CircleShape).background(StBarR).clickable {
                liked = true
                onSend("❤️")
            },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Beğen",
                tint = if (liked) Color(0xFFEF4444) else Color.White, modifier = Modifier.size(24.dp)
            )
        }
    }
}

/** Sohbet listesinde avatara dokununca o kişinin durumlarını tam ekran açar */
@Composable
fun UserStatusViewer(me: UserProfile, uid: String, onMessage: (ChatTarget) -> Unit, onClose: () -> Unit, actions: StatusMenuActions = StatusMenuActions()) {
    val allN by remember { Repo.statusesFlow() }.collectAsState(null as List<StatusItem>?)
    val all = allN ?: return   // veri ilk gelene kadar bekle (eskiden boş liste görünce hemen kapanıyordu)
    val now = System.currentTimeMillis()
    val list = all.filter { it.uid == uid && it.expiresAt > now }.sortedBy { it.createdAt }
    if (list.isEmpty()) { LaunchedEffect(Unit) { onClose() }; return }
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onClose,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            StatusViewer(me = me, groups = listOf(StatusGroup(uid, list)), live = all, startUser = 0, onMessage = { onMessage(it) }, onClose = onClose, actions = actions)
        }
    }
}


/** Durumdaki bağlantı önizleme kartı (hep koyu zemin); onRemove verilirse sağ üstte X çıkar, dokununca bağlantı açılır */
@Composable
private fun StatusLinkCard(lp: com.aurachat.app.data.LinkPreview, onRemove: (() -> Unit)?) {
    val ctx = LocalContext.current
    val host = remember(lp.url) { try { android.net.Uri.parse(lp.url).host?.removePrefix("www.") ?: "" } catch (e: Throwable) { "" } }
    val isVideo = host.contains("tiktok") || host.contains("youtu") || host.contains("vimeo") || host.contains("instagram") || host.contains("facebook") || host.contains("fb.watch") || host.contains("twitch")
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF111B21))
            .clickable(enabled = onRemove == null) {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(lp.url))) } catch (e: Throwable) {}
            }
    ) {
        if (lp.image.isNotBlank()) {
            Box(Modifier.fillMaxWidth().height(if (isVideo) 240.dp else 160.dp), contentAlignment = Alignment.Center) {
                val bmp by produceState<android.graphics.Bitmap?>(null, lp.image) {
                    value = withContext(Dispatchers.IO) {
                        try {
                            val c = java.net.URL(lp.image).openConnection() as java.net.HttpURLConnection
                            c.connectTimeout = 8000; c.readTimeout = 8000
                            c.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) }
                        } catch (e: Throwable) { null }
                    }
                }
                val b = bmp
                if (b != null) androidx.compose.foundation.Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                if (isVideo) Box(Modifier.size(64.dp).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(40.dp))
                }
                if (onRemove != null) Box(
                    Modifier.align(Alignment.TopEnd).padding(10.dp).size(36.dp).clip(CircleShape).background(Color(0x99000000)).clickable { onRemove() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Close, "Kaldır", tint = Color.White, modifier = Modifier.size(20.dp)) }
            }
        }
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            if (lp.title.isNotBlank()) Text(lp.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            if (lp.description.isNotBlank()) Text(lp.description, color = Color(0xFFD1D7DB), fontSize = 13.sp, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            Text(host, color = Color(0xFF9AA5AB), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

/** Başka uygulamadan "Durumum"a paylaşılan metin/bağlantı: yazı durumu ekranı hazır metinle açılır */
@Composable
fun StatusTextComposerHost(me: UserProfile, initial: String, onClose: () -> Unit) {
    AuraDarkIsland { StatusComposer(me, ComposerReq("text", null, initial), onClose = onClose) }
}

package com.aurachat.app.ui

import androidx.compose.ui.graphics.compositeOver
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.material.icons.filled.ArrowUpward
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.combinedClickable
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.aurachat.app.data.ChatSummary
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Media
import com.aurachat.app.data.ReplyRef
import com.aurachat.app.data.Repo
import com.aurachat.app.data.StatusItem
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

private val StBgColors = listOf(
    "#128c7e", "#075e54", "#6a1b9a", "#c2185b", "#d84315",
    "#1565c0", "#37474f", "#2e7d32", "#ad1457", "#4527a0",
    "#4f6fd8", "#c0a030", "#e53935", "#00897b", "#6d4c41"
)
/** Durum görüntüleyicideki üç nokta menüsünün dış işlemleri (arama, profil, gizleme) */
class StatusMenuActions(
    val onCall: (ChatTarget, Boolean) -> Unit = { _, _ -> },
    val onProfile: (ChatTarget) -> Unit = {},
    val onHide: (String) -> Unit = {},
    val onAddMusic: (StatusMusic) -> Unit = {}
)

private val StPanel: Color get() = auraC(0xFF202C33)
private val StMenuBg: Color get() = auraC(0xFF111B21)
private val StBar: Color get() = auraC(0xFF1F2C34)
private val StPanelR: Color get() = auraCRaw(0xFF202C33)
private val StMenuBgR: Color get() = auraCRaw(0xFF111B21)
private val StBarR: Color get() = auraCRaw(0xFF1F2C34)
private val StRingNew: Color get() = auraLc(0xFF22C55E)
private val StRingSeen: Color get() = auraLc(0xFF6B7280)

private fun stToast(ctx: android.content.Context, s: String) =
    Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

internal fun parseBg(s: String): Color =
    try { Color(android.graphics.Color.parseColor(s.substringBefore('|'))) } catch (e: Throwable) { auraLc(0xFF128C7E) }

private fun bgFont(s: String): Int = (s.substringAfter('|', "0").toIntOrNull() ?: 0).coerceIn(0, StFontFamilies.size - 1)

fun statusTimeLabel(ms: Long): String {
    val diff = System.currentTimeMillis() - ms
    if (diff < 60_000L) return "Az önce"
    if (diff < 3_600_000L) return (diff / 60_000L).toString() + " dk önce"
    val a = Calendar.getInstance().apply { timeInMillis = ms }
    val b = Calendar.getInstance()
    val same = a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    if (same) return "Bugün " + formatClock(ms)
    val y = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    if (a.get(Calendar.YEAR) == y.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)) return "Dün " + formatClock(ms)
    return java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale("tr")).format(java.util.Date(ms))
}

private data class StatusGroup(val uid: String, val list: List<StatusItem>)
private data class ViewerReq(val groups: List<StatusGroup>, val start: Int)
private data class ComposerReq(val mode: String, val uri: Uri?, val initial: String = "", val art: String? = null, val music: StatusMusic? = null)

@Composable
private fun sPx(n: Float): Dp = (n / androidx.compose.ui.platform.LocalDensity.current.density).dp

@Composable
private fun sSp(n: Float): androidx.compose.ui.unit.TextUnit = with(androidx.compose.ui.platform.LocalDensity.current) { n.toSp() }

/** "Durum ekle" kartı (WhatsApp): açık gri zemin, ince kenar, ortada 133px avatar ve sağ altında + rozeti, altta yazı */
@Composable
private fun StatusAddCard(me: UserProfile, onOpen: () -> Unit, onAdd: () -> Unit) {
    val light = AuraUi.lightReal
    Box(
        Modifier.width(sPx(231f)).height(sPx(411f)).clip(RoundedCornerShape(sPx(40f)))
            .background(if (light) Color(0xFFF6F5F3) else AuraSurface)
            .border(sPx(2f), if (light) Color(0xFFC8CAC9) else Color(0xFF2A2F33), RoundedCornerShape(sPx(40f)))
            .clickable(onClick = onOpen)
    ) {
        Box(Modifier.align(Alignment.TopCenter).padding(top = sPx(77f)).size(sPx(133f))) {
            Avatar(me.name, me.avatar, sPx(133f))
            Box(
                Modifier.align(Alignment.BottomEnd).size(sPx(56f)).clip(CircleShape)
                    .background(AuraUi.accentColor() ?: Color(0xFF185F3F)).clickable(onClick = onAdd),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Add, "Durum ekle", tint = Color.White, modifier = Modifier.size(sPx(36f))) }
        }
        Text(
            "Durum ekle", color = AuraWhite, fontSize = sSp(42f), lineHeight = sSp(52f), textAlign = TextAlign.Center,
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = sPx(10f), end = sPx(10f), bottom = sPx(26f))
        )
    }
}

/** Kişinin durum kartı (WhatsApp): arkada son durumun görseli / yazı rengi, sol üstte halkalı avatar, sol altta beyaz ad */
@Composable
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
private fun StatusUserCard(name: String, avatar: String, item: StatusItem, ring: Color, onLongClick: (() -> Unit)? = null, onClick: () -> Unit) {
    val shape = RoundedCornerShape(sPx(40f))
    Box(
        Modifier.width(sPx(231f)).height(sPx(411f)).clip(shape)
            .background(if (item.type == "text") parseBg(item.bg) else Color(0xFF202C33))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        if (item.type == "text") {
            Text(
                item.text, color = Color.White, fontSize = sSp(36f), lineHeight = sSp(44f), textAlign = TextAlign.Center,
                maxLines = 5, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.Center).padding(horizontal = sPx(20f))
            )
        } else {
            val media by androidx.compose.runtime.produceState<String?>(Repo.peekStatusMedia(item.id), item.id) {
                if (value == null) value = Repo.loadStatusMedia(item.id)
            }
            val m = media
            if (!m.isNullOrEmpty()) DataUrlImage(m, 600, Modifier.fillMaxSize(), ContentScale.Crop)
        }
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(sPx(190f))
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000))))
        )
        Box(
            Modifier.padding(start = sPx(17f), top = sPx(17f)).size(sPx(143f)).border(sPx(5.5f), ring, CircleShape),
            contentAlignment = Alignment.Center
        ) { Avatar(name, avatar, sPx(122f)) }
        Text(
            name, color = Color.White, fontSize = sSp(34f), lineHeight = sSp(42f), maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = sPx(24f), end = sPx(16f), bottom = sPx(24f))
        )
    }
}

@Composable
private fun RingAvatar(name: String, avatar: String, size: Dp, ring: Color?) {
    val outer = size + 10.dp
    Box(
        Modifier.size(outer).then(if (ring != null) Modifier.border(2.5.dp, ring, CircleShape) else Modifier),
        contentAlignment = Alignment.Center
    ) { Avatar(name, avatar, size) }
}

// =====================================================================
//  DURUM SEKMESİ
// =====================================================================
@Composable
fun StatusScreen(
    me: UserProfile,
    onFullscreen: (Boolean) -> Unit,
    onMessage: (ChatTarget) -> Unit,
    onCall: (ChatTarget, Boolean) -> Unit = { _, _ -> },
    onProfile: (ChatTarget) -> Unit = {}
) {
    val ctx = LocalContext.current
    var hidden by remember { mutableStateOf(ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).getStringSet("status_hidden", emptySet()) ?: emptySet()) }
    fun setHidden(n: Set<String>) {
        hidden = n
        ctx.getSharedPreferences("aura", android.content.Context.MODE_PRIVATE).edit().putStringSet("status_hidden", n).apply()
    }
    val all by remember { Repo.statusesFlow() }.collectAsState(emptyList<StatusItem>())
    val chats by remember(me.uid) { Repo.chatsFlow(me.uid) }.collectAsState(null as List<ChatSummary>?)
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(me.uid) {
        Repo.cleanupMyStatuses(me.uid)
        while (true) {
            delay(30_000)
            now = System.currentTimeMillis()
        }
    }

    val active = all.filter { it.expiresAt > now }
    val mine = active.filter { it.uid == me.uid }.sortedBy { it.createdAt }
    val seeable: Set<String>? = chats?.filter { !it.isGroup }?.map { it.otherUid }?.toSet()
    val groups = active
        .filter { it.uid != me.uid && !hidden.contains(it.uid) && (seeable == null || seeable.contains(it.uid)) }
        .groupBy { it.uid }
        .map { (uid, l) -> StatusGroup(uid, l.sortedBy { it.createdAt }) }
        .sortedWith(
            compareByDescending<StatusGroup> { g -> g.list.any { !it.viewers.contains(me.uid) } }
                .thenByDescending { g -> g.list.last().createdAt }
        )

    var viewer by remember { mutableStateOf<ViewerReq?>(null) }
    var composer by remember { mutableStateOf<ComposerReq?>(null) }
    var musicPick by remember { mutableStateOf(false) }
    var manage by remember { mutableStateOf(false) }
    var cardMenu by remember { mutableStateOf(false) }
    var confirmRemoveAll by remember { mutableStateOf(false) }
    var musicTarget by remember { mutableStateOf<StatusItem?>(null) }
    var pendingMusic by remember { mutableStateOf<StatusMusic?>(null) }
    androidx.compose.runtime.LaunchedEffect(StatusManageHolder.request) { if (StatusManageHolder.request) { StatusManageHolder.request = false; manage = true } }
    var layoutPick by remember { mutableStateOf(false) }
    var collageUris by remember { mutableStateOf<List<Uri>?>(null) }
    val musicScope = rememberCoroutineScope()
    var addSheet by remember { mutableStateOf(false) }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) composer = ComposerReq("image", uri, "", null, pendingMusic)
        pendingMusic = null
    }
    var camUri by remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri
        if (ok && u != null) composer = ComposerReq("image", u)
    }
    fun openCamera() {
        try {
            val dir = File(ctx.cacheDir, "camera").also { it.mkdirs() }
            val f = File(dir, "status_${System.currentTimeMillis()}.jpg")
            val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            camUri = u
            camera.launch(u)
        } catch (e: Throwable) {
            stToast(ctx, "Kamera açılamadı")
        }
    }
    fun openGallery() {
        gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    BackHandler(enabled = addSheet) { addSheet = false }
    val full = viewer != null || composer != null || addSheet
    LaunchedEffect(full) { onFullscreen(full) }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { onFullscreen(false) } }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // WhatsApp "Güncellemeler" sayfası ölçüleri (1080px ekran görüntüsünden): başlık 64px, kartlar 231x411px, aralık 17px, köşe 40px
            Text(
                "Güncellemeler", color = AuraWhite, fontSize = sSp(64f), lineHeight = sSp(76f),
                modifier = Modifier.padding(start = sPx(45f), top = sPx(30f))
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(Modifier.fillMaxSize()) {
                    item {
                        Text(
                            "Durum", color = AuraWhite, fontSize = sSp(64f), lineHeight = sSp(76f),
                            modifier = Modifier.padding(start = sPx(45f), top = sPx(70f))
                        )
                    }
                    item {
                        androidx.compose.foundation.lazy.LazyRow(
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = sPx(44f), end = sPx(44f), top = sPx(30f)),
                            horizontalArrangement = Arrangement.spacedBy(sPx(17f))
                        ) {
                            item {
                                if (mine.isEmpty()) StatusAddCard(me, onOpen = { addSheet = true }, onAdd = { addSheet = true })
                                else Box {
                                    StatusUserCard("Durumum", me.avatar, mine.last(), StRingNew) { cardMenu = true }
                                    AuraDropdownMenu(
                                        expanded = cardMenu, onDismissRequest = { cardMenu = false },
                                        containerColor = StMenuBgR, alignEnd = false, forceDark = true, floating = true, yGap = 5.dp
                                    ) {
                                        @Composable
                                        fun CItem(label: String, color: Color = Color.White, act: () -> Unit) {
                                            AuraMI(
                                                text = { Text(label, color = color, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) },
                                                onClick = { cardMenu = false; act() }
                                            )
                                        }
                                        CItem("Durum ekle") { addSheet = true }
                                        CItem("Görüntüle") { viewer = ViewerReq(listOf(StatusGroup(me.uid, mine)), 0) }
                                        CItem("Düzenle") { manage = true }
                                        CItem("Kaldır", Color(0xFFEF4444)) { confirmRemoveAll = true }
                                    }
                                }
                            }
                            items(groups, key = { it.uid }) { g ->
                                val prof by liveProfile(g.uid)
                                val p = prof
                                val unseen = g.list.any { !it.viewers.contains(me.uid) }
                                StatusUserCard(p?.name ?: "", p?.avatar ?: "", g.list.last(), if (unseen) StRingNew else StRingSeen) {
                                    viewer = ViewerReq(groups, groups.indexOfFirst { it.uid == g.uid }.coerceAtLeast(0))
                                }
                            }
                        }
                    }
                    if (hidden.isNotEmpty()) {
                        item(key = "hidden-h") {
                            Text(
                                "GİZLENEN DURUMLAR", color = AuraMuted, fontSize = 13.sp, letterSpacing = 0.5.sp,
                                modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 6.dp)
                            )
                        }
                        items(hidden.toList(), key = { "hid-$it" }) { hu ->
                            val hp by liveProfile(hu)
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Avatar(hp?.name ?: "?", hp?.avatar ?: "", 44.dp)
                                Text(hp?.name ?: "", color = AuraWhite, fontSize = 16.sp, modifier = Modifier.weight(1f).padding(start = 14.dp))
                                Text(
                                    "Göster", color = StRingNew, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { setHidden(hidden - hu) }.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
                Column(
                    Modifier.align(Alignment.BottomEnd).padding(end = 22.dp, bottom = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Box(
                        Modifier.size(46.dp).softCircle().clickable { composer = ComposerReq("text", null) },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Edit, "Yazı durumu", tint = ChipLook.fg, modifier = Modifier.size(22.dp)) }
                    Box(
                        Modifier.size(66.dp).softCircle().clickable { addSheet = true },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.CameraAlt, "Kamera", tint = ChipLook.fg, modifier = Modifier.size(30.dp)) }
                }
            }
        }

        if (addSheet) {
            AddStatusSheet(
                onClose = { addSheet = false },
                onCamera = { addSheet = false; openCamera() },
                onText = { addSheet = false; composer = ComposerReq("text", null) },
                onPick = { u ->
                    val isVideo = (ctx.contentResolver.getType(u) ?: "").startsWith("video")
                    if (isVideo) stToast(ctx, "Video durumu yakında")
                    else { addSheet = false; composer = ComposerReq("image", u) }
                },
                onSoon = { stToast(ctx, "$it yakında") },
                onMusic = { musicPick = true },
                onLayout = { layoutPick = true }
            )
        }
        if (layoutPick) {
            StatusLayoutPicker(onClose = { layoutPick = false }, onDone = { l -> layoutPick = false; collageUris = l })
        }
        val cu = collageUris
        if (cu != null) {
            AuraDarkIsland {
                StatusCollageEditor(
                    uris = cu, onBack = { collageUris = null },
                    onDone = { d -> collageUris = null; addSheet = false; composer = ComposerReq("image", null, "", d) }
                )
            }
        }
        if (musicPick) {
            StatusMusicSheet(
                currentUrl = null,
                onDismiss = { musicPick = false },
                onPick = { t ->
                    musicScope.launch {
                        val d = buildMusicArt(t)
                        if (d == null) stToast(ctx, "Kapak yüklenemedi")
                        else { addSheet = false; composer = ComposerReq("image", null, "", d, t.copy(art = true, x = 0.5f, y = 0.42f, rot = 0f, scale = 1f)) }
                    }
                }
            )
        }

        if (manage) {
            AuraDarkIsland {
                MyStatusManager(mine, onOpen = { id -> manage = false; StatusStartHolder.id = id; viewer = ViewerReq(listOf(StatusGroup(me.uid, mine)), 0) }, onChangeMusic = { musicTarget = it }, onClose = { manage = false })
            }
        }
        val mt = musicTarget
        if (mt != null) {
            StatusMusicSheet(
                currentUrl = mt.music?.preview,
                onDismiss = { MusicPreview.stop(); musicTarget = null },
                onPick = { t ->
                    MusicPreview.stop()
                    musicTarget = null
                    musicScope.launch {
                        val o = mt.music
                        val nm = if (o != null) t.copy(x = o.x, y = o.y, rot = o.rot, scale = o.scale, art = o.art) else t.copy(art = false, x = 0.5f, y = 0.18f, rot = 0f, scale = 1f)
                        try { Repo.updateStatusMusic(mt.id, nm); stToast(ctx, "Müzik değiştirildi") } catch (e: Throwable) { stToast(ctx, "Değiştirilemedi") }
                    }
                },
                resumeOnDismiss = false
            )
        }
        if (confirmRemoveAll) {
            AuraAlertDialog(
                onDismissRequest = { confirmRemoveAll = false },
                containerColor = StPanelR,
                title = { Text("Tüm durumların silinsin mi?", color = Color.White) },
                confirmButton = {
                    TextButton(onClick = {
                        confirmRemoveAll = false
                        val ids = mine.map { it.id }
                        musicScope.launch { for (id in ids) { try { Repo.deleteStatus(id) } catch (e: Throwable) { stToast(ctx, "Silinemedi") } } }
                    }) { Text("Sil", color = AuraDialogBtn) }
                },
                dismissButton = { TextButton(onClick = { confirmRemoveAll = false }) { Text("İptal", color = StRingNew) } }
            )
        }

        val cr = composer
        if (cr != null) {
            AuraDarkIsland { StatusComposer(me, cr, onClose = { composer = null }) }
        }

        val vr = viewer
        if (vr != null) {
            AuraDarkIsland {
                StatusViewer(
                    me = me, groups = vr.groups, live = all, startUser = vr.start,
                    onMessage = { viewer = null; onMessage(it) },
                    onClose = { viewer = null },
                    actions = StatusMenuActions(
                        onCall = { t, v -> viewer = null; onCall(t, v) },
                        onProfile = { viewer = null; onProfile(it) },
                        onHide = { setHidden(hidden + it) },
                        onAddMusic = { m ->
                            viewer = null
                            pendingMusic = m.copy(art = false, x = 0.5f, y = 0.18f, rot = 0f, scale = 1f)
                            openGallery()
                        }
                    )
                )
            }
        }
    }
}

/** WhatsApp tarzı "Durum ekleyin" sayfası: üstte seçenek düğmeleri, altta albüm seçimi ve galeri ızgarası */
@Composable
private fun AddStatusSheet(
    onClose: () -> Unit, onCamera: () -> Unit, onText: () -> Unit, onPick: (Uri) -> Unit, onSoon: (String) -> Unit, onMusic: () -> Unit, onLayout: () -> Unit
) {
    var album by remember { mutableStateOf<String?>(null) }
    var albums by remember { mutableStateOf<List<Pair<String, Int>>>(emptyList()) }
    var albumMenu by remember { mutableStateOf(false) }
    val musicCtx = androidx.compose.ui.platform.LocalContext.current
    val bg = auraC(0xFF1A1F24)
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(auraLc(0x8C000000)).clickable { onClose() })
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxSize().statusBarsPadding().padding(top = 10.dp)
                .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)).background(bg)
        ) {
            Box(Modifier.fillMaxWidth().padding(top = 10.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.width(40.dp).height(4.dp).clip(CircleShape).background(auraLc(0xFF6B7280)))
            }
            Box(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 18.dp).height(48.dp)) {
                IconButton(onClick = onClose, modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp)) {
                    Icon(Icons.Default.Close, "Kapat", tint = AuraWhite)
                }
                Text("Durum ekleyin", color = AuraWhite, fontSize = 22.sp, modifier = Modifier.align(Alignment.Center))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf(
                    Triple("Metin", Icons.Default.Edit, onText),
                    Triple("Müzik", Icons.Default.MusicNote, { onMusic() }),
                    Triple("Yerleşim", Icons.Default.GridView, { onLayout() }),
                    Triple("Ses", Icons.Default.Mic, { onSoon("Ses") })
                ).forEach { (label, icon, act) ->
                    Column(Modifier.weight(1f).clickable(
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null
                    ) { act() }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.width(74.dp).height(54.dp).clip(RoundedCornerShape(27.dp)).background(auraC(0xFF2B3036)), contentAlignment = Alignment.Center) {
                            Icon(icon, label, tint = AuraWhite, modifier = Modifier.size(26.dp))
                        }
                        Text(label, color = auraLc(0xFFE5E7EB), fontSize = 17.sp, modifier = Modifier.padding(top = 10.dp))
                    }
                }
            }
            Box(Modifier.padding(start = 20.dp, top = 22.dp, bottom = 12.dp)) {
                Row(Modifier.clip(RoundedCornerShape(10.dp)).clickable { albumMenu = true }.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(album ?: "Son kullanılanlar", color = auraLc(0xFFD1D5DB), fontSize = 22.sp, fontWeight = FontWeight.Medium)
                    Icon(Icons.Default.KeyboardArrowDown, null, tint = auraLc(0xFFD1D5DB), modifier = Modifier.padding(start = 6.dp).size(26.dp))
                }
                AuraDropdownMenu(expanded = albumMenu, onDismissRequest = { albumMenu = false }, containerColor = StMenuBg, alignEnd = false) {
                    DropdownMenuItem(text = { Text("Son kullanılanlar", color = AuraWhite) }, onClick = { album = null; albumMenu = false })
                    albums.forEach { (n, c) ->
                        DropdownMenuItem(text = { Text("$n  ($c)", color = AuraWhite) }, onClick = { album = n; albumMenu = false })
                    }
                }
            }
            GalleryStrip(
                accent = StRingNew, maxPick = 1, selected = emptyList(),
                onSelected = { l -> l.firstOrNull()?.let { onPick(it) } },
                modifier = Modifier.weight(1f), grid = true, album = album, onAlbums = { albums = it },
                columns = 3,
                leading = {
                    Column(
                        Modifier.fillMaxSize().background(auraC(0xFF11161A)).clickable { onCamera() },
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.CameraAlt, "Kamera", tint = StRingNew, modifier = Modifier.size(40.dp))
                        Text("Kamera", color = AuraMuted, fontSize = 20.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            )
        }
    }
}

// =====================================================================
//  OLUŞTURUCU (yazı / fotoğraf)
// =====================================================================
@Composable
private fun StatusComposer(me: UserProfile, req: ComposerReq, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val isText = req.mode == "text"
    var bgIdx by remember { mutableIntStateOf((System.currentTimeMillis() % StBgColors.size).toInt()) }
    var fontIdx by remember { mutableIntStateOf(0) }
    var fontMode by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf(req.initial.take(300)) }
    var caption by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    // metindeki ilk bağlantı için önizleme kartı (TikTok / YouTube / Facebook ...), X ile kaldırılır
    val linkUrl = remember(text) { Regex("https?://\\S+").find(text)?.value?.trimEnd('.', ',', ')') ?: "" }
    var link by remember { mutableStateOf<com.aurachat.app.data.LinkPreview?>(null) }
    var dismissedUrl by remember { mutableStateOf("") }
    LaunchedEffect(linkUrl) {
        if (linkUrl.isEmpty()) { link = null; return@LaunchedEffect }
        if (linkUrl == dismissedUrl || link?.url == linkUrl) return@LaunchedEffect
        delay(500)
        link = try { Repo.fetchLinkPreview(linkUrl) } catch (e: Throwable) { null }
    }

    val image by produceState<String?>(req.art, req.uri) {
        if (!isText && req.art == null && req.uri != null) {
            val d = withContext(Dispatchers.IO) { Media.compress(ctx, req.uri, 300 * 1024) }
            if (d == null) {
                stToast(ctx, "Fotoğraf açılamadı")
                onClose()
            } else value = d
        }
    }

    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        if (isText) {
            delay(100)
            try { focus.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("StatusScreens", e) }
        }
    }
    BackHandler { onClose() }

    fun send() {
        if (busy) return
        val t = text.trim()
        if (isText && t.isEmpty()) {
            stToast(ctx, "Önce bir şey yazın")
            return
        }
        if (!isText && image == null) return
        busy = true
        scope.launch {
            try {
                if (isText) Repo.postStatus(me, "text", t, StBgColors[bgIdx] + "|" + fontIdx, "", null, if (linkUrl.isNotEmpty() && linkUrl != dismissedUrl) link else null)
                else Repo.postStatus(me, "image", "", "", caption.trim(), image)
                stToast(ctx, "Durum paylaşıldı")
                onClose()
            } catch (e: Throwable) {
                busy = false
                stToast(ctx, "Paylaşılamadı, tekrar deneyin")
            }
        }
    }

    if (!isText) {
        val img = image
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (img == null) CircularProgressIndicator(color = Color.White, modifier = Modifier.align(Alignment.Center))
            else StatusPhotoEditor(
                imageData = img, busy = busy, onClose = onClose, initialMusic = req.music,
                onSoon = { stToast(ctx, "$it yakında eklenecek") },
                onSend = { list ->
                    if (!busy) {
                        busy = true
                        scope.launch {
                            try {
                                Repo.postStatusImages(me, list.map { it.first to it.second })
                                stToast(ctx, "Durum paylaşıldı")
                                onClose()
                            } catch (e: Throwable) {
                                busy = false
                                stToast(ctx, "Paylaşılamadı, tekrar deneyin")
                            }
                        }
                    }
                }
            )
        }
        return
    }
    Box(Modifier.fillMaxSize().background(if (isText) parseBg(StBgColors[bgIdx]) else Color.Black)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (isText) {
                    val fm = LocalFocusManager.current
                    Box(
                        Modifier.height(48.dp).clip(RoundedCornerShape(50)).background(Color.White)
                            .clickable { if (text.isBlank()) onClose() else fm.clearFocus() }.padding(horizontal = 30.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("Bitti", color = Color(0xFF111B21), fontSize = 18.sp) }
                } else IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Kapat", tint = Color.White) }
                Spacer(Modifier.weight(1f))
                if (isText) {
                    Box(
                        Modifier.size(48.dp).clip(CircleShape).background(Color(0x66000000)).clickable { fontMode = !fontMode },
                        contentAlignment = Alignment.Center
                    ) {
                        if (fontMode) Icon(Icons.Default.Palette, "Renk", tint = Color.White)
                        else Text("Aa", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp), contentAlignment = Alignment.Center) {
                if (isText) {
                  Column(Modifier.fillMaxWidth().verticalScroll(androidx.compose.foundation.rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    val lk = link
                    if (lk != null && linkUrl.isNotEmpty() && linkUrl != dismissedUrl) {
                        StatusLinkCard(lk, onRemove = { dismissedUrl = linkUrl; link = null })
                        Spacer(Modifier.height(20.dp))
                    }
                    AuraTextField(
                        value = text,
                        onValueChange = { if (it.length <= 300) text = it },
                        textStyle = TextStyle(color = Color.White, fontSize = if (linkUrl.isNotEmpty()) 24.sp else 30.sp, textAlign = TextAlign.Center,
                            fontFamily = StFontFamilies[fontIdx], fontWeight = StFontWeights[fontIdx], fontStyle = StFontStyles[fontIdx],
                            textDecoration = if (text.trim() == linkUrl && linkUrl.isNotEmpty()) androidx.compose.ui.text.style.TextDecoration.Underline else null),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.fillMaxWidth().focusRequester(focus),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.Center) {
                                if (text.isEmpty()) Text("Durum yazın", color = Color(0x66FFFFFF), fontSize = 30.sp, textAlign = TextAlign.Center, fontFamily = StFontFamilies[fontIdx], fontWeight = StFontWeights[fontIdx], fontStyle = StFontStyles[fontIdx])
                                inner()
                            }
                        }
                    )
                  }
                } else {
                    val img = image
                    if (img == null) CircularProgressIndicator(color = Color.White)
                    else DataUrlImage(img, 1600, Modifier.fillMaxSize(), ContentScale.Fit)
                }
            }
            if (isText) {
                androidx.compose.foundation.lazy.LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp)
                ) {
                    if (!fontMode) {
                        itemsIndexed(StBgColors) { i, c ->
                            Box(
                                Modifier.size(46.dp).clip(CircleShape).background(parseBg(c))
                                    .border(if (i == bgIdx) 3.dp else 1.dp, if (i == bgIdx) Color.White else Color(0x55FFFFFF), CircleShape)
                                    .clickable { bgIdx = i }
                            )
                        }
                    } else {
                        itemsIndexed(StFontFamilies) { i, _ ->
                            val on = i == fontIdx
                            Box(
                                Modifier.size(46.dp).clip(CircleShape).background(if (on) Color.White else Color(0x66000000)).clickable { fontIdx = i },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Aa", color = if (on) Color(0xFF111B21) else Color.White, fontSize = 18.sp,
                                    fontFamily = StFontFamilies[i], fontWeight = StFontWeights[i], fontStyle = StFontStyles[i])
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                if (!isText) {
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(50)).background(StPanelR)
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        AuraTextField(
                            value = caption,
                            onValueChange = { if (it.length <= 200) caption = it },
                            textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                            cursorBrush = SolidColor(Color.White),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            decorationBox = { inner ->
                                if (caption.isEmpty()) Text("Açıklama ekleyin...", color = AuraRawMuted, fontSize = 15.sp)
                                inner()
                            }
                        )
                    }
                } else {
                    Box(Modifier.clip(RoundedCornerShape(50)).background(StPanelR).padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Text("Durum (tüm kişiler)", color = Color.White, fontSize = 15.sp)
                    }
                    Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.width(10.dp))
                Box(
                    Modifier.size(52.dp).clip(CircleShape).background(StRingNew.copy(alpha = if (busy) 0.6f else 1f))
                        .clickable { send() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.ArrowUpward, "Paylaş", tint = Color.White) }
            }
        }
    }
}

// =====================================================================
//  GÖRÜNTÜLEYİCİ
// =====================================================================
/** Durum görüntüleyici: kullanıcılar arası geçiş parmağı izleyen küp efektiyle (iki yüz aynı anda görünür) */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun StatusViewer(
    me: UserProfile,
    groups: List<StatusGroup>,
    live: List<StatusItem>,
    startUser: Int,
    onMessage: (ChatTarget) -> Unit,
    onClose: () -> Unit,
    actions: StatusMenuActions = StatusMenuActions()
) {
    val pager = androidx.compose.foundation.pager.rememberPagerState(initialPage = startUser.coerceIn(0, groups.size - 1)) { groups.size }
    val scope = rememberCoroutineScope()
    val camDist = 14f * androidx.compose.ui.platform.LocalDensity.current.density
    ForceLightBarIcons()
    HideStatusBar()
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        androidx.compose.foundation.pager.HorizontalPager(
            state = pager, modifier = Modifier.fillMaxSize(), key = { groups[it].uid }
        ) { page ->
            Box(
                Modifier.fillMaxSize().graphicsLayer {
                    val off = (pager.currentPage - page) + pager.currentPageOffsetFraction   // sağdaki sayfa: negatif
                    rotationY = -90f * off.coerceIn(-1f, 1f)
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(if (off < 0f) 0f else 1f, 0.5f)
                    cameraDistance = camDist
                }
            ) {
                StatusUserPage(
                    me = me, group = groups[page], live = live,
                    isCurrent = pager.currentPage == page && !pager.isScrollInProgress,
                    hasNext = page < groups.size - 1, hasPrev = page > 0,
                    onUser = { d ->
                        scope.launch {
                            pager.animateScrollToPage(
                                (pager.currentPage + d).coerceIn(0, groups.size - 1),
                                animationSpec = androidx.compose.animation.core.tween(380)
                            )
                        }
                    },
                    onMessage = onMessage, onClose = onClose, actions = actions
                )
            }
        }
    }
}

@Composable
private fun StatusUserPage(
    me: UserProfile,
    group: StatusGroup,
    live: List<StatusItem>,
    isCurrent: Boolean,
    hasNext: Boolean,
    hasPrev: Boolean,
    onUser: (Int) -> Unit,
    onMessage: (ChatTarget) -> Unit,
    onClose: () -> Unit,
    actions: StatusMenuActions = StatusMenuActions()
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirmReport by remember { mutableStateOf(false) }
    var notifAsk by remember { mutableStateOf(false) }
    var stNotifOn by remember { mutableStateOf(false) }
    var deleted by remember { mutableStateOf<Set<String>>(emptySet()) }
    var sIdx by remember {
        mutableIntStateOf(
            run {
                val g = group
                val wanted = StatusStartHolder.take()
                val wi = if (wanted != null) g.list.indexOfFirst { it.id == wanted } else -1
                if (wi >= 0) wi else if (g.uid == me.uid) 0 else maxOf(0, g.list.indexOfFirst { !it.viewers.contains(me.uid) })
            }
        )
    }
    var progress by remember { mutableFloatStateOf(0f) }
    var hold by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var viewersSheet by remember { mutableStateOf(false) }
    var musicInfo by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var inputFocus by remember { mutableStateOf(false) }
    var replyMode by remember { mutableStateOf(false) }
    val focusMgr = androidx.compose.ui.platform.LocalFocusManager.current

    val list = group.list.filter { !deleted.contains(it.id) }
    if (list.isEmpty()) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    val idx = sIdx.coerceIn(0, list.size - 1)
    val base = list[idx]
    val cur = live.firstOrNull { it.id == base.id } ?: base
    val uid = group.uid
    val mineStatus = uid == me.uid

    fun next() {
        if (idx < list.size - 1) { progress = 0f; sIdx = idx + 1 }
        else if (hasNext) onUser(1)
        else onClose()
    }
    fun prev() {
        if (idx > 0) { progress = 0f; sIdx = idx - 1 }
        else if (hasPrev) onUser(-1)
        else progress = 0f
    }
    val nextFn = rememberUpdatedState(newValue = { next() })
    val prevFn = rememberUpdatedState(newValue = { prev() })
    val closeFn = rememberUpdatedState(newValue = onClose)

    val paused = !isCurrent || hold || menuOpen || viewersSheet || musicInfo || confirmDelete || inputFocus || replyMode
    val pausedState = rememberUpdatedState(newValue = paused)

    val mediaPair by produceState<Pair<String, String>?>(null, base.id) {
        value = base.id to (if (base.type == "image") Repo.loadStatusMedia(base.id) else "")
    }
    // önbellekte varsa / metin durumuysa ilk karede hazır: siyah yükleme sayfası çıkmasın
    val media: String? = mediaPair?.takeIf { it.first == base.id }?.second
        ?: (if (base.type != "image") "" else Repo.peekStatusMedia(base.id))
    val loaded = media != null

    LaunchedEffect(isCurrent, idx, loaded) {
        progress = 0f
        if (!loaded || !isCurrent) return@LaunchedEffect
        val dur = if (base.type == "text") 5000f else 6000f
        var last = androidx.compose.runtime.withFrameNanos { it }
        while (progress < 1f) {
            val t = androidx.compose.runtime.withFrameNanos { it }
            if (!pausedState.value) progress = (progress + (t - last) / 1_000_000f / dur).coerceAtMost(1f)
            last = t
        }
        nextFn.value()
    }

    // görüldü işaretle + sonrakini önden yükle
    LaunchedEffect(base.id, isCurrent) {
        if (!isCurrent) return@LaunchedEffect
        if (!mineStatus && !base.viewers.contains(me.uid)) Repo.markStatusViewed(base.id, me.uid)
        list.getOrNull(idx + 1)?.let { if (it.type == "image") Repo.loadStatusMedia(it.id) }
    }

    val live by liveProfile(if (uid == me.uid) "" else uid)
    val prof = if (uid == me.uid) me else live
    val p = prof?.takeIf { it.uid == uid }
    val ownerName = if (mineStatus) "Durumum" else (p?.name ?: "")

    BackHandler(enabled = isCurrent) { onClose() }
    BackHandler(enabled = isCurrent && viewersSheet) { viewersSheet = false }
    BackHandler(enabled = isCurrent && replyMode) { replyMode = false; focusMgr.clearFocus() }

    val stageBg = if (base.type == "text") parseBg(base.bg) else Color.Black
    val baseMusic = base.music

    Box(
        Modifier.fillMaxSize()
            .background(stageBg)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        hold = true
                        tryAwaitRelease()
                        hold = false
                    },
                    onTap = { o -> if (o.x < size.width * 0.35f) prevFn.value() else nextFn.value() }
                )
            }
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { if (acc > 300f) closeFn.value() else if (acc < -150f && !mineStatus) replyMode = true },
                    onVerticalDrag = { _, dy -> acc += dy }
                )
            }
    ) {
        // sahne
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (base.type == "text") {
                Column(Modifier.padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    val lk = base.link
                    if (lk != null) {
                        StatusLinkCard(lk, onRemove = null)
                        Spacer(Modifier.height(20.dp))
                    }
                    Text(base.text, color = Color.White, fontSize = if (lk != null) 22.sp else 30.sp, textAlign = TextAlign.Center, fontFamily = StFontFamilies[bgFont(base.bg)], fontWeight = StFontWeights[bgFont(base.bg)], fontStyle = StFontStyles[bgFont(base.bg)])
                }
            } else {
                when {
                    media == null -> CircularProgressIndicator(color = Color.White)
                    media.isEmpty() -> Text("Fotoğraf yüklenemedi", color = AuraRawMuted, fontSize = 14.sp)
                    else -> DataUrlImage(media, 1600, Modifier.fillMaxSize(), ContentScale.Fit)
                }
            }
        }

        // müzik kartı + önizleme sesi
        if (baseMusic != null && base.type == "image") {
            StatusMusicViewerLayer(baseMusic, isCurrent, hold)
        }

        // üst: ilerleme çubukları + başlık
        Column(
            Modifier.fillMaxWidth().align(Alignment.TopCenter)
                .background(Brush.verticalGradient(listOf(Color(0x8C000000), Color.Transparent)))
                .statusBarsPadding().padding(start = 10.dp, end = 4.dp, top = 10.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(end = 6.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                list.forEachIndexed { i, _ ->
                    val f = if (i < idx) 1f else if (i == idx) progress else 0f
                    Box(Modifier.weight(1f).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x59FFFFFF))) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(f.coerceIn(0f, 1f)).background(Color.White))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
                Avatar(ownerName, if (mineStatus) me.avatar else (p?.avatar ?: ""), 40.dp)
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    val mus = cur.music
                    if (mus == null) {
                        Text(ownerName, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(statusTimeLabel(base.createdAt), color = Color(0xFFD1D5DB), fontSize = 13.sp)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(ownerName, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                            Text("  " + statusTimeLabel(base.createdAt), color = Color(0xFFD1D5DB), fontSize = 13.sp, maxLines = 1)
                        }
                        Row(Modifier.clickable { musicInfo = true }.padding(top = 1.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(13.dp))
                            Text(" " + mus.title + " · " + mus.artist, color = Color(0xFFD1D5DB), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = Color.White) }
                    AuraDropdownMenu(
                        expanded = menuOpen,
                        onDismissRequest = { menuOpen = false },
                        containerColor = StMenuBgR,
                        forceDark = true, floating = true, yGap = 5.dp
                    ) {
                        if (mineStatus) {
                            AuraMI(
                                text = { Text("Sil", color = Color.White) },
                                onClick = { menuOpen = false; confirmDelete = true }
                            )
                            AuraMI(
                                text = { Text("Durumlarımı yönet", color = Color.White) },
                                onClick = { menuOpen = false; StatusManageHolder.request = true; onClose() }
                            )
                        } else {
                            val tgt = ChatTarget(Repo.chatId(me.uid, uid), false, uid, p?.name ?: "")
                            val flags by remember(uid) { Repo.chatFlagsFlow(me.uid, Repo.chatId(me.uid, uid)) }.collectAsState(null as Repo.ChatFlags?)
                            @Composable
                            fun Row1(label: String, color: Color = Color.White, act: () -> Unit) {
                                AuraMI(text = { Text(label, color = color) }, onClick = { menuOpen = false; act() })
                            }
                            Row1("Mesaj") { onMessage(tgt) }
                            Row1("Sesli arama") { actions.onCall(tgt, false) }
                            Row1("Görüntülü arama") { actions.onCall(tgt, true) }
                            Row1("Kişiyi görüntüle") { actions.onProfile(tgt) }
                            Row1(if (stNotifOn) "Bildirimleri sessize al" else "Bildirimler al") { notifAsk = true }
                            Row1("Gizle") { actions.onHide(uid); stToast(ctx, "Durumları gizlendi"); onClose() }
                            Row1("Şikayet et") { confirmReport = true }
                        }
                    }
                }
            }
        }

        // açıklama
        if (base.caption.isNotBlank()) {
            Text(
                base.caption, color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 96.dp)
                    .background(Color(0x73000000)).padding(horizontal = 20.dp, vertical = 10.dp)
            )
        }

        // alt: kendi durumum → görüntülenme; başkası → cevap çubuğu
        if (mineStatus) {
            Row(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp)
                    .clip(RoundedCornerShape(50)).clickable { viewersSheet = true }.padding(horizontal = 18.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Visibility, "Görenler", tint = Color.White, modifier = Modifier.size(22.dp))
                Text("  " + cur.viewers.size, color = Color.White, fontSize = 17.sp)
            }
        } else {
            val sendReply: (String) -> Unit = { txt ->
                    scope.launch {
                        val preview = when (base.type) { "text" -> base.text.ifBlank { "Durum" }.take(80); "video" -> "Video"; else -> "Fotoğraf" }
                        try {
                            Repo.sendText(
                                me,
                                ChatTarget(Repo.chatId(me.uid, uid), false, uid, p?.name ?: ""),
                                txt,
                                ReplyRef(base.id, p?.name ?: "", preview, uid, true)
                            )
                            stToast(ctx, "Cevap gönderildi")
                        } catch (e: Throwable) {
                            stToast(ctx, "Gönderilemedi")
                        }
                    }
                
            }
            if (replyMode) {
                // WhatsApp: yukarı çekince emoji tepkileri + yazı alanı
                Box(Modifier.fillMaxSize().background(Color(0x99000000)).clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { replyMode = false; focusMgr.clearFocus() }) {
                    Column(Modifier.align(Alignment.Center).padding(bottom = 80.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Göndermek için dokunun", color = Color.White, fontSize = 20.sp)
                        Spacer(Modifier.height(18.dp))
                        Row(Modifier.clip(RoundedCornerShape(50)).background(Color.White)) {
                            Box(Modifier.background(Color(0xFFD6D9DB)).padding(horizontal = 28.dp, vertical = 8.dp)) { Text("😊", fontSize = 20.sp) }
                            Box(Modifier.padding(horizontal = 28.dp, vertical = 8.dp)) { Icon(Icons.Default.Face, null, tint = Color(0xFF54656F), modifier = Modifier.size(22.dp)) }
                        }
                        Spacer(Modifier.height(24.dp))
                        listOf(listOf("😍", "😂", "😮", "😢"), listOf("😃", "👍", "🤣", "😀")).forEach { row ->
                            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                                row.forEach { e ->
                                    Text(e, fontSize = 44.sp, modifier = Modifier.clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) {
                                        sendReply(e); replyMode = false; focusMgr.clearFocus()
                                    })
                                }
                            }
                        }
                    }
                }
            }
            ReplyBar(
                modifier = Modifier.align(Alignment.BottomCenter),
                onFocus = { inputFocus = it },
                active = replyMode,
                onSend = { t -> sendReply(t); if (replyMode) { replyMode = false; focusMgr.clearFocus() } }
            )
        }

        val infoM = cur.music
        if (musicInfo && infoM != null) {
            StatusMusicInfoSheet(infoM, onClose = { musicInfo = false }, onAdd = { musicInfo = false; actions.onAddMusic(infoM) })
        }

        if (viewersSheet) {
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize().background(Color(0x80000000)).clickable { viewersSheet = false })
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                        .background(StPanelR).navigationBarsPadding().padding(top = 16.dp, bottom = 20.dp)
                ) {
                    Row(Modifier.padding(start = 20.dp, end = 20.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Visibility, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Text("  " + cur.viewers.size + " görüntülenme", color = Color.White, fontSize = 15.sp)
                    }
                    if (cur.viewers.isEmpty()) {
                        Text("Henüz kimse görmedi.", color = AuraRawMuted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp))
                    } else {
                        Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                            cur.viewers.forEach { vu -> ViewerRow(vu) }
                        }
                    }
                }
            }
        }
    }

    androidx.compose.runtime.LaunchedEffect(uid) {
        if (!mineStatus) stNotifOn = try { Repo.statusNotifOn(me.uid, uid) } catch (e: Throwable) { false }
    }
    if (notifAsk) {
        val nm = ownerName.ifBlank { "Kişi" }
        AuraAlertDialog(
            onDismissRequest = { notifAsk = false },
            containerColor = StPanelR,
            title = { Text(if (stNotifOn) "Bildirimler sessize alınsın mı?" else "Bildirim alınsın mı?", color = Color.White) },
            text = {
                Text(
                    if (stNotifOn) "$nm yeni durum eklediğinde artık bildirim almayacaksınız." else "$nm yeni durum eklediğinde bildirim alacaksınız.",
                    color = Color(0xFF9AA5AD)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    notifAsk = false
                    val on = !stNotifOn
                    stNotifOn = on
                    scope.launch {
                        try { Repo.setStatusNotif(me.uid, uid, on) } catch (e: Throwable) { stNotifOn = !on; stToast(ctx, "Değiştirilemedi") }
                    }
                }) { Text(if (stNotifOn) "Bildirimleri sessize al" else "Bildirimler al", color = AuraDialogBtn) }
            },
            dismissButton = { TextButton(onClick = { notifAsk = false }) { Text("İptal", color = AuraDialogBtn) } }
        )
    }

    if (confirmReport) {
        AuraAlertDialog(
            onDismissRequest = { confirmReport = false },
            containerColor = StPanelR,
            title = { Text("Bu durum şikayet edilsin mi?", color = Color.White) },
            confirmButton = {
                TextButton(onClick = {
                    confirmReport = false
                    Repo.reportStatus(me.uid, uid, base.id)
                    stToast(ctx, "Şikayetiniz alındı")
                }) { Text("Şikayet et", color = AuraDialogBtn) }
            },
            dismissButton = { TextButton(onClick = { confirmReport = false }) { Text("İptal", color = StRingNew) } }
        )
    }

    if (confirmDelete) {
        AuraAlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = StPanelR,
            title = { Text("Bu durum silinsin mi?", color = Color.White) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    val id = base.id
                    scope.launch {
                        try {
                            Repo.deleteStatus(id)
                            deleted = deleted + id
                            sIdx = minOf(idx, maxOf(0, list.size - 2))
                        } catch (e: Throwable) {
                            stToast(ctx, "Silinemedi")
                        }
                    }
                }) { Text("Sil", color = AuraDialogBtn) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("İptal", color = StRingNew) } }
        )
    }
}

@Composable
private fun ViewerRow(uid: String) {
    val prof by liveProfile(uid)
    val p = prof
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(p?.name ?: "", p?.avatar ?: "", 40.dp)
        Text(
            (p?.name ?: "").ifBlank { "Kullanıcı" }, color = Color.White, fontSize = 14.sp,
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}

@Composable
private fun ReplyBar(modifier: Modifier, onFocus: (Boolean) -> Unit, active: Boolean = false, onSend: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val fr = remember { FocusRequester() }
    LaunchedEffect(active) { if (active) { try { fr.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("StatusScreens", e) } } }
    var liked by remember { mutableStateOf(false) }
    Row(
        modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000))))
            .imePadding().navigationBarsPadding()
            .padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier.weight(1f).clip(RoundedCornerShape(50)).background(if (active) Color.White else StBarR).padding(start = 18.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.weight(1f).padding(vertical = 13.dp)) {
                AuraTextField(
                    value = text,
                    onValueChange = { if (it.length <= 500) text = it },
                    textStyle = TextStyle(color = if (active) Color.Black else Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(if (active) Color(0xFF0B6B4D) else Color.White),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().focusRequester(fr).onFocusChanged { onFocus(it.isFocused) },
                    decorationBox = { inner ->
                        if (text.isEmpty()) Text(if (active) "" else "Cevapla", color = AuraRawMuted, fontSize = 16.sp)
                        inner()
                    }
                )
            }
            if (text.isBlank() && active) {
            } else if (text.isBlank()) {
                Text("😍", fontSize = 26.sp, modifier = Modifier.clickable { onSend("😍") }.padding(horizontal = 8.dp))
                Text("😂", fontSize = 26.sp, modifier = Modifier.clickable { onSend("😂") }.padding(horizontal = 8.dp))
            } else {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(StRingNew).clickable {
                        val t = text
                        text = ""
                        onSend(t)
                    },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.ArrowUpward, "Gönder", tint = Color.White, modifier = Modifier.size(20.dp)) }
            }
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.size(50.dp).clip(CircleShape).background(StBarR).clickable {
                liked = true
                onSend("❤️")
            },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Beğen",
                tint = if (liked) Color(0xFFEF4444) else Color.White, modifier = Modifier.size(24.dp)
            )
        }
    }
}

/** Sohbet listesinde avatara dokununca o kişinin durumlarını tam ekran açar */
@Composable
fun UserStatusViewer(me: UserProfile, uid: String, onMessage: (ChatTarget) -> Unit, onClose: () -> Unit, actions: StatusMenuActions = StatusMenuActions()) {
    val allN by remember { Repo.statusesFlow() }.collectAsState(null as List<StatusItem>?)
    val all = allN ?: return   // veri ilk gelene kadar bekle (eskiden boş liste görünce hemen kapanıyordu)
    val now = System.currentTimeMillis()
    val list = all.filter { it.uid == uid && it.expiresAt > now }.sortedBy { it.createdAt }
    if (list.isEmpty()) { LaunchedEffect(Unit) { onClose() }; return }
    // Dialog penceresi yerine uygulamanın ana penceresindeki tam ekran katmanda çizilir (Durum sekmesindeki görüntüleyici gibi):
    // Dialog bu cihazda durum çubuğu alanını ve kenarları boş bırakıyordu
    val closeRef by androidx.compose.runtime.rememberUpdatedState(onClose)
    val body: @Composable () -> Unit = {
        androidx.activity.compose.BackHandler { closeRef() }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            StatusViewer(me = me, groups = listOf(StatusGroup(uid, list)), live = all, startUser = 0, onMessage = { onMessage(it) }, onClose = { closeRef() }, actions = actions)
        }
    }
    val bodyState = androidx.compose.runtime.rememberUpdatedState(body)
    val sCtx = LocalContext.current
    androidx.compose.runtime.DisposableEffect(Unit) {
        var cc: android.content.Context? = sCtx
        while (cc is android.content.ContextWrapper && cc !is android.app.Activity) cc = cc.baseContext
        val w = (cc as? android.app.Activity)?.window
        val ctl = w?.let { androidx.core.view.WindowCompat.getInsetsController(it, it.decorView) }
        ViewerOverlay.content.value = { bodyState.value() }
        ctl?.isAppearanceLightStatusBars = false
        ctl?.isAppearanceLightNavigationBars = false
        onDispose {
            ViewerOverlay.content.value = null
            ctl?.isAppearanceLightStatusBars = AuraUi.light
            ctl?.isAppearanceLightNavigationBars = AuraUi.light
        }
    }
}


/** Durumdaki bağlantı önizleme kartı (hep koyu zemin); onRemove verilirse sağ üstte X çıkar, dokununca bağlantı açılır */
@Composable
private fun StatusLinkCard(lp: com.aurachat.app.data.LinkPreview, onRemove: (() -> Unit)?) {
    val ctx = LocalContext.current
    val host = remember(lp.url) { try { android.net.Uri.parse(lp.url).host?.removePrefix("www.") ?: "" } catch (e: Throwable) { "" } }
    val isVideo = host.contains("tiktok") || host.contains("youtu") || host.contains("vimeo") || host.contains("instagram") || host.contains("facebook") || host.contains("fb.watch") || host.contains("twitch")
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF111B21))
            .clickable(enabled = onRemove == null) {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(lp.url))) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("StatusScreens", e) }
            }
    ) {
        if (lp.image.isNotBlank()) {
            Box(Modifier.fillMaxWidth().height(if (isVideo) 240.dp else 160.dp), contentAlignment = Alignment.Center) {
                val bmp by produceState<android.graphics.Bitmap?>(null, lp.image) {
                    value = withContext(Dispatchers.IO) {
                        try {
                            val c = java.net.URL(lp.image).openConnection() as java.net.HttpURLConnection
                            c.connectTimeout = 8000; c.readTimeout = 8000
                            c.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) }
                        } catch (e: Throwable) { null }
                    }
                }
                val b = bmp
                if (b != null) androidx.compose.foundation.Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                if (isVideo) Box(Modifier.size(64.dp).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(40.dp))
                }
                if (onRemove != null) Box(
                    Modifier.align(Alignment.TopEnd).padding(10.dp).size(36.dp).clip(CircleShape).background(Color(0x99000000)).clickable { onRemove() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Close, "Kaldır", tint = Color.White, modifier = Modifier.size(20.dp)) }
            }
        }
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            if (lp.title.isNotBlank()) Text(lp.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            if (lp.description.isNotBlank()) Text(lp.description, color = Color(0xFFD1D7DB), fontSize = 13.sp, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            Text(host, color = Color(0xFF9AA5AB), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

/** Başka uygulamadan "Durumum"a paylaşılan metin/bağlantı: yazı durumu ekranı hazır metinle açılır */
@Composable
fun StatusTextComposerHost(me: UserProfile, initial: String, onClose: () -> Unit) {
    AuraDarkIsland { StatusComposer(me, ComposerReq("text", null, initial), onClose = onClose) }
}


/** Sohbetteki durum yanıtından açılırken hangi durumdan başlanacağını taşır */
object StatusStartHolder {
    @Volatile var id: String? = null
    fun take(): String? { val v = id; id = null; return v }
}

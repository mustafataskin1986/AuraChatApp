package com.aurachat.app.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.aurachat.app.data.ChatSummary
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Media
import com.aurachat.app.data.ReplyRef
import com.aurachat.app.data.Repo
import com.aurachat.app.data.StatusItem
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

private val StBgColors = listOf(
    "#128c7e", "#075e54", "#6a1b9a", "#c2185b", "#d84315",
    "#1565c0", "#37474f", "#2e7d32", "#ad1457", "#4527a0"
)
private val StPanel: Color get() = auraC(0xFF202C33)
private val StMenuBg: Color get() = auraC(0xFF111B21)
private val StBar: Color get() = auraC(0xFF1F2C34)
private val StRingNew = Color(0xFF22C55E)
private val StRingSeen = Color(0xFF6B7280)

private fun stToast(ctx: android.content.Context, s: String) =
    Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

private fun parseBg(s: String): Color =
    try { Color(android.graphics.Color.parseColor(s)) } catch (e: Throwable) { Color(0xFF128C7E) }

fun statusTimeLabel(ms: Long): String {
    val diff = System.currentTimeMillis() - ms
    if (diff < 60_000L) return "Az önce"
    if (diff < 3_600_000L) return (diff / 60_000L).toString() + " dk önce"
    val a = Calendar.getInstance().apply { timeInMillis = ms }
    val b = Calendar.getInstance()
    val same = a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    return (if (same) "Bugün " else "Dün ") + formatClock(ms)
}

private data class StatusGroup(val uid: String, val list: List<StatusItem>)
private data class ViewerReq(val groups: List<StatusGroup>, val start: Int)
private data class ComposerReq(val mode: String, val uri: Uri?)

@Composable
private fun RingAvatar(name: String, avatar: String, size: Dp, ring: Color?) {
    val outer = size + 10.dp
    Box(
        Modifier.size(outer).then(if (ring != null) Modifier.border(2.5.dp, ring, CircleShape) else Modifier),
        contentAlignment = Alignment.Center
    ) { Avatar(name, avatar, size) }
}

// =====================================================================
//  DURUM SEKMESİ
// =====================================================================
@Composable
fun StatusScreen(
    me: UserProfile,
    onFullscreen: (Boolean) -> Unit,
    onMessage: (ChatTarget) -> Unit
) {
    val ctx = LocalContext.current
    val all by remember { Repo.statusesFlow() }.collectAsState(emptyList<StatusItem>())
    val chats by remember(me.uid) { Repo.chatsFlow(me.uid) }.collectAsState(null as List<ChatSummary>?)
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(me.uid) {
        Repo.cleanupMyStatuses(me.uid)
        while (true) {
            delay(30_000)
            now = System.currentTimeMillis()
        }
    }

    val active = all.filter { it.expiresAt > now }
    val mine = active.filter { it.uid == me.uid }.sortedBy { it.createdAt }
    val seeable: Set<String>? = chats?.filter { !it.isGroup }?.map { it.otherUid }?.toSet()
    val groups = active
        .filter { it.uid != me.uid && (seeable == null || seeable.contains(it.uid)) }
        .groupBy { it.uid }
        .map { (uid, l) -> StatusGroup(uid, l.sortedBy { it.createdAt }) }
        .sortedWith(
            compareByDescending<StatusGroup> { g -> g.list.any { !it.viewers.contains(me.uid) } }
                .thenByDescending { g -> g.list.last().createdAt }
        )

    var viewer by remember { mutableStateOf<ViewerReq?>(null) }
    var composer by remember { mutableStateOf<ComposerReq?>(null) }
    var addSheet by remember { mutableStateOf(false) }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) composer = ComposerReq("image", uri)
    }
    var camUri by remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri
        if (ok && u != null) composer = ComposerReq("image", u)
    }
    fun openCamera() {
        try {
            val dir = File(ctx.cacheDir, "camera").also { it.mkdirs() }
            val f = File(dir, "status_${System.currentTimeMillis()}.jpg")
            val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            camUri = u
            camera.launch(u)
        } catch (e: Throwable) {
            stToast(ctx, "Kamera açılamadı")
        }
    }
    fun openGallery() {
        gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    BackHandler(enabled = addSheet) { addSheet = false }
    val full = viewer != null || composer != null || addSheet
    LaunchedEffect(full) { onFullscreen(full) }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { onFullscreen(false) } }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Text(
                "Durum", color = Color.White, fontSize = 22.sp,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp)
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(Modifier.fillMaxSize()) {
                    item {
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable {
                                    if (mine.isEmpty()) addSheet = true
                                    else viewer = ViewerReq(listOf(StatusGroup(me.uid, mine)), 0)
                                }
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(68.dp)) {
                                RingAvatar(me.name, me.avatar, 58.dp, if (mine.isNotEmpty()) StRingNew else null)
                                Box(
                                    Modifier.align(Alignment.BottomEnd).size(26.dp).clip(CircleShape)
                                        .background(AuraGreen).border(2.dp, AuraBg, CircleShape)
                                        .clickable { addSheet = true },
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.Add, "Durum ekle", tint = Color.White, modifier = Modifier.size(16.dp)) }
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Durumum", color = Color.White, fontSize = 18.sp)
                                Text(
                                    if (mine.isNotEmpty()) statusTimeLabel(mine.last().createdAt) else "Durum güncellemesi ekle",
                                    color = AuraMuted, fontSize = 15.sp
                                )
                            }
                        }
                    }
                    item {
                        Text(
                            "SON GÜNCELLEMELER", color = AuraMuted, fontSize = 13.sp, letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 6.dp)
                        )
                    }
                    if (groups.isEmpty()) {
                        item {
                            Text(
                                "Henüz kimse durum paylaşmadı.", color = AuraMuted, fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 40.dp)
                            )
                        }
                    } else {
                        items(groups, key = { it.uid }) { g ->
                            val prof by liveProfile(g.uid)
                            val p = prof
                            val unseen = g.list.any { !it.viewers.contains(me.uid) }
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable {
                                        viewer = ViewerReq(groups, groups.indexOfFirst { it.uid == g.uid }.coerceAtLeast(0))
                                    }
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(68.dp), contentAlignment = Alignment.Center) {
                                    RingAvatar(p?.name ?: "", p?.avatar ?: "", 54.dp, if (unseen) StRingNew else StRingSeen)
                                }
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p?.name ?: "", color = Color.White, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(statusTimeLabel(g.list.last().createdAt), color = AuraMuted, fontSize = 15.sp)
                                }
                            }
                        }
                    }
                }
                Column(
                    Modifier.align(Alignment.BottomEnd).padding(end = 22.dp, bottom = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Box(
                        Modifier.size(46.dp).clip(CircleShape).background(StPanel).clickable { composer = ComposerReq("text", null) },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Edit, "Yazı durumu", tint = Color(0xFFE5E7EB), modifier = Modifier.size(22.dp)) }
                    Box(
                        Modifier.size(66.dp).clip(CircleShape).background(AuraGreen).clickable { addSheet = true },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.CameraAlt, "Kamera", tint = Color.White, modifier = Modifier.size(30.dp)) }
                }
            }
        }

        if (addSheet) {
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize().background(Color(0x8C000000)).clickable { addSheet = false })
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                        .background(StPanel).navigationBarsPadding()
                        .padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 26.dp)
                ) {
                    Text("Durum ekle", color = Color.White, fontSize = 17.sp, modifier = Modifier.padding(bottom = 16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        AddTile("Kamera", Icons.Default.CameraAlt, Color(0xFF10B981)) { addSheet = false; openCamera() }
                        AddTile("Galeri", Icons.Default.Image, Color(0xFF6366F1)) { addSheet = false; openGallery() }
                        AddTile("Yazı", Icons.Default.TextFields, Color(0xFFF59E0B)) { addSheet = false; composer = ComposerReq("text", null) }
                    }
                }
            }
        }

        val cr = composer
        if (cr != null) {
            StatusComposer(me, cr, onClose = { composer = null })
        }

        val vr = viewer
        if (vr != null) {
            StatusViewer(
                me = me, groups = vr.groups, live = all, startUser = vr.start,
                onMessage = { viewer = null; onMessage(it) },
                onClose = { viewer = null }
            )
        }
    }
}

@Composable
private fun AddTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(56.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
            Icon(icon, label, tint = Color.White, modifier = Modifier.size(26.dp))
        }
        Text(label, color = Color(0xFFE5E7EB), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

// =====================================================================
//  OLUŞTURUCU (yazı / fotoğraf)
// =====================================================================
@Composable
private fun StatusComposer(me: UserProfile, req: ComposerReq, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val isText = req.mode == "text"
    var bgIdx by remember { mutableIntStateOf((System.currentTimeMillis() % StBgColors.size).toInt()) }
    var text by remember { mutableStateOf("") }
    var caption by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val image by produceState<String?>(null, req.uri) {
        if (!isText && req.uri != null) {
            val d = withContext(Dispatchers.IO) { Media.compress(ctx, req.uri, 300 * 1024) }
            if (d == null) {
                stToast(ctx, "Fotoğraf açılamadı")
                onClose()
            } else value = d
        }
    }

    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        if (isText) {
            delay(100)
            try { focus.requestFocus() } catch (e: Throwable) {}
        }
    }
    BackHandler { onClose() }

    fun send() {
        if (busy) return
        val t = text.trim()
        if (isText && t.isEmpty()) {
            stToast(ctx, "Önce bir şey yazın")
            return
        }
        if (!isText && image == null) return
        busy = true
        scope.launch {
            try {
                if (isText) Repo.postStatus(me, "text", t, StBgColors[bgIdx], "", null)
                else Repo.postStatus(me, "image", "", "", caption.trim(), image)
                stToast(ctx, "Durum paylaşıldı")
                onClose()
            } catch (e: Throwable) {
                busy = false
                stToast(ctx, "Paylaşılamadı, tekrar deneyin")
            }
        }
    }

    Box(Modifier.fillMaxSize().background(if (isText) parseBg(StBgColors[bgIdx]) else Color.Black)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Kapat", tint = Color.White) }
                Spacer(Modifier.weight(1f))
                if (isText) {
                    IconButton(onClick = { bgIdx = (bgIdx + 1) % StBgColors.size }) {
                        Icon(Icons.Default.Palette, "Renk", tint = Color.White)
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 20.dp), contentAlignment = Alignment.Center) {
                if (isText) {
                    BasicTextField(
                        value = text,
                        onValueChange = { if (it.length <= 300) text = it },
                        textStyle = TextStyle(color = Color.White, fontSize = 30.sp, textAlign = TextAlign.Center),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.fillMaxWidth().focusRequester(focus),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.Center) {
                                if (text.isEmpty()) Text("Bir durum yazın", color = Color(0x99FFFFFF), fontSize = 30.sp, textAlign = TextAlign.Center)
                                inner()
                            }
                        }
                    )
                } else {
                    val img = image
                    if (img == null) CircularProgressIndicator(color = Color.White)
                    else DataUrlImage(img, 1600, Modifier.fillMaxSize(), ContentScale.Fit)
                }
            }
            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                if (!isText) {
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(50)).background(StPanel)
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        BasicTextField(
                            value = caption,
                            onValueChange = { if (it.length <= 200) caption = it },
                            textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                            cursorBrush = SolidColor(Color.White),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            decorationBox = { inner ->
                                if (caption.isEmpty()) Text("Açıklama ekleyin...", color = AuraMuted, fontSize = 15.sp)
                                inner()
                            }
                        )
                    }
                } else Spacer(Modifier.weight(1f))
                Spacer(Modifier.width(10.dp))
                Box(
                    Modifier.size(52.dp).clip(CircleShape).background(StRingNew.copy(alpha = if (busy) 0.6f else 1f))
                        .clickable { send() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.AutoMirrored.Filled.Send, "Paylaş", tint = Color.White) }
            }
        }
    }
}

// =====================================================================
//  GÖRÜNTÜLEYİCİ
// =====================================================================
@Composable
private fun StatusViewer(
    me: UserProfile,
    groups: List<StatusGroup>,
    live: List<StatusItem>,
    startUser: Int,
    onMessage: (ChatTarget) -> Unit,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var uIdx by remember { mutableIntStateOf(startUser.coerceIn(0, groups.size - 1)) }
    var deleted by remember { mutableStateOf<Set<String>>(emptySet()) }
    var sIdx by remember {
        mutableIntStateOf(
            run {
                val g = groups[startUser.coerceIn(0, groups.size - 1)]
                if (g.uid == me.uid) 0 else maxOf(0, g.list.indexOfFirst { !it.viewers.contains(me.uid) })
            }
        )
    }
    var progress by remember { mutableFloatStateOf(0f) }
    var hold by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var viewersSheet by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var inputFocus by remember { mutableStateOf(false) }

    val group = groups[uIdx]
    val list = group.list.filter { !deleted.contains(it.id) }
    if (list.isEmpty()) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    val idx = sIdx.coerceIn(0, list.size - 1)
    val base = list[idx]
    val cur = live.firstOrNull { it.id == base.id } ?: base
    val uid = group.uid
    val mineStatus = uid == me.uid

    fun next() {
        if (idx < list.size - 1) sIdx = idx + 1
        else if (uIdx < groups.size - 1) { uIdx += 1; sIdx = 0 }
        else onClose()
    }
    fun prev() {
        if (idx > 0) sIdx = idx - 1
        else if (uIdx > 0) {
            val pg = groups[uIdx - 1]
            uIdx -= 1
            sIdx = (pg.list.filter { !deleted.contains(it.id) }.size - 1).coerceAtLeast(0)
        } else progress = 0f
    }
    val nextFn = rememberUpdatedState(newValue = { next() })
    val prevFn = rememberUpdatedState(newValue = { prev() })
    val closeFn = rememberUpdatedState(newValue = onClose)

    val paused = hold || menuOpen || viewersSheet || confirmDelete || inputFocus
    val pausedState = rememberUpdatedState(newValue = paused)

    val mediaPair by produceState<Pair<String, String>?>(null, base.id) {
        value = base.id to (if (base.type == "image") Repo.loadStatusMedia(base.id) else "")
    }
    val media: String? = mediaPair?.takeIf { it.first == base.id }?.second
    val loaded = media != null

    LaunchedEffect(uIdx, idx, loaded) {
        progress = 0f
        if (!loaded) return@LaunchedEffect
        val dur = if (base.type == "text") 5000f else 6000f
        var last = androidx.compose.runtime.withFrameNanos { it }
        while (progress < 1f) {
            val t = androidx.compose.runtime.withFrameNanos { it }
            if (!pausedState.value) progress = (progress + (t - last) / 1_000_000f / dur).coerceAtMost(1f)
            last = t
        }
        nextFn.value()
    }

    // görüldü işaretle + sonrakini önden yükle
    LaunchedEffect(base.id) {
        if (!mineStatus && !base.viewers.contains(me.uid)) Repo.markStatusViewed(base.id, me.uid)
        list.getOrNull(idx + 1)?.let { if (it.type == "image") Repo.loadStatusMedia(it.id) }
    }

    val live by liveProfile(if (uid == me.uid) "" else uid)
    val prof = if (uid == me.uid) me else live
    val p = prof?.takeIf { it.uid == uid }
    val ownerName = if (mineStatus) "Durumum" else (p?.name ?: "")

    BackHandler { onClose() }
    BackHandler(enabled = viewersSheet) { viewersSheet = false }

    val stageBg = if (base.type == "text") parseBg(base.bg) else Color.Black

    Box(
        Modifier.fillMaxSize().background(stageBg)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        hold = true
                        tryAwaitRelease()
                        hold = false
                    },
                    onTap = { o -> if (o.x < size.width * 0.35f) prevFn.value() else nextFn.value() }
                )
            }
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { if (acc > 300f) closeFn.value() },
                    onVerticalDrag = { _, dy -> acc += dy }
                )
            }
    ) {
        // sahne
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (base.type == "text") {
                Text(
                    base.text, color = Color.White, fontSize = 30.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
            } else {
                when {
                    media == null -> CircularProgressIndicator(color = Color.White)
                    media.isEmpty() -> Text("Fotoğraf yüklenemedi", color = AuraMuted, fontSize = 14.sp)
                    else -> DataUrlImage(media, 1600, Modifier.fillMaxSize(), ContentScale.Fit)
                }
            }
        }

        // üst: ilerleme çubukları + başlık
        Column(
            Modifier.fillMaxWidth().align(Alignment.TopCenter)
                .background(Brush.verticalGradient(listOf(Color(0x8C000000), Color.Transparent)))
                .statusBarsPadding().padding(start = 10.dp, end = 4.dp, top = 10.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(end = 6.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                list.forEachIndexed { i, _ ->
                    val f = if (i < idx) 1f else if (i == idx) progress else 0f
                    Box(Modifier.weight(1f).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x59FFFFFF))) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(f.coerceIn(0f, 1f)).background(Color.White))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
                Avatar(ownerName, if (mineStatus) me.avatar else (p?.avatar ?: ""), 40.dp)
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(ownerName, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(statusTimeLabel(base.createdAt), color = Color(0xFFD1D5DB), fontSize = 13.sp)
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = Color.White) }
                    DropdownMenu(
                        expanded = menuOpen,
                        onDismissRequest = { menuOpen = false },
                        modifier = Modifier.background(StMenuBg)
                    ) {
                        if (mineStatus) {
                            DropdownMenuItem(
                                text = { Text("Sil", color = Color.White, fontSize = 17.sp) },
                                onClick = { menuOpen = false; confirmDelete = true }
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text("Mesaj", color = Color.White, fontSize = 17.sp) },
                                onClick = {
                                    menuOpen = false
                                    onMessage(ChatTarget(Repo.chatId(me.uid, uid), false, uid, p?.name ?: ""))
                                }
                            )
                        }
                    }
                }
            }
        }

        // açıklama
        if (base.caption.isNotBlank()) {
            Text(
                base.caption, color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 96.dp)
                    .background(Color(0x73000000)).padding(horizontal = 20.dp, vertical = 10.dp)
            )
        }

        // alt: kendi durumum → görüntülenme; başkası → cevap çubuğu
        if (mineStatus) {
            Row(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp)
                    .clip(RoundedCornerShape(50)).clickable { viewersSheet = true }.padding(horizontal = 18.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Visibility, "Görenler", tint = Color.White, modifier = Modifier.size(22.dp))
                Text("  " + cur.viewers.size, color = Color.White, fontSize = 17.sp)
            }
        } else {
            ReplyBar(
                modifier = Modifier.align(Alignment.BottomCenter),
                onFocus = { inputFocus = it },
                onSend = { txt ->
                    scope.launch {
                        val preview = ("Durum: " + base.caption.ifBlank { base.text }.ifBlank { "Fotoğraf" }).take(80)
                        try {
                            Repo.sendText(
                                me,
                                ChatTarget(Repo.chatId(me.uid, uid), false, uid, p?.name ?: ""),
                                txt,
                                ReplyRef(base.id, p?.name ?: "", preview, uid, true)
                            )
                            stToast(ctx, "Cevap gönderildi")
                        } catch (e: Throwable) {
                            stToast(ctx, "Gönderilemedi")
                        }
                    }
                }
            )
        }

        if (viewersSheet) {
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize().background(Color(0x80000000)).clickable { viewersSheet = false })
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                        .background(StPanel).navigationBarsPadding().padding(top = 16.dp, bottom = 20.dp)
                ) {
                    Row(Modifier.padding(start = 20.dp, end = 20.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Visibility, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Text("  " + cur.viewers.size + " görüntülenme", color = Color.White, fontSize = 15.sp)
                    }
                    if (cur.viewers.isEmpty()) {
                        Text("Henüz kimse görmedi.", color = AuraMuted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp))
                    } else {
                        Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                            cur.viewers.forEach { vu -> ViewerRow(vu) }
                        }
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = StPanel,
            title = { Text("Bu durum silinsin mi?", color = Color.White) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    val id = base.id
                    scope.launch {
                        try {
                            Repo.deleteStatus(id)
                            deleted = deleted + id
                            sIdx = minOf(idx, maxOf(0, list.size - 2))
                        } catch (e: Throwable) {
                            stToast(ctx, "Silinemedi")
                        }
                    }
                }) { Text("Sil", color = Color(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("İptal", color = StRingNew) } }
        )
    }
}

@Composable
private fun ViewerRow(uid: String) {
    val prof by liveProfile(uid)
    val p = prof
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(p?.name ?: "", p?.avatar ?: "", 40.dp)
        Text(
            (p?.name ?: "").ifBlank { "Kullanıcı" }, color = Color.White, fontSize = 14.sp,
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}

@Composable
private fun ReplyBar(modifier: Modifier, onFocus: (Boolean) -> Unit, onSend: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    var liked by remember { mutableStateOf(false) }
    Row(
        modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000))))
            .imePadding().navigationBarsPadding()
            .padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier.weight(1f).clip(RoundedCornerShape(50)).background(StBar).padding(start = 18.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.weight(1f).padding(vertical = 13.dp)) {
                BasicTextField(
                    value = text,
                    onValueChange = { if (it.length <= 500) text = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Color.White),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().onFocusChanged { onFocus(it.isFocused) },
                    decorationBox = { inner ->
                        if (text.isEmpty()) Text("Cevapla", color = AuraMuted, fontSize = 16.sp)
                        inner()
                    }
                )
            }
            if (text.isBlank()) {
                Text("😍", fontSize = 26.sp, modifier = Modifier.clickable { onSend("😍") }.padding(horizontal = 8.dp))
                Text("😂", fontSize = 26.sp, modifier = Modifier.clickable { onSend("😂") }.padding(horizontal = 8.dp))
            } else {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(StRingNew).clickable {
                        val t = text
                        text = ""
                        onSend(t)
                    },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.AutoMirrored.Filled.Send, "Gönder", tint = Color.White, modifier = Modifier.size(20.dp)) }
            }
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.size(50.dp).clip(CircleShape).background(StBar).clickable {
                liked = true
                onSend("❤️")
            },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Beğen",
                tint = if (liked) Color(0xFFEF4444) else Color.White, modifier = Modifier.size(24.dp)
            )
        }
    }
}

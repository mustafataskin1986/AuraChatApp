package com.aurachat.app.ui

import androidx.compose.ui.graphics.compositeOver
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** "Tümü" çipiyle aynı renkler: dolgu, yazı ve kenarlık (seçili çip görünümü) */
object ChipLook {
    val bg: Color @Composable get() {
        val lt = AuraUi.light
        val acc = AuraUi.accentColor()
        return if (acc != null) acc.copy(alpha = if (lt) 0.16f else 0.24f) else if (lt) Color(0xFFD9FDD3) else Color(0xFF103629)
    }
    val fg: Color @Composable get() {
        val lt = AuraUi.light
        val acc = AuraUi.accentColor()
        return if (acc != null) (if (lt) lerp(acc, Color.Black, 0.25f) else lerp(acc, Color.White, 0.45f)) else if (lt) Color(0xFF0B6B4D) else Color(0xFF25D366)
    }
    val border: Color @Composable get() {
        val lt = AuraUi.light
        val acc = AuraUi.accentColor()
        return if (lt) (acc?.copy(alpha = 0.4f) ?: Color(0xFFA9E5A0)) else (acc?.copy(alpha = 0.55f) ?: Color(0xFF14503B))
    }
}

/** Fotoğrafsız avatar / arama kutusu görünümü: açık vurgu zemini + vurgu çerçevesi (daire butonlar için) */
@Composable
fun Modifier.softCircle(): Modifier = this.clip(androidx.compose.foundation.shape.CircleShape)
    .background(ChipLook.bg.compositeOver(AuraBg)).border(1.dp, ChipLook.border, androidx.compose.foundation.shape.CircleShape)

/** Çip görünümlü, tam yuvarlak arama kutusu (Kişiler sayfası vb.) */
@Composable
fun ChipSearchField(value: String, onValueChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier) {
    val fg = ChipLook.fg
    Row(
        modifier.height(49.dp).clip(RoundedCornerShape(50)).background(ChipLook.bg).border(1.dp, ChipLook.border, RoundedCornerShape(50)).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Search, null, tint = fg, modifier = Modifier.size(24.dp))
        Box(Modifier.weight(1f).padding(start = 12.dp)) {
            if (value.isEmpty()) Text(placeholder, color = fg.copy(alpha = 0.7f), fontSize = 17.sp)
            AuraTextField(
                value = value, onValueChange = onValueChange, singleLine = true,
                textStyle = TextStyle(color = fg, fontSize = 17.sp),
                cursorBrush = SolidColor(fg),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

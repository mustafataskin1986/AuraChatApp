package com.aurachat.app.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile

/** Mesajdaki telefon numarasına dokunma: numara burada tutulur, sohbet ekranındaki PhoneActionDialog açar */
object PhoneNav {
    var pending by mutableStateOf<String?>(null)
}

/**
 * Metindeki "phone" (telefon) ve "url" (bağlantı) işaretli aralıklara kısa dokunuşu yakalar.
 * Dokunuş bağlantının üstündeyse balonun kendi dokunuşunu iptal eder ve bağlantıyı açar;
 * değilse (ya da uzun basma / kaydırma ise) hiçbir şeyi tüketmez, balon eskisi gibi çalışır.
 */
@Composable
fun Modifier.phoneTap(text: AnnotatedString, layout: () -> TextLayoutResult?): Modifier {
    val ctx = LocalContext.current
    if (text.getStringAnnotations("phone", 0, text.length).isEmpty() && text.getStringAnnotations("url", 0, text.length).isEmpty()) return this
    return this.pointerInput(text) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            val l = layout() ?: return@awaitEachGesture
            val off = l.getOffsetForPosition(down.position).coerceIn(0, (text.length - 1).coerceAtLeast(0))
            if (!l.getBoundingBox(off).contains(down.position)) return@awaitEachGesture
            val ph = text.getStringAnnotations("phone", off, off + 1).firstOrNull()
            val ur = if (ph == null) text.getStringAnnotations("url", off, off + 1).firstOrNull() else null
            if (ph == null && ur == null) return@awaitEachGesture
            val up = waitForUpOrCancellation() ?: return@awaitEachGesture
            if (up.uptimeMillis - down.uptimeMillis >= viewConfiguration.longPressTimeoutMillis) return@awaitEachGesture
            if ((up.position - down.position).getDistance() > viewConfiguration.touchSlop) return@awaitEachGesture
            up.consume()
            if (ph != null) PhoneNav.pending = ph.item
            else if (ur != null) {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ur.item)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Throwable) { com.aurachat.app.AuraLog.e("PhoneActions", e); Toast.makeText(ctx, "Bağlantı açılamadı", Toast.LENGTH_SHORT).show() }
            }
        }
    }
}

@Composable
fun PhoneActionDialog(onChat: (UserProfile) -> Unit, onCall: (UserProfile, Boolean) -> Unit) {
    val raw = PhoneNav.pending ?: return
    val ctx = LocalContext.current
    var res by remember(raw) { mutableStateOf<Pair<Boolean, UserProfile?>?>(null) }
    LaunchedEffect(raw) {
        res = try { true to Repo.findUserByPhone(raw) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("PhoneActions", e); true to null }
    }
    val r = res ?: return
    val user = r.second
    val digits = raw.filter { it.isDigit() || it == '+' }
    fun close() { PhoneNav.pending = null }
    Dialog(onDismissRequest = { close() }) {
        Column(Modifier.clip(RoundedCornerShape(28.dp)).background(AuraSurface).padding(vertical = 14.dp)) {
            @Composable
            fun Item(label: String, onClick: () -> Unit) {
                Text(label, color = AuraWhite, fontSize = 18.sp, modifier = Modifier.fillMaxWidth().clickable { close(); onClick() }.padding(horizontal = 24.dp, vertical = 16.dp))
            }
            if (user != null) {
                Text("Bu telefon numarası AuraChat kullanıyor", color = AuraMuted, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                Item("$raw ile sohbet et") { onChat(user) }
                Item("AuraChat'te ara") { onCall(user, false) }
            } else {
                Item("$raw numarasını ara") {
                    try { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits"))) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("PhoneActions", e) }
                }
                Item("Kişilere ekle") {
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_INSERT_OR_EDIT).apply {
                            type = android.provider.ContactsContract.Contacts.CONTENT_ITEM_TYPE
                            putExtra(android.provider.ContactsContract.Intents.Insert.PHONE, raw)
                        })
                    } catch (e: Throwable) { com.aurachat.app.AuraLog.e("PhoneActions", e) }
                }
                Item("Kopyala") {
                    (ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                        .setPrimaryClip(android.content.ClipData.newPlainText("telefon", raw))
                    Toast.makeText(ctx, "Telefon numarası kopyalandı", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}

package com.aurachat.app.ui

import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.offset
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.KeyboardArrowDown
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.aurachat.app.call.CallManager
import com.aurachat.app.call.CallUi
import com.aurachat.app.call.GPeer
import com.aurachat.app.call.GroupCallManager
import com.aurachat.app.call.Phase
import com.aurachat.app.data.CallLog
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.delay
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import java.util.Calendar

private val CallBg = Color(0xFF0B141A)
private val CallRed = Color(0xFFEF4444)
private val CallGreen = Color(0xFF22C55E)
private val CallBtn = Color(0x33FFFFFF)

private fun has(ctx: Context, perm: String) =
    ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

private fun neededPerms(ctx: Context, video: Boolean): List<String> {
    val l = ArrayList<String>()
    if (!has(ctx, Manifest.permission.RECORD_AUDIO)) l.add(Manifest.permission.RECORD_AUDIO)
    if (video && !has(ctx, Manifest.permission.CAMERA)) l.add(Manifest.permission.CAMERA)
    return l
}

private fun dispatchCall(me: UserProfile, t: ChatTarget, video: Boolean) {
    if (t.isGroup) GroupCallManager.start(me, t, video) else CallManager.startCall(me, t, video)
}

/** (sohbet, görüntülü mü) → izinleri iste, sonra aramayı başlat */
@Composable
fun rememberCallStarter(me: UserProfile): (ChatTarget, Boolean) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<Pair<ChatTarget, Boolean>?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val p = pending
        pending = null
        if (p != null) {
            if (neededPerms(ctx, p.second).isEmpty()) dispatchCall(me, p.first, p.second)
            else Toast.makeText(ctx, "Arama için izin gerekli", Toast.LENGTH_SHORT).show()
        }
    }
    return { t, video ->
        val need = neededPerms(ctx, video)
        if (need.isEmpty()) dispatchCall(me, t, video)
        else {
            pending = t to video
            launcher.launch(need.toTypedArray())
        }
    }
}

// =====================================================================
//  ARAMA EKRANI (gelen + giden + aktif) — her ekranın üstünde
// =====================================================================
@Composable
fun CallOverlay() {
    val st by CallManager.ui.collectAsState()
    var minimized by remember { mutableStateOf(false) }
    androidx.compose.runtime.LaunchedEffect(st.phase == Phase.IDLE) { if (st.phase == Phase.IDLE) minimized = false }
    if (st.phase == Phase.IDLE) return
    ForceLightBarIcons()
    val ctx = LocalContext.current

    var wantAccept by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (wantAccept) {
            wantAccept = false
            if (neededPerms(ctx, st.video).isEmpty()) CallManager.accept()
            else {
                Toast.makeText(ctx, "Arama için izin gerekli", Toast.LENGTH_SHORT).show()
                CallManager.decline()
            }
        }
    }
    fun accept() {
        val need = neededPerms(ctx, st.video)
        if (need.isEmpty()) CallManager.accept()
        else {
            wantAccept = true
            launcher.launch(need.toTypedArray())
        }
    }

    // Küçültülmüşken geri tuşu aramayı kapatmaz: uygulamada gezinmeye devam edilir (WhatsApp gibi)
    BackHandler(enabled = !minimized || st.phase == Phase.INCOMING) {
        if (st.phase == Phase.INCOMING) CallManager.decline() else CallManager.hangup()
    }

    if (minimized && st.phase != Phase.INCOMING) {
        MiniCall(st) { minimized = false }
        return
    }
    Box(Modifier.fillMaxSize().background(CallBg).pointerInput(Unit) { detectTapGestures { } }) {
        if (st.phase == Phase.INCOMING) IncomingCall(st, ::accept) else ActiveCall(st, onMinimize = { minimized = true })
    }
}

/** Küçültülmüş arama: üstte kapatma/sessiz çubuğu, görüntülüyse sürüklenebilir küçük video penceresi */
@Composable
private fun MiniCall(st: CallUi, onRestore: () -> Unit) {
    var tick by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(st.connectedAt) {
        while (st.connectedAt > 0) { tick = System.currentTimeMillis(); delay(1000) }
    }
    val status = if (st.phase == Phase.CONNECTED) fmtTimer(maxOf(0L, (tick - st.connectedAt) / 1000L)) else st.message.ifBlank { "Aranıyor…" }
    val density = androidx.compose.ui.platform.LocalDensity.current
    val cfg = androidx.compose.ui.platform.LocalConfiguration.current
    var off by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    val w = 112.dp
    val h = 170.dp
    val maxX = with(density) { (cfg.screenWidthDp.dp - w - 28.dp).toPx() }
    val maxY = with(density) { (cfg.screenHeightDp.dp - h - 200.dp).toPx() }
    Box(Modifier.fillMaxSize()) {
        val big = st.remoteVideo ?: st.localVideo
        if (st.video && big != null) {
            Box(
                Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(bottom = 90.dp, end = 14.dp)
                    .offset { androidx.compose.ui.unit.IntOffset(off.x.toInt(), off.y.toInt()) }
                    .size(width = w, height = h).clip(RoundedCornerShape(18.dp)).background(Color(0xFF1F2C34))
                    .pointerInput(maxX, maxY) {
                        detectDragGestures(
                            onDrag = { ch: androidx.compose.ui.input.pointer.PointerInputChange, d: androidx.compose.ui.geometry.Offset ->
                                ch.consume()
                                off = androidx.compose.ui.geometry.Offset((off.x + d.x).coerceIn(-maxX, 0f), (off.y + d.y).coerceIn(-maxY, 0f))
                            }
                        )
                    }
                    .clickable { onRestore() }
            ) {
                VideoView(big, st.frontCam && st.remoteVideo == null, true, Modifier.fillMaxSize())
                if (st.remoteVideo != null && st.localVideo != null) {
                    Box(Modifier.align(Alignment.BottomEnd).padding(8.dp).size(width = 36.dp, height = 52.dp).clip(RoundedCornerShape(8.dp))) {
                        VideoView(st.localVideo, st.frontCam, true, Modifier.fillMaxSize())
                    }
                }
            }
        }
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().background(Color(0xFF111B21)).statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(Color(0xFF26323A)).clickable { CallManager.toggleMic() },
                contentAlignment = Alignment.Center
            ) { Icon(if (st.micOn) Icons.Default.Mic else Icons.Default.MicOff, "Mikrofon", tint = Color.White, modifier = Modifier.size(24.dp)) }
            Row(
                Modifier.weight(1f).clickable { onRestore() }.padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(if (st.video) Icons.Default.Videocam else Icons.Default.Call, null, tint = CallGreen, modifier = Modifier.size(22.dp))
                Text(
                    "  " + st.otherName + " - " + status, color = CallGreen, fontSize = 18.sp, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(Color(0xFFE11D48)).clickable { CallManager.hangup() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.CallEnd, "Kapat", tint = Color.White, modifier = Modifier.size(24.dp)) }
        }
    }
}

@Composable
private fun CallAvatar(st: CallUi, size: Int) {
    Avatar(st.otherName, st.otherAvatar, size.dp)
}

@Composable
private fun IncomingCall(st: CallUi, onAccept: () -> Unit) {
    var drag by remember { mutableStateOf(0f) }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1F2C34), Color(0xFF0B141A))))) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(110.dp))
            Text(st.otherName, color = Color.White, fontSize = 32.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            Text(if (st.video) "AuraChat görüntülü arama" else "AuraChat sesli arama", color = Color(0xFFD1D5DB), fontSize = 17.sp, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(36.dp))
            CallAvatar(st, 180)
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth().padding(bottom = 40.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                RoundAction(Color(0xFFE11D48), 78, Icons.Default.CallEnd, "Reddet", "Reddet") { CallManager.decline() }
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(150.dp)) {
                    Box(
                        Modifier.offset { androidx.compose.ui.unit.IntOffset(0, drag.toInt()) }.size(78.dp).clip(CircleShape).background(CallGreen)
                            .clickable(onClick = onAccept)
                            .pointerInput(Unit) {
                                detectVerticalDragGestures(
                                    onDragEnd = { if (drag < -size.height * 1.2f) onAccept(); drag = 0f },
                                    onDragCancel = { drag = 0f }
                                ) { ch, d -> ch.consume(); drag = (drag + d).coerceIn(-300f, 0f) }
                            },
                        contentAlignment = Alignment.Center
                    ) { Icon(if (st.video) Icons.Default.Videocam else Icons.Default.Call, "Cevapla", tint = Color.White, modifier = Modifier.size(34.dp)) }
                    Text("Kabul etmek için yukarı kaydır", color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
    }
}

@Composable
private fun RoundAction(
    color: Color, size: Int, icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String, label: String, onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(size.dp).clip(CircleShape).background(color).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Icon(icon, desc, tint = Color.White, modifier = Modifier.size((size * 0.42f).dp)) }
        Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

private fun fmtTimer(sec: Long): String = "%02d:%02d".format(sec / 60, sec % 60)

@Composable
private fun ActiveCall(st: CallUi, onMinimize: () -> Unit) {
    var tick by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(st.connectedAt) {
        while (st.connectedAt > 0) {
            tick = System.currentTimeMillis()
            delay(1000)
        }
    }
    val status = when {
        st.phase == Phase.CONNECTED -> fmtTimer(maxOf(0L, (tick - st.connectedAt) / 1000L))
        st.message.isNotBlank() -> st.message
        else -> ""
    }
    val ctx = LocalContext.current
    val density = androidx.compose.ui.platform.LocalDensity.current
    val cfg = androidx.compose.ui.platform.LocalConfiguration.current
    var swapped by remember { mutableStateOf(false) }
    var controls by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf(false) }
    val startShare = rememberScreenShareStarter { c, d -> CallManager.startScreenShare(c, d) }
    var noise by remember { mutableStateOf(true) }
    var off by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    val showVideo = st.video && (st.remoteVideo != null || st.localVideo != null)
    val shadow = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color(0x99000000), androidx.compose.ui.geometry.Offset(0f, 2f), 6f))
    val barColor = Color(0xFF1B252B)

    Box(Modifier.fillMaxSize()) {
        if (showVideo) {
            // karşıdan görüntü gelene kadar kendi kameran tam ekran görünür (WhatsApp gibi)
            val noRemote = st.remoteVideo == null
            val bigTrack = if (noRemote) st.localVideo else if (swapped) st.localVideo else st.remoteVideo
            val smallTrack = if (noRemote) null else if (swapped) st.remoteVideo else st.localVideo
            val bigMirror = st.frontCam && (noRemote || swapped)
            val smallMirror = !swapped && st.frontCam
            Box(
                Modifier.fillMaxSize().clickable(
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null
                ) { controls = !controls; menu = false }
            ) {
                VideoView(bigTrack, bigMirror, false, Modifier.fillMaxSize())
                if (bigTrack == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CallAvatar(st, 120) }
            }
            if (smallTrack != null) {
                val w = 124.dp
                val h = 180.dp
                val maxX = with(density) { (cfg.screenWidthDp.dp - w - 28.dp).toPx() }
                val maxY = with(density) { (cfg.screenHeightDp.dp - h - 130.dp - 80.dp).toPx() }
                Box(
                    Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(bottom = 110.dp, end = 14.dp)
                        .offset { androidx.compose.ui.unit.IntOffset(off.x.toInt(), off.y.toInt()) }
                        .size(width = w, height = h).clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1F2C34))
                        .pointerInput(maxX, maxY) {
                            detectDragGestures(
                                onDrag = { ch: androidx.compose.ui.input.pointer.PointerInputChange, d: androidx.compose.ui.geometry.Offset ->
                                    ch.consume()
                                    val nx: Float = (off.x + d.x).coerceIn(-maxX, 0f)
                                    val ny: Float = (off.y + d.y).coerceIn(-maxY, 0f)
                                    off = androidx.compose.ui.geometry.Offset(nx, ny)
                                }
                            )
                        }
                        .clickable { swapped = !swapped }
                ) {
                    VideoView(smallTrack, smallMirror, true, Modifier.fillMaxSize())
                    if (controls && !swapped) Box(
                        Modifier.align(Alignment.TopEnd).padding(8.dp).size(36.dp).clip(CircleShape).background(barColor)
                            .clickable { CallManager.switchCamera() },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.FlipCameraAndroid, "Kamerayı çevir", tint = Color.White, modifier = Modifier.size(20.dp)) }
                }
            }
        } else {
            Column(Modifier.fillMaxSize().statusBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(110.dp))
                CallAvatar(st, 150)
            }
        }

        // üst başlık
        if (controls || !showVideo) {
            Column(
                Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 18.dp, start = 70.dp, end = 70.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(st.otherName, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, style = shadow.copy(fontSize = 22.sp, color = Color.White))
                if (status.isNotEmpty()) Text(status, color = Color(0xFFE5E7EB), fontSize = 16.sp, style = shadow.copy(fontSize = 16.sp, color = Color(0xFFE5E7EB)))
            }
            Box(
                Modifier.align(Alignment.TopStart).statusBarsPadding().padding(top = 8.dp, start = 12.dp).size(52.dp).clip(CircleShape)
                    .background(barColor).clickable(onClick = onMinimize),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.KeyboardArrowDown, "Küçült", tint = Color.White, modifier = Modifier.size(30.dp)) }
        }

        // alt kontrol çubuğu
        if (controls || !showVideo) {
            if (menu) {
                Column(
                    Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(start = 14.dp, bottom = 108.dp)
                        .clip(RoundedCornerShape(28.dp)).background(barColor).padding(vertical = 8.dp)
                ) {
                    @Composable
                    fun MRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit, trailing: (@Composable () -> Unit)? = null) {
                        Row(
                            Modifier.width(290.dp).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(48.dp).clip(CircleShape).background(Color(0x22FFFFFF)), contentAlignment = Alignment.Center) {
                                Icon(icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
                            }
                            Text(label, color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f).padding(start = 14.dp))
                            trailing?.invoke()
                        }
                    }
                    MRow(Icons.Default.ScreenShare, if (st.sharing) "Paylaşımı durdur" else "Ekranı paylaş", {
                        menu = false
                        if (st.sharing) CallManager.stopScreenShare()
                        else if (!st.video) Toast.makeText(ctx, "Ekran paylaşımı görüntülü aramada kullanılır", Toast.LENGTH_SHORT).show()
                        else startShare()
                    })
                    MRow(Icons.Default.Message, "Mesaj gönder", { menu = false; onMinimize() })
                    MRow(Icons.Default.Mic, "Gürültü engelleme", { noise = !noise }) {
                        androidx.compose.material3.Switch(
                            checked = noise, onCheckedChange = { noise = it },
                            colors = androidx.compose.material3.SwitchDefaults.colors(checkedTrackColor = CallGreen, checkedThumbColor = Color.White)
                        )
                    }
                }
            }
            Row(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(horizontal = 12.dp, vertical = 16.dp)
                    .fillMaxWidth().clip(RoundedCornerShape(50)).background(barColor).padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CtlButton(Icons.Default.MoreHoriz, false) { menu = !menu }
                if (st.video) CtlButton(if (st.camOn) Icons.Default.Videocam else Icons.Default.VideocamOff, st.camOn) { CallManager.toggleCam() }
                CtlButton(Icons.Default.VolumeUp, st.speakerOn) { CallManager.toggleSpeaker() }
                CtlButton(if (st.micOn) Icons.Default.Mic else Icons.Default.MicOff, false) { CallManager.toggleMic() }
                Box(
                    Modifier.size(58.dp).clip(CircleShape).background(Color(0xFFE11D48)).clickable { CallManager.hangup() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.CallEnd, "Kapat", tint = Color.White, modifier = Modifier.size(28.dp)) }
            }
        }
    }
}

@Composable
private fun CtlButton(icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(58.dp).clip(CircleShape).background(if (active) Color.White else CallBtn).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = if (active) Color.Black else Color.White, modifier = Modifier.size(26.dp)) }
}

@Composable
private fun VideoView(track: VideoTrack?, mirror: Boolean, overlay: Boolean, modifier: Modifier) {
    val ctx = LocalContext.current
    val renderer = remember {
        SurfaceViewRenderer(ctx).apply {
            init(CallManager.egl.eglBaseContext, null)
            setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
            setEnableHardwareScaler(true)
            if (overlay) setZOrderMediaOverlay(true)
        }
    }
    DisposableEffect(track) {
        try { track?.addSink(renderer) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("CallScreens", e) }
        onDispose { try { track?.removeSink(renderer) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("CallScreens", e) } }
    }
    DisposableEffect(Unit) {
        onDispose { try { renderer.release() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("CallScreens", e) } }
    }
    AndroidView(factory = { renderer }, modifier = modifier, update = { it.setMirror(mirror) })
}

// =====================================================================
//  ARAMALAR SEKMESİ
// =====================================================================
private fun callTimeLabel(ms: Long): String {
    val d = Calendar.getInstance().apply { timeInMillis = ms }
    val now = Calendar.getInstance()
    val hm = formatClock(ms)
    if (d.get(Calendar.YEAR) == now.get(Calendar.YEAR) && d.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)) return hm
    val y = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    if (d.get(Calendar.YEAR) == y.get(Calendar.YEAR) && d.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)) return "Dün $hm"
    val months = listOf("Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara")
    return d.get(Calendar.DAY_OF_MONTH).toString() + " " + months[d.get(Calendar.MONTH)] + " " + hm
}

@Composable
fun CallsScreen(
    me: UserProfile,
    onOpenChat: (ChatTarget) -> Unit,
    onCall: (ChatTarget, Boolean) -> Unit,
    onInfo: (String, String, List<String>) -> Unit = { _, _, _ -> },
    onContactInfo: (ChatTarget) -> Unit = {}
) {
    val logs0 by remember(me.uid) { Repo.callsFlow(me.uid) }.collectAsState(emptyList<CallLog>())
    // WhatsApp gibi: art arda, aynı kişi + aynı tür + aynı yön/sonuç + aynı gün → tek satır "(n)"
    val groups = remember(logs0) { groupCalls(logs0) }
    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Text(
                "Aramalar", color = AuraWhite, fontSize = 22.sp,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp)
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (groups.isEmpty()) {
                    Text(
                        "Henüz arama yok.", color = AuraMuted, fontSize = 13.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 40.dp)
                    )
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(groups, key = { it.first().id }) { g -> CallRow(me, g.first(), g.size, onOpenChat, onCall, onContactInfo) { onInfo(g.first().otherUid, g.first().otherName, g.map { it.id }) } }
                    }
                }
            }
        }
    }
}

@Composable
private fun CallRow(me: UserProfile, c: CallLog, count: Int, onOpenChat: (ChatTarget) -> Unit, onCall: (ChatTarget, Boolean) -> Unit, onContactInfo: (ChatTarget) -> Unit, onInfo: () -> Unit) {
    val prof by liveProfile(c.otherUid)
    val p = prof
    val name = (p?.name ?: "").ifBlank { c.otherName }.ifBlank { "Kullanıcı" }
    val missed = c.result == "missed" || c.result == "declined"
    val target = ChatTarget(Repo.chatId(me.uid, c.otherUid), false, c.otherUid, name)
    val sub = when (c.result) {
        "answered" -> "%02d:%02d".format(c.duration / 60, c.duration % 60)
        "missed" -> "Cevapsız"
        "declined" -> "Reddedildi"
        else -> ""
    }
    val arrowColor = if (c.result == "answered") CallGreen else CallRed
    Row(
        Modifier.fillMaxWidth().clickable { onInfo() }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        var peek by remember(c.otherUid) { mutableStateOf(false) }
        Box(Modifier.clip(CircleShape).clickable { peek = true }) { Avatar(name, p?.avatar ?: "", 50.dp) }
        if (peek) AvatarPeekDialog(name, p?.avatar ?: "", false, onDismiss = { peek = false }) { act ->
            peek = false
            when (act) { 0 -> onOpenChat(target); 1 -> onCall(target, false); 2 -> onCall(target, true); else -> onContactInfo(target) }
        }
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(
                if (count > 1) "$name ($count)" else name, color = if (missed) auraLc(0xFFF87171) else auraLc(0xFFE5E7EB), fontSize = 16.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (c.direction == "out") Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    null, tint = arrowColor, modifier = Modifier.size(14.dp)
                )
                Text(
                    " " + callTimeLabel(c.at) + (if (sub.isNotEmpty()) " · $sub" else ""),
                    color = AuraMuted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        Box(
            Modifier.size(44.dp).softCircle().clickable { onCall(target, c.callType != "audio") },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (c.callType == "audio") Icons.Default.Call else Icons.Default.Videocam,
                "Ara", tint = ChipLook.fg, modifier = Modifier.size(22.dp)
            )
        }
    }
}

private fun callKind(c: CallLog) = (if (c.result == "answered") "a" else "m") + c.direction + c.callType

private fun dayKey(ms: Long): Int { val d = Calendar.getInstance().apply { timeInMillis = ms }; return d.get(Calendar.YEAR) * 1000 + d.get(Calendar.DAY_OF_YEAR) }

fun groupCalls(logs: List<CallLog>): List<List<CallLog>> {
    val out = ArrayList<MutableList<CallLog>>()
    for (c in logs) {
        val last = out.lastOrNull()
        val f = last?.first()
        if (f != null && f.otherUid == c.otherUid && callKind(f) == callKind(c) && dayKey(f.at) == dayKey(c.at)) last.add(c) else out.add(mutableListOf(c))
    }
    return out
}

private fun dayLabel(ms: Long): String {
    val now = dayKey(System.currentTimeMillis())
    val k = dayKey(ms)
    if (k == now) return "Bugün"
    if (k == dayKey(System.currentTimeMillis() - 86_400_000L)) return "Dün"
    val d = Calendar.getInstance().apply { timeInMillis = ms }
    val months = listOf("Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık")
    return d.get(Calendar.DAY_OF_MONTH).toString() + " " + months[d.get(Calendar.MONTH)]
}

private fun durLabel(s: Int): String = if (s < 60) "$s sn." else if (s % 60 == 0) "${s / 60} dk." else "${s / 60} dk. ${s % 60} sn."

/** WhatsApp "Arama bilgisi": kişi, hızlı eylemler ve (gruplanan) aramaların gün gün listesi */
@Composable
fun CallInfoScreen(
    me: UserProfile, uid: String, name0: String, ids: List<String>,
    onBack: () -> Unit, onMessage: () -> Unit, onCall: (Boolean) -> Unit, onInfo: () -> Unit
) {
    androidx.activity.compose.BackHandler(onBack = onBack)
    val prof by liveProfile(uid)
    val p = prof
    val name = (p?.name ?: "").ifBlank { name0 }.ifBlank { "Kullanıcı" }
    val all by remember(me.uid) { Repo.callsFlow(me.uid) }.collectAsState(emptyList<CallLog>())
    val list = all.filter { it.id in ids }
    val days = list.groupBy { dayKey(it.at) }.entries.sortedByDescending { it.key }
    @Composable
    fun Act(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(84.dp).clickable(
            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null, onClick = onClick)) {
            Box(Modifier.width(74.dp).height(54.dp).clip(RoundedCornerShape(50)).background(AuraSurface), contentAlignment = Alignment.Center) {
                Icon(icon, label, tint = AuraWhite, modifier = Modifier.size(24.dp))
            }
            Text(label, color = AuraWhite, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text("Arama bilgisi", color = AuraWhite, fontSize = 21.sp, modifier = Modifier.weight(1f))
        }
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(name, p?.avatar ?: "", 140.dp)
                    Text(name, color = AuraWhite, fontSize = 24.sp, modifier = Modifier.padding(top = 14.dp))
                    if ((p?.phone ?: "").isNotBlank()) Text(p!!.phone, color = AuraMuted, fontSize = 18.sp, modifier = Modifier.padding(top = 4.dp))
                    Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Act(Icons.Default.Message, "Mesaj", onMessage)
                        Act(Icons.Default.Call, "Sesli") { onCall(false) }
                        Act(Icons.Default.Videocam, "Görüntülü") { onCall(true) }
                        Act(Icons.Default.Info, "Bilgi", onInfo)
                    }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(AuraMuted.copy(alpha = 0.18f)))
            }
            days.forEach { d ->
                item(key = "d" + d.key) {
                    Text(dayLabel(d.value.first().at), color = AuraMuted, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 16.dp, top = 22.dp, bottom = 6.dp))
                }
                items(d.value.sortedBy { it.at }, key = { it.id }) { c ->
                    val ok = c.result == "answered"
                    val kind = if (c.callType == "audio") "sesli arama" else "görüntülü arama"
                    val label = when {
                        c.result == "missed" -> "Cevapsız $kind"
                        c.result == "declined" -> if (c.direction == "out") "Reddedilen $kind" else "Reddedilen $kind"
                        c.direction == "out" -> "Giden $kind"
                        else -> "Gelen $kind"
                    }
                    val tint = if (ok) AuraGreen else CallRed
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(width = 44.dp, height = 28.dp), contentAlignment = Alignment.CenterStart) {
                            Icon(if (c.callType == "audio") Icons.Default.Call else Icons.Default.Videocam, null, tint = tint, modifier = Modifier.size(24.dp))
                            Icon(if (c.direction == "out") Icons.Default.ArrowUpward else Icons.Default.ArrowDownward, null, tint = tint, modifier = Modifier.align(Alignment.BottomEnd).size(13.dp))
                        }
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(label, color = AuraWhite, fontSize = 18.sp)
                            Text(formatClock(c.at), color = AuraMuted, fontSize = 15.sp)
                        }
                        if (ok) Text(durLabel(c.duration), color = AuraMuted, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}

// =====================================================================
//  GRUP ARAMASI EKRANI
// =====================================================================
@Composable
fun GroupCallOverlay(me: UserProfile) {
    val st by GroupCallManager.ui.collectAsState()
    if (st.phase == Phase.IDLE) return
    val ctx = LocalContext.current

    var wantAccept by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (wantAccept) {
            wantAccept = false
            if (neededPerms(ctx, st.video).isEmpty()) GroupCallManager.accept(me)
            else {
                Toast.makeText(ctx, "Arama için izin gerekli", Toast.LENGTH_SHORT).show()
                GroupCallManager.decline()
            }
        }
    }
    fun accept() {
        val need = neededPerms(ctx, st.video)
        if (need.isEmpty()) GroupCallManager.accept(me)
        else {
            wantAccept = true
            launcher.launch(need.toTypedArray())
        }
    }

    BackHandler {
        if (st.phase == Phase.INCOMING) GroupCallManager.decline() else GroupCallManager.hangup()
    }

    Box(Modifier.fillMaxSize().background(CallBg).pointerInput(Unit) { detectTapGestures { } }) {
        if (st.phase == Phase.INCOMING) {
            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(90.dp))
                Text(if (st.video) "Görüntülü grup araması" else "Sesli grup araması", color = AuraRawMuted, fontSize = 16.sp)
                Spacer(Modifier.height(30.dp))
                Avatar(st.groupName, "", 140.dp, isGroup = true)
                Spacer(Modifier.height(24.dp))
                Text(st.groupName, color = Color.White, fontSize = 30.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                Text(st.callerName + " arıyor...", color = AuraRawMuted, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp))
                Spacer(Modifier.weight(1f))
                Row(Modifier.fillMaxWidth().padding(bottom = 48.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    RoundAction(CallRed, 72, Icons.Default.CallEnd, "Reddet", "Reddet") { GroupCallManager.decline() }
                    RoundAction(CallGreen, 72, if (st.video) Icons.Default.Videocam else Icons.Default.Call, "Katıl", "Katıl", ::accept)
                }
            }
        } else {
            GroupActive(me, st)
        }
    }
}

@Composable
private fun GroupTile(name: String, avatar: String, track: VideoTrack?, mirror: Boolean, connected: Boolean, modifier: Modifier) {
    Box(modifier.padding(3.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF1F2C34))) {
        if (track != null) {
            VideoView(track, mirror, false, Modifier.fillMaxSize())
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Avatar(name, avatar, 72.dp) }
        }
        Text(
            if (connected) name else "$name (bağlanıyor)", color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart).padding(8.dp)
                .background(Color(0x66000000), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
private fun GroupActive(me: UserProfile, st: com.aurachat.app.call.GroupCallUi) {
    var tick by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(st.connectedAt) {
        while (st.connectedAt > 0) {
            tick = System.currentTimeMillis()
            delay(1000)
        }
    }
    val status = when {
        st.connectedAt > 0 && st.message.isBlank() -> fmtTimer(maxOf(0L, (tick - st.connectedAt) / 1000L))
        st.message.isNotBlank() -> st.message
        else -> ""
    }
    data class T(val key: String, val name: String, val avatar: String, val track: VideoTrack?, val mirror: Boolean, val ok: Boolean)
    val tiles = ArrayList<T>()
    tiles.add(T("me", "Sen", me.avatar, if (st.camOn) st.localVideo else null, st.frontCam, true))
    st.peers.forEach { tiles.add(T(it.uid, it.name.ifBlank { "Kullanıcı" }, it.avatar, it.video, false, it.connected)) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)) {
            Text(st.groupName, color = Color.White, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (status.isNotEmpty()) Text(status, color = Color(0xFFD1D5DB), fontSize = 14.sp)
        }
        val cols = if (tiles.size <= 1) 1 else 2
        val rows = tiles.chunked(cols)
        Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 4.dp)) {
            rows.forEach { row ->
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    row.forEach { t ->
                        androidx.compose.runtime.key(t.key) {
                            GroupTile(t.name, t.avatar, t.track, t.mirror, t.ok, Modifier.weight(1f).fillMaxSize())
                        }
                    }
                    if (row.size < cols) Box(Modifier.weight((cols - row.size).toFloat()))
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (st.video) {
                CtlButton(if (st.camOn) Icons.Default.Videocam else Icons.Default.VideocamOff, !st.camOn) { GroupCallManager.toggleCam() }
                CtlButton(Icons.Default.FlipCameraAndroid, false) { GroupCallManager.switchCamera() }
            } else {
                CtlButton(Icons.Default.VolumeUp, st.speakerOn) { GroupCallManager.toggleSpeaker() }
            }
            CtlButton(if (st.micOn) Icons.Default.Mic else Icons.Default.MicOff, !st.micOn) { GroupCallManager.toggleMic() }
            Box(
                Modifier.size(64.dp).clip(CircleShape).background(CallRed).clickable { GroupCallManager.hangup() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.CallEnd, "Kapat", tint = Color.White, modifier = Modifier.size(30.dp)) }
        }
    }
}

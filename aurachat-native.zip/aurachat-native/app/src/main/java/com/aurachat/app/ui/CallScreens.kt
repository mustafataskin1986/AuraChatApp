package com.aurachat.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.aurachat.app.call.CallManager
import com.aurachat.app.call.CallUi
import com.aurachat.app.call.Phase
import com.aurachat.app.data.CallLog
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.delay
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import java.util.Calendar

private val CallBg = Color(0xFF0B141A)
private val CallRed = Color(0xFFEF4444)
private val CallGreen = Color(0xFF22C55E)
private val CallBtn = Color(0x33FFFFFF)

private fun has(ctx: Context, perm: String) =
    ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

private fun neededPerms(ctx: Context, video: Boolean): List<String> {
    val l = ArrayList<String>()
    if (!has(ctx, Manifest.permission.RECORD_AUDIO)) l.add(Manifest.permission.RECORD_AUDIO)
    if (video && !has(ctx, Manifest.permission.CAMERA)) l.add(Manifest.permission.CAMERA)
    return l
}

/** (sohbet, görüntülü mü) → izinleri iste, sonra aramayı başlat */
@Composable
fun rememberCallStarter(me: UserProfile): (ChatTarget, Boolean) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<Pair<ChatTarget, Boolean>?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val p = pending
        pending = null
        if (p != null) {
            if (neededPerms(ctx, p.second).isEmpty()) CallManager.startCall(me, p.first, p.second)
            else Toast.makeText(ctx, "Arama için izin gerekli", Toast.LENGTH_SHORT).show()
        }
    }
    return { t, video ->
        val need = neededPerms(ctx, video)
        if (need.isEmpty()) CallManager.startCall(me, t, video)
        else {
            pending = t to video
            launcher.launch(need.toTypedArray())
        }
    }
}

// =====================================================================
//  ARAMA EKRANI (gelen + giden + aktif) — her ekranın üstünde
// =====================================================================
@Composable
fun CallOverlay() {
    val st by CallManager.ui.collectAsState()
    if (st.phase == Phase.IDLE) return
    val ctx = LocalContext.current

    var wantAccept by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (wantAccept) {
            wantAccept = false
            if (neededPerms(ctx, st.video).isEmpty()) CallManager.accept()
            else {
                Toast.makeText(ctx, "Arama için izin gerekli", Toast.LENGTH_SHORT).show()
                CallManager.decline()
            }
        }
    }
    fun accept() {
        val need = neededPerms(ctx, st.video)
        if (need.isEmpty()) CallManager.accept()
        else {
            wantAccept = true
            launcher.launch(need.toTypedArray())
        }
    }

    BackHandler {
        if (st.phase == Phase.INCOMING) CallManager.decline() else CallManager.hangup()
    }

    Box(Modifier.fillMaxSize().background(CallBg).pointerInput(Unit) { detectTapGestures { } }) {
        if (st.phase == Phase.INCOMING) IncomingCall(st, ::accept) else ActiveCall(st)
    }
}

@Composable
private fun CallAvatar(st: CallUi, size: Int) {
    Avatar(st.otherName, st.otherAvatar, size.dp)
}

@Composable
private fun IncomingCall(st: CallUi, onAccept: () -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(90.dp))
        Text(if (st.video) "Görüntülü arama" else "Sesli arama", color = AuraMuted, fontSize = 16.sp)
        Spacer(Modifier.height(30.dp))
        CallAvatar(st, 140)
        Spacer(Modifier.height(24.dp))
        Text(st.otherName, color = Color.White, fontSize = 30.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        Text("AuraChat arıyor...", color = AuraMuted, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth().padding(bottom = 48.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            RoundAction(CallRed, 72, Icons.Default.CallEnd, "Reddet", "Reddet") { CallManager.decline() }
            RoundAction(CallGreen, 72, if (st.video) Icons.Default.Videocam else Icons.Default.Call, "Cevapla", "Cevapla", onAccept)
        }
    }
}

@Composable
private fun RoundAction(
    color: Color, size: Int, icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String, label: String, onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(size.dp).clip(CircleShape).background(color).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Icon(icon, desc, tint = Color.White, modifier = Modifier.size((size * 0.42f).dp)) }
        Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

private fun fmtTimer(sec: Long): String = "%02d:%02d".format(sec / 60, sec % 60)

@Composable
private fun ActiveCall(st: CallUi) {
    var tick by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(st.connectedAt) {
        while (st.connectedAt > 0) {
            tick = System.currentTimeMillis()
            delay(1000)
        }
    }
    val status = when {
        st.phase == Phase.CONNECTED -> fmtTimer(maxOf(0L, (tick - st.connectedAt) / 1000L))
        st.message.isNotBlank() -> st.message
        else -> ""
    }
    var swapped by remember { mutableStateOf(false) }
    val showVideo = st.video && (st.remoteVideo != null || st.localVideo != null)

    Box(Modifier.fillMaxSize()) {
        if (showVideo) {
            val bigTrack = if (swapped) st.localVideo else st.remoteVideo
            val smallTrack = if (swapped) st.remoteVideo else st.localVideo
            val bigMirror = swapped && st.frontCam
            val smallMirror = !swapped && st.frontCam
            VideoView(bigTrack, bigMirror, false, Modifier.fillMaxSize())
            if (bigTrack == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CallAvatar(st, 120) }
            }
            if (smallTrack != null) {
                Box(
                    Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 70.dp, end = 14.dp)
                        .size(width = 104.dp, height = 150.dp).clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF1F2C34)).clickable { swapped = !swapped }
                ) { VideoView(smallTrack, smallMirror, true, Modifier.fillMaxSize()) }
            }
            Column(
                Modifier.fillMaxWidth().align(Alignment.TopCenter)
                    .background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent)))
                    .statusBarsPadding().padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Text(st.otherName, color = Color.White, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (status.isNotEmpty()) Text(status, color = Color(0xFFD1D5DB), fontSize = 14.sp)
            }
        } else {
            Column(
                Modifier.fillMaxSize().statusBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(90.dp))
                CallAvatar(st, 150)
                Spacer(Modifier.height(24.dp))
                Text(st.otherName, color = Color.White, fontSize = 30.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 24.dp))
                Text(status, color = AuraMuted, fontSize = 17.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }

        // alt kontroller
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000))))
                .navigationBarsPadding().padding(horizontal = 16.dp, vertical = 24.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (st.video) {
                CtlButton(if (st.camOn) Icons.Default.Videocam else Icons.Default.VideocamOff, !st.camOn) { CallManager.toggleCam() }
                CtlButton(Icons.Default.FlipCameraAndroid, false) { CallManager.switchCamera() }
            } else {
                CtlButton(Icons.Default.VolumeUp, st.speakerOn) { CallManager.toggleSpeaker() }
            }
            CtlButton(if (st.micOn) Icons.Default.Mic else Icons.Default.MicOff, !st.micOn) { CallManager.toggleMic() }
            Box(
                Modifier.size(64.dp).clip(CircleShape).background(CallRed).clickable { CallManager.hangup() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.CallEnd, "Kapat", tint = Color.White, modifier = Modifier.size(30.dp)) }
        }
    }
}

@Composable
private fun CtlButton(icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(56.dp).clip(CircleShape).background(if (active) Color.White else CallBtn).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = if (active) Color.Black else Color.White, modifier = Modifier.size(26.dp)) }
}

@Composable
private fun VideoView(track: VideoTrack?, mirror: Boolean, overlay: Boolean, modifier: Modifier) {
    val ctx = LocalContext.current
    val renderer = remember {
        SurfaceViewRenderer(ctx).apply {
            init(CallManager.egl.eglBaseContext, null)
            setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
            setEnableHardwareScaler(true)
            if (overlay) setZOrderMediaOverlay(true)
        }
    }
    DisposableEffect(track) {
        try { track?.addSink(renderer) } catch (e: Throwable) {}
        onDispose { try { track?.removeSink(renderer) } catch (e: Throwable) {} }
    }
    DisposableEffect(Unit) {
        onDispose { try { renderer.release() } catch (e: Throwable) {} }
    }
    AndroidView(factory = { renderer }, modifier = modifier, update = { it.setMirror(mirror) })
}

// =====================================================================
//  ARAMALAR SEKMESİ
// =====================================================================
private fun callTimeLabel(ms: Long): String {
    val d = Calendar.getInstance().apply { timeInMillis = ms }
    val now = Calendar.getInstance()
    val hm = formatClock(ms)
    if (d.get(Calendar.YEAR) == now.get(Calendar.YEAR) && d.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)) return hm
    val y = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    if (d.get(Calendar.YEAR) == y.get(Calendar.YEAR) && d.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)) return "Dün $hm"
    val months = listOf("Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara")
    return d.get(Calendar.DAY_OF_MONTH).toString() + " " + months[d.get(Calendar.MONTH)] + " " + hm
}

@Composable
fun CallsScreen(
    me: UserProfile,
    onOpenChat: (ChatTarget) -> Unit,
    onCall: (ChatTarget, Boolean) -> Unit
) {
    val logs by remember(me.uid) { Repo.callsFlow(me.uid) }.collectAsState(emptyList<CallLog>())
    Box(Modifier.fillMaxSize().background(AuraBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Text(
                "Aramalar", color = Color.White, fontSize = 22.sp,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp)
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (logs.isEmpty()) {
                    Text(
                        "Henüz arama yok.", color = AuraMuted, fontSize = 13.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 40.dp)
                    )
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(logs, key = { it.id }) { c -> CallRow(me, c, onOpenChat, onCall) }
                    }
                }
            }
        }
    }
}

@Composable
private fun CallRow(me: UserProfile, c: CallLog, onOpenChat: (ChatTarget) -> Unit, onCall: (ChatTarget, Boolean) -> Unit) {
    val prof by produceState<UserProfile?>(null, c.otherUid) { value = if (c.otherUid.isEmpty()) null else Repo.profileOf(c.otherUid) }
    val p = prof
    val name = (p?.name ?: "").ifBlank { c.otherName }.ifBlank { "Kullanıcı" }
    val missed = c.result == "missed" || c.result == "declined"
    val target = ChatTarget(Repo.chatId(me.uid, c.otherUid), false, c.otherUid, name)
    val sub = when (c.result) {
        "answered" -> "%02d:%02d".format(c.duration / 60, c.duration % 60)
        "missed" -> "Cevapsız"
        "declined" -> "Reddedildi"
        else -> ""
    }
    val arrowColor = if (c.result == "answered") CallGreen else CallRed
    Row(
        Modifier.fillMaxWidth().clickable { onOpenChat(target) }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(name, p?.avatar ?: "", 50.dp)
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(
                name, color = if (missed) Color(0xFFF87171) else Color(0xFFE5E7EB), fontSize = 16.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (c.direction == "out") Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    null, tint = arrowColor, modifier = Modifier.size(14.dp)
                )
                Text(
                    " " + callTimeLabel(c.at) + (if (sub.isNotEmpty()) " · $sub" else ""),
                    color = AuraMuted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        Box(
            Modifier.size(44.dp).clip(CircleShape).clickable { onCall(target, c.callType != "audio") },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (c.callType == "audio") Icons.Default.Call else Icons.Default.Videocam,
                "Ara", tint = AuraGreen, modifier = Modifier.size(24.dp)
            )
        }
    }
}

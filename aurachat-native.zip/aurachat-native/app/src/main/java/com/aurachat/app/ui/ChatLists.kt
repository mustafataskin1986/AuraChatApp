package com.aurachat.app.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.ChatSummary
import com.aurachat.app.data.Repo
import org.json.JSONArray
import org.json.JSONObject

/** Kullanıcının oluşturduğu sohbet listeleri (Sohbetler sekmesinde çip olarak görünür) */
object ChatLists {
    class L(val id: String, val name: String, val chatIds: List<String>)

    val lists = mutableStateListOf<L>()
    private var loaded = false

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("aura", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val a = JSONArray(prefs(ctx).getString("custom_lists", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val ids = o.optJSONArray("c") ?: JSONArray()
                lists.add(L(o.getString("id"), o.getString("n"), (0 until ids.length()).map { ids.getString(it) }))
            }
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatLists", e) }
    }

    private fun save(ctx: Context) {
        val a = JSONArray()
        lists.forEach { a.put(JSONObject().put("id", it.id).put("n", it.name).put("c", JSONArray(it.chatIds))) }
        prefs(ctx).edit().putString("custom_lists", a.toString()).apply()
    }

    fun put(ctx: Context, id: String?, name: String, ids: List<String>) {
        load(ctx)
        val i = lists.indexOfFirst { it.id == id }
        if (i >= 0) lists[i] = L(lists[i].id, name, ids) else lists.add(L(java.util.UUID.randomUUID().toString().take(8), name, ids))
        save(ctx)
    }

    fun delete(ctx: Context, id: String) { load(ctx); lists.removeAll { it.id == id }; save(ctx) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListEditorSheet(initial: ChatLists.L?, chats: List<ChatSummary>, names: Map<String, String>, onSave: (String, List<String>) -> Unit, onDelete: (() -> Unit)?, onDismiss: () -> Unit) {
    val dn = LocalDensity.current
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var ids by remember { mutableStateOf(initial?.chatIds ?: emptyList()) }
    var picking by remember { mutableStateOf(false) }
    ModalBottomSheet(
        onDismissRequest = onDismiss, containerColor = auraLc(0xFF12171B),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = { Box(Modifier.padding(top = with(dn) { 24f.toDp() }, bottom = with(dn) { 6f.toDp() }).width(with(dn) { 88f.toDp() }).height(with(dn) { 12f.toDp() }).clip(RoundedCornerShape(50)).background(AuraMuted.copy(alpha = 0.6f))) }
    ) {
        Column(Modifier.fillMaxWidth().imePadding().navigationBarsPadding().padding(horizontal = with(dn) { 55f.toDp() })) {
            Box(Modifier.fillMaxWidth().padding(top = with(dn) { 20f.toDp() })) {
                IconButton(onClick = onDismiss, modifier = Modifier.align(Alignment.CenterStart)) { Icon(Icons.Default.Close, "Kapat", tint = AuraWhite) }
                Text(if (initial == null) "Yeni liste" else "Listeyi düzenle", color = AuraWhite, fontSize = with(dn) { 60f.toSp() }, modifier = Modifier.align(Alignment.Center))
            }
            Text("Liste adı", color = AuraMuted, fontSize = with(dn) { 42f.toSp() }, modifier = Modifier.padding(top = with(dn) { 80f.toDp() }, bottom = with(dn) { 18f.toDp() }))
            val shape = RoundedCornerShape(with(dn) { 28f.toDp() })
            BasicTextField(
                value = name, onValueChange = { if (it.length <= 30) name = it }, singleLine = true,
                textStyle = TextStyle(color = AuraWhite, fontSize = with(dn) { 46f.toSp() }),
                cursorBrush = SolidColor(AuraGreen),
                modifier = Modifier.fillMaxWidth().height(with(dn) { 160f.toDp() }).clip(shape).border(with(dn) { 5f.toDp() }, AuraGreen, shape),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxSize().padding(horizontal = with(dn) { 44f.toDp() }), contentAlignment = Alignment.CenterStart) {
                        if (name.isEmpty()) Text("Örnek: İş, Arkadaşlar", color = AuraMuted.copy(alpha = 0.8f), fontSize = with(dn) { 46f.toSp() })
                        inner()
                    }
                }
            )
            Text("Oluşturduğunuz her liste Sohbetler sekmenizin üst kısmında bir filtre olarak görünür.", color = AuraMuted, fontSize = with(dn) { 42f.toSp() }, modifier = Modifier.padding(top = with(dn) { 28f.toDp() }))
            if (ids.isNotEmpty()) {
                Text(
                    "${ids.size} sohbet seçili · Değiştir", color = AuraGreen, fontSize = with(dn) { 44f.toSp() },
                    modifier = Modifier.padding(top = with(dn) { 36f.toDp() }).clip(RoundedCornerShape(50)).clickable { picking = true }.padding(vertical = 8.dp)
                )
            }
            if (onDelete != null) {
                Text("Listeyi sil", color = Color(0xFFF15C6D), fontSize = with(dn) { 44f.toSp() }, modifier = Modifier.padding(top = with(dn) { 12f.toDp() }).clip(RoundedCornerShape(50)).clickable { onDelete() }.padding(vertical = 8.dp))
            }
            val ready = name.isNotBlank()
            val hasIds = ids.isNotEmpty()
            Box(
                Modifier.padding(top = with(dn) { 70f.toDp() }, bottom = with(dn) { 36f.toDp() }).fillMaxWidth().height(with(dn) { 110f.toDp() }).clip(RoundedCornerShape(50))
                    .background(if (ready) AuraGreen else Color.White.copy(alpha = 0.10f))
                    .clickable(enabled = ready) { if (!hasIds) picking = true else { onSave(name.trim(), ids) } },
                contentAlignment = Alignment.Center
            ) {
                Text(if (!hasIds) "Kişi veya grup ekleyin" else "Kaydet", color = if (ready) Color.White else AuraMuted.copy(alpha = 0.6f), fontSize = with(dn) { 46f.toSp() }, fontWeight = FontWeight.Normal)
            }
        }
    }
    if (picking) androidx.compose.ui.window.Dialog(
        onDismissRequest = { picking = false },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(60.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { picking = false }) { Icon(Icons.Default.Close, "Kapat", tint = AuraWhite) }
                Text("Kişi veya grup ekleyin", color = AuraWhite, fontSize = 20.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { picking = false }) { Text("Tamam", color = AuraGreen, fontWeight = FontWeight.Bold) }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(chats.filter { !it.archivedChat }, key = { it.chatId }) { c ->
                    val on = ids.contains(c.chatId)
                    val nm = names[c.otherUid] ?: c.name
                    Row(
                        Modifier.fillMaxWidth().clickable { ids = if (on) ids - c.chatId else ids + c.chatId }.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(nm, if (c.isGroup) Repo.peekGroup(c.otherUid)?.photo else Repo.peekProfile(c.otherUid)?.avatar, 44.dp, c.isGroup)
                        Spacer(Modifier.width(14.dp))
                        Text(nm, color = AuraWhite, fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f))
                        Box(
                            Modifier.height(24.dp).width(24.dp).clip(RoundedCornerShape(6.dp)).background(if (on) AuraGreen else Color.Transparent)
                                .border(2.dp, if (on) AuraGreen else AuraMuted, RoundedCornerShape(6.dp)),
                            contentAlignment = Alignment.Center
                        ) { if (on) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.height(18.dp).width(18.dp)) }
                    }
                }
            }
        }
    }
}

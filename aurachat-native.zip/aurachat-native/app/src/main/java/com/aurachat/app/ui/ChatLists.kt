package com.aurachat.app.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.focus.focusRequester
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material.icons.filled.Add
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.ChatSummary
import com.aurachat.app.data.Repo
import org.json.JSONArray
import org.json.JSONObject

/** Kullanıcının oluşturduğu sohbet listeleri (Sohbetler sekmesinde çip olarak görünür) */
object ChatLists {
    class L(val id: String, val name: String, val chatIds: List<String>)

    val lists = mutableStateListOf<L>()
    private var loaded = false

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("aura", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val a = JSONArray(prefs(ctx).getString("custom_lists", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val ids = o.optJSONArray("c") ?: JSONArray()
                lists.add(L(o.getString("id"), o.getString("n"), (0 until ids.length()).map { ids.getString(it) }))
            }
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatLists", e) }
    }

    private fun save(ctx: Context) {
        val a = JSONArray()
        lists.forEach { a.put(JSONObject().put("id", it.id).put("n", it.name).put("c", JSONArray(it.chatIds))) }
        prefs(ctx).edit().putString("custom_lists", a.toString()).apply()
    }

    fun put(ctx: Context, id: String?, name: String, ids: List<String>): L {
        load(ctx)
        val i = lists.indexOfFirst { it.id == id }
        val l: L
        if (i >= 0) { l = L(lists[i].id, name, ids); lists[i] = l } else { l = L(java.util.UUID.randomUUID().toString().take(8), name, ids); lists.add(l) }
        save(ctx)
        return l
    }

    fun allIn(id: String, chatIds: List<String>): Boolean = lists.firstOrNull { it.id == id }?.chatIds?.let { c -> chatIds.isNotEmpty() && chatIds.all { it in c } } == true

    fun setMembers(ctx: Context, id: String, chatIds: List<String>, add: Boolean) {
        load(ctx)
        val l = lists.firstOrNull { it.id == id } ?: return
        put(ctx, id, l.name, if (add) (l.chatIds + chatIds.filter { it !in l.chatIds }) else l.chatIds.filter { it !in chatIds })
    }

    fun delete(ctx: Context, id: String) { load(ctx); lists.removeAll { it.id == id }; save(ctx) }
}

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun ListEditorSheet(initial: ChatLists.L?, chats: List<ChatSummary>, names: Map<String, String>, onSave: (String, List<String>) -> Unit, onDelete: (() -> Unit)?, onDismiss: () -> Unit, hiddenChips: List<Pair<String, String>> = emptyList(), onRestore: (String) -> Unit = {}) {
    val dn = LocalDensity.current
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var ids by remember { mutableStateOf(initial?.chatIds ?: emptyList()) }
    var picking by remember { mutableStateOf(false) }
    ModalBottomSheet(
        onDismissRequest = onDismiss, containerColor = auraLc(0xFF12171B),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = { Box(Modifier.padding(top = with(dn) { 24f.toDp() }, bottom = with(dn) { 6f.toDp() }).width(with(dn) { 88f.toDp() }).height(with(dn) { 12f.toDp() }).clip(RoundedCornerShape(50)).background(AuraMuted.copy(alpha = 0.6f))) }
    ) {
        Column(Modifier.fillMaxWidth().imePadding().navigationBarsPadding().padding(horizontal = with(dn) { 55f.toDp() })) {
            Box(Modifier.fillMaxWidth().padding(top = with(dn) { 20f.toDp() })) {
                IconButton(onClick = onDismiss, modifier = Modifier.align(Alignment.CenterStart)) { Icon(Icons.Default.Close, "Kapat", tint = AuraWhite) }
                Text(if (initial == null) "Yeni liste" else "Listeyi düzenle", color = AuraWhite, fontSize = with(dn) { 60f.toSp() }, modifier = Modifier.align(Alignment.Center))
            }
            if (hiddenChips.isNotEmpty()) {
                Text("Gizlenen çipler (dokunarak geri getir)", color = AuraMuted, fontSize = with(dn) { 42f.toSp() }, modifier = Modifier.padding(top = with(dn) { 50f.toDp() }))
                androidx.compose.foundation.layout.FlowRow(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    hiddenChips.forEach { (k, lbl) ->
                        Text(lbl, color = AuraGreen, fontSize = 15.sp, modifier = Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.10f)).clickable { onRestore(k) }.padding(horizontal = 16.dp, vertical = 6.dp))
                    }
                }
            }
            Text("Liste adı", color = AuraMuted, fontSize = with(dn) { 42f.toSp() }, modifier = Modifier.padding(top = with(dn) { 60f.toDp() }, bottom = with(dn) { 18f.toDp() }))
            val shape = RoundedCornerShape(with(dn) { 28f.toDp() })
            BasicTextField(
                value = name, onValueChange = { if (it.length <= 30) name = it }, singleLine = true,
                textStyle = TextStyle(color = AuraWhite, fontSize = with(dn) { 46f.toSp() }),
                cursorBrush = SolidColor(AuraGreen),
                modifier = Modifier.fillMaxWidth().height(with(dn) { 160f.toDp() }).clip(shape).border(with(dn) { 5f.toDp() }, AuraGreen, shape),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxSize().padding(horizontal = with(dn) { 44f.toDp() }), contentAlignment = Alignment.CenterStart) {
                        if (name.isEmpty()) Text("Örnek: İş, Arkadaşlar", color = AuraMuted.copy(alpha = 0.8f), fontSize = with(dn) { 46f.toSp() })
                        inner()
                    }
                }
            )
            Text("Oluşturduğunuz her liste Sohbetler sekmenizin üst kısmında bir filtre olarak görünür.", color = AuraMuted, fontSize = with(dn) { 42f.toSp() }, modifier = Modifier.padding(top = with(dn) { 28f.toDp() }))
            if (ids.isNotEmpty()) {
                Text(
                    "${ids.size} sohbet seçili · Değiştir", color = AuraGreen, fontSize = with(dn) { 44f.toSp() },
                    modifier = Modifier.padding(top = with(dn) { 36f.toDp() }).clip(RoundedCornerShape(50)).clickable { picking = true }.padding(vertical = 8.dp)
                )
            }
            if (onDelete != null) {
                Text("Listeyi sil", color = Color(0xFFF15C6D), fontSize = with(dn) { 44f.toSp() }, modifier = Modifier.padding(top = with(dn) { 12f.toDp() }).clip(RoundedCornerShape(50)).clickable { onDelete() }.padding(vertical = 8.dp))
            }
            val ready = name.isNotBlank()
            val hasIds = ids.isNotEmpty()
            Box(
                Modifier.padding(top = with(dn) { 70f.toDp() }, bottom = with(dn) { 36f.toDp() }).fillMaxWidth().height(with(dn) { 110f.toDp() }).clip(RoundedCornerShape(50))
                    .background(if (ready) AuraGreen else Color.White.copy(alpha = 0.10f))
                    .clickable(enabled = ready) { if (!hasIds) picking = true else { onSave(name.trim(), ids) } },
                contentAlignment = Alignment.Center
            ) {
                Text(if (!hasIds) "Kişi veya grup ekleyin" else "Kaydet", color = if (ready) Color.White else AuraMuted.copy(alpha = 0.6f), fontSize = with(dn) { 46f.toSp() }, fontWeight = FontWeight.Normal)
            }
        }
    }
    if (picking) androidx.compose.ui.window.Dialog(
        onDismissRequest = { picking = false },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(60.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { picking = false }) { Icon(Icons.Default.Close, "Kapat", tint = AuraWhite) }
                Text("Kişi veya grup ekleyin", color = AuraWhite, fontSize = 20.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { picking = false }) { Text("Tamam", color = AuraGreen, fontWeight = FontWeight.Bold) }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(chats.filter { !it.archivedChat }, key = { it.chatId }) { c ->
                    val on = ids.contains(c.chatId)
                    val nm = names[c.otherUid] ?: c.name
                    Row(
                        Modifier.fillMaxWidth().clickable { ids = if (on) ids - c.chatId else ids + c.chatId }.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(nm, if (c.isGroup) Repo.peekGroup(c.otherUid)?.photo else Repo.peekProfile(c.otherUid)?.avatar, 44.dp, c.isGroup)
                        Spacer(Modifier.width(14.dp))
                        Text(nm, color = AuraWhite, fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f))
                        Box(
                            Modifier.height(24.dp).width(24.dp).clip(RoundedCornerShape(6.dp)).background(if (on) AuraGreen else Color.Transparent)
                                .border(2.dp, if (on) AuraGreen else AuraMuted, RoundedCornerShape(6.dp)),
                            contentAlignment = Alignment.Center
                        ) { if (on) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.height(18.dp).width(18.dp)) }
                    }
                }
            }
        }
    }
}


/** Çip yönetim paneli: ekle, ad değiştir, yukarı/aşağı sırala, kaldır / geri getir */
@Composable
fun ChipManagerDialog(
    vis: List<String>, removed: List<String>, defs: Map<String, String>,
    onReorder: (String, String) -> Unit,      // (taşınan, yerine geçtiği komşu)
    onRemove: (String) -> Unit, onRestore: (String) -> Unit,
    onRename: (String, String) -> Unit, onAdd: (String) -> Unit, onDeleteList: (String) -> Unit, onEditMembers: (String) -> Unit,
    onClose: () -> Unit
) {
    val rowH = 52.dp
    val rowPx = with(LocalDensity.current) { rowH.toPx() }
    // sürükleme sırasında liste değişince hareket kesilmesin: güncel değerler state üzerinden okunur
    val visNow by androidx.compose.runtime.rememberUpdatedState(vis)
    val removedNow by androidx.compose.runtime.rememberUpdatedState(removed)
    val reorderNow by androidx.compose.runtime.rememberUpdatedState(onReorder)
    var adding by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var renaming by remember { mutableStateOf<String?>(null) }
    var renameText by remember { mutableStateOf("") }
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragY by remember { mutableStateOf(0f) }
    val shape = RoundedCornerShape(28.dp)
    val pill = RoundedCornerShape(50)

    @Composable
    fun Handle(k: String, inRemoved: Boolean) {
        Box(
            Modifier.width(44.dp).height(rowH).pointerInput(k, inRemoved) {
                detectDragGestures(
                    onDragStart = { dragKey = k; dragY = 0f },
                    onDrag = { ch, d ->
                        ch.consume(); dragY += d.y
                        // her sürükleme olayında en çok bir satır; sürükledikçe arka arkaya devam eder
                        val v = if (inRemoved) removedNow else visNow
                        val i = v.indexOf(k)
                        if (dragY > rowPx / 2f && i in 0 until v.lastIndex) { reorderNow(k, v[i + 1]); dragY -= rowPx }
                        else if (dragY < -rowPx / 2f && i > 0) { reorderNow(k, v[i - 1]); dragY += rowPx }
                    },
                    onDragEnd = { dragKey = null; dragY = 0f },
                    onDragCancel = { dragKey = null; dragY = 0f }
                )
            },
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.SwapVert, "Sırala", tint = AuraMuted, modifier = Modifier.width(24.dp).height(24.dp)) }
    }

    @Composable
    fun InputPill(value: String, onChange: (String) -> Unit, focus: androidx.compose.ui.focus.FocusRequester, onDone: () -> Unit, trailing: @Composable () -> Unit) {
        Row(
            Modifier.fillMaxWidth().clip(pill).background(ChipLook.glass).padding(start = 18.dp, end = 4.dp).height(46.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = value, onValueChange = onChange, singleLine = true,
                textStyle = TextStyle(color = ChipLook.inputFg, fontSize = 17.sp), cursorBrush = SolidColor(ChipLook.inputFg),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Done),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onDone = { onDone() }),
                modifier = Modifier.weight(1f).focusRequester(focus)
            )
            trailing()
        }
    }

    androidx.compose.ui.window.Dialog(onDismissRequest = onClose) {
        Column(
            Modifier.fillMaxWidth().clip(shape).background(AuraBg).padding(vertical = 16.dp)
                .verticalScroll(androidx.compose.foundation.rememberScrollState())
        ) {
            // Çip ekle: ortada düğme; basınca boş input olur, yazmaya başlayınca yeşil + belirir
            val addFocus = remember { androidx.compose.ui.focus.FocusRequester() }
            androidx.compose.runtime.LaunchedEffect(adding) { if (adding) try { addFocus.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChipMgr", e) } }
            Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp), contentAlignment = Alignment.Center) {
                if (!adding) {
                    Box(
                        Modifier.clip(pill).background(ChipLook.glass).clickable { adding = true }.padding(horizontal = 32.dp).height(46.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("Çip ekle", color = AuraGreen, fontSize = 17.sp, fontWeight = FontWeight.Medium) }
                } else {
                    val ready = newName.isNotBlank()
                    val doAdd = { if (ready) { onAdd(newName.trim()); newName = ""; adding = false } }
                    InputPill(newName, { if (it.length <= 30) newName = it }, addFocus, { doAdd() }) {
                        if (ready) IconButton(onClick = { doAdd() }) { Icon(Icons.Default.Add, "Ekle", tint = AuraGreen) }
                    }
                }
            }
            Text("Çipler", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(start = 22.dp, top = 14.dp, bottom = 2.dp))
            // Tümü: sabit
            Row(Modifier.fillMaxWidth().height(rowH).padding(start = 12.dp, end = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(44.dp), contentAlignment = Alignment.Center) { Icon(Icons.Default.PushPin, null, tint = AuraMuted, modifier = Modifier.width(24.dp).height(24.dp)) }
                Text(defs["all"] ?: "Tümü", color = AuraWhite, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text("Sabit", color = AuraMuted, fontSize = 13.sp)
            }
            vis.forEach { k ->
                androidx.compose.runtime.key(k) {
                    val isList = k.startsWith("list:")
                    val dragging = dragKey == k
                    val fr = remember { androidx.compose.ui.focus.FocusRequester() }
                    androidx.compose.runtime.LaunchedEffect(renaming) { if (renaming == k) try { fr.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChipMgr", e) } }
                    val saveRename = { if (renameText.isNotBlank()) onRename(k, renameText.trim()); renaming = null }
                    if (renaming == k) {
                        // satır komple input: boş başlar, yazınca tık çıkar
                        Box(Modifier.fillMaxWidth().height(rowH).padding(horizontal = 18.dp), contentAlignment = Alignment.Center) {
                            InputPill(renameText, { if (it.length <= 30) renameText = it }, fr, { saveRename() }) {
                                if (renameText.isNotBlank()) IconButton(onClick = { saveRename() }) { Icon(Icons.Default.Check, "Kaydet", tint = AuraGreen) }
                            }
                        }
                    } else {
                        Row(
                            Modifier.fillMaxWidth().height(rowH)
                                .graphicsLayer { translationY = if (dragging) dragY else 0f; alpha = if (dragging) 0.92f else 1f }
                                .background(if (dragging) Color.White.copy(alpha = 0.08f) else Color.Transparent)
                                .padding(start = 12.dp, end = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Handle(k, false)
                            Column(Modifier.weight(1f).clickable { renaming = k; renameText = "" }) {
                                Text(defs[k] ?: "", color = AuraWhite, fontSize = 17.sp, maxLines = 1, modifier = Modifier.fillMaxWidth())
                                if (isList) {
                                    val n = ChatLists.lists.firstOrNull { "list:" + it.id == k }?.chatIds?.size ?: 0
                                    Text(if (n == 0) "Boş · sohbet eklemek için kişi simgesine bas" else "$n sohbet", color = AuraMuted, fontSize = 12.sp, maxLines = 1)
                                }
                            }
                            if (isList) IconButton(onClick = { onEditMembers(k.removePrefix("list:")) }) { Icon(Icons.Default.GroupAdd, "Sohbetleri değiştir", tint = AuraMuted) }
                            IconButton(onClick = { onRemove(k) }) { Icon(Icons.Default.RemoveCircleOutline, "Kaldır", tint = Color(0xFFF15C6D)) }
                        }
                    }
                }
            }
            if (removed.isNotEmpty()) {
                Text("Kaldırılanlar", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(start = 22.dp, top = 14.dp, bottom = 2.dp))
                removed.forEach { k ->
                    androidx.compose.runtime.key("r-$k") {
                        val dragging = dragKey == k
                        Row(
                            Modifier.fillMaxWidth().height(rowH)
                                .graphicsLayer { translationY = if (dragging) dragY else 0f; alpha = if (dragging) 0.92f else 1f }
                                .background(if (dragging) Color.White.copy(alpha = 0.08f) else Color.Transparent)
                                .padding(start = 12.dp, end = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Handle(k, true)
                            Text(defs[k] ?: "", color = AuraMuted, fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f))
                            if (k.startsWith("list:")) IconButton(onClick = { onDeleteList(k.removePrefix("list:")) }) { Icon(Icons.Default.Delete, "Sil", tint = AuraMuted) }
                            IconButton(onClick = { onRestore(k) }) { Icon(Icons.Default.AddCircleOutline, "Geri getir", tint = AuraGreen) }
                        }
                    }
                }
            }
            Text(
                "Tamam", color = AuraGreen, fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.End,
                modifier = Modifier.fillMaxWidth().clickable { onClose() }.padding(horizontal = 24.dp, vertical = 14.dp)
            )
        }
    }
}


/** "Listeye ekle": Favoriler + kullanıcının tüm listeleri; işaretleyince sohbet(ler) oraya kaydolur */
@Composable
fun AddToListDialog(chatIds: List<String>, favOn: Boolean, onToggleFav: (Boolean) -> Unit, onClose: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.runtime.LaunchedEffect(Unit) { ChatLists.load(ctx) }
    val favName = remember {
        try { org.json.JSONObject(ctx.getSharedPreferences("aura", Context.MODE_PRIVATE).getString("chip_names", "{}") ?: "{}").optString("fav", "").ifBlank { "Favoriler" } } catch (e: Throwable) { "Favoriler" }
    }
    var fav by remember { mutableStateOf(favOn) }
    androidx.compose.ui.window.Dialog(onDismissRequest = onClose) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(AuraBg).padding(vertical = 16.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
            Text("Listeye ekle", color = AuraWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp))
            @Composable
            fun Row1(name: String, on: Boolean, click: () -> Unit) {
                Row(Modifier.fillMaxWidth().height(52.dp).clickable { click() }.padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = AuraWhite, fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f))
                    Box(
                        Modifier.height(24.dp).width(24.dp).clip(RoundedCornerShape(6.dp)).background(if (on) AuraGreen else Color.Transparent).border(2.dp, if (on) AuraGreen else AuraMuted, RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) { if (on) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.height(18.dp).width(18.dp)) }
                }
            }
            Row1(favName, fav) { fav = !fav; onToggleFav(fav) }
            ChatLists.lists.forEach { l ->
                val on = ChatLists.allIn(l.id, chatIds)
                Row1(l.name, on) { ChatLists.setMembers(ctx, l.id, chatIds, !on) }
            }
            Text("Tamam", color = AuraGreen, fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().clickable { onClose() }.padding(horizontal = 24.dp, vertical = 14.dp))
        }
    }
}

/** Sohbet menüsünden "Listeye ekle" isteği (menü ile ekran ayrı fonksiyonlarda olduğu için ortak durum) */
object AddListReq { var chatId by androidx.compose.runtime.mutableStateOf<String?>(null) }

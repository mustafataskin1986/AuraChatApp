package com.aurachat.app.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.material.icons.filled.Add
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.ChatSummary
import com.aurachat.app.data.Repo
import org.json.JSONArray
import org.json.JSONObject

/** Kullanıcının oluşturduğu sohbet listeleri (Sohbetler sekmesinde çip olarak görünür) */
object ChatLists {
    class L(val id: String, val name: String, val chatIds: List<String>)

    val lists = mutableStateListOf<L>()
    private var loaded = false

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("aura", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val a = JSONArray(prefs(ctx).getString("custom_lists", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val ids = o.optJSONArray("c") ?: JSONArray()
                lists.add(L(o.getString("id"), o.getString("n"), (0 until ids.length()).map { ids.getString(it) }))
            }
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ChatLists", e) }
    }

    private fun save(ctx: Context) {
        val a = JSONArray()
        lists.forEach { a.put(JSONObject().put("id", it.id).put("n", it.name).put("c", JSONArray(it.chatIds))) }
        prefs(ctx).edit().putString("custom_lists", a.toString()).apply()
    }

    fun put(ctx: Context, id: String?, name: String, ids: List<String>): L {
        load(ctx)
        val i = lists.indexOfFirst { it.id == id }
        val l: L
        if (i >= 0) { l = L(lists[i].id, name, ids); lists[i] = l } else { l = L(java.util.UUID.randomUUID().toString().take(8), name, ids); lists.add(l) }
        save(ctx)
        return l
    }

    fun delete(ctx: Context, id: String) { load(ctx); lists.removeAll { it.id == id }; save(ctx) }
}

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun ListEditorSheet(initial: ChatLists.L?, chats: List<ChatSummary>, names: Map<String, String>, onSave: (String, List<String>) -> Unit, onDelete: (() -> Unit)?, onDismiss: () -> Unit, hiddenChips: List<Pair<String, String>> = emptyList(), onRestore: (String) -> Unit = {}) {
    val dn = LocalDensity.current
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var ids by remember { mutableStateOf(initial?.chatIds ?: emptyList()) }
    var picking by remember { mutableStateOf(false) }
    ModalBottomSheet(
        onDismissRequest = onDismiss, containerColor = auraLc(0xFF12171B),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = { Box(Modifier.padding(top = with(dn) { 24f.toDp() }, bottom = with(dn) { 6f.toDp() }).width(with(dn) { 88f.toDp() }).height(with(dn) { 12f.toDp() }).clip(RoundedCornerShape(50)).background(AuraMuted.copy(alpha = 0.6f))) }
    ) {
        Column(Modifier.fillMaxWidth().imePadding().navigationBarsPadding().padding(horizontal = with(dn) { 55f.toDp() })) {
            Box(Modifier.fillMaxWidth().padding(top = with(dn) { 20f.toDp() })) {
                IconButton(onClick = onDismiss, modifier = Modifier.align(Alignment.CenterStart)) { Icon(Icons.Default.Close, "Kapat", tint = AuraWhite) }
                Text(if (initial == null) "Yeni liste" else "Listeyi düzenle", color = AuraWhite, fontSize = with(dn) { 60f.toSp() }, modifier = Modifier.align(Alignment.Center))
            }
            if (hiddenChips.isNotEmpty()) {
                Text("Gizlenen çipler (dokunarak geri getir)", color = AuraMuted, fontSize = with(dn) { 42f.toSp() }, modifier = Modifier.padding(top = with(dn) { 50f.toDp() }))
                androidx.compose.foundation.layout.FlowRow(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    hiddenChips.forEach { (k, lbl) ->
                        Text(lbl, color = AuraGreen, fontSize = 15.sp, modifier = Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.10f)).clickable { onRestore(k) }.padding(horizontal = 16.dp, vertical = 6.dp))
                    }
                }
            }
            Text("Liste adı", color = AuraMuted, fontSize = with(dn) { 42f.toSp() }, modifier = Modifier.padding(top = with(dn) { 60f.toDp() }, bottom = with(dn) { 18f.toDp() }))
            val shape = RoundedCornerShape(with(dn) { 28f.toDp() })
            BasicTextField(
                value = name, onValueChange = { if (it.length <= 30) name = it }, singleLine = true,
                textStyle = TextStyle(color = AuraWhite, fontSize = with(dn) { 46f.toSp() }),
                cursorBrush = SolidColor(AuraGreen),
                modifier = Modifier.fillMaxWidth().height(with(dn) { 160f.toDp() }).clip(shape).border(with(dn) { 5f.toDp() }, AuraGreen, shape),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxSize().padding(horizontal = with(dn) { 44f.toDp() }), contentAlignment = Alignment.CenterStart) {
                        if (name.isEmpty()) Text("Örnek: İş, Arkadaşlar", color = AuraMuted.copy(alpha = 0.8f), fontSize = with(dn) { 46f.toSp() })
                        inner()
                    }
                }
            )
            Text("Oluşturduğunuz her liste Sohbetler sekmenizin üst kısmında bir filtre olarak görünür.", color = AuraMuted, fontSize = with(dn) { 42f.toSp() }, modifier = Modifier.padding(top = with(dn) { 28f.toDp() }))
            if (ids.isNotEmpty()) {
                Text(
                    "${ids.size} sohbet seçili · Değiştir", color = AuraGreen, fontSize = with(dn) { 44f.toSp() },
                    modifier = Modifier.padding(top = with(dn) { 36f.toDp() }).clip(RoundedCornerShape(50)).clickable { picking = true }.padding(vertical = 8.dp)
                )
            }
            if (onDelete != null) {
                Text("Listeyi sil", color = Color(0xFFF15C6D), fontSize = with(dn) { 44f.toSp() }, modifier = Modifier.padding(top = with(dn) { 12f.toDp() }).clip(RoundedCornerShape(50)).clickable { onDelete() }.padding(vertical = 8.dp))
            }
            val ready = name.isNotBlank()
            val hasIds = ids.isNotEmpty()
            Box(
                Modifier.padding(top = with(dn) { 70f.toDp() }, bottom = with(dn) { 36f.toDp() }).fillMaxWidth().height(with(dn) { 110f.toDp() }).clip(RoundedCornerShape(50))
                    .background(if (ready) AuraGreen else Color.White.copy(alpha = 0.10f))
                    .clickable(enabled = ready) { if (!hasIds) picking = true else { onSave(name.trim(), ids) } },
                contentAlignment = Alignment.Center
            ) {
                Text(if (!hasIds) "Kişi veya grup ekleyin" else "Kaydet", color = if (ready) Color.White else AuraMuted.copy(alpha = 0.6f), fontSize = with(dn) { 46f.toSp() }, fontWeight = FontWeight.Normal)
            }
        }
    }
    if (picking) androidx.compose.ui.window.Dialog(
        onDismissRequest = { picking = false },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(60.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { picking = false }) { Icon(Icons.Default.Close, "Kapat", tint = AuraWhite) }
                Text("Kişi veya grup ekleyin", color = AuraWhite, fontSize = 20.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { picking = false }) { Text("Tamam", color = AuraGreen, fontWeight = FontWeight.Bold) }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(chats.filter { !it.archivedChat }, key = { it.chatId }) { c ->
                    val on = ids.contains(c.chatId)
                    val nm = names[c.otherUid] ?: c.name
                    Row(
                        Modifier.fillMaxWidth().clickable { ids = if (on) ids - c.chatId else ids + c.chatId }.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(nm, if (c.isGroup) Repo.peekGroup(c.otherUid)?.photo else Repo.peekProfile(c.otherUid)?.avatar, 44.dp, c.isGroup)
                        Spacer(Modifier.width(14.dp))
                        Text(nm, color = AuraWhite, fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f))
                        Box(
                            Modifier.height(24.dp).width(24.dp).clip(RoundedCornerShape(6.dp)).background(if (on) AuraGreen else Color.Transparent)
                                .border(2.dp, if (on) AuraGreen else AuraMuted, RoundedCornerShape(6.dp)),
                            contentAlignment = Alignment.Center
                        ) { if (on) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.height(18.dp).width(18.dp)) }
                    }
                }
            }
        }
    }
}


/** Çip yönetim paneli: ekle, ad değiştir, yukarı/aşağı sırala, kaldır / geri getir */
@Composable
fun ChipManagerDialog(
    vis: List<String>, removed: List<String>, defs: Map<String, String>,
    onReorder: (String, String) -> Unit,      // (taşınan, yerine geçtiği komşu)
    onRemove: (String) -> Unit, onRestore: (String) -> Unit,
    onRename: (String, String) -> Unit, onAdd: (String) -> Unit, onDeleteList: (String) -> Unit,
    onClose: () -> Unit
) {
    val rowH = 52.dp
    val rowPx = with(LocalDensity.current) { rowH.toPx() }
    var adding by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var renaming by remember { mutableStateOf<String?>(null) }
    var renameText by remember { mutableStateOf("") }
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragY by remember { mutableStateOf(0f) }
    val shape = RoundedCornerShape(28.dp)
    androidx.compose.ui.window.Dialog(onDismissRequest = onClose) {
        Column(
            Modifier.fillMaxWidth().clip(shape).background(AuraSurface).padding(vertical = 16.dp)
                .verticalScroll(androidx.compose.foundation.rememberScrollState())
        ) {
            Text("Çipleri düzenle", color = AuraWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 22.dp, vertical = 6.dp))
            // Çip ekle
            Row(
                Modifier.fillMaxWidth().height(rowH).clickable { adding = !adding }.padding(horizontal = 22.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Add, null, tint = AuraGreen, modifier = Modifier.width(24.dp).height(24.dp))
                Spacer(Modifier.width(14.dp))
                Text("Çip ekle", color = AuraGreen, fontSize = 17.sp)
            }
            if (adding) {
                val ready = newName.isNotBlank()
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.10f)).padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = newName, onValueChange = { if (it.length <= 30) newName = it }, singleLine = true,
                        textStyle = TextStyle(color = AuraWhite, fontSize = 17.sp), cursorBrush = SolidColor(AuraGreen),
                        modifier = Modifier.weight(1f).padding(horizontal = 14.dp, vertical = 12.dp),
                        decorationBox = { inner -> Box { if (newName.isEmpty()) Text("Çip adı", color = AuraMuted, fontSize = 17.sp); inner() } }
                    )
                    IconButton(onClick = { if (ready) { onAdd(newName.trim()); newName = ""; adding = false } }) {
                        Icon(Icons.Default.Add, "Ekle", tint = if (ready) AuraGreen else AuraMuted.copy(alpha = 0.5f))
                    }
                }
            }
            Text("Çipler", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(start = 22.dp, top = 14.dp, bottom = 2.dp))
            // Tümü: sabit
            Row(Modifier.fillMaxWidth().height(rowH).padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.width(38.dp))
                Text(defs["all"] ?: "Tümü", color = AuraWhite, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text("Sabit", color = AuraMuted, fontSize = 13.sp)
            }
            vis.forEach { k ->
                androidx.compose.runtime.key(k) {
                    val isList = k.startsWith("list:")
                    val dragging = dragKey == k
                    Row(
                        Modifier.fillMaxWidth().height(rowH)
                            .graphicsLayer { translationY = if (dragging) dragY else 0f; alpha = if (dragging) 0.92f else 1f }
                            .background(if (dragging) Color.White.copy(alpha = 0.08f) else Color.Transparent)
                            .padding(horizontal = 22.dp)
                            .pointerInput(k, vis) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { dragKey = k; dragY = 0f },
                                    onDrag = { ch, d ->
                                        ch.consume(); dragY += d.y
                                        val i = vis.indexOf(k)
                                        if (dragY > rowPx / 2f && i < vis.lastIndex) { onReorder(k, vis[i + 1]); dragY -= rowPx }
                                        else if (dragY < -rowPx / 2f && i > 0) { onReorder(k, vis[i - 1]); dragY += rowPx }
                                    },
                                    onDragEnd = { dragKey = null; dragY = 0f },
                                    onDragCancel = { dragKey = null; dragY = 0f }
                                )
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.DragHandle, null, tint = AuraMuted, modifier = Modifier.width(24.dp).height(24.dp))
                        Spacer(Modifier.width(14.dp))
                        if (renaming == k) {
                            BasicTextField(
                                value = renameText, onValueChange = { if (it.length <= 30) renameText = it }, singleLine = true,
                                textStyle = TextStyle(color = AuraWhite, fontSize = 17.sp), cursorBrush = SolidColor(AuraGreen),
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { if (renameText.isNotBlank()) onRename(k.removePrefix("list:"), renameText.trim()); renaming = null }) { Icon(Icons.Default.Check, "Kaydet", tint = AuraGreen) }
                        } else {
                            Text(defs[k] ?: "", color = AuraWhite, fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f))
                            if (isList) IconButton(onClick = { renaming = k; renameText = defs[k] ?: "" }) { Icon(Icons.Default.Edit, "Adı değiştir", tint = AuraMuted) }
                            IconButton(onClick = { onRemove(k) }) { Icon(Icons.Default.RemoveCircleOutline, "Kaldır", tint = Color(0xFFF15C6D)) }
                        }
                    }
                }
            }
            if (removed.isNotEmpty()) {
                Text("Kaldırılanlar", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(start = 22.dp, top = 14.dp, bottom = 2.dp))
                removed.forEach { k ->
                    Row(Modifier.fillMaxWidth().height(rowH).padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                        Spacer(Modifier.width(38.dp))
                        Text(defs[k] ?: "", color = AuraMuted, fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f))
                        if (k.startsWith("list:")) IconButton(onClick = { onDeleteList(k.removePrefix("list:")) }) { Icon(Icons.Default.Delete, "Sil", tint = AuraMuted) }
                        IconButton(onClick = { onRestore(k) }) { Icon(Icons.Default.AddCircleOutline, "Geri getir", tint = AuraGreen) }
                    }
                }
            }
            Text(
                "Tamam", color = AuraGreen, fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.End,
                modifier = Modifier.fillMaxWidth().clickable { onClose() }.padding(horizontal = 24.dp, vertical = 14.dp)
            )
        }
    }
}

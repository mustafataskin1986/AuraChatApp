package com.aurachat.app.ui

import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Remove
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timelapse
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.foundation.layout.imePadding
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.GroupData
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.launch

/** "AuraChat'e davet edin": indirme bağlantısını paylaşır (yeni grup ve kişiler sayfasında ortak) */
@Composable
fun InviteRow() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Row(
        Modifier.fillMaxWidth().clickable {
            val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(android.content.Intent.EXTRA_TEXT, "AuraChat'e katıl: https://github.com/mustafataskin1986/AuraChatApp/releases/download/apk-latest/AuraChat.apk")
            }
            ctx.startActivity(android.content.Intent.createChooser(send, "AuraChat'e davet et").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        }.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).softCircle(), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Share, null, tint = Color.White)
        }
        Spacer(Modifier.width(14.dp))
        Text("AuraChat'e davet edin", fontSize = 17.sp, color = AuraWhite)
    }
}

/** Çoklu kişi seçici: yeni grup (requireName=true) ve gruba kişi ekleme için. Kişiler sekmesi ve "Grup oluştur" menüsü aynı sayfayı açar */
@Composable
fun ContactPickerScreen(
    me: UserProfile,
    title: String,
    exclude: Set<String>,
    requireName: Boolean,
    onBack: () -> Unit,
    onDone: (List<UserProfile>, String, com.aurachat.app.data.GroupPerms) -> Unit
) {
    val users by remember(me.uid) { Repo.usersFlow(me.uid) }.collectAsState(Repo.cachedUsers())
    val devC by rememberDeviceContacts()
    val chats by remember(me.uid) { Repo.chatsFlow(me.uid) }.collectAsState(Repo.cachedChats(me.uid) ?: emptyList())
    var q by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var askName by remember { mutableStateOf(false) }
    var chosen by remember { mutableStateOf<List<String>>(if (requireName) listOfNotNull(NewGroupSeed.take()) else emptyList()) }
    var working by remember { mutableStateOf(false) }
    var numMode by remember { mutableStateOf(false) }
    var permOpen by remember { mutableStateOf(false) }
    var perms by remember { mutableStateOf(com.aurachat.app.data.GroupPerms()) }
    val focusReq = remember { androidx.compose.ui.focus.FocusRequester() }
    val kbd = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    androidx.compose.runtime.LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(150)
        try { focusReq.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", e) }
        kbd?.show()
    }
    var numFirst by remember { mutableStateOf(true) }
    androidx.compose.runtime.LaunchedEffect(numMode) {
        if (numFirst) { numFirst = false; return@LaunchedEffect }
        kbd?.hide(); kotlinx.coroutines.delay(60)
        try { focusReq.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", e) }
        kbd?.show()
    }

    fun finish(n: String) {
        working = true
        val byId = (users ?: emptyList()).associateBy { it.uid }
        onDone(chosen.mapNotNull { byId[it] }, n.trim(), perms)
    }

    Box(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).height(56.dp)
                    .clip(RoundedCornerShape(28.dp)).background(ChipLook.glass).border(1.dp, ChipLook.border, RoundedCornerShape(28.dp)).padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = ChipLook.fg) }
                Box(Modifier.weight(1f).padding(horizontal = 6.dp), contentAlignment = Alignment.CenterStart) {
                    if (q.isEmpty()) Text("Ad, numara, @kullanıcıadı", color = ChipLook.inputFg.copy(alpha = 0.7f), fontSize = 18.sp, maxLines = 1)
                    AuraTextField(
                        value = q, onValueChange = { q = it }, singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = ChipLook.inputFg, fontSize = 18.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(ChipLook.inputFg),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = if (numMode) androidx.compose.ui.text.input.KeyboardType.Phone else androidx.compose.ui.text.input.KeyboardType.Text
                        ),
                        modifier = Modifier.fillMaxWidth().focusRequester(focusReq)
                    )
                }
                IconButton(onClick = { numMode = !numMode }) {
                    Icon(if (numMode) Icons.Default.Keyboard else Icons.Default.Dialpad, if (numMode) "Klavye" else "Tuş takımı", tint = ChipLook.fg)
                }
            }
            val list = users
            if (list == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = AuraGreen) }
            } else {
                val byId = list.associateBy { it.uid }
                if (chosen.isNotEmpty()) {
                    androidx.compose.foundation.lazy.LazyRow(
                        Modifier.fillMaxWidth().padding(top = 6.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
                    ) {
                        items(chosen, key = { it }) { id ->
                            val u = byId[id] ?: return@items
                            Column(Modifier.width(84.dp).clickable { chosen = chosen - id }, horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.size(70.dp)) {
                                    Avatar(u.name, u.avatar, 64.dp)
                                    Box(
                                        Modifier.align(Alignment.BottomEnd).size(26.dp).clip(CircleShape).background(auraLc(0xFF3A3F44)),
                                        contentAlignment = Alignment.Center
                                    ) { Icon(Icons.Default.Close, null, tint = AuraWhite, modifier = Modifier.size(16.dp)) }
                                }
                                Text(u.name, color = AuraMuted, fontSize = 14.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                    androidx.compose.material3.HorizontalDivider(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), color = auraLc(0xFF2A2F33))
                }
                val devKeys = devC?.map { phoneKey(it.phone) }?.toSet()
                val shown = list.filter {
                    !exclude.contains(it.uid) && devKeys != null && phoneKey(it.phone) in devKeys && (q.isBlank() || it.name.contains(q, ignoreCase = true) || it.phone.contains(q))
                }
                val frequentIds = chats.filter { !it.isGroup }.sortedByDescending { it.lastTime }.map { it.otherUid }
                val frequent = if (q.isBlank()) frequentIds.mapNotNull { id -> shown.firstOrNull { it.uid == id } }.take(5) else emptyList()
                val rest = shown.filter { u -> frequent.none { it.uid == u.uid } }
                @Composable
                fun PersonRow(u: UserProfile) {
                    val on = chosen.contains(u.uid)
                    Row(
                        Modifier.fillMaxWidth().clickable { chosen = if (on) chosen - u.uid else chosen + u.uid }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(u.name, u.avatar, 46.dp)
                        Spacer(Modifier.width(18.dp))
                        Text(u.name, fontSize = 18.sp, color = AuraWhite, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Box(
                            Modifier.size(30.dp).clip(CircleShape)
                                .background(if (on) AuraGreen else Color.Transparent)
                                .border(2.dp, if (on) AuraGreen else AuraMuted, CircleShape),
                            contentAlignment = Alignment.Center
                        ) { if (on) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
                    }
                }
                val askPermG = rememberAskContacts()
                LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 96.dp)) {
                    if (devC == null) item(key = "noperm") {
                        Column(Modifier.fillParentMaxHeight(0.6f).fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
                            Text("Kişileri görmek için rehber erişimine izin ver", color = AuraMuted, fontSize = 15.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                            Text("İzin ver", color = AuraGreen, fontSize = 16.sp, modifier = Modifier.padding(top = 12.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(50)).clickable { askPermG() }.padding(horizontal = 20.dp, vertical = 8.dp))
                        }
                    }
                    if (frequent.isNotEmpty()) {
                        item(key = "h-frequent") { Text("Sık görüşülenler", color = AuraMuted, fontSize = 16.sp, modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 6.dp)) }
                        items(frequent, key = { "f-" + it.uid }) { PersonRow(it) }
                    }
                    if (rest.isNotEmpty()) {
                        item(key = "h-rest") { Text("AuraChat'taki kişiler", color = AuraMuted, fontSize = 16.sp, modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 6.dp)) }
                        items(rest, key = { "r-" + it.uid }) { PersonRow(it) }
                    }
                    item(key = "invite") { InviteRow() }
                }
            }
        }
        if (chosen.isNotEmpty() && !working) {
            Box(
                Modifier.align(Alignment.BottomEnd).padding(20.dp).size(64.dp).clip(RoundedCornerShape(18.dp)).background(AuraGreen)
                    .clickable { if (requireName) askName = true else finish("") },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "Tamam", tint = Color.White, modifier = Modifier.size(28.dp)) }
        }
        if (askName) {
            androidx.activity.compose.BackHandler(!permOpen) { askName = false }
            val nameReq = remember { androidx.compose.ui.focus.FocusRequester() }
            androidx.compose.runtime.LaunchedEffect(Unit) {
                kotlinx.coroutines.delay(150)
                try { nameReq.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", e) }
                kbd?.show()
            }
            val byId2 = (users ?: emptyList()).associateBy { it.uid }
            val members2 = chosen.mapNotNull { byId2[it] }
            fun create() {
                val n = name.trim().ifBlank { members2.joinToString(", ") { it.name.substringBefore(' ') }.take(40) }
                askName = false; finish(n)
            }
            Box(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding().imePadding().pointerInput(Unit) { detectTapGestures { } }) {
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().height(60.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { askName = false }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                        Text("Yeni grup", color = AuraWhite, fontSize = 22.sp, modifier = Modifier.padding(start = 6.dp))
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(auraLc(0xFF1A2025)))
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(60.dp).clip(CircleShape).background(auraLc(0xFF2A2F33)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.AddAPhoto, null, tint = AuraMuted, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Box(
                            Modifier.weight(1f).height(60.dp).clip(RoundedCornerShape(10.dp)).border(2.dp, AuraGreen, RoundedCornerShape(10.dp)).padding(horizontal = 16.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (name.isEmpty()) Text("Grup adı (isteğe bağlı)", color = AuraMuted, fontSize = 17.sp, maxLines = 1)
                            AuraTextField(
                                value = name, onValueChange = { name = it }, singleLine = true,
                                textStyle = androidx.compose.ui.text.TextStyle(color = AuraWhite, fontSize = 17.sp),
                                cursorBrush = androidx.compose.ui.graphics.SolidColor(AuraGreen),
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                    capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Sentences,
                                    imeAction = androidx.compose.ui.text.input.ImeAction.Done
                                ),
                                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onDone = { create() }),
                                modifier = Modifier.fillMaxWidth().focusRequester(nameReq)
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Icon(Icons.Default.EmojiEmotions, null, tint = AuraMuted, modifier = Modifier.size(30.dp))
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Süreli mesajlar", color = AuraWhite, fontSize = 18.sp)
                            Text("Kapalı", color = AuraMuted, fontSize = 15.5.sp)
                        }
                        Icon(Icons.Default.Timelapse, null, tint = AuraMuted, modifier = Modifier.size(28.dp))
                    }
                    Row(Modifier.fillMaxWidth().clickable { permOpen = true }.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Grup izinleri", color = AuraWhite, fontSize = 18.sp, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.Settings, null, tint = AuraMuted, modifier = Modifier.size(28.dp))
                    }
                    Text("Üyeler: ${members2.size}", color = AuraMuted, fontSize = 16.sp, modifier = Modifier.padding(start = 16.dp, top = 30.dp, bottom = 12.dp))
                    androidx.compose.foundation.lazy.LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp)) {
                        items(members2, key = { it.uid }) { u ->
                            Column(Modifier.width(84.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Avatar(u.name, u.avatar, 56.dp)
                                Text(u.name, color = AuraMuted, fontSize = 15.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                }
                if (!working) Box(
                    Modifier.align(Alignment.BottomEnd).padding(20.dp).size(64.dp).clip(RoundedCornerShape(18.dp)).background(AuraGreen).clickable { create() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Check, "Oluştur", tint = Color.Black, modifier = Modifier.size(28.dp)) }
                if (permOpen) GroupPermissionsPage(perms, { perms = it }) { permOpen = false }
            }
        }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun GroupPermissionsPage(perms: com.aurachat.app.data.GroupPerms, onChange: (com.aurachat.app.data.GroupPerms) -> Unit, readOnly: Boolean = false, onBack: () -> Unit) {
    androidx.activity.compose.BackHandler { onBack() }
    val edit = perms.edit; val send = perms.send; val add = perms.add
    var link by remember { mutableStateOf(false) }
    var approve by remember { mutableStateOf(false) }
    val green = accOr(Color(0xFF22C55E))
    @Composable
    fun PRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, desc: String?, on: Boolean, onChange: (Boolean) -> Unit, more: Boolean = false) {
        Row(Modifier.fillMaxWidth().clickable { onChange(!on) }.padding(horizontal = 22.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = AuraMuted, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(26.dp))
            Column(Modifier.weight(1f).padding(end = 16.dp)) {
                Text(title, color = AuraWhite, fontSize = 18.sp)
                if (desc != null) {
                    if (more) Text(androidx.compose.ui.text.buildAnnotatedString {
                        append("$desc ")
                        pushStyle(androidx.compose.ui.text.SpanStyle(color = green)); append("Daha fazla bilgi"); pop()
                    }, color = AuraMuted, fontSize = 16.sp)
                    else Text(desc, color = AuraMuted, fontSize = 16.sp)
                }
            }
            androidx.compose.material3.Switch(
                checked = on, onCheckedChange = onChange,
                thumbContent = { Icon(if (on) Icons.Default.Check else Icons.Default.Remove, null, modifier = Modifier.size(16.dp)) },
                colors = androidx.compose.material3.SwitchDefaults.colors(
                    checkedTrackColor = green, checkedThumbColor = Color(0xFF0B141A), checkedIconColor = green, checkedBorderColor = green,
                    uncheckedTrackColor = auraLc(0xFF1F2327), uncheckedThumbColor = auraLc(0xFF8696A0), uncheckedIconColor = auraLc(0xFF1F2327), uncheckedBorderColor = auraLc(0xFF8696A0)
                )
            )
        }
    }
    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding().verticalScroll(androidx.compose.foundation.rememberScrollState())) {
        Row(Modifier.fillMaxWidth().height(60.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text("Grup izinleri", color = AuraWhite, fontSize = 22.sp, modifier = Modifier.padding(start = 6.dp))
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(auraLc(0xFF1A2025)))
        Text("Üyeler:", color = AuraMuted, fontSize = 16.sp, modifier = Modifier.padding(start = 22.dp, top = 22.dp, bottom = 8.dp))
        PRow(Icons.Default.Edit, "Grup ayarlarını düzenleyebilir", "Adı, simgeyi, açıklamayı, süreli mesajların süresini, mesajları sabitlemeyi, tutmayı ve tutma işlemini geri almayı kapsar.", edit, { if (!readOnly) onChange(perms.copy(edit = it)) })
        PRow(Icons.Default.Message, "Yeni mesajlar gönder", null, send, { if (!readOnly) onChange(perms.copy(send = it)) })
        PRow(Icons.Default.PersonAdd, "Başka üyeler ekleyebilir", null, add, { if (!readOnly) onChange(perms.copy(add = it)) })
        PRow(Icons.Default.Link, "Bağlantı veya QR ile davet et", null, link, { link = it })
        Text("Yöneticiler:", color = AuraMuted, fontSize = 16.sp, modifier = Modifier.padding(start = 22.dp, top = 30.dp, bottom = 8.dp))
        PRow(Icons.Default.ManageAccounts, "Yeni üyeleri onaylayabilir", "Bu ayar etkinleştirildiğinde yöneticilerin gruba katılmak isteyen herkesi onaylaması gerekir.", approve, { approve = it }, more = true)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupInfoScreen(
    me: UserProfile,
    target: com.aurachat.app.data.ChatTarget,
    onBack: () -> Unit,
    onLeft: () -> Unit,
    onMessage: () -> Unit,
    onSearch: () -> Unit,
    onMedia: () -> Unit,
    onStarred: () -> Unit,
    onCall: (Boolean) -> Unit,
    onTheme: () -> Unit,
    onForward: (List<com.aurachat.app.data.Message>) -> Unit = {},
    onShowInChat: (com.aurachat.app.data.Message) -> Unit = {},
    onEdited: (String) -> Unit = {}
) {
    val groupId = target.chatId
    val scope = rememberCoroutineScope()
    val group by remember(groupId) { Repo.groupFlow(groupId) }.collectAsState(null as GroupData?)
    var showAdd by remember { mutableStateOf(false) }
    var cropUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var photoPickerOpen by remember { mutableStateOf(false) }
    if (photoPickerOpen) PhotoPickerScreen(onClose = { photoPickerOpen = false }, onPick = { photoPickerOpen = false; cropUri = it })
    var showRename by remember { mutableStateOf(false) }
    var showPerms by remember { mutableStateOf(false) }
    var showChanges by remember { mutableStateOf(false) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        when (GroupAction.take()) {
            "rename" -> showRename = true
            "add" -> showAdd = true
            "perms" -> showPerms = true
            "photo" -> photoPickerOpen = true
        }
    }
    var showLeave by remember { mutableStateOf(false) }
    var memberAction by remember { mutableStateOf<UserProfile?>(null) }

    val g = group
    if (g == null) {
        Box(Modifier.fillMaxSize().background(AuraBg), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = AuraGreen)
        }
        return
    }

    val cu = cropUri
    val ctxG = androidx.compose.ui.platform.LocalContext.current
    if (cu != null) {
        AvatarCropper(cu, 320, onDone = { d ->
            cropUri = null
            Repo.setGroupPhoto(groupId, d)
            android.widget.Toast.makeText(ctxG, "Grup fotoğrafı güncellendi", android.widget.Toast.LENGTH_SHORT).show()
        }, onCancel = { cropUri = null })
    }
    val iAmAdmin = g.admins.contains(me.uid) || g.createdBy == me.uid
    val members by remember(g.members, me) {
        kotlinx.coroutines.flow.combine(
            g.members.map { uid ->
                if (uid == me.uid) kotlinx.coroutines.flow.flowOf(me)
                else Repo.profileFlow(uid).let { f -> kotlinx.coroutines.flow.flow { f.collect { emit(it ?: UserProfile(uid, "", "", "", "")) } } }
            }
        ) { arr -> arr.map { p -> if (p.name.isBlank()) p.copy(name = "Kullanıcı") else p } }
    }.collectAsState(emptyList<UserProfile>())

    if (showChanges) {
        GroupChangesPage(groupId) { showChanges = false }
        return
    }
    if (showPerms) {
        GroupPermissionsPage(
            com.aurachat.app.data.GroupPerms(g.permEdit, g.permSend, g.permAdd),
            { np -> scope.launch { try { Repo.setGroupPerms(groupId, np) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", e) } } },
            readOnly = !iAmAdmin
        ) { showPerms = false }
        return
    }
    if (showAdd) {
        ContactPickerScreen(
            me = me, title = "Kişi ekle", exclude = g.members.toSet(), requireName = false,
            onBack = { showAdd = false }
        ) { picked, _, _ ->
            showAdd = false
            scope.launch { try { Repo.addMembers(me, g, picked.map { it.uid }) } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", ignored) } }
        }
        return
    }

    ContactInfoScreen(
        me = me, target = target, onBack = onBack, onMessage = onMessage, onSearch = onSearch, onMedia = onMedia,
        onStarred = onStarred, onCall = onCall, onTheme = onTheme, group = g,
        onForward = onForward, onShowInChat = onShowInChat, onEdited = onEdited,
        onAvatarTap = if (iAmAdmin || g.permEdit) ({ photoPickerOpen = true }) else null,
        onNameTap = if (iAmAdmin || g.permEdit) ({ showRename = true }) else null,
        groupBody = {
            Column {
                val canEdit = iAmAdmin || g.permEdit
                val canAdd = iAmAdmin || g.permAdd
                if (canEdit) {
                    GRow(Icons.Default.CameraAlt, AuraGreen, "Grup fotoğrafını değiştir") {
                        photoPickerOpen = true
                    }
                    GRow(Icons.Default.Edit, AuraGreen, "Grup adını değiştir") { showRename = true }
                }
                if (canAdd) GRow(Icons.Default.PersonAdd, AuraGreen, "Üye ekle") { showAdd = true }
                GRow(Icons.Default.Settings, AuraGreen, "Grup izinleri") { showPerms = true }
                Box(Modifier.fillMaxWidth().height(1.dp).background(auraC(0xFF111B21)))
                var memberSearch by remember { mutableStateOf(false) }
                var memberQ by remember { mutableStateOf("") }
                val mFocus = remember { androidx.compose.ui.focus.FocusRequester() }
                if (!memberSearch) {
                    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 8.dp, bottom = 0.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${g.members.size} üye", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        IconButton(onClick = { memberSearch = true }) {
                            Icon(Icons.Default.Search, "Üyelerde ara", tint = AuraMuted)
                        }
                    }
                } else {
                    androidx.compose.runtime.LaunchedEffect(Unit) { try { mFocus.requestFocus() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", e) } }
                    Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 6.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { memberSearch = false; memberQ = "" }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kapat", tint = AuraMuted)
                        }
                        Box(Modifier.weight(1f)) {
                            if (memberQ.isEmpty()) Text("Üye ara", color = AuraMuted, fontSize = 16.sp)
                            AuraTextField(
                                value = memberQ, onValueChange = { memberQ = it }, singleLine = true,
                                textStyle = androidx.compose.ui.text.TextStyle(color = AuraWhite, fontSize = 16.sp),
                                cursorBrush = androidx.compose.ui.graphics.SolidColor(AuraGreen),
                                modifier = Modifier.fillMaxWidth().focusRequester(mFocus)
                            )
                        }
                        if (memberQ.isNotEmpty()) IconButton(onClick = { memberQ = "" }) {
                            Icon(Icons.Default.Close, "Temizle", tint = AuraMuted)
                        }
                    }
                }
                members.filter { memberQ.isBlank() || it.name.contains(memberQ.trim(), ignoreCase = true) }.forEach { u ->
                    val isMe = u.uid == me.uid
                    val tags = ArrayList<String>()
                    if (isMe) tags.add("Sen")
                    if (g.createdBy == u.uid) tags.add("Kurucu") else if (g.admins.contains(u.uid)) tags.add("Yönetici")
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable(enabled = iAmAdmin && !isMe && g.createdBy != u.uid) { memberAction = u }
                            .padding(horizontal = 20.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(u.name, u.avatar, 46.dp)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(u.name, fontSize = 17.sp, color = AuraWhite, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            if (u.about.isNotBlank()) Text(u.about, fontSize = 13.sp, color = AuraMuted, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        }
                        if (tags.isNotEmpty()) {
                            Text(
                                tags.joinToString(" · "), color = AuraGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }
                }
                Text(
                    "Üye değişikliklerini görüntüle", color = AuraGreen, fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth().clickable { showChanges = true }.padding(horizontal = 20.dp, vertical = 16.dp)
                )
                Box(Modifier.fillMaxWidth().height(1.dp).background(auraC(0xFF111B21)))
                GRow(Icons.AutoMirrored.Filled.ExitToApp, auraLc(0xFFFB7185), "Gruptan ayrıl", auraLc(0xFFFB7185)) { showLeave = true }
            }
        }
    )

    if (showLeave) {
        AuraAlertDialog(
            onDismissRequest = { showLeave = false },
            containerColor = AuraSurface,
            title = { Text("Gruptan ayrılmak istiyor musun?", color = AuraWhite) },
            confirmButton = {
                TextButton(onClick = {
                    showLeave = false
                    scope.launch {
                        try { Repo.leaveGroup(me, g) } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", ignored) }
                        onLeft()
                    }
                }) { Text("Ayrıl", color = AuraDialogBtn) }
            },
            dismissButton = { TextButton(onClick = { showLeave = false }) { Text("Vazgeç", color = AuraDialogBtn) } }
        )
    }

    if (showRename) {
        var newName by remember { mutableStateOf(g.name) }
        AuraAlertDialog(
            onDismissRequest = { showRename = false },
            containerColor = AuraSurface,
            title = { Text("Grup adı", color = AuraWhite) },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, singleLine = true, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Sentences)) },
            confirmButton = {
                TextButton(onClick = {
                    val n = newName.trim()
                    showRename = false
                    if (n.isNotEmpty() && n != g.name) scope.launch { try { Repo.renameGroup(g, n) } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", ignored) } }
                }) { Text("Kaydet", color = AuraGreen) }
            },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text("Vazgeç", color = AuraMuted) } }
        )
    }

    val ma = memberAction
    if (ma != null) {
        val isAdm = g.admins.contains(ma.uid)
        AuraAlertDialog(
            onDismissRequest = { memberAction = null },
            containerColor = AuraSurface,
            title = { Text(ma.name, color = AuraWhite) },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton(onClick = {
                        memberAction = null
                        scope.launch { try { Repo.setAdmin(g, ma.uid, !isAdm) } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", ignored) } }
                    }) { Text(if (isAdm) "Yöneticiliği kaldır" else "Yönetici yap", color = AuraGreen) }
                    TextButton(onClick = {
                        memberAction = null
                        scope.launch { try { Repo.removeMember(g, ma.uid, me) } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", ignored) } }
                    }) { Text("Gruptan çıkar", color = AuraDialogBtn) }
                    TextButton(onClick = { memberAction = null }) { Text("Vazgeç", color = AuraMuted) }
                }
            }
        )
    }
}

@Composable
private fun GRow(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, label: String, labelColor: Color = AuraWhite, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        Text(label, color = labelColor, fontSize = 16.sp, modifier = Modifier.padding(start = 20.dp))
    }
}


/** Üye değişiklikleri: son 60 günde gruptan ayrılan / çıkarılan / eklenen kişiler */
@Composable
private fun GroupChangesPage(groupId: String, onBack: () -> Unit) {
    androidx.activity.compose.BackHandler { onBack() }
    var events by remember { mutableStateOf<List<com.aurachat.app.data.Message>?>(null) }
    androidx.compose.runtime.LaunchedEffect(groupId) {
        events = try { Repo.groupMemberEvents(groupId) } catch (e: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", e); emptyList() }
    }
    val fmt = remember { java.text.SimpleDateFormat("dd.MM.yyyy, HH:mm", java.util.Locale("tr")) }
    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
            Text("Üye değişiklikleri", color = AuraWhite, fontSize = 20.sp, modifier = Modifier.padding(start = 8.dp))
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(auraC(0xFF111B21)))
        Text(
            "Kimlerin ayrıldığı, çıkarıldığı ya da eklendiği gibi son 60 güne ait güncellemeleri görün.",
            color = AuraMuted, fontSize = 15.sp, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 12.dp)
        )
        val list = events
        if (list == null) {
            Box(Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.TopCenter) { CircularProgressIndicator(color = AuraGreen) }
        } else if (list.isEmpty()) {
            Text("Son 60 günde üye değişikliği yok.", color = AuraMuted, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp))
        } else {
            androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize()) {
                items(list.size) { i ->
                    val ev = list[i]
                    // ayrılan: gönderen; eklenen / çıkarılan: etiketlenen kişi
                    val uid = if (ev.text.contains("gruptan ayrıldı")) ev.senderUid else (ev.mentions.firstOrNull() ?: ev.senderUid)
                    val p by liveProfile(uid)
                    // olay metnindeki adlar kayıt anındaki adlardır: sonradan değişenler güncel adla gösterilir
                    val sp by liveProfile(ev.senderUid)
                    val mp0 by liveProfile(ev.mentions.getOrNull(0) ?: "")
                    val mp1 by liveProfile(ev.mentions.getOrNull(1) ?: "")
                    val mp2 by liveProfile(ev.mentions.getOrNull(2) ?: "")
                    var shownText = sp?.name?.takeIf { it.isNotBlank() && ev.senderName.isNotBlank() && it != ev.senderName }?.let { ev.text.replace(ev.senderName, it) } ?: ev.text
                    listOf(mp0, mp1, mp2).forEachIndexed { k, pr ->
                        val old = ev.mentionNames.getOrNull(k) ?: ""
                        val nn = pr?.name ?: ""
                        if (old.isNotBlank() && nn.isNotBlank() && nn != old) shownText = shownText.replace(old, nn)
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(p?.name ?: ev.senderName, p?.avatar ?: "", 56.dp)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(shownText, color = AuraWhite, fontSize = 17.sp)
                            Text(fmt.format(java.util.Date(ev.time)), color = AuraMuted, fontSize = 15.sp)
                        }
                    }
                }
            }
        }
    }
}

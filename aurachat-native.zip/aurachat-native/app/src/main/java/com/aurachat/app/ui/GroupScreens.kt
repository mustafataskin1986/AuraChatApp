package com.aurachat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.GroupData
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.launch

/** Çoklu kişi seçici: yeni grup (requireName=true) ve gruba kişi ekleme için */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactPickerScreen(
    me: UserProfile,
    title: String,
    exclude: Set<String>,
    requireName: Boolean,
    onBack: () -> Unit,
    onDone: (List<UserProfile>, String) -> Unit
) {
    val users by produceState<List<UserProfile>?>(null) {
        value = try { Repo.loadUsers(me.uid) } catch (e: Exception) { emptyList() }
    }
    var q by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var chosen by remember { mutableStateOf<Set<String>>(emptySet()) }
    var working by remember { mutableStateOf(false) }

    val canConfirm = chosen.isNotEmpty() && (!requireName || name.isNotBlank()) && !working

    Scaffold(
        containerColor = AuraBg,
        topBar = {
            TopAppBar(
                title = { Text(title) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AuraBg, titleContentColor = Color.White, navigationIconContentColor = Color.White),
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") } }
            )
        },
        floatingActionButton = {
            if (canConfirm) {
                FloatingActionButton(
                    onClick = {
                        working = true
                        val list = (users ?: emptyList()).filter { chosen.contains(it.uid) }
                        onDone(list, name.trim())
                    },
                    containerColor = AuraBtn, contentColor = Color.White
                ) { Icon(Icons.Default.Check, "Tamam") }
            }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            if (requireName) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Grup adı") },
                    singleLine = true, modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 12.dp)
                )
            }
            OutlinedTextField(
                value = q, onValueChange = { q = it }, placeholder = { Text("Kişi ara") },
                singleLine = true, modifier = Modifier.fillMaxWidth().padding(12.dp)
            )
            if (chosen.isNotEmpty()) {
                Text("${chosen.size} kişi seçildi", color = AuraGreen, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
            }
            val list = users
            if (list == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = AuraGreen) }
            } else {
                val shown = list.filter {
                    !exclude.contains(it.uid) && (q.isBlank() || it.name.contains(q, ignoreCase = true) || it.phone.contains(q))
                }
                LazyColumn {
                    items(shown, key = { it.uid }) { u ->
                        val on = chosen.contains(u.uid)
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (on) Color(0x3322C55E) else Color.Transparent)
                                .clickable { chosen = if (on) chosen - u.uid else chosen + u.uid }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(u.name, u.avatar, 44.dp)
                            Spacer(Modifier.width(14.dp))
                            Text(u.name, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            if (on) Icon(Icons.Default.Check, null, tint = AuraGreen)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupInfoScreen(
    me: UserProfile,
    groupId: String,
    onBack: () -> Unit,
    onLeft: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val group by remember(groupId) { Repo.groupFlow(groupId) }.collectAsState(null as GroupData?)
    var showAdd by remember { mutableStateOf(false) }
    var cropUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val photoPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()
    ) { u -> if (u != null) cropUri = u }
    var showRename by remember { mutableStateOf(false) }
    var showLeave by remember { mutableStateOf(false) }
    var memberAction by remember { mutableStateOf<UserProfile?>(null) }

    val g = group
    if (g == null) {
        Box(Modifier.fillMaxSize().background(AuraBg), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = AuraGreen)
        }
        return
    }

    val cu = cropUri
    val ctxG = androidx.compose.ui.platform.LocalContext.current
    if (cu != null) {
        AvatarCropper(cu, 320, onDone = { d ->
            cropUri = null
            Repo.setGroupPhoto(groupId, d)
            android.widget.Toast.makeText(ctxG, "Grup fotoğrafı güncellendi", android.widget.Toast.LENGTH_SHORT).show()
        }, onCancel = { cropUri = null })
    }
    val iAmAdmin = g.admins.contains(me.uid) || g.createdBy == me.uid
    val members by produceState<List<UserProfile>>(emptyList(), g.members) {
        value = g.members.map { uid -> if (uid == me.uid) me else Repo.profileOf(uid).let { p -> if (p.name.isBlank()) p.copy(name = "Kullanıcı") else p } }
    }

    if (showAdd) {
        ContactPickerScreen(
            me = me, title = "Kişi ekle", exclude = g.members.toSet(), requireName = false,
            onBack = { showAdd = false }
        ) { picked, _ ->
            showAdd = false
            scope.launch { try { Repo.addMembers(me, g, picked.map { it.uid }) } catch (ignored: Throwable) {} }
        }
        return
    }

    val ctx = androidx.compose.ui.platform.LocalContext.current
    val recent by remember(groupId) { Repo.messagesFlow(groupId, 150) }.collectAsState(emptyList())
    val mediaImages = remember(recent) {
        recent.filter { it.type == "image" && !it.deleted }.flatMap { messageImages(it) }
    }
    var viewer by remember { mutableStateOf<Pair<List<String>, Int>?>(null) }

    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
            Text("Grup bilgisi", color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(start = 8.dp))
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF1F2A33)))
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Column(Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box {
                        Avatar(g.name, g.photo, 112.dp)
                        if (iAmAdmin) {
                            Box(
                                Modifier.align(Alignment.BottomEnd).size(36.dp).clip(CircleShape).background(AuraBtn)
                                    .border(2.dp, AuraBg, CircleShape)
                                    .clickable {
                                        photoPicker.launch(androidx.activity.result.PickVisualMediaRequest(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly))
                                    },
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Default.CameraAlt, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
                        }
                    }
                    Row(Modifier.padding(top = 16.dp, start = 24.dp, end = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(g.name, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = Color.White, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        if (iAmAdmin) {
                            Icon(
                                Icons.Default.Edit, "Adı değiştir", tint = AuraGreen,
                                modifier = Modifier.padding(start = 10.dp).size(20.dp).clickable { showRename = true }
                            )
                        }
                    }
                    Text("${g.members.size} üye", color = AuraMuted, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF111B21)))
            }
            item {
                Column(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Medya, bağlantı ve belgeler", color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                        Text("${mediaImages.size}", color = AuraMuted, fontSize = 15.sp)
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = AuraMuted)
                    }
                    if (mediaImages.isNotEmpty()) {
                        androidx.compose.foundation.lazy.LazyRow(
                            Modifier.fillMaxWidth().padding(top = 12.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
                        ) {
                            items(mediaImages.take(20).size) { i ->
                                DataUrlImage(
                                    mediaImages[i], 360,
                                    Modifier.size(96.dp).clip(RoundedCornerShape(12.dp)).clickable { viewer = Pair(mediaImages, i) },
                                    androidx.compose.ui.layout.ContentScale.Crop
                                )
                            }
                        }
                    }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF111B21)))
            }
            if (iAmAdmin) {
                item {
                    Row(
                        Modifier.fillMaxWidth().clickable { showAdd = true }.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(50.dp).clip(CircleShape).background(AuraBtn), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.PersonAdd, null, tint = Color.White)
                        }
                        Spacer(Modifier.width(16.dp))
                        Text("Üye ekle", fontSize = 18.sp, color = Color.White)
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF111B21)))
                }
            }
            items(members, key = { it.uid }) { u ->
                val isMe = u.uid == me.uid
                val tags = ArrayList<String>()
                if (isMe) tags.add("Sen")
                if (g.createdBy == u.uid) tags.add("Kurucu") else if (g.admins.contains(u.uid)) tags.add("Yönetici")
                Row(
                    Modifier.fillMaxWidth()
                        .clickable(enabled = iAmAdmin && !isMe && g.createdBy != u.uid) { memberAction = u }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(u.name, u.avatar, 50.dp)
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(u.name, fontSize = 18.sp, color = Color.White, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        if (u.about.isNotBlank()) Text(u.about, fontSize = 14.sp, color = AuraMuted, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    }
                    if (tags.isNotEmpty()) {
                        Text(
                            tags.joinToString(" · "), color = AuraGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0x3310B981)).padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF111B21)))
            }
            item {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(14.dp))
                        .background(Color(0x1AE11D48)).border(1.dp, Color(0x33E11D48), RoundedCornerShape(14.dp))
                        .clickable { showLeave = true }.padding(vertical = 16.dp),
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.AutoMirrored.Filled.ExitToApp, null, tint = Color(0xFFFB7185))
                    Spacer(Modifier.width(10.dp))
                    Text("Gruptan ayrıl", color = Color(0xFFFB7185), fontSize = 19.sp)
                }
            }
        }
    }
    val vw = viewer
    if (vw != null) ImageViewer(vw.first, vw.second) { viewer = null }

    if (showLeave) {
        AlertDialog(
            onDismissRequest = { showLeave = false },
            containerColor = AuraSurface,
            title = { Text("Gruptan ayrılmak istiyor musun?", color = Color.White) },
            confirmButton = {
                TextButton(onClick = {
                    showLeave = false
                    scope.launch {
                        try { Repo.leaveGroup(me, g) } catch (ignored: Throwable) {}
                        onLeft()
                    }
                }) { Text("Ayrıl", color = Color(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { showLeave = false }) { Text("Vazgeç", color = AuraGreen) } }
        )
    }

    if (showRename) {
        var newName by remember { mutableStateOf(g.name) }
        AlertDialog(
            onDismissRequest = { showRename = false },
            containerColor = AuraSurface,
            title = { Text("Grup adı", color = Color.White) },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val n = newName.trim()
                    showRename = false
                    if (n.isNotEmpty() && n != g.name) scope.launch { try { Repo.renameGroup(g, n) } catch (ignored: Throwable) {} }
                }) { Text("Kaydet", color = AuraGreen) }
            },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text("Vazgeç", color = AuraMuted) } }
        )
    }

    val ma = memberAction
    if (ma != null) {
        val isAdm = g.admins.contains(ma.uid)
        AlertDialog(
            onDismissRequest = { memberAction = null },
            containerColor = AuraSurface,
            title = { Text(ma.name, color = Color.White) },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton(onClick = {
                        memberAction = null
                        scope.launch { try { Repo.setAdmin(g, ma.uid, !isAdm) } catch (ignored: Throwable) {} }
                    }) { Text(if (isAdm) "Yöneticiliği kaldır" else "Yönetici yap", color = AuraGreen) }
                    TextButton(onClick = {
                        memberAction = null
                        scope.launch { try { Repo.removeMember(g, ma.uid) } catch (ignored: Throwable) {} }
                    }) { Text("Gruptan çıkar", color = Color(0xFFEF4444)) }
                    TextButton(onClick = { memberAction = null }) { Text("Vazgeç", color = AuraMuted) }
                }
            }
        )
    }
}

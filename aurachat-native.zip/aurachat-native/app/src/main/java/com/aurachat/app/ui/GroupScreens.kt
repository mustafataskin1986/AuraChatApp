package com.aurachat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.GroupData
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.launch

/** Çoklu kişi seçici: yeni grup (requireName=true) ve gruba kişi ekleme için */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactPickerScreen(
    me: UserProfile,
    title: String,
    exclude: Set<String>,
    requireName: Boolean,
    onBack: () -> Unit,
    onDone: (List<UserProfile>, String) -> Unit
) {
    val users by produceState<List<UserProfile>?>(null) {
        value = try { Repo.loadUsers(me.uid) } catch (e: Exception) { emptyList() }
    }
    var q by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var chosen by remember { mutableStateOf<Set<String>>(emptySet()) }
    var working by remember { mutableStateOf(false) }

    val canConfirm = chosen.isNotEmpty() && (!requireName || name.isNotBlank()) && !working

    Scaffold(
        containerColor = AuraBg,
        topBar = {
            TopAppBar(
                title = { Text(title) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AuraSurface),
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") } }
            )
        },
        floatingActionButton = {
            if (canConfirm) {
                FloatingActionButton(
                    onClick = {
                        working = true
                        val list = (users ?: emptyList()).filter { chosen.contains(it.uid) }
                        onDone(list, name.trim())
                    },
                    containerColor = AuraGreen, contentColor = Color.Black
                ) { Icon(Icons.Default.Check, "Tamam") }
            }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            if (requireName) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Grup adı") },
                    singleLine = true, modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 12.dp)
                )
            }
            OutlinedTextField(
                value = q, onValueChange = { q = it }, placeholder = { Text("Kişi ara") },
                singleLine = true, modifier = Modifier.fillMaxWidth().padding(12.dp)
            )
            if (chosen.isNotEmpty()) {
                Text("${chosen.size} kişi seçildi", color = AuraGreen, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
            }
            val list = users
            if (list == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = AuraGreen) }
            } else {
                val shown = list.filter {
                    !exclude.contains(it.uid) && (q.isBlank() || it.name.contains(q, ignoreCase = true) || it.phone.contains(q))
                }
                LazyColumn {
                    items(shown, key = { it.uid }) { u ->
                        val on = chosen.contains(u.uid)
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (on) Color(0x3322C55E) else Color.Transparent)
                                .clickable { chosen = if (on) chosen - u.uid else chosen + u.uid }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(u.name, u.avatar, 44.dp)
                            Spacer(Modifier.width(14.dp))
                            Text(u.name, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            if (on) Icon(Icons.Default.Check, null, tint = AuraGreen)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupInfoScreen(
    me: UserProfile,
    groupId: String,
    onBack: () -> Unit,
    onLeft: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val group by remember(groupId) { Repo.groupFlow(groupId) }.collectAsState(null as GroupData?)
    var showAdd by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var showLeave by remember { mutableStateOf(false) }
    var memberAction by remember { mutableStateOf<UserProfile?>(null) }

    val g = group
    if (g == null) {
        Box(Modifier.fillMaxSize().background(AuraBg), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = AuraGreen)
        }
        return
    }

    val iAmAdmin = g.admins.contains(me.uid) || g.createdBy == me.uid
    val members by produceState<List<UserProfile>>(emptyList(), g.members) {
        value = g.members.map { uid -> if (uid == me.uid) me else Repo.profileOf(uid).let { p -> if (p.name.isBlank()) p.copy(name = "Kullanıcı") else p } }
    }

    if (showAdd) {
        ContactPickerScreen(
            me = me, title = "Kişi ekle", exclude = g.members.toSet(), requireName = false,
            onBack = { showAdd = false }
        ) { picked, _ ->
            showAdd = false
            scope.launch { try { Repo.addMembers(me, g, picked.map { it.uid }) } catch (ignored: Throwable) {} }
        }
        return
    }

    Scaffold(
        containerColor = AuraBg,
        topBar = {
            TopAppBar(
                title = { Text("Grup bilgisi") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AuraSurface),
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") } }
            )
        }
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad)) {
            item {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(g.name, g.photo, 96.dp)
                    Spacer(Modifier.height(12.dp))
                    Text(g.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("${g.members.size} üye", color = AuraMuted, fontSize = 14.sp)
                    if (iAmAdmin) {
                        TextButton(onClick = { showRename = true }) { Text("Adı değiştir", color = AuraGreen) }
                    }
                }
            }
            if (iAmAdmin) {
                item {
                    Row(
                        Modifier.fillMaxWidth().clickable { showAdd = true }.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(44.dp).clip(CircleShape).background(AuraGreen), contentAlignment = Alignment.Center) {
                            Text("+", color = Color.Black, fontSize = 24.sp)
                        }
                        Spacer(Modifier.width(14.dp))
                        Text("Kişi ekle", fontSize = 16.sp, color = Color.White)
                    }
                }
            }
            items(members, key = { it.uid }) { u ->
                val isAdm = g.admins.contains(u.uid) || g.createdBy == u.uid
                Row(
                    Modifier.fillMaxWidth()
                        .clickable(enabled = iAmAdmin && u.uid != me.uid) { memberAction = u }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(u.name, u.avatar, 44.dp)
                    Spacer(Modifier.width(14.dp))
                    Text(if (u.uid == me.uid) "Sen" else u.name, fontSize = 16.sp, color = Color.White, modifier = Modifier.weight(1f))
                    if (isAdm) Text("Yönetici", color = AuraGreen, fontSize = 12.sp)
                }
            }
            item {
                TextButton(onClick = { showLeave = true }, modifier = Modifier.padding(8.dp)) {
                    Text("Gruptan ayrıl", color = Color(0xFFEF4444), fontSize = 16.sp)
                }
            }
        }
    }

    if (showLeave) {
        AlertDialog(
            onDismissRequest = { showLeave = false },
            containerColor = AuraSurface,
            title = { Text("Gruptan ayrılmak istiyor musun?", color = Color.White) },
            confirmButton = {
                TextButton(onClick = {
                    showLeave = false
                    scope.launch {
                        try { Repo.leaveGroup(me, g) } catch (ignored: Throwable) {}
                        onLeft()
                    }
                }) { Text("Ayrıl", color = Color(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { showLeave = false }) { Text("Vazgeç", color = AuraGreen) } }
        )
    }

    if (showRename) {
        var newName by remember { mutableStateOf(g.name) }
        AlertDialog(
            onDismissRequest = { showRename = false },
            containerColor = AuraSurface,
            title = { Text("Grup adı", color = Color.White) },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val n = newName.trim()
                    showRename = false
                    if (n.isNotEmpty() && n != g.name) scope.launch { try { Repo.renameGroup(g, n) } catch (ignored: Throwable) {} }
                }) { Text("Kaydet", color = AuraGreen) }
            },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text("Vazgeç", color = AuraMuted) } }
        )
    }

    val ma = memberAction
    if (ma != null) {
        val isAdm = g.admins.contains(ma.uid)
        AlertDialog(
            onDismissRequest = { memberAction = null },
            containerColor = AuraSurface,
            title = { Text(ma.name, color = Color.White) },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton(onClick = {
                        memberAction = null
                        scope.launch { try { Repo.setAdmin(g, ma.uid, !isAdm) } catch (ignored: Throwable) {} }
                    }) { Text(if (isAdm) "Yöneticiliği kaldır" else "Yönetici yap", color = AuraGreen) }
                    TextButton(onClick = {
                        memberAction = null
                        scope.launch { try { Repo.removeMember(g, ma.uid) } catch (ignored: Throwable) {} }
                    }) { Text("Gruptan çıkar", color = Color(0xFFEF4444)) }
                    TextButton(onClick = { memberAction = null }) { Text("Vazgeç", color = AuraMuted) }
                }
            }
        )
    }
}

package com.aurachat.app.ui

import androidx.compose.ui.graphics.compositeOver
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.GroupData
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import kotlinx.coroutines.launch

/** "AuraChat'e davet edin": indirme bağlantısını paylaşır (yeni grup ve kişiler sayfasında ortak) */
@Composable
fun InviteRow() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Row(
        Modifier.fillMaxWidth().clickable {
            val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(android.content.Intent.EXTRA_TEXT, "AuraChat'e katıl: https://github.com/mustafataskin1986/AuraChatApp/releases/download/apk-latest/AuraChat.apk")
            }
            ctx.startActivity(android.content.Intent.createChooser(send, "AuraChat'e davet et").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        }.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).softCircle(), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Share, null, tint = ChipLook.fg)
        }
        Spacer(Modifier.width(14.dp))
        Text("AuraChat'e davet edin", fontSize = 17.sp, color = AuraWhite)
    }
}

/** Çoklu kişi seçici: yeni grup (requireName=true) ve gruba kişi ekleme için. Kişiler sekmesi ve "Grup oluştur" menüsü aynı sayfayı açar */
@Composable
fun ContactPickerScreen(
    me: UserProfile,
    title: String,
    exclude: Set<String>,
    requireName: Boolean,
    onBack: () -> Unit,
    onDone: (List<UserProfile>, String) -> Unit
) {
    val users by remember(me.uid) { Repo.usersFlow(me.uid) }.collectAsState(Repo.cachedUsers())
    val chats by remember(me.uid) { Repo.chatsFlow(me.uid) }.collectAsState(Repo.cachedChats(me.uid) ?: emptyList())
    var q by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var askName by remember { mutableStateOf(false) }
    var chosen by remember { mutableStateOf<List<String>>(emptyList()) }
    var working by remember { mutableStateOf(false) }

    fun finish(n: String) {
        working = true
        val byId = (users ?: emptyList()).associateBy { it.uid }
        onDone(chosen.mapNotNull { byId[it] }, n.trim())
    }

    Box(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding().navigationBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).height(56.dp)
                    .clip(RoundedCornerShape(28.dp)).background(AuraSurface).padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Box(Modifier.weight(1f).padding(horizontal = 6.dp), contentAlignment = Alignment.CenterStart) {
                    if (q.isEmpty()) Text("Ad, numara, @kullanıcıadı", color = AuraMuted, fontSize = 18.sp, maxLines = 1)
                    AuraTextField(
                        value = q, onValueChange = { q = it }, singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = AuraWhite, fontSize = 18.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(AuraGreen),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            val list = users
            if (list == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = AuraGreen) }
            } else {
                val byId = list.associateBy { it.uid }
                if (chosen.isNotEmpty()) {
                    androidx.compose.foundation.lazy.LazyRow(
                        Modifier.fillMaxWidth().padding(top = 6.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
                    ) {
                        items(chosen, key = { it }) { id ->
                            val u = byId[id] ?: return@items
                            Column(Modifier.width(84.dp).clickable { chosen = chosen - id }, horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.size(70.dp)) {
                                    Avatar(u.name, u.avatar, 64.dp)
                                    Box(
                                        Modifier.align(Alignment.BottomEnd).size(26.dp).clip(CircleShape).background(auraLc(0xFF3A3F44)),
                                        contentAlignment = Alignment.Center
                                    ) { Icon(Icons.Default.Close, null, tint = AuraWhite, modifier = Modifier.size(16.dp)) }
                                }
                                Text(u.name, color = AuraMuted, fontSize = 15.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                    androidx.compose.material3.HorizontalDivider(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), color = auraLc(0xFF2A2F33))
                }
                val shown = list.filter {
                    !exclude.contains(it.uid) && (q.isBlank() || it.name.contains(q, ignoreCase = true) || it.phone.contains(q))
                }
                val frequentIds = chats.filter { !it.isGroup }.sortedByDescending { it.lastTime }.map { it.otherUid }
                val frequent = if (q.isBlank()) frequentIds.mapNotNull { id -> shown.firstOrNull { it.uid == id } }.take(5) else emptyList()
                val rest = shown.filter { u -> frequent.none { it.uid == u.uid } }
                @Composable
                fun PersonRow(u: UserProfile) {
                    val on = chosen.contains(u.uid)
                    Row(
                        Modifier.fillMaxWidth().clickable { chosen = if (on) chosen - u.uid else chosen + u.uid }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(u.name, u.avatar, 46.dp)
                        Spacer(Modifier.width(18.dp))
                        Text(u.name, fontSize = 18.sp, color = AuraWhite, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Box(
                            Modifier.size(30.dp).clip(CircleShape)
                                .background(if (on) AuraGreen else Color.Transparent)
                                .border(2.dp, if (on) AuraGreen else AuraMuted, CircleShape),
                            contentAlignment = Alignment.Center
                        ) { if (on) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
                    }
                }
                LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 96.dp)) {
                    if (frequent.isNotEmpty()) {
                        item(key = "h-frequent") { Text("Sık görüşülenler", color = AuraMuted, fontSize = 16.sp, modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 6.dp)) }
                        items(frequent, key = { "f-" + it.uid }) { PersonRow(it) }
                    }
                    if (rest.isNotEmpty()) {
                        item(key = "h-rest") { Text("AuraChat'taki kişiler", color = AuraMuted, fontSize = 16.sp, modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 6.dp)) }
                        items(rest, key = { "r-" + it.uid }) { PersonRow(it) }
                    }
                    item(key = "invite") { InviteRow() }
                }
            }
        }
        if (chosen.isNotEmpty() && !working) {
            Box(
                Modifier.align(Alignment.BottomEnd).padding(20.dp).size(64.dp).clip(RoundedCornerShape(18.dp)).background(AuraGreen)
                    .clickable { if (requireName) askName = true else finish("") },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "Tamam", tint = Color.White, modifier = Modifier.size(28.dp)) }
        }
        if (askName) {
            AuraAlertDialog(
                onDismissRequest = { askName = false },
                containerColor = AuraSurface,
                title = { Text("Yeni grup", color = AuraWhite, fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it }, label = { Text("Grup adı") },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Sentences)
                    )
                },
                confirmButton = {
                    TextButton(enabled = name.isNotBlank() && !working, onClick = { askName = false; finish(name) }) {
                        Text("Oluştur", color = if (name.isNotBlank()) AuraGreen else AuraMuted, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = { TextButton(onClick = { askName = false }) { Text("Vazgeç", color = AuraWhite) } }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupInfoScreen(
    me: UserProfile,
    target: com.aurachat.app.data.ChatTarget,
    onBack: () -> Unit,
    onLeft: () -> Unit,
    onMessage: () -> Unit,
    onSearch: () -> Unit,
    onMedia: () -> Unit,
    onStarred: () -> Unit,
    onCall: (Boolean) -> Unit,
    onTheme: () -> Unit,
    onForward: (List<com.aurachat.app.data.Message>) -> Unit = {},
    onShowInChat: (com.aurachat.app.data.Message) -> Unit = {},
    onEdited: (String) -> Unit = {}
) {
    val groupId = target.chatId
    val scope = rememberCoroutineScope()
    val group by remember(groupId) { Repo.groupFlow(groupId) }.collectAsState(null as GroupData?)
    var showAdd by remember { mutableStateOf(false) }
    var cropUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val photoPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()
    ) { u -> if (u != null) cropUri = u }
    var showRename by remember { mutableStateOf(false) }
    var showLeave by remember { mutableStateOf(false) }
    var memberAction by remember { mutableStateOf<UserProfile?>(null) }

    val g = group
    if (g == null) {
        Box(Modifier.fillMaxSize().background(AuraBg), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = AuraGreen)
        }
        return
    }

    val cu = cropUri
    val ctxG = androidx.compose.ui.platform.LocalContext.current
    if (cu != null) {
        AvatarCropper(cu, 320, onDone = { d ->
            cropUri = null
            Repo.setGroupPhoto(groupId, d)
            android.widget.Toast.makeText(ctxG, "Grup fotoğrafı güncellendi", android.widget.Toast.LENGTH_SHORT).show()
        }, onCancel = { cropUri = null })
    }
    val iAmAdmin = g.admins.contains(me.uid) || g.createdBy == me.uid
    val members by remember(g.members, me) {
        kotlinx.coroutines.flow.combine(
            g.members.map { uid ->
                if (uid == me.uid) kotlinx.coroutines.flow.flowOf(me)
                else Repo.profileFlow(uid).let { f -> kotlinx.coroutines.flow.flow { f.collect { emit(it ?: UserProfile(uid, "", "", "", "")) } } }
            }
        ) { arr -> arr.map { p -> if (p.name.isBlank()) p.copy(name = "Kullanıcı") else p } }
    }.collectAsState(emptyList<UserProfile>())

    if (showAdd) {
        ContactPickerScreen(
            me = me, title = "Kişi ekle", exclude = g.members.toSet(), requireName = false,
            onBack = { showAdd = false }
        ) { picked, _ ->
            showAdd = false
            scope.launch { try { Repo.addMembers(me, g, picked.map { it.uid }) } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", ignored) } }
        }
        return
    }

    ContactInfoScreen(
        me = me, target = target, onBack = onBack, onMessage = onMessage, onSearch = onSearch, onMedia = onMedia,
        onStarred = onStarred, onCall = onCall, onTheme = onTheme, group = g,
        onForward = onForward, onShowInChat = onShowInChat, onEdited = onEdited,
        groupBody = {
            Column {
                if (iAmAdmin) {
                    GRow(Icons.Default.CameraAlt, AuraGreen, "Grup fotoğrafını değiştir") {
                        photoPicker.launch(androidx.activity.result.PickVisualMediaRequest(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    GRow(Icons.Default.Edit, AuraGreen, "Grup adını değiştir") { showRename = true }
                    GRow(Icons.Default.PersonAdd, AuraGreen, "Üye ekle") { showAdd = true }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(auraC(0xFF111B21)))
                }
                Text("${g.members.size} üye", color = AuraMuted, fontSize = 14.sp, modifier = Modifier.padding(start = 20.dp, top = 14.dp, bottom = 6.dp))
                members.forEach { u ->
                    val isMe = u.uid == me.uid
                    val tags = ArrayList<String>()
                    if (isMe) tags.add("Sen")
                    if (g.createdBy == u.uid) tags.add("Kurucu") else if (g.admins.contains(u.uid)) tags.add("Yönetici")
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable(enabled = iAmAdmin && !isMe && g.createdBy != u.uid) { memberAction = u }
                            .padding(horizontal = 20.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(u.name, u.avatar, 46.dp)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(u.name, fontSize = 17.sp, color = AuraWhite, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            if (u.about.isNotBlank()) Text(u.about, fontSize = 13.sp, color = AuraMuted, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        }
                        if (tags.isNotEmpty()) {
                            Text(
                                tags.joinToString(" · "), color = AuraGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(auraLc(0x3310B981)).padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(auraC(0xFF111B21)))
                GRow(Icons.AutoMirrored.Filled.ExitToApp, auraLc(0xFFFB7185), "Gruptan ayrıl", auraLc(0xFFFB7185)) { showLeave = true }
            }
        }
    )

    if (showLeave) {
        AuraAlertDialog(
            onDismissRequest = { showLeave = false },
            containerColor = AuraSurface,
            title = { Text("Gruptan ayrılmak istiyor musun?", color = AuraWhite) },
            confirmButton = {
                TextButton(onClick = {
                    showLeave = false
                    scope.launch {
                        try { Repo.leaveGroup(me, g) } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", ignored) }
                        onLeft()
                    }
                }) { Text("Ayrıl", color = auraLc(0xFFEF4444)) }
            },
            dismissButton = { TextButton(onClick = { showLeave = false }) { Text("Vazgeç", color = AuraGreen) } }
        )
    }

    if (showRename) {
        var newName by remember { mutableStateOf(g.name) }
        AuraAlertDialog(
            onDismissRequest = { showRename = false },
            containerColor = AuraSurface,
            title = { Text("Grup adı", color = AuraWhite) },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, singleLine = true, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Sentences)) },
            confirmButton = {
                TextButton(onClick = {
                    val n = newName.trim()
                    showRename = false
                    if (n.isNotEmpty() && n != g.name) scope.launch { try { Repo.renameGroup(g, n) } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", ignored) } }
                }) { Text("Kaydet", color = AuraGreen) }
            },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text("Vazgeç", color = AuraMuted) } }
        )
    }

    val ma = memberAction
    if (ma != null) {
        val isAdm = g.admins.contains(ma.uid)
        AuraAlertDialog(
            onDismissRequest = { memberAction = null },
            containerColor = AuraSurface,
            title = { Text(ma.name, color = AuraWhite) },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton(onClick = {
                        memberAction = null
                        scope.launch { try { Repo.setAdmin(g, ma.uid, !isAdm) } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", ignored) } }
                    }) { Text(if (isAdm) "Yöneticiliği kaldır" else "Yönetici yap", color = AuraGreen) }
                    TextButton(onClick = {
                        memberAction = null
                        scope.launch { try { Repo.removeMember(g, ma.uid) } catch (ignored: Throwable) { com.aurachat.app.AuraLog.e("GroupScreens", ignored) } }
                    }) { Text("Gruptan çıkar", color = auraLc(0xFFEF4444)) }
                    TextButton(onClick = { memberAction = null }) { Text("Vazgeç", color = AuraMuted) }
                }
            }
        )
    }
}

@Composable
private fun GRow(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, label: String, labelColor: Color = AuraWhite, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        Text(label, color = labelColor, fontSize = 16.sp, modifier = Modifier.padding(start = 20.dp))
    }
}

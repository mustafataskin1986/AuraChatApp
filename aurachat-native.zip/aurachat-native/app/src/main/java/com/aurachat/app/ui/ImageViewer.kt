package com.aurachat.app.ui

import androidx.compose.material.icons.filled.ArrowUpward
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Download
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.width
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aurachat.app.data.Media
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

data class ViewerItem(val src: String, val time: Long = 0L, val senderName: String = "", val id: String = "", val caption: String = "")

class ViewerActions(
    val onForward: ((ViewerItem) -> Unit)? = null,
    val onStar: ((ViewerItem) -> Unit)? = null,
    val isStarred: (ViewerItem) -> Boolean = { false },
    val getReaction: (ViewerItem) -> String? = { null },
    val onReact: ((ViewerItem, String) -> Unit)? = null,
    val onReplySend: ((ViewerItem, String) -> Unit)? = null,
    val menu: List<Pair<String, (ViewerItem) -> Unit>> = emptyList()
)

private val IvBar = Color(0xCC000000)
private val IvMenuBg = Color(0xFF233138)
private val IvPill = Color(0xFF1F2C34)

private fun ivTimeLabel(ms: Long): String {
    if (ms <= 0L) return ""
    val d = Calendar.getInstance().apply { timeInMillis = ms }
    val hm = "%02d:%02d".format(d.get(Calendar.HOUR_OF_DAY), d.get(Calendar.MINUTE))
    val now = Calendar.getInstance()
    fun dayStart(c: Calendar) = Calendar.getInstance().apply {
        timeInMillis = c.timeInMillis
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val diff = ((dayStart(now) - dayStart(d)) / 86_400_000L).toInt()
    return when (diff) {
        0 -> "Bugün $hm"
        1 -> "Dün $hm"
        else -> "%02d.%02d.%d %s".format(d.get(Calendar.DAY_OF_MONTH), d.get(Calendar.MONTH) + 1, d.get(Calendar.YEAR), hm)
    }
}

/** Basit görüntüleyici (paylaşılan medya, kişi bilgisi vb.): resim + geri + indir */
@Composable
fun ImageViewer(images: List<String>, startIndex: Int, onClose: () -> Unit) {
    ChatImageViewer(images.map { ViewerItem(it) }, startIndex, false, ViewerActions(), onClose)
}

/** WhatsApp / web sürümündeki gibi resim görüntüleyici: üst bar, alt "Cevapla" çubuğu, albüm listesi */
@Composable
fun ChatImageViewer(items: List<ViewerItem>, startIndex: Int, album: Boolean, actions: ViewerActions, onClose: () -> Unit) {
    if (items.isEmpty()) { onClose(); return }
    val ctx = LocalContext.current
    var mode by remember { mutableStateOf(if (album && items.size > 1) "list" else "single") }
    var fromAlbum by remember { mutableStateOf(false) }
    var cur by remember { mutableIntStateOf(startIndex.coerceIn(0, items.size - 1)) }

    fun goBack() {
        if (mode == "single" && fromAlbum && album) { fromAlbum = false; mode = "list" } else onClose()
    }

    // Pencere (Dialog) yerine uygulamanın en üstündeki tam ekran katmanda çizilir: sistem çubuklarıyla uğraşmadan gerçek tam ekran olur
    val body: @Composable () -> Unit = {
        BackHandler { goBack() }
        // Albümden açılan resim, albüm listesinin ÜSTÜNDE çizilir: aşağı/yukarı sürükleyince arkada sohbet değil liste görünür
        Box(Modifier.fillMaxSize()) {
            if (mode == "list" || (mode == "single" && fromAlbum && album)) {
                AlbumList(items, cur, onBack = { goBack() }, onPick = { i -> cur = i; fromAlbum = true; mode = "single" })
            }
            if (mode == "single") {
                SingleViewer(items, cur, actions, onBack = { goBack() }, onClose = onClose, onPage = { cur = it })
            }
        }
    }
    val bodyState = androidx.compose.runtime.rememberUpdatedState(body)
    var actCtx: android.content.Context? = ctx
    while (actCtx is android.content.ContextWrapper && actCtx !is android.app.Activity) actCtx = actCtx.baseContext
    val activity = actCtx as? android.app.Activity
    androidx.compose.runtime.DisposableEffect(Unit) {
        ViewerOverlay.content.value = { bodyState.value() }
        val w = activity?.window
        val c = w?.let { androidx.core.view.WindowCompat.getInsetsController(it, it.decorView) }
        c?.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose {
            ViewerOverlay.content.value = null
            c?.show(androidx.core.view.WindowInsetsCompat.Type.statusBars())
        }
    }
}

/** Resim görüntüleyicinin çizildiği uygulama içi tam ekran katman (MainActivity'de en üstte durur) */
object ViewerOverlay {
    val content = androidx.compose.runtime.mutableStateOf<(@Composable () -> Unit)?>(null)
}

@Composable
fun ViewerOverlayHost() {
    val c = ViewerOverlay.content.value
    if (c != null) Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }) { c() }
}

@Composable
private fun TopBtn(onClick: () -> Unit, content: @Composable () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(44.dp)) { content() }
}

@Composable
private fun AlbumList(items: List<ViewerItem>, start: Int, onBack: () -> Unit, onPick: (Int) -> Unit) {
    val state = rememberLazyListState(initialFirstVisibleItemIndex = start.coerceIn(0, items.size - 1))
    // listenin en üstünde aşağı, en altında yukarı çekince (taşma) kapanır
    var pull by androidx.compose.runtime.remember { mutableFloatStateOf(0f) }
    val threshold = with(LocalDensity.current) { 110.dp.toPx() }
    val conn = androidx.compose.runtime.remember {
        object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): Offset {
                if (pull != 0f && source == androidx.compose.ui.input.nestedscroll.NestedScrollSource.UserInput) {
                    val np = pull + available.y
                    if (pull * np <= 0f) { val used = -pull; pull = 0f; return Offset(0f, used) }
                    pull = np
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }
            override fun onPostScroll(consumed: Offset, available: Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): Offset {
                if (source == androidx.compose.ui.input.nestedscroll.NestedScrollSource.UserInput && available.y != 0f) {
                    pull += available.y
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }
            override suspend fun onPreFling(available: androidx.compose.ui.unit.Velocity): androidx.compose.ui.unit.Velocity {
                if (kotlin.math.abs(pull) > threshold) onBack()
                else if (pull != 0f) androidx.compose.animation.core.animate(pull, 0f) { v, _ -> pull = v }
                return androidx.compose.ui.unit.Velocity.Zero
            }
        }
    }
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = (1f - kotlin.math.abs(pull) / 1200f).coerceIn(0.35f, 1f)))) {
        LazyColumn(state = state, modifier = Modifier.fillMaxSize().nestedScroll(conn).graphicsLayer { translationY = pull * 0.6f }, contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 78.dp, bottom = 20.dp)) {
            itemsIndexed(items, key = { i, _ -> i }) { i, it ->
                val bmp by produceState<Bitmap?>(null, it.src) { value = withContext(Dispatchers.Default) { Media.decode(it.src, 1600) } }
                val b = bmp
                Box(Modifier.fillMaxWidth().padding(bottom = 6.dp).background(Color(0xFF111111)).clickable { onPick(i) }) {
                    if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
                    else Spacer(Modifier.fillMaxWidth().height(240.dp))
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(IvBar).statusBarsPadding().padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TopBtn(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
            Column(Modifier.weight(1f).padding(start = 4.dp)) {
                Text(items[0].senderName, color = Color.White, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${items.size} fotoğraf", color = Color(0xBFFFFFFF), fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun SingleViewer(
    items: List<ViewerItem>, start: Int, actions: ViewerActions,
    onBack: () -> Unit, onClose: () -> Unit, onPage: (Int) -> Unit
) {
    val ctx = LocalContext.current
    val pager = rememberPagerState(initialPage = start.coerceIn(0, items.size - 1)) { items.size }
    val item = items[pager.currentPage.coerceIn(0, items.size - 1)]
    var zoomed by remember { mutableStateOf(false) }
    var bars by remember { mutableStateOf(true) }
    var menuOpen by remember { mutableStateOf(false) }
    var dragY by remember { mutableFloatStateOf(0f) }
    val screenH = with(LocalDensity.current) { LocalConfiguration.current.screenHeightDp.dp.toPx() }
    var reply by remember { mutableStateOf("") }
    var focused by remember { mutableStateOf(false) }
    var strip by remember { mutableStateOf(false) }
    val showBars = bars && dragY == 0f
    val barAlpha by androidx.compose.animation.core.animateFloatAsState(if (showBars) 1f else 0f, androidx.compose.animation.core.tween(380, easing = androidx.compose.animation.core.FastOutSlowInEasing), label = "barAlpha")
    val hasBottom = actions.onReplySend != null || actions.onReact != null
    // çubuklar görünürken durum çubuğu da görünür (aynı renk); dokununca hepsi gizlenip tam ekran olur
    val statusHidden = !bars && dragY == 0f   // sürüklerken durum çubuğu görünür kalır (arkada albüm/sohbet olduğunda boşluk kalmasın)
    androidx.compose.runtime.LaunchedEffect(statusHidden) {
        var cc: android.content.Context? = ctx
        while (cc is android.content.ContextWrapper && cc !is android.app.Activity) cc = cc.baseContext
        val w = (cc as? android.app.Activity)?.window ?: return@LaunchedEffect
        val c = androidx.core.view.WindowCompat.getInsetsController(w, w.decorView)
        c.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        // çubuklarla aynı anda gelip gitsin: kayarak animasyonlu sistem çağrısı yerine eski bayrak (anında)
        @Suppress("DEPRECATION")
        run {
            val dv = w.decorView
            val fl = android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            dv.systemUiVisibility = if (!statusHidden) dv.systemUiVisibility and fl.inv() else dv.systemUiVisibility or fl
        }
    }
    androidx.compose.runtime.LaunchedEffect(pager.currentPage) { onPage(pager.currentPage) }

    // durum çubuğunu gizle (WhatsApp gibi tam ekran); ekranın kenarından çekince geçici görünür
    val camDist = 14f * LocalDensity.current.density

    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = (1f - kotlin.math.abs(dragY) / (screenH * 0.6f)).coerceIn(0f, 1f)))) {
        HorizontalPager(
            state = pager, userScrollEnabled = !zoomed, modifier = Modifier.fillMaxSize().graphicsLayer(translationY = dragY)
        ) { page ->
            Box(
                Modifier.fillMaxSize().graphicsLayer {
                    val off = (pager.currentPage - page) + pager.currentPageOffsetFraction   // sağdaki sayfa: negatif
                    rotationY = -80f * off.coerceIn(-1f, 1f)
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(if (off < 0f) 0f else 1f, 0.5f)
                    cameraDistance = camDist
                }
            ) {
            ZoomableImage(
                items[page].src,
                onTap = { menuOpen = false; strip = false; bars = !bars },
                onZoom = { zoomed = it },
                onDrag = { dy -> dragY += dy },
                onDragEnd = { if (kotlin.math.abs(dragY) > screenH * 0.10f) onBack() else dragY = 0f }
            )
            }
        }

        if (focused) Box(Modifier.fillMaxSize().background(Color(0x99000000)))

        if (barAlpha > 0.01f) {
            Row(
                Modifier.align(Alignment.TopCenter).fillMaxWidth().graphicsLayer(alpha = barAlpha).background(IvBar).statusBarsPadding().padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TopBtn(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White) }
                Column(Modifier.weight(1f).padding(start = 4.dp)) {
                    if (item.senderName.isNotBlank()) Text(item.senderName, color = Color.White, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    val tl = ivTimeLabel(item.time)
                    if (tl.isNotEmpty()) Text(tl, color = Color(0xBFFFFFFF), fontSize = 14.sp)
                }
                TopBtn({
                    val ok = Media.saveToGallery(ctx, item.src, "aura_${System.currentTimeMillis()}.jpg")
                    Toast.makeText(ctx, if (ok) "Galeriye kaydedildi" else "Kaydedilemedi", Toast.LENGTH_SHORT).show()
                }) { Icon(Icons.Default.Download, "İndir", tint = Color.White) }
                if (actions.onForward != null) TopBtn({ actions.onForward?.invoke(item) }) {
                    Icon(Icons.AutoMirrored.Filled.Reply, "İlet", tint = Color.White, modifier = Modifier.graphicsLayer(scaleX = -1f))
                }
                if (actions.onStar != null) {
                    val st = actions.isStarred(item)
                    TopBtn({ actions.onStar?.invoke(item) }) {
                        Icon(if (st) Icons.Default.Star else Icons.Default.StarBorder, "Yıldızla", tint = if (st) Color(0xFFFBBF24) else Color.White)
                    }
                }
                if (actions.menu.isNotEmpty()) TopBtn({ menuOpen = !menuOpen }) { Icon(Icons.Default.MoreVert, "Menü", tint = Color.White) }
            }
            if (menuOpen) {
                Column(
                    Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 62.dp, end = 10.dp)
                        .width(androidx.compose.foundation.layout.IntrinsicSize.Max).widthIn(min = 180.dp).clip(RoundedCornerShape(12.dp)).background(AuraRawSurface)
                ) {
                    actions.menu.forEach { (label, fn) ->
                        Text(
                            label, color = Color.White, fontSize = 15.sp, maxLines = 1,
                            modifier = Modifier.fillMaxWidth().clickable { menuOpen = false; fn(item) }.padding(horizontal = 16.dp, vertical = 12.dp)
                        )
                    }
                }
            }
        }

        if (barAlpha > 0.01f && hasBottom) {
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().graphicsLayer(alpha = barAlpha)
                    .background(IvBar)
                    .imePadding().navigationBarsPadding().padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 12.dp)
            ) {
                val current = actions.getReaction(item)
                @Composable
                fun Emo(e: String) {
                    Box(
                        Modifier.size(44.dp).clip(CircleShape).background(if (current == e) Color(0x38FFFFFF) else Color.Transparent)
                            .clickable { actions.onReact?.invoke(item, e); strip = false },
                        contentAlignment = Alignment.Center
                    ) { Text(e, fontSize = 28.sp) }
                }
                if (strip) {
                    Row(
                        Modifier.align(Alignment.CenterHorizontally).padding(bottom = 10.dp).clip(RoundedCornerShape(50))
                            .background(Color(0xFF233138)).padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) { listOf("👍", "❤️", "😂", "😮", "😢", "🙏").forEach { Emo(it) } }
                }
                if (!(focused || reply.isNotEmpty()) && item.caption.isNotBlank()) {
                    Text(
                        item.caption, color = Color.White, fontSize = 17.sp, maxLines = 4, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 12.dp)
                    )
                }
                // alıntı ve cevap girişi tek çerçevede
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(IvPill)) {
                if (focused || reply.isNotEmpty()) {
                    // WhatsApp gibi: yazarken alıntılanan resim (ad, açıklama, küçük resim) girişin üstünde görünür
                    QuoteCard(
                        item.senderName.ifBlank { "Fotoğraf" }, Color(0xFF86EFAC), Color(0xFF22C55E),
                        item.caption.ifBlank { "Fotoğraf" }, true, item.src,
                        Color(0x40000000), 12.dp, 13f, 48.dp, Modifier.padding(start = 8.dp, end = 8.dp, top = 8.dp)
                    )
                }
                Row(
                    Modifier.fillMaxWidth().height(48.dp).padding(start = 18.dp, end = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.weight(1f)) {
                        if (reply.isEmpty()) Text("Cevapla", color = Color(0x99FFFFFF), fontSize = 16.sp)
                        AuraTextField(
                            value = reply, onValueChange = { reply = it }, singleLine = true,
                            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                            cursorBrush = SolidColor(Color.White),
                            modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused }
                        )
                    }
                    val has = reply.isNotBlank()
                    if (!focused && !has) {
                        Emo("❤️"); Emo("😂")
                        TopBtn({ strip = !strip }) { Icon(Icons.Default.EmojiEmotions, "Emoji", tint = Color.White) }
                    }
                    if (has) Box(
                        Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF22C55E)).clickable {
                            val t = reply.trim()
                            if (t.isNotEmpty()) { actions.onReplySend?.invoke(item, t); onClose() }
                        },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.ArrowUpward, "Gönder", tint = Color.White, modifier = Modifier.size(22.dp)) }
                }
                }
            }
        }
    }
}

@Composable
private fun ZoomableImage(
    data: String,
    onTap: () -> Unit,
    onZoom: (Boolean) -> Unit,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit
) {
    val bmp by produceState<Bitmap?>(null, data) {
        value = withContext(Dispatchers.Default) { Media.decode(data, 2048) }
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val b = bmp
    var boxSize by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
    // resim çerçevenin dışına akmasın: kaydırma, büyütülmüş resmin kenarlarıyla sınırlı
    fun clampOff(o: Offset, sc: Float): Offset {
        val bm = bmp
        if (bm == null || boxSize.width == 0 || boxSize.height == 0 || sc <= 1f) return Offset.Zero
        val bw = boxSize.width.toFloat(); val bh = boxSize.height.toFloat()
        val fit = minOf(bw / bm.width, bh / bm.height)
        val mx = maxOf(0f, (bm.width * fit * sc - bw) / 2f)
        val my = maxOf(0f, (bm.height * fit * sc - bh) / 2f)
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }
    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { boxSize = it }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = {
                        if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f
                        onZoom(scale > 1f)
                    }
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    var dragging = false
                    do {
                        val ev = awaitPointerEvent()
                        val pts = ev.changes.filter { it.pressed }
                        if (pts.size >= 2 || scale > 1f) {
                            val zoom = ev.calculateZoom()
                            val pan = ev.calculatePan()
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            offset = if (scale > 1f) clampOff(offset + pan, scale) else Offset.Zero
                            onZoom(scale > 1.01f)
                            ev.changes.forEach { if (it.positionChange() != Offset.Zero) it.consume() }
                        } else if (pts.size == 1) {
                            val ch = pts[0]
                            val d = ch.positionChange()
                            if (dragging || (kotlin.math.abs(d.y) > kotlin.math.abs(d.x) * 1.5f && kotlin.math.abs(d.y) > 3f)) {
                                dragging = true
                                onDrag(d.y)
                                ch.consume()
                            }
                        }
                    } while (ev.changes.any { it.pressed })
                    if (dragging) onDragEnd()
                }
            },
        contentAlignment = Alignment.Center
    ) {
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().graphicsLayer(
                    scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y
                )
            )
        }
    }
}

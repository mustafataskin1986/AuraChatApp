package com.aurachat.app.ui

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.unit.Velocity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aurachat.app.data.Media
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ImageViewer(images: List<String>, startIndex: Int, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val pager = rememberPagerState(initialPage = startIndex.coerceIn(0, (images.size - 1).coerceAtLeast(0))) { images.size }
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        var zoomed by remember { mutableStateOf(false) }
        var drag by remember { mutableFloatStateOf(0f) }
        val closePx = with(androidx.compose.ui.platform.LocalDensity.current) { 120.dp.toPx() }
        val conn = remember {
            object : NestedScrollConnection {
                override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                    if (source == NestedScrollSource.UserInput && available.y != 0f) { drag += available.y; return available }
                    return Offset.Zero
                }
                override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                    if (kotlin.math.abs(drag) > closePx) onClose() else drag = 0f
                    return Velocity.Zero
                }
            }
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = (1f - kotlin.math.abs(drag) / 900f).coerceIn(0.3f, 1f)))) {
            VerticalPager(
                state = pager, userScrollEnabled = !zoomed,
                modifier = Modifier.fillMaxSize().nestedScroll(conn).graphicsLayer(translationY = drag * 0.5f)
            ) { page ->
                ZoomableImage(images[page]) { zoomed = it }
            }
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = Color.White)
                }
                Box(Modifier.weight(1f))
                if (images.size > 1) {
                    Text("${pager.currentPage + 1} / ${images.size}", color = Color.White)
                }
                IconButton(onClick = {
                    val ok = Media.saveToGallery(ctx, images[pager.currentPage], "aura_${System.currentTimeMillis()}.jpg")
                    Toast.makeText(ctx, if (ok) "Galeriye kaydedildi" else "Kaydedilemedi", Toast.LENGTH_SHORT).show()
                }) {
                    Icon(Icons.Default.Download, "Kaydet", tint = Color.White)
                }
            }
        }
    }
}

@Composable
private fun ZoomableImage(data: String, onZoom: (Boolean) -> Unit) {
    val bmp by produceState<android.graphics.Bitmap?>(null, data) {
        value = withContext(Dispatchers.Default) { Media.decode(data, 2048) }
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val b = bmp
    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1f) {
                        scale = 1f
                        offset = Offset.Zero
                    } else {
                        scale = 2.5f
                    }
                    onZoom(scale > 1f)
                })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val pts = ev.changes.filter { it.pressed }
                        if (pts.size >= 2 || scale > 1f) {
                            val zoom = ev.calculateZoom()
                            val pan = ev.calculatePan()
                            scale = (scale * zoom).coerceIn(1f, 6f)
                            offset = if (scale > 1f) offset + pan else Offset.Zero
                            onZoom(scale > 1.01f)
                            ev.changes.forEach { if (it.positionChange() != Offset.Zero) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center
    ) {
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    )
            )
        }
    }
}

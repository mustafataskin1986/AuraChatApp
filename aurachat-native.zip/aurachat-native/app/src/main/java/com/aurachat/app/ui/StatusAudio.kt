package com.aurachat.app.ui

import android.media.MediaPlayer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Media
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Ses durumu kartı (WhatsApp ölçüleri: 321x68dp, köşe 14dp, solda 48dp avatar + mikrofon rozeti, noktalı çizgi).
 * bars: kayıt sırasında canlı seviyeler; frac >= 0: oynatma konumu; timeText: sağdaki süre
 */
@Composable
fun StatusAudioCard(name: String, avatar: String, bars: List<Float>, frac: Float, timeText: String?, showCursor: Boolean, modifier: Modifier = Modifier) {
    Row(
        modifier.padding(horizontal = 36.dp).fillMaxWidth().height(68.dp)
            .clip(RoundedCornerShape(14.dp)).background(Color(0x2E000000)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.padding(start = 10.dp).size(54.dp)) {
            Box(Modifier.align(Alignment.CenterStart)) { Avatar(name, avatar, 48.dp) }
            Icon(Icons.Default.Mic, null, tint = Color.White, modifier = Modifier.align(Alignment.BottomEnd).size(22.dp))
        }
        Canvas(Modifier.weight(1f).height(40.dp).padding(start = 12.dp, end = 8.dp)) {
            val n = 60
            val step = size.width / n
            val cy = size.height / 2f
            val vis = if (bars.size > n - 1) bars.takeLast(n - 1) else bars
            val dotR = 1.5.dp.toPx()
            val cursorIdx = if (frac >= 0f) (frac * n).toInt().coerceIn(0, n - 1) else vis.size.coerceIn(0, n - 1)
            for (i in 0 until n) {
                val x = i * step + step / 2f
                if (frac < 0f && i < vis.size) {
                    val h = 4.dp.toPx() + vis[i] * 30.dp.toPx()
                    drawLine(Color.White, Offset(x, cy - h / 2f), Offset(x, cy + h / 2f), 2.5.dp.toPx(), StrokeCap.Round)
                } else {
                    val played = frac >= 0f && i < cursorIdx
                    drawCircle(if (played) Color.White else Color(0x59FFFFFF), dotR, Offset(x, cy))
                }
            }
            if (showCursor) {
                val x = cursorIdx * step + step / 2f
                drawLine(Color.White, Offset(x, cy - 12.dp.toPx()), Offset(x, cy + 12.dp.toPx()), 2.5.dp.toPx(), StrokeCap.Round)
            }
        }
        if (timeText != null) Text(timeText, color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(end = 14.dp))
        else Box(Modifier.padding(end = 14.dp))
    }
}

/** Görüntüleyici: ses durumu kartı + otomatik oynatma (duraklatılınca durur) */
@Composable
fun StatusAudioStage(id: String, data: String, name: String, avatar: String, sec: Int, frac: Float, active: Boolean) {
    val ctx = LocalContext.current
    val player by produceState<MediaPlayer?>(null, id, data) {
        value = withContext(Dispatchers.IO) {
            try {
                val f = Media.writeCacheFile(ctx, data, "stat_$id.m4a")
                MediaPlayer().apply { setDataSource(f.absolutePath); prepare() }
            } catch (e: Throwable) { null }
        }
    }
    DisposableEffect(player) { onDispose { try { player?.release() } catch (_: Throwable) {} } }
    LaunchedEffect(player, active) {
        val p = player ?: return@LaunchedEffect
        try { if (active) p.start() else if (p.isPlaying) p.pause() } catch (_: Throwable) {}
    }
    val shown = (frac * sec).toInt().coerceIn(0, sec)
    StatusAudioCard(name, avatar, emptyList(), frac, "%d:%02d".format(shown / 60, shown % 60), showCursor = true)
}

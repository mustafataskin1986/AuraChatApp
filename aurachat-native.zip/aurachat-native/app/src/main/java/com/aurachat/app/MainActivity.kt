package com.aurachat.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import android.widget.Toast
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Message
import com.aurachat.app.data.OpenChat
import com.aurachat.app.ui.ContactPickerScreen
import com.aurachat.app.ui.ForwardScreen
import com.aurachat.app.ui.GroupInfoScreen
import com.aurachat.app.ui.StarredScreen
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import com.aurachat.app.ui.AuraBg
import com.aurachat.app.ui.AuraGreen
import com.aurachat.app.ui.AuraTheme
import com.aurachat.app.ui.ChatListScreen
import com.aurachat.app.ui.ChatScreen
import com.aurachat.app.ui.ContactsScreen
import com.aurachat.app.ui.LoginScreen
import com.aurachat.app.ui.NameScreen
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val openChat = mutableStateOf<OpenChat?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        readIntent(intent)
        setContent { AuraTheme { AuraRoot(openChat) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    override fun onStart() { super.onStart(); AppState.foreground = true }
    override fun onStop() { super.onStop(); AppState.foreground = false }

    private fun readIntent(i: Intent?) {
        val cid = i?.getStringExtra("chatId")
        if (!cid.isNullOrEmpty()) {
            openChat.value = OpenChat(cid, i?.getStringExtra("otherUid") ?: "", i?.getStringExtra("otherName") ?: "")
        }
    }
}

@Composable
private fun AuraRoot(openChat: MutableState<OpenChat?>) {
    val auth = remember { FirebaseAuth.getInstance() }
    var fbUser by remember { mutableStateOf(auth.currentUser) }
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener { fbUser = it.currentUser }
        auth.addAuthStateListener(l)
        onDispose { auth.removeAuthStateListener(l) }
    }

    val uid = fbUser?.uid
    var profile by remember(uid) { mutableStateOf<UserProfile?>(uid?.let { Repo.cachedProfile(it) }) }
    var loaded by remember(uid) { mutableStateOf(profile != null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(uid) {
        if (uid != null) {
            val fresh = try { Repo.loadProfile(uid) } catch (e: Exception) { null }
            if (fresh != null) profile = fresh
            loaded = true
        }
    }

    val p = profile
    when {
        uid == null -> LoginScreen()
        !loaded -> Box(Modifier.fillMaxSize().background(AuraBg), Alignment.Center) { CircularProgressIndicator(color = AuraGreen) }
        p == null || p.name.isBlank() -> NameScreen { name ->
            scope.launch { profile = Repo.saveName(uid, fbUser?.email ?: "", name) }
        }
        else -> Home(p, openChat) { auth.signOut() }
    }
}

private sealed interface Screen {
    data object Chats : Screen
    data object Contacts : Screen
    data object NewGroup : Screen
    data object Starred : Screen
    data class Chat(val target: ChatTarget) : Screen
    data class GroupInfo(val target: ChatTarget) : Screen
    data class Forward(val from: ChatTarget, val msgs: List<Message>) : Screen
}

@Composable
private fun Home(me: UserProfile, openChat: MutableState<OpenChat?>, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf<Screen>(Screen.Chats) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(me.uid) {
        Repo.registerPush(me.uid)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    // Bildirime dokununca doğrudan sohbet (birebir ya da grup) açılır
    LaunchedEffect(openChat.value) {
        openChat.value?.let {
            screen = Screen.Chat(Repo.targetFor(me.uid, it.chatId, it.otherName))
            openChat.value = null
        }
    }
    BackHandler(enabled = screen !is Screen.Chats) {
        screen = when (val s = screen) {
            is Screen.GroupInfo -> Screen.Chat(s.target)
            is Screen.Forward -> Screen.Chat(s.from)
            Screen.NewGroup -> Screen.Contacts
            else -> Screen.Chats
        }
    }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        when (val s = screen) {
            Screen.Chats -> ChatListScreen(
                me,
                onOpen = { screen = Screen.Chat(ChatTarget(it.chatId, it.isGroup, it.otherUid, it.name)) },
                onNewChat = { screen = Screen.Contacts },
                onNewGroup = { screen = Screen.NewGroup },
                onStarred = { screen = Screen.Starred },
                onSignOut = onSignOut
            )
            Screen.Contacts -> ContactsScreen(
                me,
                onBack = { screen = Screen.Chats },
                onNewGroup = { screen = Screen.NewGroup }
            ) { u ->
                screen = Screen.Chat(ChatTarget(Repo.chatId(me.uid, u.uid), false, u.uid, u.name))
            }
            Screen.NewGroup -> ContactPickerScreen(
                me = me, title = "Yeni grup", exclude = emptySet(), requireName = true,
                onBack = { screen = Screen.Contacts }
            ) { picked, name ->
                scope.launch {
                    try {
                        val id = Repo.createGroup(me, name, picked.map { it.uid })
                        screen = Screen.Chat(ChatTarget(id, true, id, name))
                    } catch (e: Throwable) {
                        Toast.makeText(ctx, "Grup oluşturulamadı", Toast.LENGTH_SHORT).show()
                        screen = Screen.Chats
                    }
                }
            }
            Screen.Starred -> StarredScreen(me, onBack = { screen = Screen.Chats }) { item ->
                screen = Screen.Chat(Repo.targetFor(me.uid, item.chatId, item.chatName))
            }
            is Screen.Chat -> ChatScreen(
                me = me,
                target = s.target,
                onBack = { screen = Screen.Chats },
                onOpenGroupInfo = { screen = Screen.GroupInfo(s.target) },
                onForward = { msgs -> screen = Screen.Forward(s.target, msgs) }
            )
            is Screen.GroupInfo -> GroupInfoScreen(
                me = me,
                groupId = s.target.chatId,
                onBack = { screen = Screen.Chat(s.target) },
                onLeft = { screen = Screen.Chats }
            )
            is Screen.Forward -> ForwardScreen(me, s.msgs.size, onBack = { screen = Screen.Chat(s.from) }) { to ->
                scope.launch {
                    try {
                        s.msgs.forEach { Repo.forward(me, to, it) }
                    } catch (e: Throwable) {
                        Toast.makeText(ctx, "İletilemedi", Toast.LENGTH_SHORT).show()
                    }
                }
                screen = Screen.Chat(to)
            }
        }
    }
}

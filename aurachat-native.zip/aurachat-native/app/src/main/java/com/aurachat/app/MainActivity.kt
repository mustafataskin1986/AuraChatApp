package com.aurachat.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.aurachat.app.data.OpenChat
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import com.aurachat.app.ui.AuraBg
import com.aurachat.app.ui.AuraGreen
import com.aurachat.app.ui.AuraTheme
import com.aurachat.app.ui.ChatListScreen
import com.aurachat.app.ui.ChatScreen
import com.aurachat.app.ui.ContactsScreen
import com.aurachat.app.ui.LoginScreen
import com.aurachat.app.ui.NameScreen
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val openChat = mutableStateOf<OpenChat?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        readIntent(intent)
        setContent { AuraTheme { AuraRoot(openChat) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    override fun onStart() { super.onStart(); AppState.foreground = true }
    override fun onStop() { super.onStop(); AppState.foreground = false }

    private fun readIntent(i: Intent?) {
        val cid = i?.getStringExtra("chatId")
        val ou = i?.getStringExtra("otherUid")
        if (!cid.isNullOrEmpty() && !ou.isNullOrEmpty()) {
            openChat.value = OpenChat(cid, ou, i.getStringExtra("otherName") ?: "")
        }
    }
}

@Composable
private fun AuraRoot(openChat: MutableState<OpenChat?>) {
    val auth = remember { FirebaseAuth.getInstance() }
    var fbUser by remember { mutableStateOf(auth.currentUser) }
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener { fbUser = it.currentUser }
        auth.addAuthStateListener(l)
        onDispose { auth.removeAuthStateListener(l) }
    }

    val uid = fbUser?.uid
    var profile by remember(uid) { mutableStateOf<UserProfile?>(null) }
    var loaded by remember(uid) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(uid) {
        if (uid != null) {
            profile = try { Repo.loadProfile(uid) } catch (e: Exception) { null }
            loaded = true
        }
    }

    val p = profile
    when {
        uid == null -> LoginScreen()
        !loaded -> Box(Modifier.fillMaxSize().background(AuraBg), Alignment.Center) { CircularProgressIndicator(color = AuraGreen) }
        p == null || p.name.isBlank() -> NameScreen { name ->
            scope.launch { profile = Repo.saveName(uid, fbUser?.email ?: "", name) }
        }
        else -> Home(p, openChat) { auth.signOut() }
    }
}

private sealed interface Screen {
    data object Chats : Screen
    data object Contacts : Screen
    data class Chat(val chatId: String, val otherUid: String, val otherName: String) : Screen
}

@Composable
private fun Home(me: UserProfile, openChat: MutableState<OpenChat?>, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf<Screen>(Screen.Chats) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(me.uid) {
        Repo.registerPush(me.uid)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    // Bildirime dokununca doğrudan sohbet açılır
    LaunchedEffect(openChat.value) {
        openChat.value?.let { screen = Screen.Chat(it.chatId, it.otherUid, it.otherName); openChat.value = null }
    }
    BackHandler(enabled = screen !is Screen.Chats) { screen = Screen.Chats }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        when (val s = screen) {
            Screen.Chats -> ChatListScreen(
                me,
                onOpen = { screen = Screen.Chat(it.chatId, it.otherUid, it.otherName) },
                onNewChat = { screen = Screen.Contacts },
                onSignOut = onSignOut
            )
            Screen.Contacts -> ContactsScreen(me, onBack = { screen = Screen.Chats }) { u ->
                screen = Screen.Chat(Repo.chatId(me.uid, u.uid), u.uid, u.name)
            }
            is Screen.Chat -> ChatScreen(me, s.chatId, s.otherUid, s.otherName) { screen = Screen.Chats }
        }
    }
}

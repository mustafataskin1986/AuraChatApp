package com.aurachat.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import android.widget.Toast
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Message
import com.aurachat.app.data.OpenChat
import com.aurachat.app.ui.ContactPickerScreen
import com.aurachat.app.ui.ForwardScreen
import com.aurachat.app.ui.GroupInfoScreen
import com.aurachat.app.ui.StarredScreen
import com.aurachat.app.ui.SettingsScreen
import com.aurachat.app.ui.ProfileScreen
import com.aurachat.app.ui.PrivacyScreen
import com.aurachat.app.ui.ProfilePhotoScreen
import com.aurachat.app.ui.AboutScreen
import com.aurachat.app.ui.AppIcon
import com.aurachat.app.ui.AppIconScreen
import com.aurachat.app.ui.StatusScreen
import com.aurachat.app.ui.CallOverlay
import com.aurachat.app.ui.CallsScreen
import com.aurachat.app.ui.MainTabs
import com.aurachat.app.ui.rememberCallStarter
import com.aurachat.app.call.CallManager
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import com.aurachat.app.ui.AuraBg
import com.aurachat.app.ui.AuraGreen
import com.aurachat.app.ui.AuraTheme
import com.aurachat.app.ui.ChatListScreen
import com.aurachat.app.ui.ChatScreen
import com.aurachat.app.ui.ContactsScreen
import com.aurachat.app.ui.LoginScreen
import com.aurachat.app.ui.NameScreen
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val openChat = mutableStateOf<OpenChat?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        val t0 = android.os.SystemClock.uptimeMillis()
        // Görünmez splash: ilk liste hazır olana (en fazla 1,2 sn) kadar siyah ekran, logo yok
        splash.setKeepOnScreenCondition { !AppState.ready && android.os.SystemClock.uptimeMillis() - t0 < 1200 }
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        readIntent(intent)
        setContent { AuraTheme { AuraRoot(openChat) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        AppIcon.applyPending(this)
    }

    override fun onStart() { super.onStart(); AppState.foreground = true }
    override fun onStop() { super.onStop(); AppState.foreground = false }

    private fun readIntent(i: Intent?) {
        if (i?.getBooleanExtra("incomingCall", false) == true) {
            try {
                if (Build.VERSION.SDK_INT >= 27) {
                    setShowWhenLocked(true)
                    setTurnScreenOn(true)
                }
            } catch (e: Throwable) {}
        }
        val cid = i?.getStringExtra("chatId")
        if (!cid.isNullOrEmpty()) {
            openChat.value = OpenChat(cid, i?.getStringExtra("otherUid") ?: "", i?.getStringExtra("otherName") ?: "")
        }
    }
}

@Composable
private fun AuraRoot(openChat: MutableState<OpenChat?>) {
    val auth = remember { FirebaseAuth.getInstance() }
    var fbUser by remember { mutableStateOf(auth.currentUser) }
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener { fbUser = it.currentUser }
        auth.addAuthStateListener(l)
        onDispose { auth.removeAuthStateListener(l) }
    }

    val uid = fbUser?.uid
    var profile by remember(uid) { mutableStateOf<UserProfile?>(uid?.let { Repo.cachedProfile(it) }) }
    var loaded by remember(uid) { mutableStateOf(profile != null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(uid) {
        if (uid != null) {
            val fresh = try { Repo.loadProfile(uid) } catch (e: Exception) { null }
            if (fresh != null) profile = fresh
            loaded = true
        }
    }

    val p = profile
    when {
        uid == null -> { AppState.ready = true; LoginScreen() }
        !loaded -> Box(Modifier.fillMaxSize().background(AuraBg), Alignment.Center) { CircularProgressIndicator(color = AuraGreen) }
        p == null || p.name.isBlank() -> {
            AppState.ready = true
            NameScreen { name ->
                scope.launch { profile = Repo.saveName(uid, fbUser?.email ?: "", name) }
            }
        }
        else -> Home(p, openChat, onProfile = { profile = it }) { auth.signOut() }
    }
}

private sealed interface Screen {
    data object Chats : Screen
    data object Contacts : Screen
    data object NewGroup : Screen
    data object Starred : Screen
    data object Settings : Screen
    data object Profile : Screen
    data object Privacy : Screen
    data object AppIconPick : Screen
    data object Photo : Screen
    data class About(val backTo: Screen) : Screen
    data class Chat(val target: ChatTarget, val jumpTo: String? = null, val search: Boolean = false) : Screen
    data class GroupInfo(val target: ChatTarget) : Screen
    data class ContactInfo(val target: ChatTarget) : Screen
    data class SharedMedia(val target: ChatTarget, val backTo: Screen) : Screen
    data class ChatTheme(val target: ChatTarget) : Screen
    data class Forward(val from: ChatTarget, val msgs: List<Message>) : Screen
}

@Composable
private fun Home(me: UserProfile, openChat: MutableState<OpenChat?>, onProfile: (UserProfile) -> Unit, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf<Screen>(Screen.Chats) }
    val startCall = rememberCallStarter(me)
    LaunchedEffect(me) { CallManager.startWatching(me) }
    var tabPage by remember { mutableIntStateOf(0) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(me.uid) {
        Repo.registerPush(me.uid)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    // Çevrimiçi / son görülme: uygulama açıkken 10 sn'de bir, kapanınca çevrimdışı
    val lifeOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    var visible by remember { mutableStateOf(lifeOwner.lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)) }
    DisposableEffect(lifeOwner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_START) visible = true
            if (e == androidx.lifecycle.Lifecycle.Event.ON_STOP) visible = false
        }
        lifeOwner.lifecycle.addObserver(obs)
        onDispose { lifeOwner.lifecycle.removeObserver(obs) }
    }
    LaunchedEffect(me.uid) { Repo.syncPresenceHidden(me.uid) }
    LaunchedEffect(me.uid, visible) {
        if (visible) {
            while (true) {
                Repo.writePresence(me.uid, true)
                kotlinx.coroutines.delay(10000)
            }
        } else {
            Repo.writePresence(me.uid, false)
        }
    }
    // Bildirime dokununca doğrudan sohbet (birebir ya da grup) açılır
    LaunchedEffect(openChat.value) {
        openChat.value?.let {
            screen = Screen.Chat(Repo.targetFor(me.uid, it.chatId, it.otherName))
            openChat.value = null
        }
    }
    BackHandler(enabled = screen !is Screen.Chats) {
        screen = when (val s = screen) {
            is Screen.GroupInfo -> Screen.Chat(s.target)
            is Screen.ContactInfo -> Screen.Chat(s.target)
            is Screen.SharedMedia -> s.backTo
            is Screen.ChatTheme -> Screen.Chat(s.target)
            is Screen.Forward -> Screen.Chat(s.from)
            Screen.NewGroup -> Screen.Contacts
            Screen.Profile -> Screen.Settings
            Screen.Privacy -> Screen.Settings
            Screen.AppIconPick -> Screen.Settings
            Screen.Photo -> Screen.Profile
            is Screen.About -> s.backTo
            else -> Screen.Chats
        }
    }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        when (val s = screen) {
            Screen.Chats -> MainTabs(
                page = tabPage,
                onPageChanged = { tabPage = it },
                chats = {
                    ChatListScreen(
                        me,
                        onOpen = { screen = Screen.Chat(ChatTarget(it.chatId, it.isGroup, it.otherUid, it.name)) },
                        onNewChat = { screen = Screen.Contacts },
                        onNewGroup = { screen = Screen.NewGroup },
                        onStarred = { screen = Screen.Starred },
                        onSettings = { screen = Screen.Settings },
                        onSignOut = onSignOut,
                        tabIsActive = tabPage == 0
                    )
                },
                status = { setFullscreen ->
                    StatusScreen(me, onFullscreen = setFullscreen, onMessage = { screen = Screen.Chat(it) })
                },
                contacts = {
                    ContactsScreen(me, onBack = {}, onNewGroup = { screen = Screen.NewGroup }, tab = true) { u ->
                        screen = Screen.Chat(ChatTarget(Repo.chatId(me.uid, u.uid), false, u.uid, u.name))
                    }
                },
                calls = {
                    CallsScreen(
                        me,
                        onOpenChat = { screen = Screen.Chat(it) },
                        onCall = { t, v -> startCall(t, v) }
                    )
                }
            )
            Screen.AppIconPick -> AppIconScreen(onBack = { screen = Screen.Settings })
            Screen.Contacts -> ContactsScreen(
                me,
                onBack = { screen = Screen.Chats },
                onNewGroup = { screen = Screen.NewGroup }
            ) { u ->
                screen = Screen.Chat(ChatTarget(Repo.chatId(me.uid, u.uid), false, u.uid, u.name))
            }
            Screen.NewGroup -> ContactPickerScreen(
                me = me, title = "Yeni grup", exclude = emptySet(), requireName = true,
                onBack = { screen = Screen.Contacts }
            ) { picked, name ->
                scope.launch {
                    try {
                        val id = Repo.createGroup(me, name, picked.map { it.uid })
                        screen = Screen.Chat(ChatTarget(id, true, id, name))
                    } catch (e: Throwable) {
                        Toast.makeText(ctx, "Grup oluşturulamadı", Toast.LENGTH_SHORT).show()
                        screen = Screen.Chats
                    }
                }
            }
            Screen.Settings -> SettingsScreen(
                me,
                onBack = { screen = Screen.Chats },
                onOpenProfile = { screen = Screen.Profile },
                onOpenAbout = { screen = Screen.About(Screen.Settings) },
                onOpenPrivacy = { screen = Screen.Privacy },
                onOpenAppIcon = { screen = Screen.AppIconPick }
            )
            Screen.Profile -> ProfileScreen(
                me, onProfile,
                onBack = { screen = Screen.Settings },
                onOpenPhoto = { screen = Screen.Photo },
                onOpenAbout = { screen = Screen.About(Screen.Profile) },
                onSignOut = onSignOut
            )
            Screen.Privacy -> PrivacyScreen(me, onBack = { screen = Screen.Settings })
            Screen.Photo -> ProfilePhotoScreen(me, onProfile, onBack = { screen = Screen.Profile })
            is Screen.About -> AboutScreen(me, onProfile, onBack = { screen = s.backTo })
            Screen.Starred -> StarredScreen(me, onBack = { screen = Screen.Chats }) { item ->
                screen = Screen.Chat(Repo.targetFor(me.uid, item.chatId, item.chatName), item.msgId)
            }
            is Screen.Chat -> ChatScreen(
                me = me,
                target = s.target,
                onBack = { screen = Screen.Chats },
                onOpenGroupInfo = { screen = if (s.target.isGroup) Screen.GroupInfo(s.target) else Screen.ContactInfo(s.target) },
                onForward = { msgs -> screen = Screen.Forward(s.target, msgs) },
                onCall = { v -> startCall(s.target, v) },
                onOpenTheme = { screen = Screen.ChatTheme(s.target) },
                jumpToMsgId = s.jumpTo,
                startSearch = s.search
            )
            is Screen.ChatTheme -> com.aurachat.app.ui.ChatThemeScreen(s.target.chatId, onBack = { screen = Screen.Chat(s.target) })
            is Screen.SharedMedia -> com.aurachat.app.ui.SharedMediaScreen(me, s.target) { screen = s.backTo }
            is Screen.ContactInfo -> com.aurachat.app.ui.ContactInfoScreen(
                me = me,
                target = s.target,
                onBack = { screen = Screen.Chat(s.target) },
                onMessage = { screen = Screen.Chat(s.target) },
                onSearch = { screen = Screen.Chat(s.target, null, true) },
                onMedia = { screen = Screen.SharedMedia(s.target, s) },
                onStarred = { screen = Screen.Starred },
                onCall = { v -> startCall(s.target, v) },
                onTheme = { screen = Screen.ChatTheme(s.target) }
            )
            is Screen.GroupInfo -> GroupInfoScreen(
                me = me,
                groupId = s.target.chatId,
                onBack = { screen = Screen.Chat(s.target) },
                onLeft = { screen = Screen.Chats }
            )
            is Screen.Forward -> ForwardScreen(me, s.msgs.size, onBack = { screen = Screen.Chat(s.from) }) { to ->
                scope.launch {
                    try {
                        s.msgs.forEach { Repo.forward(me, to, it) }
                    } catch (e: Throwable) {
                        Toast.makeText(ctx, "İletilemedi", Toast.LENGTH_SHORT).show()
                    }
                }
                screen = Screen.Chat(to)
            }
        }
        CallOverlay()
    }
}

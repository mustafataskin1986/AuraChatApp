package com.aurachat.app

import android.Manifest
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.withContext
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import android.widget.Toast
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Message
import com.aurachat.app.data.OpenChat
import com.aurachat.app.ui.ContactPickerScreen
import com.aurachat.app.ui.ForwardScreen
import com.aurachat.app.ui.GroupInfoScreen
import com.aurachat.app.ui.StarredScreen
import com.aurachat.app.ui.SettingsScreen
import com.aurachat.app.ui.ProfileScreen
import com.aurachat.app.ui.PrivacyScreen
import com.aurachat.app.ui.ProfilePhotoScreen
import com.aurachat.app.ui.AboutScreen
import com.aurachat.app.ui.AppIcon
import com.aurachat.app.ui.AppIconScreen
import com.aurachat.app.ui.StatusScreen
import com.aurachat.app.ui.CallOverlay
import com.aurachat.app.ui.CallsScreen
import com.aurachat.app.ui.MainTabs
import com.aurachat.app.ui.rememberCallStarter
import com.aurachat.app.call.CallManager
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import com.aurachat.app.ui.AuraBg
import com.aurachat.app.ui.AuraGreen
import com.aurachat.app.ui.AuraTheme
import com.aurachat.app.ui.ChatListScreen
import com.aurachat.app.ui.ChatScreen
import com.aurachat.app.ui.ContactsScreen
import com.aurachat.app.ui.LoginScreen
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope

class MainActivity : ComponentActivity() {
    private val openChat = mutableStateOf<OpenChat?>(null)

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        // Android sistem teması (koyu/açık) değişince "Sistem" modu anında uygulansın
        com.aurachat.app.ui.AuraUi.systemDark = (newConfig.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) != android.content.res.Configuration.UI_MODE_NIGHT_NO
    }

    override fun onResume() {
        super.onResume()
        com.aurachat.app.ui.AuraUi.systemDark = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) != android.content.res.Configuration.UI_MODE_NIGHT_NO
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        val t0 = android.os.SystemClock.uptimeMillis()
        // Görünmez splash: ilk liste hazır olana (en fazla 1,2 sn) kadar siyah ekran, logo yok
        splash.setKeepOnScreenCondition { !AppState.ready && android.os.SystemClock.uptimeMillis() - t0 < 1200 }
        super.onCreate(savedInstanceState)
        // Açılışta pencere zemini uygulamanın seçili temasına göre (açık: beyaz, koyu: siyah); siyah kısa flaş olmasın
        com.aurachat.app.ui.AuraUi.load(this)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(if (com.aurachat.app.ui.AuraUi.lightReal) android.graphics.Color.WHITE else android.graphics.Color.BLACK))
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        readIntent(intent)
        if (lockOn() && intent?.getBooleanExtra("incomingCall", false) != true) AppState.locked.value = true
        setContent(parent = appRecomposer()) { AuraTheme { Box(Modifier.fillMaxSize()) { AuraRoot(openChat); com.aurachat.app.ui.ViewerOverlayHost(); com.aurachat.app.ui.LockOverlay(); com.aurachat.app.ui.UpdateOverlay(); com.aurachat.app.ui.AdminBannerOverlay(); com.aurachat.app.ui.UpdateProgressBar(); com.aurachat.app.ui.ColorProbeOverlay() } } }
    }

    /** Sistem animasyon ölçeğini (kapalı/1x) yok sayar: uygulama animasyonları her zaman 0.5x süreyle çalışır */
    @OptIn(androidx.compose.ui.InternalComposeUiApi::class)
    private fun appRecomposer(): androidx.compose.runtime.Recomposer {
        val scale = object : androidx.compose.ui.MotionDurationScale {
            override val scaleFactor: Float = 0.5f
        }
        val ctx = androidx.compose.ui.platform.AndroidUiDispatcher.CurrentThread + scale
        val rec = androidx.compose.runtime.Recomposer(ctx)
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        var pending = false
        androidx.compose.runtime.snapshots.Snapshot.registerGlobalWriteObserver {
            if (!pending) {
                pending = true
                handler.post { pending = false; androidx.compose.runtime.snapshots.Snapshot.sendApplyNotifications() }
            }
        }
        lifecycleScope.launch(ctx) { rec.runRecomposeAndApplyChanges() }
        return rec
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    private fun lockOn() = getSharedPreferences("aura", MODE_PRIVATE).getBoolean("applock", false)

    override fun onStart() {
        super.onStart()
        AppState.foreground = true
        if (lockOn() && AppState.leftAt > 0L && System.currentTimeMillis() - AppState.leftAt > 30_000L &&
            intent?.getBooleanExtra("incomingCall", false) != true) AppState.locked.value = true
    }
    override fun onStop() { super.onStop(); AppState.foreground = false; AppState.leftAt = System.currentTimeMillis() }

    private fun readIntent(i: Intent?) {
        if (i?.getBooleanExtra("openErrors", false) == true) {
            i.removeExtra("openErrors")
            if (com.aurachat.app.ui.isAdminAccount()) AppState.showErrors.value = true
        }
        if (i?.getBooleanExtra("installUpdate", false) == true) {
            i.removeExtra("installUpdate")
            com.aurachat.app.ui.Updater.installFromNotification(this)
        }
        if (i?.getBooleanExtra("incomingCall", false) == true) {
            AppState.callWait.longValue = android.os.SystemClock.uptimeMillis()
            try {
                if (Build.VERSION.SDK_INT >= 27) {
                    setShowWhenLocked(true)
                    setTurnScreenOn(true)
                }
            } catch (e: Throwable) { com.aurachat.app.AuraLog.e("MainActivity", e) }
        }
        if (i?.action == Intent.ACTION_SEND || i?.action == Intent.ACTION_SEND_MULTIPLE) {
            try {
                val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: ""
                val uris = ArrayList<android.net.Uri>()
                if (i.action == Intent.ACTION_SEND) {
                    (if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, android.net.Uri::class.java)
                    else @Suppress("DEPRECATION") i.getParcelableExtra<android.net.Uri>(Intent.EXTRA_STREAM))?.let { uris.add(it) }
                } else {
                    (if (Build.VERSION.SDK_INT >= 33) i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, android.net.Uri::class.java)
                    else @Suppress("DEPRECATION") i.getParcelableArrayListExtra<android.net.Uri>(Intent.EXTRA_STREAM))?.let { uris.addAll(it) }
                }
                val sid = i.getStringExtra("android.intent.extra.shortcut.ID") ?: ""
                val direct = if (sid.startsWith("chat_")) sid.removePrefix("chat_") else ""
                if (text.isNotBlank() || uris.isNotEmpty()) AppState.sharedIn.value = SharedIn(text, uris.take(10), direct)
            } catch (e: Throwable) { com.aurachat.app.AuraLog.e("MainActivity", e) }
        }
        val cid = i?.getStringExtra("chatId")
        if (!cid.isNullOrEmpty()) {
            openChat.value = OpenChat(cid, i?.getStringExtra("otherUid") ?: "", i?.getStringExtra("otherName") ?: "")
        }
    }
}

@Composable
private fun AuraRoot(openChat: MutableState<OpenChat?>) {
    val auth = remember { FirebaseAuth.getInstance() }
    var fbUser by remember { mutableStateOf(auth.currentUser) }
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener { fbUser = it.currentUser }
        auth.addAuthStateListener(l)
        onDispose { auth.removeAuthStateListener(l) }
    }

    val uid = fbUser?.uid
    var profile by remember(uid) { mutableStateOf<UserProfile?>(uid?.let { Repo.cachedProfile(it) }) }
    androidx.compose.runtime.DisposableEffect(uid) { AppState.profileSetter = { profile = it }; onDispose { AppState.profileSetter = null } }
    var loaded by remember(uid) { mutableStateOf(profile != null) }
    val scope = rememberCoroutineScope()
    var verifyTick by remember { mutableIntStateOf(0) }

    LaunchedEffect(uid) {
        if (uid != null) {
            val fresh = try { Repo.loadProfile(uid) } catch (e: Exception) { null }
            if (fresh != null) profile = fresh
            loaded = true
        }
    }

    val p = profile
    when {
        uid == null -> { AppState.ready = true; LoginScreen() }
        !loaded -> Box(Modifier.fillMaxSize().background(AuraBg), Alignment.Center) { CircularProgressIndicator(color = AuraGreen) }
        fbUser != null && verifyTick >= 0 && fbUser!!.providerData.any { it.providerId == "password" } && !fbUser!!.isEmailVerified -> {
            AppState.ready = true
            com.aurachat.app.ui.VerifyEmailScreen(
                email = fbUser?.email ?: "",
                onVerified = { verifyTick++ },
                onBack = { auth.currentUser?.delete()?.addOnCompleteListener { auth.signOut() } ?: auth.signOut() }
            )
        }
        p == null || p.name.isBlank() || p.phone.isBlank() -> {
            AppState.ready = true
            com.aurachat.app.ui.ProfileSetupScreen(fbUser?.email ?: "") { name, phone10, avatar ->
                try {
                    profile = Repo.createProfile(uid, fbUser?.email ?: "", name, phone10, avatar)
                    null
                } catch (e: IllegalStateException) {
                    if (e.message == "PHONE_TAKEN") "Bu telefon numarası başka bir hesaba tanımlı." else "Kaydedilemedi"
                } catch (e: Throwable) { "Kaydedilemedi, tekrar dene." }
            }
        }
        else -> Home(p, openChat, onProfile = { profile = it }) { auth.signOut() }
    }
}

private sealed interface Screen {
    data object Chats : Screen
    data object Contacts : Screen
    data object NewGroup : Screen
    data object Starred : Screen
    data object Settings : Screen
    data object Profile : Screen
    data object Privacy : Screen
    data object AppIconPick : Screen
    data object Backup : Screen
    data object Admin : Screen
    data object Storage : Screen
    data object Qr : Screen
    data object Photo : Screen
    data class About(val backTo: Screen) : Screen
    data class Chat(val target: ChatTarget, val jumpTo: String? = null, val search: Boolean = false, val fromStarred: Boolean = false) : Screen
    data class GroupInfo(val target: ChatTarget) : Screen
    data class ContactInfo(val target: ChatTarget) : Screen
    data object MyStatus : Screen
    data class CallInfo(val uid: String, val name: String, val ids: List<String>) : Screen
    data class SharedMedia(val target: ChatTarget, val backTo: Screen) : Screen
    data class ChatTheme(val target: ChatTarget) : Screen
    data class Forward(val from: ChatTarget, val msgs: List<Message>, val toStarred: Boolean = false) : Screen
    data class ShareTo(val data: SharedIn) : Screen
    data class StatusText(val text: String) : Screen
}

@Composable
private fun Home(me: UserProfile, openChat: MutableState<OpenChat?>, onProfile: (UserProfile) -> Unit, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf<Screen>(Screen.Chats) }
    if (AppState.showErrors.value) com.aurachat.app.ui.ErrorLogDialog { AppState.showErrors.value = false }
    val startCall = rememberCallStarter(me)
    var showDeleteAcc by remember { mutableStateOf(false) }
    if (showDeleteAcc) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDeleteAcc = false },
            containerColor = com.aurachat.app.ui.AuraSurface,
            title = { androidx.compose.material3.Text("Hesap silinsin mi?", color = androidx.compose.ui.graphics.Color.White) },
            text = { androidx.compose.material3.Text("Profilin, sohbet listen ve yıldızlı mesajların kalıcı olarak silinir. Bu işlem geri alınamaz.", color = com.aurachat.app.ui.AuraMuted) },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    showDeleteAcc = false
                    scope.launch {
                        val err = try { Repo.deleteAccount(me.uid) } catch (e: Throwable) { "Hesap silinemedi" }
                        when (err) {
                            null -> { Toast.makeText(ctx, "Hesabın silindi", Toast.LENGTH_SHORT).show(); FirebaseAuth.getInstance().signOut() }
                            "RELOGIN" -> Toast.makeText(ctx, "Güvenlik için çıkış yapıp tekrar giriş yap, hemen ardından hesabı sil", Toast.LENGTH_LONG).show()
                            else -> Toast.makeText(ctx, err, Toast.LENGTH_LONG).show()
                        }
                    }
                }) { androidx.compose.material3.Text("Sil", color = androidx.compose.ui.graphics.Color(0xFFEF4444)) }
            },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { showDeleteAcc = false }) { androidx.compose.material3.Text("Vazgeç", color = AuraGreen) } }
        )
    }
    suspend fun runShare(sh: SharedIn, to: ChatTarget) {
        try {
            val imgUris = sh.uris.filter { (ctx.contentResolver.getType(it) ?: "").startsWith("image/") }
            val vidUris = sh.uris.filter { (ctx.contentResolver.getType(it) ?: "").startsWith("video/") }
            val docUris = sh.uris - imgUris.toSet() - vidUris.toSet()
            for (u in vidUris) {
                val v = withContext(kotlinx.coroutines.Dispatchers.IO) { com.aurachat.app.data.Media.readVideo(ctx, u) }
                if (v == null) Toast.makeText(ctx, "Video çok büyük (en fazla 640 KB)", Toast.LENGTH_LONG).show()
                else Repo.sendVideo(me, to, v, null)
            }
            if (imgUris.isNotEmpty()) {
                val imgs = withContext(kotlinx.coroutines.Dispatchers.IO) {
                    imgUris.mapNotNull { u -> com.aurachat.app.data.Media.compress(ctx, u, 700 * 1024) }
                }
                if (imgs.isNotEmpty()) Repo.sendImages(me, to, imgs, sh.text, null)
            } else if (docUris.isEmpty() && vidUris.isEmpty() && sh.text.isNotBlank()) {
                Repo.sendText(me, to, sh.text, null)
            }
            for (u in docUris) {
                val f = withContext(kotlinx.coroutines.Dispatchers.IO) { com.aurachat.app.data.Media.readDocument(ctx, u) }
                if (f == null) Toast.makeText(ctx, "Belge okunamadı ya da 700 KB'tan büyük", Toast.LENGTH_SHORT).show()
                else Repo.sendDocument(me, to, f.name, f.mime, f.dataUrl, null)
            }
        } catch (e: Throwable) {
            Toast.makeText(ctx, "Paylaşılamadı", Toast.LENGTH_SHORT).show()
        }
    }
    LaunchedEffect(me) { CallManager.startWatching(me) }
    var tabPage by remember { mutableIntStateOf(0) }
    // Alt çubuk rozetleri: okunmamış sohbet sayısı, yeni durum noktası, cevapsız arama sayısı
    val navChats by remember(me.uid) { Repo.chatsFlow(me.uid) }.collectAsState(emptyList())
    val navStatuses by remember { Repo.statusesFlow() }.collectAsState(emptyList())
    val navCalls by remember(me.uid) { Repo.callsFlow(me.uid) }.collectAsState(emptyList())
    val callsPrefs = remember { ctx.getSharedPreferences("navbadge", Context.MODE_PRIVATE) }
    var callsSeenAt by remember { mutableStateOf(callsPrefs.getLong("calls_seen_at", 0L)) }
    LaunchedEffect(tabPage, navCalls.size) {
        if (tabPage == 3) { callsSeenAt = System.currentTimeMillis(); callsPrefs.edit().putLong("calls_seen_at", callsSeenAt).apply() }
    }
    val navBadges = listOf(
        navChats.count { it.unread > 0 && !it.muted },
        if (navStatuses.any { it.uid != me.uid && it.expiresAt > System.currentTimeMillis() && !it.viewers.contains(me.uid) }) -1 else 0,
        0,
        navCalls.count { it.result == "missed" && it.direction == "in" && it.at > callsSeenAt }
    )

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(me.uid) {
        Repo.registerPush(me.uid)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    // Çevrimiçi / son görülme: uygulama açıkken 10 sn'de bir, kapanınca çevrimdışı
    val lifeOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    var visible by remember { mutableStateOf(lifeOwner.lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)) }
    DisposableEffect(lifeOwner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_START) visible = true
            if (e == androidx.lifecycle.Lifecycle.Event.ON_STOP) visible = false
        }
        lifeOwner.lifecycle.addObserver(obs)
        onDispose { lifeOwner.lifecycle.removeObserver(obs) }
    }
    LaunchedEffect(me.uid) { Repo.syncPresenceHidden(me.uid) }
    LaunchedEffect(me.uid, visible) {
        if (visible) {
            while (true) {
                Repo.writePresence(me.uid, true)
                kotlinx.coroutines.delay(10000)
            }
        } else {
            Repo.writePresence(me.uid, false)
        }
    }
    // Bildirime dokununca doğrudan sohbet (birebir ya da grup) açılır
    LaunchedEffect(openChat.value) {
        openChat.value?.let {
            val cur = screen
            if (cur is Screen.Chat && cur.target.chatId == it.chatId) AppState.chatPing.intValue++
            else screen = Screen.Chat(Repo.targetFor(me.uid, it.chatId, it.otherName))
            openChat.value = null
        }
    }
    val shared = AppState.sharedIn.value
    LaunchedEffect(shared) {
        if (shared != null) {
            AppState.sharedIn.value = null
            if (shared.shortcutChatId.isNotEmpty()) {
                val cs = Repo.cachedChats(me.uid)?.firstOrNull { it.chatId == shared.shortcutChatId }
                val to = Repo.targetFor(me.uid, shared.shortcutChatId, cs?.name ?: "")
                scope.launch { runShare(shared, to) }
                screen = Screen.Chat(to)
            } else screen = Screen.ShareTo(shared)
        }
    }
    BackHandler(enabled = screen !is Screen.Chats) {
        screen = when (val s = screen) {
            is Screen.GroupInfo -> Screen.Chat(s.target)
            is Screen.ContactInfo -> Screen.Chat(s.target)
            is Screen.SharedMedia -> s.backTo
            is Screen.ChatTheme -> Screen.Chat(s.target)
            is Screen.Forward -> if (s.toStarred) Screen.Starred else Screen.Chat(s.from)
            is Screen.Chat -> if (s.fromStarred) Screen.Starred else Screen.Chats
            is Screen.ShareTo -> Screen.Chats
            is Screen.StatusText -> Screen.Chats
            Screen.NewGroup -> Screen.Contacts
            Screen.Profile -> Screen.Settings
            Screen.Privacy -> Screen.Settings
            Screen.AppIconPick -> Screen.Settings
            Screen.Backup -> Screen.Settings
            Screen.Storage -> Screen.Settings
            Screen.Qr -> Screen.Settings
            Screen.Photo -> Screen.Profile
            is Screen.About -> s.backTo
            else -> Screen.Chats
        }
    }

    Box(Modifier.fillMaxSize().background(AuraBg)) {
        com.aurachat.app.ui.AuraLightLayer(Modifier.fillMaxSize()) {
        when (val s = screen) {
            Screen.Chats -> MainTabs(
                page = tabPage,
                badges = navBadges,
                onPageChanged = { tabPage = it },
                chats = {
                    ChatListScreen(
                        me,
                        onOpen = { screen = Screen.Chat(ChatTarget(it.chatId, it.isGroup, it.otherUid, it.name)) },
                        onOpenMsg = { c0, mid -> screen = Screen.Chat(ChatTarget(c0.chatId, c0.isGroup, c0.otherUid, c0.name), mid) },
                        onForwardMsg = { c0, m -> val msgs = com.aurachat.app.ui.fwdCheck(ctx, listOf(m)); if (msgs.isNotEmpty()) screen = Screen.Forward(ChatTarget(c0.chatId, c0.isGroup, c0.otherUid, c0.name), msgs) },
                        onEditedImg = { c0, d -> com.aurachat.app.ui.ViewerBridge.put(c0.chatId, d); screen = Screen.Chat(ChatTarget(c0.chatId, c0.isGroup, c0.otherUid, c0.name)) },
                        onNewChat = { screen = Screen.Contacts },
                        onNewGroup = { screen = Screen.NewGroup },
                        onStarred = { screen = Screen.Starred },
                        onAdmin = { screen = Screen.Admin },
                        onSettings = { screen = Screen.Settings },
                        onSignOut = onSignOut,
                        tabIsActive = tabPage == 0,
                        onInfo = {
                            val t = ChatTarget(it.chatId, it.isGroup, it.otherUid, it.name)
                            screen = if (it.isGroup) Screen.GroupInfo(t) else Screen.ContactInfo(t)
                        },
                        onCall = { c, v -> startCall(ChatTarget(c.chatId, c.isGroup, c.otherUid, c.name), v) }
                    )
                },
                status = { setFullscreen ->
                    StatusScreen(
                        me, onFullscreen = setFullscreen, onMessage = { screen = Screen.Chat(it) },
                        onCall = { t, v -> startCall(t, v) },
                        onProfile = { screen = Screen.ContactInfo(it) }
                    )
                },
                contacts = {
                    ContactsScreen(
                        me, onBack = {}, onNewGroup = { screen = Screen.NewGroup }, tab = true,
                        onCall = { u, v -> startCall(ChatTarget(Repo.chatId(me.uid, u.uid), false, u.uid, u.name), v) },
                        onInfo = { u -> screen = Screen.ContactInfo(ChatTarget(Repo.chatId(me.uid, u.uid), false, u.uid, u.name)) }
                    ) { u ->
                        screen = Screen.Chat(ChatTarget(Repo.chatId(me.uid, u.uid), false, u.uid, u.name))
                    }
                },
                calls = {
                    CallsScreen(
                        me,
                        onOpenChat = { screen = Screen.Chat(it) },
                        onCall = { t, v -> startCall(t, v) },
                        onInfo = { u, n, ids -> screen = Screen.CallInfo(u, n, ids) },
                        onContactInfo = { screen = Screen.ContactInfo(it) }
                    )
                }
            )
            is Screen.CallInfo -> {
                val t = ChatTarget(Repo.chatId(me.uid, s.uid), false, s.uid, s.name)
                com.aurachat.app.ui.CallInfoScreen(
                    me, s.uid, s.name, s.ids,
                    onBack = { screen = Screen.Chats },
                    onMessage = { screen = Screen.Chat(t) },
                    onCall = { v -> startCall(t, v) },
                    onInfo = { screen = Screen.ContactInfo(t) }
                )
            }
            Screen.AppIconPick -> AppIconScreen(onBack = { screen = Screen.Settings })
            Screen.Backup -> com.aurachat.app.ui.BackupScreen(me, onBack = { screen = Screen.Settings })
            Screen.Storage -> com.aurachat.app.ui.StorageScreen(onBack = { screen = Screen.Settings })
            Screen.Contacts -> ContactsScreen(
                me,
                onBack = { screen = Screen.Chats },
                onNewGroup = { screen = Screen.NewGroup },
                onCall = { u, v -> startCall(ChatTarget(Repo.chatId(me.uid, u.uid), false, u.uid, u.name), v) },
                onInfo = { u -> screen = Screen.ContactInfo(ChatTarget(Repo.chatId(me.uid, u.uid), false, u.uid, u.name)) }
            ) { u ->
                screen = Screen.Chat(ChatTarget(Repo.chatId(me.uid, u.uid), false, u.uid, u.name))
            }
            Screen.NewGroup -> ContactPickerScreen(
                me = me, title = "Yeni grup", exclude = emptySet(), requireName = true,
                onBack = { screen = Screen.Contacts }
            ) { picked, name ->
                scope.launch {
                    try {
                        val id = Repo.createGroup(me, name, picked.map { it.uid })
                        screen = Screen.Chat(ChatTarget(id, true, id, name))
                    } catch (e: Throwable) {
                        Toast.makeText(ctx, "Grup oluşturulamadı", Toast.LENGTH_SHORT).show()
                        screen = Screen.Chats
                    }
                }
            }
            Screen.Settings -> SettingsScreen(
                me,
                onBack = { screen = Screen.Chats },
                onOpenProfile = { screen = Screen.Profile },
                onOpenAbout = { screen = Screen.About(Screen.Settings) },
                onOpenPrivacy = { screen = Screen.Privacy },
                onOpenAppIcon = { screen = Screen.AppIconPick },
                onOpenBackup = { screen = Screen.Backup },
                onOpenStorage = { screen = Screen.Storage },
                onOpenQr = { screen = Screen.Qr },
                onDeleteAccount = { showDeleteAcc = true }
            )
            Screen.Qr -> com.aurachat.app.ui.QrScreen(me, onBack = { screen = Screen.Settings }, onOpenChat = { screen = Screen.Chat(it) })
            Screen.Profile -> ProfileScreen(
                me, onProfile,
                onBack = { screen = Screen.Settings },
                onOpenPhoto = { screen = Screen.Photo },
                onOpenAbout = { screen = Screen.About(Screen.Profile) },
                onSignOut = onSignOut
            )
            Screen.Privacy -> PrivacyScreen(me, onBack = { screen = Screen.Settings })
            Screen.Photo -> ProfilePhotoScreen(me, onProfile, onBack = { screen = Screen.Profile })
            is Screen.About -> AboutScreen(me, onProfile, onBack = { screen = s.backTo })
            Screen.Admin -> com.aurachat.app.ui.AdminPanelScreen(onBack = { screen = Screen.Chats })
            Screen.Starred -> StarredScreen(
                me, onBack = { screen = Screen.Chats },
                onForward = { msgs0 ->
                    val msgs = com.aurachat.app.ui.fwdCheck(ctx, msgs0)
                    val f = Repo.targetFor(me.uid, "", "")
                    if (msgs.isNotEmpty()) screen = Screen.Forward(f, msgs, true)
                }
            ) { item ->
                screen = Screen.Chat(Repo.targetFor(me.uid, item.chatId, item.chatName), item.msgId, false, true)
            }
            is Screen.Chat -> com.aurachat.app.ui.ChatLockGate(s.target.chatId, onDenied = { screen = Screen.Chats }) { ChatScreen(
                me = me,
                target = s.target,
                onBack = { screen = if (s.fromStarred) Screen.Starred else Screen.Chats },
                onOpenGroupInfo = { screen = if (s.target.isGroup) Screen.GroupInfo(s.target) else Screen.ContactInfo(s.target) },
                onForward = { msgs0 -> val msgs = com.aurachat.app.ui.fwdCheck(ctx, msgs0); if (msgs.isNotEmpty()) screen = Screen.Forward(s.target, msgs) },
                onCall = { v -> startCall(s.target, v) },
                onOpenTheme = { screen = Screen.ChatTheme(s.target) },
                onNewGroup = { screen = Screen.NewGroup },
                onOpenMedia = { screen = Screen.SharedMedia(s.target, Screen.Chat(s.target)) },
                jumpToMsgId = s.jumpTo,
                startSearch = s.search,
                onMemberChat = { u -> screen = Screen.Chat(ChatTarget(Repo.chatId(me.uid, u.uid), false, u.uid, u.name)) },
                onMemberCall = { u, v -> startCall(ChatTarget(Repo.chatId(me.uid, u.uid), false, u.uid, u.name), v) }
            ) }
            is Screen.ChatTheme -> com.aurachat.app.ui.ChatThemeScreen(s.target.chatId, onBack = { screen = Screen.Chat(s.target) })
            is Screen.SharedMedia -> com.aurachat.app.ui.SharedMediaScreen(
                me, s.target,
                onForward = { msgs0 -> val msgs = com.aurachat.app.ui.fwdCheck(ctx, msgs0); if (msgs.isNotEmpty()) screen = Screen.Forward(s.target, msgs) },
                onShowInChat = { msg -> screen = Screen.Chat(s.target, msg.id) },
                onEdited = { d -> com.aurachat.app.ui.ViewerBridge.put(s.target.chatId, d); screen = Screen.Chat(s.target) }
            ) { screen = s.backTo }
            is Screen.ContactInfo -> com.aurachat.app.ui.ContactInfoScreen(
                me = me,
                target = s.target,
                onBack = { screen = Screen.Chat(s.target) },
                onMessage = { screen = Screen.Chat(s.target) },
                onSearch = { screen = Screen.Chat(s.target, null, true) },
                onMedia = { screen = Screen.SharedMedia(s.target, s) },
                onStarred = { screen = Screen.Starred },
                onCall = { v -> startCall(s.target, v) },
                onTheme = { screen = Screen.ChatTheme(s.target) },
                onForward = { msgs0 -> val msgs = com.aurachat.app.ui.fwdCheck(ctx, msgs0); if (msgs.isNotEmpty()) screen = Screen.Forward(s.target, msgs) },
                onShowInChat = { msg -> screen = Screen.Chat(s.target, msg.id) },
                onEdited = { d -> com.aurachat.app.ui.ViewerBridge.put(s.target.chatId, d); screen = Screen.Chat(s.target) }
            )
            is Screen.GroupInfo -> GroupInfoScreen(
                me = me,
                target = s.target,
                onBack = { screen = Screen.Chat(s.target) },
                onLeft = { screen = Screen.Chats },
                onMessage = { screen = Screen.Chat(s.target) },
                onSearch = { screen = Screen.Chat(s.target, null, true) },
                onMedia = { screen = Screen.SharedMedia(s.target, s) },
                onStarred = { screen = Screen.Starred },
                onCall = { v -> startCall(s.target, v) },
                onTheme = { screen = Screen.ChatTheme(s.target) },
                onForward = { msgs0 -> val msgs = com.aurachat.app.ui.fwdCheck(ctx, msgs0); if (msgs.isNotEmpty()) screen = Screen.Forward(s.target, msgs) },
                onShowInChat = { msg -> screen = Screen.Chat(s.target, msg.id) },
                onEdited = { d -> com.aurachat.app.ui.ViewerBridge.put(s.target.chatId, d); screen = Screen.Chat(s.target) }
            )
            Screen.MyStatus -> com.aurachat.app.ui.UserStatusViewer(me, me.uid, onMessage = {}, onClose = { tabPage = 1; screen = Screen.Chats })
            is Screen.StatusText -> com.aurachat.app.ui.StatusTextComposerHost(me, s.text) { screen = Screen.Chats }
            is Screen.ShareTo -> {
                val sh = s.data
                val imgCount = sh.uris.count { (ctx.contentResolver.getType(it) ?: "").startsWith("image/") }
                val docCount = sh.uris.size - imgCount
                val summary = listOfNotNull(
                    if (imgCount > 0) "$imgCount resim" else null,
                    if (docCount > 0) "$docCount belge" else null,
                    if (sh.text.isNotBlank()) (if (sh.uris.isEmpty()) sh.text.take(40) else "metin") else null
                ).joinToString(" · ")
                com.aurachat.app.ui.ShareTargetScreen(me, summary, sh.uris, sh.text.isNotBlank(), onBack = { screen = Screen.Chats }, text = sh.text, onStatus = {
                    scope.launch {
                        try {
                            val imgUris = sh.uris.filter { (ctx.contentResolver.getType(it) ?: "").startsWith("image/") }
                            if (imgUris.isNotEmpty()) {
                                tabPage = 1   // geri dönünce Durum sekmesi açık olsun
                                for (u in imgUris.take(5)) {
                                    val d = withContext(kotlinx.coroutines.Dispatchers.IO) { com.aurachat.app.data.Media.compress(ctx, u, 300 * 1024) }
                                    if (d != null) Repo.postStatus(me, "image", "", "", sh.text.trim(), d)
                                }
                                Toast.makeText(ctx, "Durum paylaşıldı", Toast.LENGTH_SHORT).show()
                                screen = Screen.MyStatus   // paylaşılan durumu hemen göster
                            } else if (sh.text.isNotBlank()) {
                                // doğrudan paylaşmak yerine yazı durumu ekranı açılır (bağlantı önizleme kartıyla)
                                screen = Screen.StatusText(sh.text.trim())
                                return@launch
                            } else {
                                Toast.makeText(ctx, "Bu içerik durumda paylaşılamaz", Toast.LENGTH_SHORT).show()
                                screen = Screen.Chats
                            }
                        } catch (e: Throwable) { Toast.makeText(ctx, "Durum paylaşılamadı", Toast.LENGTH_SHORT).show(); screen = Screen.Chats }
                    }
                    // Not: yükleme bitene kadar paylaşım ekranı açık kalır; bitince doğrudan durum görüntüleyici açılır (arada durum sekmesi görünmez)
                }) { targets, caption ->
                    val sh2 = if (caption.isNotBlank()) sh.copy(text = caption) else sh
                    scope.launch { targets.forEach { runShare(sh2, it) } }
                    screen = if (targets.size == 1) Screen.Chat(targets[0]) else Screen.Chats
                    if (targets.size > 1) Toast.makeText(ctx, "Gönderiliyor…", Toast.LENGTH_SHORT).show()
                }
            }
            is Screen.Forward -> ForwardScreen(me, s.msgs.size, msgs = s.msgs, onStatus = {
                scope.launch {
                    try {
                        val imgs = s.msgs.filter { it.type == "image" }
                        if (imgs.isNotEmpty()) {
                            val datas = imgs.flatMap { m -> if (m.images.isNotEmpty()) m.images else listOf(m.imageUrl) }
                                .filter { it.isNotEmpty() && !it.startsWith("file:") }.take(5)
                            if (datas.isEmpty()) { Toast.makeText(ctx, "Bu içerik durumda paylaşılamaz", Toast.LENGTH_SHORT).show(); return@launch }
                            tabPage = 1
                            for (d in datas) Repo.postStatus(me, "image", "", "", imgs[0].text.trim(), d)
                            Toast.makeText(ctx, "Durum paylaşıldı", Toast.LENGTH_SHORT).show()
                            screen = Screen.MyStatus
                        } else {
                            val t0 = s.msgs.firstOrNull { it.text.isNotBlank() }?.text?.trim() ?: ""
                            if (t0.isNotEmpty()) screen = Screen.StatusText(t0)
                            else Toast.makeText(ctx, "Bu içerik durumda paylaşılamaz", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Throwable) { Toast.makeText(ctx, "Durum paylaşılamadı", Toast.LENGTH_SHORT).show() }
                }
            }, onBack = { screen = if (s.toStarred) Screen.Starred else Screen.Chat(s.from) }) { targets ->
                scope.launch {
                    try {
                        targets.forEach { to -> s.msgs.forEach { Repo.forward(me, to, it) } }
                    } catch (e: Throwable) {
                        Toast.makeText(ctx, "İletilemedi", Toast.LENGTH_SHORT).show()
                    }
                }
                screen = if (targets.size == 1) Screen.Chat(targets[0]) else Screen.Chats
            }
        }
        }
        run {
            val cs by com.aurachat.app.call.CallManager.ui.collectAsState()
            val waitAt = AppState.callWait.longValue
            var waiting by remember(waitAt) { mutableStateOf(waitAt > 0L) }
            LaunchedEffect(waitAt) { if (waitAt > 0L) { kotlinx.coroutines.delay(10_000L); waiting = false } }
            if (waiting && cs.phase == com.aurachat.app.call.Phase.IDLE) {
                Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color(0xFF0B141A)).clickable(enabled = false) {}, contentAlignment = Alignment.Center) {
                    androidx.compose.material3.Text("Gelen arama…", color = androidx.compose.ui.graphics.Color.White, fontSize = 18.sp)
                }
            }
        }
        CallOverlay()
        com.aurachat.app.ui.GroupCallOverlay(me)
        com.aurachat.app.ui.BackupOverlay()
    }
}

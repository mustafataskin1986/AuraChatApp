package com.aurachat.app.push

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.app.RemoteInput
import com.aurachat.app.data.Repo
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Bildirimdeki Cevapla / Okundu olarak işaretle / Sessize al düğmeleri (uygulama kapalıyken de çalışır) */
class NotifActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val chatId = i.getStringExtra("chatId") ?: return
        val action = i.action ?: return
        if (action == Notifs.ACT_CLEAR) { Notifs.forget(c, chatId); return }
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val reply = if (action == Notifs.ACT_REPLY)
            RemoteInput.getResultsFromIntent(i)?.getCharSequence(Notifs.KEY_REPLY)?.toString()?.trim() else null
        val app = c.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val name = Notifs.otherNameOf(app, chatId)
                val target = Repo.targetFor(uid, chatId, name)
                when (action) {
                    Notifs.ACT_REPLY -> {
                        if (!reply.isNullOrEmpty()) {
                            try {
                                val me = Repo.profileOf(uid)
                                Repo.sendText(me, target, reply, null)
                                Notifs.appendMine(app, chatId, reply)
                                try { Repo.markChatRead(uid, target) } catch (e: Throwable) {}
                            } catch (e: Throwable) {
                                Notifs.appendFailure(app, chatId)
                            }
                        }
                    }
                    Notifs.ACT_READ -> {
                        try { Repo.markChatRead(uid, target) } catch (e: Throwable) {}
                        Notifs.clear(app, chatId)
                    }
                    Notifs.ACT_MUTE -> {
                        Repo.setMuted(uid, chatId, true)
                        Notifs.clear(app, chatId)
                        withContext(Dispatchers.Main) { Toast.makeText(app, "Sohbet sessize alındı", Toast.LENGTH_SHORT).show() }
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }
}

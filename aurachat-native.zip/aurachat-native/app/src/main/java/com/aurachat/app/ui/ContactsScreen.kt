package com.aurachat.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Add
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactsScreen(me: UserProfile, onBack: () -> Unit, onNewGroup: () -> Unit, tab: Boolean = false, onPick: (UserProfile) -> Unit) {
    val users by remember(me.uid) { Repo.usersFlow(me.uid) }.collectAsState(Repo.cachedUsers())
    var q by remember { mutableStateOf("") }

    Scaffold(
        containerColor = AuraBg,
        contentWindowInsets = if (tab) androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0) else androidx.compose.material3.ScaffoldDefaults.contentWindowInsets,
        topBar = {
            if (tab) {
                Text(
                    "Kişiler", color = Color.White, fontSize = 22.sp,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 18.dp)
                )
            } else {
                TopAppBar(
                    title = { Text("Kişi seç") },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = AuraBg, titleContentColor = Color.White, navigationIconContentColor = Color.White),
                    navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") } }
                )
            }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(
                value = q, onValueChange = { q = it }, placeholder = { Text("Ara") },
                singleLine = true, modifier = Modifier.fillMaxWidth().padding(12.dp)
            )
            val list = users
            if (list == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = AuraGreen) }
            } else {
                val shown = list.filter { q.isBlank() || it.name.contains(q, ignoreCase = true) || it.phone.contains(q) }
                LazyColumn {
                    item(key = "new-group") {
                        Row(
                            Modifier.fillMaxWidth().clickable { onNewGroup() }.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(44.dp).clip(CircleShape).background(AuraBtn),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Default.Add, null, tint = Color.White) }
                            Spacer(Modifier.width(14.dp))
                            Text("Yeni grup", fontSize = 16.sp)
                        }
                    }
                    items(shown, key = { it.uid }) { u ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onPick(u) }.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(u.name, u.avatar, 44.dp)
                            Spacer(Modifier.width(14.dp))
                            Text(u.name, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }
}

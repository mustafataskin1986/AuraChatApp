package com.aurachat.app.ui

import androidx.compose.ui.graphics.compositeOver
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.focus.focusRequester
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Add
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactsScreen(me: UserProfile, onBack: () -> Unit, onNewGroup: () -> Unit, tab: Boolean = false, onCall: (UserProfile, Boolean) -> Unit = { _, _ -> }, onInfo: (UserProfile) -> Unit = {}, onOpenQr: () -> Unit = {}, onNewContact: () -> Unit = {}, onPick: (UserProfile) -> Unit) {
    val allUsers by remember(me.uid) { Repo.usersFlow(me.uid) }.collectAsState(Repo.cachedUsers())
    val dev by rememberDeviceContacts()
    val askPerm = rememberAskContacts()
    val ctxC = androidx.compose.ui.platform.LocalContext.current
    // WhatsApp gibi: yalnız telefon rehberindeki numaralarla eşleşen AuraChat kullanıcıları + AuraChat'te olmayanlar için davet
    val keys = remember(allUsers) { allUsers?.map { phoneKey(it.phone) }?.toSet() ?: emptySet() }
    val users = remember(allUsers, dev) {
        val d = dev
        if (allUsers == null) null else if (d == null) emptyList() else { val dk = d.map { phoneKey(it.phone) }.toSet(); allUsers!!.filter { phoneKey(it.phone) in dk } }
    }
    val invites = remember(dev, keys) { dev?.filter { phoneKey(it.phone) !in keys } ?: emptyList() }
    val noPerm = dev == null
    var q by remember { mutableStateOf("") }
    if (!tab) {
        PickContactPage(users, onBack, onNewGroup, onCall, onInfo, onOpenQr, onNewContact, onPick, invites, noPerm, askPerm)
        return
    }

    Scaffold(
        containerColor = AuraBg,
        contentWindowInsets = if (tab) androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0) else androidx.compose.material3.ScaffoldDefaults.contentWindowInsets,
        topBar = {
            if (tab) {
                TitleSlot(Modifier.statusBarsPadding()) {
                    Text(
                        "Kişiler", color = AuraWhite, fontSize = 22.sp,
                        modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 18.dp)
                    )
                }
            } else {
                TopAppBar(
                    title = { Text("Kişi seç") },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = AuraBg, titleContentColor = AuraWhite, navigationIconContentColor = AuraWhite),
                    navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") } }
                )
            }
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            ChipSearchField(q, { q = it }, "Ara", Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 8.dp))
            val list = users
            if (list == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = AuraGreen) }
            } else {
                val shown = list.filter { q.isBlank() || it.name.contains(q, ignoreCase = true) || it.phone.contains(q) }
                LazyColumn {
                    items(shown, key = { it.uid }) { u ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onPick(u) }.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            var peek by remember(u.uid) { mutableStateOf(false) }
                            Box(Modifier.clip(CircleShape).clickable { peek = true }) { Avatar(u.name, u.avatar, 44.dp) }
                            if (peek) AvatarPeekDialog(u.name, u.avatar, false, onDismiss = { peek = false }) { act ->
                                when (act) { 0 -> onPick(u); 1 -> onCall(u, false); 2 -> onCall(u, true); else -> onInfo(u) }
                            }
                            Spacer(Modifier.width(14.dp))
                            Text(u.name, fontSize = 16.sp)
                        }
                    }
                    if (noPerm) item(key = "noperm") { NoPermRow(askPerm) }
                    inviteItems(invites.filter { q.isBlank() || it.name.contains(q, true) || it.phone.contains(q) }, ctxC)
                }
            }
        }
    }
}


@Composable
private fun PickContactPage(
    users: List<UserProfile>?, onBack: () -> Unit, onNewGroup: () -> Unit,
    onCall: (UserProfile, Boolean) -> Unit, onInfo: (UserProfile) -> Unit, onOpenQr: () -> Unit, onNewContact: () -> Unit, onPick: (UserProfile) -> Unit,
    invites: List<DevContact> = emptyList(), noPerm: Boolean = false, onAskPerm: () -> Unit = {}
) {
    val d = androidx.compose.ui.platform.LocalDensity.current.density
    fun p(n: Float) = (n / d).dp
    var searching by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val sub = lm(Color(0xFF5B6266))
    val circle = AuraGreen
    androidx.activity.compose.BackHandler(searching) { searching = false; q = "" }

    Column(Modifier.fillMaxSize().background(AuraBg).statusBarsPadding()) {
        if (searching) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = p(44f), vertical = p(24f)).height(p(131f))
                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(50)).background(lm(Color(0xFFF6F5F3))),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { searching = false; q = "" }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                val fr = remember { androidx.compose.ui.focus.FocusRequester() }
                androidx.compose.runtime.LaunchedEffect(Unit) { fr.requestFocus() }
                Box(Modifier.weight(1f)) {
                    if (q.isEmpty()) Text("Ad, numara, @kullanıcıadı", color = sub, fontSize = 17.sp)
                    androidx.compose.foundation.text.BasicTextField(
                        value = q, onValueChange = { q = it }, singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = AuraWhite, fontSize = 17.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(AuraGreen),
                        modifier = Modifier.fillMaxWidth().focusRequester(fr)
                    )
                }
                Spacer(Modifier.width(12.dp))
            }
        } else {
            Row(Modifier.fillMaxWidth().height(60.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = AuraWhite) }
                Column(Modifier.weight(1f).padding(start = 6.dp)) {
                    Text("Kişi seç", color = AuraWhite, fontSize = 18.sp)
                    if (users != null) Text("${users.size} kişi", color = sub, fontSize = 14.sp)
                }
                IconButton(onClick = { searching = true }) { Icon(Icons.Default.Search, "Ara", tint = AuraWhite) }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menü", tint = AuraWhite) }
                    AuraDropdownMenu(menu, { menu = false }, floating = true, yGap = 5.dp) {
                        AuraMI(text = { Text("Kişi ayarları") }, onClick = { menu = false })
                        AuraMI(text = { Text("Arkadaşlarınızı davet edin") }, onClick = {
                            menu = false
                            val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(android.content.Intent.EXTRA_TEXT, "AuraChat'e katıl: https://github.com/mustafataskin1986/AuraChatApp/releases/download/apk-latest/AuraChat.apk")
                            }
                            ctx.startActivity(android.content.Intent.createChooser(send, "AuraChat'e davet et").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                        })
                        AuraMI(text = { Text("Kişiler") }, onClick = { menu = false })
                        AuraMI(text = { Text("Yenile") }, onClick = { menu = false })
                        AuraMI(text = { Text("Yardım") }, onClick = { menu = false })
                    }
                }
            }
            Box(Modifier.fillMaxWidth().height(hairline()).background(lm(Color(0xFFE6E4E1))))
        }
        if (users == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = AuraGreen) }
        } else {
            val shown = users.filter { q.isBlank() || it.name.contains(q, true) || it.phone.contains(q) || it.username.contains(q.removePrefix("@"), true) }
            LazyColumn(Modifier.fillMaxSize()) {
                if (!searching) {
                    val acts = listOf(
                        Triple(Icons.Default.GroupAdd, "Yeni grup", 0),
                        Triple(Icons.Default.PersonAdd, "Yeni kişi", 1),
                        Triple(Icons.Default.Groups, "Yeni topluluk", 2),
                        Triple(Icons.Default.CalendarMonth, "Yeni etkinlik", 3)
                    )
                    items(acts.size, key = { "act$it" }) { i ->
                        val (ic, label, id) = acts[i]
                        Row(Modifier.fillMaxWidth().height(p(187f)).clickable { if (id == 0) onNewGroup() else if (id == 1) onNewContact() }.padding(start = p(44f), end = p(44f)), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(p(110f)).clip(CircleShape).background(circle), contentAlignment = Alignment.Center) {
                                Icon(ic, null, tint = Color.White, modifier = Modifier.size(26.dp))
                            }
                            Spacer(Modifier.width(p(45f)))
                            Text(label, color = AuraWhite, fontSize = 18.sp, modifier = Modifier.weight(1f))
                            if (id == 1) Box(Modifier.size(44.dp).clip(CircleShape).clickable { onOpenQr() }, contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.QrCode2, "Profil paylaşımı", tint = AuraWhite, modifier = Modifier.size(26.dp))
                            }
                        }
                    }
                }
                item(key = "hdr") {
                    Text(if (searching) "Kişiler" else "AuraChat'taki kişiler", color = sub, fontSize = 16.sp,
                        modifier = Modifier.padding(start = p(44f), top = p(40f), bottom = p(24f)))
                }
                items(shown, key = { it.uid }) { u ->
                    Row(Modifier.fillMaxWidth().height(p(187f)).clickable { onPick(u) }.padding(start = p(44f)), verticalAlignment = Alignment.CenterVertically) {
                        var peek by remember(u.uid) { mutableStateOf(false) }
                        Box(Modifier.clip(CircleShape).clickable { peek = true }) { Avatar(u.name, u.avatar, p(108f)) }
                        if (peek) AvatarPeekDialog(u.name, u.avatar, false, onDismiss = { peek = false }) { act ->
                            when (act) { 0 -> onPick(u); 1 -> onCall(u, false); 2 -> onCall(u, true); else -> onInfo(u) }
                        }
                        Spacer(Modifier.width(p(47f)))
                        Column(Modifier.weight(1f).padding(end = 16.dp)) {
                            Text(u.name, color = AuraWhite, fontSize = 18.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            if (u.about.isNotBlank()) Text(u.about, color = sub, fontSize = 15.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        }
                    }
                }
                if (noPerm) item(key = "noperm") { NoPermRow(onAskPerm) }
                inviteItems(invites.filter { q.isBlank() || it.name.contains(q, true) || it.phone.contains(q) }, ctx)
            }
        }
    }
}


@Composable
private fun NoPermRow(onAsk: () -> Unit) {
    androidx.compose.foundation.layout.Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Kişileri görmek için rehber erişimine izin ver", color = AuraMuted, fontSize = 15.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Text("İzin ver", color = AuraGreen, fontSize = 16.sp, modifier = Modifier.padding(top = 12.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(50)).clickable { onAsk() }.padding(horizontal = 20.dp, vertical = 8.dp))
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.inviteItems(list: List<DevContact>, ctx: android.content.Context) {
    if (list.isEmpty()) return
    item(key = "inv-hdr") {
        Text("AuraChat'te olmayan kişiler", color = AuraMuted, fontSize = 16.sp, modifier = Modifier.padding(start = 16.dp, top = 20.dp, bottom = 8.dp))
    }
    items(list, key = { "inv-" + phoneKey(it.phone) }) { c ->
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(c.name, null, 44.dp)
            Spacer(Modifier.width(14.dp))
            Text(c.name, color = AuraWhite, fontSize = 16.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Text("Davet et", color = AuraGreen, fontSize = 15.sp, modifier = Modifier.clip(androidx.compose.foundation.shape.RoundedCornerShape(50)).clickable { inviteTo(ctx, c.phone) }.padding(horizontal = 12.dp, vertical = 6.dp))
        }
    }
}

package com.aurachat.app.call

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Vibrator
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.aurachat.app.data.ChatTarget
import com.aurachat.app.data.Repo
import com.aurachat.app.data.UserProfile
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class GPeer(
    val uid: String,
    val name: String = "",
    val avatar: String = "",
    val video: VideoTrack? = null,
    val connected: Boolean = false
)

data class GroupCallUi(
    val phase: Phase = Phase.IDLE,
    val groupId: String = "",
    val groupName: String = "",
    val callerName: String = "",
    val video: Boolean = false,
    val micOn: Boolean = true,
    val camOn: Boolean = true,
    val speakerOn: Boolean = false,
    val frontCam: Boolean = true,
    val connectedAt: Long = 0L,
    val message: String = "",
    val localVideo: VideoTrack? = null,
    val peers: List<GPeer> = emptyList()
)

/**
 * Grup araması: herkes herkesle doğrudan bağlanır (mesh). Küçük gruplar (4-6 kişi) için uygundur.
 * Sinyalleşme: chats/{grupId}/call/group (durum) + chats/{grupId}/call/group/callerCandidates (kişiden kişiye sinyaller)
 * Yeni katılan, aramada zaten olan herkese teklif (offer) gönderir.
 */
object GroupCallManager {
    private lateinit var app: Context
    private val db get() = FirebaseFirestore.getInstance()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _ui = MutableStateFlow(GroupCallUi())
    val ui: StateFlow<GroupCallUi> = _ui

    private class PeerState(val uid: String, val pc: PeerConnection, val offerer: Boolean) {
        var remoteSet = false
        val pending = ArrayList<IceCandidate>()
    }

    private val peers = HashMap<String, PeerState>()
    private var me: UserProfile? = null
    private var callId: Long = 0L
    private var stateReg: ListenerRegistration? = null
    private var sigReg: ListenerRegistration? = null
    private var audioSource: org.webrtc.AudioSource? = null
    private var audioTrack: AudioTrack? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var capturer: CameraVideoCapturer? = null
    private var textureHelper: SurfaceTextureHelper? = null
    private var ringtone: Ringtone? = null
    private var timeoutJob: Job? = null
    private var prevAudioMode = AudioManager.MODE_NORMAL
    private var prevSpeaker = false
    private var audioRouted = false
    private var joined = false

    // gelen arama bilgisi
    private var incomingCallId: Long = 0L

    fun init(ctx: Context) { app = ctx.applicationContext }

    private fun toast(s: String) = Toast.makeText(app, s, Toast.LENGTH_SHORT).show()
    private fun stateDoc(gid: String) = db.collection("chats").document(gid).collection("call").document("group")
    private fun sigCol(gid: String) = stateDoc(gid).collection("callerCandidates")

    fun busy() = _ui.value.phase != Phase.IDLE

    // =====================================================================
    //  BAŞLAT
    // =====================================================================
    fun start(p: UserProfile, target: ChatTarget, video: Boolean) {
        me = p
        if (busy() || CallManager.ui.value.phase != Phase.IDLE) { toast("Zaten bir arama devam ediyor"); return }
        val gid = target.chatId
        _ui.value = GroupCallUi(
            phase = Phase.CONNECTING, groupId = gid, groupName = target.name, video = video,
            speakerOn = video, message = "Aranıyor..."
        )
        scope.launch {
            try {
                val g = db.collection("groups").document(gid).get().await()
                @Suppress("UNCHECKED_CAST")
                val members = (g.get("members") as? List<String>) ?: emptyList()
                if (!members.contains(p.uid)) throw IllegalStateException("üye değil")
                val others = members.filter { it != p.uid }
                if (others.isEmpty()) { finish("Grupta başka kimse yok"); return@launch }

                callId = System.currentTimeMillis()
                stateDoc(gid).set(
                    hashMapOf(
                        "active" to true, "video" to video, "callId" to callId,
                        "startedBy" to p.uid, "startedByName" to p.name, "groupName" to target.name,
                        "participants" to listOf(p.uid)
                    )
                ).await()
                joinMedia(video)
                joined = true
                listenState(gid)
                listenSignals(gid)
                _ui.update { it.copy(message = "Çalıyor...") }

                try {
                    db.collection("chats").document(gid).collection("messages").add(
                        mapOf(
                            "type" to "system",
                            "text" to (if (video) "📹 ${p.name} görüntülü grup araması başlattı" else "📞 ${p.name} sesli grup araması başlattı"),
                            "senderUid" to p.uid, "senderName" to p.name,
                            "createdAt" to FieldValue.serverTimestamp(), "read" to false
                        )
                    )
                } catch (e: Throwable) {}
                for (u in others) {
                    launch {
                        try {
                            db.collection("incomingCalls").document(u).set(
                                hashMapOf(
                                    "chatId" to gid, "callType" to (if (video) "video" else "audio"), "isGroup" to true,
                                    "callerUid" to p.uid, "callerName" to p.name, "groupName" to target.name,
                                    "callId" to callId, "at" to System.currentTimeMillis()
                                )
                            ).await()
                        } catch (e: Throwable) {}
                        try {
                            Repo.sendCallPush(
                                u, target.name, "${p.name} " + (if (video) "📹 görüntülü grup araması başlattı" else "📞 sesli grup araması başlattı"),
                                gid, p.uid, p.name, if (video) "video" else "audio", true
                            )
                        } catch (e: Throwable) {}
                    }
                }
                timeoutJob?.cancel()
                timeoutJob = scope.launch {
                    delay(60_000)
                    if (_ui.value.phase == Phase.CONNECTING && _ui.value.peers.isEmpty()) hangup("Cevap veren olmadı")
                }
            } catch (e: Throwable) {
                finish("Arama başlatılamadı")
            }
        }
    }

    // =====================================================================
    //  GELEN
    // =====================================================================
    fun onIncoming(gid: String, callerName: String, groupName: String, video: Boolean, cid: Long) {
        if (busy() || CallManager.ui.value.phase != Phase.IDLE) return
        incomingCallId = cid
        _ui.value = GroupCallUi(
            phase = Phase.INCOMING, groupId = gid, groupName = groupName.ifBlank { "Grup" }, callerName = callerName,
            video = video, speakerOn = video
        )
        startRinging()
        // arama sürüyor mu izle (bitince zil sussun)
        stateReg?.remove()
        stateReg = stateDoc(gid).addSnapshotListener { snap, _ ->
            if (_ui.value.phase != Phase.INCOMING) return@addSnapshotListener
            if (snap == null || !snap.exists() || snap.getBoolean("active") != true || (snap.getLong("callId") ?: 0L) != cid) {
                stopRinging(); resetAll()
            }
        }
        timeoutJob?.cancel()
        timeoutJob = scope.launch {
            delay(60_000)
            if (_ui.value.phase == Phase.INCOMING) { stopRinging(); resetAll() }
        }
    }

    fun decline() {
        if (_ui.value.phase != Phase.INCOMING) return
        stopRinging()
        resetAll()
    }

    fun accept(p: UserProfile) {
        val cur = _ui.value
        if (cur.phase != Phase.INCOMING) return
        me = p
        stopRinging()
        stateReg?.remove(); stateReg = null
        _ui.update { it.copy(phase = Phase.CONNECTING, message = "Bağlanıyor...") }
        scope.launch {
            try {
                val gid = cur.groupId
                val snap = stateDoc(gid).get().await()
                if (snap.getBoolean("active") != true) { finish("Arama sona erdi"); return@launch }
                callId = snap.getLong("callId") ?: 0L
                val video = snap.getBoolean("video") ?: cur.video
                joinMedia(video)
                joined = true
                listenSignals(gid)
                stateDoc(gid).update("participants", FieldValue.arrayUnion(p.uid)).await()
                val after = stateDoc(gid).get().await()
                @Suppress("UNCHECKED_CAST")
                val parts = (after.get("participants") as? List<String>) ?: emptyList()
                listenState(gid)
                for (u in parts) if (u != p.uid) offerTo(u)
                if (parts.size <= 1) _ui.update { it.copy(message = "Bekleniyor...") }
            } catch (e: Throwable) {
                hangup("Bağlantı kurulamadı")
            }
        }
    }

    // =====================================================================
    //  KATILIMCI TAKİBİ
    // =====================================================================
    private fun listenState(gid: String) {
        stateReg?.remove()
        stateReg = stateDoc(gid).addSnapshotListener { snap, _ ->
            if (snap == null || !joined) return@addSnapshotListener
            if (!snap.exists() || snap.getBoolean("active") != true) {
                if (_ui.value.phase != Phase.IDLE && _ui.value.phase != Phase.ENDED) finish("Arama sona erdi")
                return@addSnapshotListener
            }
            @Suppress("UNCHECKED_CAST")
            val parts = (snap.get("participants") as? List<String>) ?: emptyList()
            val my = me?.uid ?: return@addSnapshotListener
            // ayrılanları kapat
            for (u in peers.keys.toList()) if (!parts.contains(u)) removePeer(u)
            _ui.update { cur -> cur.copy(peers = cur.peers.filter { parts.contains(it.uid) }) }
            if (parts.none { it != my } && _ui.value.phase == Phase.CONNECTED) {
                _ui.update { it.copy(message = "Diğer katılımcılar ayrıldı") }
            }
        }
    }

    private fun listenSignals(gid: String) {
        val my = me?.uid ?: return
        sigReg?.remove()
        sigReg = sigCol(gid).whereEqualTo("to", my).addSnapshotListener { snap, _ ->
            if (snap == null) return@addSnapshotListener
            for (ch in snap.documentChanges) {
                if (ch.type != DocumentChange.Type.ADDED) continue
                val d = ch.document
                if ((d.getLong("callId") ?: 0L) != callId) continue
                val from = d.getString("from") ?: continue
                val type = d.getString("type") ?: continue
                val sdp = d.getString("sdp") ?: ""
                val mid = d.getString("mid") ?: ""
                val idx = (d.getLong("idx") ?: 0L).toInt()
                try { d.reference.delete() } catch (e: Throwable) {}
                scope.launch { onSignal(from, type, sdp, mid, idx) }
            }
        }
    }

    private fun send(to: String, type: String, sdp: String = "", mid: String = "", idx: Int = 0) {
        val my = me?.uid ?: return
        val gid = _ui.value.groupId
        sigCol(gid).add(
            hashMapOf<String, Any>(
                "to" to to, "from" to my, "type" to type, "sdp" to sdp, "mid" to mid, "idx" to idx, "callId" to callId
            )
        )
    }

    private suspend fun onSignal(from: String, type: String, sdp: String, mid: String, idx: Int) {
        val my = me?.uid ?: return
        try {
            when (type) {
                "offer" -> {
                    val existing = peers[from]
                    if (existing != null) {
                        // iki taraf aynı anda teklif gönderdi: uid'si küçük olan teklif sahibi kalır
                        if (existing.offerer && my < from) return
                        removePeer(from, keepUi = true)
                    }
                    val ps = createPeer(from, false)
                    ps.pc.setRemote(SessionDescription(SessionDescription.Type.OFFER, sdp))
                    ps.remoteSet = true
                    drain(ps)
                    val ans = ps.pc.createAnswerSuspend()
                    ps.pc.setLocal(ans)
                    send(from, "answer", ans.description)
                }
                "answer" -> {
                    val ps = peers[from] ?: return
                    if (!ps.offerer || ps.remoteSet) return
                    ps.pc.setRemote(SessionDescription(SessionDescription.Type.ANSWER, sdp))
                    ps.remoteSet = true
                    drain(ps)
                }
                "cand" -> {
                    val ps = peers[from]
                    val c = IceCandidate(mid, idx, sdp)
                    if (ps == null) return
                    if (ps.remoteSet) { try { ps.pc.addIceCandidate(c) } catch (e: Throwable) {} } else ps.pending.add(c)
                }
            }
        } catch (e: Throwable) {}
    }

    private fun drain(ps: PeerState) {
        for (c in ps.pending) { try { ps.pc.addIceCandidate(c) } catch (e: Throwable) {} }
        ps.pending.clear()
    }

    private suspend fun offerTo(uid: String) {
        if (peers.containsKey(uid)) return
        val ps = createPeer(uid, true)
        val offer = ps.pc.createOfferSuspend(_ui.value.video)
        ps.pc.setLocal(offer)
        send(uid, "offer", offer.description)
    }

    private fun addPeerUi(uid: String) {
        _ui.update { cur ->
            if (cur.peers.any { it.uid == uid }) cur
            else cur.copy(peers = cur.peers + GPeer(uid, Repo.peekProfile(uid)?.name ?: "", Repo.peekProfile(uid)?.avatar ?: ""))
        }
        if (Repo.peekProfile(uid) == null) {
            scope.launch {
                val pr = try { Repo.profileOf(uid) } catch (e: Throwable) { null } ?: return@launch
                _ui.update { cur -> cur.copy(peers = cur.peers.map { if (it.uid == uid) it.copy(name = pr.name, avatar = pr.avatar) else it }) }
            }
        }
    }

    private fun setPeerVideo(uid: String, t: VideoTrack) {
        _ui.update { cur -> cur.copy(peers = cur.peers.map { if (it.uid == uid) it.copy(video = t) else it }) }
    }

    private fun setPeerConnected(uid: String) {
        _ui.update { cur ->
            val c = cur.copy(peers = cur.peers.map { if (it.uid == uid) it.copy(connected = true) else it })
            if (c.phase == Phase.CONNECTING || c.phase == Phase.OUTGOING) {
                timeoutJob?.cancel()
                c.copy(phase = Phase.CONNECTED, connectedAt = if (c.connectedAt > 0) c.connectedAt else System.currentTimeMillis(), message = "")
            } else c.copy(message = "")
        }
    }

    private fun removePeer(uid: String, keepUi: Boolean = false) {
        val ps = peers.remove(uid) ?: return
        try { ps.pc.close() } catch (e: Throwable) {}
        try { ps.pc.dispose() } catch (e: Throwable) {}
        if (!keepUi) _ui.update { cur -> cur.copy(peers = cur.peers.filter { it.uid != uid }) }
    }

    // =====================================================================
    //  WEBRTC
    // =====================================================================
    private fun joinMedia(video: Boolean) {
        val f = CallManager.ensureFactory()
        setupAudioRoute(video)
        try { ContextCompat.startForegroundService(app, Intent(app, CallService::class.java)) } catch (e: Throwable) {}
        val aSrc = f.createAudioSource(MediaConstraints())
        audioSource = aSrc
        audioTrack = f.createAudioTrack("aura_g_audio", aSrc)
        if (video) {
            val en = Camera2Enumerator(app)
            val names = en.deviceNames
            val front = names.firstOrNull { en.isFrontFacing(it) }
            val name = front ?: names.firstOrNull()
            if (name != null) {
                val cap = en.createCapturer(name, null)
                if (cap != null) {
                    val helper = SurfaceTextureHelper.create("AuraGCapture", CallManager.egl.eglBaseContext)
                    val vSrc = f.createVideoSource(false)
                    cap.initialize(helper, app, vSrc.capturerObserver)
                    cap.startCapture(640, 480, 24)
                    val vTrack = f.createVideoTrack("aura_g_video", vSrc)
                    capturer = cap; textureHelper = helper; videoSource = vSrc; videoTrack = vTrack
                    _ui.update { it.copy(localVideo = vTrack, frontCam = front != null) }
                }
            }
        }
    }

    private fun createPeer(uid: String, offerer: Boolean): PeerState {
        val f = CallManager.ensureFactory()
        val servers = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )
        val cfg = PeerConnection.RTCConfiguration(servers)
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val pc = f.createPeerConnection(cfg, object : PeerConnection.Observer {
            override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                scope.launch {
                    when (s) {
                        PeerConnection.IceConnectionState.CONNECTED, PeerConnection.IceConnectionState.COMPLETED -> setPeerConnected(uid)
                        PeerConnection.IceConnectionState.FAILED -> { if (peers.containsKey(uid)) removePeer(uid) }
                        else -> {}
                    }
                }
            }
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(c: IceCandidate?) {
                if (c == null) return
                send(uid, "cand", c.sdp, c.sdpMid ?: "", c.sdpMLineIndex)
            }
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
            override fun onAddStream(s: MediaStream?) {}
            override fun onRemoveStream(s: MediaStream?) {}
            override fun onDataChannel(d: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver?, s: Array<out MediaStream>?) {
                val t = r?.track()
                if (t is VideoTrack) scope.launch { setPeerVideo(uid, t) }
            }
            override fun onTrack(t: RtpTransceiver?) {
                val tr = t?.receiver?.track()
                if (tr is VideoTrack) scope.launch { setPeerVideo(uid, tr) }
            }
        }) ?: throw IllegalStateException("peer")
        audioTrack?.let { pc.addTrack(it, listOf("aura_g_stream")) }
        videoTrack?.let { pc.addTrack(it, listOf("aura_g_stream")) }
        val ps = PeerState(uid, pc, offerer)
        peers[uid] = ps
        addPeerUi(uid)
        return ps
    }

    // =====================================================================
    //  KONTROLLER
    // =====================================================================
    fun toggleMic() {
        val on = !_ui.value.micOn
        audioTrack?.setEnabled(on)
        _ui.update { it.copy(micOn = on) }
    }

    fun toggleCam() {
        val on = !_ui.value.camOn
        videoTrack?.setEnabled(on)
        _ui.update { it.copy(camOn = on) }
    }

    fun switchCamera() {
        val c = capturer ?: return
        try {
            c.switchCamera(object : CameraVideoCapturer.CameraSwitchHandler {
                override fun onCameraSwitchDone(isFrontCamera: Boolean) { _ui.update { it.copy(frontCam = isFrontCamera) } }
                override fun onCameraSwitchError(errorDescription: String?) {}
            })
        } catch (e: Throwable) {}
    }

    fun toggleSpeaker() {
        val on = !_ui.value.speakerOn
        setSpeaker(on)
        _ui.update { it.copy(speakerOn = on) }
    }

    private fun setSpeaker(on: Boolean) {
        try {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            @Suppress("DEPRECATION")
            am.isSpeakerphoneOn = on
        } catch (e: Throwable) {}
    }

    private fun setupAudioRoute(video: Boolean) {
        try {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            prevAudioMode = am.mode
            @Suppress("DEPRECATION")
            prevSpeaker = am.isSpeakerphoneOn
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            @Suppress("DEPRECATION")
            am.isSpeakerphoneOn = video
            audioRouted = true
        } catch (e: Throwable) {}
    }

    private fun restoreAudioRoute() {
        if (!audioRouted) return
        audioRouted = false
        try {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            @Suppress("DEPRECATION")
            am.isSpeakerphoneOn = prevSpeaker
            am.mode = prevAudioMode
        } catch (e: Throwable) {}
    }

    // =====================================================================
    //  AYRIL / BİTİR
    // =====================================================================
    fun hangup(message: String = "Arama sonlandı") {
        val cur = _ui.value
        if (cur.phase == Phase.IDLE || cur.phase == Phase.ENDED) return
        if (cur.phase == Phase.INCOMING) { decline(); return }
        val my = me
        val gid = cur.groupId
        val wasJoined = joined
        finish(message)
        if (my != null && wasJoined) {
            scope.launch {
                try {
                    stateDoc(gid).update("participants", FieldValue.arrayRemove(my.uid)).await()
                    val snap = stateDoc(gid).get().await()
                    @Suppress("UNCHECKED_CAST")
                    val parts = (snap.get("participants") as? List<String>) ?: emptyList()
                    if (parts.isEmpty()) stateDoc(gid).update("active", false).await()
                } catch (e: Throwable) {}
            }
        }
    }

    private fun finish(message: String) {
        val cur = _ui.value
        if (cur.phase == Phase.IDLE || cur.phase == Phase.ENDED) return
        _ui.update { it.copy(phase = Phase.ENDED, message = message) }
        releaseAll()
        scope.launch {
            delay(900)
            if (_ui.value.phase == Phase.ENDED) _ui.value = GroupCallUi()
        }
    }

    private fun resetAll() {
        releaseAll()
        _ui.value = GroupCallUi()
    }

    private fun releaseAll() {
        timeoutJob?.cancel()
        stopRinging()
        stateReg?.remove(); stateReg = null
        sigReg?.remove(); sigReg = null
        for (u in peers.keys.toList()) removePeer(u, keepUi = true)
        peers.clear()
        try { capturer?.stopCapture() } catch (e: Throwable) {}
        try { capturer?.dispose() } catch (e: Throwable) {}
        capturer = null
        try { textureHelper?.dispose() } catch (e: Throwable) {}
        textureHelper = null
        try { videoTrack?.dispose() } catch (e: Throwable) {}
        videoTrack = null
        try { videoSource?.dispose() } catch (e: Throwable) {}
        videoSource = null
        try { audioTrack?.dispose() } catch (e: Throwable) {}
        audioTrack = null
        try { audioSource?.dispose() } catch (e: Throwable) {}
        audioSource = null
        joined = false
        callId = 0L
        restoreAudioRoute()
        try { app.stopService(Intent(app, CallService::class.java)) } catch (e: Throwable) {}
    }

    private fun startRinging() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val r = RingtoneManager.getRingtone(app, uri)
            if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
            r.play()
            ringtone = r
        } catch (e: Throwable) {}
        try {
            val v = app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            @Suppress("DEPRECATION")
            v?.vibrate(longArrayOf(0, 400, 300, 400, 1200), 0)
        } catch (e: Throwable) {}
    }

    private fun stopRinging() {
        try { ringtone?.stop() } catch (e: Throwable) {}
        ringtone = null
        try { (app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.cancel() } catch (e: Throwable) {}
    }

    // ---- SDP yardımcıları ----
    private suspend fun PeerConnection.createOfferSuspend(video: Boolean): SessionDescription =
        suspendCancellableCoroutine { c ->
            val mc = MediaConstraints()
            mc.mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mc.mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", if (video) "true" else "false"))
            createOffer(object : SdpObserver {
                override fun onCreateSuccess(d: SessionDescription?) { if (d != null) c.resume(d) else c.resumeWithException(Exception("offer")) }
                override fun onSetSuccess() {}
                override fun onCreateFailure(e: String?) { c.resumeWithException(Exception(e ?: "offer")) }
                override fun onSetFailure(e: String?) {}
            }, mc)
        }

    private suspend fun PeerConnection.createAnswerSuspend(): SessionDescription =
        suspendCancellableCoroutine { c ->
            createAnswer(object : SdpObserver {
                override fun onCreateSuccess(d: SessionDescription?) { if (d != null) c.resume(d) else c.resumeWithException(Exception("answer")) }
                override fun onSetSuccess() {}
                override fun onCreateFailure(e: String?) { c.resumeWithException(Exception(e ?: "answer")) }
                override fun onSetFailure(e: String?) {}
            }, MediaConstraints())
        }

    private suspend fun PeerConnection.setLocal(d: SessionDescription) =
        suspendCancellableCoroutine<Unit> { c ->
            setLocalDescription(object : SdpObserver {
                override fun onCreateSuccess(x: SessionDescription?) {}
                override fun onSetSuccess() { c.resume(Unit) }
                override fun onCreateFailure(e: String?) {}
                override fun onSetFailure(e: String?) { c.resumeWithException(Exception(e ?: "setLocal")) }
            }, d)
        }

    private suspend fun PeerConnection.setRemote(d: SessionDescription) =
        suspendCancellableCoroutine<Unit> { c ->
            setRemoteDescription(object : SdpObserver {
                override fun onCreateSuccess(x: SessionDescription?) {}
                override fun onSetSuccess() { c.resume(Unit) }
                override fun onCreateFailure(e: String?) {}
                override fun onSetFailure(e: String?) { c.resumeWithException(Exception(e ?: "setRemote")) }
            }, d)
        }
}

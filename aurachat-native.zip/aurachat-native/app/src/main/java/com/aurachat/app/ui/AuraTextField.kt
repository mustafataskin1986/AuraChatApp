package com.aurachat.app.ui

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Uygulamadaki tüm metin kutuları için ortak alan: BasicTextField gibi çalışır, ek olarak
 * iki kez hızlı dokununca dokunulan kelimeyi seçer (basılı tutmaya gerek kalmaz).
 */
@Composable
fun AuraTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    textStyle: TextStyle = TextStyle.Default,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    singleLine: Boolean = false,
    maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE,
    onTextLayout: (TextLayoutResult) -> Unit = {},
    cursorBrush: Brush = SolidColor(androidx.compose.ui.graphics.Color.Black),
    decorationBox: @Composable (innerTextField: @Composable () -> Unit) -> Unit = { it() }
) {
    var tfv by remember { mutableStateOf(TextFieldValue(value)) }
    val shown = if (tfv.text == value) tfv else TextFieldValue(value, TextRange(value.length))
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val scope = rememberCoroutineScope()
    var lastUp by remember { mutableStateOf(0L) }
    var lastPos by remember { mutableStateOf(Offset.Zero) }
    val view = androidx.compose.ui.platform.LocalView.current
    var fieldPos by remember { mutableStateOf(Offset.Zero) }

    BasicTextField(
        value = shown,
        onValueChange = { tfv = it; if (it.text != value) onValueChange(it.text) },
        modifier = modifier.onGloballyPositioned { fieldPos = it.positionInRoot() }.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                val up = waitForUpOrCancellation(PointerEventPass.Initial) ?: return@awaitEachGesture
                if (up.uptimeMillis - down.uptimeMillis > 250) { lastUp = 0L; return@awaitEachGesture }
                val near = (up.position - lastPos).getDistance() < 48.dp.toPx()
                if (lastUp != 0L && up.uptimeMillis - lastUp < 320 && near) {
                    lastUp = 0L
                    val pos = up.position
                    scope.launch {
                        delay(70) // alanın kendi dokunuş işlemi bittikten sonra seç
                        val l = layout ?: return@launch
                        val cur = tfv.text
                        if (cur.isEmpty()) return@launch
                        val off = l.getOffsetForPosition(pos).coerceIn(0, cur.length)
                        val w = l.getWordBoundary(if (off >= cur.length) cur.length - 1 else off)
                        tfv = tfv.copy(selection = TextRange(w.start, w.end))
                        // Seçim anında görünsün; ardından sistemin kendi "basılı tutma" hareketi taklit edilir:
                        // böylece iki tutamaç ve Kes/Kopyala/Yapıştır menüsü basılı tutmadaki gibi çıkar
                        try {
                            val x = fieldPos.x + pos.x; val y = fieldPos.y + pos.y
                            val t0 = android.os.SystemClock.uptimeMillis()
                            val dn = android.view.MotionEvent.obtain(t0, t0, android.view.MotionEvent.ACTION_DOWN, x, y, 0)
                            view.dispatchTouchEvent(dn)
                            delay(android.view.ViewConfiguration.getLongPressTimeout() + 80L)
                            val t1 = android.os.SystemClock.uptimeMillis()
                            val upE = android.view.MotionEvent.obtain(t0, t1, android.view.MotionEvent.ACTION_UP, x, y, 0)
                            view.dispatchTouchEvent(upE)
                            dn.recycle(); upE.recycle()
                        } catch (e: Throwable) {}
                    }
                } else { lastUp = up.uptimeMillis; lastPos = up.position }
            }
        },
        textStyle = textStyle,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        singleLine = singleLine,
        maxLines = maxLines,
        onTextLayout = { layout = it; onTextLayout(it) },
        cursorBrush = cursorBrush,
        decorationBox = decorationBox
    )
}

package com.aurachat.app.ui

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalTextToolbar
import androidx.compose.ui.text.AnnotatedString
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Uygulamadaki tüm metin kutuları için ortak alan: BasicTextField gibi çalışır, ek olarak
 * iki kez hızlı dokununca dokunulan kelimeyi seçer (basılı tutmaya gerek kalmaz).
 */
@Composable
fun AuraTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    textStyle: TextStyle = TextStyle.Default,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    singleLine: Boolean = false,
    maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE,
    onTextLayout: (TextLayoutResult) -> Unit = {},
    cursorBrush: Brush = SolidColor(androidx.compose.ui.graphics.Color.Black),
    decorationBox: @Composable (innerTextField: @Composable () -> Unit) -> Unit = { it() }
) {
    var tfv by remember { mutableStateOf(TextFieldValue(value)) }
    val shown = if (tfv.text == value) tfv else TextFieldValue(value, TextRange(value.length))
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val scope = rememberCoroutineScope()
    var lastUp by remember { mutableStateOf(0L) }
    var lastPos by remember { mutableStateOf(Offset.Zero) }
    val toolbar = LocalTextToolbar.current
    val clipboard = LocalClipboardManager.current
    var fieldPos by remember { mutableStateOf(Offset.Zero) }

    // seçim menüsü (Kes / Kopyala / Yapıştır / Tümünü seç): basılı tutmadaki gibi çift dokunuşta da açılır
    fun showMenuFor(sel: TextRange) {
        val l = layout ?: return
        val cur = tfv.text
        if (sel.collapsed || cur.isEmpty()) return
        val a = l.getBoundingBox(sel.start.coerceIn(0, cur.length - 1))
        val b = l.getBoundingBox((sel.end - 1).coerceIn(0, cur.length - 1))
        val rect = Rect(minOf(a.left, b.left) + fieldPos.x, minOf(a.top, b.top) + fieldPos.y, maxOf(a.right, b.right) + fieldPos.x, maxOf(a.bottom, b.bottom) + fieldPos.y)
        fun replaceSel(txt: String) {
            val t = tfv.text
            val s0 = minOf(tfv.selection.start, tfv.selection.end); val e0 = maxOf(tfv.selection.start, tfv.selection.end)
            val nt = t.substring(0, s0) + txt + t.substring(e0)
            tfv = TextFieldValue(nt, TextRange(s0 + txt.length))
            onValueChange(nt)
            toolbar.hide()
        }
        toolbar.showMenu(
            rect = rect,
            onCopyRequested = {
                val s0 = minOf(tfv.selection.start, tfv.selection.end); val e0 = maxOf(tfv.selection.start, tfv.selection.end)
                clipboard.setText(AnnotatedString(tfv.text.substring(s0, e0)))
                tfv = tfv.copy(selection = TextRange(e0)); toolbar.hide()
            },
            onPasteRequested = { clipboard.getText()?.text?.let { replaceSel(it) } },
            onCutRequested = {
                val s0 = minOf(tfv.selection.start, tfv.selection.end); val e0 = maxOf(tfv.selection.start, tfv.selection.end)
                clipboard.setText(AnnotatedString(tfv.text.substring(s0, e0)))
                replaceSel("")
            },
            onSelectAllRequested = {
                tfv = tfv.copy(selection = TextRange(0, tfv.text.length))
                showMenuFor(tfv.selection)
            }
        )
    }
    androidx.compose.runtime.LaunchedEffect(tfv.selection) { if (tfv.selection.collapsed) toolbar.hide() }

    BasicTextField(
        value = shown,
        onValueChange = { tfv = it; if (it.text != value) onValueChange(it.text) },
        modifier = modifier.onGloballyPositioned { fieldPos = it.positionInRoot() }.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                val up = waitForUpOrCancellation(PointerEventPass.Initial) ?: return@awaitEachGesture
                if (up.uptimeMillis - down.uptimeMillis > 250) { lastUp = 0L; return@awaitEachGesture }
                val near = (up.position - lastPos).getDistance() < 48.dp.toPx()
                if (lastUp != 0L && up.uptimeMillis - lastUp < 320 && near) {
                    lastUp = 0L
                    val pos = up.position
                    scope.launch {
                        delay(70) // alanın kendi dokunuş işlemi bittikten sonra seç
                        val l = layout ?: return@launch
                        val cur = tfv.text
                        if (cur.isEmpty()) return@launch
                        val off = l.getOffsetForPosition(pos).coerceIn(0, cur.length)
                        val w = l.getWordBoundary(if (off >= cur.length) cur.length - 1 else off)
                        tfv = tfv.copy(selection = TextRange(w.start, w.end))
                        showMenuFor(tfv.selection)
                    }
                } else { lastUp = up.uptimeMillis; lastPos = up.position }
            }
        },
        textStyle = textStyle,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        singleLine = singleLine,
        maxLines = maxLines,
        onTextLayout = { layout = it; onTextLayout(it) },
        cursorBrush = cursorBrush,
        decorationBox = decorationBox
    )
}

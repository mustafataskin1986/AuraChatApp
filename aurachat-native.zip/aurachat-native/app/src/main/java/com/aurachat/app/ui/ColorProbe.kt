package com.aurachat.app.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.PixelCopy
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Colorize
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun Context.activity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

/**
 * Her sayfada sol üstte duran küçük renk bulucu: dokununca etkinleşir, ekranda bir noktaya
 * dokunup sürükleyince o pikselin hex kodunu gösterir; çipe tekrar dokununca kodu kopyalar ve kapanır.
 * (Sadece ana pencereyi okur; açılır pencere / alt sayfa içindeki renkler okunamaz.)
 */
@Composable
fun ColorProbeOverlay() {
    val ctx = LocalContext.current
    var shot by remember { mutableStateOf<Bitmap?>(null) }
    var active by remember { mutableStateOf(false) }
    var picked by remember { mutableStateOf<Int?>(null) }
    var touch by remember { mutableStateOf<Offset?>(null) }

    fun capture() {
        val act = ctx.activity() ?: return
        val v = act.window.decorView
        if (v.width <= 0 || v.height <= 0) return
        val bmp = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                PixelCopy.request(act.window, bmp, { res ->
                    if (res == PixelCopy.SUCCESS) { shot = bmp; picked = null; touch = null; active = true }
                }, Handler(Looper.getMainLooper()))
            } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ColorProbe", e) }
        } else {
            try { v.draw(android.graphics.Canvas(bmp)); shot = bmp; picked = null; touch = null; active = true } catch (e: Throwable) { com.aurachat.app.AuraLog.e("ColorProbe", e) }
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (active) {
            Box(
                Modifier.fillMaxSize().pointerInput(Unit) {
                    awaitEachGesture {
                        val d = awaitFirstDown()
                        fun sample(p: Offset) {
                            val b = shot ?: return
                            val x = p.x.toInt().coerceIn(0, b.width - 1)
                            val y = p.y.toInt().coerceIn(0, b.height - 1)
                            picked = b.getPixel(x, y) or 0xFF000000.toInt()
                            touch = p
                        }
                        sample(d.position)
                        d.consume()
                        do {
                            val ev = awaitPointerEvent()
                            val ch = ev.changes.firstOrNull()
                            if (ch != null) { sample(ch.position); ch.consume() }
                        } while (ev.changes.any { it.pressed })
                    }
                }
            ) {
                val t = touch
                if (t != null) Canvas(Modifier.fillMaxSize()) {
                    drawCircle(Color.Black, 14.dp.toPx(), t, style = Stroke(3.dp.toPx()))
                    drawCircle(Color.White, 12.dp.toPx(), t, style = Stroke(2.dp.toPx()))
                }
            }
        }
        val hex = picked?.let { "#%06X".format(it and 0xFFFFFF) }
        Row(
            Modifier.statusBarsPadding().padding(start = 6.dp, top = 6.dp)
                .clip(RoundedCornerShape(50)).background(Color(0xCC000000))
                .border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(50))
                .clickable {
                    if (!active) capture()
                    else {
                        if (hex != null) {
                            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager)?.setPrimaryClip(ClipData.newPlainText("hex", hex))
                            android.widget.Toast.makeText(ctx, "$hex kopyalandı", android.widget.Toast.LENGTH_SHORT).show()
                        }
                        active = false; shot = null; picked = null; touch = null
                    }
                }
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!active) {
                Icon(Icons.Default.Colorize, "Renk bulucu", tint = Color.White, modifier = Modifier.size(18.dp))
            } else {
                Box(Modifier.size(18.dp).clip(CircleShape).background(picked?.let { Color(it) } ?: Color.Transparent).border(1.dp, Color.White, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text(hex ?: "dokun", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

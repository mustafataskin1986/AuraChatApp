package com.aurachat.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

private fun galleryPermission() =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE

private fun queryRecentImages(ctx: Context, limit: Int): List<Uri> {
    val out = ArrayList<Uri>()
    try {
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        ctx.contentResolver.query(
            base, arrayOf(MediaStore.Images.Media._ID), null, null,
            MediaStore.Images.Media.DATE_ADDED + " DESC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            while (c.moveToNext() && out.size < limit) {
                out.add(android.content.ContentUris.withAppendedId(base, c.getLong(idCol)))
            }
        }
    } catch (e: Throwable) {}
    return out
}

private fun loadThumb(ctx: Context, uri: Uri): Bitmap? = try {
    if (Build.VERSION.SDK_INT >= 29) {
        ctx.contentResolver.loadThumbnail(uri, Size(240, 240), null)
    } else {
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, b) }
        var s = 1
        while (max(b.outWidth, b.outHeight) / (s * 2) >= 240) s *= 2
        ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        }
    }
} catch (e: Throwable) { null }

/**
 * "+" panelinin altındaki galeri ızgarası (WhatsApp tarzı): telefondaki son fotoğraflar,
 * numaralı çoklu seçim, altta "N seçildi · Ekle" çubuğu.
 */
@Composable
fun GalleryStrip(accent: Color, maxPick: Int, onPick: (List<Uri>) -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, galleryPermission()) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    var images by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var selected by remember { mutableStateOf<List<Uri>>(emptyList()) }

    LaunchedEffect(granted) {
        if (granted) images = withContext(Dispatchers.IO) { queryRecentImages(ctx, 120) }
    }

    Box(modifier.fillMaxWidth()) {
        if (!granted) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("Resimleri burada görmek için galeri izni gerekiyor.", color = Color(0xFFCBD5E1), fontSize = 14.sp)
                Text(
                    "İzin ver", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 10.dp).clip(CircleShape).background(accent)
                        .clickable { permLauncher.launch(galleryPermission()) }
                        .padding(horizontal = 22.dp, vertical = 8.dp)
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                items(images, key = { it.toString() }) { uri ->
                    val idx = selected.indexOf(uri)
                    val on = idx >= 0
                    val bmp by produceState<Bitmap?>(null, uri) { value = withContext(Dispatchers.IO) { loadThumb(ctx, uri) } }
                    Box(
                        Modifier.aspectRatio(1f).background(Color(0xFF1B262D))
                            .then(if (on) Modifier.border(3.dp, accent) else Modifier)
                            .clickable {
                                selected = if (on) selected - uri
                                else if (selected.size < maxPick) selected + uri else selected
                            }
                    ) {
                        val b = bmp
                        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Box(
                            Modifier.align(Alignment.TopEnd).padding(5.dp).size(22.dp).clip(CircleShape)
                                .background(if (on) accent else Color(0x40000000))
                                .border(2.dp, if (on) accent else Color(0xCCFFFFFF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (on) Text("${idx + 1}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            if (selected.isNotEmpty()) {
                Row(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xF5111B21))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${selected.size} seçildi", color = Color.White, fontSize = 14.sp)
                    Text(
                        "Ekle", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(CircleShape).background(accent)
                            .clickable { val s = selected; selected = emptyList(); onPick(s) }
                            .padding(horizontal = 22.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

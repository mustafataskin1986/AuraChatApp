package com.aurachat.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

private fun galleryPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

class GItem(val uri: Uri, val video: Boolean, val durMs: Long, val bucket: String, val date: Long)

private fun queryMedia(ctx: Context, limit: Int): List<GItem> {
    val out = ArrayList<GItem>()
    try {
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        ctx.contentResolver.query(
            base, arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.BUCKET_DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED), null, null,
            MediaStore.Images.Media.DATE_ADDED + " DESC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val bCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            val dCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            while (c.moveToNext() && out.size < limit) {
                out.add(GItem(android.content.ContentUris.withAppendedId(base, c.getLong(idCol)), false, 0L, c.getString(bCol) ?: "", c.getLong(dCol)))
            }
        }
    } catch (e: Throwable) { com.aurachat.app.AuraLog.e("GalleryStrip", e) }
    try {
        val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        var n = 0
        ctx.contentResolver.query(
            base, arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media.DATE_ADDED, MediaStore.Video.Media.DURATION), null, null,
            MediaStore.Video.Media.DATE_ADDED + " DESC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val bCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            val dCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            while (c.moveToNext() && n < limit) {
                n++
                out.add(GItem(android.content.ContentUris.withAppendedId(base, c.getLong(idCol)), true, c.getLong(durCol), c.getString(bCol) ?: "", c.getLong(dCol)))
            }
        }
    } catch (e: Throwable) { com.aurachat.app.AuraLog.e("GalleryStrip", e) }
    return out.sortedByDescending { it.date }
}

private fun loadThumb(ctx: Context, uri: Uri): Bitmap? = try {
    if (Build.VERSION.SDK_INT >= 29) {
        ctx.contentResolver.loadThumbnail(uri, Size(240, 240), null)
    } else {
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, b) }
        var s = 1
        while (max(b.outWidth, b.outHeight) / (s * 2) >= 240) s *= 2
        ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        }
    }
} catch (e: Throwable) { null }

/**
 * "+" panelinin altındaki galeri ızgarası (WhatsApp tarzı): telefondaki son fotoğraflar,
 * numaralı çoklu seçim, altta "N seçildi · Ekle" çubuğu.
 */
@Composable
fun GalleryStrip(
    accent: Color, maxPick: Int, selected: List<Uri>, onSelected: (List<Uri>) -> Unit, modifier: Modifier = Modifier, grid: Boolean = false,
    album: String? = null, onAlbums: (List<Pair<String, Int>>) -> Unit = {},
    columns: Int = 4, leading: (@Composable () -> Unit)? = null
) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, galleryPermissions()[0]) == PackageManager.PERMISSION_GRANTED ||
                (Build.VERSION.SDK_INT >= 34 && ContextCompat.checkSelfPermission(ctx, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED") == PackageManager.PERMISSION_GRANTED)
        )
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r.values.any { it } || ContextCompat.checkSelfPermission(ctx, galleryPermissions()[0]) == PackageManager.PERMISSION_GRANTED
    }
    var allItems by remember { mutableStateOf<List<GItem>>(emptyList()) }

    LaunchedEffect(granted) {
        if (granted) {
            allItems = withContext(Dispatchers.IO) { queryMedia(ctx, 300) }
            onAlbums(allItems.groupBy { it.bucket }.map { it.key to it.value.size }.filter { it.first.isNotBlank() }.sortedByDescending { it.second })
        }
    }
    val items = remember(allItems, album) { if (album == null) allItems.take(240) else allItems.filter { it.bucket == album } }
    val videoSet = remember(allItems) { allItems.filter { it.video }.map { it.uri }.toSet() }
    val durMap = remember(allItems) { allItems.filter { it.video }.associate { it.uri to it.durMs } }

    Box(modifier.fillMaxWidth()) {
        if (!granted) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("Resimleri burada görmek için galeri izni gerekiyor.", color = auraLc(0xFFCBD5E1), fontSize = 14.sp)
                Text(
                    "İzin ver", color = AuraWhite, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 10.dp).clip(CircleShape).background(accent)
                        .clickable { permLauncher.launch(galleryPermissions()) }
                        .padding(horizontal = 22.dp, vertical = 8.dp)
                )
            }
        } else {
            @Composable
            fun Cell(uri: Uri, sizeMod: Modifier) {
                run {
                    val idx = selected.indexOf(uri)
                    val on = idx >= 0
                    val bmp by produceState<Bitmap?>(null, uri) { value = withContext(Dispatchers.IO) { loadThumb(ctx, uri) } }
                    Box(
                        sizeMod.background(auraLc(0xFF1B262D))
                            .clickable {
                                onSelected(
                                    if (on) selected - uri
                                    else if (selected.size < maxPick) selected + uri else selected
                                )
                            }
                    ) {
                        val b = bmp
                        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, colorFilter = auraImageFilter())
                        if (on) Box(Modifier.fillMaxSize().background(auraLc(0x73FFFFFF)))
                        if (videoSet.contains(uri)) {
                            val sec = ((durMap[uri] ?: 0L) / 1000).toInt()
                            Text(
                                "▶ %d:%02d".format(sec / 60, sec % 60), color = AuraWhite, fontSize = 11.sp,
                                modifier = Modifier.align(Alignment.BottomStart).padding(4.dp).clip(CircleShape)
                                    .background(auraLc(0x99000000)).padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Box(
                            Modifier.align(Alignment.TopEnd).padding(5.dp).size(22.dp).clip(CircleShape)
                                .background(if (on) accent else auraLc(0x40000000))
                                .border(2.dp, if (on) accent else auraLc(0xCCFFFFFF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (on) Text(
                                "${idx + 1}", color = AuraWhite, fontWeight = FontWeight.Bold,
                                style = androidx.compose.ui.text.TextStyle(
                                    fontSize = 12.sp, lineHeight = 12.sp,
                                    lineHeightStyle = androidx.compose.ui.text.style.LineHeightStyle(
                                        androidx.compose.ui.text.style.LineHeightStyle.Alignment.Center,
                                        androidx.compose.ui.text.style.LineHeightStyle.Trim.Both
                                    ),
                                    platformStyle = androidx.compose.ui.text.PlatformTextStyle(includeFontPadding = false)
                                )
                            )
                        }
                    }
                }
            }
            if (grid) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns), modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(2.dp), verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    if (leading != null) item(key = "leading") { Box(Modifier.aspectRatio(1f)) { leading() } }
                    items(items, key = { it.uri.toString() }) { g -> Cell(g.uri, Modifier.aspectRatio(1f)) }
                }
            } else {
                androidx.compose.foundation.lazy.LazyRow(
                    Modifier.fillMaxWidth().height(96.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) { items(items, key = { it.uri.toString() }) { g -> Cell(g.uri, Modifier.size(96.dp)) } }
            }
        }
    }
}

package com.aurachat.app.data

import android.content.Context
import android.content.SharedPreferences
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/** Web sürümüyle AYNI Firestore şemasını kullanır; iki taraf birlikte çalışır. */
object Repo {
    private const val API = "https://aurachat-amber.vercel.app/api/send-notification"

    private val db get() = FirebaseFirestore.getInstance()
    private val auth get() = FirebaseAuth.getInstance()
    private val bg = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ---------- Önbellek ----------
    private var prefs: SharedPreferences? = null
    private var profDir: java.io.File? = null
    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)
        profDir = java.io.File(ctx.filesDir, "prof").apply { mkdirs() }
        LocalMedia.init(ctx)
        LocalDb.init(ctx)
    }

    /** Açılışta ağı beklemeden gösterilsin diye son bilinen profil */
    fun cachedProfile(uid: String): UserProfile? {
        val p = prefs ?: return null
        val n = p.getString("name_$uid", null) ?: return null
        return UserProfile(uid, n, p.getString("phone_$uid", "") ?: "")
    }

    private fun cacheProfile(p: UserProfile) {
        if (p.name.isBlank()) return
        prefs?.edit()?.putString("name_${p.uid}", p.name)?.putString("phone_${p.uid}", p.phone)?.apply()
    }

    /** Açılışta liste hemen çizilsin diye son bilinen sohbet listesi */
    fun cachedChats(uid: String): List<ChatSummary>? {
        val raw = prefs?.getString("chats_$uid", null) ?: return null
        return try {
            val arr = org.json.JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ChatSummary(
                    chatId = o.getString("id"), isGroup = o.getBoolean("g"), otherUid = o.getString("u"),
                    name = o.getString("n"), lastMessage = o.getString("m"), lastTime = o.getLong("t"),
                    lastSenderUid = o.getString("su"), lastSenderName = o.getString("sn"),
                    lastRead = o.getBoolean("r"), unread = o.getInt("c"), pinned = o.getBoolean("p"),
                    favorite = o.getBoolean("f"), typing = false, clearedAt = o.getLong("ca"), keepRow = o.optBoolean("k", false),
                    muted = o.optBoolean("mu", false), archivedChat = o.optBoolean("ar", false)
                )
            }
        } catch (e: Throwable) { null }
    }

    private fun cacheChats(uid: String, list: List<ChatSummary>) {
        bg.launch {
            try {
                val arr = org.json.JSONArray()
                list.forEach { c ->
                    arr.put(JSONObject().put("id", c.chatId).put("g", c.isGroup).put("u", c.otherUid).put("n", c.name)
                        .put("m", c.lastMessage.take(200)).put("t", c.lastTime).put("su", c.lastSenderUid)
                        .put("sn", c.lastSenderName).put("r", c.lastRead).put("c", c.unread).put("p", c.pinned)
                        .put("f", c.favorite).put("ca", c.clearedAt).put("k", c.keepRow).put("mu", c.muted).put("ar", c.archivedChat))
                }
                prefs?.edit()?.putString("chats_$uid", arr.toString())?.apply()
            } catch (e: Throwable) {}
        }
    }

    fun chatId(a: String, b: String) = listOf(a, b).sorted().joinToString("_")

    /** Birebir sohbet id'si "uidA_uidB" biçimindedir; gruplar farklı. */
    fun isDirect(chatId: String) = chatId.split("_").size == 2

    fun targetFor(me: String, chatId: String, name: String): ChatTarget {
        return if (isDirect(chatId)) {
            val other = chatId.split("_").firstOrNull { it != me } ?: ""
            ChatTarget(chatId, false, other, name)
        } else {
            ChatTarget(chatId, true, chatId, name)
        }
    }

    private val clearedMap = java.util.concurrent.ConcurrentHashMap<String, Long>()

    /** Sohbetin temizlenme zamanı (anında): sohbet açılırken eski mesajlar bir an görünmesin */
    fun peekClearedAt(uid: String, chatId: String): Long =
        clearedMap[chatId] ?: (cachedChats(uid)?.firstOrNull { it.chatId == chatId }?.clearedAt ?: 0L)

    private fun DocumentSnapshot.ts(field: String): Long =
        getTimestamp(field, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L

    // ---------- Profil ----------
    suspend fun loadProfile(uid: String): UserProfile? {
        val d = db.collection("users").document(uid).get().await()
        if (!d.exists()) return null
        return UserProfile(uid, d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("avatar") ?: "", d.getString("about") ?: "", d.getString("username") ?: "")
            .also { cacheProfile(it) }
    }

    suspend fun saveName(uid: String, email: String, name: String): UserProfile {
        db.collection("users").document(uid).set(
            mapOf("uid" to uid, "name" to name, "email" to email, "lastSeen" to FieldValue.serverTimestamp()),
            SetOptions.merge()
        ).await()
        return UserProfile(uid, name).also { cacheProfile(it) }
    }

    /** Kayıt: telefon (10 hane) başka hesapta varsa IllegalStateException("PHONE_TAKEN") */
    suspend fun createProfile(uid: String, email: String, name: String, phone10: String, avatar: String): UserProfile {
        val formatted = "+90$phone10"
        val snap = db.collection("users").whereIn("phone", listOf(phone10, formatted, "0$phone10")).get().await()
        if (snap.documents.any { it.id != uid }) throw IllegalStateException("PHONE_TAKEN")
        db.collection("users").document(uid).set(
            mapOf("uid" to uid, "name" to name, "email" to email, "phone" to formatted, "avatar" to avatar,
                "lastSeen" to FieldValue.serverTimestamp()),
            SetOptions.merge()
        ).await()
        return UserProfile(uid, name, formatted, avatar).also { cacheProfile(it) }
    }

    private val profileCache = ConcurrentHashMap<String, UserProfile>()

    /** Diskteki son bilinen profil (ad + avatar) – ağı beklemeden hemen gösterilir */
    private fun diskProfile(uid: String): UserProfile? {
        val f = java.io.File(profDir ?: return null, "$uid.json")
        if (!f.exists()) return null
        return try {
            val o = org.json.JSONObject(f.readText())
            UserProfile(uid, o.optString("n"), o.optString("p"), o.optString("a"), o.optString("b"), o.optString("u"))
        } catch (e: Throwable) { null }
    }

    private fun saveProfile(p: UserProfile) {
        val d = profDir ?: return
        bg.launch {
            try {
                val o = org.json.JSONObject()
                    .put("n", p.name).put("p", p.phone).put("a", p.avatar).put("b", p.about).put("u", p.username)
                java.io.File(d, "${p.uid}.json").writeText(o.toString())
            } catch (e: Throwable) {}
        }
    }

    /** Bellek/disk önbelleğindeki profil (senkron) */
    fun peekProfile(uid: String): UserProfile? =
        profileCache[uid] ?: diskProfile(uid)?.also { profileCache[uid] = it }

    /** Kendi profil alanlarını günceller (name, about, avatar); güncel profili döner */
    suspend fun updateProfileFields(me: UserProfile, fields: Map<String, Any>): UserProfile {
        db.collection("users").document(me.uid).update(fields).await()
        profileCache.remove(me.uid)
        val np = me.copy(
            name = (fields["name"] as? String) ?: me.name,
            about = if (fields.containsKey("about")) (fields["about"] as? String ?: "") else me.about,
            avatar = if (fields.containsKey("avatar")) (fields["avatar"] as? String ?: "") else me.avatar
        )
        cacheProfile(np)
        return np
    }

    /** Başka bir kullanıcının adı ve avatarı (bellekte önbelleklenir) */
    suspend fun profileOf(uid: String): UserProfile {
        profileCache[uid]?.let { return it }
        diskProfile(uid)?.let { profileCache[uid] = it; return it }
        val p = try {
            val d = db.collection("users").document(uid).get().await()
            UserProfile(uid, d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("avatar") ?: "", d.getString("about") ?: "")
        } catch (e: Exception) {
            UserProfile(uid, "")
        }
        if (p.name.isNotBlank() || p.avatar.isNotBlank()) { profileCache[uid] = p; saveProfile(p) }
        return p
    }

    suspend fun avatarOf(uid: String): String = profileOf(uid).avatar

    /** Bir kullanıcının profilini canlı izler: ad/avatar değişince her yer kendiliğinden güncellenir */
    fun profileFlow(uid: String): Flow<UserProfile?> = callbackFlow {
        peekProfile(uid)?.let { trySend(it) }
        val reg = db.collection("users").document(uid).addSnapshotListener { d, _ ->
            if (d != null && d.exists()) {
                val p = UserProfile(
                    uid, d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("avatar") ?: "",
                    d.getString("about") ?: "", d.getString("username") ?: ""
                )
                if (p.name.isNotBlank()) { profileCache[uid] = p; saveProfile(p) }
                trySend(p)
            } else trySend(null)
        }
        awaitClose { reg.remove() }
    }

    @Volatile private var usersCache: List<UserProfile>? = null
    fun cachedUsers(): List<UserProfile>? = usersCache

    /** Tüm kullanıcılar canlı: ad / avatar değişince kişiler ekranı kendiliğinden güncellenir */
    fun usersFlow(myUid: String): Flow<List<UserProfile>> = callbackFlow {
        usersCache?.let { trySend(it) }
        val reg = db.collection("users").addSnapshotListener { snap, _ ->
            if (snap == null) return@addSnapshotListener
            val list = snap.documents.mapNotNull { d ->
                val name = d.getString("name") ?: return@mapNotNull null
                if (d.id == myUid || name.isBlank()) null
                else UserProfile(d.id, name, d.getString("phone") ?: "", d.getString("avatar") ?: "", d.getString("about") ?: "")
            }.sortedBy { it.name.lowercase() }
            usersCache = list
            trySend(list)
        }
        awaitClose { reg.remove() }
    }

    suspend fun loadUsers(myUid: String): List<UserProfile> {
        val snap = db.collection("users").get().await()
        return snap.documents.mapNotNull { d ->
            val name = d.getString("name") ?: return@mapNotNull null
            if (d.id == myUid || name.isBlank()) null
            else UserProfile(d.id, name, d.getString("phone") ?: "", d.getString("avatar") ?: "", d.getString("about") ?: "")
        }.sortedBy { it.name.lowercase() }
    }

    // ---------- Sohbet listesi ----------
    private fun summaryRef(uid: String, chatId: String) =
        db.collection("users").document(uid).collection("chats").document(chatId)

    fun chatsFlow(uid: String): Flow<List<ChatSummary>> = callbackFlow {
        val reg = db.collection("users").document(uid).collection("chats")
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.map { d ->
                    val group = d.getBoolean("isGroup") ?: !isDirect(d.id)
                    ChatSummary(
                        chatId = d.id,
                        isGroup = group,
                        otherUid = if (group) d.id else (d.getString("otherUid") ?: ""),
                        name = if (group) (d.getString("groupName") ?: "Grup") else (d.getString("otherName") ?: ""),
                        lastMessage = d.getString("lastMessage") ?: "",
                        lastTime = d.ts("lastMessageTime"),
                        lastSenderUid = d.getString("lastSenderUid") ?: "",
                        lastSenderName = d.getString("lastSenderName") ?: "",
                        lastRead = d.getBoolean("lastMessageRead") ?: false,
                        unread = (d.getLong("unreadCount") ?: 0L).toInt(),
                        pinned = d.getBoolean("pinned") ?: false,
                        favorite = d.getBoolean("archived") ?: false,
                        typing = d.getBoolean("typing") ?: false,
                        clearedAt = d.ts("clearedAt"),
                        muted = (d.getBoolean("muted") ?: false) && ((d.getLong("mutedUntil") ?: 0L).let { it <= 0L || it > System.currentTimeMillis() }),
                        keepRow = d.getBoolean("keepRow") ?: false,
                        archivedChat = d.getBoolean("chatArchived") ?: false,
                        archivedAt = d.ts("chatArchivedAt")
                    )
                } ?: emptyList()
                if (snap != null) { list.forEach { if (it.clearedAt > 0L) clearedMap[it.chatId] = it.clearedAt }; cacheChats(uid, list) }
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    fun clearedAtFlow(uid: String, chatId: String): Flow<Long> = callbackFlow {
        val reg = summaryRef(uid, chatId).addSnapshotListener { snap, _ ->
            val v = snap?.ts("clearedAt") ?: 0L
            clearedMap[chatId] = v
            trySend(v)
        }
        awaitClose { reg.remove() }
    }

    /** Hesabı siler. null = tamam, "RELOGIN" = güvenlik için yeniden giriş gerekli */
    suspend fun deleteAccount(uid: String): String? {
        val user = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser ?: return "Oturum yok"
        val tok = user.getIdToken(true).await()
        if (System.currentTimeMillis() - tok.authTimestamp * 1000L > 5 * 60_000L) return "RELOGIN"
        try {
            val u = db.collection("users").document(uid)
            for (sub in listOf("chats", "starred")) {
                u.collection(sub).get().await().documents.forEach { try { it.reference.delete().await() } catch (e: Throwable) {} }
            }
            try { db.collection("presence").document(uid).delete().await() } catch (e: Throwable) {}
            u.delete().await()
        } catch (e: Throwable) { return "Veriler silinemedi" }
        return try { user.delete().await(); null } catch (e: Throwable) { "Hesap silinemedi" }
    }

    fun setPinned(me: String, chatId: String, pinned: Boolean) {
        summaryRef(me, chatId).update("pinned", pinned)
    }

    fun setChatArchived(me: String, chatId: String, v: Boolean) {
        summaryRef(me, chatId).set(mapOf("chatArchived" to v, "chatArchivedAt" to FieldValue.serverTimestamp()), SetOptions.merge())
    }

    fun setFavorite(me: String, chatId: String, fav: Boolean) {
        summaryRef(me, chatId).update("archived", fav)
    }

    // ---------- Kişi bilgisi: favori / sessiz / engel / süreli mesaj / temizle ----------
    data class ChatFlags(val exists: Boolean, val fav: Boolean, val muted: Boolean)

    fun chatFlagsFlow(uid: String, chatId: String): Flow<ChatFlags> = callbackFlow {
        val reg = summaryRef(uid, chatId).addSnapshotListener { snap, _ ->
            trySend(ChatFlags(snap?.exists() == true, snap?.getBoolean("archived") ?: false, ((snap?.getBoolean("muted") ?: false) && ((snap?.getLong("mutedUntil") ?: 0L).let { it <= 0L || it > System.currentTimeMillis() }))))
        }
        awaitClose { reg.remove() }
    }

    /** Süreli mesaj ayarı (ms, 0 = kapalı) */
    fun disappearFlow(chatId: String): Flow<Long> = callbackFlow {
        val reg = db.collection("chats").document(chatId).addSnapshotListener { snap, _ ->
            trySend(snap?.getLong("disappearAfter") ?: 0L)
        }
        awaitClose { reg.remove() }
    }

    /** Durum şikayeti: "reports" koleksiyonuna yazar (kural izin vermezse sessizce geçer) */
    fun reportStatus(me: String, owner: String, statusId: String) {
        try {
            db.collection("reports").add(mapOf("by" to me, "owner" to owner, "statusId" to statusId, "at" to System.currentTimeMillis()))
        } catch (e: Throwable) {}
    }

    /** untilMs > 0 ise sessize alma o zamana kadar sürer (8 saat / 1 hafta), 0 = her zaman */
    fun setMuted(me: String, chatId: String, muted: Boolean, untilMs: Long = 0L) {
        summaryRef(me, chatId).set(mapOf("muted" to muted, "mutedUntil" to (if (muted) untilMs else 0L)), SetOptions.merge())
    }

    fun setGroupPhoto(groupId: String, dataUrl: String) {
        db.collection("groups").document(groupId).update("photo", dataUrl)
    }

    fun blockedFlow(uid: String): Flow<List<String>> = callbackFlow {
        val reg = db.collection("users").document(uid).addSnapshotListener { snap, _ ->
            trySend((snap?.get("blockedUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList())
        }
        awaitClose { reg.remove() }
    }

    fun setBlocked(me: String, other: String, blocked: Boolean) {
        db.collection("users").document(me).update(
            "blockedUids", if (blocked) FieldValue.arrayUnion(other) else FieldValue.arrayRemove(other)
        )
    }

    /** Süreli mesajlar (yeni mesajlar için); web ile aynı alan ve sistem mesajı */
    fun setDisappearAfter(chatId: String, myName: String, myUid: String, ms: Long) {
        db.collection("chats").document(chatId).set(mapOf("disappearAfter" to ms), SetOptions.merge())
        val label = if (ms >= 7 * 24 * 3600 * 1000L) "7 gün" else "24 saat"
        val text = if (ms > 0) "$myName süreli mesajları açtı: yeni mesajlar $label sonra silinir" else "$myName süreli mesajları kapattı"
        db.collection("chats").document(chatId).collection("messages").add(
            mapOf("type" to "system", "text" to text, "senderUid" to myUid, "senderName" to myName,
                "createdAt" to FieldValue.serverTimestamp(), "read" to false)
        )
    }

    /** Sohbetin içini temizler, liste satırı kalır (web wipeChat ile aynı) */
    fun wipeChat(me: String, chatId: String) {
        clearedMap[chatId] = System.currentTimeMillis()
        bg.launch { LocalDb.clearChat(chatId) }
        summaryRef(me, chatId).set(
            mapOf("clearedAt" to FieldValue.serverTimestamp(), "keepRow" to true, "lastMessage" to "",
                "unreadCount" to 0, "hasMention" to false),
            SetOptions.merge()
        )
    }

    /** Sohbeti listeden sil: kalıcı olarak "clearedAt" yazılır, eski mesajlar bir daha yüklenmez */
    fun clearChat(me: String, chatId: String) {
        clearedMap[chatId] = System.currentTimeMillis()
        bg.launch { LocalDb.clearChat(chatId) }
        summaryRef(me, chatId).set(
            mapOf("clearedAt" to FieldValue.serverTimestamp(), "keepRow" to false, "unreadCount" to 0, "pinned" to false),
            SetOptions.merge()
        )
    }

    /** Yedekten dönen sohbetleri listeye geri getirir (silme/temizleme işaretini kaldırır) */
    fun restoreChats(me: String, rows: List<Array<String>>) {
        val last = HashMap<String, Message>()
        for (r in rows) {
            val m = LocalDb.parse(r[3]) ?: continue
            if (m.deleted || m.deletedFor.contains(me)) continue
            val cur = last[r[0]]
            if (cur == null || m.time >= cur.time) last[r[0]] = m
        }
        last.forEach { (chatId, m) ->
            clearedMap.remove(chatId)
            val f = HashMap<String, Any>()
            f["clearedAt"] = FieldValue.delete()
            f["keepRow"] = false
            f["lastMessage"] = previewOf(m)
            if (m.time > 0L) f["lastMessageTime"] = com.google.firebase.Timestamp(java.util.Date(m.time))
            f["lastSenderUid"] = m.senderUid
            f["lastMessageRead"] = true
            if (isDirect(chatId)) f["otherUid"] = chatId.split("_").firstOrNull { it != me } ?: ""
            summaryRef(me, chatId).set(f, SetOptions.merge())
        }
    }

    // ---------- Yerel depolama yardımcıları (arka plan iş parçacığında çağrılır) ----------
    /** Telefona yazılan medyanın Firebase'deki kopyasını siler */
    fun ackMediaBlocking(chatId: String, msgId: String, upd: Map<String, Any?>) {
        try {
            com.google.android.gms.tasks.Tasks.await(
                db.collection("chats").document(chatId).collection("messages").document(msgId).update(upd),
                10, java.util.concurrent.TimeUnit.SECONDS
            )
        } catch (e: Throwable) {}
    }

    fun fetchMessageBlocking(chatId: String, msgId: String): Message? = try {
        com.google.android.gms.tasks.Tasks.await(
            db.collection("chats").document(chatId).collection("messages").document(msgId).get(),
            12, java.util.concurrent.TimeUnit.SECONDS
        ).takeIf { it.exists() }?.toMessage()
    } catch (e: Throwable) { null }

    /** Sohbetin son mesajlarını okundu yapar (bildirimdeki "Okundu olarak işaretle" için) */
    suspend fun markChatRead(me: String, t: ChatTarget) {
        val snap = db.collection("chats").document(t.chatId).collection("messages")
            .orderBy("createdAt", Query.Direction.DESCENDING).limit(60).get().await()
        markRead(me, t, snap.documents.map { it.toMessage() })
    }

    // ---------- Mesajlar ----------
    private fun DocumentSnapshot.toMessage(): Message {
        val reply = (get("replyTo") as? Map<*, *>)?.let { m ->
            ReplyRef(
                msgId = m["msgId"] as? String ?: "",
                senderName = m["senderName"] as? String ?: "",
                previewText = m["previewText"] as? String ?: "",
                senderUid = m["senderUid"] as? String ?: ""
            )
        }
        val reactions = HashMap<String, String>()
        (get("reactions") as? Map<*, *>)?.forEach { (k, v) ->
            if (k is String && v is String) reactions[k] = v
        }
        val images = (get("images") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
        val lat = getDouble("lat")
        val lng = getDouble("lng")
        return Message(
            id = id,
            type = getString("type") ?: "text",
            text = getString("text") ?: "",
            senderUid = getString("senderUid") ?: "",
            senderName = getString("senderName") ?: "",
            time = ts("createdAt"),
            read = getBoolean("read") ?: false,
            readBy = (get("readBy") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            deleted = getBoolean("deleted") ?: false,
            deletedFor = (get("deletedFor") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            pending = metadata.hasPendingWrites(),
            imageUrl = getString("imageUrl") ?: "",
            images = images,
            imagesCount = (getLong("imagesCount") ?: 0L).toInt(),
            audio = getString("audio") ?: "",
            audioDuration = (getLong("audioDuration") ?: 0L).toInt(),
            lat = lat ?: 0.0,
            lng = lng ?: 0.0,
            hasLocation = lat != null && lng != null,
            fileName = getString("fileName") ?: "",
            fileMime = getString("fileMime") ?: "",
            replyTo = reply,
            reactions = reactions,
            edited = getBoolean("edited") ?: false,
            forwarded = getBoolean("forwarded") ?: false,
            callDuration = (getLong("duration") ?: 0L).toInt(),
            callType = getString("callType") ?: "",
            viewOnce = getBoolean("viewOnce") ?: false,
            imageDelivered = getBoolean("imageDelivered") ?: false,
            imagesDelivered = getBoolean("imagesDelivered") ?: false,
            audioDelivered = getBoolean("audioDelivered") ?: false,
            question = getString("question") ?: "",
            pollOptions = parsePollOptions(get("options")),
            pollMulti = getBoolean("multi") ?: false,
            mentions = (get("mentions") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            mentionNames = (get("mentionNames") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            votes = parseVotes(get("votes")),
            thumb = getString("thumb") ?: "",
            thumbs = (get("thumbs") as? List<*>)?.map { (it as? String) ?: "" } ?: emptyList(),
            linkPreview = (get("linkPreview") as? Map<*, *>)?.let { lp ->
                val u = lp["url"] as? String
                if (u.isNullOrBlank()) null
                else LinkPreview(u, (lp["title"] as? String) ?: "", (lp["description"] as? String) ?: "", (lp["image"] as? String) ?: "")
            }
        )
    }

    private fun parsePollOptions(raw: Any?): List<PollOption> {
        val out = ArrayList<PollOption>()
        if (raw is List<*>) {
            for (o in raw) {
                if (o is Map<*, *>) {
                    val id = o["id"] as? String
                    if (id != null) out.add(PollOption(id, (o["text"] as? String) ?: ""))
                }
            }
        }
        return out
    }

    private fun parseVotes(raw: Any?): Map<String, List<String>> {
        val out = HashMap<String, List<String>>()
        if (raw is Map<*, *>) {
            for ((k, v) in raw) {
                if (k is String && v is List<*>) out[k] = v.filterIsInstance<String>()
            }
        }
        return out
    }

    /** En yeni en başta */
    fun messagesFlow(chatId: String, limit: Long): Flow<List<Message>> = callbackFlow {
        val gotSnap = java.util.concurrent.atomic.AtomicBoolean(false)
        // Önce yerel veritabanından anında göster
        launch(Dispatchers.IO) {
            val local = LocalDb.recent(chatId, limit.toInt())
            if (local.isNotEmpty() && !gotSnap.get()) trySend(local)
        }
        val reg = db.collection("chats").document(chatId).collection("messages")
            .orderBy("createdAt", Query.Direction.DESCENDING).limit(limit)
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.map { it.toMessage() } ?: emptyList()
                gotSnap.set(true)
                trySend(list)
                if (snap != null && list.isNotEmpty()) bg.launch {
                    LocalDb.upsert(chatId, list)
                    if (!snap.metadata.isFromCache && !snap.metadata.hasPendingWrites() && list.size.toLong() < limit) {
                        LocalDb.pruneWindow(chatId, 0L, list.map { it.id }.toSet())
                    } else if (!snap.metadata.isFromCache && !snap.metadata.hasPendingWrites()) {
                        LocalDb.pruneWindow(chatId, list.minOf { it.time }, list.map { it.id }.toSet())
                    }
                }
            }
        awaitClose { reg.remove() }
    }

    fun typingFlow(chatId: String, otherUid: String): Flow<Boolean> = callbackFlow {
        val reg = db.collection("chats").document(chatId).addSnapshotListener { snap, _ ->
            trySend(snap?.getBoolean("typing_$otherUid") ?: false)
        }
        awaitClose { reg.remove() }
    }

    /** Karşı tarafın çevrimiçi/son görülme bilgisi (presence/{uid}); gizliyse null */
    data class Presence(val online: Boolean, val lastSeenMs: Long)

    fun presenceFlow(uid: String): Flow<Presence?> = callbackFlow {
        val reg = db.collection("presence").document(uid).addSnapshotListener { snap, _ ->
            if (snap != null && snap.exists() && snap.getBoolean("hidden") != true) {
                trySend(Presence(snap.getBoolean("online") ?: false, snap.ts("lastSeen")))
            } else {
                trySend(null)
            }
        }
        awaitClose { reg.remove() }
    }

    @Volatile private var presenceHidden = false
    @Volatile private var receiptsHidden = false

    fun isPresenceHidden() = presenceHidden
    fun isReceiptsHidden() = receiptsHidden

    fun syncPresenceHidden(uid: String) {
        db.collection("presence").document(uid).get().addOnSuccessListener {
            presenceHidden = it.getBoolean("hidden") == true
            receiptsHidden = it.getBoolean("hideReceipts") == true
        }
    }

    fun setPresenceHidden(uid: String, hidden: Boolean) {
        presenceHidden = hidden
        val ref = db.collection("presence").document(uid)
        if (hidden) {
            ref.set(mapOf("hidden" to true, "online" to false, "lastSeen" to FieldValue.delete()), SetOptions.merge())
        } else {
            ref.set(mapOf("hidden" to false), SetOptions.merge()).addOnSuccessListener { writePresence(uid, true) }
        }
    }

    fun setReceiptsHidden(uid: String, hidden: Boolean) {
        receiptsHidden = hidden
        db.collection("presence").document(uid).set(mapOf("hideReceipts" to hidden), SetOptions.merge())
    }

    fun writePresence(uid: String, online: Boolean) {
        if (presenceHidden) return
        db.collection("presence").document(uid).set(
            mapOf("online" to online, "lastSeen" to FieldValue.serverTimestamp()),
            SetOptions.merge()
        )
    }

    /** Grupta şu an yazan diğer üyelerin uid'leri (chats/{id}.typing_<uid>) */
    fun groupTypingFlow(chatId: String, me: String): Flow<List<String>> = callbackFlow {
        val reg = db.collection("chats").document(chatId).addSnapshotListener { snap, _ ->
            val out = ArrayList<String>()
            snap?.data?.forEach { (k, v) ->
                if (k.startsWith("typing_") && v == true && k.removePrefix("typing_") != me) out.add(k.removePrefix("typing_"))
            }
            trySend(out)
        }
        awaitClose { reg.remove() }
    }

    fun setTyping(me: String, t: ChatTarget, typing: Boolean) {
        db.collection("chats").document(t.chatId)
            .set(mapOf("typing_$me" to typing), SetOptions.merge())
        if (!t.isGroup) {
            summaryRef(t.otherUid, t.chatId)
                .update(mapOf("typing" to typing, "typingAt" to System.currentTimeMillis()))
        }
    }

    /** Karşıdan gelen okunmamış mesajları okundu yapar ve listedeki rozeti sıfırlar. */
    fun markRead(me: String, t: ChatTarget, messages: List<Message>) {
        val unread = messages.filter {
            it.senderUid != me && !it.pending && it.type != "system" &&
                (if (t.isGroup) !it.readBy.contains(me) else !it.read)
        }
        if (!receiptsHidden) unread.forEach {
            val upd = HashMap<String, Any>()
            upd["readBy"] = FieldValue.arrayUnion(me)
            if (!t.isGroup) upd["read"] = true
            db.collection("chats").document(t.chatId).collection("messages").document(it.id).update(upd)
        }
        summaryRef(me, t.chatId).update(mapOf("unreadCount" to 0, "hasMention" to false))
        if (unread.isNotEmpty() && !t.isGroup && !receiptsHidden) {
            summaryRef(t.otherUid, t.chatId).update("lastMessageRead", true)
        }
    }

    // ---------- Aramalar (kayıtlar + bildirim) ----------
    fun callsFlow(uid: String): Flow<List<CallLog>> = callbackFlow {
        val reg = db.collection("users").document(uid).collection("calls")
            .orderBy("at", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener { snap, _ ->
                if (snap == null) return@addSnapshotListener
                trySend(snap.documents.map { d ->
                    CallLog(
                        id = d.id,
                        otherUid = d.getString("otherUid") ?: "",
                        otherName = d.getString("otherName") ?: "",
                        callType = d.getString("callType") ?: "video",
                        result = d.getString("result") ?: "",
                        duration = (d.getLong("duration") ?: 0L).toInt(),
                        at = d.getLong("at") ?: 0L,
                        direction = d.getString("direction") ?: "in"
                    )
                })
            }
        awaitClose { reg.remove() }
    }

    private suspend fun writeCallEntries(
        chatId: String, callerUid: String, calleeUid: String, callerName: String, calleeName: String,
        callType: String, result: String, duration: Int, fromUid: String
    ) {
        try {
            val at = System.currentTimeMillis()
            val cid = chatId + "_" + result + "_" + (at / 60000L)
            val base = HashMap<String, Any>()
            base["callType"] = callType
            base["result"] = result
            base["duration"] = duration
            base["at"] = at
            base["fromUid"] = fromUid
            val outMap = HashMap<String, Any>(base)
            outMap["otherUid"] = calleeUid
            outMap["otherName"] = calleeName
            outMap["direction"] = "out"
            val inMap = HashMap<String, Any>(base)
            inMap["otherUid"] = callerUid
            inMap["otherName"] = callerName
            inMap["direction"] = "in"
            try { db.collection("users").document(callerUid).collection("calls").document(cid).set(outMap, SetOptions.merge()).await() } catch (e: Exception) {}
            try { db.collection("users").document(calleeUid).collection("calls").document(cid).set(inMap, SetOptions.merge()).await() } catch (e: Exception) {}
        } catch (e: Exception) {}
    }

    private suspend fun writeCallMessage(
        chatId: String, msgType: String, callType: String, senderUid: String, senderName: String,
        read: Boolean, duration: Int, label: String, callerUid: String, calleeUid: String, unreadForCallee: Boolean
    ) {
        try {
            val m = HashMap<String, Any>()
            m["type"] = msgType
            m["callType"] = callType
            m["text"] = ""
            m["senderUid"] = senderUid
            m["senderName"] = senderName
            m["createdAt"] = FieldValue.serverTimestamp()
            m["read"] = read
            if (duration > 0) m["duration"] = duration
            db.collection("chats").document(chatId).collection("messages").add(m).await()
            val mine = hashMapOf<String, Any>(
                "lastMessage" to label,
                "lastMessageTime" to FieldValue.serverTimestamp(),
                "lastSenderUid" to senderUid,
                "lastMessageRead" to read,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val theirs = HashMap<String, Any>(mine)
            if (unreadForCallee) theirs["unreadCount"] = FieldValue.increment(1)
            db.collection("users").document(callerUid).collection("chats").document(chatId).set(mine, SetOptions.merge()).await()
            db.collection("users").document(calleeUid).collection("chats").document(chatId).set(theirs, SetOptions.merge()).await()
        } catch (e: Exception) {}
    }

    suspend fun logMissedCall(chatId: String, callerUid: String, callerName: String, calleeUid: String, calleeName: String, callType: String) {
        writeCallEntries(chatId, callerUid, calleeUid, callerName, calleeName, callType, "missed", 0, callerUid)
        val label = if (callType == "audio") "📞 Cevapsız sesli arama" else "📹 Cevapsız görüntülü arama"
        writeCallMessage(chatId, "missed_call", callType, callerUid, callerName, false, 0, label, callerUid, calleeUid, true)
    }

    suspend fun logDeclinedCall(chatId: String, callerUid: String, callerName: String, calleeUid: String, calleeName: String, callType: String) {
        writeCallEntries(chatId, callerUid, calleeUid, callerName, calleeName, callType, "declined", 0, calleeUid)
        val label = if (callType == "audio") "📞 Reddedilen sesli arama" else "📹 Reddedilen görüntülü arama"
        writeCallMessage(chatId, "declined_call", callType, callerUid, callerName, false, 0, label, callerUid, calleeUid, true)
    }

    suspend fun logCallDuration(
        chatId: String, myUid: String, myName: String, otherUid: String, otherName: String,
        callType: String, seconds: Int, callerUid: String
    ) {
        val calleeUid = if (callerUid == myUid) otherUid else myUid
        val callerName = if (callerUid == myUid) myName else otherName
        val calleeName = if (callerUid == myUid) otherName else myName
        writeCallEntries(chatId, callerUid, calleeUid, callerName, calleeName, callType, "answered", seconds, myUid)
        val m = seconds / 60
        val r = seconds % 60
        val dur = if (m == 0) "$r sn" else if (r != 0) "$m dk $r sn" else "$m dk"
        val label = (if (callType == "audio") "📞 Sesli arama" else "📹 Görüntülü arama") + " • " + dur
        writeCallMessage(chatId, "call_duration", callType, myUid, myName, true, seconds, label, myUid, otherUid, false)
    }

    /** Kullanıcı şikayeti: sunucuya (api/report) gönderilir, yönetici panelinde listelenir */
    suspend fun sendReport(chatId: String, reportedUid: String, reportedName: String, isGroup: Boolean, reporterName: String, reason: String, note: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val idToken = auth.currentUser?.getIdToken(false)?.await()?.token ?: return@withContext false
                val payload = JSONObject().put("chatId", chatId).put("reportedUid", reportedUid).put("reportedName", reportedName)
                    .put("isGroup", isGroup).put("reporterName", reporterName).put("reason", reason).put("note", note)
                val c = URL("https://aurachat-amber.vercel.app/api/report").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 10000; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer $idToken")
                c.outputStream.use { it.write(payload.toString().toByteArray()) }
                val ok = c.responseCode in 200..299
                c.disconnect()
                ok
            } catch (e: Exception) { false }
        }

    /** Arama bildirimi (kind=call) ya da cevapsız arama bildirimi gönderir */
    suspend fun sendCallPush(
        receiverUid: String, title: String, body: String, chatId: String, otherUid: String,
        otherName: String, callType: String, ringing: Boolean
    ) {
        withContext(Dispatchers.IO) {
            try {
                val idToken = auth.currentUser?.getIdToken(false)?.await()?.token ?: return@withContext
                val data = JSONObject()
                    .put("chatId", chatId)
                    .put("otherUid", otherUid)
                    .put("otherName", otherName)
                if (ringing) {
                    data.put("kind", "call").put("callType", callType).put("callerName", otherName)
                }
                val payload = JSONObject()
                    .put("receiverUid", receiverUid)
                    .put("title", title.take(100))
                    .put("body", body.take(200))
                    .put("data", data)
                    .put("tag", "call_$chatId")
                val c = URL(API).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer $idToken")
                c.outputStream.use { it.write(payload.toString().toByteArray()) }
                c.responseCode
                c.disconnect()
            } catch (ignored: Exception) {
            }
        }
    }

    // ---------- Durum (statuses/{id} + statusMedia/{id}) ----------
    private val statusMediaCache = ConcurrentHashMap<String, String>()

    fun statusesFlow(): Flow<List<StatusItem>> = callbackFlow {
        val reg = db.collection("statuses")
            .whereGreaterThan("expiresAt", System.currentTimeMillis())
            .addSnapshotListener { snap, _ ->
                if (snap == null) return@addSnapshotListener
                val list = snap.documents.mapNotNull { d ->
                    val uid = d.getString("uid") ?: return@mapNotNull null
                    StatusItem(
                        id = d.id,
                        uid = uid,
                        type = d.getString("type") ?: "text",
                        text = d.getString("text") ?: "",
                        bg = d.getString("bg") ?: "",
                        caption = d.getString("caption") ?: "",
                        createdAt = d.getLong("createdAt") ?: 0L,
                        expiresAt = d.getLong("expiresAt") ?: 0L,
                        viewers = (d.get("viewers") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                        hasImage = d.getBoolean("hasImage") ?: false
                    )
                }
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    suspend fun loadStatusMedia(id: String): String {
        statusMediaCache[id]?.let { return it }
        return try {
            val d = db.collection("statusMedia").document(id).get().await()
            (d.getString("image") ?: "").also { if (it.isNotEmpty()) statusMediaCache[id] = it }
        } catch (e: Exception) {
            ""
        }
    }

    suspend fun postStatus(me: UserProfile, type: String, text: String, bg: String, caption: String, image: String?) {
        val ref = db.collection("statuses").document()
        val now = System.currentTimeMillis()
        if (!image.isNullOrEmpty()) {
            db.collection("statusMedia").document(ref.id).set(mapOf("uid" to me.uid, "image" to image)).await()
            statusMediaCache[ref.id] = image
        }
        val data = HashMap<String, Any>()
        data["uid"] = me.uid
        data["type"] = type
        data["text"] = text
        data["bg"] = bg
        data["caption"] = caption
        data["createdAt"] = now
        data["expiresAt"] = now + 24L * 60 * 60 * 1000
        data["viewers"] = emptyList<String>()
        data["hasImage"] = !image.isNullOrEmpty()
        ref.set(data).await()
    }

    suspend fun deleteStatus(id: String) {
        try { db.collection("statusMedia").document(id).delete().await() } catch (e: Exception) {}
        db.collection("statuses").document(id).delete().await()
        statusMediaCache.remove(id)
    }

    fun markStatusViewed(id: String, me: String) {
        db.collection("statuses").document(id).update("viewers", FieldValue.arrayUnion(me))
    }

    /** Süresi dolmuş kendi durumlarımı temizler */
    fun cleanupMyStatuses(me: String) {
        bg.launch {
            try {
                val snap = db.collection("statuses").whereEqualTo("uid", me).get().await()
                val now = System.currentTimeMillis()
                for (d in snap.documents) {
                    if ((d.getLong("expiresAt") ?: 0L) <= now) {
                        try { db.collection("statusMedia").document(d.id).delete().await() } catch (e: Exception) {}
                        try { d.reference.delete().await() } catch (e: Exception) {}
                    }
                }
            } catch (e: Exception) {}
        }
    }

    // ---------- Gönderme ----------
    private fun replyMap(r: ReplyRef): Map<String, Any> =
        HashMap<String, Any>().apply {
            put("msgId", r.msgId); put("senderName", r.senderName)
            put("previewText", r.previewText); put("senderUid", r.senderUid)
            if (r.isStatus) put("isStatus", true)
        }

    suspend fun loadGroup(groupId: String): GroupData? {
        val d = db.collection("groups").document(groupId).get().await()
        return if (d.exists()) d.toGroup() else null
    }

    private fun DocumentSnapshot.toGroup() = GroupData(
        id = id,
        name = getString("name") ?: "Grup",
        members = (get("members") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
        admins = (get("admins") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
        createdBy = getString("createdBy") ?: "",
        photo = getString("photo") ?: ""
    )

    private val groupCache = ConcurrentHashMap<String, GroupData>()

    /** Bellek/disk önbelleğindeki grup (ad + fotoğraf) – ağı beklemeden gösterilir */
    fun peekGroup(id: String): GroupData? {
        groupCache[id]?.let { return it }
        val f = java.io.File(profDir ?: return null, "g_$id.json")
        if (!f.exists()) return null
        return try {
            val o = org.json.JSONObject(f.readText())
            fun l(k: String): List<String> { val a = o.optJSONArray(k) ?: return emptyList(); return (0 until a.length()).map { a.optString(it) } }
            GroupData(id, o.optString("n"), l("m"), l("a"), o.optString("c"), o.optString("p")).also { groupCache[id] = it }
        } catch (e: Throwable) { null }
    }

    private fun saveGroup(g: GroupData) {
        groupCache[g.id] = g
        val d = profDir ?: return
        bg.launch {
            try {
                val o = org.json.JSONObject().put("n", g.name).put("m", org.json.JSONArray(g.members))
                    .put("a", org.json.JSONArray(g.admins)).put("c", g.createdBy).put("p", g.photo)
                java.io.File(d, "g_${g.id}.json").writeText(o.toString())
            } catch (e: Throwable) {}
        }
    }

    fun groupFlow(groupId: String): Flow<GroupData?> = callbackFlow {
        peekGroup(groupId)?.let { trySend(it) }
        val reg = db.collection("groups").document(groupId).addSnapshotListener { snap, _ ->
            val g = if (snap != null && snap.exists()) snap.toGroup() else null
            if (g != null) saveGroup(g)
            trySend(g)
        }
        awaitClose { reg.remove() }
    }

    /**
     * Tek mesaj yazma yolu: mesaj + sohbet özetleri tek paket, ardından bildirim.
     * Sunucuya ulaşana kadar bekler; arayüz yerel önbellekten anında gösterir.
     */
    suspend fun postMessage(
        me: UserProfile,
        t: ChatTarget,
        fields: Map<String, Any>,
        summary: String,
        pushBody: String,
        msgType: String = "text",
        mentions: List<String> = emptyList()
    ): String {
        val msgRef = db.collection("chats").document(t.chatId).collection("messages").document()
        val data = HashMap<String, Any>(fields)
        data["senderUid"] = me.uid
        data["senderName"] = me.name
        data["createdAt"] = FieldValue.serverTimestamp()
        data["read"] = false

        val batch = db.batch()
        batch.set(msgRef, data)

        var group: GroupData? = null
        if (t.isGroup) {
            group = loadGroup(t.chatId) ?: throw IllegalStateException("Grup bulunamadı")
            for (m in group.members) {
                batch.set(
                    summaryRef(m, t.chatId),
                    mapOf(
                        "isGroup" to true,
                        "groupName" to group.name,
                        "lastMessage" to summary,
                        "lastMessageTime" to FieldValue.serverTimestamp(),
                        "lastSenderUid" to me.uid,
                        "lastSenderName" to me.name,
                        "lastMessageRead" to false,
                        "unreadCount" to (if (m == me.uid) 0 else FieldValue.increment(1)),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    SetOptions.merge()
                )
            }
        } else {
            batch.set(
                summaryRef(me.uid, t.chatId),
                mapOf(
                    "otherUid" to t.otherUid,
                    "otherName" to t.name,
                    "lastMessage" to summary,
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastMessageRead" to false,
                    "unreadCount" to 0,
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
            batch.set(
                summaryRef(t.otherUid, t.chatId),
                mapOf(
                    "otherUid" to me.uid,
                    "otherName" to me.name,
                    "lastMessage" to summary,
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastMessageRead" to false,
                    "typing" to false,
                    "unreadCount" to FieldValue.increment(1),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
        if (group != null) {
            for (m in group.members) {
                if (mentions.contains(m) && m != me.uid) {
                    batch.set(summaryRef(m, t.chatId), mapOf("hasMention" to true), SetOptions.merge())
                }
            }
        }
        batch.commit().await()

        val msgId = msgRef.id
        if (group != null) {
            val g = group
            for (m in g.members) {
                if (m == me.uid) continue
                bg.launch {
                    notify(m, g.name, "${me.name}: $pushBody", t.chatId, t.chatId, g.name, if (mentions.contains(m)) "mention" else msgType, msgId)
                }
            }
        } else {
            bg.launch { notify(t.otherUid, me.name, pushBody, t.chatId, me.uid, me.name, msgType, msgId) }
        }
        return msgId
    }

    suspend fun sendText(
        me: UserProfile, t: ChatTarget, text: String, reply: ReplyRef?,
        mentions: List<String> = emptyList(), mentionNames: List<String> = emptyList(),
        preview: LinkPreview? = null, noPreview: Boolean = false
    ) {
        val f = HashMap<String, Any>()
        f["type"] = "text"
        f["text"] = text
        if (mentions.isNotEmpty()) { f["mentions"] = mentions; f["mentionNames"] = mentionNames }
        if (reply != null) f["replyTo"] = replyMap(reply)
        if (preview != null) f["linkPreview"] = mapOf("url" to preview.url, "title" to preview.title, "description" to preview.description, "image" to preview.image)
        val id = postMessage(me, t, f, text.take(100), text.take(200), "text", mentions)
        val url = Regex("https?://[^\\s<>\"']+", RegexOption.IGNORE_CASE).find(text)?.value?.trimEnd('.', ',', ';', ':', '!', '?', ')', ']')
        if (url != null && id.isNotEmpty() && preview == null && !noPreview) attachLinkPreview(t.chatId, id, url)
    }

    /** Linkin başlık/açıklama/resim bilgisini sunucudan alıp mesaja yazar (web ile aynı API) */
    suspend fun fetchLinkPreview(url: String): LinkPreview? {
        return withContext(Dispatchers.IO) {
            try {
                val host0 = try { android.net.Uri.parse(url).host?.lowercase() ?: "" } catch (e: Exception) { "" }
                if (host0.endsWith("tiktok.com")) {
                    // TikTok'un og:image adresi sunucuda 500 karakterde kesiliyor → oEmbed ile tam adresi al
                    try {
                        // vt.tiktok.com kısa bağlantısını gerçek video adresine çöz
                        var full = url
                        if (host0.startsWith("vt.") || host0.startsWith("vm.") || !url.contains("/video/")) {
                            val rc = URL(url).openConnection() as HttpURLConnection
                            rc.instanceFollowRedirects = true
                            rc.connectTimeout = 10000; rc.readTimeout = 15000
                            rc.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                            rc.connect()
                            full = rc.url.toString()
                            rc.disconnect()
                        }
                        full = full.substringBefore("?")
                        val oc = URL("https://www.tiktok.com/oembed?url=" + java.net.URLEncoder.encode(full, "UTF-8")).openConnection() as HttpURLConnection
                        oc.connectTimeout = 10000; oc.readTimeout = 15000
                        oc.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                        val ob = oc.inputStream.bufferedReader().readText(); oc.disconnect()
                        val oo = JSONObject(ob)
                        val thumb = oo.optString("thumbnail_url")
                        if (thumb.isNotBlank()) {
                            val author = oo.optString("author_name")
                            return@withContext LinkPreview(
                                url, "TikTok" + if (author.isNotBlank()) " · $author" else "", oo.optString("title"), thumb
                            )
                        }
                    } catch (e: Exception) {}
                }
                if (host0.endsWith("youtube.com") || host0 == "youtu.be") {
                    // YouTube sayfası çerez/onay sayfası döndürdüğü için başlık ve resim oEmbed + sabit küçük resim adresinden alınır
                    val u0 = android.net.Uri.parse(url)
                    val vid = if (host0 == "youtu.be") u0.lastPathSegment
                        else u0.getQueryParameter("v") ?: u0.pathSegments.let { sg -> if (sg.size >= 2 && (sg[0] == "shorts" || sg[0] == "embed" || sg[0] == "live")) sg[1] else null }
                    if (!vid.isNullOrBlank()) {
                        var title = ""; var author = ""
                        try {
                            val oc = URL("https://www.youtube.com/oembed?format=json&url=" + java.net.URLEncoder.encode("https://www.youtube.com/watch?v=$vid", "UTF-8")).openConnection() as HttpURLConnection
                            oc.connectTimeout = 10000; oc.readTimeout = 15000
                            oc.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                            val oo = JSONObject(oc.inputStream.bufferedReader().readText()); oc.disconnect()
                            title = oo.optString("title"); author = oo.optString("author_name")
                        } catch (e: Exception) {}
                        return@withContext LinkPreview(
                            url, title.ifBlank { "YouTube" }, if (author.isNotBlank()) "YouTube · $author" else "YouTube",
                            "https://i.ytimg.com/vi/$vid/hqdefault.jpg"
                        )
                    }
                }
                // Sayfayı telefondan çek, og:başlık / açıklama / resim bilgilerini oku (sunucuya gerek yok)
                val pc = URL(url).openConnection() as HttpURLConnection
                pc.instanceFollowRedirects = true
                pc.connectTimeout = 10000; pc.readTimeout = 15000
                pc.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36 facebookexternalhit/1.1")
                pc.setRequestProperty("Accept-Language", "tr,en;q=0.8")
                val ctype = pc.contentType ?: ""
                if (pc.responseCode !in 200..299 || (ctype.isNotEmpty() && !ctype.contains("html", true))) { pc.disconnect(); return@withContext null }
                val finalUrl = pc.url
                val bytes = pc.inputStream.use { ins ->
                    val bo = java.io.ByteArrayOutputStream()
                    val buf = ByteArray(8192)
                    while (bo.size() < 300_000) { val n = ins.read(buf); if (n < 0) break; bo.write(buf, 0, n) }
                    bo.toByteArray()
                }
                pc.disconnect()
                val html = String(bytes, Charsets.UTF_8)
                val head = html.substringBefore("</head>", html)
                fun meta(vararg keys: String): String {
                    for (k in keys) {
                        val kq = Regex.escape(k)
                        val r1 = Regex("<meta[^>]+(?:property|name)=[\"']$kq[\"'][^>]*content=[\"']([^\"']*)[\"']", RegexOption.IGNORE_CASE)
                        val r2 = Regex("<meta[^>]+content=[\"']([^\"']*)[\"'][^>]*(?:property|name)=[\"']$kq[\"']", RegexOption.IGNORE_CASE)
                        val v = r1.find(head)?.groupValues?.get(1) ?: r2.find(head)?.groupValues?.get(1)
                        if (!v.isNullOrBlank()) return android.text.Html.fromHtml(v, android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
                    }
                    return ""
                }
                var title = meta("og:title", "twitter:title")
                if (title.isBlank()) {
                    val t = Regex("<title[^>]*>([^<]*)</title>", RegexOption.IGNORE_CASE).find(head)?.groupValues?.get(1) ?: ""
                    title = android.text.Html.fromHtml(t, android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
                }
                val desc = meta("og:description", "twitter:description", "description")
                var image = meta("og:image", "og:image:url", "twitter:image", "twitter:image:src")
                if (image.isNotBlank()) image = try { URL(finalUrl, image).toString() } catch (e: Exception) { "" }
                if (title.isBlank() && desc.isBlank() && image.isBlank()) return@withContext null
                LinkPreview(url, title.take(140), desc.take(220), image)
            } catch (e: Exception) { null }
        }
    }

    private suspend fun attachLinkPreview(chatId: String, msgId: String, url: String) {
        val lp = fetchLinkPreview(url) ?: return
        try {
            msgRef(chatId, msgId).update("linkPreview", mapOf("url" to lp.url, "title" to lp.title, "description" to lp.description, "image" to lp.image)).await()
        } catch (e: Exception) {}
    }

    /** Yeni tepki: mesaj sahibine bildirim (web applyReaction ile aynı) */
    suspend fun reactNotify(me: UserProfile, t: ChatTarget, m: Message, emoji: String) {
        if (m.senderUid.isBlank() || m.senderUid == me.uid) return
        val title = if (t.isGroup) t.name.ifBlank { "Grup" } else me.name
        val body = "$emoji ${if (t.isGroup) me.name + " " else ""}mesajına tepki verdi: ${previewOf(m).take(80)}".trim()
        notify(m.senderUid, title, body, t.chatId, if (t.isGroup) t.chatId else me.uid, title, "reaction", "")
    }

    suspend fun sendImages(
        me: UserProfile, t: ChatTarget, images: List<String>, caption: String, reply: ReplyRef?,
        viewOnce: Boolean = false
    ) {
        val f = HashMap<String, Any>()
        f["type"] = "image"
        f["text"] = if (viewOnce) "" else caption
        if (!viewOnce) {
            val th = images.take(4).map { Media.tinyThumb(it) }
            if (images.size == 1) { if (th[0].isNotEmpty()) f["thumb"] = th[0] }
            else if (th.any { it.isNotEmpty() }) f["thumbs"] = th
        }
        if (images.size == 1) {
            f["imageUrl"] = images[0]
            if (viewOnce) {
                f["viewOnce"] = true
                // Grupta açılmamış fotoğraf 48 saat sonra kalkar (web ile aynı alan)
                if (t.isGroup) f["expiresAtMs"] = System.currentTimeMillis() + 48 * 3600 * 1000L
            }
        } else {
            f["images"] = images
            f["imagesCount"] = images.size
            f["imagesDelivered"] = false
        }
        if (reply != null) f["replyTo"] = replyMap(reply)
        val label = if (images.size > 1) "📷 ${images.size} Fotoğraf" else "📷 Fotoğraf"
        val summary = if (viewOnce) "📷 Bir kez görüntülenebilir fotoğraf" else if (caption.isNotBlank()) "$label $caption" else label
        postMessage(me, t, f, summary.take(100), summary.take(200), "image")
    }

    suspend fun sendAudio(me: UserProfile, t: ChatTarget, dataUrl: String, seconds: Int, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "audio"
        f["audio"] = dataUrl
        f["audioDuration"] = seconds
        f["text"] = ""
        if (reply != null) f["replyTo"] = replyMap(reply)
        val label = "🎤 Sesli mesaj (${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')})"
        postMessage(me, t, f, label, "🎤 Sesli mesaj", "audio")
    }

    suspend fun sendPoll(me: UserProfile, t: ChatTarget, question: String, options: List<String>, multi: Boolean, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "poll"
        f["question"] = question
        f["options"] = options.mapIndexed { i, s -> mapOf("id" to "o$i", "text" to s) }
        f["multi"] = multi
        f["votes"] = HashMap<String, Any>()
        f["text"] = ""
        if (reply != null) f["replyTo"] = replyMap(reply)
        postMessage(me, t, f, ("📊 " + question).take(100), ("📊 Anket gönderdi: " + question).take(120), "poll")
    }

    /** Ankette bir seçeneğe dokunma: tekli ankette aynısına tekrar dokunmak oyu geri alır */
    fun votePoll(me: String, chatId: String, m: Message, optId: String) {
        val mine = m.votes[me] ?: emptyList()
        val has = mine.contains(optId)
        val next = if (m.pollMulti) (if (has) mine - optId else mine + optId) else (if (has) emptyList() else listOf(optId))
        msgRef(chatId, m.id).update("votes.$me", next)
    }

    suspend fun sendLocation(me: UserProfile, t: ChatTarget, lat: Double, lng: Double, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "location"
        f["lat"] = lat
        f["lng"] = lng
        f["text"] = ""
        if (reply != null) f["replyTo"] = replyMap(reply)
        postMessage(me, t, f, "📍 Konum", "📍 Konum gönderdi", "location")
    }

    suspend fun sendDocument(me: UserProfile, t: ChatTarget, name: String, mime: String, dataUrl: String, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "document"
        f["fileName"] = name.take(120)
        f["fileMime"] = mime
        f["imageUrl"] = dataUrl
        f["text"] = ""
        if (reply != null) f["replyTo"] = replyMap(reply)
        postMessage(me, t, f, "📄 $name".take(100), "📄 Belge gönderdi", "document")
    }

    suspend fun sendVideo(me: UserProfile, t: ChatTarget, v: Media.PickedVideo, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "video"
        f["fileName"] = v.name.take(120)
        f["fileMime"] = v.mime
        f["imageUrl"] = v.dataUrl
        if (v.poster.isNotEmpty()) f["thumb"] = v.poster
        f["audioDuration"] = v.durationSec
        f["text"] = ""
        if (reply != null) f["replyTo"] = replyMap(reply)
        postMessage(me, t, f, "🎥 Video", "🎥 Video gönderdi", "video")
    }

    /** Bir mesajı başka sohbete iletir */
    suspend fun forward(me: UserProfile, to: ChatTarget, m: Message) {
        val f = HashMap<String, Any>()
        f["forwarded"] = true
        f["text"] = m.text
        when (m.type) {
            "image" -> {
                f["type"] = "image"
                if (m.images.isNotEmpty()) {
                    f["images"] = m.images.map { Media.dataUrlOf(it) }
                    f["imagesCount"] = m.images.size
                    f["imagesDelivered"] = false
                } else if (m.imageUrl.isNotEmpty()) {
                    f["imageUrl"] = Media.dataUrlOf(m.imageUrl)
                }
            }
            "audio" -> {
                f["type"] = "audio"
                f["audio"] = Media.dataUrlOf(m.audio)
                f["audioDuration"] = m.audioDuration
            }
            "location" -> {
                f["type"] = "location"
                f["lat"] = m.lat
                f["lng"] = m.lng
            }
            "document" -> {
                f["type"] = "document"
                f["fileName"] = m.fileName
                f["fileMime"] = m.fileMime
                f["imageUrl"] = Media.dataUrlOf(m.imageUrl, m.fileMime)
            }
            "video" -> {
                f["type"] = "video"
                f["fileName"] = m.fileName
                f["fileMime"] = m.fileMime
                f["imageUrl"] = Media.dataUrlOf(m.imageUrl, m.fileMime)
                if (m.thumb.isNotEmpty()) f["thumb"] = m.thumb
                f["audioDuration"] = m.audioDuration
            }
            else -> f["type"] = "text"
        }
        postMessage(me, to, f, previewOf(m).take(100), previewOf(m).take(200), m.type)
    }

    fun previewOf(m: Message): String = when {
        m.deleted || m.type == "deleted" -> "🚫 Bu mesaj silindi"
        m.type == "image" && m.viewOnce -> "📷 Bir kez görüntülenebilir fotoğraf"
        m.type == "image" -> if (m.images.size > 1 || m.imagesCount > 1) "📷 ${maxOf(m.images.size, m.imagesCount)} Fotoğraf" else "📷 Fotoğraf"
        m.type == "audio" -> "🎤 Sesli mesaj"
        m.type == "location" -> "📍 Konum"
        m.type == "document" -> "📄 " + m.fileName.ifBlank { "Belge" }
        m.type == "video" -> "🎥 Video"
        m.type == "poll" -> "📊 " + m.question.ifBlank { "Anket" }.take(100)
        else -> m.text.take(120)
    }

    // ---------- Sohbet "son görülen mesaj" (okunmamış ayırıcısı) + klavye yüksekliği ----------
    fun lastSeen(chatId: String): Long = prefs?.getLong("seen_$chatId", 0L) ?: 0L
    fun setLastSeen(chatId: String, t: Long) {
        if (t > lastSeen(chatId)) prefs?.edit()?.putLong("seen_$chatId", t)?.apply()
    }
    fun savedKbPx(): Int = prefs?.getInt("kb_px", 0) ?: 0
    fun saveKbPx(px: Int) { prefs?.edit()?.putInt("kb_px", px)?.apply() }

    // ---------- Bir kez görüntülenebilir fotoğraf ----------
    fun isViewOnceSeen(chatId: String, msgId: String): Boolean =
        prefs?.getBoolean("vo_${chatId}_$msgId", false) ?: false

    /** Birebir: fotoğraf sunucudan silinir. Grup: mesaj ortak olduğu için sadece bu cihazda "açıldı" işaretlenir. */
    fun openViewOnce(chatId: String, msgId: String, isGroup: Boolean) {
        if (!isGroup) msgRef(chatId, msgId).update("imageDelivered", true)
    }

    fun consumeViewOnce(chatId: String, msgId: String, isGroup: Boolean) {
        if (isGroup) {
            prefs?.edit()?.putBoolean("vo_${chatId}_$msgId", true)?.apply()
        } else {
            msgRef(chatId, msgId).update("imageUrl", null, "imageDelivered", true)
        }
    }

    // ---------- Mesaj işlemleri ----------
    private fun msgRef(chatId: String, msgId: String) =
        db.collection("chats").document(chatId).collection("messages").document(msgId)

    fun react(me: String, chatId: String, msgId: String, emoji: String, current: String?) {
        val v: Any = if (current == emoji) FieldValue.delete() else emoji
        msgRef(chatId, msgId).update("reactions.$me", v)
    }

    fun editText(chatId: String, msgId: String, text: String) {
        msgRef(chatId, msgId).update(
            mapOf("text" to text, "edited" to true, "editedAt" to FieldValue.serverTimestamp())
        )
    }

    fun deleteForMe(me: String, chatId: String, msgId: String) {
        msgRef(chatId, msgId).update("deletedFor", FieldValue.arrayUnion(me))
        unstarKey(me, starKey(chatId, msgId))
    }

    fun deleteForEveryone(chatId: String, msgId: String, me: String? = null) {
        if (me != null) unstarKey(me, starKey(chatId, msgId))
        val del = FieldValue.delete()
        msgRef(chatId, msgId).update(
            mapOf(
                "type" to "deleted",
                "deleted" to true,
                "text" to "",
                "imageUrl" to del,
                "images" to del,
                "imagesCount" to 0,
                "lat" to del,
                "lng" to del,
                "audio" to del,
                "audioDuration" to del
            )
        )
    }

    // ---------- Yıldızlı mesajlar ----------
    fun starredFlow(uid: String): Flow<List<StarredItem>> = callbackFlow {
        val reg = db.collection("users").document(uid).collection("starred").addSnapshotListener { snap, _ ->
            trySend(
                snap?.documents?.map { d ->
                    StarredItem(
                        key = d.id,
                        chatId = d.getString("chatId") ?: "",
                        msgId = d.getString("msgId") ?: "",
                        chatName = d.getString("chatName") ?: "",
                        preview = d.getString("preview") ?: "",
                        senderName = d.getString("senderName") ?: "",
                        msgTime = d.getLong("msgTime") ?: 0L,
                        senderUid = d.getString("senderUid") ?: ""
                    )
                }?.sortedByDescending { it.msgTime } ?: emptyList()
            )
        }
        awaitClose { reg.remove() }
    }

    fun unstarKey(me: String, key: String) {
        db.collection("users").document(me).collection("starred").document(key).delete()
    }

    fun unstarAll(me: String, keys: List<String>) {
        val col = db.collection("users").document(me).collection("starred")
        keys.chunked(400).forEach { part ->
            val b = db.batch()
            part.forEach { b.delete(col.document(it)) }
            b.commit()
        }
    }

    fun starKey(chatId: String, msgId: String) = "${chatId}__$msgId"

    fun toggleStar(me: String, t: ChatTarget, m: Message, isStarred: Boolean) {
        val ref = db.collection("users").document(me).collection("starred").document(starKey(t.chatId, m.id))
        if (isStarred) {
            ref.delete()
        } else {
            ref.set(
                mapOf(
                    "chatId" to t.chatId,
                    "msgId" to m.id,
                    "chatName" to t.name,
                    "preview" to previewOf(m),
                    "senderUid" to m.senderUid,
                    "senderName" to m.senderName,
                    "msgTime" to (if (m.time > 0) m.time else System.currentTimeMillis()),
                    "starredAt" to FieldValue.serverTimestamp()
                )
            )
        }
    }

    // ---------- Gruplar ----------
    suspend fun createGroup(me: UserProfile, name: String, memberUids: List<String>): String {
        val members = listOf(me.uid) + memberUids.filter { it != me.uid }.distinct()
        val ref = db.collection("groups").document()
        ref.set(
            mapOf(
                "name" to name,
                "members" to members,
                "createdBy" to me.uid,
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        val batch = db.batch()
        for (m in members) {
            batch.set(
                summaryRef(m, ref.id),
                mapOf(
                    "isGroup" to true,
                    "groupName" to name,
                    "lastMessage" to "Grup oluşturuldu",
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastSenderName" to me.name,
                    "lastMessageRead" to false,
                    "unreadCount" to (if (m == me.uid) 0 else 1),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
        batch.commit().await()
        for (m in members) {
            if (m == me.uid) continue
            bg.launch { notify(m, name, "${me.name} seni gruba ekledi", ref.id, ref.id, name, "text", "") }
        }
        return ref.id
    }

    private suspend fun systemMessage(me: UserProfile, groupId: String, text: String) {
        db.collection("chats").document(groupId).collection("messages").add(
            mapOf(
                "type" to "system",
                "text" to text,
                "senderUid" to me.uid,
                "senderName" to me.name,
                "createdAt" to FieldValue.serverTimestamp(),
                "read" to false
            )
        ).await()
    }

    private suspend fun bumpGroupSummaries(me: UserProfile, g: GroupData, memberUids: List<String>, text: String) {
        val batch = db.batch()
        for (m in memberUids) {
            batch.set(
                summaryRef(m, g.id),
                mapOf(
                    "isGroup" to true,
                    "groupName" to g.name,
                    "lastMessage" to text,
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastSenderName" to me.name,
                    "lastMessageRead" to false,
                    "unreadCount" to (if (m == me.uid) 0 else FieldValue.increment(1)),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
        batch.commit().await()
    }

    suspend fun leaveGroup(me: UserProfile, g: GroupData) {
        val text = "${me.name} gruptan ayrıldı"
        systemMessage(me, g.id, text)
        val others = g.members.filter { it != me.uid }
        bumpGroupSummaries(me, g, others, text)
        db.collection("groups").document(g.id).update(
            mapOf("members" to FieldValue.arrayRemove(me.uid), "admins" to FieldValue.arrayRemove(me.uid))
        ).await()
        // Kendi listemden kaldır
        summaryRef(me.uid, g.id).set(
            mapOf("clearedAt" to FieldValue.serverTimestamp(), "keepRow" to false, "unreadCount" to 0, "pinned" to false),
            SetOptions.merge()
        )
        for (m in others) {
            bg.launch { notify(m, g.name, text, g.id, g.id, g.name, "text", "") }
        }
    }

    suspend fun addMembers(me: UserProfile, g: GroupData, uids: List<String>) {
        if (uids.isEmpty()) return
        db.collection("groups").document(g.id).update("members", FieldValue.arrayUnion(*uids.toTypedArray())).await()
        val batch = db.batch()
        for (m in uids) {
            batch.set(
                summaryRef(m, g.id),
                mapOf(
                    "isGroup" to true,
                    "groupName" to g.name,
                    "lastMessage" to "${me.name} seni gruba ekledi",
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastSenderName" to me.name,
                    "lastMessageRead" to false,
                    "unreadCount" to 1,
                    "clearedAt" to FieldValue.delete(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
        batch.commit().await()
        for (m in uids) {
            bg.launch { notify(m, g.name, "${me.name} seni gruba ekledi", g.id, g.id, g.name, "text", "") }
        }
    }

    suspend fun renameGroup(g: GroupData, name: String) {
        db.collection("groups").document(g.id).update("name", name).await()
        for (m in g.members) {
            summaryRef(m, g.id).set(mapOf("groupName" to name), SetOptions.merge())
        }
    }

    suspend fun removeMember(g: GroupData, uid: String) {
        db.collection("groups").document(g.id).update(
            mapOf("members" to FieldValue.arrayRemove(uid), "admins" to FieldValue.arrayRemove(uid))
        ).await()
    }

    suspend fun setAdmin(g: GroupData, uid: String, admin: Boolean) {
        val v: Any = if (admin) FieldValue.arrayUnion(uid) else FieldValue.arrayRemove(uid)
        db.collection("groups").document(g.id).update("admins", v).await()
    }

    // ---------- Bildirim ----------
    fun registerPush(uid: String) {
        FirebaseMessaging.getInstance().token.addOnSuccessListener { saveToken(uid, it) }
    }

    fun saveToken(uid: String, token: String) {
        db.collection("users").document(uid).set(
            mapOf(
                "fcmToken" to token,
                "platform" to "native",
                // Sunucu bu durumda sadece veri gönderir; bildirimi uygulama kendisi çizer
                "nativeMsgStyle" to true,
                "lastTokenUpdate" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        )
    }

    private suspend fun notify(
        receiverUid: String,
        title: String,
        body: String,
        chatId: String,
        otherUid: String,
        otherName: String,
        msgType: String,
        msgId: String
    ) {
        withContext(Dispatchers.IO) {
            try {
                val idToken = auth.currentUser?.getIdToken(false)?.await()?.token ?: return@withContext
                val data = JSONObject()
                    .put("chatId", chatId)
                    .put("otherUid", otherUid)
                    .put("otherName", otherName)
                    .put("msgType", msgType)
                if (msgId.isNotEmpty()) data.put("msgId", msgId)
                val payload = JSONObject()
                    .put("receiverUid", receiverUid)
                    .put("title", title.take(100))
                    .put("body", body.take(400))
                    .put("data", data)
                if (msgId.isNotEmpty()) payload.put("tag", "msg-$msgId")
                val c = URL(API).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer $idToken")
                c.outputStream.use { it.write(payload.toString().toByteArray()) }
                c.responseCode
                c.disconnect()
            } catch (ignored: Exception) {
            }
        }
    }
}

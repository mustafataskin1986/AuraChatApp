package com.aurachat.app.data

import android.content.Context
import android.content.SharedPreferences
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/** Web sürümüyle AYNI Firestore şemasını kullanır; iki taraf birlikte çalışır. */
object Repo {
    private const val API = "https://aurachat-amber.vercel.app/api/send-notification"

    private val db get() = FirebaseFirestore.getInstance()
    private val auth get() = FirebaseAuth.getInstance()

    private var prefs: SharedPreferences? = null
    fun init(ctx: Context) { prefs = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE) }

    /** Açılışta ağı beklemeden gösterilsin diye son bilinen profil */
    fun cachedProfile(uid: String): UserProfile? {
        val p = prefs ?: return null
        val n = p.getString("name_$uid", null) ?: return null
        return UserProfile(uid, n, p.getString("phone_$uid", "") ?: "")
    }

    private fun cacheProfile(p: UserProfile) {
        if (p.name.isBlank()) return
        prefs?.edit()?.putString("name_${p.uid}", p.name)?.putString("phone_${p.uid}", p.phone)?.apply()
    }

    fun chatId(a: String, b: String) = listOf(a, b).sorted().joinToString("_")

    /** Birebir sohbet id'si "uidA_uidB" biçimindedir; gruplar farklı. */
    fun isDirect(chatId: String) = chatId.split("_").size == 2

    private fun DocumentSnapshot.ts(field: String): Long =
        getTimestamp(field, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L

    // ---------- Profil ----------
    suspend fun loadProfile(uid: String): UserProfile? {
        val d = db.collection("users").document(uid).get().await()
        if (!d.exists()) return null
        return UserProfile(uid, d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("avatar") ?: "")
            .also { cacheProfile(it) }
    }

    suspend fun saveName(uid: String, email: String, name: String): UserProfile {
        db.collection("users").document(uid).set(
            mapOf("uid" to uid, "name" to name, "email" to email, "lastSeen" to FieldValue.serverTimestamp()),
            SetOptions.merge()
        ).await()
        return UserProfile(uid, name).also { cacheProfile(it) }
    }

    private val avatarCache = ConcurrentHashMap<String, String>()
    suspend fun avatarOf(uid: String): String {
        avatarCache[uid]?.let { return it }
        val a = try { db.collection("users").document(uid).get().await().getString("avatar") ?: "" } catch (e: Exception) { "" }
        avatarCache[uid] = a
        return a
    }

    suspend fun loadUsers(myUid: String): List<UserProfile> {
        val snap = db.collection("users").get().await()
        return snap.documents.mapNotNull { d ->
            val name = d.getString("name") ?: return@mapNotNull null
            if (d.id == myUid || name.isBlank()) null
            else UserProfile(d.id, name, d.getString("phone") ?: "", d.getString("avatar") ?: "")
        }.sortedBy { it.name.lowercase() }
    }

    // ---------- Sohbet listesi ----------
    fun chatsFlow(uid: String): Flow<List<ChatSummary>> = callbackFlow {
        val reg = db.collection("users").document(uid).collection("chats")
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.map { d ->
                    ChatSummary(
                        chatId = d.id,
                        otherUid = d.getString("otherUid") ?: "",
                        otherName = d.getString("otherName") ?: "",
                        lastMessage = d.getString("lastMessage") ?: "",
                        lastTime = d.ts("lastMessageTime"),
                        lastSenderUid = d.getString("lastSenderUid") ?: "",
                        lastRead = d.getBoolean("lastMessageRead") ?: false,
                        unread = (d.getLong("unreadCount") ?: 0L).toInt(),
                        pinned = d.getBoolean("pinned") ?: false,
                        archived = d.getBoolean("archived") ?: false,
                        typing = d.getBoolean("typing") ?: false
                    )
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    // ---------- Mesajlar ----------
    fun messagesFlow(chatId: String, limit: Long = 50): Flow<List<Message>> = callbackFlow {
        val reg = db.collection("chats").document(chatId).collection("messages")
            .orderBy("createdAt", Query.Direction.DESCENDING).limit(limit)
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.map { d ->
                    Message(
                        id = d.id,
                        text = d.getString("text") ?: "",
                        senderUid = d.getString("senderUid") ?: "",
                        time = d.ts("createdAt"),
                        read = d.getBoolean("read") ?: false,
                        type = d.getString("type") ?: "text",
                        deleted = d.getBoolean("deleted") ?: false,
                        pending = d.metadata.hasPendingWrites()
                    )
                } ?: emptyList()
                trySend(list) // en yeni en başta (ters liste için hazır)
            }
        awaitClose { reg.remove() }
    }

    fun typingFlow(chatId: String, otherUid: String): Flow<Boolean> = callbackFlow {
        val reg = db.collection("chats").document(chatId).addSnapshotListener { snap, _ ->
            trySend(snap?.getBoolean("typing_$otherUid") ?: false)
        }
        awaitClose { reg.remove() }
    }

    suspend fun sendText(me: UserProfile, chatId: String, otherUid: String, otherName: String, text: String) {
        val msgRef = db.collection("chats").document(chatId).collection("messages").document()
        val myRef = db.collection("users").document(me.uid).collection("chats").document(chatId)
        val otherRef = db.collection("users").document(otherUid).collection("chats").document(chatId)
        val batch = db.batch()
        batch.set(
            msgRef,
            mapOf(
                "text" to text,
                "senderUid" to me.uid,
                "senderName" to me.name,
                "createdAt" to FieldValue.serverTimestamp(),
                "read" to false
            )
        )
        batch.set(
            myRef,
            mapOf(
                "otherUid" to otherUid,
                "otherName" to otherName,
                "lastMessage" to text,
                "lastMessageTime" to FieldValue.serverTimestamp(),
                "lastSenderUid" to me.uid,
                "lastMessageRead" to false,
                "unreadCount" to 0,
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        )
        batch.set(
            otherRef,
            mapOf(
                "otherUid" to me.uid,
                "otherName" to me.name,
                "lastMessage" to text,
                "lastMessageTime" to FieldValue.serverTimestamp(),
                "lastSenderUid" to me.uid,
                "lastMessageRead" to false,
                "typing" to false,
                "unreadCount" to FieldValue.increment(1),
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        )
        batch.commit().await()
        notify(me, chatId, otherUid, text, msgRef.id)
    }

    fun setTyping(me: String, chatId: String, otherUid: String, typing: Boolean) {
        db.collection("chats").document(chatId)
            .set(mapOf("typing_$me" to typing), SetOptions.merge())
        db.collection("users").document(otherUid).collection("chats").document(chatId)
            .update(mapOf("typing" to typing, "typingAt" to System.currentTimeMillis()))
    }

    /** Karşıdan gelen okunmamış mesajları okundu yapar ve listedeki rozeti sıfırlar. */
    fun markRead(me: String, chatId: String, otherUid: String, messages: List<Message>) {
        val unread = messages.filter { it.senderUid != me && !it.read && !it.pending }
        unread.forEach {
            db.collection("chats").document(chatId).collection("messages").document(it.id)
                .update(mapOf("read" to true, "readBy" to FieldValue.arrayUnion(me)))
        }
        db.collection("users").document(me).collection("chats").document(chatId)
            .update(mapOf("unreadCount" to 0, "hasMention" to false))
        if (unread.isNotEmpty()) {
            db.collection("users").document(otherUid).collection("chats").document(chatId)
                .update("lastMessageRead", true)
        }
    }

    // ---------- Bildirim ----------
    fun registerPush(uid: String) {
        FirebaseMessaging.getInstance().token.addOnSuccessListener { saveToken(uid, it) }
    }

    fun saveToken(uid: String, token: String) {
        db.collection("users").document(uid).set(
            mapOf(
                "fcmToken" to token,
                "platform" to "native",
                // Sunucu bu durumda sadece veri gönderir; bildirimi uygulama kendisi çizer
                "nativeMsgStyle" to true,
                "lastTokenUpdate" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        )
    }

    private suspend fun notify(me: UserProfile, chatId: String, otherUid: String, text: String, msgId: String) {
        withContext(Dispatchers.IO) {
            try {
                val idToken = auth.currentUser?.getIdToken(false)?.await()?.token ?: return@withContext
                val payload = JSONObject()
                    .put("receiverUid", otherUid)
                    .put("title", me.name)
                    .put("body", text.take(400))
                    .put("tag", "msg-$msgId")
                    .put(
                        "data",
                        JSONObject()
                            .put("chatId", chatId)
                            .put("otherUid", me.uid)
                            .put("otherName", me.name)
                            .put("msgType", "text")
                            .put("msgId", msgId)
                    )
                val c = URL(API).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer $idToken")
                c.outputStream.use { it.write(payload.toString().toByteArray()) }
                c.responseCode
                c.disconnect()
            } catch (_: Exception) {
            }
        }
    }
}

package com.aurachat.app.data

import com.aurachat.app.ui.toJson
import com.aurachat.app.ui.toMap
import android.content.Context
import android.content.SharedPreferences
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/** Web sürümüyle AYNI Firestore şemasını kullanır; iki taraf birlikte çalışır. */
object Repo {
    private const val API = "https://aurachat-amber.vercel.app/api/send-notification"

    private val db get() = FirebaseFirestore.getInstance()
    private val auth get() = FirebaseAuth.getInstance()
    private val bg = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ---------- Önbellek ----------
    private var prefs: SharedPreferences? = null
    private var profDir: java.io.File? = null
    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)
        profDir = java.io.File(ctx.filesDir, "prof").apply { mkdirs() }
        LocalMedia.init(ctx)
        LocalDb.init(ctx)
    }

    /** Açılışta ağı beklemeden gösterilsin diye son bilinen profil */
    fun cachedProfile(uid: String): UserProfile? {
        val p = prefs ?: return null
        val n = p.getString("name_$uid", null) ?: return null
        return UserProfile(uid, n, p.getString("phone_$uid", "") ?: "")
    }

    private fun cacheProfile(p: UserProfile) {
        if (p.name.isBlank()) return
        prefs?.edit()?.putString("name_${p.uid}", p.name)?.putString("phone_${p.uid}", p.phone)?.apply()
    }

    /** Açılışta liste hemen çizilsin diye son bilinen sohbet listesi */
    fun cachedChats(uid: String): List<ChatSummary>? {
        val raw = prefs?.getString("chats_$uid", null) ?: return null
        return try {
            val arr = org.json.JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ChatSummary(
                    chatId = o.getString("id"), isGroup = o.getBoolean("g"), otherUid = o.getString("u"),
                    name = o.getString("n"), lastMessage = o.getString("m"), lastTime = o.getLong("t"),
                    lastSenderUid = o.getString("su"), lastSenderName = o.getString("sn"),
                    lastRead = o.getBoolean("r"), unread = o.getInt("c"), pinned = o.getBoolean("p"),
                    favorite = o.getBoolean("f"), typing = false, clearedAt = o.getLong("ca"), keepRow = o.optBoolean("k", false),
                    muted = o.optBoolean("mu", false), archivedChat = o.optBoolean("ar", false)
                )
            }
        } catch (e: Throwable) { null }
    }

    private fun cacheChats(uid: String, list: List<ChatSummary>) {
        bg.launch {
            try {
                val arr = org.json.JSONArray()
                list.forEach { c ->
                    arr.put(JSONObject().put("id", c.chatId).put("g", c.isGroup).put("u", c.otherUid).put("n", c.name)
                        .put("m", c.lastMessage.take(200)).put("t", c.lastTime).put("su", c.lastSenderUid)
                        .put("sn", c.lastSenderName).put("r", c.lastRead).put("c", c.unread).put("p", c.pinned)
                        .put("f", c.favorite).put("ca", c.clearedAt).put("k", c.keepRow).put("mu", c.muted).put("ar", c.archivedChat))
                }
                prefs?.edit()?.putString("chats_$uid", arr.toString())?.apply()
            } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Repo", e, "cacheChats:86") }
        }
    }

    fun chatId(a: String, b: String) = listOf(a, b).sorted().joinToString("_")

    /** Birebir sohbet id'si "uidA_uidB" biçimindedir; gruplar farklı. */
    fun isDirect(chatId: String) = chatId.split("_").size == 2

    fun targetFor(me: String, chatId: String, name: String): ChatTarget {
        return if (isDirect(chatId)) {
            val other = chatId.split("_").firstOrNull { it != me } ?: ""
            ChatTarget(chatId, false, other, name)
        } else {
            ChatTarget(chatId, true, chatId, name)
        }
    }

    private val clearedMap = java.util.concurrent.ConcurrentHashMap<String, Long>()

    /** Sohbetin temizlenme zamanı (anında): sohbet açılırken eski mesajlar bir an görünmesin */
    fun peekClearedAt(uid: String, chatId: String): Long =
        clearedMap[chatId] ?: (cachedChats(uid)?.firstOrNull { it.chatId == chatId }?.clearedAt ?: 0L)

    private fun DocumentSnapshot.ts(field: String): Long =
        getTimestamp(field, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L

    // ---------- Profil ----------
    suspend fun loadProfile(uid: String): UserProfile? {
        val d = db.collection("users").document(uid).get().await()
        if (!d.exists()) return null
        return UserProfile(uid, d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("avatar") ?: "", aboutOf(d), d.getString("username") ?: "")
            .also { cacheProfile(it) }
    }

    /** Profil QR/bağlantı anahtarı: sıfırlanınca eski QR ve bağlantılar geçersiz olur (boşsa kısıtlama yok) */
    suspend fun qrKeyOf(uid: String): String =
        try { db.collection("users").document(uid).get().await().getString("qrKey") ?: "" } catch (e: Exception) { "" }

    suspend fun resetQrKey(uid: String): String {
        val chars = "abcdefghijkmnpqrstuvwxyz23456789"
        val k = (1..10).map { chars.random() }.joinToString("")
        db.collection("users").document(uid).set(mapOf("qrKey" to k), SetOptions.merge()).await()
        return k
    }

    suspend fun saveName(uid: String, email: String, name: String): UserProfile {
        db.collection("users").document(uid).set(
            mapOf("uid" to uid, "name" to name, "email" to email, "lastSeen" to FieldValue.serverTimestamp()),
            SetOptions.merge()
        ).await()
        return UserProfile(uid, name).also { cacheProfile(it) }
    }

    /** Telefon numarasından AuraChat kullanıcısı bulur (kayıtlı biçimler: 5xx…, 05xx…, +90 5xx…) */
    suspend fun findUserByPhone(raw: String): UserProfile? {
        val digits = raw.filter { it.isDigit() }
        if (digits.length < 10) return null
        val p10 = digits.takeLast(10)
        val snap = db.collection("users").whereIn("phone", listOf(p10, "+90$p10", "0$p10")).limit(1).get().await()
        val d = snap.documents.firstOrNull() ?: return null
        return UserProfile(d.id, d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("avatar") ?: "", aboutOf(d), d.getString("username") ?: "")
    }

    /** Kayıt: telefon (10 hane) başka hesapta varsa IllegalStateException("PHONE_TAKEN") */
    suspend fun createProfile(uid: String, email: String, name: String, phone10: String, avatar: String): UserProfile {
        val formatted = "+90$phone10"
        val snap = db.collection("users").whereIn("phone", listOf(phone10, formatted, "0$phone10")).get().await()
        if (snap.documents.any { it.id != uid }) throw IllegalStateException("PHONE_TAKEN")
        db.collection("users").document(uid).set(
            mapOf("uid" to uid, "name" to name, "email" to email, "phone" to formatted, "avatar" to avatar,
                "lastSeen" to FieldValue.serverTimestamp()),
            SetOptions.merge()
        ).await()
        return UserProfile(uid, name, formatted, avatar).also { cacheProfile(it) }
    }

    private val profileCache = ConcurrentHashMap<String, UserProfile>()

    /** Diskteki son bilinen profil (ad + avatar) – ağı beklemeden hemen gösterilir */
    private fun diskProfile(uid: String): UserProfile? {
        val f = java.io.File(profDir ?: return null, "$uid.json")
        if (!f.exists()) return null
        return try {
            val o = org.json.JSONObject(f.readText())
            UserProfile(uid, o.optString("n"), o.optString("p"), o.optString("a"), o.optString("b"), o.optString("u"))
        } catch (e: Throwable) { null }
    }

    private fun saveProfile(p: UserProfile) {
        val d = profDir ?: return
        bg.launch {
            try {
                val o = org.json.JSONObject()
                    .put("n", p.name).put("p", p.phone).put("a", p.avatar).put("b", p.about).put("u", p.username)
                java.io.File(d, "${p.uid}.json").writeText(o.toString())
            } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Repo", e, "saveProfile:161") }
        }
    }

    /** Bellek/disk önbelleğindeki profil (senkron) */
    fun peekProfile(uid: String): UserProfile? =
        profileCache[uid] ?: diskProfile(uid)?.also { profileCache[uid] = it }

    /** Kendi profil alanlarını günceller (name, about, avatar); güncel profili döner */
    suspend fun updateProfileFields(me: UserProfile, fields: Map<String, Any>): UserProfile {
        db.collection("users").document(me.uid).update(fields).await()
        val base = peekProfile(me.uid) ?: me
        profileCache.remove(me.uid)
        val np = base.copy(
            name = (fields["name"] as? String) ?: me.name,
            about = if (fields.containsKey("about")) (fields["about"] as? String ?: "") else me.about,
            avatar = if (fields.containsKey("avatar")) (fields["avatar"] as? String ?: "") else me.avatar
        )
        cacheProfile(np)
        // bellek ve disk önbelleği de yeni profille değişsin: eski resim tekrar okunup her yerde görünmesin
        if (np.name.isNotBlank()) { profileCache[me.uid] = np; saveProfile(np) }
        return np
    }

    /** Başka bir kullanıcının adı ve avatarı (bellekte önbelleklenir) */
    suspend fun profileOf(uid: String): UserProfile {
        profileCache[uid]?.let { return it }
        diskProfile(uid)?.let { profileCache[uid] = it; return it }
        val p = try {
            val d = db.collection("users").document(uid).get().await()
            UserProfile(uid, d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("avatar") ?: "", aboutOf(d))
        } catch (e: Exception) {
            UserProfile(uid, "")
        }
        if (p.name.isNotBlank() || p.avatar.isNotBlank()) { profileCache[uid] = p; saveProfile(p) }
        return p
    }

    suspend fun avatarOf(uid: String): String = profileOf(uid).avatar

    /** Bir kullanıcının profilini canlı izler: ad/avatar değişince her yer kendiliğinden güncellenir */
    fun profileFlow(uid: String): Flow<UserProfile?> = callbackFlow {
        peekProfile(uid)?.let { trySend(it) }
        val reg = db.collection("users").document(uid).addSnapshotListener { d, _ ->
            if (d != null && d.exists()) {
                val p = UserProfile(
                    uid, d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("avatar") ?: "",
                    aboutOf(d), d.getString("username") ?: ""
                )
                if (p.name.isNotBlank()) { profileCache[uid] = p; saveProfile(p) }
                trySend(p)
            } else trySend(null)
        }
        awaitClose { reg.remove() }
    }

    @Volatile private var usersCache: List<UserProfile>? = null
    fun cachedUsers(): List<UserProfile>? = usersCache

    /** Tüm kullanıcılar canlı: ad / avatar değişince kişiler ekranı kendiliğinden güncellenir */
    fun usersFlow(myUid: String): Flow<List<UserProfile>> = callbackFlow {
        usersCache?.let { trySend(it) }
        val reg = db.collection("users").addSnapshotListener { snap, _ ->
            if (snap == null) return@addSnapshotListener
            val list = snap.documents.mapNotNull { d ->
                val name = d.getString("name") ?: return@mapNotNull null
                if (d.id == myUid || name.isBlank()) null
                else UserProfile(d.id, name, d.getString("phone") ?: "", d.getString("avatar") ?: "", aboutOf(d))
            }.sortedBy { it.name.lowercase() }
            usersCache = list
            trySend(list)
        }
        awaitClose { reg.remove() }
    }

    suspend fun loadUsers(myUid: String): List<UserProfile> {
        val snap = db.collection("users").get().await()
        return snap.documents.mapNotNull { d ->
            val name = d.getString("name") ?: return@mapNotNull null
            if (d.id == myUid || name.isBlank()) null
            else UserProfile(d.id, name, d.getString("phone") ?: "", d.getString("avatar") ?: "", aboutOf(d))
        }.sortedBy { it.name.lowercase() }
    }

    // ---------- Sohbet listesi ----------
    private fun summaryRef(uid: String, chatId: String) =
        db.collection("users").document(uid).collection("chats").document(chatId)

    fun chatsFlow(uid: String): Flow<List<ChatSummary>> = callbackFlow {
        val reg = db.collection("users").document(uid).collection("chats")
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.map { d ->
                    val group = d.getBoolean("isGroup") ?: !isDirect(d.id)
                    ChatSummary(
                        chatId = d.id,
                        isGroup = group,
                        otherUid = if (group) d.id else (d.getString("otherUid") ?: ""),
                        name = if (group) (d.getString("groupName") ?: "Grup") else (d.getString("otherName") ?: ""),
                        lastMessage = d.getString("lastMessage") ?: "",
                        lastTime = d.ts("lastMessageTime"),
                        lastSenderUid = d.getString("lastSenderUid") ?: "",
                        lastSenderName = d.getString("lastSenderName") ?: "",
                        lastRead = d.getBoolean("lastMessageRead") ?: false,
                        unread = (d.getLong("unreadCount") ?: 0L).toInt(),
                        pinned = d.getBoolean("pinned") ?: false,
                        favorite = d.getBoolean("archived") ?: false,
                        typing = d.getBoolean("typing") ?: false,
                        clearedAt = d.ts("clearedAt"),
                        muted = (d.getBoolean("muted") ?: false) && ((d.getLong("mutedUntil") ?: 0L).let { it <= 0L || it > System.currentTimeMillis() }),
                        keepRow = d.getBoolean("keepRow") ?: false,
                        archivedChat = d.getBoolean("chatArchived") ?: false,
                        archivedAt = d.ts("chatArchivedAt")
                    )
                } ?: emptyList()
                if (snap != null) { list.forEach { if (it.clearedAt > 0L) clearedMap[it.chatId] = it.clearedAt }; cacheChats(uid, list) }
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    fun clearedAtFlow(uid: String, chatId: String): Flow<Long> = callbackFlow {
        val reg = summaryRef(uid, chatId).addSnapshotListener { snap, _ ->
            val v = snap?.ts("clearedAt") ?: 0L
            clearedMap[chatId] = v
            trySend(v)
        }
        awaitClose { reg.remove() }
    }

    /** Hesabı siler. null = tamam, "RELOGIN" = güvenlik için yeniden giriş gerekli */
    suspend fun deleteAccount(uid: String): String? {
        val user = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser ?: return "Oturum yok"
        val tok = user.getIdToken(true).await()
        if (System.currentTimeMillis() - tok.authTimestamp * 1000L > 5 * 60_000L) return "RELOGIN"
        try {
            val u = db.collection("users").document(uid)
            for (sub in listOf("chats", "starred")) {
                u.collection(sub).get().await().documents.forEach { try { it.reference.delete().await() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Repo", e, "deleteAccount:295") } }
            }
            try { db.collection("presence").document(uid).delete().await() } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Repo", e, "deleteAccount:297") }
            u.delete().await()
        } catch (e: Throwable) { return "Veriler silinemedi" }
        return try { user.delete().await(); null } catch (e: Throwable) { "Hesap silinemedi" }
    }

    fun setPinned(me: String, chatId: String, pinned: Boolean) {
        summaryRef(me, chatId).update("pinned", pinned)
    }

    fun setChatArchived(me: String, chatId: String, v: Boolean) {
        summaryRef(me, chatId).set(mapOf("chatArchived" to v, "chatArchivedAt" to FieldValue.serverTimestamp()), SetOptions.merge())
    }

    fun setFavorite(me: String, chatId: String, fav: Boolean) {
        summaryRef(me, chatId).update("archived", fav)
    }

    // ---------- Kişi bilgisi: favori / sessiz / engel / süreli mesaj / temizle ----------
    data class ChatFlags(val exists: Boolean, val fav: Boolean, val muted: Boolean)

    fun chatFlagsFlow(uid: String, chatId: String): Flow<ChatFlags> = callbackFlow {
        val reg = summaryRef(uid, chatId).addSnapshotListener { snap, _ ->
            trySend(ChatFlags(snap?.exists() == true, snap?.getBoolean("archived") ?: false, ((snap?.getBoolean("muted") ?: false) && ((snap?.getLong("mutedUntil") ?: 0L).let { it <= 0L || it > System.currentTimeMillis() }))))
        }
        awaitClose { reg.remove() }
    }

    /** Süreli mesaj ayarı (ms, 0 = kapalı) */
    fun disappearFlow(chatId: String): Flow<Long> = callbackFlow {
        val reg = db.collection("chats").document(chatId).addSnapshotListener { snap, _ ->
            val v = snap?.getLong("disappearAfter") ?: 0L
            if (snap != null) putDisappear(chatId, v)
            trySend(v)
        }
        awaitClose { reg.remove() }
    }

    // Süreli mesaj ayarı önbelleği: simge ilk karede (sunucuyu beklemeden) görünsün
    private val disappearCache: ConcurrentHashMap<String, Long> by lazy {
        val m = ConcurrentHashMap<String, Long>()
        try {
            val f = java.io.File(profDir ?: return@lazy m, "disappear.json")
            if (f.exists()) { val o = org.json.JSONObject(f.readText()); o.keys().forEach { k -> m[k] = o.optLong(k) } }
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Repo", e, "disappearCache") }
        m
    }

    fun peekDisappear(chatId: String): Long = disappearCache[chatId] ?: 0L

    private fun putDisappear(chatId: String, v: Long) {
        val old = disappearCache[chatId] ?: 0L
        if (old == v && (v == 0L || disappearCache.containsKey(chatId))) return
        if (v == 0L) disappearCache.remove(chatId) else disappearCache[chatId] = v
        val d = profDir ?: return
        bg.launch {
            try {
                val o = org.json.JSONObject(); disappearCache.forEach { (k, x) -> o.put(k, x) }
                java.io.File(d, "disappear.json").writeText(o.toString())
            } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Repo", e, "putDisappear") }
        }
    }

    /** Durum şikayeti: "reports" koleksiyonuna yazar (kural izin vermezse sessizce geçer) */
    fun reportStatus(me: String, owner: String, statusId: String) {
        try {
            db.collection("reports").add(mapOf("by" to me, "owner" to owner, "statusId" to statusId, "at" to System.currentTimeMillis()))
        } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Repo", e, "reportStatus:337") }
    }

    /** untilMs > 0 ise sessize alma o zamana kadar sürer (8 saat / 1 hafta), 0 = her zaman */
    fun setMuted(me: String, chatId: String, muted: Boolean, untilMs: Long = 0L) {
        summaryRef(me, chatId).set(mapOf("muted" to muted, "mutedUntil" to (if (muted) untilMs else 0L)), SetOptions.merge())
    }

    fun setGroupPhoto(groupId: String, dataUrl: String) {
        db.collection("groups").document(groupId).update("photo", dataUrl)
    }

    private val blockedCache = ConcurrentHashMap<String, List<String>>()

    /** Son bilinen engel listesi (bellek + disk): sohbet açılırken alt çubuk/balon gecikmeden doğru çizilsin */
    fun peekBlocked(uid: String): List<String> {
        blockedCache[uid]?.let { return it }
        val f = java.io.File(profDir ?: return emptyList(), "bl_$uid.json")
        if (!f.exists()) return emptyList()
        return try {
            val a = org.json.JSONArray(f.readText())
            (0 until a.length()).map { a.optString(it) }.also { blockedCache[uid] = it }
        } catch (e: Throwable) { emptyList() }
    }

    private fun putBlocked(uid: String, l: List<String>) {
        if (blockedCache[uid] == l) return
        blockedCache[uid] = l
        val d = profDir ?: return
        bg.launch {
            try { java.io.File(d, "bl_$uid.json").writeText(org.json.JSONArray(l).toString()) } catch (e: Throwable) { }
        }
    }

    /** Sohbet listesi açılınca: sohbetteki kişilerin engel listesi ve grup bilgisi önceden indirilir (sohbet açılışında bekleme olmasın) */
    fun prefetchChatState(chats: List<ChatSummary>) {
        bg.launch {
            for (c in chats.take(40)) {
                try {
                    if (c.isGroup) {
                        if (peekGroup(c.chatId) == null) {
                            val d = db.collection("groups").document(c.chatId).get().await()
                            if (d.exists()) saveGroup(d.toGroup())
                        }
                    } else if (c.otherUid.isNotBlank() && peekBlocked(c.otherUid).isEmpty() && blockedCache[c.otherUid] == null) {
                        val d = db.collection("users").document(c.otherUid).get().await()
                        putBlocked(c.otherUid, (d.get("blockedUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList())
                    }
                } catch (e: Throwable) { }
            }
        }
    }

    fun blockedFlow(uid: String): Flow<List<String>> = callbackFlow {
        val reg = db.collection("users").document(uid).addSnapshotListener { snap, _ ->
            val l = (snap?.get("blockedUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
            putBlocked(uid, l)
            trySend(l)
        }
        awaitClose { reg.remove() }
    }

    fun setBlocked(me: String, other: String, blocked: Boolean, chatId: String = "") {
        val upd = {
            db.collection("users").document(me).update(
                "blockedUids", if (blocked) FieldValue.arrayUnion(other) else FieldValue.arrayRemove(other)
            )
        }
        // Kurallar engelli çiftte mesaj yazmayı yasaklar: engellerken bilgi satırı ÖNCE yazılır (yoksa reddedilip kaybolur), engeli kaldırırken SONRA
        if (!blocked) upd()
        // WhatsApp gibi: sohbette kalıcı bilgi satırı (yalnız engelleyen görür; karşı taraf için deletedFor ile gizlenir)
        if (chatId.isNotBlank()) {
            val line = if (blocked) "Bu kişiyi engellediniz. Engeli kaldırmak için dokunun." else "Bu kişinin engelini kaldırdınız."
            db.collection("chats").document(chatId).collection("messages").add(
                mapOf("type" to "system", "text" to line, "senderUid" to me, "senderName" to "",
                    "deletedFor" to listOf(other), "createdAt" to FieldValue.serverTimestamp(), "read" to true)
            )
            noticeSummary(listOf(me), chatId, line)
        }
        if (blocked) upd()
    }

    private val dmChecked = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    /** Yeni sohbetlerde uygulanan varsayılan süreli mesaj süresi (ms, 0 = kapalı); bu telefonda saklanır */
    fun defaultDisappearMs(): Long = prefs?.getLong("default_disappear", 0L) ?: 0L
    fun setDefaultDisappearMs(ms: Long) { prefs?.edit()?.putLong("default_disappear", ms)?.apply() }
    fun disappearLabel(ms: Long): String = when { ms >= 90L * 24 * 3600 * 1000L -> "90 gün"; ms >= 7L * 24 * 3600 * 1000L -> "7 gün"; else -> "24 saat" }

    /** Süreli mesajlar (yeni mesajlar için); web ile aynı alan ve sistem mesajı */
    /** Sohbet uyarıları (engel, süreli mesaj, tema...) liste satırında son mesaj olarak görünür */
    fun noticeSummary(uids: List<String>, chatId: String, text: String) {
        for (u in uids) {
            if (u.isBlank()) continue
            summaryRef(u, chatId).update(
                mapOf(
                    "lastMessage" to text, "lastMessageTime" to FieldValue.serverTimestamp(), "lastSenderUid" to "",
                    "lastSenderName" to "", "lastMessageRead" to true, "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }
    }

    /** Sohbet teması (herkes için): chats/{id}.chatTheme alanı; değişiklikleri dinler */
    fun chatThemeFlow(chatId: String): kotlinx.coroutines.flow.Flow<Map<String, Any?>?> = kotlinx.coroutines.flow.callbackFlow {
        val reg = db.collection("chats").document(chatId).addSnapshotListener { snap, _ ->
            @Suppress("UNCHECKED_CAST")
            trySend(snap?.get("chatTheme") as? Map<String, Any?>)
        }
        awaitClose { reg.remove() }
    }

    /** Temayı herkes için ayarlar: kabul beklenmez; karşı taraf otomatik uygular */
    suspend fun setChatTheme(me: UserProfile, t: ChatTarget, theme: Map<String, Any>, at: Long) {
        val others: List<String> = if (t.isGroup) (loadGroup(t.chatId)?.members ?: emptyList()).filter { it != me.uid } else listOf(t.otherUid)
        db.collection("chats").document(t.chatId).set(mapOf("chatTheme" to (theme + mapOf("by" to me.uid, "at" to at))), SetOptions.merge()).await()
        val mine = "Sohbet temasını herkes için değiştirdiniz."
        val theirs = "${me.name} sohbet temasını herkes için değiştirdi. Değiştir"
        val col = db.collection("chats").document(t.chatId).collection("messages")
        col.add(mapOf("type" to "system", "text" to mine, "senderUid" to me.uid, "senderName" to "", "deletedFor" to others,
            "createdAt" to FieldValue.serverTimestamp(), "read" to true))
        col.add(mapOf("type" to "system", "text" to theirs, "senderUid" to me.uid, "senderName" to me.name, "deletedFor" to listOf(me.uid),
            "createdAt" to FieldValue.serverTimestamp(), "read" to false))
        noticeSummary(listOf(me.uid), t.chatId, mine)
        noticeSummary(others, t.chatId, theirs)
    }

    fun setDisappearAfter(chatId: String, myName: String, myUid: String, ms: Long, otherUid: String = "") {
        val prevMs = disappearCache[chatId] ?: 0L
        db.collection("chats").document(chatId).set(mapOf("disappearAfter" to ms), SetOptions.merge())
        val label = disappearLabel(ms)
        // WhatsApp metinleri; kendi işlemimiz de 3. şahıs ("Ad ... etkinleştirdi"), sonunda "Süreyi değiştirin"
        val text = when {
            ms <= 0L -> "$myName süreli mesajları devre dışı bıraktı. Süreyi değiştirin"
            prevMs > 0L -> "$myName mesaj süresini güncelledi. Tutulmadığı takdirde yeni mesajlar gönderildikten $label sonra bu sohbetten kaybolacak. Süreyi değiştirin"
            else -> "$myName süreli mesajları etkinleştirdi. Tutulmadığı takdirde yeni mesajlar gönderildikten $label sonra bu sohbetten kaybolacak. Süreyi değiştirin"
        }
        val ref = db.collection("chats").document(chatId).collection("messages").document()
        ref.set(
            mapOf("type" to "system", "text" to text, "senderUid" to myUid, "senderName" to myName,
                "createdAt" to FieldValue.serverTimestamp(), "read" to false)
        )
        // uyarı sohbete girince beklemeden görünsün: yerel listeye ve yerel veritabanına hemen yaz
        val localMsg = Message(
            id = ref.id, type = "system", text = text, senderUid = myUid, senderName = myName, time = System.currentTimeMillis(), read = false,
            readBy = emptyList(), deleted = false, deletedFor = emptyList(), pending = true, imageUrl = "", images = emptyList(), imagesCount = 0,
            audio = "", audioDuration = 0, lat = 0.0, lng = 0.0, hasLocation = false, fileName = "", fileMime = "", replyTo = null,
            reactions = emptyMap(), edited = false, forwarded = false, callDuration = 0
        )
        msgMem[chatId] = listOf(localMsg) + (msgMem[chatId] ?: emptyList()).filter { it.id != ref.id }
        bg.launch { try { LocalDb.upsert(chatId, listOf(localMsg)) } catch (e: Throwable) { } }
        bg.launch {
            val all = if (otherUid.isNotBlank()) listOf(myUid, otherUid) else (try { loadGroup(chatId)?.members } catch (_: Throwable) { null } ?: listOf(myUid))
            noticeSummary(all, chatId, text)
        }
    }

    /** Sohbetin içini temizler, liste satırı kalır (web wipeChat ile aynı) */
    fun wipeChat(me: String, chatId: String) {
        clearedMap[chatId] = System.currentTimeMillis()
        bg.launch { LocalDb.clearChat(chatId) }
        summaryRef(me, chatId).set(
            mapOf("clearedAt" to FieldValue.serverTimestamp(), "keepRow" to true, "lastMessage" to "",
                "unreadCount" to 0, "hasMention" to false),
            SetOptions.merge()
        )
    }

    /** Sohbeti listeden sil: kalıcı olarak "clearedAt" yazılır, eski mesajlar bir daha yüklenmez */
    fun clearChat(me: String, chatId: String) {
        clearedMap[chatId] = System.currentTimeMillis()
        bg.launch { LocalDb.clearChat(chatId) }
        summaryRef(me, chatId).set(
            mapOf("clearedAt" to FieldValue.serverTimestamp(), "keepRow" to false, "unreadCount" to 0, "pinned" to false),
            SetOptions.merge()
        )
    }

    /** Yedekten dönen sohbetleri listeye geri getirir (silme/temizleme işaretini kaldırır) */
    fun restoreChats(me: String, rows: List<Array<String>>) {
        val last = HashMap<String, Message>()
        for (r in rows) {
            val m = LocalDb.parse(r[3]) ?: continue
            if (m.deleted || m.deletedFor.contains(me)) continue
            val cur = last[r[0]]
            if (cur == null || m.time >= cur.time) last[r[0]] = m
        }
        last.forEach { (chatId, m) ->
            clearedMap.remove(chatId)
            val f = HashMap<String, Any>()
            f["clearedAt"] = FieldValue.delete()
            f["keepRow"] = false
            f["lastMessage"] = previewOf(m)
            if (m.time > 0L) f["lastMessageTime"] = com.google.firebase.Timestamp(java.util.Date(m.time))
            f["lastSenderUid"] = m.senderUid
            f["lastMessageRead"] = true
            if (isDirect(chatId)) f["otherUid"] = chatId.split("_").firstOrNull { it != me } ?: ""
            summaryRef(me, chatId).set(f, SetOptions.merge())
        }
    }

    // ---------- Yerel depolama yardımcıları (arka plan iş parçacığında çağrılır) ----------
    /** Telefona yazılan medyanın Firebase'deki kopyasını siler */
    /** false: sunucu izin vermedi (PERMISSION_DENIED); aynı mesaj için tekrar denenmemeli */
    fun ackMediaBlocking(chatId: String, msgId: String, upd: Map<String, Any?>): Boolean {
        return try {
            com.google.android.gms.tasks.Tasks.await(
                db.collection("chats").document(chatId).collection("messages").document(msgId).update(upd),
                10, java.util.concurrent.TimeUnit.SECONDS
            )
            true
        } catch (e: Throwable) {
            com.aurachat.app.AuraLog.e("Repo", e, "ackMedia $chatId/$msgId")
            !(e.toString().contains("PERMISSION_DENIED") || (e.cause?.toString() ?: "").contains("PERMISSION_DENIED"))
        }
    }

    fun fetchMessageBlocking(chatId: String, msgId: String): Message? = try {
        com.google.android.gms.tasks.Tasks.await(
            db.collection("chats").document(chatId).collection("messages").document(msgId).get(),
            12, java.util.concurrent.TimeUnit.SECONDS
        ).takeIf { it.exists() }?.toMessage()
    } catch (e: Throwable) { null }

    /** Sohbetin son mesajlarını okundu yapar (bildirimdeki "Okundu olarak işaretle" için) */
    suspend fun markChatRead(me: String, t: ChatTarget) {
        val snap = db.collection("chats").document(t.chatId).collection("messages")
            .orderBy("createdAt", Query.Direction.DESCENDING).limit(60).get().await()
        markRead(me, t, snap.documents.map { it.toMessage() })
    }

    // ---------- Mesajlar ----------
    private fun DocumentSnapshot.toMessage(): Message {
        val reply = (get("replyTo") as? Map<*, *>)?.let { m ->
            ReplyRef(
                msgId = m["msgId"] as? String ?: "",
                senderName = m["senderName"] as? String ?: "",
                previewText = m["previewText"] as? String ?: "",
                senderUid = m["senderUid"] as? String ?: "",
                isStatus = (m["isStatus"] as? Boolean) ?: false
            )
        }
        // durum yanıtının küçük resmi sohbet açılmadan hazır olsun
        if (reply != null && reply.isStatus && reply.msgId.isNotEmpty() && statusMediaCache[reply.msgId] == null) {
            val sid = reply.msgId
            bg.launch { try { loadStatusMedia(sid) } catch (_: Throwable) {} }
        }
        val reactions = HashMap<String, String>()
        (get("reactions") as? Map<*, *>)?.forEach { (k, v) ->
            if (k is String && v is String) reactions[k] = v
        }
        val images = (get("images") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
        val lat = getDouble("lat")
        val lng = getDouble("lng")
        return Message(
            id = id,
            type = getString("type") ?: "text",
            text = getString("text") ?: "",
            senderUid = getString("senderUid") ?: "",
            senderName = getString("senderName") ?: "",
            time = ts("createdAt"),
            read = getBoolean("read") ?: false,
            readBy = (get("readBy") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            deleted = getBoolean("deleted") ?: false,
            deletedFor = (get("deletedFor") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            pending = metadata.hasPendingWrites(),
            imageUrl = getString("imageUrl") ?: "",
            images = images,
            imagesCount = (getLong("imagesCount") ?: 0L).toInt(),
            audio = getString("audio") ?: "",
            audioDuration = (getLong("audioDuration") ?: 0L).toInt(),
            audioWave = (get("wave") as? List<*>)?.mapNotNull { (it as? Number)?.toInt() } ?: emptyList(),
            lat = lat ?: 0.0,
            lng = lng ?: 0.0,
            hasLocation = lat != null && lng != null,
            fileName = getString("fileName") ?: "",
            fileMime = getString("fileMime") ?: "",
            replyTo = reply,
            reactions = reactions,
            edited = getBoolean("edited") ?: false,
            forwarded = getBoolean("forwarded") ?: false,
            callDuration = (getLong("duration") ?: 0L).toInt(),
            callType = getString("callType") ?: "",
            viewOnce = getBoolean("viewOnce") ?: false,
            imageDelivered = getBoolean("imageDelivered") ?: false,
            imagesDelivered = getBoolean("imagesDelivered") ?: false,
            audioDelivered = getBoolean("audioDelivered") ?: false,
            question = getString("question") ?: "",
            pollOptions = parsePollOptions(get("options")),
            pollMulti = getBoolean("multi") ?: false,
            mentions = (get("mentions") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            mentionNames = (get("mentionNames") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            votes = parseVotes(get("votes")),
            thumb = getString("thumb") ?: "",
            thumbs = (get("thumbs") as? List<*>)?.map { (it as? String) ?: "" } ?: emptyList(),
            linkPreview = (get("linkPreview") as? Map<*, *>)?.let { lp ->
                val u = lp["url"] as? String
                if (u.isNullOrBlank()) null
                else LinkPreview(u, (lp["title"] as? String) ?: "", (lp["description"] as? String) ?: "", (lp["image"] as? String) ?: "")
            }
        )
    }

    private fun parsePollOptions(raw: Any?): List<PollOption> {
        val out = ArrayList<PollOption>()
        if (raw is List<*>) {
            for (o in raw) {
                if (o is Map<*, *>) {
                    val id = o["id"] as? String
                    if (id != null) out.add(PollOption(id, (o["text"] as? String) ?: ""))
                }
            }
        }
        return out
    }

    private fun parseVotes(raw: Any?): Map<String, List<String>> {
        val out = HashMap<String, List<String>>()
        if (raw is Map<*, *>) {
            for ((k, v) in raw) {
                if (k is String && v is List<*>) out[k] = v.filterIsInstance<String>()
            }
        }
        return out
    }

    /** En yeni en başta */
    private val msgMem = java.util.concurrent.ConcurrentHashMap<String, List<Message>>()

    /** Sohbet ilk karede boş görünmesin: bu oturumda gösterilen son mesaj listesi, yoksa yerel veritabanından küçük bir okuma */
    fun cachedMessages(chatId: String): List<Message> =
        msgMem[chatId] ?: try { LocalDb.recent(chatId, 30).also { if (it.isNotEmpty()) msgMem[chatId] = it } } catch (e: Throwable) { emptyList() }

    /** Tepki bildirimi gelince sohbetin son 30 mesajını sunucudan çekip yerel önbelleğe yazar: sohbet açılınca emojiler ilk karede hazır olur */
    fun refreshChatCache(chatId: String) {
        bg.launch {
            try {
                val snap = db.collection("chats").document(chatId).collection("messages")
                    .orderBy("createdAt", Query.Direction.DESCENDING).limit(30)
                    .get(com.google.firebase.firestore.Source.SERVER).await()
                val list = snap.documents.map { it.toMessage() }
                if (list.isNotEmpty()) { msgMem[chatId] = list; LocalDb.upsert(chatId, list) }
            } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Repo", e, "refreshChatCache") }
        }
    }

    fun messagesFlow(chatId: String, limit: Long): Flow<List<Message>> = callbackFlow {
        val gotSnap = java.util.concurrent.atomic.AtomicBoolean(false)
        // Önce yerel veritabanından anında göster
        launch(Dispatchers.IO) {
            val local = LocalDb.recent(chatId, limit.toInt())
            if (local.isNotEmpty() && !gotSnap.get()) { msgMem[chatId] = local; trySend(local) }
        }
        val reg = db.collection("chats").document(chatId).collection("messages")
            .orderBy("createdAt", Query.Direction.DESCENDING).limit(limit)
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.map { it.toMessage() } ?: emptyList()
                gotSnap.set(true)
                if (list.isNotEmpty()) msgMem[chatId] = list
                trySend(list)
                if (snap != null && list.isNotEmpty()) bg.launch {
                    LocalDb.upsert(chatId, list)
                    if (!snap.metadata.isFromCache && !snap.metadata.hasPendingWrites() && list.size.toLong() < limit) {
                        LocalDb.pruneWindow(chatId, 0L, list.map { it.id }.toSet())
                    } else if (!snap.metadata.isFromCache && !snap.metadata.hasPendingWrites()) {
                        LocalDb.pruneWindow(chatId, list.minOf { it.time }, list.map { it.id }.toSet())
                    }
                }
            }
        awaitClose { reg.remove() }
    }

    fun typingFlow(chatId: String, otherUid: String): Flow<Boolean> = callbackFlow {
        val reg = db.collection("chats").document(chatId).addSnapshotListener { snap, _ ->
            trySend(snap?.getBoolean("typing_$otherUid") ?: false)
        }
        awaitClose { reg.remove() }
    }

    /** Karşı tarafın çevrimiçi/son görülme bilgisi (presence/{uid}); gizliyse null */
    data class Presence(val online: Boolean, val lastSeenMs: Long)

    fun presenceFlow(uid: String): Flow<Presence?> = callbackFlow {
        val reg = db.collection("presence").document(uid).addSnapshotListener { snap, _ ->
            if (snap != null && snap.exists() && snap.getBoolean("hidden") != true) {
                trySend(Presence(snap.getBoolean("online") ?: false, snap.ts("lastSeen")))
            } else {
                trySend(null)
            }
        }
        awaitClose { reg.remove() }
    }

    @Volatile private var presenceHidden = false
    @Volatile private var receiptsHidden = false

    fun isPresenceHidden() = presenceHidden
    fun isReceiptsHidden() = receiptsHidden

    fun syncPresenceHidden(uid: String) {
        db.collection("presence").document(uid).get().addOnSuccessListener {
            presenceHidden = it.getBoolean("hidden") == true
            receiptsHidden = it.getBoolean("hideReceipts") == true
        }
    }

    fun setPresenceHidden(uid: String, hidden: Boolean) {
        presenceHidden = hidden
        val ref = db.collection("presence").document(uid)
        if (hidden) {
            ref.set(mapOf("hidden" to true, "online" to false, "lastSeen" to FieldValue.delete()), SetOptions.merge())
        } else {
            ref.set(mapOf("hidden" to false), SetOptions.merge()).addOnSuccessListener { writePresence(uid, true) }
        }
    }

    fun setReceiptsHidden(uid: String, hidden: Boolean) {
        receiptsHidden = hidden
        db.collection("presence").document(uid).set(mapOf("hideReceipts" to hidden), SetOptions.merge())
    }

    fun writePresence(uid: String, online: Boolean) {
        if (presenceHidden) return
        db.collection("presence").document(uid).set(
            mapOf("online" to online, "lastSeen" to FieldValue.serverTimestamp()),
            SetOptions.merge()
        )
    }

    /** Grupta şu an yazan diğer üyelerin uid'leri (chats/{id}.typing_<uid>) */
    fun groupTypingFlow(chatId: String, me: String): Flow<List<String>> = callbackFlow {
        val reg = db.collection("chats").document(chatId).addSnapshotListener { snap, _ ->
            val out = ArrayList<String>()
            snap?.data?.forEach { (k, v) ->
                if (k.startsWith("typing_") && v == true && k.removePrefix("typing_") != me) out.add(k.removePrefix("typing_"))
            }
            trySend(out)
        }
        awaitClose { reg.remove() }
    }

    fun setTyping(me: String, t: ChatTarget, typing: Boolean) {
        db.collection("chats").document(t.chatId)
            .set(mapOf("typing_$me" to typing), SetOptions.merge())
        if (!t.isGroup) {
            summaryRef(t.otherUid, t.chatId)
                .update(mapOf("typing" to typing, "typingAt" to System.currentTimeMillis()))
        }
    }

    /** Karşıdan gelen okunmamış mesajları okundu yapar ve listedeki rozeti sıfırlar. */
    fun markRead(me: String, t: ChatTarget, messages: List<Message>) {
        val unread = messages.filter {
            it.senderUid != me && !it.pending && it.type != "system" &&
                (if (t.isGroup) !it.readBy.contains(me) else !it.read)
        }
        if (!receiptsHidden) unread.forEach {
            val upd = HashMap<String, Any>()
            upd["readBy"] = FieldValue.arrayUnion(me)
            if (!t.isGroup) upd["read"] = true
            db.collection("chats").document(t.chatId).collection("messages").document(it.id).update(upd)
        }
        summaryRef(me, t.chatId).update(mapOf("unreadCount" to 0, "hasMention" to false))
        if (unread.isNotEmpty() && !t.isGroup && !receiptsHidden) {
            summaryRef(t.otherUid, t.chatId).update("lastMessageRead", true)
        }
    }

    // ---------- Aramalar (kayıtlar + bildirim) ----------
    /** Arama kayıtlarını yalnız benim listemden siler */
    fun deleteCalls(uid: String, ids: List<String>) {
        if (ids.isEmpty()) return
        val b = db.batch()
        ids.forEach { b.delete(db.collection("users").document(uid).collection("calls").document(it)) }
        b.commit()
    }

    fun callsFlow(uid: String): Flow<List<CallLog>> = callbackFlow {
        val reg = db.collection("users").document(uid).collection("calls")
            .orderBy("at", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener { snap, _ ->
                if (snap == null) return@addSnapshotListener
                trySend(snap.documents.map { d ->
                    CallLog(
                        id = d.id,
                        otherUid = d.getString("otherUid") ?: "",
                        otherName = d.getString("otherName") ?: "",
                        callType = d.getString("callType") ?: "video",
                        result = d.getString("result") ?: "",
                        duration = (d.getLong("duration") ?: 0L).toInt(),
                        at = d.getLong("at") ?: 0L,
                        direction = d.getString("direction") ?: "in"
                    )
                })
            }
        awaitClose { reg.remove() }
    }

    private suspend fun writeCallEntries(
        chatId: String, callerUid: String, calleeUid: String, callerName: String, calleeName: String,
        callType: String, result: String, duration: Int, fromUid: String
    ) {
        try {
            val at = System.currentTimeMillis()
            val cid = chatId + "_" + result + "_" + (at / 60000L)
            val base = HashMap<String, Any>()
            base["callType"] = callType
            base["result"] = result
            base["duration"] = duration
            base["at"] = at
            base["fromUid"] = fromUid
            val outMap = HashMap<String, Any>(base)
            outMap["otherUid"] = calleeUid
            outMap["otherName"] = calleeName
            outMap["direction"] = "out"
            val inMap = HashMap<String, Any>(base)
            inMap["otherUid"] = callerUid
            inMap["otherName"] = callerName
            inMap["direction"] = "in"
            try { db.collection("users").document(callerUid).collection("calls").document(cid).set(outMap, SetOptions.merge()).await() } catch (e: Exception) { com.aurachat.app.AuraLog.e("Repo", e, "writeCallEntries:707") }
            try { db.collection("users").document(calleeUid).collection("calls").document(cid).set(inMap, SetOptions.merge()).await() } catch (e: Exception) { com.aurachat.app.AuraLog.e("Repo", e, "writeCallEntries:708") }
        } catch (e: Exception) { com.aurachat.app.AuraLog.e("Repo", e, "writeCallEntries:709") }
    }

    private suspend fun writeCallMessage(
        chatId: String, msgType: String, callType: String, senderUid: String, senderName: String,
        read: Boolean, duration: Int, label: String, callerUid: String, calleeUid: String, unreadForCallee: Boolean
    ) {
        try {
            val m = HashMap<String, Any>()
            m["type"] = msgType
            m["callType"] = callType
            m["text"] = ""
            m["senderUid"] = senderUid
            m["senderName"] = senderName
            m["createdAt"] = FieldValue.serverTimestamp()
            m["read"] = read
            if (duration > 0) m["duration"] = duration
            db.collection("chats").document(chatId).collection("messages").add(m).await()
            val mine = hashMapOf<String, Any>(
                "lastMessage" to label,
                "lastMessageTime" to FieldValue.serverTimestamp(),
                "lastSenderUid" to senderUid,
                "lastMessageRead" to read,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val theirs = HashMap<String, Any>(mine)
            if (unreadForCallee) theirs["unreadCount"] = FieldValue.increment(1)
            db.collection("users").document(callerUid).collection("chats").document(chatId).set(mine, SetOptions.merge()).await()
            db.collection("users").document(calleeUid).collection("chats").document(chatId).set(theirs, SetOptions.merge()).await()
        } catch (e: Exception) { com.aurachat.app.AuraLog.e("Repo", e, "writeCallMessage:738") }
    }

    suspend fun logMissedCall(chatId: String, callerUid: String, callerName: String, calleeUid: String, calleeName: String, callType: String) {
        writeCallEntries(chatId, callerUid, calleeUid, callerName, calleeName, callType, "missed", 0, callerUid)
        val label = if (callType == "audio") "📞 Cevapsız sesli arama" else "📹 Cevapsız görüntülü arama"
        writeCallMessage(chatId, "missed_call", callType, callerUid, callerName, false, 0, label, callerUid, calleeUid, true)
    }

    suspend fun logDeclinedCall(chatId: String, callerUid: String, callerName: String, calleeUid: String, calleeName: String, callType: String) {
        writeCallEntries(chatId, callerUid, calleeUid, callerName, calleeName, callType, "declined", 0, calleeUid)
        val label = if (callType == "audio") "📞 Reddedilen sesli arama" else "📹 Reddedilen görüntülü arama"
        writeCallMessage(chatId, "declined_call", callType, callerUid, callerName, false, 0, label, callerUid, calleeUid, true)
    }

    suspend fun logCallDuration(
        chatId: String, myUid: String, myName: String, otherUid: String, otherName: String,
        callType: String, seconds: Int, callerUid: String
    ) {
        val calleeUid = if (callerUid == myUid) otherUid else myUid
        val callerName = if (callerUid == myUid) myName else otherName
        val calleeName = if (callerUid == myUid) otherName else myName
        writeCallEntries(chatId, callerUid, calleeUid, callerName, calleeName, callType, "answered", seconds, myUid)
        val m = seconds / 60
        val r = seconds % 60
        val dur = if (m == 0) "$r sn" else if (r != 0) "$m dk $r sn" else "$m dk"
        val label = (if (callType == "audio") "📞 Sesli arama" else "📹 Görüntülü arama") + " • " + dur
        writeCallMessage(chatId, "call_duration", callType, myUid, myName, true, seconds, label, myUid, otherUid, false)
    }

    /** Kullanıcı şikayeti: sunucuya (api/report) gönderilir, yönetici panelinde listelenir */
    suspend fun sendReport(chatId: String, reportedUid: String, reportedName: String, isGroup: Boolean, reporterName: String, reason: String, note: String, lastMsgs: List<JSONObject> = emptyList(), bubbleHex: String = ""): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val idToken = auth.currentUser?.getIdToken(false)?.await()?.token ?: return@withContext false
                val payload = JSONObject().put("chatId", chatId).put("reportedUid", reportedUid).put("reportedName", reportedName)
                    .put("isGroup", isGroup).put("reporterName", reporterName).put("reason", reason).put("note", note)
                    .put("messages", org.json.JSONArray(lastMsgs.take(5))).put("bubble", bubbleHex)
                val c = URL("https://aurachat-amber.vercel.app/api/report").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 10000; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer $idToken")
                c.outputStream.use { it.write(payload.toString().toByteArray()) }
                val ok = c.responseCode in 200..299
                c.disconnect()
                ok
            } catch (e: Exception) { false }
        }

    /** Arama bildirimi (kind=call) ya da cevapsız arama bildirimi gönderir */
    suspend fun sendCallPush(
        receiverUid: String, title: String, body: String, chatId: String, otherUid: String,
        otherName: String, callType: String, ringing: Boolean
    ) {
        withContext(Dispatchers.IO) {
            try {
                val idToken = auth.currentUser?.getIdToken(false)?.await()?.token ?: return@withContext
                val data = JSONObject()
                    .put("chatId", chatId)
                    .put("otherUid", otherUid)
                    .put("otherName", otherName)
                if (ringing) {
                    data.put("kind", "call").put("callType", callType).put("callerName", otherName)
                }
                val payload = JSONObject()
                    .put("receiverUid", receiverUid)
                    .put("title", title.take(100))
                    .put("body", body.take(200))
                    .put("data", data)
                    .put("tag", "call_$chatId")
                val c = URL(API).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer $idToken")
                c.outputStream.use { it.write(payload.toString().toByteArray()) }
                c.responseCode
                c.disconnect()
            } catch (ignored: Exception) { com.aurachat.app.AuraLog.e("Repo", ignored, "sendCallPush:818") }
        }
    }

    // ---------- Durum (statuses/{id} + statusMedia/{id}) ----------
    private val statusMediaCache = ConcurrentHashMap<String, String>()

    /** WhatsApp gibi: aralarında engel olan iki kişi birbirinin durumunu görmez (ben engellediysem ya da o beni engellediyse gizlenir) */
    private fun hiddenByBlock(uid: String): Boolean {
        val my = auth.currentUser?.uid ?: return false
        if (uid == my) return false
        return peekBlocked(my).contains(uid) || blockedCache[uid]?.contains(my) == true
    }

    fun statusesFlow(): Flow<List<StatusItem>> = callbackFlow {
        var raw: List<StatusItem> = emptyList()
        val asked = HashSet<String>()
        fun emit() {
            val v = raw.filter { !hiddenByBlock(it.uid) }
            statusMem = v
            saveStatuses(v)
            trySend(v)
        }
        // karşı tarafın engel listesi bilinmiyorsa bir kez okunur, sonra liste yeniden süzülür
        fun askBlocks(list: List<StatusItem>) {
            for (u in list.map { it.uid }.distinct()) {
                if (u == auth.currentUser?.uid || !asked.add(u)) continue
                db.collection("users").document(u).get().addOnSuccessListener { d ->
                    putBlocked(u, (d.get("blockedUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList())
                    emit()
                }
            }
        }
        val myUid = auth.currentUser?.uid
        val blkReg = if (myUid != null) db.collection("users").document(myUid).addSnapshotListener { snap, _ ->
            putBlocked(myUid, (snap?.get("blockedUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList())
            emit()
        } else null
        val reg = db.collection("statuses")
            .whereGreaterThan("expiresAt", System.currentTimeMillis())
            .addSnapshotListener { snap, _ ->
                if (snap == null) return@addSnapshotListener
                val list = snap.documents.mapNotNull { d ->
                    val uid = d.getString("uid") ?: return@mapNotNull null
                    StatusItem(
                        id = d.id,
                        uid = uid,
                        type = d.getString("type") ?: "text",
                        text = d.getString("text") ?: "",
                        bg = d.getString("bg") ?: "",
                        caption = d.getString("caption") ?: "",
                        createdAt = d.getLong("createdAt") ?: 0L,
                        expiresAt = d.getLong("expiresAt") ?: 0L,
                        viewers = (d.get("viewers") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                        hasImage = d.getBoolean("hasImage") ?: false,
                        link = (d.get("linkPreview") as? Map<*, *>)?.let { lp ->
                            val u = (lp["url"] as? String) ?: ""
                            if (u.isBlank()) null else LinkPreview(u, (lp["title"] as? String) ?: "", (lp["description"] as? String) ?: "", (lp["image"] as? String) ?: "")
                        },
                        music = com.aurachat.app.ui.statusMusicFromMap(d.get("music") as? Map<*, *>)
                    )
                }
                raw = list
                askBlocks(list)
                emit()
            }
        awaitClose { reg.remove(); blkReg?.remove() }
    }

    // Durum halkası ilk karede görünsün: son bilinen durum listesi bellekte ve diskte tutulur
    @Volatile private var statusMem: List<StatusItem>? = null

    fun peekStatuses(): List<StatusItem> {
        val now = System.currentTimeMillis()
        statusMem?.let { return it.filter { s -> s.expiresAt > now } }
        val f = java.io.File(profDir ?: return emptyList(), "statuses.json")
        if (!f.exists()) return emptyList()
        return try {
            val a = org.json.JSONArray(f.readText())
            val l = (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val v = o.optJSONArray("v")
                StatusItem(
                    id = o.optString("i"), uid = o.optString("u"), type = o.optString("t", "text"), text = o.optString("x"),
                    bg = o.optString("b"), caption = o.optString("c"), createdAt = o.optLong("ca"), expiresAt = o.optLong("e"),
                    viewers = if (v == null) emptyList() else (0 until v.length()).map { v.optString(it) },
                    hasImage = o.optBoolean("h"),
                    music = com.aurachat.app.ui.statusMusicFromJson(o.optJSONObject("m"))
                )
            }
            statusMem = l
            l.filter { it.expiresAt > now }
        } catch (e: Throwable) { emptyList() }
    }

    private fun saveStatuses(list: List<StatusItem>) {
        val d = profDir ?: return
        bg.launch {
            try {
                val a = org.json.JSONArray()
                list.forEach { s ->
                    a.put(org.json.JSONObject().put("i", s.id).put("u", s.uid).put("t", s.type).put("x", s.text).put("b", s.bg)
                        .put("c", s.caption).put("ca", s.createdAt).put("e", s.expiresAt).put("v", org.json.JSONArray(s.viewers)).put("h", s.hasImage)
                        .put("m", s.music?.toJson()))
                }
                java.io.File(d, "statuses.json").writeText(a.toString())
            } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Repo", e, "saveStatuses") }
        }
    }

    private fun stMediaFile(id: String): java.io.File = java.io.File(java.io.File(profDir?.parentFile, "stmedia"), "$id.txt")

    fun peekStatusMedia(id: String): String? = statusMediaCache[id]

    suspend fun loadStatusMedia(id: String): String {
        statusMediaCache[id]?.let { return it }
        // önce diskten (uygulama yeniden açılsa bile anında)
        try {
            val f = stMediaFile(id)
            if (f.exists()) { val t = f.readText(); if (t.isNotEmpty()) { statusMediaCache[id] = t; return t } }
        } catch (_: Throwable) {}
        return try {
            val d = db.collection("statusMedia").document(id).get().await()
            (d.getString("image") ?: "").also {
                if (it.isNotEmpty()) {
                    statusMediaCache[id] = it
                    try { stMediaFile(id).apply { parentFile?.mkdirs() }.writeText(it) } catch (_: Throwable) {}
                }
            }
        } catch (e: Exception) {
            ""
        }
    }

    suspend fun postStatus(me: UserProfile, type: String, text: String, bg: String, caption: String, image: String?, link: LinkPreview? = null, music: com.aurachat.app.ui.StatusMusic? = if (type == "image") com.aurachat.app.ui.StatusMusicHolder.selected else null, at: Long = 0L, notify: Boolean = true) {
        val ref = db.collection("statuses").document()
        val now = if (at > 0L) at else System.currentTimeMillis()
        if (!image.isNullOrEmpty()) {
            db.collection("statusMedia").document(ref.id).set(mapOf("uid" to me.uid, "image" to image)).await()
            statusMediaCache[ref.id] = image
        }
        val data = HashMap<String, Any>()
        data["uid"] = me.uid
        data["type"] = type
        data["text"] = text
        data["bg"] = bg
        data["caption"] = caption
        data["createdAt"] = now
        data["expiresAt"] = now + 24L * 60 * 60 * 1000
        data["viewers"] = emptyList<String>()
        data["hasImage"] = !image.isNullOrEmpty()
        if (music != null) data["music"] = music.toMap()
        if (link != null) data["linkPreview"] = mapOf("url" to link.url, "title" to link.title, "description" to link.description, "image" to link.image)
        ref.set(data).await()
        // bildirim almayı açmış kişilere "Durum eklendi" bildirimi (sunucu gönderir); hata gönderimi bozmaz
        if (notify) this.bg.launch { notifyStatusPosted(ref.id) }
    }

    /** Bu kişinin durum bildirimlerini alıyor muyum */
    suspend fun statusNotifOn(me: String, uid: String): Boolean {
        val l = db.collection("users").document(me).get().await().get("statusNotifUids") as? List<*>
        return l?.contains(uid) == true
    }

    suspend fun setStatusNotif(me: String, uid: String, on: Boolean) {
        db.collection("users").document(me).set(
            mapOf("statusNotifUids" to (if (on) FieldValue.arrayUnion(uid) else FieldValue.arrayRemove(uid))),
            SetOptions.merge()
        ).await()
    }

    private suspend fun notifyStatusPosted(statusId: String) {
        withContext(Dispatchers.IO) {
            try {
                val idToken = auth.currentUser?.getIdToken(false)?.await()?.token ?: return@withContext
                val c = URL(API.replace("send-notification", "status-notify")).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer $idToken")
                c.outputStream.use { it.write(JSONObject().put("statusId", statusId).toString().toByteArray()) }
                c.responseCode
                c.disconnect()
            } catch (ignored: Exception) { com.aurachat.app.AuraLog.e("Repo", ignored, "notifyStatus") }
        }
    }

    /** Birden fazla resmi aynı anda yükler; sıra createdAt ile korunur (sıralı beklemeye göre çok daha hızlı) */
    suspend fun postStatusImages(me: UserProfile, items: List<Pair<String, String>>) {
        val music = com.aurachat.app.ui.StatusMusicHolder.selected
        val base = System.currentTimeMillis()
        kotlinx.coroutines.coroutineScope {
            items.mapIndexed { i, (data, cap) ->
                async(Dispatchers.IO) { postStatus(me, "image", "", "", cap, data, null, music, base + i, i == 0) }
            }.awaitAll()
        }
    }

    suspend fun deleteStatus(id: String) {
        try { db.collection("statusMedia").document(id).delete().await() } catch (e: Exception) { /* medyası olmayan durumda belge yoktur; kural reddeder, sorun değil */ }
        db.collection("statuses").document(id).delete().await()
        statusMediaCache.remove(id)
    }

    /** Mevcut bir durumun müziğini değiştirir (kendi durumumuz) */
    suspend fun updateStatusMusic(id: String, m: com.aurachat.app.ui.StatusMusic) {
        db.collection("statuses").document(id).update("music", m.toMap()).await()
    }

    /** Sürükle-bırak sonrası: yeni sıradaki durumlara, eski zaman değerleri sırayla verilir */
    suspend fun reorderStatuses(ordered: List<StatusItem>, times: List<Long>) {
        // tek seferde (atomik): ara sıralar görünmesin
        val batch = db.batch()
        var n = 0
        for (i in ordered.indices) {
            if (i < times.size && ordered[i].createdAt != times[i]) {
                batch.update(db.collection("statuses").document(ordered[i].id), "createdAt", times[i]); n++
            }
        }
        if (n > 0) batch.commit().await()
    }

    /** İki durumun sırasını değiştirir (createdAt değerleri takas edilir) */
    suspend fun swapStatusOrder(a: StatusItem, b: StatusItem) {
        db.collection("statuses").document(a.id).update("createdAt", b.createdAt).await()
        db.collection("statuses").document(b.id).update("createdAt", a.createdAt).await()
    }

    fun markStatusViewed(id: String, me: String) {
        db.collection("statuses").document(id).update("viewers", FieldValue.arrayUnion(me))
    }

    /** Süresi dolmuş kendi durumlarımı temizler */
    fun cleanupMyStatuses(me: String) {
        bg.launch {
            try {
                val snap = db.collection("statuses").whereEqualTo("uid", me).get().await()
                val now = System.currentTimeMillis()
                for (d in snap.documents) {
                    if ((d.getLong("expiresAt") ?: 0L) <= now) {
                        if (d.getBoolean("hasImage") == true) try { db.collection("statusMedia").document(d.id).delete().await() } catch (e: Exception) { com.aurachat.app.AuraLog.e("Repo", e, "cleanupMyStatuses:905") }
                        try { d.reference.delete().await() } catch (e: Exception) { com.aurachat.app.AuraLog.e("Repo", e, "cleanupMyStatuses:906") }
                    }
                }
            } catch (e: Exception) { com.aurachat.app.AuraLog.e("Repo", e, "cleanupMyStatuses:909") }
        }
    }

    // ---------- Gönderme ----------
    private fun replyMap(r: ReplyRef): Map<String, Any> =
        HashMap<String, Any>().apply {
            put("msgId", r.msgId); put("senderName", r.senderName)
            put("previewText", r.previewText); put("senderUid", r.senderUid)
            if (r.isStatus) put("isStatus", true)
        }

    suspend fun loadGroup(groupId: String): GroupData? {
        val d = db.collection("groups").document(groupId).get().await()
        return if (d.exists()) d.toGroup() else null
    }

    private fun DocumentSnapshot.toGroup() = GroupData(
        id = id,
        name = getString("name") ?: "Grup",
        members = (get("members") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
        admins = (get("admins") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
        createdBy = getString("createdBy") ?: "",
        photo = getString("photo") ?: "",
        permEdit = getBoolean("permEdit") != false,
        permSend = getBoolean("permSend") != false,
        permAdd = getBoolean("permAdd") != false
    )

    private val groupCache = ConcurrentHashMap<String, GroupData>()

    /** Bellek/disk önbelleğindeki grup (ad + fotoğraf) – ağı beklemeden gösterilir */
    /** Cihazda önbellekte bilinen, iki kişinin de üyesi olduğu grupların sayısı */
    fun commonGroupCount(a: String, b: String): Int {
        val files = java.io.File(profDir ?: return 0, "").listFiles { f -> f.name.startsWith("g_") && f.name.endsWith(".json") } ?: return 0
        return files.count { f -> peekGroup(f.name.removePrefix("g_").removeSuffix(".json"))?.let { a in it.members && b in it.members } == true }
    }

    fun peekGroup(id: String): GroupData? {
        groupCache[id]?.let { return it }
        val f = java.io.File(profDir ?: return null, "g_$id.json")
        if (!f.exists()) return null
        return try {
            val o = org.json.JSONObject(f.readText())
            fun l(k: String): List<String> { val a = o.optJSONArray(k) ?: return emptyList(); return (0 until a.length()).map { a.optString(it) } }
            GroupData(id, o.optString("n"), l("m"), l("a"), o.optString("c"), o.optString("p"), o.optBoolean("pe", true), o.optBoolean("ps", true), o.optBoolean("pa", true)).also { groupCache[id] = it }
        } catch (e: Throwable) { null }
    }

    private fun saveGroup(g: GroupData) {
        groupCache[g.id] = g
        val d = profDir ?: return
        bg.launch {
            try {
                val o = org.json.JSONObject().put("n", g.name).put("m", org.json.JSONArray(g.members))
                    .put("a", org.json.JSONArray(g.admins)).put("c", g.createdBy).put("p", g.photo)
                    .put("pe", g.permEdit).put("ps", g.permSend).put("pa", g.permAdd)
                java.io.File(d, "g_${g.id}.json").writeText(o.toString())
            } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Repo", e, "saveGroup:957") }
        }
    }

    fun groupFlow(groupId: String): Flow<GroupData?> = callbackFlow {
        peekGroup(groupId)?.let { trySend(it) }
        val reg = db.collection("groups").document(groupId).addSnapshotListener { snap, _ ->
            val g = if (snap != null && snap.exists()) snap.toGroup() else null
            if (g != null) saveGroup(g)
            trySend(g)
        }
        awaitClose { reg.remove() }
    }

    /**
     * Tek mesaj yazma yolu: mesaj + sohbet özetleri tek paket, ardından bildirim.
     * Sunucuya ulaşana kadar bekler; arayüz yerel önbellekten anında gösterir.
     */
    suspend fun postMessage(
        me: UserProfile,
        t: ChatTarget,
        fields: Map<String, Any>,
        summary: String,
        pushBody: String,
        msgType: String = "text",
        mentions: List<String> = emptyList()
    ): String {
        // Varsayılan süreli mesaj: yeni bire bir sohbetin ilk mesajında sohbete uygulanır ve bilgi kartı düşer
        if (!t.isGroup) {
            val dm = defaultDisappearMs()
            if (dm > 0 && dmChecked.add(t.chatId)) {
                val exists = try { summaryRef(me.uid, t.chatId).get().await().exists() } catch (e: Exception) { true }
                if (!exists) {
                    db.collection("chats").document(t.chatId).set(mapOf("disappearAfter" to dm), SetOptions.merge())
                    db.collection("chats").document(t.chatId).collection("messages").add(
                        mapOf("type" to "system",
                            "text" to "${me.name} yeni sohbetlerdeki süreli mesajlar için varsayılan süreyi kullanıyor. Tutulmadığı takdirde yeni mesajlar gönderildikten ${disappearLabel(dm)} sonra bu sohbetten kaybolacak. Kendi varsayılan sürenizi ayarlayın",
                            "senderUid" to me.uid, "senderName" to me.name, "createdAt" to FieldValue.serverTimestamp(), "read" to true)
                    )
                }
            }
        }
        val msgRef = db.collection("chats").document(t.chatId).collection("messages").document()
        val data = HashMap<String, Any>(fields)
        data["senderUid"] = me.uid
        data["senderName"] = me.name
        data["createdAt"] = FieldValue.serverTimestamp()
        data["read"] = false

        val batch = db.batch()
        batch.set(msgRef, data)

        var group: GroupData? = null
        if (t.isGroup) {
            group = loadGroup(t.chatId) ?: throw IllegalStateException("Grup bulunamadı")
            for (m in group.members) {
                batch.set(
                    summaryRef(m, t.chatId),
                    mapOf(
                        "isGroup" to true,
                        "groupName" to group.name,
                        "lastMessage" to summary,
                        "lastMessageTime" to FieldValue.serverTimestamp(),
                        "lastSenderUid" to me.uid,
                        "lastSenderName" to me.name,
                        "lastMessageRead" to false,
                        "unreadCount" to (if (m == me.uid) 0 else FieldValue.increment(1)),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    SetOptions.merge()
                )
            }
        } else {
            batch.set(
                summaryRef(me.uid, t.chatId),
                mapOf(
                    "otherUid" to t.otherUid,
                    "otherName" to t.name,
                    "lastMessage" to summary,
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastMessageRead" to false,
                    "unreadCount" to 0,
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
            batch.set(
                summaryRef(t.otherUid, t.chatId),
                mapOf(
                    "otherUid" to me.uid,
                    "otherName" to me.name,
                    "lastMessage" to summary,
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastMessageRead" to false,
                    "typing" to false,
                    "unreadCount" to FieldValue.increment(1),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
        if (group != null) {
            for (m in group.members) {
                if (mentions.contains(m) && m != me.uid) {
                    batch.set(summaryRef(m, t.chatId), mapOf("hasMention" to true), SetOptions.merge())
                }
            }
        }
        batch.commit().await()

        val msgId = msgRef.id
        if (group != null) {
            val g = group
            for (m in g.members) {
                if (m == me.uid) continue
                bg.launch {
                    notify(m, g.name, "${me.name}: $pushBody", t.chatId, t.chatId, g.name, if (mentions.contains(m)) "mention" else msgType, msgId)
                }
            }
        } else {
            bg.launch { notify(t.otherUid, me.name, pushBody, t.chatId, me.uid, me.name, msgType, msgId) }
        }
        return msgId
    }

    suspend fun sendText(
        me: UserProfile, t: ChatTarget, text: String, reply: ReplyRef?,
        mentions: List<String> = emptyList(), mentionNames: List<String> = emptyList(),
        preview: LinkPreview? = null, noPreview: Boolean = false
    ) {
        val f = HashMap<String, Any>()
        f["type"] = "text"
        f["text"] = text
        if (mentions.isNotEmpty()) { f["mentions"] = mentions; f["mentionNames"] = mentionNames }
        if (reply != null) f["replyTo"] = replyMap(reply)
        if (preview != null) f["linkPreview"] = mapOf("url" to preview.url, "title" to preview.title, "description" to preview.description, "image" to preview.image)
        val id = postMessage(me, t, f, text.take(100), text.take(200), "text", mentions)
        val url = Regex("https?://[^\\s<>\"']+", RegexOption.IGNORE_CASE).find(text)?.value?.trimEnd('.', ',', ';', ':', '!', '?', ')', ']')
        if (url != null && id.isNotEmpty() && preview == null && !noPreview) attachLinkPreview(t.chatId, id, url)
    }

    /** Linkin başlık/açıklama/resim bilgisini sunucudan alıp mesaja yazar (web ile aynı API) */
    private val lpCache = java.util.concurrent.ConcurrentHashMap<String, LinkPreview>()

    /** Aynı link için ikinci çağrı (paylaşma ekranı → gönderim → sohbet) ağa gitmeden anında döner */
    suspend fun fetchLinkPreview(url: String): LinkPreview? {
        lpCache[url]?.let { return it }
        // Kendi bağlantımız: ağa gitmeden yerel kart (kapak uygulama simgesinden çizilir)
        if (url.contains("aurachat-amber.vercel.app")) return LinkPreview(url, "AuraChat", "", "")
        val r = fetchLinkPreviewNet(url)
        if (r != null) lpCache[url] = r
        return r
    }

    private suspend fun fetchLinkPreviewNet(url: String): LinkPreview? {
        return withContext(Dispatchers.IO) {
            try {
                val host0 = try { android.net.Uri.parse(url).host?.lowercase() ?: "" } catch (e: Exception) { "" }
                if (host0.endsWith("tiktok.com")) {
                    // TikTok'un og:image adresi sunucuda 500 karakterde kesiliyor → oEmbed ile tam adresi al
                    try {
                        // vt.tiktok.com kısa bağlantısını gerçek video adresine çöz
                        var full = url
                        if (host0.startsWith("vt.") || host0.startsWith("vm.") || !url.contains("/video/")) {
                            val rc = URL(url).openConnection() as HttpURLConnection
                            rc.instanceFollowRedirects = true
                            rc.connectTimeout = 10000; rc.readTimeout = 15000
                            rc.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                            rc.connect()
                            full = rc.url.toString()
                            rc.disconnect()
                        }
                        full = full.substringBefore("?")
                        val oc = URL("https://www.tiktok.com/oembed?url=" + java.net.URLEncoder.encode(full, "UTF-8")).openConnection() as HttpURLConnection
                        oc.connectTimeout = 10000; oc.readTimeout = 15000
                        oc.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                        val ob = oc.inputStream.bufferedReader().readText(); oc.disconnect()
                        val oo = JSONObject(ob)
                        val thumb = oo.optString("thumbnail_url")
                        if (thumb.isNotBlank()) {
                            val author = oo.optString("author_name")
                            return@withContext LinkPreview(
                                url, "TikTok" + if (author.isNotBlank()) " · $author" else "", oo.optString("title"), thumb
                            )
                        }
                    } catch (e: Exception) { com.aurachat.app.AuraLog.e("Repo", e, "fetchLinkPreviewNet:1127") }
                }
                if (host0.endsWith("youtube.com") || host0 == "youtu.be") {
                    // YouTube sayfası çerez/onay sayfası döndürdüğü için başlık ve resim oEmbed + sabit küçük resim adresinden alınır
                    val u0 = android.net.Uri.parse(url)
                    val vid = if (host0 == "youtu.be") u0.lastPathSegment
                        else u0.getQueryParameter("v") ?: u0.pathSegments.let { sg -> if (sg.size >= 2 && (sg[0] == "shorts" || sg[0] == "embed" || sg[0] == "live")) sg[1] else null }
                    if (!vid.isNullOrBlank()) {
                        var title = ""; var author = ""
                        try {
                            val oc = URL("https://www.youtube.com/oembed?format=json&url=" + java.net.URLEncoder.encode("https://www.youtube.com/watch?v=$vid", "UTF-8")).openConnection() as HttpURLConnection
                            oc.connectTimeout = 10000; oc.readTimeout = 15000
                            oc.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                            val oo = JSONObject(oc.inputStream.bufferedReader().readText()); oc.disconnect()
                            title = oo.optString("title"); author = oo.optString("author_name")
                        } catch (e: Exception) { com.aurachat.app.AuraLog.e("Repo", e, "fetchLinkPreviewNet:1142") }
                        return@withContext LinkPreview(
                            url, title.ifBlank { "YouTube" }, if (author.isNotBlank()) "YouTube · $author" else "YouTube",
                            "https://i.ytimg.com/vi/$vid/hqdefault.jpg"
                        )
                    }
                }
                // Sayfayı telefondan çek, og:başlık / açıklama / resim bilgilerini oku (sunucuya gerek yok)
                val pc = URL(url).openConnection() as HttpURLConnection
                pc.instanceFollowRedirects = true
                pc.connectTimeout = 10000; pc.readTimeout = 15000
                val fbHost = host0.contains("facebook.com") || host0.endsWith("fb.com") || host0.endsWith("fb.watch") || host0.endsWith("fb.me") || host0.contains("instagram.com")
                pc.setRequestProperty("User-Agent", if (fbHost) "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)" else "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36 facebookexternalhit/1.1")
                pc.setRequestProperty("Accept-Language", "tr,en;q=0.8")
                val ctype = pc.contentType ?: ""
                if (pc.responseCode !in 200..299 || (ctype.isNotEmpty() && !ctype.contains("html", true))) { pc.disconnect(); return@withContext null }
                val finalUrl = pc.url
                val bytes = pc.inputStream.use { ins ->
                    val bo = java.io.ByteArrayOutputStream()
                    val buf = ByteArray(8192)
                    while (bo.size() < 300_000) { val n = ins.read(buf); if (n < 0) break; bo.write(buf, 0, n) }
                    bo.toByteArray()
                }
                pc.disconnect()
                val html = String(bytes, Charsets.UTF_8)
                val head = html.substringBefore("</head>", html)
                fun meta(vararg keys: String): String {
                    for (k in keys) {
                        val kq = Regex.escape(k)
                        val r1 = Regex("<meta[^>]+(?:property|name)=[\"']$kq[\"'][^>]*content=[\"']([^\"']*)[\"']", RegexOption.IGNORE_CASE)
                        val r2 = Regex("<meta[^>]+content=[\"']([^\"']*)[\"'][^>]*(?:property|name)=[\"']$kq[\"']", RegexOption.IGNORE_CASE)
                        val v = r1.find(head)?.groupValues?.get(1) ?: r2.find(head)?.groupValues?.get(1)
                        if (!v.isNullOrBlank()) return android.text.Html.fromHtml(v, android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
                    }
                    return ""
                }
                var title = meta("og:title", "twitter:title")
                if (title.isBlank()) {
                    val t = Regex("<title[^>]*>([^<]*)</title>", RegexOption.IGNORE_CASE).find(head)?.groupValues?.get(1) ?: ""
                    title = android.text.Html.fromHtml(t, android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()
                }
                val desc = meta("og:description", "twitter:description", "description")
                var image = meta("og:image", "og:image:url", "twitter:image", "twitter:image:src")
                if (image.isNotBlank()) image = try { URL(finalUrl, image).toString() } catch (e: Exception) { "" }
                if (title.isBlank() && desc.isBlank() && image.isBlank()) return@withContext null
                LinkPreview(url, title.take(140), desc.take(220), image)
            } catch (e: Exception) { null }
        }
    }

    private suspend fun attachLinkPreview(chatId: String, msgId: String, url: String) {
        val lp = fetchLinkPreview(url) ?: return
        try {
            msgRef(chatId, msgId).update("linkPreview", mapOf("url" to lp.url, "title" to lp.title, "description" to lp.description, "image" to lp.image)).await()
        } catch (e: Exception) { com.aurachat.app.AuraLog.e("Repo", e, "attachLinkPreview:1196") }
    }

    /** Yeni tepki: mesaj sahibine bildirim (web applyReaction ile aynı) */
    suspend fun reactNotify(me: UserProfile, t: ChatTarget, m: Message, emoji: String) {
        if (m.senderUid.isBlank() || m.senderUid == me.uid) return
        val title = if (t.isGroup) t.name.ifBlank { "Grup" } else me.name
        val body = "$emoji ${if (t.isGroup) me.name + " " else ""}mesajına tepki verdi: ${previewOf(m).take(80)}".trim()
        notify(m.senderUid, title, body, t.chatId, if (t.isGroup) t.chatId else me.uid, title, "reaction", "")
    }

    suspend fun sendImages(
        me: UserProfile, t: ChatTarget, images: List<String>, caption: String, reply: ReplyRef?,
        viewOnce: Boolean = false
    ) {
        val f = HashMap<String, Any>()
        f["type"] = "image"
        f["text"] = if (viewOnce) "" else caption
        if (!viewOnce) {
            val th = images.take(4).map { Media.tinyThumb(it) }
            if (images.size == 1) { if (th[0].isNotEmpty()) f["thumb"] = th[0] }
            else if (th.any { it.isNotEmpty() }) f["thumbs"] = th
        }
        if (images.size == 1) {
            f["imageUrl"] = images[0]
            if (viewOnce) {
                f["viewOnce"] = true
                // Grupta açılmamış fotoğraf 48 saat sonra kalkar (web ile aynı alan)
                if (t.isGroup) f["expiresAtMs"] = System.currentTimeMillis() + 48 * 3600 * 1000L
            }
        } else {
            f["images"] = images
            f["imagesCount"] = images.size
            f["imagesDelivered"] = false
        }
        if (reply != null) f["replyTo"] = replyMap(reply)
        val label = if (images.size > 1) "📷 ${images.size} Fotoğraf" else "📷 Fotoğraf"
        val summary = if (viewOnce) "📷 Bir kez görüntülenebilir fotoğraf" else if (caption.isNotBlank()) "$label $caption" else label
        postMessage(me, t, f, summary.take(100), summary.take(200), "image")
    }

    suspend fun sendAudio(me: UserProfile, t: ChatTarget, dataUrl: String, seconds: Int, reply: ReplyRef?, viewOnce: Boolean = false, wave: List<Int> = emptyList()) {
        val f = HashMap<String, Any>()
        if (wave.isNotEmpty()) f["wave"] = wave
        f["type"] = "audio"
        f["audio"] = dataUrl
        f["audioDuration"] = seconds
        f["text"] = ""
        if (viewOnce) f["viewOnce"] = true
        if (reply != null) f["replyTo"] = replyMap(reply)
        val label = if (viewOnce) "🎤 Bir kez dinlenebilir ses" else "🎤 Sesli mesaj (${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')})"
        postMessage(me, t, f, label, if (viewOnce) "🎤 Bir kez dinlenebilir ses" else "🎤 Sesli mesaj", "audio")
    }

    suspend fun sendPoll(me: UserProfile, t: ChatTarget, question: String, options: List<String>, multi: Boolean, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "poll"
        f["question"] = question
        f["options"] = options.mapIndexed { i, s -> mapOf("id" to "o$i", "text" to s) }
        f["multi"] = multi
        f["votes"] = HashMap<String, Any>()
        f["text"] = ""
        if (reply != null) f["replyTo"] = replyMap(reply)
        postMessage(me, t, f, ("📊 " + question).take(100), ("📊 Anket gönderdi: " + question).take(120), "poll")
    }

    /** Ankette bir seçeneğe dokunma: tekli ankette aynısına tekrar dokunmak oyu geri alır */
    fun votePoll(me: String, chatId: String, m: Message, optId: String) {
        val mine = m.votes[me] ?: emptyList()
        val has = mine.contains(optId)
        val next = if (m.pollMulti) (if (has) mine - optId else mine + optId) else (if (has) emptyList() else listOf(optId))
        msgRef(chatId, m.id).update("votes.$me", next)
    }

    suspend fun sendLocation(me: UserProfile, t: ChatTarget, lat: Double, lng: Double, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "location"
        f["lat"] = lat
        f["lng"] = lng
        f["text"] = ""
        if (reply != null) f["replyTo"] = replyMap(reply)
        postMessage(me, t, f, "📍 Konum", "📍 Konum gönderdi", "location")
    }

    /** Kişi kartı: text = ad, fileName = telefon, fileMime = AuraChat uid'si (boş olabilir) */
    suspend fun sendContact(me: UserProfile, t: ChatTarget, uid: String, name: String, phone: String, reply: ReplyRef? = null) {
        val f = HashMap<String, Any>()
        f["type"] = "contact"
        f["text"] = name.take(120)
        f["fileName"] = phone
        f["fileMime"] = uid
        if (reply != null) f["replyTo"] = replyMap(reply)
        postMessage(me, t, f, "👤 $name".take(100), "👤 Kişi gönderdi", "contact")
    }

    suspend fun sendDocument(me: UserProfile, t: ChatTarget, name: String, mime: String, dataUrl: String, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "document"
        f["fileName"] = name.take(120)
        f["fileMime"] = mime
        f["imageUrl"] = dataUrl
        f["text"] = ""
        if (reply != null) f["replyTo"] = replyMap(reply)
        postMessage(me, t, f, "📄 $name".take(100), "📄 Belge gönderdi", "document")
    }

    suspend fun sendVideo(me: UserProfile, t: ChatTarget, v: Media.PickedVideo, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "video"
        f["fileName"] = v.name.take(120)
        f["fileMime"] = v.mime
        f["imageUrl"] = v.dataUrl
        if (v.poster.isNotEmpty()) f["thumb"] = v.poster
        f["audioDuration"] = v.durationSec
        f["text"] = ""
        if (reply != null) f["replyTo"] = replyMap(reply)
        postMessage(me, t, f, "🎥 Video", "🎥 Video gönderdi", "video")
    }

    /** Bir mesajı başka sohbete iletir */
    suspend fun forward(me: UserProfile, to: ChatTarget, m: Message) {
        val f = HashMap<String, Any>()
        f["forwarded"] = true
        f["text"] = m.text
        when (m.type) {
            "image" -> {
                f["type"] = "image"
                if (m.images.isNotEmpty()) {
                    f["images"] = m.images.map { Media.dataUrlOf(it) }
                    f["imagesCount"] = m.images.size
                    f["imagesDelivered"] = false
                } else if (m.imageUrl.isNotEmpty()) {
                    f["imageUrl"] = Media.dataUrlOf(m.imageUrl)
                }
            }
            "audio" -> {
                f["type"] = "audio"
                f["audio"] = Media.dataUrlOf(m.audio)
                f["audioDuration"] = m.audioDuration
            }
            "location" -> {
                f["type"] = "location"
                f["lat"] = m.lat
                f["lng"] = m.lng
            }
            "document" -> {
                f["type"] = "document"
                f["fileName"] = m.fileName
                f["fileMime"] = m.fileMime
                f["imageUrl"] = Media.dataUrlOf(m.imageUrl, m.fileMime)
            }
            "video" -> {
                f["type"] = "video"
                f["fileName"] = m.fileName
                f["fileMime"] = m.fileMime
                f["imageUrl"] = Media.dataUrlOf(m.imageUrl, m.fileMime)
                if (m.thumb.isNotEmpty()) f["thumb"] = m.thumb
                f["audioDuration"] = m.audioDuration
            }
            else -> {
                f["type"] = "text"
                m.linkPreview?.let { lp -> f["linkPreview"] = mapOf("url" to lp.url, "title" to lp.title, "description" to lp.description, "image" to lp.image) }
            }
        }
        val newId = postMessage(me, to, f, previewOf(m).take(100), previewOf(m).take(200), m.type)
        if (m.type == "text" && m.linkPreview == null && newId.isNotEmpty()) {
            val url = Regex("https?://[^\\s<>\"']+", RegexOption.IGNORE_CASE).find(m.text)?.value?.trimEnd('.', ',', ';', ':', '!', '?', ')', ']')
            if (url != null) attachLinkPreview(to.chatId, newId, url)
        }
    }

    fun previewOf(m: Message): String = when {
        m.deleted || m.type == "deleted" -> "🚫 Bu mesaj silindi"
        m.type == "image" && m.viewOnce -> "📷 Bir kez görüntülenebilir fotoğraf"
        m.type == "image" -> if (m.images.size > 1 || m.imagesCount > 1) "📷 ${maxOf(m.images.size, m.imagesCount)} Fotoğraf" else "📷 Fotoğraf"
        m.type == "audio" && m.viewOnce -> "🎤 Bir kez dinlenebilir ses"
        m.type == "audio" -> "🎤 Sesli mesaj"
        m.type == "location" -> "📍 Konum"
        m.type == "document" -> "📄 " + m.fileName.ifBlank { "Belge" }
        m.type == "contact" -> "👤 " + m.text
        m.type == "video" -> "🎥 Video"
        m.type == "poll" -> "📊 " + m.question.ifBlank { "Anket" }.take(100)
        else -> m.text.take(120)
    }

    // ---------- Sohbet "son görülen mesaj" (okunmamış ayırıcısı) + klavye yüksekliği ----------
    fun lastSeen(chatId: String): Long = prefs?.getLong("seen_$chatId", 0L) ?: 0L
    fun setLastSeen(chatId: String, t: Long) {
        if (t > lastSeen(chatId)) prefs?.edit()?.putLong("seen_$chatId", t)?.apply()
    }
    fun savedKbPx(): Int = prefs?.getInt("kb_px", 0) ?: 0
    fun saveKbPx(px: Int) { prefs?.edit()?.putInt("kb_px", px)?.apply() }

    // ---------- Bir kez görüntülenebilir fotoğraf ----------
    fun isViewOnceSeen(chatId: String, msgId: String): Boolean =
        prefs?.getBoolean("vo_${chatId}_$msgId", false) ?: false

    /** Birebir: fotoğraf sunucudan silinir. Grup: mesaj ortak olduğu için sadece bu cihazda "açıldı" işaretlenir. */
    fun openViewOnce(chatId: String, msgId: String, isGroup: Boolean) {
        if (!isGroup) msgRef(chatId, msgId).update("imageDelivered", true)
    }

    fun consumeViewOnce(chatId: String, msgId: String, isGroup: Boolean) {
        if (isGroup) {
            prefs?.edit()?.putBoolean("vo_${chatId}_$msgId", true)?.apply()
        } else {
            msgRef(chatId, msgId).update("imageUrl", null, "imageDelivered", true)
        }
    }

    /** Tek dinlemelik ses dinlendi: birebirde ses sunucudan silinir, grupta bu cihazda "dinlendi" işaretlenir */
    fun consumeAudioOnce(chatId: String, msgId: String, isGroup: Boolean) {
        if (isGroup) {
            prefs?.edit()?.putBoolean("vo_${chatId}_$msgId", true)?.apply()
        } else {
            msgRef(chatId, msgId).update("audio", null, "audioDelivered", true)
        }
    }

    // ---------- Mesaj işlemleri ----------
    private fun msgRef(chatId: String, msgId: String) =
        db.collection("chats").document(chatId).collection("messages").document(msgId)

    fun react(me: String, chatId: String, msgId: String, emoji: String, current: String?) {
        val v: Any = if (current == emoji) FieldValue.delete() else emoji
        msgRef(chatId, msgId).update("reactions.$me", v)
    }

    /** Sabitlemeler sohbet belgesinde (chats/{id}.pins.{msgId} = {at, until}); karşı tarafın mesajı da sabitlenebilsin diye mesaj belgesine yazılmaz */
    fun pinMessage(chatId: String, msgId: String, pin: Boolean, durationMs: Long = 0L) {
        val ref = db.collection("chats").document(chatId)
        if (pin) {
            val now = System.currentTimeMillis()
            ref.set(mapOf("pins" to mapOf(msgId to mapOf("at" to now, "until" to (if (durationMs > 0L) now + durationMs else 0L)))), SetOptions.merge())
        } else ref.update("pins.$msgId", FieldValue.delete())
    }

    /** msgId -> (sabitlenme zamanı, bitiş zamanı) */
    private val pinsMem = ConcurrentHashMap<String, Map<String, Pair<Long, Long>>>()

    /** Sabit mesajlar: bellekte yoksa diskten (sohbet açılırken sabit çubuk sonradan çıkmasın) */
    fun peekPins(chatId: String): Map<String, Pair<Long, Long>> = pinsMem[chatId] ?: run {
        val s = prefs?.getString("pins_$chatId", null) ?: return emptyMap()
        try {
            val o = org.json.JSONObject(s); val out = HashMap<String, Pair<Long, Long>>()
            o.keys().forEach { k -> val a = o.optJSONArray(k); if (a != null) out[k] = Pair(a.optLong(0), a.optLong(1)) }
            out.also { pinsMem[chatId] = it }
        } catch (e: Throwable) { emptyMap() }
    }

    fun pinsFlow(chatId: String): Flow<Map<String, Pair<Long, Long>>> = callbackFlow {
        val reg = db.collection("chats").document(chatId).addSnapshotListener { snap, _ ->
            val out = HashMap<String, Pair<Long, Long>>()
            (snap?.get("pins") as? Map<*, *>)?.forEach { (k, v) ->
                if (k is String && v is Map<*, *>) out[k] = Pair((v["at"] as? Number)?.toLong() ?: 0L, (v["until"] as? Number)?.toLong() ?: 0L)
            }
            if (snap != null) {
                pinsMem[chatId] = out
                val o = org.json.JSONObject(); out.forEach { (k, v) -> o.put(k, org.json.JSONArray().put(v.first).put(v.second)) }
                prefs?.edit()?.putString("pins_$chatId", o.toString())?.apply()
            }
            trySend(out)
        }
        awaitClose { reg.remove() }
    }

    fun editText(chatId: String, msgId: String, text: String) {
        msgRef(chatId, msgId).update(
            mapOf("text" to text, "edited" to true, "editedAt" to FieldValue.serverTimestamp())
        )
    }

    /** Silinen mesaj sohbetteki son mesajsa, liste satırında bir önceki mesaj görünür */
    fun refreshLastAfterDelete(me: String, t: ChatTarget, deletedIds: Set<String>, everyone: Boolean) {
        val all = (msgMem[t.chatId] ?: return).sortedBy { it.time }
        fun fix(uid: String) {
            val vis = all.filter { !it.deletedFor.contains(uid) && !it.deleted && it.type != "deleted" }
            val before = all.filter { !it.deletedFor.contains(uid) }
            val lastShown = before.lastOrNull() ?: return
            if (lastShown.id !in deletedIds) return
            val prev = vis.lastOrNull { it.id !in deletedIds }
            val f = HashMap<String, Any>()
            if (prev != null) {
                f["lastMessage"] = previewOf(prev)
                if (prev.time > 0L) f["lastMessageTime"] = com.google.firebase.Timestamp(java.util.Date(prev.time))
                f["lastSenderUid"] = prev.senderUid
            } else f["lastMessage"] = ""
            summaryRef(uid, t.chatId).set(f, SetOptions.merge())
        }
        fix(me)
        if (everyone && !t.isGroup && t.otherUid.isNotBlank()) fix(t.otherUid)
    }

    /** Silinen mesajı bellek önbelleğinde ve yerel veritabanında hemen günceller (sohbete geri dönünce eski hali görünmesin) */
    private fun localApplyDelete(chatId: String, msgId: String, me: String?, everyone: Boolean) {
        fun ap(m: Message): Message =
            if (everyone) m.copy(type = "deleted", deleted = true, text = "", imageUrl = "", images = emptyList(), imagesCount = 0, audio = "", audioDuration = 0, hasLocation = false, pending = false)
            else if (me != null && !m.deletedFor.contains(me)) m.copy(deletedFor = m.deletedFor + me, pending = false) else m
        msgMem[chatId]?.let { l -> msgMem[chatId] = l.map { if (it.id == msgId) ap(it) else it } }
        bg.launch {
            try { LocalDb.get(chatId, msgId)?.let { LocalDb.upsert(chatId, listOf(ap(it))) } } catch (e: Throwable) { com.aurachat.app.AuraLog.e("LocalDb", e) }
        }
    }

    fun deleteForMe(me: String, chatId: String, msgId: String) {
        localApplyDelete(chatId, msgId, me, false)
        msgRef(chatId, msgId).update("deletedFor", FieldValue.arrayUnion(me))
        unstarKey(me, starKey(chatId, msgId))
    }

    fun deleteForEveryone(chatId: String, msgId: String, me: String? = null) {
        localApplyDelete(chatId, msgId, me, true)
        if (me != null) unstarKey(me, starKey(chatId, msgId))
        val del = FieldValue.delete()
        msgRef(chatId, msgId).update(
            mapOf(
                "type" to "deleted",
                "deleted" to true,
                "text" to "",
                "imageUrl" to del,
                "images" to del,
                "imagesCount" to 0,
                "lat" to del,
                "lng" to del,
                "audio" to del,
                "audioDuration" to del
            )
        )
    }

    // ---------- Yıldızlı mesajlar ----------
    private val starredMem = ConcurrentHashMap<String, List<StarredItem>>()

    /** Yıldızlı mesajlar: açılışta önceki oturumdan (yıldız işaretleri sohbet açılınca sonradan belirmesin) */
    fun peekStarred(uid: String): List<StarredItem> = starredMem[uid] ?: run {
        val s = prefs?.getString("starred_$uid", null) ?: return emptyList()
        try {
            val a = org.json.JSONArray(s)
            (0 until a.length()).map { i -> val o = a.getJSONObject(i)
                StarredItem(o.optString("k"), o.optString("c"), o.optString("m"), o.optString("n"), o.optString("p"), o.optString("s"), o.optLong("t"), o.optString("u")) }
                .also { starredMem[uid] = it }
        } catch (e: Throwable) { emptyList() }
    }

    fun starredFlow(uid: String): Flow<List<StarredItem>> = callbackFlow {
        val reg = db.collection("users").document(uid).collection("starred").addSnapshotListener { snap, _ ->
            if (snap != null) bg.launch {
                try {
                    val items = snap.documents.map { d -> StarredItem(d.id, d.getString("chatId") ?: "", d.getString("msgId") ?: "", d.getString("chatName") ?: "", d.getString("preview") ?: "", d.getString("senderName") ?: "", d.getLong("msgTime") ?: 0L, d.getString("senderUid") ?: "") }
                    starredMem[uid] = items
                    val a = org.json.JSONArray()
                    items.forEach { i -> a.put(org.json.JSONObject().put("k", i.key).put("c", i.chatId).put("m", i.msgId).put("n", i.chatName).put("p", i.preview).put("s", i.senderName).put("t", i.msgTime).put("u", i.senderUid)) }
                    prefs?.edit()?.putString("starred_$uid", a.toString())?.apply()
                } catch (e: Throwable) { com.aurachat.app.AuraLog.e("Repo", e, "starredCache") }
            }
            trySend(
                snap?.documents?.map { d ->
                    StarredItem(
                        key = d.id,
                        chatId = d.getString("chatId") ?: "",
                        msgId = d.getString("msgId") ?: "",
                        chatName = d.getString("chatName") ?: "",
                        preview = d.getString("preview") ?: "",
                        senderName = d.getString("senderName") ?: "",
                        msgTime = d.getLong("msgTime") ?: 0L,
                        senderUid = d.getString("senderUid") ?: ""
                    )
                }?.sortedByDescending { it.msgTime } ?: emptyList()
            )
        }
        awaitClose { reg.remove() }
    }

    fun unstarKey(me: String, key: String) {
        db.collection("users").document(me).collection("starred").document(key).delete()
    }

    fun unstarAll(me: String, keys: List<String>) {
        val col = db.collection("users").document(me).collection("starred")
        keys.chunked(400).forEach { part ->
            val b = db.batch()
            part.forEach { b.delete(col.document(it)) }
            b.commit()
        }
    }

    fun starKey(chatId: String, msgId: String) = "${chatId}__$msgId"

    /** Albümden seçili fotoğrafları siler (kendi mesajımız). Hepsi silinecekse false döner. */
    suspend fun removeAlbumImages(me: String, t: ChatTarget, m: Message, idxs: Set<Int>): Boolean {
        if (m.senderUid != me || m.images.size < 2) return false
        val rest = m.images.filterIndexed { i, _ -> i !in idxs }
        if (rest.isEmpty() || rest.size == m.images.size) return false
        val upd = HashMap<String, Any>()
        if (rest.size == 1) {
            upd["imageUrl"] = rest[0]
            upd["images"] = FieldValue.delete(); upd["imagesCount"] = FieldValue.delete()
            upd["imagesDelivered"] = FieldValue.delete(); upd["thumbs"] = FieldValue.delete()
            val t1 = Media.tinyThumb(rest[0]); if (t1.isNotEmpty()) upd["thumb"] = t1
        } else {
            upd["images"] = rest; upd["imagesCount"] = rest.size
            val ths = rest.take(4).map { Media.tinyThumb(it) }
            if (ths.any { it.isNotEmpty() }) upd["thumbs"] = ths else upd["thumbs"] = FieldValue.delete()
        }
        db.collection("chats").document(t.chatId).collection("messages").document(m.id).update(upd).await()
        return true
    }

    /** Albümden bir fotoğrafı ayırıp tekli mesaj yapar (WhatsApp gibi); yeni mesajın id'sini döndürür. Sadece kendi gönderdiğimiz albümde. */
    suspend fun splitAlbumImage(me: String, t: ChatTarget, m: Message, idx: Int): String? {
        if (m.senderUid != me || m.images.size < 2 || idx !in m.images.indices) return null
        val col = db.collection("chats").document(t.chatId).collection("messages")
        val img = m.images[idx]
        val rest = m.images.filterIndexed { i, _ -> i != idx }
        val newRef = col.document()
        val ts = com.google.firebase.Timestamp(java.util.Date(maxOf(m.time, 1L) + 1L))
        val nf = HashMap<String, Any>()
        nf["type"] = "image"; nf["text"] = ""; nf["imageUrl"] = img
        nf["senderUid"] = m.senderUid; nf["senderName"] = m.senderName
        nf["createdAt"] = ts; nf["read"] = m.read
        if (m.readBy.isNotEmpty()) nf["readBy"] = m.readBy
        val th = Media.tinyThumb(img); if (th.isNotEmpty()) nf["thumb"] = th
        val upd = HashMap<String, Any>()
        if (rest.size == 1) {
            upd["imageUrl"] = rest[0]
            upd["images"] = FieldValue.delete(); upd["imagesCount"] = FieldValue.delete()
            upd["imagesDelivered"] = FieldValue.delete(); upd["thumbs"] = FieldValue.delete()
            val t1 = Media.tinyThumb(rest[0]); if (t1.isNotEmpty()) upd["thumb"] = t1
        } else {
            upd["images"] = rest; upd["imagesCount"] = rest.size
            val ths = rest.take(4).map { Media.tinyThumb(it) }
            if (ths.any { it.isNotEmpty() }) upd["thumbs"] = ths else upd["thumbs"] = FieldValue.delete()
        }
        val batch = db.batch()
        batch.set(newRef, nf)
        batch.update(col.document(m.id), upd)
        batch.commit().await()
        return newRef.id
    }

    fun toggleStar(me: String, t: ChatTarget, m: Message, isStarred: Boolean) {
        val ref = db.collection("users").document(me).collection("starred").document(starKey(t.chatId, m.id))
        if (isStarred) {
            ref.delete()
        } else {
            ref.set(
                mapOf(
                    "chatId" to t.chatId,
                    "msgId" to m.id,
                    "chatName" to t.name,
                    "preview" to previewOf(m),
                    "senderUid" to m.senderUid,
                    "senderName" to m.senderName,
                    "msgTime" to (if (m.time > 0) m.time else System.currentTimeMillis()),
                    "starredAt" to FieldValue.serverTimestamp()
                )
            )
        }
    }

    // ---------- Gruplar ----------
    suspend fun createGroup(me: UserProfile, name: String, memberUids: List<String>, perms: com.aurachat.app.data.GroupPerms = com.aurachat.app.data.GroupPerms()): String {
        val members = listOf(me.uid) + memberUids.filter { it != me.uid }.distinct()
        val ref = db.collection("groups").document()
        ref.set(
            mapOf(
                "name" to name,
                "members" to members,
                "createdBy" to me.uid,
                "permEdit" to perms.edit,
                "permSend" to perms.send,
                "permAdd" to perms.add,
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        val batch = db.batch()
        for (m in members) {
            batch.set(
                summaryRef(m, ref.id),
                mapOf(
                    "isGroup" to true,
                    "groupName" to name,
                    "lastMessage" to "Grup oluşturuldu",
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastSenderName" to me.name,
                    "lastMessageRead" to false,
                    "unreadCount" to (if (m == me.uid) 0 else 1),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
        batch.commit().await()
        for (m in members) {
            if (m == me.uid) continue
            bg.launch { notify(m, name, "${me.name} seni gruba ekledi", ref.id, ref.id, name, "text", "") }
        }
        return ref.id
    }

    private suspend fun systemMessage(me: UserProfile, groupId: String, text: String, mentions: List<String> = emptyList(), mentionNames: List<String> = emptyList()) {
        db.collection("chats").document(groupId).collection("messages").add(
            mapOf(
                "type" to "system",
                "text" to text,
                "senderUid" to me.uid,
                "senderName" to me.name,
                "mentions" to mentions,
                "mentionNames" to mentionNames,
                "createdAt" to FieldValue.serverTimestamp(),
                "read" to false
            )
        ).await()
    }

    private suspend fun bumpGroupSummaries(me: UserProfile, g: GroupData, memberUids: List<String>, text: String) {
        val batch = db.batch()
        for (m in memberUids) {
            batch.set(
                summaryRef(m, g.id),
                mapOf(
                    "isGroup" to true,
                    "groupName" to g.name,
                    "lastMessage" to text,
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastSenderName" to me.name,
                    "lastMessageRead" to false,
                    "unreadCount" to (if (m == me.uid) 0 else FieldValue.increment(1)),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
        batch.commit().await()
    }

    suspend fun leaveGroup(me: UserProfile, g: GroupData) {
        val text = "${me.name} gruptan ayrıldı"
        systemMessage(me, g.id, text)
        val others = g.members.filter { it != me.uid }
        bumpGroupSummaries(me, g, others, text)
        db.collection("groups").document(g.id).update(
            mapOf("members" to FieldValue.arrayRemove(me.uid), "admins" to FieldValue.arrayRemove(me.uid))
        ).await()
        // Kendi listemden kaldır
        summaryRef(me.uid, g.id).set(
            mapOf("clearedAt" to FieldValue.serverTimestamp(), "keepRow" to false, "unreadCount" to 0, "pinned" to false),
            SetOptions.merge()
        )
        for (m in others) {
            bg.launch { notify(m, g.name, text, g.id, g.id, g.name, "text", "") }
        }
    }

    suspend fun addMembers(me: UserProfile, g: GroupData, uids: List<String>) {
        if (uids.isEmpty()) return
        db.collection("groups").document(g.id).update("members", FieldValue.arrayUnion(*uids.toTypedArray())).await()
        val batch = db.batch()
        for (m in uids) {
            batch.set(
                summaryRef(m, g.id),
                mapOf(
                    "isGroup" to true,
                    "groupName" to g.name,
                    "lastMessage" to "${me.name} seni gruba ekledi",
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastSenderName" to me.name,
                    "lastMessageRead" to false,
                    "unreadCount" to 1,
                    "clearedAt" to FieldValue.delete(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
        batch.commit().await()
        try {
            val names = uids.map { u -> (try { profileOf(u).name } catch (_: Throwable) { "" }).ifBlank { "Kişi" } }
            systemMessage(me, g.id, "${me.name} ${names.joinToString(", ")} kişisini ekledi", uids, names)
        } catch (_: Throwable) {}
        for (m in uids) {
            bg.launch { notify(m, g.name, "${me.name} seni gruba ekledi", g.id, g.id, g.name, "text", "") }
        }
    }

    /** Grubun son 60 günlük üye hareketleri (ayrılan / çıkarılan / eklenen): sistem mesajlarından, yeniden eskiye */
    suspend fun groupMemberEvents(groupId: String): List<Message> {
        val since = com.google.firebase.Timestamp(java.util.Date(System.currentTimeMillis() - 60L * 24 * 3600 * 1000))
        val snap = db.collection("chats").document(groupId).collection("messages")
            .whereGreaterThanOrEqualTo("createdAt", since).orderBy("createdAt", Query.Direction.DESCENDING).limit(400).get().await()
        return snap.documents.map { it.toMessage() }.filter { m ->
            m.type == "system" && (m.text.contains("gruptan ayrıldı") || m.text.contains("kişisini çıkardı") || m.text.contains("kişisini ekledi") || m.text.contains("gruba katıldı"))
        }
    }

    suspend fun setGroupPerms(groupId: String, p: com.aurachat.app.data.GroupPerms) {
        db.collection("groups").document(groupId).update(mapOf("permEdit" to p.edit, "permSend" to p.send, "permAdd" to p.add)).await()
    }

    suspend fun renameGroup(g: GroupData, name: String) {
        db.collection("groups").document(g.id).update("name", name).await()
        for (m in g.members) {
            summaryRef(m, g.id).set(mapOf("groupName" to name), SetOptions.merge())
        }
    }

    suspend fun removeMember(g: GroupData, uid: String, me: UserProfile? = null) {
        db.collection("groups").document(g.id).update(
            mapOf("members" to FieldValue.arrayRemove(uid), "admins" to FieldValue.arrayRemove(uid))
        ).await()
        if (me != null) try {
            val n = (try { profileOf(uid).name } catch (_: Throwable) { "" }).ifBlank { "Kişi" }
            systemMessage(me, g.id, "${me.name} $n kişisini çıkardı", listOf(uid), listOf(n))
        } catch (_: Throwable) {}
    }

    suspend fun setAdmin(g: GroupData, uid: String, admin: Boolean) {
        val v: Any = if (admin) FieldValue.arrayUnion(uid) else FieldValue.arrayRemove(uid)
        db.collection("groups").document(g.id).update("admins", v).await()
    }

    // ---------- Bildirim ----------
    fun registerPush(uid: String) {
        FirebaseMessaging.getInstance().token.addOnSuccessListener { saveToken(uid, it) }
    }

    fun saveToken(uid: String, token: String) {
        db.collection("users").document(uid).set(
            mapOf(
                "fcmToken" to token,
                "platform" to "native",
                // Sunucu bu durumda sadece veri gönderir; bildirimi uygulama kendisi çizer
                "nativeMsgStyle" to true,
                "lastTokenUpdate" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        )
    }

    private suspend fun notify(
        receiverUid: String,
        title: String,
        body: String,
        chatId: String,
        otherUid: String,
        otherName: String,
        msgType: String,
        msgId: String
    ) {
        withContext(Dispatchers.IO) {
            try {
                val idToken = auth.currentUser?.getIdToken(false)?.await()?.token ?: return@withContext
                val data = JSONObject()
                    .put("chatId", chatId)
                    .put("otherUid", otherUid)
                    .put("otherName", otherName)
                    .put("msgType", msgType)
                if (msgId.isNotEmpty()) data.put("msgId", msgId)
                val payload = JSONObject()
                    .put("receiverUid", receiverUid)
                    .put("title", title.take(100))
                    .put("body", body.take(400))
                    .put("data", data)
                if (msgId.isNotEmpty()) payload.put("tag", "msg-$msgId")
                val c = URL(API).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer $idToken")
                c.outputStream.use { it.write(payload.toString().toByteArray()) }
                c.responseCode
                c.disconnect()
            } catch (ignored: Exception) { com.aurachat.app.AuraLog.e("Repo", ignored, "notify:1749") }
        }
    }
}

private fun aboutOf(d: com.google.firebase.firestore.DocumentSnapshot): String {
    val t = d.getString("about") ?: ""
    val exp = d.getLong("aboutExpiresAt") ?: 0L
    if (exp > 0L && exp < System.currentTimeMillis()) return ""
    val mine = FirebaseAuth.getInstance().currentUser?.uid == d.id
    if (!mine && d.getString("aboutAudience") == "Hiç kimse") return ""
    return t
}

package com.aurachat.app.data

import android.content.Context
import android.content.SharedPreferences
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/** Web sürümüyle AYNI Firestore şemasını kullanır; iki taraf birlikte çalışır. */
object Repo {
    private const val API = "https://aurachat-amber.vercel.app/api/send-notification"

    private val db get() = FirebaseFirestore.getInstance()
    private val auth get() = FirebaseAuth.getInstance()
    private val bg = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ---------- Önbellek ----------
    private var prefs: SharedPreferences? = null
    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("aura", Context.MODE_PRIVATE)
    }

    /** Açılışta ağı beklemeden gösterilsin diye son bilinen profil */
    fun cachedProfile(uid: String): UserProfile? {
        val p = prefs ?: return null
        val n = p.getString("name_$uid", null) ?: return null
        return UserProfile(uid, n, p.getString("phone_$uid", "") ?: "")
    }

    private fun cacheProfile(p: UserProfile) {
        if (p.name.isBlank()) return
        prefs?.edit()?.putString("name_${p.uid}", p.name)?.putString("phone_${p.uid}", p.phone)?.apply()
    }

    fun chatId(a: String, b: String) = listOf(a, b).sorted().joinToString("_")

    /** Birebir sohbet id'si "uidA_uidB" biçimindedir; gruplar farklı. */
    fun isDirect(chatId: String) = chatId.split("_").size == 2

    fun targetFor(me: String, chatId: String, name: String): ChatTarget {
        return if (isDirect(chatId)) {
            val other = chatId.split("_").firstOrNull { it != me } ?: ""
            ChatTarget(chatId, false, other, name)
        } else {
            ChatTarget(chatId, true, chatId, name)
        }
    }

    private fun DocumentSnapshot.ts(field: String): Long =
        getTimestamp(field, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L

    // ---------- Profil ----------
    suspend fun loadProfile(uid: String): UserProfile? {
        val d = db.collection("users").document(uid).get().await()
        if (!d.exists()) return null
        return UserProfile(uid, d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("avatar") ?: "", d.getString("about") ?: "")
            .also { cacheProfile(it) }
    }

    suspend fun saveName(uid: String, email: String, name: String): UserProfile {
        db.collection("users").document(uid).set(
            mapOf("uid" to uid, "name" to name, "email" to email, "lastSeen" to FieldValue.serverTimestamp()),
            SetOptions.merge()
        ).await()
        return UserProfile(uid, name).also { cacheProfile(it) }
    }

    private val profileCache = ConcurrentHashMap<String, UserProfile>()

    /** Başka bir kullanıcının adı ve avatarı (bellekte önbelleklenir) */
    suspend fun profileOf(uid: String): UserProfile {
        profileCache[uid]?.let { return it }
        val p = try {
            val d = db.collection("users").document(uid).get().await()
            UserProfile(uid, d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("avatar") ?: "", d.getString("about") ?: "")
        } catch (e: Exception) {
            UserProfile(uid, "")
        }
        if (p.name.isNotBlank() || p.avatar.isNotBlank()) profileCache[uid] = p
        return p
    }

    suspend fun avatarOf(uid: String): String = profileOf(uid).avatar

    suspend fun loadUsers(myUid: String): List<UserProfile> {
        val snap = db.collection("users").get().await()
        return snap.documents.mapNotNull { d ->
            val name = d.getString("name") ?: return@mapNotNull null
            if (d.id == myUid || name.isBlank()) null
            else UserProfile(d.id, name, d.getString("phone") ?: "", d.getString("avatar") ?: "", d.getString("about") ?: "")
        }.sortedBy { it.name.lowercase() }
    }

    // ---------- Sohbet listesi ----------
    private fun summaryRef(uid: String, chatId: String) =
        db.collection("users").document(uid).collection("chats").document(chatId)

    fun chatsFlow(uid: String): Flow<List<ChatSummary>> = callbackFlow {
        val reg = db.collection("users").document(uid).collection("chats")
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.map { d ->
                    val group = d.getBoolean("isGroup") ?: !isDirect(d.id)
                    ChatSummary(
                        chatId = d.id,
                        isGroup = group,
                        otherUid = if (group) d.id else (d.getString("otherUid") ?: ""),
                        name = if (group) (d.getString("groupName") ?: "Grup") else (d.getString("otherName") ?: ""),
                        lastMessage = d.getString("lastMessage") ?: "",
                        lastTime = d.ts("lastMessageTime"),
                        lastSenderUid = d.getString("lastSenderUid") ?: "",
                        lastSenderName = d.getString("lastSenderName") ?: "",
                        lastRead = d.getBoolean("lastMessageRead") ?: false,
                        unread = (d.getLong("unreadCount") ?: 0L).toInt(),
                        pinned = d.getBoolean("pinned") ?: false,
                        favorite = d.getBoolean("archived") ?: false,
                        typing = d.getBoolean("typing") ?: false,
                        clearedAt = d.ts("clearedAt")
                    )
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    fun clearedAtFlow(uid: String, chatId: String): Flow<Long> = callbackFlow {
        val reg = summaryRef(uid, chatId).addSnapshotListener { snap, _ ->
            trySend(snap?.ts("clearedAt") ?: 0L)
        }
        awaitClose { reg.remove() }
    }

    fun setPinned(me: String, chatId: String, pinned: Boolean) {
        summaryRef(me, chatId).update("pinned", pinned)
    }

    fun setFavorite(me: String, chatId: String, fav: Boolean) {
        summaryRef(me, chatId).update("archived", fav)
    }

    /** Sohbeti listeden sil: kalıcı olarak "clearedAt" yazılır, eski mesajlar bir daha yüklenmez */
    fun clearChat(me: String, chatId: String) {
        summaryRef(me, chatId).set(
            mapOf("clearedAt" to FieldValue.serverTimestamp(), "unreadCount" to 0, "pinned" to false),
            SetOptions.merge()
        )
    }

    // ---------- Mesajlar ----------
    private fun DocumentSnapshot.toMessage(): Message {
        val reply = (get("replyTo") as? Map<*, *>)?.let { m ->
            ReplyRef(
                msgId = m["msgId"] as? String ?: "",
                senderName = m["senderName"] as? String ?: "",
                previewText = m["previewText"] as? String ?: "",
                senderUid = m["senderUid"] as? String ?: ""
            )
        }
        val reactions = HashMap<String, String>()
        (get("reactions") as? Map<*, *>)?.forEach { (k, v) ->
            if (k is String && v is String) reactions[k] = v
        }
        val images = (get("images") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
        val lat = getDouble("lat")
        val lng = getDouble("lng")
        return Message(
            id = id,
            type = getString("type") ?: "text",
            text = getString("text") ?: "",
            senderUid = getString("senderUid") ?: "",
            senderName = getString("senderName") ?: "",
            time = ts("createdAt"),
            read = getBoolean("read") ?: false,
            readBy = (get("readBy") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            deleted = getBoolean("deleted") ?: false,
            deletedFor = (get("deletedFor") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            pending = metadata.hasPendingWrites(),
            imageUrl = getString("imageUrl") ?: "",
            images = images,
            imagesCount = (getLong("imagesCount") ?: 0L).toInt(),
            audio = getString("audio") ?: "",
            audioDuration = (getLong("audioDuration") ?: 0L).toInt(),
            lat = lat ?: 0.0,
            lng = lng ?: 0.0,
            hasLocation = lat != null && lng != null,
            fileName = getString("fileName") ?: "",
            fileMime = getString("fileMime") ?: "",
            replyTo = reply,
            reactions = reactions,
            edited = getBoolean("edited") ?: false,
            forwarded = getBoolean("forwarded") ?: false,
            callDuration = (getLong("duration") ?: 0L).toInt()
        )
    }

    /** En yeni en başta */
    fun messagesFlow(chatId: String, limit: Long): Flow<List<Message>> = callbackFlow {
        val reg = db.collection("chats").document(chatId).collection("messages")
            .orderBy("createdAt", Query.Direction.DESCENDING).limit(limit)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.documents?.map { it.toMessage() } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun typingFlow(chatId: String, otherUid: String): Flow<Boolean> = callbackFlow {
        val reg = db.collection("chats").document(chatId).addSnapshotListener { snap, _ ->
            trySend(snap?.getBoolean("typing_$otherUid") ?: false)
        }
        awaitClose { reg.remove() }
    }

    /** Karşı tarafın çevrimiçi/son görülme bilgisi (presence/{uid}); gizliyse null */
    data class Presence(val online: Boolean, val lastSeenMs: Long)

    fun presenceFlow(uid: String): Flow<Presence?> = callbackFlow {
        val reg = db.collection("presence").document(uid).addSnapshotListener { snap, _ ->
            if (snap != null && snap.exists() && snap.getBoolean("hidden") != true) {
                trySend(Presence(snap.getBoolean("online") ?: false, snap.ts("lastSeen")))
            } else {
                trySend(null)
            }
        }
        awaitClose { reg.remove() }
    }

    @Volatile private var presenceHidden = false

    fun syncPresenceHidden(uid: String) {
        db.collection("presence").document(uid).get().addOnSuccessListener {
            presenceHidden = it.getBoolean("hidden") == true
        }
    }

    fun writePresence(uid: String, online: Boolean) {
        if (presenceHidden) return
        db.collection("presence").document(uid).set(
            mapOf("online" to online, "lastSeen" to FieldValue.serverTimestamp()),
            SetOptions.merge()
        )
    }

    /** Grupta şu an yazan diğer üyelerin uid'leri (chats/{id}.typing_<uid>) */
    fun groupTypingFlow(chatId: String, me: String): Flow<List<String>> = callbackFlow {
        val reg = db.collection("chats").document(chatId).addSnapshotListener { snap, _ ->
            val out = ArrayList<String>()
            snap?.data?.forEach { (k, v) ->
                if (k.startsWith("typing_") && v == true && k.removePrefix("typing_") != me) out.add(k.removePrefix("typing_"))
            }
            trySend(out)
        }
        awaitClose { reg.remove() }
    }

    fun setTyping(me: String, t: ChatTarget, typing: Boolean) {
        db.collection("chats").document(t.chatId)
            .set(mapOf("typing_$me" to typing), SetOptions.merge())
        if (!t.isGroup) {
            summaryRef(t.otherUid, t.chatId)
                .update(mapOf("typing" to typing, "typingAt" to System.currentTimeMillis()))
        }
    }

    /** Karşıdan gelen okunmamış mesajları okundu yapar ve listedeki rozeti sıfırlar. */
    fun markRead(me: String, t: ChatTarget, messages: List<Message>) {
        val unread = messages.filter {
            it.senderUid != me && !it.pending && it.type != "system" &&
                (if (t.isGroup) !it.readBy.contains(me) else !it.read)
        }
        unread.forEach {
            val upd = HashMap<String, Any>()
            upd["readBy"] = FieldValue.arrayUnion(me)
            if (!t.isGroup) upd["read"] = true
            db.collection("chats").document(t.chatId).collection("messages").document(it.id).update(upd)
        }
        summaryRef(me, t.chatId).update(mapOf("unreadCount" to 0, "hasMention" to false))
        if (unread.isNotEmpty() && !t.isGroup) {
            summaryRef(t.otherUid, t.chatId).update("lastMessageRead", true)
        }
    }

    // ---------- Gönderme ----------
    private fun replyMap(r: ReplyRef): Map<String, Any> =
        mapOf("msgId" to r.msgId, "senderName" to r.senderName, "previewText" to r.previewText, "senderUid" to r.senderUid)

    suspend fun loadGroup(groupId: String): GroupData? {
        val d = db.collection("groups").document(groupId).get().await()
        return if (d.exists()) d.toGroup() else null
    }

    private fun DocumentSnapshot.toGroup() = GroupData(
        id = id,
        name = getString("name") ?: "Grup",
        members = (get("members") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
        admins = (get("admins") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
        createdBy = getString("createdBy") ?: "",
        photo = getString("photo") ?: ""
    )

    fun groupFlow(groupId: String): Flow<GroupData?> = callbackFlow {
        val reg = db.collection("groups").document(groupId).addSnapshotListener { snap, _ ->
            trySend(if (snap != null && snap.exists()) snap.toGroup() else null)
        }
        awaitClose { reg.remove() }
    }

    /**
     * Tek mesaj yazma yolu: mesaj + sohbet özetleri tek paket, ardından bildirim.
     * Sunucuya ulaşana kadar bekler; arayüz yerel önbellekten anında gösterir.
     */
    suspend fun postMessage(
        me: UserProfile,
        t: ChatTarget,
        fields: Map<String, Any>,
        summary: String,
        pushBody: String,
        msgType: String = "text"
    ): String {
        val msgRef = db.collection("chats").document(t.chatId).collection("messages").document()
        val data = HashMap<String, Any>(fields)
        data["senderUid"] = me.uid
        data["senderName"] = me.name
        data["createdAt"] = FieldValue.serverTimestamp()
        data["read"] = false

        val batch = db.batch()
        batch.set(msgRef, data)

        var group: GroupData? = null
        if (t.isGroup) {
            group = loadGroup(t.chatId) ?: throw IllegalStateException("Grup bulunamadı")
            for (m in group.members) {
                batch.set(
                    summaryRef(m, t.chatId),
                    mapOf(
                        "isGroup" to true,
                        "groupName" to group.name,
                        "lastMessage" to summary,
                        "lastMessageTime" to FieldValue.serverTimestamp(),
                        "lastSenderUid" to me.uid,
                        "lastSenderName" to me.name,
                        "lastMessageRead" to false,
                        "unreadCount" to (if (m == me.uid) 0 else FieldValue.increment(1)),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    SetOptions.merge()
                )
            }
        } else {
            batch.set(
                summaryRef(me.uid, t.chatId),
                mapOf(
                    "otherUid" to t.otherUid,
                    "otherName" to t.name,
                    "lastMessage" to summary,
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastMessageRead" to false,
                    "unreadCount" to 0,
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
            batch.set(
                summaryRef(t.otherUid, t.chatId),
                mapOf(
                    "otherUid" to me.uid,
                    "otherName" to me.name,
                    "lastMessage" to summary,
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastMessageRead" to false,
                    "typing" to false,
                    "unreadCount" to FieldValue.increment(1),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
        batch.commit().await()

        val msgId = msgRef.id
        if (group != null) {
            val g = group
            for (m in g.members) {
                if (m == me.uid) continue
                bg.launch {
                    notify(m, g.name, "${me.name}: $pushBody", t.chatId, t.chatId, g.name, msgType, msgId)
                }
            }
        } else {
            bg.launch { notify(t.otherUid, me.name, pushBody, t.chatId, me.uid, me.name, msgType, msgId) }
        }
        return msgId
    }

    suspend fun sendText(me: UserProfile, t: ChatTarget, text: String, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "text"
        f["text"] = text
        if (reply != null) f["replyTo"] = replyMap(reply)
        postMessage(me, t, f, text.take(100), text.take(200), "text")
    }

    suspend fun sendImages(me: UserProfile, t: ChatTarget, images: List<String>, caption: String, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "image"
        f["text"] = caption
        if (images.size == 1) {
            f["imageUrl"] = images[0]
        } else {
            f["images"] = images
            f["imagesCount"] = images.size
            f["imagesDelivered"] = false
        }
        if (reply != null) f["replyTo"] = replyMap(reply)
        val label = if (images.size > 1) "📷 ${images.size} Fotoğraf" else "📷 Fotoğraf"
        val summary = if (caption.isNotBlank()) "$label $caption" else label
        postMessage(me, t, f, summary.take(100), summary.take(200), "image")
    }

    suspend fun sendAudio(me: UserProfile, t: ChatTarget, dataUrl: String, seconds: Int, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "audio"
        f["audio"] = dataUrl
        f["audioDuration"] = seconds
        f["text"] = ""
        if (reply != null) f["replyTo"] = replyMap(reply)
        val label = "🎤 Sesli mesaj (${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')})"
        postMessage(me, t, f, label, "🎤 Sesli mesaj", "audio")
    }

    suspend fun sendLocation(me: UserProfile, t: ChatTarget, lat: Double, lng: Double, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "location"
        f["lat"] = lat
        f["lng"] = lng
        f["text"] = ""
        if (reply != null) f["replyTo"] = replyMap(reply)
        postMessage(me, t, f, "📍 Konum", "📍 Konum gönderdi", "location")
    }

    suspend fun sendDocument(me: UserProfile, t: ChatTarget, name: String, mime: String, dataUrl: String, reply: ReplyRef?) {
        val f = HashMap<String, Any>()
        f["type"] = "document"
        f["fileName"] = name.take(120)
        f["fileMime"] = mime
        f["imageUrl"] = dataUrl
        f["text"] = ""
        if (reply != null) f["replyTo"] = replyMap(reply)
        postMessage(me, t, f, "📄 $name".take(100), "📄 Belge gönderdi", "document")
    }

    /** Bir mesajı başka sohbete iletir */
    suspend fun forward(me: UserProfile, to: ChatTarget, m: Message) {
        val f = HashMap<String, Any>()
        f["forwarded"] = true
        f["text"] = m.text
        when (m.type) {
            "image" -> {
                f["type"] = "image"
                if (m.images.isNotEmpty()) {
                    f["images"] = m.images
                    f["imagesCount"] = m.images.size
                    f["imagesDelivered"] = false
                } else if (m.imageUrl.isNotEmpty()) {
                    f["imageUrl"] = m.imageUrl
                }
            }
            "audio" -> {
                f["type"] = "audio"
                f["audio"] = m.audio
                f["audioDuration"] = m.audioDuration
            }
            "location" -> {
                f["type"] = "location"
                f["lat"] = m.lat
                f["lng"] = m.lng
            }
            "document" -> {
                f["type"] = "document"
                f["fileName"] = m.fileName
                f["fileMime"] = m.fileMime
                f["imageUrl"] = m.imageUrl
            }
            else -> f["type"] = "text"
        }
        postMessage(me, to, f, previewOf(m).take(100), previewOf(m).take(200), m.type)
    }

    fun previewOf(m: Message): String = when {
        m.deleted || m.type == "deleted" -> "🚫 Bu mesaj silindi"
        m.type == "image" -> if (m.images.size > 1 || m.imagesCount > 1) "📷 ${maxOf(m.images.size, m.imagesCount)} Fotoğraf" else "📷 Fotoğraf"
        m.type == "audio" -> "🎤 Sesli mesaj"
        m.type == "location" -> "📍 Konum"
        m.type == "document" -> "📄 " + m.fileName.ifBlank { "Belge" }
        m.type == "poll" -> "📊 Anket"
        else -> m.text.take(120)
    }

    // ---------- Mesaj işlemleri ----------
    private fun msgRef(chatId: String, msgId: String) =
        db.collection("chats").document(chatId).collection("messages").document(msgId)

    fun react(me: String, chatId: String, msgId: String, emoji: String, current: String?) {
        val v: Any = if (current == emoji) FieldValue.delete() else emoji
        msgRef(chatId, msgId).update("reactions.$me", v)
    }

    fun editText(chatId: String, msgId: String, text: String) {
        msgRef(chatId, msgId).update(
            mapOf("text" to text, "edited" to true, "editedAt" to FieldValue.serverTimestamp())
        )
    }

    fun deleteForMe(me: String, chatId: String, msgId: String) {
        msgRef(chatId, msgId).update("deletedFor", FieldValue.arrayUnion(me))
    }

    fun deleteForEveryone(chatId: String, msgId: String) {
        val del = FieldValue.delete()
        msgRef(chatId, msgId).update(
            mapOf(
                "type" to "deleted",
                "deleted" to true,
                "text" to "",
                "imageUrl" to del,
                "images" to del,
                "imagesCount" to 0,
                "lat" to del,
                "lng" to del,
                "audio" to del,
                "audioDuration" to del
            )
        )
    }

    // ---------- Yıldızlı mesajlar ----------
    fun starredFlow(uid: String): Flow<List<StarredItem>> = callbackFlow {
        val reg = db.collection("users").document(uid).collection("starred").addSnapshotListener { snap, _ ->
            trySend(
                snap?.documents?.map { d ->
                    StarredItem(
                        key = d.id,
                        chatId = d.getString("chatId") ?: "",
                        msgId = d.getString("msgId") ?: "",
                        chatName = d.getString("chatName") ?: "",
                        preview = d.getString("preview") ?: "",
                        senderName = d.getString("senderName") ?: "",
                        msgTime = d.getLong("msgTime") ?: 0L
                    )
                }?.sortedByDescending { it.msgTime } ?: emptyList()
            )
        }
        awaitClose { reg.remove() }
    }

    fun starKey(chatId: String, msgId: String) = "${chatId}__$msgId"

    fun toggleStar(me: String, t: ChatTarget, m: Message, isStarred: Boolean) {
        val ref = db.collection("users").document(me).collection("starred").document(starKey(t.chatId, m.id))
        if (isStarred) {
            ref.delete()
        } else {
            ref.set(
                mapOf(
                    "chatId" to t.chatId,
                    "msgId" to m.id,
                    "chatName" to t.name,
                    "preview" to previewOf(m),
                    "senderUid" to m.senderUid,
                    "senderName" to m.senderName,
                    "msgTime" to (if (m.time > 0) m.time else System.currentTimeMillis()),
                    "starredAt" to FieldValue.serverTimestamp()
                )
            )
        }
    }

    // ---------- Gruplar ----------
    suspend fun createGroup(me: UserProfile, name: String, memberUids: List<String>): String {
        val members = listOf(me.uid) + memberUids.filter { it != me.uid }.distinct()
        val ref = db.collection("groups").document()
        ref.set(
            mapOf(
                "name" to name,
                "members" to members,
                "createdBy" to me.uid,
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        val batch = db.batch()
        for (m in members) {
            batch.set(
                summaryRef(m, ref.id),
                mapOf(
                    "isGroup" to true,
                    "groupName" to name,
                    "lastMessage" to "Grup oluşturuldu",
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastSenderName" to me.name,
                    "lastMessageRead" to false,
                    "unreadCount" to (if (m == me.uid) 0 else 1),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
        batch.commit().await()
        for (m in members) {
            if (m == me.uid) continue
            bg.launch { notify(m, name, "${me.name} seni gruba ekledi", ref.id, ref.id, name, "text", "") }
        }
        return ref.id
    }

    private suspend fun systemMessage(me: UserProfile, groupId: String, text: String) {
        db.collection("chats").document(groupId).collection("messages").add(
            mapOf(
                "type" to "system",
                "text" to text,
                "senderUid" to me.uid,
                "senderName" to me.name,
                "createdAt" to FieldValue.serverTimestamp(),
                "read" to false
            )
        ).await()
    }

    private suspend fun bumpGroupSummaries(me: UserProfile, g: GroupData, memberUids: List<String>, text: String) {
        val batch = db.batch()
        for (m in memberUids) {
            batch.set(
                summaryRef(m, g.id),
                mapOf(
                    "isGroup" to true,
                    "groupName" to g.name,
                    "lastMessage" to text,
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastSenderName" to me.name,
                    "lastMessageRead" to false,
                    "unreadCount" to (if (m == me.uid) 0 else FieldValue.increment(1)),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
        batch.commit().await()
    }

    suspend fun leaveGroup(me: UserProfile, g: GroupData) {
        val text = "${me.name} gruptan ayrıldı"
        systemMessage(me, g.id, text)
        val others = g.members.filter { it != me.uid }
        bumpGroupSummaries(me, g, others, text)
        db.collection("groups").document(g.id).update(
            mapOf("members" to FieldValue.arrayRemove(me.uid), "admins" to FieldValue.arrayRemove(me.uid))
        ).await()
        // Kendi listemden kaldır
        summaryRef(me.uid, g.id).set(
            mapOf("clearedAt" to FieldValue.serverTimestamp(), "unreadCount" to 0, "pinned" to false),
            SetOptions.merge()
        )
        for (m in others) {
            bg.launch { notify(m, g.name, text, g.id, g.id, g.name, "text", "") }
        }
    }

    suspend fun addMembers(me: UserProfile, g: GroupData, uids: List<String>) {
        if (uids.isEmpty()) return
        db.collection("groups").document(g.id).update("members", FieldValue.arrayUnion(*uids.toTypedArray())).await()
        val batch = db.batch()
        for (m in uids) {
            batch.set(
                summaryRef(m, g.id),
                mapOf(
                    "isGroup" to true,
                    "groupName" to g.name,
                    "lastMessage" to "${me.name} seni gruba ekledi",
                    "lastMessageTime" to FieldValue.serverTimestamp(),
                    "lastSenderUid" to me.uid,
                    "lastSenderName" to me.name,
                    "lastMessageRead" to false,
                    "unreadCount" to 1,
                    "clearedAt" to FieldValue.delete(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        }
        batch.commit().await()
        for (m in uids) {
            bg.launch { notify(m, g.name, "${me.name} seni gruba ekledi", g.id, g.id, g.name, "text", "") }
        }
    }

    suspend fun renameGroup(g: GroupData, name: String) {
        db.collection("groups").document(g.id).update("name", name).await()
        for (m in g.members) {
            summaryRef(m, g.id).set(mapOf("groupName" to name), SetOptions.merge())
        }
    }

    suspend fun removeMember(g: GroupData, uid: String) {
        db.collection("groups").document(g.id).update(
            mapOf("members" to FieldValue.arrayRemove(uid), "admins" to FieldValue.arrayRemove(uid))
        ).await()
    }

    suspend fun setAdmin(g: GroupData, uid: String, admin: Boolean) {
        val v: Any = if (admin) FieldValue.arrayUnion(uid) else FieldValue.arrayRemove(uid)
        db.collection("groups").document(g.id).update("admins", v).await()
    }

    // ---------- Bildirim ----------
    fun registerPush(uid: String) {
        FirebaseMessaging.getInstance().token.addOnSuccessListener { saveToken(uid, it) }
    }

    fun saveToken(uid: String, token: String) {
        db.collection("users").document(uid).set(
            mapOf(
                "fcmToken" to token,
                "platform" to "native",
                // Sunucu bu durumda sadece veri gönderir; bildirimi uygulama kendisi çizer
                "nativeMsgStyle" to true,
                "lastTokenUpdate" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        )
    }

    private suspend fun notify(
        receiverUid: String,
        title: String,
        body: String,
        chatId: String,
        otherUid: String,
        otherName: String,
        msgType: String,
        msgId: String
    ) {
        withContext(Dispatchers.IO) {
            try {
                val idToken = auth.currentUser?.getIdToken(false)?.await()?.token ?: return@withContext
                val data = JSONObject()
                    .put("chatId", chatId)
                    .put("otherUid", otherUid)
                    .put("otherName", otherName)
                    .put("msgType", msgType)
                if (msgId.isNotEmpty()) data.put("msgId", msgId)
                val payload = JSONObject()
                    .put("receiverUid", receiverUid)
                    .put("title", title.take(100))
                    .put("body", body.take(400))
                    .put("data", data)
                if (msgId.isNotEmpty()) payload.put("tag", "msg-$msgId")
                val c = URL(API).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer $idToken")
                c.outputStream.use { it.write(payload.toString().toByteArray()) }
                c.responseCode
                c.disconnect()
            } catch (ignored: Exception) {
            }
        }
    }
}

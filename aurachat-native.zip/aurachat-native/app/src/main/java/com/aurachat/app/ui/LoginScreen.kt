package com.aurachat.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

private const val WEB_CLIENT_ID = "447747395966-3shresouu36769er1b9656oec8vd13aa.apps.googleusercontent.com"

@Composable
fun LoginScreen() {
    val ctx = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val gClient = remember {
        GoogleSignIn.getClient(
            ctx,
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(WEB_CLIENT_ID).requestEmail().build()
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        try {
            val acc = GoogleSignIn.getSignedInAccountFromIntent(r.data).getResult(ApiException::class.java)
            val cred = GoogleAuthProvider.getCredential(acc.idToken, null)
            auth.signInWithCredential(cred).addOnCompleteListener { t ->
                busy = false
                if (!t.isSuccessful) error = "Google girişi başarısız: ${t.exception?.localizedMessage}"
            }
        } catch (e: ApiException) {
            busy = false
            error = "Google girişi başarısız (kod ${e.statusCode})"
        }
    }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("AuraChat", fontSize = 36.sp, color = AuraGreen)
        Spacer(Modifier.height(32.dp))
        OutlinedTextField(
            value = email, onValueChange = { email = it }, label = { Text("E-posta") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password, onValueChange = { password = it }, label = { Text("Şifre") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )
        error?.let { Spacer(Modifier.height(12.dp)); Text(it, color = Color(0xFFEF4444)) }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                if (email.isBlank() || password.isBlank()) {
                    error = "E-posta ve şifre gir."
                } else {
                    busy = true
                    error = null
                    auth.signInWithEmailAndPassword(email.trim(), password).addOnCompleteListener { t ->
                        busy = false
                        if (!t.isSuccessful) {
                            error = "Giriş başarısız: ${t.exception?.localizedMessage}"
                        } else if (auth.currentUser?.isEmailVerified == false) {
                            auth.signOut()
                            error = "E-postanı henüz onaylamadın. Web sürümünden onayla."
                        }
                    }
                }
            },
            enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AuraGreen)
        ) { Text("Giriş yap") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = {
                busy = true; error = null
                gClient.signOut().addOnCompleteListener { launcher.launch(gClient.signInIntent) }
            },
            enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("Google ile giriş yap") }
        Spacer(Modifier.height(16.dp))
        Text("Yeni hesap için şimdilik web sürümünden kayıt ol.", color = AuraMuted, fontSize = 13.sp)
    }
}

@Composable
fun NameScreen(onSave: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Adın ne?", fontSize = 24.sp)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { if (name.isNotBlank()) onSave(name.trim()) },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AuraGreen)
        ) { Text("Devam") }
    }
}

package com.aurachat.app.ui

import kotlinx.coroutines.launch
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import kotlinx.coroutines.tasks.await
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

private const val WEB_CLIENT_ID = "447747395966-3shresouu36769er1b9656oec8vd13aa.apps.googleusercontent.com"

@Composable
fun LoginScreen() {
    val ctx = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var register by remember { mutableStateOf(false) }

    val gClient = remember {
        GoogleSignIn.getClient(
            ctx,
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(WEB_CLIENT_ID).requestEmail().build()
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        try {
            val acc = GoogleSignIn.getSignedInAccountFromIntent(r.data).getResult(ApiException::class.java)
            val cred = GoogleAuthProvider.getCredential(acc.idToken, null)
            auth.signInWithCredential(cred).addOnCompleteListener { t ->
                busy = false
                if (!t.isSuccessful) error = "Google girişi başarısız: ${t.exception?.localizedMessage}"
            }
        } catch (e: ApiException) {
            busy = false
            error = "Google girişi başarısız (kod ${e.statusCode})"
        }
    }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("AuraChat", fontSize = 36.sp, color = AuraGreen)
        Spacer(Modifier.height(32.dp))
        OutlinedTextField(
            value = email, onValueChange = { email = it }, label = { Text("E-posta") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password, onValueChange = { password = it }, label = { Text("Şifre") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )
        error?.let { Spacer(Modifier.height(12.dp)); Text(it, color = Color(0xFFEF4444)) }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                if (email.isBlank() || password.isBlank()) {
                    error = "E-posta ve şifre gir."
                } else if (register && password.length < 6) {
                    error = "Şifre en az 6 karakter olmalı."
                } else {
                    busy = true
                    error = null
                    if (register) {
                        auth.createUserWithEmailAndPassword(email.trim().lowercase(), password).addOnCompleteListener { t ->
                            busy = false
                            if (!t.isSuccessful) error = "Kayıt başarısız: ${t.exception?.localizedMessage}"
                            else t.result?.user?.sendEmailVerification()
                        }
                    } else {
                        auth.signInWithEmailAndPassword(email.trim(), password).addOnCompleteListener { t ->
                            busy = false
                            if (!t.isSuccessful) {
                                error = "Giriş başarısız: ${t.exception?.localizedMessage}"
                            } else if (auth.currentUser?.isEmailVerified == false) {
                                auth.currentUser?.sendEmailVerification()
                                auth.signOut()
                                error = "E-postanı henüz onaylamadın. Sana yeni bir onay e-postası gönderdik."
                            }
                        }
                    }
                }
            },
            enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AuraGreen)
        ) { Text(if (register) "Hesap oluştur" else "Giriş yap") }
        androidx.compose.material3.TextButton(onClick = { register = !register; error = null }) {
            Text(if (register) "Zaten hesabım var — giriş yap" else "Hesabın yok mu? Kayıt ol", color = AuraGreen)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = {
                busy = true; error = null
                gClient.signOut().addOnCompleteListener { launcher.launch(gClient.signInIntent) }
            },
            enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("Google ile giriş yap") }
    }
}

/** E-posta onay bekleme ekranı (kayıt sonrası). Onaylanınca onVerified çağrılır. */
@Composable
fun VerifyEmailScreen(email: String, onVerified: () -> Unit, onBack: () -> Unit) {
    val auth = remember { FirebaseAuth.getInstance() }
    var msg by remember { mutableStateOf<String?>(null) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(3000)
            val u = auth.currentUser ?: break
            try { u.reload().await() } catch (e: Throwable) {}
            if (u.isEmailVerified) { onVerified(); break }
        }
    }
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("E-postanı onayla", fontSize = 24.sp, color = Color.White)
        Spacer(Modifier.height(12.dp))
        Text("$email adresine bir onay bağlantısı gönderdik. Bağlantıya dokununca bu ekran kendiliğinden devam eder.",
            color = AuraMuted, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        msg?.let { Spacer(Modifier.height(10.dp)); Text(it, color = AuraGreen, fontSize = 13.sp) }
        Spacer(Modifier.height(20.dp))
        OutlinedButton(
            onClick = { auth.currentUser?.sendEmailVerification()?.addOnCompleteListener { msg = "Onay e-postası tekrar gönderildi" } },
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) { Text("Tekrar gönder") }
        androidx.compose.material3.TextButton(onClick = onBack) { Text("Geri dön", color = AuraMuted) }
    }
}

/** Kayıt adım 2: kullanıcı adı + telefon (+90) + isteğe bağlı profil resmi */
@Composable
fun ProfileSetupScreen(email: String, onSave: suspend (name: String, phone10: String, avatar: String) -> String?) {
    val ctx = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var avatar by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var cropUri by remember { mutableStateOf<android.net.Uri?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u -> if (u != null) cropUri = u }
    val hintLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        try {
            val num = com.google.android.gms.auth.api.identity.Identity.getSignInClient(ctx).getPhoneNumberFromIntent(r.data)
            val d = num.filter { it.isDigit() }
            if (d.length >= 10) phone = d.takeLast(10)
        } catch (e: Throwable) {}
    }
    fun pickPhone() {
        try {
            val act = ctx as android.app.Activity
            com.google.android.gms.auth.api.identity.Identity.getSignInClient(act)
                .getPhoneNumberHintIntent(com.google.android.gms.auth.api.identity.GetPhoneNumberHintIntentRequest.builder().build())
                .addOnSuccessListener { pi ->
                    try { hintLauncher.launch(androidx.activity.result.IntentSenderRequest.Builder(pi.intentSender).build()) } catch (e: Throwable) {}
                }
                .addOnFailureListener { error = "Telefon numarası önerisi alınamadı, elle yaz." }
        } catch (e: Throwable) { error = "Telefon numarası önerisi alınamadı, elle yaz." }
    }

    val cu = cropUri
    if (cu != null) AvatarCropper(cu, 320, onDone = { d -> avatar = d; cropUri = null }, onCancel = { cropUri = null })

    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Profilini tamamla", fontSize = 24.sp, color = Color.White)
        Spacer(Modifier.height(20.dp))
        androidx.compose.foundation.layout.Box(
            Modifier.size(104.dp).clickable {
                picker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            contentAlignment = Alignment.BottomEnd
        ) {
            Avatar(name.ifBlank { "?" }, avatar, 104.dp)
            androidx.compose.foundation.layout.Box(
                Modifier.size(32.dp).clip(androidx.compose.foundation.shape.CircleShape).background(AuraBtn),
                contentAlignment = Alignment.Center
            ) { androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Default.CameraAlt, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
        }
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = name, onValueChange = { name = it }, label = { Text("Kullanıcı adı") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = phone, onValueChange = { v -> phone = v.filter { it.isDigit() }.takeLast(10) },
            label = { Text("Telefon (5XX XXX XX XX)") }, prefix = { Text("+90 ") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            trailingIcon = {
                androidx.compose.material3.TextButton(onClick = { pickPhone() }) { Text("Seç", color = AuraGreen) }
            }
        )
        error?.let { Spacer(Modifier.height(12.dp)); Text(it, color = Color(0xFFEF4444)) }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                if (name.isBlank() || phone.length != 10) {
                    error = "Kullanıcı adı ve 10 haneli telefon numarası gerekli."
                } else {
                    busy = true; error = null
                    scope.launch {
                        val e = onSave(name.trim(), phone, avatar)
                        if (e != null) { error = e; busy = false }
                    }
                }
            },
            enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AuraGreen)
        ) { Text(if (busy) "Kaydediliyor…" else "Kaydı tamamla") }
    }
}
